/**
 * Created by jy25 on 8/19/2015.
 */

var gulp = require('gulp');
var coffee = require('gulp-coffee');
var gutil = require('gulp-util');
var del = require('del');
var server = require( 'gulp-develop-server' );
var runSequence = require('run-sequence');

/**
 * Clean dist folder
 */
gulp.task('clean', function(cb) {
  del(['dist/**/*.js'], cb)
});

/**
 * compile coffee script
 */
gulp.task('coffee', function() {
  return gulp.src('./src/**/*.coffee')
    .pipe(coffee({bare: true}).on('error', gutil.log))
    .pipe(gulp.dest('./dist/'));
});

/**
 * copy some project file
 */
gulp.task('copy', function() {
  gulp.src(['./redis-dog.ini'])
    .pipe(gulp.dest('./dist'));

});

/**
 * start server
 */
gulp.task('serve', function () {
  server.listen(
    {
      path: 'dist/index.js',
      execArgv: ['--harmony']
    });
});

gulp.task('server-restart', function(){
  server.restart();
});

gulp.task('watch', function(){
  gulp.watch([
    'src/**/*.coffee',
    'src/**/*.js'
  ], {debounceDelay: 2000}, ['reload'])
});

gulp.task('reload', function(callback){
  runSequence('clean',
    ['copy', 'coffee'],
    'server-restart',
    callback);
});

/**
 * default task
 */
gulp.task('default', function(callback){
  runSequence('clean',
    ['copy', 'coffee'],
    'serve',
    'watch',
    callback);
});