﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Mail
{
    [RestService("/mail/london2-content")]
    public class LondonIIMailQuery
    {
        public string CompanyCode { get; set; }

        public string CountryCode { get; set; }

        public string LanguageCode { get; set; }

        public string SystemID { get; set; }

        public string TemplateID { get; set; }

        public List<MailTemplateVariable> MailTemplateVariables { get; set; }
    }
}
