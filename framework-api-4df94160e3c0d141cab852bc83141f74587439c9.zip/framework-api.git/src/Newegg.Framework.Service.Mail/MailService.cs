﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Mail.Components;
using Newegg.Framework.Service.Mail.Models;

namespace Newegg.Framework.Service.Mail
{
    public class MailService : RestServiceBase<MailRequest>
    {
        public override object OnPost(MailRequest request)
        {
            MailSendResult response = new MailSendResult();
            string failedReason = string.Empty;
            try
            {
                if (request.MailType == Models.MailType.Smtp)
                {
                    new SmtpMailComponent().SendEmail(request.ToSmtpMailMessage());
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(request.LondonIISetting.TemplateID))
                    {
                        new LondonIIComponent().SendEmail(request.ToLondonIIEmailMessage());
                    }
                    else
                    {
                        new LondonIIComponent().SendTemplateEmail(request.ToLondonIITemplateEmailMessage(), request.LondonIISetting.MailTemplateVariables.ToKeyValue());
                    }
                }

                response.IsSendSuccess = true;
            }
            catch (Exception e)
            {
                response.IsSendSuccess = false;
                failedReason = e.Message;
            }

            if (request.IsNeedLog)
            {
                MailExtendInfo extend = new MailExtendInfo();
                extend.IsSendSuccessfully = response.IsSendSuccess;
                extend.SendFailedReason = failedReason;
                string logUri = new LogClient().RecoredMailLog(request, extend);
                response.MailLogUri = logUri;
            }
            
            return response;
        }        
    }
}
