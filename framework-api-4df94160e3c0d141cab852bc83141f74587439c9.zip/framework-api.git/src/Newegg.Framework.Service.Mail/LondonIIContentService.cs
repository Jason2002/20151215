﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Mail.LondonIIMailService;
using Newegg.Framework.Service.Mail.Models;

namespace Newegg.Framework.Service.Mail
{
    public class LondonIIContentService : RestServiceBase<LondonIIMailQuery>
    {
        public override object OnPost(LondonIIMailQuery request)
        {
            EmailServiceCenterProxyClient client = new LondonIIMailService.EmailServiceCenterProxyClient();
            var keyValues = request.MailTemplateVariables.ToKeyValue();
            if(keyValues == null)
            {
                keyValues = new List<KeyValue>();
            }
            var content = client.GetEmailContentByTemplate(GetQueryMessage(request), keyValues.ToArray());

            MailRequest result = new MailRequest();
            if (content != null)
            {
                result.From = content.FromName;
                result.Subject = content.Subject;
                result.Body = content.Body;
            }
            return result;
        }

        private GetEmailContentMessageV10 GetQueryMessage(LondonIIMailQuery request)
        {
            GetEmailContentMessageV10 message = new GetEmailContentMessageV10
            {
                CompanyCode = request.CompanyCode,
                CountryCode = request.CountryCode,
                LanguageCode = request.LanguageCode,
                SystemID = request.SystemID,
                TemplateID = request.TemplateID,
            };
            return message;
        }
    }
}
