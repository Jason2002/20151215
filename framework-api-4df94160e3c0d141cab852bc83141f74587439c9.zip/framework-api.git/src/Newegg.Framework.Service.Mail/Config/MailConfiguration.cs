﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Xml;

namespace Newegg.Framework.Service.Mail.Config
{
    public class MailConfiguration : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, XmlNode section)
        {
            MailSetting setting = new MailSetting();

            if (section != null && section.Attributes != null)
            {
                if (section.Attributes["HostEnvironment"] != null && section.Attributes["HostEnvironment"].Value != null)
                {
                    setting.HostEnvironment = section.Attributes["HostEnvironment"].Value.Trim();
                }
                if (section.Attributes["MaxAttachmentSize_MB"] != null && section.Attributes["MaxAttachmentSize_MB"].Value != null)
                {
                    setting.MasAttachmentSize = Int32.Parse(section.Attributes["MaxAttachmentSize_MB"].Value.Trim());
                }
                if (section.Attributes["MaxAttachmentCount"] != null && section.Attributes["MaxAttachmentCount"].Value != null)
                {
                    setting.MaxAttachmentCount = Int32.Parse(section.Attributes["MaxAttachmentCount"].Value.Trim());
                }
                if (section.Attributes["MailLogGlobalName"] != null && section.Attributes["MailLogGlobalName"].Value != null)
                {
                    setting.MailLogGlobalName = section.Attributes["MailLogGlobalName"].Value.Trim();
                }
                if (section.Attributes["MailLogLocalName"] != null && section.Attributes["MailLogLocalName"].Value != null)
                {
                    setting.MailLogLocalName = section.Attributes["MailLogLocalName"].Value.Trim();
                }
                if (section.Attributes["MailLogCategoryName"] != null && section.Attributes["MailLogCategoryName"].Value != null)
                {
                    setting.MailLogCategoryName = section.Attributes["MailLogCategoryName"].Value.Trim();
                }
                if (section.Attributes["DefaultDomain"] != null && section.Attributes["DefaultDomain"].Value != null)
                {
                    setting.DefaultDomain = section.Attributes["DefaultDomain"].Value.Trim();
                }
                if (section.HasChildNodes)
                {
                    foreach (XmlNode node in section.ChildNodes)
                    {
                        if (node.Name.Equals("mailServers", StringComparison.InvariantCultureIgnoreCase) && node.HasChildNodes)
                        {
                            foreach (XmlNode server in node.ChildNodes)
                            {
                                if (server.Name.Equals("server", StringComparison.InvariantCultureIgnoreCase) && server.Attributes != null)
                                {
                                    if (setting.MailServers == null)
                                    {
                                        setting.MailServers = new List<MailServer>();
                                    }
                                    MailServer serverSetting = new MailServer();
                                    if (server.Attributes["address"] != null && server.Attributes["address"].Value != null)
                                    {
                                        serverSetting.Address = server.Attributes["address"].Value.Trim();
                                    }
                                    if (server.Attributes["userName"] != null && server.Attributes["userName"].Value != null)
                                    {
                                        serverSetting.UserName = server.Attributes["userName"].Value.Trim();
                                    }
                                    if (server.Attributes["password"] != null && server.Attributes["password"].Value != null)
                                    {
                                        serverSetting.Password = server.Attributes["password"].Value.Trim();
                                    }
                                    if (server.Attributes["domain"] != null && server.Attributes["domain"].Value != null)
                                    {
                                        serverSetting.Domain = server.Attributes["domain"].Value.Trim();
                                    }
                                    setting.MailServers.Add(serverSetting);
                                }
                            }
                        }
                    }
                }
            }

            return setting;
        }
    }

    public class MailSetting
    {
        public List<MailServer> MailServers { get; set; }

        public string HostEnvironment { get; set; }

        public int MasAttachmentSize { get; set; }

        public int MaxAttachmentCount { get; set; }

        public string MailLogGlobalName { get; set; }

        public string MailLogLocalName { get; set; }

        public string MailLogCategoryName { get; set; }

        public string DefaultDomain { get; set; }
    }

    public class MailServer
    {
        public string Address { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public string Domain { get; set; }
    }
}
