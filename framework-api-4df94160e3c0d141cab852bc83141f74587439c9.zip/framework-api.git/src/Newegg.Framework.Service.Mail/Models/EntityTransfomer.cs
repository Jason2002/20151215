﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using Newegg.API.Exceptions;
using Newegg.Framework.Service.Mail.Config;
using Newegg.Framework.Service.Mail.LondonIIMailService;

namespace Newegg.Framework.Service.Mail.Models
{
    public static class EntityTransfomer
    {
        #region Smtp Mail Entity Transform

        public static MailMessage ToSmtpMailMessage(this MailRequest request)
        {
            MailSetting setting = ConfigurationManager.GetSection("mailSetting") as MailSetting;
            MailMessage message = new MailMessage();

            message.Subject = request.Subject;
            message.Body = request.Body;
            if (!string.IsNullOrWhiteSpace(request.From))
            {
                message.From = new MailAddress(request.From);
            }
            SetDestAddressToMailMessage(message, request, setting);
            message.SubjectEncoding = TransformEncodingFromContract(request.SmtpSetting.SubjectEncoding);
            message.BodyEncoding = TransformEncodingFromContract(request.SmtpSetting.BodyEncoding);
            message.IsBodyHtml = request.ContentType == MailContentType.Html ? true : false;
            message.Priority = TransformMailPriorityFromContract(request.Priority);
            SetAttachmentToMailMessage(message, request.SmtpSetting.Attachments, setting);
            return message;
        }

        private static void SetDestAddressToMailMessage(MailMessage mail, MailRequest request, MailSetting setting)
        {
            if (!string.IsNullOrWhiteSpace(request.To))
            {
                string[] toAddresses = request.To.Trim().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < toAddresses.Length; i++)
                {
                    if (!string.IsNullOrEmpty(toAddresses[i]))
                    {
                        string temp = GetMailAddress(toAddresses[i], setting.DefaultDomain);
                        if (!string.IsNullOrEmpty(temp))
                        {
                            mail.To.Add(temp);
                        }
                    }
                }
            }
            if (!string.IsNullOrWhiteSpace(request.CC))
            {
                string[] ccAddresses = request.CC.Trim().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < ccAddresses.Length; i++)
                {
                    if (!string.IsNullOrEmpty(ccAddresses[i]))
                    {
                        string temp = GetMailAddress(ccAddresses[i], setting.DefaultDomain);
                        if (!string.IsNullOrEmpty(temp))
                        {
                            mail.CC.Add(temp);
                        }
                    }
                }
            }
            if (!string.IsNullOrWhiteSpace(request.BCC))
            {
                string[] bccAddresses = request.BCC.Trim().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < bccAddresses.Length; i++)
                {
                    if (!string.IsNullOrEmpty(bccAddresses[i]))
                    {
                        string temp = GetMailAddress(bccAddresses[i], setting.DefaultDomain);
                        if (!string.IsNullOrEmpty(temp))
                        {
                            mail.Bcc.Add(temp);
                        }
                    }
                }
            }
        }

        private static Dictionary<string, string> s_CacheMailAddress = new Dictionary<string, string>();
        internal static string GetMailAddress(string address, string domainName)
        {
            if (address.IndexOf("@") > 0)
            {
                return address;
            }

            //by user short name
            if (address.Trim().Length == 4)
            {
                return GetUserMailById(address, domainName);
            }

            //by group name
            if (address.Trim().StartsWith("*"))
            {
                return GetGroupMailByName(address, domainName);
            }

            return address;
        }

        private static string GetUserMailById(string shortName, string domainName)
        {
            string key = shortName.Trim().ToLower();
            string mailAddress;
            if (!s_CacheMailAddress.TryGetValue(key, out mailAddress))
            {
                DirectorySearcher ds = new DirectorySearcher()
                {
                    SearchRoot = new DirectoryEntry("LDAP://" + domainName),
                    Filter = String.Format("(&(objectCategory=User)(sAMAccountName={0}))", shortName)
                };

                SearchResult sr = ds.FindOne();

                if (sr != null)
                {
                    DirectoryEntry entry = sr.GetDirectoryEntry();

                    if (entry != null)
                    {
                        mailAddress = entry.Properties["mail"].Value as String;
                        if (!string.IsNullOrEmpty(mailAddress))
                        {
                            lock (typeof(EntityTransfomer))
                            {
                                if (!s_CacheMailAddress.ContainsKey(key))
                                {
                                    s_CacheMailAddress.Add(key, mailAddress);
                                }
                            }
                        }
                        else
                        {
                            //throw new HttpError(ErrorCodes.EmailAddressError, string.Format("Send mail failed, can not found email address for user {0}.", shortName));
                            return string.Empty;
                        }
                    }

                }
                else
                {
                    //throw new HttpError(ErrorCodes.EmailAddressError, string.Format("Send mail failed, can not found user account {0} in {1}", shortName, domainName));
                    return string.Empty;
                }
            }

            return mailAddress;
        }

        private static string GetGroupMailByName(string groupName, string domainName)
        {
            string key = groupName.Trim().ToLower();
            string mailAddress;
            if (!s_CacheMailAddress.TryGetValue(key, out mailAddress))
            {
                DirectorySearcher ds = new DirectorySearcher()
                {
                    SearchRoot = new DirectoryEntry("LDAP://" + domainName),
                    Filter = String.Format("(&(objectCategory=Group)(cn={0}))", groupName)
                };

                SearchResult sr = ds.FindOne();

                if (sr != null)
                {
                    DirectoryEntry entry = sr.GetDirectoryEntry();

                    if (entry != null)
                    {
                        mailAddress = entry.Properties["mail"].Value as String;
                        if (!string.IsNullOrEmpty(mailAddress))
                        {
                            lock (typeof(EntityTransfomer))
                            {
                                if (!s_CacheMailAddress.ContainsKey(key))
                                {
                                    s_CacheMailAddress.Add(key, mailAddress);
                                }
                            }
                        }
                        else
                        {
                            //throw new HttpError(ErrorCodes.EmailAddressError, string.Format("Send mail failed, can not found email address for user {0}.", shortName));
                            return string.Empty;
                        }
                    }

                }
                else
                {
                    //throw new HttpError(ErrorCodes.EmailAddressError, string.Format("Send mail failed, can not found user account {0} in {1}", shortName, domainName));
                    return string.Empty;
                }
            }

            return mailAddress;
        }

        private static System.Text.Encoding TransformEncodingFromContract(MailEncoding encoding)
        {
            switch (encoding)
            {
                case MailEncoding.ASCII:
                    return System.Text.Encoding.ASCII;
                case MailEncoding.UTF8:
                    return System.Text.Encoding.UTF8;
                case MailEncoding.UTF32:
                    return System.Text.Encoding.UTF32;
                case MailEncoding.Unicode:
                    return System.Text.Encoding.Unicode;
                default:
                    return System.Text.Encoding.UTF8;
            }
        }

        private static System.Net.Mail.MailPriority TransformMailPriorityFromContract(MailPriority priority)
        {
            switch (priority)
            {
                case MailPriority.High:
                    return System.Net.Mail.MailPriority.High;
                case MailPriority.Normal:
                    return System.Net.Mail.MailPriority.Normal;
                case MailPriority.Low:
                    return System.Net.Mail.MailPriority.Low;
                default:
                    return System.Net.Mail.MailPriority.Normal;
            }
        }

        private static void SetAttachmentToMailMessage(MailMessage mail, List<MailAttachment> attachments, MailSetting setting)
        {
            if (mail == null || attachments == null || attachments.Count == 0)
            {
                return;
            }
            if (attachments.Count > setting.MaxAttachmentCount)
            {
                throw new HttpError(ErrorCodes.AttachementsCountError,
                    string.Format("Attachment count is greater than max count, The max attchment count in configuration is {0}.",
                    setting.MaxAttachmentCount));
            }
            foreach (MailAttachment attachmentContract in attachments)
            {
                if (attachmentContract.FileContent != null
                    && attachmentContract.FileContent.Length > 0
                    && !string.IsNullOrWhiteSpace(attachmentContract.FileName))
                {
                    if (attachmentContract.FileContent.Length > setting.MasAttachmentSize * 1024 * 1024)
                    {
                        throw new HttpError(ErrorCodes.AttachementsSizeError,
                            string.Format("Attachment file size is larger than max file size.The max file size in configuration is {0}MB.",
                            setting.MasAttachmentSize));
                    }
                    Attachment attachment = new Attachment(
                        CreateMemoryStreamFromBytes(attachmentContract.FileContent),
                        attachmentContract.FileName, TransformMediaTypeFromContract(attachmentContract.MediaType));
                    attachment.ContentDisposition.FileName = attachmentContract.FileName;
                    mail.Attachments.Add(attachment);
                }
            }
        }

        private static MemoryStream CreateMemoryStreamFromBytes(byte[] inputData)
        {
            if (inputData == null || inputData.Length == 0)
            {
                return null;
            }
            MemoryStream result = new MemoryStream(inputData, false);
            return result;
        }

        private static string TransformMediaTypeFromContract(MediaType mediaType)
        {
            switch (mediaType)
            {
                case MediaType.GIF:
                    return System.Net.Mime.MediaTypeNames.Image.Gif;
                case MediaType.JPEG:
                    return System.Net.Mime.MediaTypeNames.Image.Jpeg;
                case MediaType.TIFF:
                    return System.Net.Mime.MediaTypeNames.Image.Tiff;
                case MediaType.PDF:
                    return System.Net.Mime.MediaTypeNames.Application.Pdf;
                case MediaType.RTF:
                    return System.Net.Mime.MediaTypeNames.Application.Rtf;
                case MediaType.SOAP:
                    return System.Net.Mime.MediaTypeNames.Application.Soap;
                case MediaType.ZIP:
                    return System.Net.Mime.MediaTypeNames.Application.Zip;
                case MediaType.Other:
                    return System.Net.Mime.MediaTypeNames.Application.Octet;
                default:
                    return System.Net.Mime.MediaTypeNames.Application.Octet;
            }
        }

        #endregion

        public static EmailMessageV10 ToLondonIIEmailMessage(this MailRequest message)
        {
            var mail = new EmailMessageV10();

            mail.FromName = message.From;
            mail.ToName = message.To;
            mail.CCName = message.CC;
            mail.BCCName = message.BCC;
            mail.Subject = message.Subject;
            mail.Body = message.Body;


            if (message.ContentType == MailContentType.Html)
            {
                mail.HtmlType = EmailHtmlType.Html;
            }
            else if (message.ContentType == MailContentType.Text)
            {
                mail.HtmlType = EmailHtmlType.Text;
            }

            if (message.Priority == MailPriority.Low)
            {
                mail.Priority = EmailPriority.Low;
            }
            else if (message.Priority == MailPriority.High)
            {
                mail.Priority = EmailPriority.High;
            }
            else
            {
                mail.Priority = EmailPriority.Normal;
            }

            mail.CompanyCode = message.LondonIISetting.CompanyCode;
            mail.CountryCode = message.LondonIISetting.CountryCode;
            mail.LanguageCode = message.LondonIISetting.LanguageCode;
            mail.SystemID = message.LondonIISetting.SystemID;
            mail.CustomerNumber = message.LondonIISetting.CustomerNumber;

            return mail;
        }

        public static TemplateEmailMessageV10 ToLondonIITemplateEmailMessage(this MailRequest message)
        {
            var template = new TemplateEmailMessageV10();

            template.ToName = message.To;
            template.CCName = message.CC;
            template.BCCName = message.BCC;
            template.CompanyCode = message.LondonIISetting.CompanyCode;
            template.CountryCode = message.LondonIISetting.CountryCode;
            template.LanguageCode = message.LondonIISetting.LanguageCode;
            template.SystemID = message.LondonIISetting.SystemID;
            template.TemplateID = message.LondonIISetting.TemplateID;
            template.CustomerNumber = message.LondonIISetting.CustomerNumber;

            return template;
        }

        public static List<KeyValue> ToKeyValue(this List<MailTemplateVariable> variables)
        {
            if (variables == null)
            {
                return null;
            }

            var keyValue = new List<KeyValue>();

            foreach (var variable in variables)
            {
                keyValue.Add(new KeyValue { Key = variable.Key, Value = variable.Value });
            }

            return keyValue;
        }
    }
}
