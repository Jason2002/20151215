﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Service.Mail.LondonIIMailService;

namespace Newegg.Framework.Service.Mail.Components
{
    public class LondonIIComponent
    {
        public void SendEmail(EmailMessageV10 mail)
        {
            new EmailServiceCenterProxyClient().SendEmail(mail);
        }

        public void SendTemplateEmail(TemplateEmailMessageV10 mail, List<KeyValue> dataVariables)
        {
            new EmailServiceCenterProxyClient().SendEmailByTemplate(mail, dataVariables.ToArray());

        }
    }
}
