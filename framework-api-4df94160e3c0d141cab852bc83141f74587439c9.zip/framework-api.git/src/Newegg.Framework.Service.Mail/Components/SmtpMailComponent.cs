﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using Newegg.Framework.Service.Mail.Config;

namespace Newegg.Framework.Service.Mail.Components
{
    public class SmtpMailComponent
    {
        public void SendEmail(MailMessage mail)
        {
            MailSetting setting = ConfigurationManager.GetSection("mailSetting") as MailSetting;

            if (!string.IsNullOrWhiteSpace(setting.HostEnvironment))
            {
                mail.Subject = mail.Subject.Replace("#HostEnvironment#", setting.HostEnvironment);
            }

            bool isSuccessful = false;
            var mailServerList = setting.MailServers;
            string message = string.Empty;
            foreach (var server in mailServerList)
            {
                try
                {
                    isSuccessful = Invoke(mail, server);
                    break;
                }
                catch(Exception e)
                {
                    message += e.Message + System.Environment.NewLine;
                }
            }
            if (isSuccessful)
            {
                return;
            }
            else
            {
                throw new Exception(message);
            }
        }

        private bool Invoke(MailMessage mail, MailServer server)
        {
            SmtpClient mailClient = new SmtpClient();
            mailClient.Host = server.Address;

            if (!string.IsNullOrWhiteSpace(server.UserName))
            {
                mailClient.Credentials = new NetworkCredential(
                        server.UserName,
                        server.Password,
                        server.Domain
                    );
            }
            int retryTimes = 2;
            for (int i = 0; i < retryTimes; i++)
            {
                try
                {
                    mailClient.Send(mail);
                    break;
                }
                catch (SmtpException smtpException)
                {
                    //忽略无效收件人
                    if (smtpException.StatusCode == SmtpStatusCode.MailboxUnavailable)
                    {
                        break;
                    }

                    if (i == retryTimes - 1)
                    {
                        throw;
                    }
                    else
                    {
                        System.Threading.Thread.Sleep(TimeSpan.FromSeconds(0.5));
                    }
                }
            }
            return true;
        }
    }
}
