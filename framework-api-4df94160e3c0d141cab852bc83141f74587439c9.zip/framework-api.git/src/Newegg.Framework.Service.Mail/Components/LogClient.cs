﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using Newegg.API.Client;
using Newegg.Framework.Service.Mail.Config;

namespace Newegg.Framework.Service.Mail.Components
{
    public class LogClient
    {
        public string RecoredMailLog(MailRequest mail, MailExtendInfo mailExtendInfo)
        {
            LogEntry log = new LogEntry();
            log.ExtendedProperties = new List<ExtendProperty>();
            log.ExtendedProperties.Add(new ExtendProperty { Key = "IsSuccess", Value = mailExtendInfo.IsSendSuccessfully.ToString() });
            if (!string.IsNullOrEmpty(mailExtendInfo.SendFailedReason))
            {
                log.ExtendedProperties.Add(new ExtendProperty { Key = "FailedReason", Value = mailExtendInfo.SendFailedReason });
            }
            log.ExtendedProperties.Add(new ExtendProperty { Key = "Sender", Value = mail.From });
            log.ExtendedProperties.Add(new ExtendProperty { Key = "To", Value = mail.To });
            if (!string.IsNullOrEmpty(mail.CC))
            {
                log.ExtendedProperties.Add(new ExtendProperty { Key = "CC", Value = mail.CC });
            }
            if (!string.IsNullOrEmpty(mail.BCC))
            {
                log.ExtendedProperties.Add(new ExtendProperty { Key = "BCC", Value = mail.BCC });
            }
            log.ExtendedProperties.Add(new ExtendProperty { Key = "Subject", Value = mail.Subject });
            log.ExtendedProperties.Add(new ExtendProperty { Key = "MailBody", Value = mail.Body });
            if (mail.MailType == Models.MailType.Smtp && mail.SmtpSetting.Attachments != null
                && mail.SmtpSetting.Attachments.Count > 0)
            {
                string attachments = string.Empty;
                foreach (MailAttachment attachment in mail.SmtpSetting.Attachments)
                {
                    attachments += string.Format("Attachment Name:{0}, Attachment Type:{1}.  ", attachment.FileName, attachment.MediaType);
                }
                log.ExtendedProperties.Add(new ExtendProperty { Key = "Attachments", Value = attachments });
            }
            var setting = ConfigurationManager.GetSection("mailSetting") as MailSetting;
            log.GlobalName = setting.MailLogGlobalName;
            log.LocalName = setting.MailLogLocalName;
            log.CategoryName = setting.MailLogCategoryName;
            log.LogServerName = HttpContext.Current.Server.MachineName;
            log.LogServerIP = GetIPAddress(log.LogServerName);
            log.LogType = mailExtendInfo.IsSendSuccessfully ? "I" : "E";
            log.LogUserName = "MailAPI";

            string apiUri = ConfigurationManager.AppSettings["FrameworkAPIAddress"];
            RestAPIClient client = new RestAPIClient(apiUri);
            AsyncResponseStatus response = client.Post<AsyncResponseStatus>("/log-entry", log);
            return response.ResourceUri;
        }

        private string GetIPAddress(string serverName)
        {
            string logServerIP = string.Empty;
            if (!string.IsNullOrEmpty(serverName))
            {
                IPAddress[] address = Dns.GetHostEntry(serverName).AddressList;
                if (address != null)
                {
                    foreach (IPAddress addr in address)
                    {
                        //过滤IPv6的地址信息
                        if (addr.ToString().Length <= 16 && addr.ToString().Length > 5)
                        {
                            logServerIP = addr.ToString();
                            break;
                        }
                    }
                }
            }
            return logServerIP;
        }
    }

    public class MailExtendInfo
    {
        public bool IsSendSuccessfully { get; set; }

        public string SendFailedReason { get; set; }
    }

    public class LogEntry
    {
        public string LocalName { get; set; }


        public string GlobalName { get; set; }


        public string Content { get; set; }


        public string LogUserName { get; set; }


        public string CategoryName { get; set; }


        public string LogServerIP { get; set; }


        public string LogServerName { get; set; }


        public string LogType { get; set; }


        public List<ExtendProperty> ExtendedProperties { get; set; }

    }

    public class ExtendProperty
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }
}
