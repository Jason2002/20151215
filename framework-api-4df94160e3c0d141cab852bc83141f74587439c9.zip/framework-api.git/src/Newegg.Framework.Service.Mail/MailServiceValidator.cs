﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using FluentValidation;
using System.Text.RegularExpressions;
using Newegg.Framework.Service.Mail.Config;
using System.Configuration;

namespace Newegg.Framework.Service.Mail
{
    public class MailServiceValidator : CustomerValidator<MailRequest>
    {
        public MailServiceValidator()
        {
            RuleSet(ApplyTo.Post,
                () =>
                {
                    RuleFor(m => m.To, true).NotNull().NotEmpty().Must(to =>
                    {
                        string[] toAddresses = to.Trim().Split(new char[] {';'}, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < toAddresses.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(toAddresses[i]))
                            {
                                bool match = Regex.IsMatch(toAddresses[i].ToUpper(), @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$");
                                if (!match)
                                {
                                    return match;
                                }
                            }
                        }
                        return true;
                    }).WithMessage("Invalid mail to address").When(m => m.MailType == Models.MailType.LondongII);

                    RuleFor(m => m.From).Must(from => Regex.IsMatch(@from.ToUpper(), @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$"))
                        .WithMessage("Invalid mail from address").When(m => !string.IsNullOrWhiteSpace(m.From));
                    
                    RuleFor(m => m.CC).Must(cc =>
                        {
                            string[] toAddresses = cc.Trim().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                            for (int i = 0; i < toAddresses.Length; i++)
                            {
                                if (!string.IsNullOrEmpty(toAddresses[i]))
                                {
                                    bool match = Regex.IsMatch(toAddresses[i].ToUpper(), @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$");
                                    if (!match)
                                    {
                                        return match;
                                    }
                                }
                            }
                            return true;
                        }).WithMessage("Invalid mail cc address").When(m => !string.IsNullOrWhiteSpace(m.CC) && m.MailType == Models.MailType.LondongII);

                    RuleFor(m => m.BCC).Must(bcc =>
                    {
                        string[] toAddresses = bcc.Trim().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < toAddresses.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(toAddresses[i]))
                            {
                                bool match = Regex.IsMatch(toAddresses[i].ToUpper(), @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$");
                                if (!match)
                                {
                                    return match;
                                }
                            }
                        }
                        return true;
                    }).WithMessage("Invalid mail bcc address").When(m => !string.IsNullOrWhiteSpace(m.BCC) && m.MailType == Models.MailType.LondongII);

                    RuleFor(m => m.Subject, true).NotNull().NotEmpty().When(m => m.MailType == Models.MailType.Smtp); ;
                    
                    RuleFor(m => m.SmtpSetting).NotNull().When(m => m.MailType == Models.MailType.Smtp);

                    RuleFor(m => m.SmtpSetting).SetValidator(new SmtpSettingValidator()).When(m => m.MailType == Models.MailType.Smtp);

                    RuleFor(m => m.LondonIISetting).NotNull().When(m => m.MailType == Models.MailType.LondongII);
                    
                    RuleFor(m => m.LondonIISetting).SetValidator(new LondonIISettingValidator()).When(m => m.MailType == Models.MailType.LondongII);
                });
        }
    }

    public class LondonIISettingValidator : CustomerValidator<LondonIISetting>
    {
        public LondonIISettingValidator()
        {
            RuleFor(s => s.CompanyCode, true).NotNull().NotEmpty();
            RuleFor(s => s.CountryCode, true).NotNull().NotEmpty();
            RuleFor(s => s.LanguageCode, true).NotNull().NotEmpty();
            RuleFor(s => s.SystemID, true).NotNull().NotEmpty();
            RuleFor(s => s.MailTemplateVariables).NotNull().When(s => !string.IsNullOrWhiteSpace(s.TemplateID));
        }
    }

    public class SmtpSettingValidator : CustomerValidator<SmtpSetting>
    {
        public SmtpSettingValidator()
        {
            MailSetting setting = ConfigurationManager.GetSection("mailSetting") as MailSetting;
            RuleFor(s => s.Attachments, true).Must(a =>
                {
                    
                    if (a.Count > setting.MaxAttachmentCount)
                    {
                        return false;
                    }
                    return true;
                }).WithMessage(string.Format("Attachment count is greater than max count, The max attchment count in configuration is {0}.", setting.MaxAttachmentCount)).When(s => s.Attachments != null && s.Attachments.Count > 0);

            RuleFor(s => s.Attachments, true).Must(a =>
            {

                foreach (MailAttachment attachmentContract in a)
                {
                    if (attachmentContract.FileContent.Length > setting.MasAttachmentSize * 1024 * 1024)
                    {
                        return false;
                    }

                }
                return true;
            }).WithMessage(string.Format("Attachment file size is larger than max file size.The max file size in configuration is {0}MB.", setting.MasAttachmentSize)).When(s => s.Attachments != null && s.Attachments.Count > 0);
        }
    }
}
