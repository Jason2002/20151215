﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.ServiceHost;

namespace Newegg.Framework.Service.Nair
{
    public class AppInit : AppHostBase
    {
        public override void Init()
        {
            this.RegisterValidators(typeof (AppInit).Assembly);
        }
    }
}
