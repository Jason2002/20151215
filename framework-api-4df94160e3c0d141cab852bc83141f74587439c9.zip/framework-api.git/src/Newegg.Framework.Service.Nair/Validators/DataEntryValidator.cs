﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentValidation;
using Newegg.API.Validation;

namespace Newegg.Framework.Service.Nair.Validators
{
    public class DataEntryValidator : CustomerValidator<Dto.DataEntryRequest>
    {
        public DataEntryValidator()
        {
            RuleSet(ApplyTo.Get | ApplyTo.Put | ApplyTo.Delete, () =>
            {
                RuleFor(a => a.Database, true).NotNullorEmpty();
                RuleFor(a => a.Key, true).NotNullorEmpty();

            });
            RuleSet(ApplyTo.Put, () =>
            {
                RuleFor(a => a.Value, true).NotNullorEmpty();
                RuleFor(a => a.ExpireTime, true).GreaterThan(0);
            });
        }
    }
}
