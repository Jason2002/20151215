﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Nair.Dto
{
    [RestService("/database")]
    [RestService("/database/{Database}/{Key}")]
    public class DataEntryRequest
    {
        public string Database { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
        public int ExpireTime { get; set; }
    }

    public class DataEntryResponse
    {
        public string Database { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
