﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Nair.Dto
{
    [RestService("/database/database-info")]
    public class DbCacheEntry : global::Nair.Sdk.DatabaseEntry
    {
        
    }
}
