﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using Nair.Sdk;
using Newegg.API.Exceptions;
using Newegg.API.Interfaces;
using Newegg.API.Serialization;
using Newegg.Framework.Service.Nair.Biz;
using Newegg.Framework.Service.Nair.Dto;

namespace Newegg.Framework.Service.Nair.Service
{
    public class NairService : RestServiceBase<Dto.DataEntryRequest>
    {
        private const string PassHeader = "x-nair-password";
        private static string _password = string.Empty;

        protected override void OnBeforeExecute(DataEntryRequest request)
        {
            _password = RequestContext.GetHeader(PassHeader);
        }

        public override object OnGet(DataEntryRequest request)
        {
            var response = new NairBiz().Get(request, _password);
            if (response==null)
            {
                throw new HttpError(HttpStatusCode.NotFound, "", "Key not found in database");
            }
            return response;
        }

        public override object OnPut(DataEntryRequest request)
        {
            var biz = new NairBiz();
            biz.Update(request, _password);
            return request;
        }

        public override object OnDelete(DataEntryRequest request)
        {
            var biz = new NairBiz();
            biz.Delete(request, _password);
            return null;
        }
    }
}
