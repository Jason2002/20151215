﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nair.Sdk;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Nair.Dto;

namespace Newegg.Framework.Service.Nair.Service
{

    public class DbCacheService : RestServiceBase<Dto.DbCacheEntry>
    {
        public override object OnGet(DbCacheEntry request)
        {
            return DataCache.GetCache().Values;
        }

        public override object OnPost(DbCacheEntry request)
        {
            DataCache.UpdateCache(request);
            return request;
        }
    }
}
