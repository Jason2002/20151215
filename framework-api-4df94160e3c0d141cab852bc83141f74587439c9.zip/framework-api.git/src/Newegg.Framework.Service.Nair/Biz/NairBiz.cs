﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nair.Sdk;
using Newegg.Framework.Service.Nair.Dto;

namespace Newegg.Framework.Service.Nair.Biz
{
    public class NairBiz
    {
        private static NairClient _nairClient = NairFactory.GetNairClient();

        public DataEntryResponse Get(DataEntryRequest request, string password = null)
        {
            var value = _nairClient.Get(request.Database, request.Key, password);
            if (string.IsNullOrEmpty(value))
            {
                return null;
            }
            var response = new DataEntryResponse
            {
                Database = request.Database,
                Key = request.Key,
                Value = value
            };
            return response;
        }

        public void Update(DataEntryRequest request, string password = null)
        {
            _nairClient.Put(request.Database, request.Key, request.Value, request.ExpireTime, password);
        }

        public void Delete(DataEntryRequest request, string password = null)
        {
            _nairClient.Remove(request.Database, request.Key, password);
        }
    }
}
