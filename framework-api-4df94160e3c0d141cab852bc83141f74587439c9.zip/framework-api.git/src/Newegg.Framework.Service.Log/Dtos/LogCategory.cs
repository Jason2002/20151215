﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Newegg.API.Attributes;
using Newegg.API.Models;

namespace Newegg.Framework.Service.Log.Dtos
{
    [RestService("/log-entry/category")]
    [ResponseType(typeof(LogCategory))]
    public class LogCategory
    {

        public string GlobalID { get; set; }


        public string GlobalName { get; set; }


        public string LocalID { get; set; }


        public string LocalName { get; set; }


        public string CategoryName { get; set; }


        public string CategoryDescription { get; set; }

        [XmlIgnore]
        [IgnoreDataMember]
        public string DistributeConfig { get; set; }


        public string LogType { get; set; }


        public EmailNotificationConfig EmailNotification { get; set; }


        public string Status { get; set; }


        public string InUser { get; set; }


        public DateTime InDate { get; set; }


        public bool EnableRemoveLog { get; set; }


        public int RemoveOverDays { get; set; }
    }

    public class EmailNotificationConfig
    {
        public bool NeedNotify { get; set; }


        public string Subject { get; set; }


        public string Address { get; set; }


        public int Interval { get; set; }


        public bool FilterDuplicate { get; set; }
    }

    [ResponseType(typeof(LogCategory))]
    public class LogCategoryCollection
    {
        public int TotalCount { get; set; }

        public PageInfo PageInfo { get; set; }

        public List<LogCategory> LogCategories { get; set; }
    }

    //为了序列化数据库xml
    [XmlInclude(typeof(EmailNotificationConfigEntity))]
    public class NotificationConfigBase
    {
        public bool NeedNotify { get; set; }
    }

    public class EmailNotificationConfigEntity : NotificationConfigBase
    {
        public string Subject { get; set; }

        public string MailTo { get; set; }

        public int Interval { get; set; }

        public bool FilterDuplicate { get; set; }

    }
}
