﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Log.Dtos
{
    public static class LogCategoryExtension
    {
        public static void HandlerCategory(this LogCategory category)
        {
            if (category.RemoveOverDays == 0)
            {
                category.EnableRemoveLog = false;
                category.RemoveOverDays = 30;
            }
            else
            {
                category.EnableRemoveLog = true;
            }
            if (!string.IsNullOrEmpty(category.DistributeConfig))
            {
                List<NotificationConfigBase> configs = ServiceStack.Text.XmlSimpleSerializer.DeserializeFromString<List<NotificationConfigBase>>(category.DistributeConfig);
                if (configs != null && configs.Count > 0)
                {
                    var entity = (EmailNotificationConfigEntity)configs[0];
                    category.EmailNotification = new EmailNotificationConfig
                    {
                        Address = entity.MailTo,
                        FilterDuplicate = entity.FilterDuplicate,
                        Interval = entity.Interval,
                        NeedNotify = entity.NeedNotify,
                        Subject = entity.Subject
                    };
                }
            }
        }

        public static EmailNotificationConfigEntity GetNotiicationEntity(this LogCategory category)
        {
            if (!string.IsNullOrEmpty(category.DistributeConfig))
            {
                List<NotificationConfigBase> configs = ServiceStack.Text.XmlSimpleSerializer.DeserializeFromString<List<NotificationConfigBase>>(category.DistributeConfig);
                if (configs != null && configs.Count > 0)
                {
                    var entity = (EmailNotificationConfigEntity)configs[0];
                    return entity;
                }
            }

            return null;
        }
    }
}
