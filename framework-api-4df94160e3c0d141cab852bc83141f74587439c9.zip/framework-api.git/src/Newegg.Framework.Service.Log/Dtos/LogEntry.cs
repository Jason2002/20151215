﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Newegg.API.Attributes;
using Newegg.API.Models;

namespace Newegg.Framework.Service.Log.Dtos
{
    [RestService("/log-entry")]
    [RestService("/log-entry/{ID}")]
    [ResponseType(typeof(LogEntry))]
    public class LogEntry
    {
        #region Query Date
        [XmlIgnore]
        [IgnoreDataMember]
        public DateTime? From { get; set; }

        [XmlIgnore]
        [IgnoreDataMember]
        public DateTime? To { get; set; }
        #endregion

        public string ID { get; set; }

        
        public string LocalID { get; set; }

        
        public string LocalName { get; set; }

        
        public string GlobalID { get; set; }

        
        public string GlobalName { get; set; }

        
        public string Content { get; set; }

        
        public string LogUserName { get; set; }

        
        public DateTime LogCreateDate { get; set; }

        
        public string CategoryName { get; set; }

        
        public string LogServerIP { get; set; }

        
        public string LogServerName { get; set; }

        
        public string LogType { get; set; }


        public List<ExtendProperty> ExtendedProperties { get; set; }

        [XmlIgnore]
        [IgnoreDataMember]
        public string ExtendedPropertiesString { get; set; }

        
        public string ReferenceKey { get; set; }
    }

    public class ExtendProperty
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }

    [ResponseType(typeof(LogEntry))]
    public class LogEntryCollection
    {
        public int TotalCount { get; set; }

        public PageInfo PageInfo { get; set; }

        public List<LogEntry> LogEntries { get; set; }
    }
}
