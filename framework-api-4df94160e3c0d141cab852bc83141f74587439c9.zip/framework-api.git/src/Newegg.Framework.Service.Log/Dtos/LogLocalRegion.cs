﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Log.Dtos
{
    [RestService("/log-entry/local-region")]
    [RestService("/log-entry/local-region/{LocalID}")]
    [ResponseType(typeof(LogLocalRegion))]
    public class LogLocalRegion
    {   
        public string LocalID { get; set; }
   
        public string GlobalID { get; set; }
        
        public string GlobalName { get; set; }
        
        public string LocalName { get; set; }
        
        public string Status { get; set; }
    }
}
