﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Log.Dtos
{
    [RestService("/log-entry/global-region")]
    [RestService("/log-entry/global-region/{GlobalID}")]
    [ResponseType(typeof(LogGlobalRegion))]
    public class LogGlobalRegion
    {
        public string GlobalID { get; set; }

        public string GlobalName { get; set; }

        public string Status { get; set; }
    }
}
