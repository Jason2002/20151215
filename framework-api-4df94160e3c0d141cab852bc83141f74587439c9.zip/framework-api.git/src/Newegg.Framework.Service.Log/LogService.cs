﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Newegg.API.Async;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Log.Biz;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log
{
    public class LogService : RestServiceBase<LogEntry>
    {
        /*
        private void HandlerResponse(LogEntry log)
        {
            List<ExtendProperty> properties = new List<ExtendProperty>();
            if (!string.IsNullOrEmpty(log.ExtendedPropertiesString) && log.ExtendedPropertiesString.Trim().Length > 0)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(log.ExtendedPropertiesString);
                XmlNodeList list = xmlDoc.GetElementsByTagName("ExtendedPropertyData");
                foreach (XmlNode node in list)
                {
                    properties.Add(new ExtendProperty
                    {
                        Key = node.ChildNodes[0].InnerText, 
                        Value = node.ChildNodes[1].InnerText
                    });
                }

            }
            log.ExtendedProperties = properties;
        }

        protected override object OnAfterExecute(object response)
        {
            if ((response as LogEntry) != null)
            {
                LogEntry result = response as LogEntry;
                HandlerResponse(result);
                return result;
            }
            else if ((response as LogEntryCollection) != null)
            {
                LogEntryCollection results = response as LogEntryCollection;
                if (results.LogEntries != null && results.LogEntries.Count > 0)
                {
                    foreach (var item in results.LogEntries)
                    {
                        HandlerResponse(item);
                    }
                }
                return results;
            }
            else
            {
                return response;
            }
        }
        
        public override object OnGet(LogEntry request)
        {
            if (!string.IsNullOrWhiteSpace(request.ID))
            {
                return new LogBiz().GetLogById(request.ID);
            }
            else
            {
                if (!string.IsNullOrEmpty(request.GlobalName))
                {
                    var global = new GlobalBiz().GetGlobalByName(request.GlobalName);
                    if (global != null)
                    {
                        request.GlobalID = global.GlobalID;
                    }
                }
                if (!string.IsNullOrEmpty(request.LocalName))
                {
                    var locals = new LocalBiz().GetLocals(new LogLocalRegion { LocalName = request.LocalName });
                    if (locals != null && locals.Count > 0)
                    {
                        request.LocalID = locals[0].LocalID;
                    }
                }
                if (string.IsNullOrEmpty(this.RequestContext.RequestPageInfo.SortFields))
                {
                    RequestContext.RequestPageInfo.SortFields = "LogCreateDate";
                }
                if (string.IsNullOrEmpty(this.RequestContext.RequestPageInfo.Sort))
                {
                    RequestContext.RequestPageInfo.Sort = "desc";
                }
                return new LogBiz().GetLogEntries(request, RequestContext.RequestPageInfo);
            }
        }
        */
        public override object OnPost(LogEntry request)
        {
            var id = Guid.NewGuid().ToString();
            request.ID = id;
            if (string.IsNullOrWhiteSpace(request.LogType))
            {
                request.LogType = "I";
            }
            //Task.Factory.StartNew(() => new LogBiz().WriteLog(request));
            new LogBiz().WriteLog(request);

            return AsyncHandler.HandlerAsync(RequestContext, string.Format("/log-entry/{0}", id));
        }
    }
}
