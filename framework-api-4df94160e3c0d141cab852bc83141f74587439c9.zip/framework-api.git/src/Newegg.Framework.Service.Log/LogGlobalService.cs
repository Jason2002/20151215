﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Common;
using Newegg.API.Exceptions;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Log.Biz;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log
{
    public class LogGlobalService : RestServiceBase<LogGlobalRegion>
    {
        protected override void OnBeforeExecute(LogGlobalRegion request)
        {
            if (this.RequestContext.ExecuteContext.HttpMethod == HttpMethods.Post)
            {
                var find2 = new GlobalBiz().GetGlobalByName(request.GlobalName);
                if (find2 != null)
                {
                    throw new HttpError(ErrorCodes.GlobalNameExists, "Global Name Exists");
                }
            }
            if (this.RequestContext.ExecuteContext.HttpMethod == HttpMethods.Put)
            {
                var biz = new GlobalBiz();
                var find = biz.GetGlobalById(request.GlobalID);
                if (find == null)
                {
                    throw new HttpError(ErrorCodes.GlobalNotExists, "Global ID not Exists");
                }
                if (!request.GlobalName.Equals(find.GlobalName, StringComparison.InvariantCultureIgnoreCase))
                {
                    var exist = biz.GetGlobalByName(request.GlobalName);
                    if (exist != null)
                    {
                        throw new HttpError(ErrorCodes.GlobalNameExists, "Global Name Exists");
                    }
                }
            }
        }

        public override object OnGet(LogGlobalRegion request)
        {
            if (string.IsNullOrWhiteSpace(request.GlobalID))
            {
                return new GlobalBiz().GetGlobals(request);
            }
            else
            {
                return new GlobalBiz().GetGlobalById(request.GlobalID);
            }
        }

        public override object OnPost(LogGlobalRegion request)
        {
            return new GlobalBiz().CreateGlobal(request);
        }

        public override object OnPut(LogGlobalRegion request)
        {
            return new GlobalBiz().EditGlobal(request);
        }
    }
}
