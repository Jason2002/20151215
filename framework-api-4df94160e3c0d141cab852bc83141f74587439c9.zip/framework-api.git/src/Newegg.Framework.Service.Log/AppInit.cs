﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.ServiceHost;

namespace Newegg.Framework.Service.Log
{
    public class AppInit : AppHostBase
    {
        public override void Init()
        {
            this.RegisterValidators(typeof(AppInit).Assembly);
            this.SetDefaultPageInfo(10, 0, 50);
        }
    }
}
