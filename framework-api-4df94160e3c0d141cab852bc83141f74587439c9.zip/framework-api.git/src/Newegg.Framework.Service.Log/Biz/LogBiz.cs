﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using Newegg.API.Models;
using Newegg.Framework.Service.Log.Distributor;
using Newegg.Framework.Service.Log.Dtos;
using Newegg.Oversea.DataAccess;

namespace Newegg.Framework.Service.Log.Biz
{
    public class LogBiz
    {
        /*
        public LogEntry GetLogById(string id)
        {
            var command = DataCommandManager.GetDataCommand("GetLogEntry");
            return command.ExecuteEntity<LogEntry>(new { ID = id });
        }

        public LogEntryCollection GetLogEntries(LogEntry request, PageInfo pageInfo)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetLogEntries");
            DynamicParameters paras = new DynamicParameters();
            paras.Add("@TotalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
            paras.Add("@pageIndex", pageInfo.PageIndex);
            paras.Add("@pageSize", pageInfo.PageSize);
            string sortFields = string.Empty;
            if (pageInfo.SortFields.Equals("LocalName", StringComparison.InvariantCultureIgnoreCase))
            {
                sortFields = "c." + pageInfo.SortFields;
            }
            else if (pageInfo.SortFields.Equals("GlobalName", StringComparison.InvariantCultureIgnoreCase))
            {
                sortFields = "b." + pageInfo.SortFields;
            }
            else
            {
                sortFields = "a." + pageInfo.SortFields;
            }
            string orderby = sortFields + " " + pageInfo.Sort;
            string strWhere = string.Empty;
            if (!string.IsNullOrWhiteSpace(request.CategoryName))
            {
                strWhere += "AND a.CategoryName= @CategoryName ";
                paras.Add("@CategoryName", request.CategoryName);
            }
            if (!string.IsNullOrWhiteSpace(request.GlobalID))
            {
                strWhere += "AND a.GlobalID = @GlobalID ";
                paras.Add("@GlobalID", request.GlobalID);
            }
            if (!string.IsNullOrWhiteSpace(request.LocalID))
            {
                strWhere += "AND a.LocalID = @LocalID ";
                paras.Add("@LocalID", request.LocalID);
            }

            if (!string.IsNullOrWhiteSpace(request.ReferenceKey))
            {
                strWhere += "AND a.ReferenceKey like @ReferenceKey ";
                paras.Add("@ReferenceKey", request.ReferenceKey);
            }

            if (request.From.HasValue)
            {
                strWhere += "AND a.LogCreateDate >= @LogCreateDateFrom ";
                paras.Add("@LogCreateDateFrom", request.From.Value.Date, dbType: DbType.DateTime);
            }

            if (request.To.HasValue)
            {
                strWhere += "AND a.LogCreateDate < @LogCreateDateTo ";
                paras.Add("@LogCreateDateTo", request.To.Value.Date.AddDays(1), dbType: DbType.DateTime);
            }

            if (!string.IsNullOrWhiteSpace(request.LogType))
            {
                strWhere += "AND a.LogType = @LogType ";
                paras.Add("@LogType", request.LogType);
            }

            command.CommandText = string.Format(command.CommandText, orderby, strWhere);
            var collection = command.ExecuteEntityList<LogEntry>(paras);
            LogEntryCollection result = new LogEntryCollection();
            result.LogEntries = collection;
            result.PageInfo = pageInfo;
            result.TotalCount = paras.Get<Int32>("@TotalCount");
            return result;
        }
        */
        public void WriteLog(LogEntry request)
        {
            request.GlobalID = GetGlobalID(request.GlobalName);
            request.LocalID = GetLocalID(request.LocalName, request.GlobalID);
            var category = GetCategoryName(request.CategoryName, request.GlobalID, request.LocalID);
            request.CategoryName = category.CategoryName;

            //考虑到后面写SQL Server和发邮件的逻辑较慢，因此先写Elasticsearch
            var nodeUrls = ConfigurationManager.AppSettings["Framework.ElasticsearchNodes"];
            if (string.IsNullOrEmpty(nodeUrls) == false)
            {
                LogIndexBiz.Write(request);
            }
            /* 暂停写sql server
            if (request.ExtendedProperties != null && request.ExtendedProperties.Count > 0)
            {
                StringBuilder sb = new StringBuilder(100);
                sb.Append("<ExtendedProperties>");
                foreach (ExtendProperty kv in request.ExtendedProperties)
                {
                    sb.Append("<ExtendedPropertyData>");
                    sb.AppendFormat("<PropertyName>{0}</PropertyName>", kv.Key);
                    sb.AppendFormat("<PropertyValue><![CDATA[{0}]]></PropertyValue>", kv.Value);
                    sb.Append("</ExtendedPropertyData>");
                }
                sb.Append("</ExtendedProperties>");

                request.ExtendedPropertiesString = sb.ToString();
            }

            var command = DataCommandManager.GetDataCommand("CreateLogEntry");
            command.ExecuteNonQuery(request);
             */
            request.LogCreateDate = DateTime.Now;
            LogDistributorManager.Distribute(request);
        }

        private string GetGlobalID(string globalName)
        {
            var globalBiz = new GlobalBiz();
            var global = globalBiz.GetGlobalByName(globalName);
            if (global == null)
            {
                global = new LogGlobalRegion
                {
                    GlobalName = globalName,
                    Status = "A",
                };
                global = globalBiz.CreateGlobal(global);
            }
            return global.GlobalID;
        }

        private string GetLocalID(string localName, string globalID)
        {
            var localBiz = new LocalBiz();
            var locals = localBiz.GetLocals(new LogLocalRegion { LocalName = localName, GlobalID = globalID });
            if (locals == null || locals.Count == 0)
            {
                var local = new LogLocalRegion
                {
                    GlobalID = globalID,
                    LocalName = localName,
                    Status = "A",
                };
                local = localBiz.CreateLocal(local);
                return local.LocalID;
            }
            else
            {
                return locals[0].LocalID;
            }
            
        }

        private LogCategory GetCategoryName(string categoryName, string glocalID, string localID)
        {
            var categoryBiz = new CategoryBiz();
            var category = categoryBiz.GetCategory(glocalID, localID, categoryName);
            if (category == null)
            {
                category = new LogCategory
                {
                    CategoryName = categoryName,
                    GlobalID = glocalID,
                    LocalID = localID,
                    CategoryDescription = "Auto created by system",
                    EnableRemoveLog = true,
                    RemoveOverDays = 30,
                    LogType = "I",
                    InDate = DateTime.Now,
                    InUser = @"AuthCenterAdmin\bitkoo\AuthCenterAdmin[1014]",
                    Status = "A",
                    EmailNotification = new EmailNotificationConfig(),
                };
                category = categoryBiz.CreateCategory(category);
            }
            return category;
        }
    }
}
