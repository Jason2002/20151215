﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Newegg.API.Models;
using Newegg.Framework.Service.Log.Dtos;
using Newegg.Oversea.DataAccess;
using ServiceStack.Text;

namespace Newegg.Framework.Service.Log.Biz
{
    public class CategoryBiz
    {
        public LogCategory GetCategory(string globalId, string localId, string categoryName)
        {
            var command = DataCommandManager.GetDataCommand("GetLogCategory");
            return command.ExecuteEntity<LogCategory>(
                new
                {
                    GlobalID = globalId,
                    LocalID = localId,
                    CategoryName = categoryName,
                });
        }

        public LogCategoryCollection GetCategories(LogCategory request, PageInfo pageInfo)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetLogCategories");
            DynamicParameters paras = new DynamicParameters();
            paras.Add("@TotalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
            paras.Add("@pageIndex", pageInfo.PageIndex);
            paras.Add("@pageSize", pageInfo.PageSize);
            string sortFields = string.Empty;
            if (pageInfo.SortFields.Equals("LocalName", StringComparison.InvariantCultureIgnoreCase))
            {
                sortFields = "c." + pageInfo.SortFields;
            }
            else if (pageInfo.SortFields.Equals("GlobalName", StringComparison.InvariantCultureIgnoreCase))
            {
                sortFields = "b." + pageInfo.SortFields;
            }
            else
            {
                sortFields  = "a." + pageInfo.SortFields;
            }
            string orderby = sortFields + " " + pageInfo.Sort;
            string strWhere = string.Empty;
            if (!string.IsNullOrWhiteSpace(request.CategoryName))
            {
                strWhere += "AND a.CategoryName= @CategoryName ";
                paras.Add("@CategoryName", request.CategoryName);
            }
            if (!string.IsNullOrWhiteSpace(request.GlobalID))
            {
                strWhere += "AND a.GlobalID = @GlobalID ";
                paras.Add("@GlobalID", request.GlobalID);
            }
            if (!string.IsNullOrWhiteSpace(request.LocalID))
            {
                strWhere += "AND a.LocalID = @LocalID ";
                paras.Add("@LocalID", request.LocalID);
            }

            if (!string.IsNullOrWhiteSpace(request.Status))
            {
                strWhere += "AND a.Status = @Status ";
                paras.Add("@Status", request.Status);
            }

            if (!string.IsNullOrWhiteSpace(request.LogType))
            {
                strWhere += "AND a.LogType = @LogType ";
                paras.Add("@LogType", request.LogType);
            }

            command.CommandText = string.Format(command.CommandText, orderby, strWhere);
            var collection = command.ExecuteEntityList<LogCategory>(paras);
            LogCategoryCollection result = new LogCategoryCollection();
            result.LogCategories = collection;
            result.PageInfo = pageInfo;
            result.TotalCount = paras.Get<Int32>("@TotalCount");
            return result;
        }

        public LogCategory CreateCategory(LogCategory request)
        {
            var command = DataCommandManager.GetDataCommand("CreateLogCategory");
            return command.ExecuteEntity<LogCategory>(GetParaEntity(request));
        }

        public LogCategory EditCategory(LogCategory request)
        {
            var command = DataCommandManager.GetDataCommand("EditLogCategory");
            return command.ExecuteEntity<LogCategory>(GetParaEntity(request));
        }

        private dynamic GetParaEntity(LogCategory request)
        {
            List<NotificationConfigBase> result = new List<NotificationConfigBase>();
            result.Add(new EmailNotificationConfigEntity()
            {
                NeedNotify = request.EmailNotification.NeedNotify,
                FilterDuplicate = request.EmailNotification.FilterDuplicate,
                Interval = request.EmailNotification.Interval,
                MailTo = request.EmailNotification.Address,
                Subject = request.EmailNotification.Subject
            });
            return new
            {
                LocalID = request.LocalID,
                GlobalID = request.GlobalID,
                CategoryName = request.CategoryName,
                CategoryDescription = request.CategoryDescription,
                LogType = request.LogType,
                DistributeConfig = XmlSimpleSerializer.SerializeToString<List<NotificationConfigBase>>(result),
                Status = request.Status,
                InUser = request.InUser,
                RemoveOverDays = request.EnableRemoveLog ? request.RemoveOverDays : 0,
            };
        }
    }
}
