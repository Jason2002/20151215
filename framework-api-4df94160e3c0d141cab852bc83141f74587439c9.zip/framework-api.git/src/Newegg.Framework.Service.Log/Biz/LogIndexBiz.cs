﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using Newegg.Framework.Service.Log.Dtos;
using Elasticsearch.Net;
using Elasticsearch.Net.Connection;
using Elasticsearch.Net.ConnectionPool;

namespace Newegg.Framework.Service.Log.Biz
{
    public static class LogIndexBiz
    {
        private static readonly ElasticsearchClient _es_client;
        private static readonly string _index_name = "framework";

        static LogIndexBiz()
        {
            var nodeUrls = ConfigurationManager.AppSettings["Framework.ElasticsearchNodes"];
            if (string.IsNullOrEmpty(nodeUrls))
            {
                throw new ConfigurationErrorsException("missing config setting: Framework.ElasticsearchNodes");
            }

            var nodes = nodeUrls.Split(new char[] {';'}).Select(url => new Uri(url));

            var connectionPool = new SniffingConnectionPool(nodes);
            var config = new ConnectionConfiguration(connectionPool)
                .SniffOnStartup(true)
                .SniffLifeSpan(TimeSpan.FromMinutes(1))
                .SetPingTimeout(5*1000)
                .SetTimeout(60*1000)
                .MaximumRetries(2);

            _es_client = new ElasticsearchClient(config);

            //_es_client.IndicesDelete(_index_name);
            //如果索引不存在，则创建
            if (_es_client.IndicesExists(_index_name).HttpStatusCode == (int)HttpStatusCode.NotFound)
            {
                var _body = new
                {
                    mappings = new
                    {
                        logs = new
                        {
                            _ttl = new
                            {
                                enabled = true,
                                //store = true,
                                @default = "1d"
                            }
                        }
                    }
                };
                _es_client.IndicesCreate(_index_name, _body);
            }
        }

        public static void Write(LogEntry request)
        {
            try
            {
                //指定utc是为了和数据库统一存入美国时间
                request.LogCreateDate = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);

                //d (days), m (minutes), h (hours), ms (milliseconds) or w (weeks), milliseconds is used as default unit.
                _es_client.Index(_index_name, "logs", request.ID, request, item => item
                    .Ttl("30d"));
            }
            catch (Exception)
            {
                //throw;
            }
        }
    }
}
