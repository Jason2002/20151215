﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Service.Log.Dtos;
using Newegg.Oversea.DataAccess;

namespace Newegg.Framework.Service.Log.Biz
{
    public class LocalBiz
    {
        public LogLocalRegion GetLocalById(string localId)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetLogLocals");
            command.CommandText += " WHERE Local.LocalID = @LocalID";
            return command.ExecuteEntity<LogLocalRegion>(new { LocalID = localId });
        }

        public List<LogLocalRegion> GetLocals(LogLocalRegion request)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetLogLocals");
            command.CommandText += " WHERE 1 =1 ";
            DynamicParameters paras = new DynamicParameters();
            if (!string.IsNullOrWhiteSpace(request.GlobalID))
            {
                command.CommandText += " AND Local.GlobalID = @GlobalID";
                paras.Add("@GlobalID", request.GlobalID);
            }
            if (!string.IsNullOrWhiteSpace(request.LocalID))
            {
                command.CommandText += " AND Local.LocalID = @LocalID";
                paras.Add("@LocalID", request.LocalID);
            }
            if (!string.IsNullOrWhiteSpace(request.LocalName))
            {
                command.CommandText += " AND Local.LocalName = @LocalName";
                paras.Add("@LocalName", request.LocalName);
            }
            if (!string.IsNullOrWhiteSpace(request.Status))
            {
                command.CommandText += " AND Local.Status = @Status";
                paras.Add("@Status", request.Status);
            }

            return command.ExecuteEntityList<LogLocalRegion>(paras);
        }

        public LogLocalRegion CreateLocal(LogLocalRegion request)
        {
            var command = DataCommandManager.GetDataCommand("CreateLogLocal");
            request.LocalID = Guid.NewGuid().ToString();
            return command.ExecuteEntity<LogLocalRegion>(request);
        }

        public LogLocalRegion EditLocal(LogLocalRegion request)
        {
            var command = DataCommandManager.GetDataCommand("EditLogLocal");
            return command.ExecuteEntity<LogLocalRegion>(request);
        }
    }
}
