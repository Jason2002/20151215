﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Service.Log.Dtos;
using Newegg.Oversea.DataAccess;

namespace Newegg.Framework.Service.Log.Biz
{
    public class GlobalBiz
    {
        public LogGlobalRegion GetGlobalById(string id)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetLogGlobal");
            command.CommandText += " WHERE GlobalID = @GlobalID";
            return command.ExecuteEntity<LogGlobalRegion>(new { GlobalID = id });
        }

        public LogGlobalRegion GetGlobalByName(string name)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetLogGlobal");
            command.CommandText += " WHERE GlobalName = @GlobalName";
            return command.ExecuteEntity<LogGlobalRegion>(new { GlobalName = name });
        }

        public List<LogGlobalRegion> GetGlobals()
        {
            var command = DataCommandManager.GetDataCommand("GetLogGlobal");
            return command.ExecuteEntityList<LogGlobalRegion>();
        }

        public List<LogGlobalRegion> GetGlobals(LogGlobalRegion request)
        {
            var all = GetGlobals();
            var find = all.Where(a =>
                {
                    bool globalIDMatch = false;
                    bool statuMath = false;
                    if (string.IsNullOrEmpty(request.GlobalID)
                        || a.GlobalID.Equals(request.GlobalID, StringComparison.InvariantCultureIgnoreCase))
                    {
                        globalIDMatch = true;
                    }

                    if (request.Status == null ||
                        request.Status.Equals(a.Status, StringComparison.InvariantCultureIgnoreCase))
                    {
                        statuMath = true;
                    }
                    return globalIDMatch && statuMath;
                });

            if (find.Count() > 0)
            {
                var result = find.ToList();
                result.RemoveAll(a => a.GlobalName == "");
                return result;
            }
            else
            {
                return new List<LogGlobalRegion>();
            }
        }

        public LogGlobalRegion CreateGlobal(LogGlobalRegion request)
        {
            var command = DataCommandManager.GetDataCommand("CreateLogGlobal");
            request.GlobalID = Guid.NewGuid().ToString();
            return command.ExecuteEntity<LogGlobalRegion>(request);
        }

        public LogGlobalRegion EditGlobal(LogGlobalRegion request)
        {
            var command = DataCommandManager.GetDataCommand("EditLogGlobal");
            return command.ExecuteEntity<LogGlobalRegion>(request);
        }
    }
}
