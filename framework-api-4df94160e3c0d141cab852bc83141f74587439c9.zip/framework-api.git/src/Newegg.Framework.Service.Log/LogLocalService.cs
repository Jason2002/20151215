﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Common;
using Newegg.API.Exceptions;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Log.Biz;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log
{
    public class LogLocalService : RestServiceBase<LogLocalRegion>
    {
        protected override void OnBeforeExecute(LogLocalRegion request)
        {
            if (this.RequestContext.ExecuteContext.HttpMethod == HttpMethods.Post)
            {
                var localBiz = new LocalBiz();
                var globalBiz = new GlobalBiz();
                var find = globalBiz.GetGlobalById(request.GlobalID);
                if (find == null)
                {
                    throw new HttpError(ErrorCodes.GlobalNotExists, "Global ID not Exists");
                }
                var find2 = localBiz.GetLocals(new LogLocalRegion { GlobalID = request.GlobalID, LocalName = request.LocalName });
                if (find2 != null && find2.Count > 0)
                {
                    throw new HttpError(ErrorCodes.LocalNameExists, "Local Name Exists");
                }
            }
            if (this.RequestContext.ExecuteContext.HttpMethod == HttpMethods.Put)
            {
                var localBiz = new LocalBiz();
                var globalBiz = new GlobalBiz();
                var find = globalBiz.GetGlobalById(request.GlobalID);
                if (find == null)
                {
                    throw new HttpError(ErrorCodes.GlobalNotExists, "Global ID not Exists");
                }
                var find3 = localBiz.GetLocalById(request.LocalID);
                if (find3 == null)
                {
                    throw new HttpError(ErrorCodes.LocalNotExists, "Local ID not Exists");
                }
                if (!request.LocalName.Equals(find3.LocalName, StringComparison.InvariantCultureIgnoreCase))
                {
                    var exist = localBiz.GetLocals(new LogLocalRegion { GlobalID = request.GlobalID, LocalName = request.LocalName });
                    if (exist != null && exist.Count > 0)
                    {
                        throw new HttpError(ErrorCodes.LocalNameExists, "Local Name Exists");
                    }
                }
            }
        }

        public override object OnGet(LogLocalRegion request)
        {
            if (!string.IsNullOrWhiteSpace(request.LocalID))
            {
                return new LocalBiz().GetLocalById(request.LocalID);
            }
            else
            {
                return new LocalBiz().GetLocals(request);
            }
        }

        public override object OnPost(LogLocalRegion request)
        {
            return new LocalBiz().CreateLocal(request);
        }

        public override object OnPut(LogLocalRegion request)
        {
            return new LocalBiz().EditLocal(request);
        }
    }
}
