﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Common;
using Newegg.API.Exceptions;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Log.Biz;
using Newegg.Framework.Service.Log.Dtos;
using ServiceStack.Text;

namespace Newegg.Framework.Service.Log
{
    public class LogCategoryService : RestServiceBase<LogCategory>
    {
        protected override object OnAfterExecute(object response)
        {
            if ((response as LogCategory) != null)
            {
                LogCategory result = response as LogCategory;
                result.HandlerCategory();
                return result;
            }
            else if ((response as LogCategoryCollection) != null)
            {
                LogCategoryCollection results = response as LogCategoryCollection;
                if (results.LogCategories != null && results.LogCategories.Count > 0)
                {
                    foreach (var item in results.LogCategories)
                    {
                        item.HandlerCategory();
                    }
                }
                return results;
            }
            else
            {
                return response;
            }
        }

        public override object OnGet(LogCategory request)
        {
            if (!string.IsNullOrWhiteSpace(request.LocalID)
                && !string.IsNullOrWhiteSpace(request.GlobalID)
                && !string.IsNullOrWhiteSpace(request.CategoryName))
            {
                return new CategoryBiz().GetCategory(request.GlobalID, request.LocalID, request.CategoryName);
            }
            else
            {
                if (string.IsNullOrEmpty(this.RequestContext.RequestPageInfo.SortFields))
                {
                    RequestContext.RequestPageInfo.SortFields = "CategoryName";
                }
                if (string.IsNullOrEmpty(this.RequestContext.RequestPageInfo.Sort))
                {
                    RequestContext.RequestPageInfo.Sort = "asc";
                }

                if (string.IsNullOrEmpty(RequestContext.ExecuteContext.Expand) == false
                    && RequestContext.ExecuteContext.Expand.Equals("all", StringComparison.InvariantCultureIgnoreCase))
                {
                    RequestContext.RequestPageInfo.PageIndex = 0;
                    RequestContext.RequestPageInfo.PageSize = int.MaxValue;
                    return new CategoryBiz().GetCategories(request, this.RequestContext.RequestPageInfo).LogCategories;
                }
                else
                {
                    return new CategoryBiz().GetCategories(request, this.RequestContext.RequestPageInfo);
                }
            }
        }

        protected override void OnBeforeExecute(LogCategory request)
        {
            if (RequestContext.ExecuteContext.HttpMethod == HttpMethods.Post)
            {
                var localBiz = new LocalBiz();
                var categoryBiz = new CategoryBiz();
                var find = localBiz.GetLocals(new LogLocalRegion { LocalID = request.LocalID, GlobalID = request.GlobalID });
                if (find == null && find.Count == 0)
                {
                    throw new HttpError(ErrorCodes.LocalNotExists, "Invalid Local and Global");
                }
                var duplicate = categoryBiz.GetCategory(request.GlobalID, request.LocalID, request.CategoryName);
                if(duplicate != null)
                {
                    throw new HttpError(ErrorCodes.CategoryExists, "Category exists");
                }
            }
            if (RequestContext.ExecuteContext.HttpMethod == HttpMethods.Put)
            {
                var localBiz = new LocalBiz();
                var find = localBiz.GetLocals(new LogLocalRegion { LocalID = request.LocalID, GlobalID = request.GlobalID });
                if (find == null && find.Count == 0)
                {
                    throw new HttpError(ErrorCodes.LocalNotExists, "Invalid Local and Global");
                }
            }
        }

        public override object OnPost(LogCategory request)
        {
            return new CategoryBiz().CreateCategory(request);
        }

        public override object OnPut(LogCategory request)
        {
            return new CategoryBiz().EditCategory(request);
        }
    }
}
