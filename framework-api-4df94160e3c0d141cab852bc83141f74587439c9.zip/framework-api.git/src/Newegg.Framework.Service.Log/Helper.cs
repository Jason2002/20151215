﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Log
{
    public static class Helper
    {
        public static string GetReadableLogType(string logType)
        {
            if(string.IsNullOrWhiteSpace(logType))
            {
                return string.Empty;
            }
            logType = logType.ToUpper();
            switch (logType)
            {
                case "I":
                    return "Info";
                case "T":
                    return "Trace";
                case "E":
                    return "Error";
                case "D":
                    return "Debug";
                case "A":
                    return "Audit";
                default:
                    return "Unknow";
            }
        }
    }
}
