﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using Newegg.Framework.Service.Log.Dtos;
using FluentValidation;

namespace Newegg.Framework.Service.Log.Validators
{
    public class LogEntryValidator : CustomerValidator<LogEntry>
    {
        public LogEntryValidator()
        {
            RuleSet(ApplyTo.Post,
                () =>
                {
                    RuleFor(l => l.GlobalName, true).NotNull().NotEmpty();

                    RuleFor(l => l.LocalName, true).NotNull().NotEmpty();

                    RuleFor(l => l.CategoryName, true).NotNull().NotEmpty();

                    RuleFor(c => c.LogType, true).Must(s =>
                    {
                        return s.Trim().Equals("i", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("t", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("e", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("d", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("a", StringComparison.InvariantCultureIgnoreCase);
                    }).WithMessage("Invalid log type string. I: Info, T: Trace, E: Error, D: Debug, A: Audit")
                    .When(c => !string.IsNullOrWhiteSpace(c.LogType));
                });
        }
    }
}
