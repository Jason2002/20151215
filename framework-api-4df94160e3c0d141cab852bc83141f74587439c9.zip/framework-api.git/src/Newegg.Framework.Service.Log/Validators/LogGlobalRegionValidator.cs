﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using Newegg.Framework.Service.Log.Dtos;
using FluentValidation;

namespace Newegg.Framework.Service.Log.Validators
{
    public class LogGlobalRegionValidator : CustomerValidator<LogGlobalRegion>
    {
        public LogGlobalRegionValidator()
        {
            RuleSet(ApplyTo.Post | ApplyTo.Put,
                () =>
                {
                    RuleFor(g => g.GlobalName, true).NotNull().NotEmpty();
                    RuleFor(g => g.Status, true).NotNull().NotEmpty().Must(s =>
                        {
                            return s.Trim().Equals("a", StringComparison.InvariantCultureIgnoreCase)
                                || s.Trim().Equals("i", StringComparison.InvariantCultureIgnoreCase);
                        }).WithMessage("Invalid status string. A: Active, I: Inactive");
                });

            RuleSet(ApplyTo.Put,
                () =>
                {
                    RuleFor(g => g.GlobalID, true).NotNull().NotEmpty();
                });
        }
    }
}
