﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using Newegg.Framework.Service.Log.Dtos;
using FluentValidation;

namespace Newegg.Framework.Service.Log.Validators
{
    public class LogLocalRegionValidator : CustomerValidator<LogLocalRegion>
    {
        public LogLocalRegionValidator()
        {
            RuleSet(ApplyTo.Post | ApplyTo.Put,
                () =>
                {
                    RuleFor(l => l.GlobalID, true).NotNull().NotEmpty();
                    RuleFor(l => l.LocalName, true).NotNull().NotEmpty();
                    RuleFor(l => l.Status, true).NotNull().NotEmpty().Must(s =>
                    {
                        return s.Trim().Equals("a", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("i", StringComparison.InvariantCultureIgnoreCase);
                    }).WithMessage("Invalid status string. A: Active, I: Inactive"); ;
                });

            RuleSet(ApplyTo.Put,
                () =>
                {
                    RuleFor(l => l.LocalID, true).NotNull().NotEmpty();
                });
        }
    }
}
