﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using Newegg.Framework.Service.Log.Dtos;
using FluentValidation;

namespace Newegg.Framework.Service.Log.Validators
{
    public class LogCategoryValidator : CustomerValidator<LogCategory>
    {
        public LogCategoryValidator()
        {
            RuleSet(ApplyTo.Post | ApplyTo.Put,
                () =>
                {
                    RuleFor(c => c.CategoryName, true).NotNull().NotEmpty();
                    RuleFor(c => c.GlobalID, true).NotNull().NotEmpty();
                    RuleFor(c => c.InUser, true).NotNull().NotEmpty();
                    RuleFor(c => c.LocalID, true).NotNull().NotEmpty();

                    RuleFor(c => c.LogType, true).NotNull().NotEmpty().Must(s =>
                    {
                        return s.Trim().Equals("i", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("t", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("e", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("d", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("a", StringComparison.InvariantCultureIgnoreCase);
                    }).WithMessage("Invalid log type string. I: Info, T: Trace, E: Error, D: Debug, A: Audit");

                    RuleFor(c => c.Status, true).NotNull().NotEmpty().Must(s =>
                    {
                        return s.Trim().Equals("a", StringComparison.InvariantCultureIgnoreCase)
                            || s.Trim().Equals("i", StringComparison.InvariantCultureIgnoreCase);
                    }).WithMessage("Invalid status string. A: Active, I: Inactive");
                });
        }
    }
}
