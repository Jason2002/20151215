﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Log
{
    public static class ErrorCodes
    {
        public static string GlobalNotExists = "";
        public static string GlobalExists = "";
        public static string GlobalNameExists = "";
        public static string LocalNameExists = "";
        public static string LocalExists = "";
        public static string LocalNotExists = "";
        public static string CategoryExists = "";
    }
}
