﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log.Distributor
{
    public static class LogMailSender
    {
        private static string headContent;
        private static string loopContent;
        private static string afterbodyContent;

        static LogMailSender()
        {
            string templatePath = System.Configuration.ConfigurationManager.AppSettings["LogMailTemplatePath"];

            if (string.IsNullOrEmpty(templatePath))
            {
                throw new ApplicationException("templatePath is null or empty string, please check your appSettings in application config file.");
            }

            string template = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, templatePath));

            int startIndex = template.IndexOf("$loop_begin$");
            int endIndex = template.IndexOf("$loop_end$");

            headContent = template.Substring(0, startIndex);

            loopContent = template.Substring(startIndex + "$loop_begin$".Length, endIndex - startIndex - "$loop_begin$".Length);

            afterbodyContent = template.Substring(endIndex + "$loop_end$".Length);

        }


        public static void Send(EmailNotificationItem mailItem)
        {
            string body = BuildMailBody(mailItem);
            MailClient client = new MailClient();
            client.Send(mailItem.EmailNotificationConfig.MailTo, mailItem.EmailNotificationConfig.Subject, body);
        }

        private static string BuildMailBody(EmailNotificationItem wrapperList)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(headContent);

            foreach (LogEntry log in wrapperList.Logs)
            {
                StringBuilder innerSB = new StringBuilder(loopContent);

                innerSB.Replace("$LogType$", Helper.GetReadableLogType(log.LogType));
                innerSB.Replace("$LogCreateDate$", HtmlEncode(log.LogCreateDate.ToString()));
                innerSB.Replace("$LogUserName$", HtmlEncode(log.LogUserName));
                innerSB.Replace("$GlobalName$", HtmlEncode(log.GlobalName));
                innerSB.Replace("$LocalName$", HtmlEncode(log.LocalName));
                innerSB.Replace("$ID$", HtmlEncode(log.ID));
                innerSB.Replace("$CategoryName$", HtmlEncode(log.CategoryName));
                innerSB.Replace("$ServerIP$", HtmlEncode(log.LogServerIP));
                innerSB.Replace("$ServerName$", HtmlEncode(log.LogServerName));
                innerSB.Replace("$ReferenceKey$", HtmlEncode(log.ReferenceKey));
                innerSB.Replace("$Content$", HtmlEncode(log.Content).Replace("\r\n", "<br>").Replace("\t", "&nbsp;&nbsp;"));
                innerSB.Replace("$ExtendedProperties$", BuildExtendedPropertiesHtml(log.ExtendedProperties));
                innerSB.Replace("$DuplicateCount$", HtmlEncode(wrapperList.DuplicateCount.ToString()));

                innerSB.Append("<br />");

                sb.Append(innerSB.ToString());
            }

            sb.Append(afterbodyContent);

            return sb.ToString();
        }

        private static string BuildExtendedPropertiesHtml(List<ExtendProperty> extendedProperties)
        {
            if (extendedProperties == null || extendedProperties.Count == 0)
            {
                return string.Empty;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("<table border=1>");
            foreach (ExtendProperty kv in extendedProperties)
            {
                sb.AppendFormat("<tr><td><nobr>{0}</nobr></td><td>{1}</td></tr>", HtmlEncode(kv.Key), HtmlEncode(kv.Value).Replace("\r\n", "<br>").Replace("\t", "&nbsp;&nbsp;"));
            }
            sb.Append("</table>");
            return sb.ToString();
        }

        private static string HtmlEncode(string value)
        {
            return HttpUtility.HtmlEncode(value);
        }
    }
}
