﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Service.Log.Biz;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log.Distributor
{
    public static class LogDistributorManager
    {
        static List<ILogDistributor> m_DistributorList;

        static LogDistributorManager()
        {
            m_DistributorList = new List<ILogDistributor>();
            m_DistributorList.Add(new EmailDistributor());
        }

        public static void Distribute(LogEntry log)
        {
            LogCategory category = new CategoryBiz().GetCategory(log.GlobalID, log.LocalID, log.CategoryName);

            if (category != null && category.DistributeConfig != null)
            {
                var notification = category.GetNotiicationEntity();
                Distributors.ForEach(delegate(ILogDistributor distributor)
                {
                    distributor.Distribute(log, notification);
                });
            }
        }

        public static List<ILogDistributor> Distributors
        {
            get
            {
                return m_DistributorList;
            }
        }

        public static void Dispose()
        {
            lock (typeof(LogDistributorManager))
            {
                Distributors.ForEach(delegate(ILogDistributor distributor)
                {
                    using (distributor as IDisposable)
                    {
                        distributor.Dispose();
                    }
                });
            }
        }
    }
}
