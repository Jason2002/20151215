﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log.Distributor
{
    public interface ILogDistributor : IDisposable
    {
        void Distribute(LogEntry log, NotificationConfigBase distributeConfig);
    }
}
