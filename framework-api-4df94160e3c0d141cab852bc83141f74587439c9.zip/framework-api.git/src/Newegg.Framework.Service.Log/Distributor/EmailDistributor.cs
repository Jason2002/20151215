﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Newegg.Framework.Service.Log.Dtos;


namespace Newegg.Framework.Service.Log.Distributor
{
    public class EmailDistributor : ILogDistributor
    {
        private static long m_Period = 30 * 1000;

        private static Timer m_Timer = new Timer(new TimerCallback(SendMail), null, m_Period, m_Period);

        private static void SendMail(object state)
        {
            m_Timer.Change(Timeout.Infinite, Timeout.Infinite);

            try
            {
                List<EmailNotificationItem> logs = EmailNotificationQueue.GetAll();
                foreach (EmailNotificationItem log in logs)
                {
                    if (log.Logs.Count > 0)
                    {
                        if (DateTime.Now >= log.LastDistributeTime.AddSeconds(log.EmailNotificationConfig.Interval)
                            || log.Logs.Count > 10)
                        {
                            LogMailSender.Send(log);
                            log.Reset();
                        }
                    }
                }
            }
            finally
            {
                m_Timer.Change(m_Period, m_Period);
            }
        }

        public void Distribute(LogEntry log, NotificationConfigBase distributeConfig)
        {
            EmailNotificationConfigEntity cfg = distributeConfig as EmailNotificationConfigEntity;
            if (cfg == null || cfg.NeedNotify == false)
            {
                return;
            }

            EmailNotificationItem item = new EmailNotificationItem(log, cfg);

            if (cfg.Interval == 0)
            {
                LogMailSender.Send(item);
            }
            else
            {
                EmailNotificationQueue.AddItem(item);
            }
        }


        #region IDisposable Members

        public void Dispose()
        {
            List<EmailNotificationItem> logs = EmailNotificationQueue.GetAll();
            foreach (EmailNotificationItem log in logs)
            {
                if (log.Logs.Count > 0)
                {
                    LogMailSender.Send(log);
                    log.Reset();
                }
            }
        }

        #endregion
    }
}
