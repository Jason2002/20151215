﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log.Distributor
{
    [Serializable]
    public class EmailNotificationItem
    {
        private long m_DuplicateCount;

        public EmailNotificationItem()
        {
            Logs = new List<LogEntry>();
            LastDistributeTime = DateTime.Now;
        }

        public EmailNotificationItem(LogEntry log, EmailNotificationConfigEntity cfg)
        {
            Logs = new List<LogEntry>();
            Logs.Add(log);
            LastDistributeTime = DateTime.Now;
            EmailNotificationConfig = cfg;
        }

        public List<LogEntry> Logs { get; set; }

        public DateTime LastDistributeTime { get; set; }

        public int DuplicateCount
        {
            get
            {

                return (int)Interlocked.Read(ref m_DuplicateCount);
            }
        }

        public void IncrementDuplicateCount()
        {
            Interlocked.Increment(ref m_DuplicateCount);
        }

        public EmailNotificationConfigEntity EmailNotificationConfig { get; set; }

        public void Reset()
        {
            Logs.Clear();
            LastDistributeTime = DateTime.Now;
            Interlocked.Exchange(ref m_DuplicateCount, 0);
        }
    }
}
