﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Newegg.API.Client;

namespace Newegg.Framework.Service.Log.Distributor
{
    public class MailClient
    {
        public void Send(string to, string subject, string body)
        {
            string mailAPIAddress = ConfigurationManager.AppSettings["FrameworkAPIAddress"];
            RestAPIClient client = new RestAPIClient(mailAPIAddress, ContentTypes.Json);
            MailRequest request = GetLogMailRequest(to, subject, body);
            var result = client.Post<object>("/mail", request);
        }

        private MailRequest GetLogMailRequest(string to, string subject, string body)
        {
            MailRequest request = new MailRequest
            {
                From = "misalert@newegg.com",
                To = to,
                Subject = subject,
                Body = body,
                Priority = MailPriority.Normal,
                ContentType = MailContentType.Html,
                MailType = MailType.Smtp,
                SmtpSetting = new SmtpSetting
                {
                    BodyEncoding = MailEncoding.UTF8,
                    SubjectEncoding = MailEncoding.UTF8,
                },
            };
            return request;
        }
    }


    public class MailRequest
    {
        public string From { get; set; }

        public string To { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public MailPriority Priority { get; set; }

        public MailContentType ContentType { get; set; }

        public MailType MailType { get; set; }

        public SmtpSetting SmtpSetting { get; set; }

    }

    public class SmtpSetting
    {
        public MailEncoding SubjectEncoding { get; set; }

        public MailEncoding BodyEncoding { get; set; }

    }

    public enum MailPriority
    {
        Normal = 0,

        Low = 1,

        High = 2,
    }

    public enum MailContentType
    {
        Html,
        Text,
    }

    public enum MailType
    {
        LondongII,
        Smtp,
    }

    public enum MailEncoding
    {

        UTF8,

        ASCII,

        UTF32,

        Unicode
    }
}
