﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Service.Log.Dtos;

namespace Newegg.Framework.Service.Log.Distributor
{
    public static class EmailNotificationQueue
    {
        private static Dictionary<string, EmailNotificationItem> m_List = new Dictionary<string, EmailNotificationItem>();

        private static string GenerateCacheKey(string globalID, string localID, string categoryName)
        {
            return string.Format("LK_{0}_{1}_{2}", globalID.ToLower().Trim(), localID.Trim().ToLower(), categoryName);
        }

        public static List<EmailNotificationItem> GetAll()
        {
            return m_List.Values.ToList<EmailNotificationItem>();
        }

        public static void AddItem(EmailNotificationItem item)
        {
            LogEntry log = item.Logs[0];
            string key = GenerateCacheKey(log.GlobalID, log.LocalID, log.CategoryName);

            lock (typeof(EmailNotificationQueue))
            {
                if (m_List.ContainsKey(key))
                {
                    EmailNotificationItem cachedData = m_List[key];
                    cachedData.EmailNotificationConfig = item.EmailNotificationConfig;
                    if (cachedData.EmailNotificationConfig.FilterDuplicate)
                    {
                        foreach (LogEntry i in cachedData.Logs)
                        {
                            if (i.Content == log.Content)
                            {
                                cachedData.IncrementDuplicateCount();
                                return;
                            }
                        }
                    }
                    cachedData.Logs.Add(log);
                }
                else
                {
                    m_List.Add(key, item);
                }
            }
        }


        public static EmailNotificationItem GetData(string globalID, string localID, string categoryName)
        {
            string key = GenerateCacheKey(globalID, localID, categoryName);
            return m_List[key];
        }


    }
}
