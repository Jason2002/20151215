﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using FluentValidation;

namespace Newegg.Framework.Service.Profile
{
    public class ProfileValidation : CustomerValidator<UserProfile>
    {
        public ProfileValidation()
        {
            RuleSet(ApplyTo.Get | ApplyTo.Put | ApplyTo.Delete,
                () =>
                {
                    RuleFor(p => p.SystemName).NotNullorEmpty();
                    RuleFor(p => p.UserId).NotNullorEmpty();
                });

            RuleSet(ApplyTo.Put,
                () => RuleFor(p => p.Profiles).NotNull().SetCollectionValidator(new ProfileContentValidation()));
        }
    }


    public class ProfileContentValidation : CustomerValidator<ProfileContent>
    {
        public ProfileContentValidation()
        {
            RuleFor(p => p.Key).NotNullorEmpty();
            RuleFor(p => p.Value).NotNullorEmpty();
        }
    }
}
