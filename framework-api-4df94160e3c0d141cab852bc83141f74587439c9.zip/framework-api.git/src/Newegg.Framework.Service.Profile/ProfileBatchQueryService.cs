﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;

namespace Newegg.Framework.Service.Profile
{
    public class ProfileBatchQueryService : RestServiceBase<BatchProfile>
    {
        public override object OnPost(BatchProfile request)
        {
            if (request.BatchQuery == null || request.BatchQuery.Count == 0)
            {
                return new List<UserProfile>();
            }
            else
            {
                return new ProfileBiz().BatchGetProfiles(request.BatchQuery);
            }
        }
    }
}
