﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;

namespace Newegg.Framework.Service.Profile
{
    public class ProfileService : RestServiceBase<UserProfile>
    {
        public override object OnGet(UserProfile request)
        {
            if (string.IsNullOrEmpty(request.Key))
            {
                return new ProfileBiz().GetProfiles(request.SystemName, request.UserId);
            }
            else
            {
                return new ProfileBiz().GetProfile(request.SystemName, request.UserId, request.Key);
            }
        }

        public override object OnPut(UserProfile request)
        {
            new ProfileBiz().Set(request);

            return RequestContext.ReturnCreatedResponse(string.Empty);
        }

        public override object OnDelete(UserProfile request)
        {
            if (string.IsNullOrEmpty(request.Key))
            {
                new ProfileBiz().RemoveProfile(request.SystemName, request.UserId);
            }
            else
            {
                new ProfileBiz().RemoveProfile(request.SystemName, request.UserId, request.Key);
            }
            return RequestContext.ReturnNoResponse();
        }
    }
}
