﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Nair.Sdk;

namespace Newegg.Framework.Service.Profile
{
    public class ProfileBiz
    {
        private readonly string m_nairKey = "{0}-{1}";
        private NairClient m_nairClient;
        private static string m_DbName = ConfigurationManager.AppSettings["UserProfileDbName"];

        public ProfileBiz()
        {
            m_nairClient = NairFactory.GetNairClient();
        }

        private string GetHashId(string systemName, string userId)
        {
            return string.Format(m_nairKey, systemName, userId);
        }

        private List<ProfileEntity> GetProfileEntities(string systemName, string userId)
        {
            var profiles = m_nairClient.Get<List<ProfileEntity>>(m_DbName, GetHashId(systemName, userId));
            return profiles ?? new List<ProfileEntity>();
        }

        public UserProfile GetProfiles(string systemName, string userId)
        {
            var profiles = GetProfileEntities(systemName, userId);
            if (profiles == null || profiles.Count == 0)
            {
                return null;
            }
            else
            {
                var userProfile = new UserProfile {SystemName = systemName, UserId = userId};
                userProfile.Profiles = profiles.Select(p => new ProfileContent {Key = p.Key, Value = p.Data, LastEditDate = p.LastEditDate}).ToList();
                return userProfile;
            }
        }

        public UserProfile GetProfile(string systemName, string userId, string key)
        {
            var profiles = GetProfileEntities(systemName, userId).FirstOrDefault(p => p.Key == key);
            if (profiles == null)
            {
                return null;
            }
            else
            {
                var userProfile = new UserProfile { SystemName = systemName, UserId = userId };
                userProfile.Profiles = new List<ProfileContent> { new ProfileContent { Key = profiles.Key, Value = profiles.Data, LastEditDate = profiles.LastEditDate} };
                return userProfile;
            }
        }

        public List<UserProfile> BatchGetProfiles(List<BatchQueryCondition> users)
        {
            var keys = users.Select(u => GetHashId(u.SystemName, u.UserId)).ToList();
            var result = m_nairClient.Get<List<ProfileEntity>>(m_DbName, keys);
            var profiles = new List<UserProfile>();
            foreach (var user in users)
            {
                var key = GetHashId(user.SystemName, user.UserId);
                if (result.ContainsKey(key))
                {
                    var profile = new UserProfile
                    {
                        SystemName = user.SystemName,
                        UserId = user.UserId,
                    };
                    if (!string.IsNullOrEmpty(user.Key))
                    {
                        var temp = result[key].FirstOrDefault(p => p.Key == user.Key);
                        if (temp != null)
                        {
                            profile.Profiles = new List<ProfileContent>
                            {
                                new ProfileContent
                                {
                                    Key = temp.Key,
                                    Value = temp.Data,
                                    LastEditDate = temp.LastEditDate
                                }
                            };
                            profiles.Add(profile);
                        }
                    }
                    else
                    {
                        profiles.Add(
                            new UserProfile
                            {
                                SystemName = user.SystemName,
                                UserId = user.UserId,
                                Profiles = result[key].Select(p => new ProfileContent {Key = p.Key, Value = p.Data, LastEditDate = p.LastEditDate}).ToList()
                            }
                        );
                    }

                }
            }
            return profiles;
        }

        public void Set(UserProfile entity)
        {
            var tKey = GetHashId(entity.SystemName, entity.UserId);
            var orgProfiles = GetProfileEntities(entity.SystemName, entity.UserId);
            foreach (var profileContent in entity.Profiles)
            {
                orgProfiles.RemoveAll(p => p.Key == profileContent.Key);
                orgProfiles.Add(new ProfileEntity()
                {
                    SystemName = entity.SystemName,
                    UserId = entity.UserId,
                    Key = profileContent.Key,
                    Data = profileContent.Value,
                    LastEditDate = DateTime.Now
                });
            }
            m_nairClient.Put(m_DbName, tKey, orgProfiles, 0);
        }

        public void RemoveProfile(string systemName, string userId)
        {
            var tKey = GetHashId(systemName, userId);
            m_nairClient.Remove(m_DbName, tKey);
        }

        public void RemoveProfile(string systemName, string userId, string key)
        {
            var tKey = GetHashId(systemName, userId);
            var profiles = GetProfileEntities(systemName, userId);
            profiles.RemoveAll(p => p.Key == key);
            m_nairClient.Put(m_DbName, tKey, profiles);
        }

    }
}
