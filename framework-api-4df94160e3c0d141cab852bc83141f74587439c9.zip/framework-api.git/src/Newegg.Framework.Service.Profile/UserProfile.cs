﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Profile
{
    [RestService("/user-profile/{SystemName}/{UserId}")]
    [RestService("/user-profile")]
    public class UserProfile
    {
        public string SystemName { get; set; }

        public string UserId { get; set; }

        [XmlIgnore]
        [IgnoreDataMember]
        public string Key { get; set; }

        public List<ProfileContent> Profiles { get; set; } 
    }

    [RestService("/user-profile/batch-query")]
    public class BatchProfile
    {
        public List<BatchQueryCondition> BatchQuery { get; set; } 
    }

    public class BatchQueryCondition
    {
        public string SystemName { get; set; }

        public string UserId { get; set; }

        public string Key { get; set; }
    }

    public class ProfileContent
    {
        public string Key { get; set; }

        public string Value { get; set; }

        public DateTime LastEditDate { get; set; }
    }


    public class ProfileEntity
    {
        public string SystemName { get; set; }

        public string UserId { get; set; }

        public DateTime LastEditDate { get; set; }

        public string Data { get; set; }

        public string Key { get; set; }
    }
}
