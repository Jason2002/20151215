﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;
using Newegg.API.Validation;
using FluentValidation;

namespace Newegg.Framework.Service.Keystone.Dto
{
    [RestService("/keystone/has-functions")]
    public class HasFunctions
    {
        public string UserName { get; set; }

        public List<string> Functions { get; set; }

        public string ApplicationId { get; set; }
    }

    public class HasFunctionResult
    {
        public string FunctionName { get; set; }

        public bool Result { get; set; }
    }

    public class HasFunctionsValidator : CustomerValidator<HasFunctions>
    {
        public HasFunctionsValidator()
        {
            RuleSet(ApplyTo.Post,
                () =>
                {
                    RuleFor(a => a.UserName).NotNullorEmpty();
                    RuleFor(a => a.ApplicationId).NotNullorEmpty();
                    RuleFor(a => a.Functions).Must(ids => ids != null && ids.Count > 0).WithMessage("Please provide function names!");
                });
        }
    }
}
