﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using FluentValidation;

namespace Newegg.Framework.Service.Keystone.Dto
{
    public class AuthLoginValidator:CustomerValidator<AuthLogin>
    {
        public AuthLoginValidator()
        {
            RuleSet(ApplyTo.Post,
                () =>
                {
                    RuleFor(a => a.UserName).NotNullorEmpty();
                    RuleFor(a => a.Password).NotNullorEmpty();
                    RuleFor(a => a.ApplicationIds).Must(ids => ids != null && ids.Count > 0).WithMessage("Please provide login application id!");
                });
        }
    }
}
