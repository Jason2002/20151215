﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Keystone.Dto
{
    public class AuthResultCache
    {
        public List<AuthResult> AuthResults { get; set; }
    }

    public class AuthResult
    {
        public string CacheKey { get; set; }
        public bool LoginResult { get; set; }
        public UserInfo UserInfo { get; set; }
        public List<RoleAttribute> RoleAttributes { get; set; }
        public List<Role> Roles { get; set; }
        public List<FunctionalAbility> Functions { get; set; } 
    }

    public class UserInfo
    {
        public string UserID { get; set; }

        public string UserName { get; set; }

        public string Avatar
        {
            get
            {
                var id = UserID;
                if (string.IsNullOrEmpty(id))
                {
                    id = "none";
                }
                var baseAddress = ConfigurationManager.AppSettings["UserAvatarAddress"];
                return string.Format(baseAddress, id);
            }
        }

        public string FullName { get; set; }

        public string DisplayName { get; set; }

        public string EmailAddress { get; set; }

        public string EmployeeID { get; set; }

        public string Country { get; set; }

        public string Company { get; set; }

        public string Department { get; set; }

        public string TelephoneNumber { get; set; }

        public string Title { get; set; }

    }

    public class RoleAttribute
    {
        public string RoleName { get; set; }

        public string Type { get; set; }

        public string Name { get; set; }

        public string Value { get; set; }

        public string ApplicationId { get; set; }

    }

    public class Role
    {
        public string RoleID { get; set; }

        public string RoleName { get; set; }

        public string ApplicationID { get; set; }

    }

    public class FunctionalAbility
    {
        public string Name { get; set; }

        public string ApplicationId { get; set; }
    }
}
