﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;
using Newegg.API.ServiceHost;

namespace Newegg.Framework.Service.Keystone.Dto
{
    [RestService("/keystone/function")]
    public class Function
    {
        public string FunctionName { get; set; }
        public string ApplicationId { get; set; }
    }

    public class FunctionResult
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
