﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Keystone.Dto
{
    public class SSOToken
    {
        public Passport passport { get; set; }
    }

    public class Passport
    {
        public PassportUser user { get; set; }
    }

    public class PassportUser
    {
        public string username { get; set; }
    }
}
