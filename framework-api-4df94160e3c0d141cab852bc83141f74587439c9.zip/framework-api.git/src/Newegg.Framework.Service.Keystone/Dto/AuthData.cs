﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Keystone.Dto
{
    [RestService("/keystone/sso-auth-data")]
    [RestService("/keystone/sso-auth-data/{Token}")]
    public class AuthData
    {
        public string Token { get; set; }

        public bool Strict { get; set; }

        public List<string> ApplicationIds { get; set; }
    }
}
