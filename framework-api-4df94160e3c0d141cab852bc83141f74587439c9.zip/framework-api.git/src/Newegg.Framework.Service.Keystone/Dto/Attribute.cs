﻿using System.Collections.Generic;
using FluentValidation;
using Newegg.API.Attributes;
using Newegg.API.Validation;

namespace Newegg.Framework.Service.Keystone.Dto
{
    [RestService("/keystone/attribute")]
    public class Attribute
    {        
        public string UserName { get; set; }        

        public string RoleName { get; set; }

        public List<string> ApplicationIds { get; set; }
    }
}
