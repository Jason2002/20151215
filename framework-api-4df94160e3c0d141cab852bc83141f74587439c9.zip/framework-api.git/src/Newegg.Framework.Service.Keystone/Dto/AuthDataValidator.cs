﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using FluentValidation;

namespace Newegg.Framework.Service.Keystone.Dto
{
    public class AuthDataValidator:CustomerValidator<AuthData>
    {
        public AuthDataValidator()
        {
            RuleSet(ApplyTo.Post,
                () => RuleFor(a => a.Token).NotNullorEmpty());
            RuleSet(ApplyTo.Delete,
                () => RuleFor(a => a.Token).NotNullorEmpty());
        }
    }
}
