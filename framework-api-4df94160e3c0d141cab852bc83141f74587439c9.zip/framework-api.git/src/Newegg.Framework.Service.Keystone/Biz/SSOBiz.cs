﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Nair.Sdk;
using Newegg.Framework.Service.Keystone.Dto;
using ServiceStack.Text;

namespace Newegg.Framework.Service.Keystone.Biz
{
    public class SSOBiz
    {
        private readonly string m_authDataKey = "{0}-auth";
        private NairClient m_nairClient;
        private static string _dbName = ConfigurationManager.AppSettings["SSODbName"];
        private static string _password = ConfigurationManager.AppSettings["SSODbPassword"];
        private static int _expired = Int32.Parse(ConfigurationManager.AppSettings["SSODataExpired"]);
        private AuthResultCache _authResultCache;

        public SSOBiz()
        {
            m_nairClient = NairFactory.GetNairClient();
        }

        public SSOToken GetSSOToken(string token)
        {
            return m_nairClient.Get<SSOToken>(_dbName, token, _password);
        }

        public void CacheAuthData(AuthResult data, AuthData request)
        {
            var key = string.Format(m_authDataKey, request.Token);

            data.CacheKey = GetCacheKeybyAppIds(request.ApplicationIds);

            if (_authResultCache == null)
            {
                _authResultCache = new AuthResultCache();
            }
            if (_authResultCache.AuthResults == null)
            {
                _authResultCache.AuthResults = new List<AuthResult>();
            }
            _authResultCache.AuthResults.RemoveAll(a => a.CacheKey == data.CacheKey);

            _authResultCache.AuthResults.Add(data);

            m_nairClient.Put(_dbName, key, _authResultCache, _expired, _password);
        }

        public AuthResult GetCacheAuthData(AuthData request)
        {
            var key = string.Format(m_authDataKey, request.Token);

            _authResultCache = m_nairClient.Get<AuthResultCache>(_dbName, key, _password);

            return (_authResultCache == null || _authResultCache.AuthResults == null)
                ? null
                : _authResultCache.AuthResults.FirstOrDefault(
                    a => a.CacheKey == GetCacheKeybyAppIds(request.ApplicationIds));
        }

        public void RemoveCacheAuthData(string token)
        {
            var key = string.Format(m_authDataKey, token);

            m_nairClient.Remove(_dbName, key, _password);
        }

        private string GetCacheKeybyAppIds(List<string> appIds)
        {
            if(appIds == null)
                appIds = new List<string>();

            return JsonSerializer.SerializeToString(appIds).MD5();
        }
    }
}
