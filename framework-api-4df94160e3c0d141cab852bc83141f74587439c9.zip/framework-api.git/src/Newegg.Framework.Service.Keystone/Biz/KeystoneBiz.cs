﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BitKoo.Keystone;
using Newegg.API.Logging;
using Newegg.Framework.Service.Keystone.Dto;
using Newegg.Oversea.DataAccess;

namespace Newegg.Framework.Service.Keystone.Biz
{
    public class KeystoneBiz
    {
        private string m_currentDomain;
        private string[] m_KS_SourceDirectories;
        private string m_KS_PrimaryAuthUrl;
        private string m_KS_SecondaryAuthUrl;
        private string m_enableSuperuser;

        public KeystoneBiz()
        {
            m_KS_SourceDirectories = KeystoneConfig.Keystone.SourceDirectories;
            m_KS_PrimaryAuthUrl = KeystoneConfig.Keystone.PrimaryAuthUrl;
            m_KS_SecondaryAuthUrl = KeystoneConfig.Keystone.SecondaryAuthUrl;
            m_enableSuperuser = ConfigurationManager.AppSettings["EnableSuperuser"];
        }

        public AuthResult LoginTask(string username, string password, List<string> applicationIds, bool isNeedLogin)
        {
            var result = new AuthResult();

            if (isNeedLogin)
            {
                var isLogin = Login(username, password, applicationIds);
                result.LoginResult = isLogin;
                if (!isLogin)
                {
                    return result;
                }
            }
            else
            {
                HandlerDomain(username);
            }

            var tasks = new List<Task>();

            var getUserInfoTask = new Task(() =>
            {
                result.UserInfo = GetUserInfoFromAD(username);
            });
            tasks.Add(getUserInfoTask);

            var getRoleAttributesTask = new Task(() =>
            {
                result.RoleAttributes = GetAuthRoleAttributes(username, applicationIds);
            });
            tasks.Add(getRoleAttributesTask);

            var getRolesTask = new Task(() =>
            {
                result.Roles = GetAuthRolesByUser(username, applicationIds);
            });
            tasks.Add(getRolesTask);

            var getFunctionsTask = new Task(() =>
            {
                result.Functions = GetAuthFunctionalAbilities(username, applicationIds);
            });
            tasks.Add(getFunctionsTask);

            tasks.ForEach((t) => t.Start());
            Task.WaitAll(tasks.ToArray());

            return result;
        }

        private void HandlerDomain(string username)
        {
            if (!string.IsNullOrEmpty(m_enableSuperuser) && username.ToLower() == "superuser")
            {
                m_currentDomain = "bitkoo";
            }
            else
            {
                m_currentDomain = ConfigurationManager.AppSettings["CurrentDomain"];
            }
        }

        public bool Login(string userName, string password, List<string> applicationIds)
        {
            var loginUserParams = new object[] { userName, password };
            string[] sourceDirectories = m_KS_SourceDirectories;
            var auth = new Auth { PrimaryAuthUrl = m_KS_PrimaryAuthUrl, SecondaryAuthUrl = m_KS_SecondaryAuthUrl };
            foreach (string appId in applicationIds)
            {
                auth.ApplicationId = appId;
                foreach (string sourceDirectory in sourceDirectories)
                {
                    if (auth.Login(sourceDirectory, loginUserParams))
                    {
                        m_currentDomain = sourceDirectory;
                        return true;
                    }
                    if (auth.Message != null &&
                        auth.Message.Equals("User does not possess any roles in the application."))
                    {
                        m_currentDomain = sourceDirectory;
                        return true;
                    }

                    //该判断是为了防止AD账号3次登录失败后，把账号给locked了；
                    if (auth.Message != null && auth.Message.Equals("Authentication Failed, Message: Invalid Credentials"))
                    {
                        return false;
                    }
                }
            }
            return false;
        }

        public UserInfo GetUserInfoFromAD(string userID)
        {
            userID = userID.ToLower().Trim();
            UserInfo user = new UserInfo();
            user.UserID = userID;
            user.UserName = userID;
            user.FullName = userID;
            try
            {
                DirectorySearcher ds = new DirectorySearcher()
                {
                    SearchRoot = new DirectoryEntry("LDAP://" + m_currentDomain),
                    Filter = String.Format("(&(objectCategory=User)(sAMAccountName={0}))", userID)
                };

                SearchResult sr = ds.FindOne();
                
                if (sr != null)
                {
                    DirectoryEntry entry = sr.GetDirectoryEntry();

                    if (entry != null)
                    {
                        user.FullName = entry.Properties["name"].Value as String;
                        user.DisplayName = entry.Properties["DisplayName"].Value as String;
                        user.EmailAddress = entry.Properties["mail"].Value as String;
                        user.EmployeeID = entry.Properties["employeeID"].Value as String;
                        user.Country = entry.Properties["co"].Value as String;
                        user.Company = entry.Properties["company"].Value as String;
                        user.Department = entry.Properties["department"].Value as String;
                        user.TelephoneNumber =
                            entry.Properties["telephoneNumber"].Value as String;
                        user.Title = entry.Properties["Title"].Value as String;
                    }
                }
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                LogFactory.Log.Error(ex);
            }


            return user;

        }

        /// <summary>
        /// 获取当前登录用户的所有role attribute
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="applicationIds"></param>
        /// <returns></returns>
        public List<RoleAttribute> GetAuthRoleAttributes(string userName, List<string> applicationIds)
        {
            if (applicationIds == null || applicationIds.Count == 0)
            {
                return new List<RoleAttribute>();
            }
            var dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetAuthRoleAttributes");

            using (var sqlBuilder = new DynamicQuerySqlBuilder(dataCommand.CommandText, dataCommand, null, "R.system_id ASC"))
            {
                sqlBuilder.ConditionConstructor.AddInCondition<string>(QueryConditionRelationType.AND, "R.system_id", DbType.String, applicationIds);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "UAS.unique_identifier", DbType.String, "@UserName", QueryConditionOperatorType.Equal, userName);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "D.Prefix", DbType.String, "@Directory", QueryConditionOperatorType.Equal, m_currentDomain);
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
            }

            return dataCommand.ExecuteEntityList<RoleAttribute>();
        }

        /// <summary>
        /// 根据UserName和RoleName获取所有Role Attribute
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="roleName"></param>
        /// <param name="applicationIds"></param>
        /// <returns></returns>
        public List<RoleAttribute> GetAuthRoleAttributes(string userName, string roleName, List<string> applicationIds)
        {
            var dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetAuthRoleAttributes");
            using (var sqlBuilder = new DynamicQuerySqlBuilder(dataCommand.CommandText, dataCommand, null, "R.system_id ASC"))
            {
                sqlBuilder.ConditionConstructor.AddInCondition<string>(QueryConditionRelationType.AND, "R.system_id",DbType.String, applicationIds);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "UAS.unique_identifier",
                    DbType.String, "@UserName", QueryConditionOperatorType.Equal, userName);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "R.role_name",
                    DbType.String, "@RoleName", QueryConditionOperatorType.Equal, roleName);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "D.Prefix", DbType.String,
                    "@Directory", QueryConditionOperatorType.Equal, m_currentDomain);
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
            }

            return dataCommand.ExecuteEntityList<RoleAttribute>();
        }

        /// <summary>
        /// 获取当前用户所拥有的Role
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="applicationIds"></param>
        /// <returns></returns>
        public List<Role> GetAuthRolesByUser(string userName, List<string> applicationIds)
        {
            if (applicationIds == null || applicationIds.Count == 0)
            {
                return new List<Role>();
            }
            var dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetAuthRolesByUser");

            using (var sqlBuilder = new DynamicQuerySqlBuilder(dataCommand.CommandText, dataCommand, null, "R.system_id ASC"))
            {
                sqlBuilder.ConditionConstructor.AddInCondition<string>(QueryConditionRelationType.AND, "R.system_id", DbType.String, applicationIds);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "UAS.unique_identifier", DbType.String, "@UserName", QueryConditionOperatorType.Equal, userName);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "D.Prefix", DbType.String, "@Directory", QueryConditionOperatorType.Equal, m_currentDomain);
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
            }

            return dataCommand.ExecuteEntityList<Role>();
        }

        /// <summary>
        /// 获取当前登录用户的所有functional ability
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="applicationIds"></param>
        /// <returns></returns>
        public List<FunctionalAbility> GetAuthFunctionalAbilities(string userName, List<string> applicationIds)
        {
            if (applicationIds == null || applicationIds.Count == 0)
            {
                return new List<FunctionalAbility>();
            }
            var dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetAuthFunctionalAbilities");

            using (var sqlBuilder = new DynamicQuerySqlBuilder(dataCommand.CommandText, dataCommand, null, "F.system_id ASC"))
            {
                sqlBuilder.ConditionConstructor.AddInCondition<string>(QueryConditionRelationType.AND, "F.system_id", DbType.String, applicationIds);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "UAS.unique_identifier", DbType.String, "@UserName", QueryConditionOperatorType.Equal, userName);
                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "D.Prefix", DbType.String, "@Directory", QueryConditionOperatorType.Equal, m_currentDomain);
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
            }

            return dataCommand.ExecuteEntityList<FunctionalAbility>();
        }

        public List<FunctionResult> GetUserInfosByFunction(string functionName, string applicationId)
        {
            var dataCommand = DataCommandManager.GetDataCommand("GetUserIdsByFunction");
            var users =
                dataCommand.ExecuteEntityList<FunctionResult>(new {FunctionName = functionName, ApplicationId = applicationId});
            return users;
        }
    }
}
