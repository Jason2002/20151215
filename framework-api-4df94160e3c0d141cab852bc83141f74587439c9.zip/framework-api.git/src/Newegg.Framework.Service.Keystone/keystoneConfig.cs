﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Keystone
{
    public class KeystoneConfig
    {
        private static KeystoneSection s_keystoneSection;

        static KeystoneConfig()
        {
            s_keystoneSection = (KeystoneSection)ConfigurationManager.GetSection("keystone");
        }

        public static KeystoneSection Keystone
        {
            get
            {
                return s_keystoneSection;
            }
        }
    }

    public class KeystoneSection: ConfigurationSection
    {
        [ConfigurationProperty("sourceDirectory", IsRequired = true)]
        public string SourceDirectory
        {
            get
            {
                return (string)this["sourceDirectory"];
            }
            set
            {
                this["sourceDirectory"] = value;
            }
        }


        [ConfigurationProperty("primaryAuthUrl", IsRequired = true)]
        public string PrimaryAuthUrl
        {
            get
            {
                return (string)this["primaryAuthUrl"];
            }
            set
            {
                this["primaryAuthUrl"] = value;
            }
        }

        [ConfigurationProperty("secondaryAuthUrl", IsRequired = true)]
        public string SecondaryAuthUrl
        {
            get
            {
                return (string)this["secondaryAuthUrl"];
            }
            set
            {
                this["secondaryAuthUrl"] = value;
            }
        }

        
        public string[] SourceDirectories
        {
            get
            {
                string sourceDirectory = this.SourceDirectory;
                string[] result = sourceDirectory == null ? new string[] { } : sourceDirectory.Split(new char[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                return result;
            }
        }

        
    }
}
