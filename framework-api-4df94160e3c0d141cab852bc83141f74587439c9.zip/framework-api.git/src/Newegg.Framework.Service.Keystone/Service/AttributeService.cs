﻿using Newegg.API.Interfaces;
using Newegg.Framework.Service.Keystone.Biz;
using Newegg.Framework.Service.Keystone.Dto;

namespace Newegg.Framework.Service.Keystone.Service
{
    public class AttributeService : RestServiceBase<Dto.Attribute>
    {
        public override object OnPost(Dto.Attribute request)
        {
            var biz = new KeystoneBiz();
            var result = biz.GetAuthRoleAttributes(request.UserName, request.RoleName, request.ApplicationIds);
            return result;
        }
    }
}
