﻿using System;
using System.Net;
using Newegg.API.Exceptions;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Keystone.Biz;
using Newegg.Framework.Service.Keystone.Dto;
using ServiceStack.Text;

namespace Newegg.Framework.Service.Keystone.Service
{
    public class AuthDataService : RestServiceBase<AuthData>
    {
        public override object OnPost(AuthData request)
        {
            var ssoBiz = new SSOBiz();
            var token = ssoBiz.GetSSOToken(request.Token);
            if (token == null)
            {
                throw new HttpError(HttpStatusCode.Forbidden, "403", "Invalid token.");
            }

            var authData = ssoBiz.GetCacheAuthData(request);

            if (authData == null)
            {
                authData = new KeystoneBiz().LoginTask(token.passport.user.username, string.Empty, request.ApplicationIds, false);
                if (request.Strict && authData.Roles.IsNullOrEmpty())
                {
                    throw new HttpError(HttpStatusCode.Forbidden, "403", "User does not belong any roles.");
                }
                ssoBiz.CacheAuthData(authData, request);
            }

            return authData;
        }

        public override object OnDelete(AuthData request)
        {
            var ssoBiz = new SSOBiz();
            ssoBiz.RemoveCacheAuthData(request.Token);
            return RequestContext.ReturnNoResponse();
        }
    }
}
