﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Keystone.Biz;
using Newegg.Framework.Service.Keystone.Dto;

namespace Newegg.Framework.Service.Keystone.Service
{
    public class HasFunctionService : RestServiceBase<HasFunctions>
    {
        public override object OnPost(HasFunctions request)
        {
            var biz = new KeystoneBiz();
            var functions = biz.GetAuthFunctionalAbilities(request.UserName, new List<string> {request.ApplicationId}) ??
                            new List<FunctionalAbility>();
            return request.Functions.Select(f => new HasFunctionResult
            {
                FunctionName = f,
                Result = functions.Exists(fa => fa.Name.Equals(f, StringComparison.InvariantCultureIgnoreCase))
            }).ToList();

        }
    }
}
