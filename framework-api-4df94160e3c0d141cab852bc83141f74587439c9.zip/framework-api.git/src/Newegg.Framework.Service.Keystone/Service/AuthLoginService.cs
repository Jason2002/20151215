﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Keystone.Biz;
using Newegg.Framework.Service.Keystone.Dto;

namespace Newegg.Framework.Service.Keystone.Service
{
    public class AuthLoginService:RestServiceBase<AuthLogin>
    {
        public override object OnPost(AuthLogin request)
        {
            return new KeystoneBiz().LoginTask(request.UserName, request.Password, request.ApplicationIds, true);
        }

        
    }
}
