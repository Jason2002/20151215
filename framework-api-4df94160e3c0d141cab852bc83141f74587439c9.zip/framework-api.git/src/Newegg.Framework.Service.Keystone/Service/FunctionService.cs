﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.Framework.Service.Keystone.Biz;
using Newegg.Framework.Service.Keystone.Dto;

namespace Newegg.Framework.Service.Keystone.Service
{
    public class FunctionService : RestServiceBase<Dto.Function>
    {
        public override object OnPost(Function request)
        {
            var biz = new KeystoneBiz();
            var result = biz.GetUserInfosByFunction(request.FunctionName, request.ApplicationId);
            return result;
        }
    }
}
