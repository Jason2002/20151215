﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Newegg.FrameworkAPI.SDK.CloudData
{
    public static class QueryConditionBuilder
    {
        private static string m_normalValueString = "\"{0}\":{1}";
        private static string m_twoValueString = "\"{0}\":{1},\"{2}\":{3}";
        public static FieldCondition BuildCondition(QueryOperator op, string fieldName, params object[] value)
        {
            return BuildConditionCore(new FieldCondition(), op, fieldName, value);
        }
        public static FieldCondition BuildOrCondition(QueryOperator op, string fieldName, params object[] value)
        {
            return BuildConditionCore(new FieldCondition(true), op, fieldName, value);
        }

        private static FieldCondition BuildConditionCore(FieldCondition condition, QueryOperator op, string fieldName, params object[] value)
        {
            if (value == null || value.Length == 0)
            {
                throw new ArgumentException("Field value is required.");
            }
            condition.FieldName = fieldName;
            switch (op)
            {
                case QueryOperator.Equal:
                    condition.SetValueObj(false);
                    condition.FieldValue = JsonConvert.SerializeObject(value[0]);
                    break;
                case QueryOperator.Match:
                    condition.FieldValue = buildNormalOper(m_normalValueString, "$match", value);
                    break;
                case QueryOperator.In:
                    condition.FieldValue = buildArrayOper(m_normalValueString, "$in", value);
                    break;
                case QueryOperator.NotIn:
                    condition.FieldValue = buildArrayOper(m_normalValueString, "$nin", value);
                    break;
                case QueryOperator.Greater:
                    condition.FieldValue = buildNormalOper(m_normalValueString, "$gt", value);
                    break;
                case QueryOperator.GreaterEqual:
                    condition.FieldValue = buildNormalOper(m_normalValueString, "$gte", value);
                    break;
                case QueryOperator.Less:
                    condition.FieldValue = buildNormalOper(m_normalValueString, "$lt", value);
                    break;
                case QueryOperator.LessEqual:
                    condition.FieldValue = buildNormalOper(m_normalValueString, "$lte", value);
                    break;
                case QueryOperator.GreaterAndLess:
                    condition.FieldValue = buildTwoValueOper(m_twoValueString, "$gt", "$lt", value);
                    break;
                case QueryOperator.Between:
                    condition.FieldValue = buildTwoValueOper(m_twoValueString, "$gte", "$lte", value);
                    break;

            }
            return condition;
        }

        private static string buildNormalOper(string temp, string oper, params object[] value)
        {
            return string.Format(temp, oper, JsonConvert.SerializeObject(value[0]));
        }

        private static string buildTwoValueOper(string temp, string oper1, string oper2, params object[] value)
        {
            if (value.Length != 2)
            {
                throw new ArgumentException("Must provider two values.");
            }
            return string.Format(temp, oper1, JsonConvert.SerializeObject(value[0]), oper2, JsonConvert.SerializeObject(value[1]));
        }

        private static string buildArrayOper(string temp, string oper, params object[] value)
        {
            return string.Format(temp, oper, JsonConvert.SerializeObject(value));
        }

        
    }
}
