﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Client;
using Newtonsoft.Json;
using ServiceStack.Text;

namespace Newegg.FrameworkAPI.SDK.CloudData
{
    public static class CloudDataHelper
    {
        private static readonly RestAPIClient m_RestClient = null;
        private static readonly string uriTemplate = "/{0}/{1}";

        static CloudDataHelper()
        {
            m_RestClient = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress.Replace("framework", "datastore"))
            {
                RawSerializeFn = JsonConvert.SerializeObject
            };
        }

        private static string GetAddress(string store, string collection)
        {
            return string.Format(uriTemplate, store, collection);
        }

        private static void SetPwd(string pwd)
        {
            if (!string.IsNullOrEmpty(pwd))
            {
                m_RestClient.AddCustomHeader("x-cloud-pwd", pwd);
            }
        }

        public static void BatchInsert<T>(string store, string collection, List<T> rows, string pwd = null)
        {
            SetPwd(pwd);
            m_RestClient.Post<string>(GetAddress(store, collection) + "/batch-insert", rows);
        }

        public static void BatchUpdate<T>(string store, string collection, List<T> rows, string pwd = null)
        {
            SetPwd(pwd);
            m_RestClient.Post<string>(GetAddress(store, collection) + "/batch-save", rows);
        }

        public static void Insert<T>(string store, string collection, T row, string pwd = null)
        {
            SetPwd(pwd);
            m_RestClient.Post<string>(string.Concat(GetAddress(store, collection), "?strict=true"), row);
        }

        public static void Update<T>(string store, string collection, T row, string pwd = null)
        {
            SetPwd(pwd);
            m_RestClient.Put<string>(string.Concat(GetAddress(store, collection), "?strict=true"), row);
        }

        public static void Save<T>(string store, string collection, T row, string pwd = null)
        {
            SetPwd(pwd);
            m_RestClient.Put<string>(GetAddress(store, collection), row);
        }

        public static void Remove(string store, string collection, string id, string pwd = null)
        {
            SetPwd(pwd);
            m_RestClient.Delete<string>(GetAddress(store, collection) + "/" + id, null);
        }

        public static T QueryById<T>(string store, string collection, string id, string pwd = null)
        {
            SetPwd(pwd);
            return m_RestClient.Get<T>(GetAddress(store, collection) + "/" + id, null);
        }

        public static QueryResult<T> Query<T>(string store, string collection, QueryCondition qc, string pwd = null)
        {
            SetPwd(pwd);
            string queryString = "?";
            if (qc.PageInfo != null)
            {
                queryString += QueryStringSerializer.SerializeToString(qc.PageInfo);
            }
            if (qc.FieldConditions != null)
            {
                foreach (var condition in qc.FieldConditions)
                {
                    queryString += "&" + condition;
                }
            }
            var normalQuery = GetNormalQueryString(qc);
            if (!string.IsNullOrEmpty(normalQuery))
            {
                queryString += "&" + normalQuery;
            }

            return m_RestClient.Get<QueryResult<T>>(GetAddress(store, collection) + queryString, null);
        }

        private static string GetNormalQueryString(QueryCondition qc)
        {
            string queryString = string.Empty;
            if (qc.ReturnFields != null && qc.ReturnFields.Count > 0)
            {
                queryString = "fields=" + JsonConvert.SerializeObject(qc.ReturnFields);
            }
            if (qc.Sort != null && !string.IsNullOrEmpty(qc.Sort.SortField))
            {
                if (!string.IsNullOrEmpty(queryString))
                {
                    queryString += "&";
                }
                queryString += "sortField=" + qc.Sort.SortField + "&sort=" + qc.Sort.Direction.ToString();
            }
            return queryString;
        }
    }
}
