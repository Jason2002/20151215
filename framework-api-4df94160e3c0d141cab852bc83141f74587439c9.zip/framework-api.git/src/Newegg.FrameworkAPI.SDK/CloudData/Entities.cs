﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.CloudData
{
    public enum QueryOperator
    {
        Equal,
        In,
        NotIn,
        Greater,
        GreaterEqual,
        Less,
        LessEqual,
        GreaterAndLess,
        Between,
        Match,
    }

    public class PageInfo
    {
        public int pageIndex { get; set; }
        public int pageSize { get; set; }
    }

    public class QueryResult<T>
    {
        public int pageIndex { get; set; }
        public int pageSize { get; set; }
        public int total_rows { get; set; }
        public List<T> rows { get; set; }
    }

    public class QueryCondition
    {
        public QueryCondition()
        {
            PageInfo = new PageInfo
            {
                pageIndex = 1,
                pageSize = 10,
            };
            FieldConditions = new List<FieldCondition>();
        }

        public void SetPage(int pageIndex, int pageSize)
        {
            if (pageIndex <= 0 || pageSize <= 0)
            {
                throw new ArgumentException("Page index and page size must be greater than 0");
            }
            PageInfo.pageIndex = pageIndex;
            PageInfo.pageSize = pageSize;
        }

        public PageInfo PageInfo { get; private set; }

        public List<string> ReturnFields { get; set; } 

        public SortDescription Sort { get; set; }

        public List<FieldCondition> FieldConditions { get; set; }
    }

    public class FieldCondition
    {
        public FieldCondition(bool isOr)
        {
            m_preFix = isOr ? "fo_" : "f_";
        }

        public FieldCondition():this(false)
        {
        }

        private string m_preFix;
        private bool m_isValueObj = true;
        public string FieldName { get; set; }
        public string FieldValue { get; set; }

        public void SetValueObj(bool isValueObj)
        {
            m_isValueObj = isValueObj;
        }
        public override string ToString()
        {
            if (m_isValueObj)
            {
                return m_preFix + FieldName + "={" + FieldValue + "}";
            }
            else
            {
                return m_preFix + FieldName + "=" + FieldValue;
            }
        }
    }

    public class SortDescription
    {
        public string SortField { get; set; }

        public SortDirection Direction { get; set; }
    }

    public enum SortDirection
    {
        asc,
        desc,
    }
}
