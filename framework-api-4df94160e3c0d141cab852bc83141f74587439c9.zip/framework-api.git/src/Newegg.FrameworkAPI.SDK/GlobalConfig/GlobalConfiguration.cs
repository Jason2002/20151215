﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.GlobalConfig
{
    public class GlobalConfiguration
    {
        public string ApplicationId { get; set; }


        public int ConfigID { get; set; }


        public string Key { get; set; }


        public string Value { get; set; }


        public string Domain { get; set; }


        public string Description { get; set; }


        public string InUser { get; set; }


        public DateTime InDate { get; set; }


        public string EditUser { get; set; }


        public DateTime? EditDate { get; set; }
    }
}
