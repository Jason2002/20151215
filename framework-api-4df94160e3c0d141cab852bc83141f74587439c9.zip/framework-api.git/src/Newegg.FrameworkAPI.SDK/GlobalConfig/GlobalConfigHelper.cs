﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Client;

namespace Newegg.FrameworkAPI.SDK.GlobalConfig
{
    public static class GlobalConfigHelper
    {
        public static GlobalConfiguration GetConfig(string domain, string key)
        {
            RestAPIClient client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);
            GlobalConfiguration request = new GlobalConfiguration
            {
                Domain = domain,
                Key = key,
            };
            return client.Get<GlobalConfiguration>("/global-configuration", request);
        }
    }
}
