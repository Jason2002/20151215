﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Client;

namespace Newegg.FrameworkAPI.SDK.Profile
{
    public static class ProfileHelper
    {
        private static RestAPIClient client;

        static ProfileHelper()
        {
            client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);
        }
        public static UserProfile GetProfiles(string systemName, string userId)
        {
            var path = string.Format("/user-profile/{0}/{1}", systemName, userId);
            return client.Get<UserProfile>(path, null);
        }

        public static UserProfile GetProfile(string systemName, string userId, string key)
        {
            var request = new ProfileRequest {SystemName = systemName, UserId = userId, Key = key};
            return client.Get<UserProfile>("/user-profile", request);
        }

        public static List<UserProfile> BatchGetProfile(BatchProfile batchQuery)
        {
            return client.Post<List<UserProfile>>("/user-profile/batch-query", batchQuery);
        }

        public static void SetProfiles(UserProfile profile)
        {
            client.Put<string>("/user-profile", profile);
        }

        public static void DeleteProfiles(string systemName, string userId)
        {
            var path = string.Format("/user-profile/{0}/{1}", systemName, userId);
            client.Delete<string>(path, null);
        }

        public static void DeleteProfile(string systemName, string userId, string key)
        {
            var request = new ProfileRequest {SystemName = systemName, UserId = userId, Key = key};
            client.Delete<string>("/user-profile", request);
        }
    }
}
