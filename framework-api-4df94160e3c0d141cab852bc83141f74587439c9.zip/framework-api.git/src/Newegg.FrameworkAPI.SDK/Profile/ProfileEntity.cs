﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.Profile
{
    public class UserProfile
    {
        public string SystemName { get; set; }

        public string UserId { get; set; }

        public List<ProfileContent> Profiles { get; set; }
    }

    public class ProfileContent
    {
        public string Key { get; set; }

        public string Value { get; set; }

        public DateTime LastEditDate { get; set; }
    }

    public class BatchProfile
    {
        public List<BatchQueryCondition> BatchQuery { get; set; }
    }

    public class BatchQueryCondition
    {
        public string SystemName { get; set; }

        public string UserId { get; set; }

        public string Key { get; set; }
    }

    internal class ProfileRequest
    {
        public string SystemName { get; set; }

        public string UserId { get; set; }

        public string Key { get; set; }
    }
}
