﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.Keystone
{
    public class HasFunctionResult
    {
        public string FunctionName { get; set; }

        public bool Result { get; set; }
    }

    public class HasFunctions
    {
        public string UserName { get; set; }

        public List<string> Functions { get; set; }

        public string ApplicationId { get; set; }
    }

    public class Function
    {
        public string FunctionName { get; set; }
        public string ApplicationId { get; set; }
    }

    public class FunctionResult
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class Attribute
    {
        public string UserName { get; set; }

        public string RoleName { get; set; }

        public List<string> ApplicationIds { get; set; }
    }

    public class RoleAttribute
    {
        public string RoleName { get; set; }

        public string Type { get; set; }

        public string Name { get; set; }

        public string Value { get; set; }

        public string ApplicationId { get; set; }

    }
}
