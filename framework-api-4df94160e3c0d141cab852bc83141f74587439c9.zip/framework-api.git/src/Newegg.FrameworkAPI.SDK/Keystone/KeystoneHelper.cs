﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Client;

namespace Newegg.FrameworkAPI.SDK.Keystone
{
    public static class KeystoneHelper
    {
        public static List<HasFunctionResult> HasFunctions(string userName, string applicationId,
            List<string> functionNames)
        {
            var client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);

            var request = new HasFunctions
            {
                ApplicationId = applicationId,
                UserName = userName,
                Functions = functionNames
            };

            return client.Post<List<HasFunctionResult>>("/keystone/has-functions", request);
        }

        public static List<RoleAttribute> GetAuthRoleAttributes(string userName, string roleName,
            List<string> applicationIds)
        {
            var client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);

            var request = new Attribute
            {
                UserName = userName,
                RoleName = roleName,
                ApplicationIds = applicationIds
            };

            return client.Post<List<RoleAttribute>>("/keystone/attribute", request);
        }

        public static List<FunctionResult> GetUsersByFunction(string functionName, string applicationId)
        {
            var client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);

            var request = new Function
            {
                FunctionName = functionName,
                ApplicationId = applicationId
            };
            return client.Post<List<FunctionResult>>("/keystone/function", request);
        }
    }
}
