﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Client;
using Newegg.Framework.Tools.Log;

namespace Newegg.FrameworkAPI.SDK.Log
{
    public static class LogHelper
    {
        public static void WriteLog(LogEntry logEntry)
        {
            if (string.IsNullOrEmpty(logEntry.GlobalName) || string.IsNullOrWhiteSpace(logEntry.GlobalName))
            {
                logEntry.GlobalName = SdkConfig.Instance.LogConfig.LogGlobal;
            }
            if (string.IsNullOrEmpty(logEntry.LocalName) || string.IsNullOrWhiteSpace(logEntry.LocalName))
            {
                logEntry.LocalName = SdkConfig.Instance.LogConfig.LogLocal;
            }
            RestAPIClient client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);            
            client.Post<string>("/log-entry", logEntry, true);
        }
    }
}
