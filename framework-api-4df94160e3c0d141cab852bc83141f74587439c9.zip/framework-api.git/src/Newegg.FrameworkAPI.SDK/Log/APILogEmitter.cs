﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Tools.Log;
using Newegg.Framework.Tools.Log.Emitter;

namespace Newegg.FrameworkAPI.SDK.Log
{
    public class APILogEmitter : ILogEmitter
    {
        public void EmitLog(LogEntry log)
        {
            LogHelper.WriteLog(log);
        }
    }
}
