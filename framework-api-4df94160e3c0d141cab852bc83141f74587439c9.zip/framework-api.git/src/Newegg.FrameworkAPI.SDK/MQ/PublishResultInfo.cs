﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.MQ
{
    public class PublishResultInfo
    {
        /// <summary>
        /// 消息发送是否成功
        /// </summary>
        public bool IsSucceed { get; set; }

        /// <summary>
        /// 标识消息的唯一ID
        /// </summary>
        public Guid MessageId { get; set; }

        /// <summary>
        /// 错误码
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 错误描述信息
        /// </summary>
        public string ErrorMessage { get; set; }
    }
}
