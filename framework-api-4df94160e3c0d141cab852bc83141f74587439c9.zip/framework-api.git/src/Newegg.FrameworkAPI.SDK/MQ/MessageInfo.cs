﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.MQ
{
    public class MessageInfo
    {
        public string MessageName { get; set; }

        public string Password { get; set; }

        public string MessageBody { get; set; }

        public string CallbackUri { get; set; }

        public string InvokeUri { get; set; }

        public string ContentType { get; set; }

        public InvokeType InvokeType { get; set; }

        public List<RequestHeader> MessageHeaders { get; set; }

        public List<RequestHeader> RequestHeaders { get; set; }
    }

    public class RequestHeader
    {
        public string HeaderName { get; set; }

        public string HeaderValue { get; set; }
    }

    public enum InvokeType
    {
        Normal,
        Async,
        Message,
    }
}
