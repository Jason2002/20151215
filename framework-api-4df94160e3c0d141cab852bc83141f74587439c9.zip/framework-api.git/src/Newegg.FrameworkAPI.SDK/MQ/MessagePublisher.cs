﻿using Newegg.API.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.MQ
{
    public static class MessagePublisher
    {
        private static readonly RestAPIClient m_RestClient = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);

        public static PublishResultInfo SendMessageJson<T>(T request, string messageName, string callbackUri)
        {
            return SendMessageJson<T>(request, messageName, string.Empty, null, callbackUri);
        }

        public static PublishResultInfo SendMessageJson<T>(T request, string messageName, string password,
            IEnumerable<KeyValuePair<string, string>> headers, string callbackUri)
        {
            string body = ServiceStack.Text.JsonSerializer.SerializeToString<T>(request);
            return SendMessage(body, messageName, password, callbackUri, ContentTypes.Json, headers);
        }

        public static PublishResultInfo SendMessageXml<T>(T request, string messageName, string callbackUri)
        {
            return SendMessageXml<T>(request, messageName, string.Empty, null, callbackUri);
        }

        public static PublishResultInfo SendMessageXml<T>(T request, string messageName, string password,
            IEnumerable<KeyValuePair<string, string>> headers, string callbackUri)
        {
            string body = ServiceStack.Text.XmlSimpleSerializer.SerializeToString<T>(request);
            return SendMessage(body, messageName, password, callbackUri, ContentTypes.Xml, headers);
        }

        private static PublishResultInfo SendMessage(string body, string messageName, string password,
            string callbackUri, string contentType, IEnumerable<KeyValuePair<string, string>> headers)
        {
            var messageInfo = new MessageInfo
            {
                MessageName = messageName,
                Password = password,
                MessageBody = body,
                ContentType = contentType,
                CallbackUri = callbackUri,
                InvokeType = InvokeType.Message
            };
            if (headers != null)
            {
                messageInfo.MessageHeaders = new List<RequestHeader>();
                foreach (var header in headers)
                {
                    messageInfo.MessageHeaders.Add(new RequestHeader()
                    {
                        HeaderName = header.Key,
                        HeaderValue = header.Value
                    });
                }
            }
            try
            {
                var publishResultInfo = m_RestClient.Post<PublishResultInfo>("/enterprise-messaging/message", messageInfo);
                publishResultInfo.IsSucceed = true;
                return publishResultInfo;
            }
            catch (WebServiceException wse)
            {
                return new PublishResultInfo
                {
                    IsSucceed = false,
                    ErrorCode = wse.ResponseCode,
                    ErrorMessage = wse.Message
                };
            }
            catch (Exception ex)
            {
                return new PublishResultInfo
                {
                    IsSucceed = false,
                    ErrorMessage = ex.Message
                };
            }
        }
    }
}