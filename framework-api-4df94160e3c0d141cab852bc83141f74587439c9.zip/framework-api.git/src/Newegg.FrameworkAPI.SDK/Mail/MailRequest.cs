﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.FrameworkAPI.SDK.Mail
{
    public class MailRequest
    {
        public string From { get; set; }

        public string To { get; set; }

        public string CC { get; set; }

        public string BCC { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public bool IsNeedLog { get; set; }

        public MailPriority Priority { get; set; }

        public MailContentType ContentType { get; set; }

        public MailType MailType { get; set; }

        public LondonIISetting LondonIISetting { get; set; }

        public SmtpSetting SmtpSetting { get; set; }

    }

    public class MailAttachment
    {
        public string FileName { get; set; }

        public byte[] FileContent { get; set; }

        public MediaType MediaType { get; set; }
    }

    public class SmtpSetting
    {
        public MailEncoding SubjectEncoding { get; set; }

        public MailEncoding BodyEncoding { get; set; }

        public List<MailAttachment> Attachments { get; set; }

    }

    public class LondonIISetting
    {
        public string CompanyCode { get; set; }

        public string CountryCode { get; set; }

        public string LanguageCode { get; set; }

        public string SystemID { get; set; }

        public string TemplateID { get; set; }

        public int? CustomerNumber { get; set; }

        public List<MailTemplateVariable> MailTemplateVariables { get; set; }
    }

    public class MailTemplateVariable
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }

    public class MailSendResult
    {
        public bool IsSendSuccess { get; set; }

        public string MailLogUri { get; set; }
    }

    public enum MailPriority
    {
        Normal = 0,

        Low = 1,

        High = 2,
    }

    public enum MailContentType
    {
        Html,
        Text,
    }

    public enum MailType
    {
        LondongII,
        Smtp,
    }

    public enum MailEncoding
    {

        UTF8,

        ASCII,

        UTF32,

        Unicode
    }

    public enum MediaType
    {

        GIF,

        JPEG,

        TIFF,

        PDF,

        RTF,

        SOAP,

        ZIP,

        Other
    }

    public class LondonIIMailQuery
    {
        public string CompanyCode { get; set; }

        public string CountryCode { get; set; }

        public string LanguageCode { get; set; }

        public string SystemID { get; set; }

        public string TemplateID { get; set; }

        public List<MailTemplateVariable> MailTemplateVariables { get; set; }
    }
}
