﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Client;

namespace Newegg.FrameworkAPI.SDK.Mail
{
    public static class MailSender
    {
        public static MailSendResult Send(MailRequest request)
        {
            RestAPIClient client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);
            return client.Post<MailSendResult>("/mail", request);
        }

        public static MailRequest GetLondonIIContent(LondonIIMailQuery query)
        {
            RestAPIClient client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);
            return client.Post<MailRequest>("/mail/london2-content", query);
        }
    }
}
