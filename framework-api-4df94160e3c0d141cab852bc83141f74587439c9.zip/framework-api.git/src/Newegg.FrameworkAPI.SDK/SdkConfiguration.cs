﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Xml;

namespace Newegg.FrameworkAPI.SDK
{
    public class SdkConfiguration : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            SdkConfig config = GetDefaultConfig();

            if (section != null && section.HasChildNodes)
            {
                foreach (XmlNode node in section.ChildNodes)
                {
                    if (node.Name.Equals("frameworkAPI", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (node.Attributes["uri"] != null && node.Attributes["uri"].Value != null)
                        {
                            config.FrameworkAPIAddress = node.Attributes["uri"].Value.Trim();
                        }
                    }
                    if (node.Name.Equals("logConfig", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (node.Attributes["logGlobal"] != null && node.Attributes["logGlobal"].Value != null)
                        {
                            config.LogConfig.LogGlobal = node.Attributes["logGlobal"].Value.Trim();
                        }
                        if (node.Attributes["logLocal"] != null && node.Attributes["logLocal"].Value != null)
                        {
                            config.LogConfig.LogLocal = node.Attributes["logLocal"].Value.Trim();
                        }
                    }
                }
            }
            return config;
        }

        private SdkConfig GetDefaultConfig()
        {
            return new SdkConfig
            {
                FrameworkAPIAddress = "http://apis.newegg.org/framework/v1/",
                LogConfig = new LogConfig
                {
                    LogGlobal = "DefaultGlobal",
                    LogLocal = "DefaultLocal",
                },
            };
        }
    }

    public class SdkConfig
    {
        public LogConfig LogConfig { get; set; }

        public string FrameworkAPIAddress { get; set; }

        private static SdkConfig m_config = null;
        static object _lock = new object();

        public static SdkConfig Instance
        {
            get
            {
                if (m_config == null)
                {
                    lock (_lock)
                    {
                        m_config = ConfigurationManager.GetSection("frameworkAPISdk") as SdkConfig;
                    }
                    if (m_config == null)
                    {
                        throw new ConfigurationErrorsException("Missing 'frameworkAPISdk' configuration section.");
                    }
                }
                return m_config;
            }
        }
    }

    public class LogConfig
    {
        public string LogGlobal { get; set; }

        public string LogLocal { get; set; }
    }
}
