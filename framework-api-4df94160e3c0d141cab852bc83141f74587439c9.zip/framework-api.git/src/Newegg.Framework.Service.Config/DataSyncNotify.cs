﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Config
{
    public class DataSyncNotify
    {
        public EntrySyncNotify<GlobalConfiguration> Config { get; set; }
    }

    public class EntrySyncNotify<T>
    {
        public DataSyncAction SyncAction { get; set; }
        public T Config { get; set; }
    }

    public enum DataSyncAction
    { 
        Insert = 1,
        Update = 2,
        Delete = 3
    }
}
