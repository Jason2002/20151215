﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.Config
{
    public static class ErrorCodes
    {
        public static string ConfigExists = "";
        public static string ConfigNotExists = "";
    }
}
