﻿using Newegg.API.Common;
using Newegg.API.ServiceHost;

namespace Newegg.Framework.Service.Config
{
    public class AppInit : AppHostBase
    {
        public override void Init()
        {
            this.RegisterValidators(typeof(AppInit).Assembly);

            this.RequestFilters.Insert(0, (req, res, obj) =>
            {
                if (req.Headers[HttpHeaders.Origin] != null)
                {
                    res.AddHeader(HttpHeaders.AllowOrigin, req.Headers[HttpHeaders.Origin]);
                }
                if (req.Headers[HttpHeaders.RequestHeaders] != null)
                {
                    res.AddHeader(HttpHeaders.AllowHeaders, req.Headers[HttpHeaders.RequestHeaders]);
                }
            });
        }
    }
}
