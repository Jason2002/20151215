﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Newegg.API.Attributes;

namespace Newegg.Framework.Service.Config
{
    [RestService("/global-configuration/{Domain}/{Key}")]
    [RestService("/global-configuration/{Domain}")]
    [RestService("/global-configuration")]
    [ResponseType(typeof(GlobalConfiguration))]
    public class GlobalConfiguration
    {
        public string ApplicationId { get; set; }

        [IgnoreDataMember]
        [XmlIgnore]
        public string DomainKey
        {
            get
            {
                return Domain.ToLower() + ":" + Key.ToLower();
            }
        }

        public int ConfigID { get; set; }

        
        public string Key { get; set; }

        
        public string Value { get; set; }

        
        public string Domain { get; set; }

        
        public string Description { get; set; }

        
        public string InUser { get; set; }

        
        public DateTime InDate { get; set; }

        
        public string EditUser { get; set; }

        
        public DateTime? EditDate { get; set; }
    }
}
