﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Nair.Sdk;
using Newegg.FrameworkAPI.SDK.CloudData;

namespace Newegg.Framework.Service.Config
{
    public class GlobalConfigurationBiz
    {
        private static string m_appId = ConfigurationManager.AppSettings["GlobalConfigDefaultAppId"];
        private NairClient m_nairClient;
        public GlobalConfigurationBiz()
        {
            m_nairClient = NairFactory.GetNairClient();
        }        

        private static string m_Store = ConfigurationManager.AppSettings["GlobalConfigStoreName"];
        private static string m_Collection = ConfigurationManager.AppSettings["GlobalConfigCollectionName"];

        private static string m_DbName = ConfigurationManager.AppSettings["GlobalConfigDbName"];
        private static string m_Key = ConfigurationManager.AppSettings["GlobalConfigKey"];
        #region GetConfigurations
        public List<GlobalConfiguration> GetConfigurations(string domain)
        {
            List<GlobalConfiguration> configs;
            bool usedCloudData = false;
            try
            {
                configs = m_nairClient.Get<List<GlobalConfiguration>>(m_DbName, m_Key);
            }
            catch (Exception)
            {
                var qc = new QueryCondition();
                qc.SetPage(1, 3000);
                configs = CloudDataHelper.Query<GlobalConfiguration>(m_Store, m_Collection, qc).rows;
                usedCloudData = true;
            }
            if ((configs == null || configs.Count == 0) && !usedCloudData)
            {
                var qc = new QueryCondition();
                qc.SetPage(1, 3000);
                configs = CloudDataHelper.Query<GlobalConfiguration>(m_Store, m_Collection, qc).rows;
            }
            configs = configs ?? new List<GlobalConfiguration>();
            if (string.IsNullOrEmpty(domain))
            {
                return configs;
            }
            else
            {
                return configs.Where(c => c.Domain.Equals(domain, StringComparison.InvariantCultureIgnoreCase)).ToList();
            }
             
        }

        #endregion

        #region GetConfiguration
        public GlobalConfiguration GetConfiguration(string domain, string key)
        {
            var domainKey = domain.ToLower() + ":" + key.ToLower();
            var list = GetConfigurations(domain).FirstOrDefault(p => p.DomainKey == domainKey);
            if (list != null )
            {
                return list;
            }
            return null;
        }

        #endregion

        #region IsConfigExists
        public bool IsConfigExists(string domain, string key, int? configID = null)
        {
            string domainkey = domain.ToLower() + ":" + key.ToLower();
            var qc = new QueryCondition();
            qc.FieldConditions.Add(QueryConditionBuilder.BuildCondition(
                QueryOperator.Equal,
                "DomainKey",
                domainkey
                ));
            var config = CloudDataHelper.Query<GlobalConfiguration>(m_Store, m_Collection, qc, null).rows;
            if (config == null || config.Count == 0)
            {
                return false;
            }
            else
            {                
                return true;
            }
        }
       
        #endregion

        #region  Create

        public GlobalConfiguration Create(GlobalConfiguration entity)
        {
            entity.ApplicationId = m_appId;
            entity.InDate = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
            var configs = GetConfigurations(null);
            CloudDataHelper.Save<GlobalConfiguration>(m_Store, m_Collection, entity);
            
            configs.Add(entity);
            m_nairClient.Put(m_DbName, m_Key, configs, 0);

            return entity;
        }

        #endregion

        #region Update

        public void Update(GlobalConfiguration entity)
        {
            entity.ApplicationId = m_appId;
            entity.EditDate = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
            
            CloudDataHelper.Save<GlobalConfiguration>(m_Store, m_Collection, entity);
            var configs = GetConfigurations(null);
            configs.RemoveAll(p => p.DomainKey == entity.DomainKey);
            configs.Add(entity);
            m_nairClient.Put(m_DbName, m_Key, configs, 0);
        }

        #endregion

        #region Delete

        public void Delete(GlobalConfiguration entity)
        {
            var configs = GetConfigurations(null);
            //对于删除动作，要求Domain和Key为必须
            var deletedConfig = GetConfiguration(entity.Domain, entity.Key);

            if (deletedConfig != null)
            {
                CloudDataHelper.Remove(m_Store, m_Collection, deletedConfig.DomainKey);
                
                configs.RemoveAll(p=>p.DomainKey == entity.DomainKey);
                m_nairClient.Put(m_DbName, m_Key, configs, 0);
            }
        }

        #endregion

        #region Test
        public void Test()
        {
            GetConfigurations(null);
            IsConfigExists("admin", "asdfasd", 1276);
        }

        public void TestCreate()
        {
            GlobalConfiguration entity = new GlobalConfiguration();
            entity.ConfigID = 1272;
            entity.ApplicationId = "16feb62f-e80d-4472-8b35-7841427b43f0";
            entity.Domain = "admin";
            entity.EditDate = DateTime.Now;
            entity.EditUser = "admin";
            entity.InDate = DateTime.Now;
            entity.Key = "asdfasd";
            entity.InUser = "admin";
            Create(entity);
        }

        public void TestUpdate()
        {
            GlobalConfiguration entity = new GlobalConfiguration();
            entity.ConfigID = 1276;
            entity.ApplicationId = "16feb62f-e80d-4472-8b35-7841427b43f0";
            entity.Domain = "admin";
            entity.EditDate = DateTime.Now;
            entity.EditUser = "admin123";
            entity.InDate = DateTime.Now;
            entity.Key = "asdfasd";
            entity.InUser = "admin123";
            Update(entity);
        }

        public void TestDelete()
        {
            GlobalConfiguration entity = new GlobalConfiguration();
            entity.ConfigID = 1276;
            entity.ApplicationId = "16feb62f-e80d-4472-8b35-7841427b43f0";
            entity.Domain = "admin";
            entity.EditDate = DateTime.Now;
            entity.EditUser = "admin123";
            entity.InDate = DateTime.Now;
            entity.Key = "asdfasd";
            entity.InUser = "admin";
            Delete(entity);
        }

        #endregion
    }
}
