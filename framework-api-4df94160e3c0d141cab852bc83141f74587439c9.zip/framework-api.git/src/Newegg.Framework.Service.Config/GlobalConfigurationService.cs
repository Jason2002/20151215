﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Common;
using Newegg.API.Exceptions;
using Newegg.API.Interfaces;

namespace Newegg.Framework.Service.Config
{
    public class GlobalConfigurationService : RestServiceBase<GlobalConfiguration>
    {
        protected override void OnBeforeExecute(GlobalConfiguration request)
        {
            if (RequestContext.ExecuteContext.HttpMethod == HttpMethods.Post)
            {
                var exists = new GlobalConfigurationBiz().IsConfigExists(request.Domain, request.Key);
                if (exists)
                {
                    throw new HttpError(ErrorCodes.ConfigExists, "Global configuration exists with same domain and key");
                }
            }
            if (RequestContext.ExecuteContext.HttpMethod == HttpMethods.Put)
            {
                var exists = new GlobalConfigurationBiz().IsConfigExists(request.Domain, request.Key, request.ConfigID);
                if (!exists)
                {
                    throw new HttpError(ErrorCodes.ConfigNotExists, "Global configuration not exists");
                }
            }
        }

        public override object OnGet(GlobalConfiguration request)
        {
            if (!string.IsNullOrWhiteSpace(request.Domain) && !string.IsNullOrWhiteSpace(request.Key))
            {
                return new GlobalConfigurationBiz().GetConfiguration(request.Domain, request.Key);
            }
            else
            {
                return new GlobalConfigurationBiz().GetConfigurations(request.Domain);
            }
        }

        public override object OnPost(GlobalConfiguration request)
        {

            var obj = new GlobalConfigurationBiz().Create(request);

            return obj;
        }

        public override object OnPut(GlobalConfiguration request)
        {
            new GlobalConfigurationBiz().Update(request);
            return request;
        }

        public override object OnDelete(GlobalConfiguration request)
        {
            new GlobalConfigurationBiz().Delete(request);
            return request;
        }
    }
}
