﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using FluentValidation;

namespace Newegg.Framework.Service.Config
{
    public class GlobalConfigurationValidator : CustomerValidator<GlobalConfiguration>
    {
        public GlobalConfigurationValidator()
        {
            RuleSet(ApplyTo.Post | ApplyTo.Put,
                () =>
                {
                    RuleFor(g => g.Domain, true).NotNull().NotEmpty();
                    RuleFor(g => g.Key, true).NotNull().NotEmpty();
                    RuleFor(g => g.Value, true).NotNull().NotEmpty();
                });

            RuleSet(ApplyTo.Post,
                () =>
                {
                    RuleFor(g => g.InUser, true).NotNull().NotEmpty();
                });

            RuleSet(ApplyTo.Put,
                () =>
                {
                    RuleFor(g => g.EditUser, true).NotNull().NotEmpty();
                });

            RuleSet(ApplyTo.Delete,
                () =>
                {
                    RuleFor(g => g.Domain, true).NotNull().NotEmpty();
                    RuleFor(g => g.Key, true).NotNull().NotEmpty();
                });
        }
    }
}
