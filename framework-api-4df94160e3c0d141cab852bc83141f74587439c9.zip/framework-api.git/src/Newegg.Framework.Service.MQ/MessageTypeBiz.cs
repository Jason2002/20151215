﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Oversea.DataAccess;

namespace Newegg.Framework.Service.MQ
{
    public class MessageTypeBiz
    {
        public List<MessageType> GetListWithSubscribers()
        {
            var dataCommand = DataCommandManager.GetDataCommand("Message.GetListWithSubscribers");
            using (var gridReader = dataCommand.ExecuteMultiple())
            {
                var allMsgTypes = gridReader.Read<MessageType>();
                var allMsgTags = gridReader.Read<MessageTag>();
                var allSubscribers = gridReader.Read<Subscriber>();
                var allConditions = gridReader.Read<SubscriberFilter>();

                foreach (var msgType in allMsgTypes)
                {
                    msgType.Subscribers = (from s in allSubscribers
                        where s.MsgTypeId == msgType.MsgTypeId
                        select s).ToList();

                    var tags = (from t in allMsgTags
                        where t.MessageTypeId == msgType.MsgTypeId
                        select t.TagName).ToList();
                    msgType.Tags = string.Join(",", tags);

                    if (msgType.Subscribers.Count > 0)
                    {
                        foreach (var sub in msgType.Subscribers)
                        {
                            sub.Filters = (from f in allConditions
                                where f.SubscriberId == sub.SubscriberId
                                select f
                                ).ToList();
                        }
                    }
                }

                return allMsgTypes.ToList();
            }
        }
    }
}
