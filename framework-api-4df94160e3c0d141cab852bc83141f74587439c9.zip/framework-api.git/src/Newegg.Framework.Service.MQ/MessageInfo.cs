﻿using Newegg.API.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceStack.Text;

namespace Newegg.Framework.Service.MQ
{
    [RestService("/enterprise-messaging/message-type")]
    [ResponseType(typeof(MessageType))]
    public class MessageType
    {
        public Guid MsgTypeId { get; set; }
        public string MsgTypeName { get; set; }
        public string Password { get; set; }
        public string Description { get; set; }
        public int MaxPendingLength { get; set; }
        public int AlertPendingLength { get; set; }
        public string Provider { get; set; }
        public int RetentionTime { get; set; }
        public int RetentionQuota { get; set; }

        /// <summary>
        /// kb
        /// </summary>
        public int MaxMessageSize { get; set; }
        public string ContentSchema { get; set; }
        public string Owner { get; set; }
        public string ContactInfo { get; set; }
        public string ContentType { get; set; }
        public bool OrderRequired { get; set; }
        public bool IsMessageTracking { get; set; }
        public int TTL { get; set; }
        public string Tags { get; set; }
        public List<Subscriber> Subscribers { get; set; }

    }

    public class Subscriber
    {
        public Guid SubscriberId { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public int Priority { get; set; }
        public Guid MsgTypeId { get; set; }
        public string HttpMethod { get; set; }
        public string Uri { get; set; }
        public int Timeout { get; set; }
        public int RetryCount { get; set; }
        public int RetryInterval { get; set; }
        public int MaxPendingLength { get; set; }
        public int AlertPendingLength { get; set; }
        public int? AutoReplayInterval { get; set; }
        public int PrefetchGear { get; set; }
        public string ContactInfo { get; set; }
        public bool IsSendAlertMail { get; set; }
        public int Status { get; set; }
        public bool IsEnableFilter { get; set; }
        public string Expression { get; set; }
        public bool IsEnableCallback { get; set; }
        public int Range { get; set; }
        public string CallbackQueue { get; set; }
        public bool OriginalMessageBodyFlag { get; set; }
        public bool FullTextSearchFlag { get; set; }
        public List<SubscriberFilter> Filters { get; set; }
        
        [IgnoreDataMember]
        public string BackupUri { get; set; }

        public string[] BackupUris
        {
            get
            {
                var backupUris = new string[] {};
                if (!string.IsNullOrEmpty(BackupUri))
                {
                    backupUris = BackupUri.Split(' ');
                }
                return backupUris;
            }
        }
    }

    public class SubscriberFilter 
    {
        public int FilterId { get; set; }
        public Guid SubscriberId { get; set; }
        public string PK { get; set; }
        public FilterDataType DataType { get; set; }
        public string FieldName { get; set; }
        public string Operate { get; set; }
        public string Value { get; set; }
    }

    public class MessageTag
    {
        public Guid MessageTypeId { get; set; }
        public string TagName { get; set; }
    }

    public enum FilterDataType
    {
        None = 0,
        Number = 1,
        String = 3,
        Datetime = 4,
        RegularExpression = 5
    }
}
