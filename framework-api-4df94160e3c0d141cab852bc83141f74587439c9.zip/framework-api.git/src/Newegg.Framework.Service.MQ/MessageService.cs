﻿using System.Configuration;
using Newegg.API.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Service.MQ
{
    public class MsgTypeService : RestServiceBase<MessageType>
    {
        public override object OnGet(MessageType request)
        {
            return new MessageTypeBiz().GetListWithSubscribers();
        }
    }
}
