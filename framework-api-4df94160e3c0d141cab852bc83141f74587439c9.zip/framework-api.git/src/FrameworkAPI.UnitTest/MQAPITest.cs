﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.FrameworkAPI.SDK.MQ;
using Newegg.FrameworkAPI.SDK.Mail;
using System.IO;

namespace FrameworkAPI.UnitTest
{
    [TestClass]
    public class MQAPITest
    {
        [TestMethod]
        public void MQ_PublishMsg_Test()
        {
            //for (int i = 1; i < 10; i++)
            //{
            MailRequest request = new MailRequest();
            request.Subject = "Mail Send From Message Queue ";
            request.From = "james.y.yang@newegg.com";
            request.To = "james.y.yang@newegg.com";
            request.CC = "zeeman.z.huang@newegg.com";
            request.Body = "test body";
            request.ContentType = MailContentType.Html;
            request.IsNeedLog = false;
            request.Priority = MailPriority.Low;
            request.MailType = MailType.Smtp;
            request.SmtpSetting = new SmtpSetting
            {
                BodyEncoding = MailEncoding.UTF8,
                SubjectEncoding = MailEncoding.UTF8,
            };

            MessagePublisher.SendMessageJson<MailRequest>(request, "TestMailMessage", "http://www.google.com");
            //}

            //MessagePublisher.SendMessageXml<TestMessageInfo>(new TestMessageInfo
            //{
            //    Name = "this is test name",
            //    Department = "this is test department",
            //}, "ACCT_fa_order_pay", "this is callback url");

            //MessagePublisher.SendMessageJson<TestMessageInfo>(new TestMessageInfo
            //{
            //    Name = "Message Json",
            //    Department = "MIS",
            //}, "TestMailMessage", "http://10.16.76.250:11355/framework/v1/global-configuration");

            //MessagePublisher.SendMessageXml<TestMessageInfo>(new TestMessageInfo
            //{
            //    Name = "Message Xml",
            //    Department = "MIS",
            //}, "James_Test_Message", "http://10.16.76.250:11355/framework/v1/global-configuration");
        }

        [TestMethod]
        public void MQ_PublishMsg_Test2()
        {
            MessagePublisher.SendMessageJson<string>(
                "{\"MessageType\":\"Newegg.BigData.Entity.Common.EntitySaveRequest\",\"MessageBody\":\"{\\\"Action\\\":1,\\\"EntityOrList\\\":[{\\\"HashRowKey\\\":\\\"d132a4520c4023e785afb55f54d2d8006d9b23e6bf649ea6d123173376e00735\\\",\\\"ItemNumber\\\":\\\"00-918-014\\\",\\\"Description\\\":\\\"nnnn\\\",\\\"ManufacturerPartNumber\\\":\\\"ddddd\\\",\\\"ReceivingInstruction\\\":\\\"\\\",\\\"ArrivingDate\\\":\\\"2013-01-25T00:00:00\\\",\\\"ReceivingImage\\\":\\\"00-918-014-01.jpg\\\",\\\"StandaloneFlag\\\":false,\\\"Manufacturer\\\":48118,\\\"CairoFixedFlag\\\":false,\\\"DownloadSoftwareFlag\\\":\\\"U\\\",\\\"SubCategoryCode\\\":2726,\\\"DummyCellPhoneFlag\\\":false,\\\"ThirdPartyItemLink\\\":\\\"\\\",\\\"ManufacturerProductLink\\\":\\\"http://\\\",\\\"NewEggSpecialMark\\\":false,\\\"RecertifiedFlag\\\":false,\\\"ProductType\\\":\\\"001\\\",\\\"ImageName\\\":\\\"00-918-014-01.jpg\\\",\\\"FullImageName\\\":\\\"00-918-014-01.jpg\\\",\\\"Rating\\\":0,\\\"AdsNumber\\\":\\\"ggggg\\\",\\\"HumanRating\\\":0,\\\"SouthBridge\\\":1,\\\"AdjustRate\\\":0,\\\"AdjustQuantity\\\":0,\\\"GreenItemFlag\\\":false,\\\"DiscontinueFlag\\\":true,\\\"UNSPSC\\\":\\\"\\\",\\\"OEMFlag\\\":true,\\\"OEMDisplayFlag\\\":false,\\\"AcademicFlag\\\":false,\\\"WatermarkExceptionFlag\\\":false,\\\"WebsiteSubcategoryCode\\\":2795,\\\"Scene7ImageReadyFlag\\\":false,\\\"ItemCreateDate\\\":\\\"2012-01-01T00:00:00\\\",\\\"ItemCreateUser\\\":\\\"my30\\\",\\\"BaseLastEditDate\\\":\\\"2013-08-03T01:39:47\\\",\\\"BaseLastEditUser\\\":\\\"my30\\\",\\\"DeleteFlag\\\":false,\\\"DeleteUser\\\":\\\"\\\",\\\"DeleteDate\\\":\\\"0001-01-01T00:00:00\\\",\\\"MacCompatibleFlag\\\":null,\\\"LastImageNumber\\\":null,\\\"LargeFlag\\\":null,\\\"UPCCode\\\":null,\\\"OwnerCompanyCode\\\":null,\\\"ParentItem\\\":null,\\\"SellerPartNumber\\\":null,\\\"SellerID\\\":null,\\\"ItemGroupID\\\":null,\\\"ShipByNewegg\\\":null,\\\"SBNConvertible\\\":null,\\\"FirstFromAsia\\\":null,\\\"SellerItemNeedMeasureFlag\\\":null,\\\"Base02LastEditDate\\\":null,\\\"Base02LastEditUser\\\":null,\\\"Title\\\":null,\\\"BulletDescription\\\":null,\\\"LineDescription\\\":null,\\\"WebDescription\\\":null,\\\"DetailSpecification\\\":null,\\\"Checked\\\":null,\\\"Checker\\\":null,\\\"CheckDate\\\":null,\\\"ManualTitle\\\":null,\\\"ManualBullet\\\":null,\\\"ManualLine\\\":null,\\\"ManualWeb\\\":null,\\\"ViewDescription\\\":null,\\\"ProductTitle\\\":null,\\\"ProductWeb\\\":null,\\\"ProductName\\\":null,\\\"ManualProductTitle\\\":null,\\\"ManualProductWeb\\\":null,\\\"ManualProductName\\\":null,\\\"DescriptionInDate\\\":null,\\\"DescriptionInUser\\\":null,\\\"DescriptionLastEditDate\\\":null,\\\"DescriptionLastEditUser\\\":null,\\\"Length\\\":null,\\\"Width\\\":null,\\\"Height\\\":null,\\\"PackageWeight\\\":null,\\\"DimensionWeightUPS\\\":null,\\\"DimensionWeightFedEx\\\":null,\\\"DimensionWeightAIT\\\":null,\\\"APOCompatible\\\":null,\\\"UPSLargePackageFlag\\\":null,\\\"DimensionWeightUPSGround\\\":null,\\\"DimensionWeightUPSINTL\\\":null,\\\"DimensionWeightPurolatorGround\\\":null,\\\"DimensionWeightPurolatorExpress\\\":null,\\\"DimensionInDate\\\":null,\\\"DimensionInUser\\\":null,\\\"DimensionLastEditDate\\\":null,\\\"DimensionLastEditUser\\\":null,\\\"ChildItemList\\\":null,\\\"ImageList\\\":null,\\\"MultiDescriptionList\\\":null}],\\\"EntityType\\\":\\\"Newegg.BigData.Entity.ItemMaintain.ItemBaseBDEntity\\\",\\\"ParamEntity\\\":{\\\"NoExtendFlag\\\":false,\\\"NoMessageFlag\\\":false,\\\"KeySpace\\\":\\\"ItemMaintainNewegg\\\",\\\"Cluster\\\":\\\"\\\",\\\"ConsistencyLevel\\\":1,\\\"ProviderName\\\":\\\"CassandraProvider\\\"},\\\"SaveType\\\":0,\\\"ListRemoveBeforeSave\\\":false,\\\"SerializeType\\\":null,\\\"ResultValueType\\\":0}\"}",
                "IMMessage", null);
        }

        [TestMethod]
        public void MQ_PublishMsg_Test30()
        {
            List<int> data = new List<int>();
            for (int i = 0; i < 10; i++)
            {
                data.Add(i);
            }

            Parallel.ForEach(data, new ParallelOptions
            {
                MaxDegreeOfParallelism = 10,
            },
                (i) =>
                {
                    Stopwatch watch = new Stopwatch();
                    watch.Start();
                    Assert.IsTrue(MessagePublisher.SendMessageJson<int>(i, "zeetest3", null).IsSucceed);
                    watch.Stop();
                    Console.WriteLine(string.Format("Worker {0}, Elapsed: {1}", 0, watch.ElapsedMilliseconds));
                });
        }

        [TestMethod]
        public void MQ_PublishMsg_Test3()
        {
            using (StreamReader sr = new StreamReader("IMMessageBody.txt"))
            {
                string body = sr.ReadToEnd();
                List<string> data = new List<string>();
                for (int i = 0; i < 10; i++)
                {
                    data.Add(body);
                }

                Parallel.ForEach(data, new ParallelOptions
                {
                    MaxDegreeOfParallelism = 10,
                },
                    (i) =>
                    {
                        Stopwatch watch = new Stopwatch();
                        watch.Start();
                        Assert.IsTrue(MessagePublisher.SendMessageJson<string>(i, "zeetest3", null).IsSucceed);
                        watch.Stop();
                        System.Diagnostics.Debug.WriteLine(string.Format("Worker {0}, Elapsed: {1}", 0, watch.ElapsedMilliseconds));
                    });
            }
        }

        [TestMethod]
        public void MQ_PublishMsg_Test31()
        {
            using (StreamReader sr = new StreamReader("IMMessageBody.txt"))
            {
                string body = sr.ReadToEnd();
                List<int> data = new List<int>();
                for (int i = 0; i < 5; i++)
                {
                    //MessagePublisher.SendMessageJson<int>(i, "zeetest3", null);
                    Stopwatch watch = new Stopwatch();
                    watch.Start();
                    var result = MessagePublisher.SendMessageJson<string>(body, "zeetest3", null);
                    watch.Stop();
                    System.Diagnostics.Debug.WriteLine(string.Format("Worker {0}, Elapsed: {1}", i, watch.ElapsedMilliseconds));
                }


            }
        }

        [TestMethod]
        public void MQ_PublishMsg_Test4()
        {
            for (int i = 1; i < 10; i++)
            {
                var result = MessagePublisher.SendMessageJson(i, "zeetest3", "123456", null, "http://www.google.com");
                bool isok = result.IsSucceed;
            }
        }

        [TestMethod]
        public void MQ_PublishMsg_Test4_ForGQC()
        {
            for (int i = 1; i < 10; i++)
            {
                MailRequest request = new MailRequest();
                request.Subject = "Mail Send From Message Queue " + i.ToString();
                request.From = "zeeman.z.huang@newegg.com";
                request.To = "zeeman.z.huang@newegg.com";
                //request.CC = "james.y.yang@newegg.com";
                request.Body = "test body " + i.ToString();
                request.ContentType = MailContentType.Html;
                request.IsNeedLog = false;
                request.Priority = MailPriority.Low;
                request.MailType = MailType.Smtp;
                request.SmtpSetting = new SmtpSetting
                {
                    BodyEncoding = MailEncoding.UTF8,
                    SubjectEncoding = MailEncoding.UTF8,
                };

                var result = MessagePublisher.SendMessageJson(request, "zeetest2", "123456", null, "http://www.google.com");
                bool isok = result.IsSucceed;
            }
        }

        [TestMethod]
        public void MQ_PublishMsg_Test6()
        {
            for (int i = 1; i < 2; i++)
            {
                MailRequest request = new MailRequest();
                request.Subject = "Mail Send From Message Queue " + i.ToString();
                request.From = "zeeman.z.huang@newegg.com";
                request.To = "zeeman.z.huang@newegg.com";
                //request.CC = "james.y.yang@newegg.com";
                request.Body = "test body " + i.ToString();
                request.ContentType = MailContentType.Html;
                request.IsNeedLog = false;
                request.Priority = MailPriority.Low;
                request.MailType = MailType.Smtp;
                request.SmtpSetting = new SmtpSetting
                {
                    BodyEncoding = MailEncoding.UTF8,
                    SubjectEncoding = MailEncoding.UTF8,
                };

                var headers = new Dictionary<string, string>();
                //headers.Add("MailCategory", "Invoice");
                //headers.Add("MailType", "HTML");
                //headers.Add("MailCategory", "Invoice2");

                var result = MessagePublisher.SendMessageJson<MailRequest>(request, "zeetest2",
                    string.Empty, null, "http://www.google.com");
                bool isok = result.IsSucceed;
            }
        }

        [TestMethod]
        public void MQ_PublishMsg_Test5()
        {
            using (StreamReader sr = new StreamReader("IMMessageBody.txt"))
            {
                string body = sr.ReadToEnd();
                var result = MessagePublisher.SendMessageJson<string>(body, "IMMessage", null);
            }
        }
    }

    public class TestMessageInfo
    {
        public string Name { get; set; }

        public string Department { get; set; }
    }
}
