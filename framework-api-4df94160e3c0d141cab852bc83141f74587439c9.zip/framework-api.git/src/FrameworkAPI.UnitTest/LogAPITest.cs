﻿using System;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.API.Client;
using Newegg.Framework.Tools.Log;
using Newegg.FrameworkAPI.SDK.Log;

namespace FrameworkAPI.UnitTest
{
    [TestClass]
    public class LogAPITest
    {
        [TestMethod]
        public void Log_WriteLogMaiImmediately_Test()
        {
            var logEntry = GetTestLogEntry();
            LogHelper.WriteLog(logEntry);
            Assert.IsNotNull(logEntry.ID);
        }

        [TestMethod]
        public void Log_WriteLogWithMailInterval_Test()
        {
            var logEntry = GetTestLogEntryWithMail();
            LogHelper.WriteLog(logEntry);
            Assert.IsNotNull(logEntry.ID);
        }

        [TestMethod]
        public void Log_WriteLogWithFrameworkTools_Test()
        {
            var id = Logger.WriteLog("Test Log", "ExceptionLog");
            Assert.IsNotNull(id);
        }

        private LogEntry GetTestLogEntry()
        {
            LogEntry log = new LogEntry
            {
                CategoryName = "TestLog",
                LogType = "I",
                Content = "Test Log by James.Y.Yang",
                LogUserName = "jy25",
                ExtendedProperties = new System.Collections.Generic.List<ExtendProperty>
                {
                    new ExtendProperty
                    {
                        Key = "test key",
                        Value = "test value",
                    }
                },

            };

            return log;
        }

        private LogEntry GetTestLogEntryWithMail()
        {
            LogEntry log = new LogEntry
            {
                CategoryName = "test again",
                LogType = "I",
                Content = "Test Log",
                LogUserName = "jy25",
                ExtendedProperties = new System.Collections.Generic.List<ExtendProperty>
                {
                    new ExtendProperty
                    {
                        Key = "test key",
                        Value = "test value",
                    }
                },

            };

            return log;
        }
    }
}
