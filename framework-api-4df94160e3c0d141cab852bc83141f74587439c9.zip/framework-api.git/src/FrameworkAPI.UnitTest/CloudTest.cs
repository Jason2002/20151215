﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Framework.Tools.String;
using Newegg.FrameworkAPI.SDK.CloudData;

namespace FrameworkAPI.UnitTest
{
    public class SOMaster
    {
        public int SONumber { get; set; }
        public int CustomerNumber { get; set; }
        public DateTime SODate { get; set; }
        public decimal SOAmount { get; set; }
        public string CustomerPONumber { get; set; }
        public string Status { get; set; }
        public string Type { get; set; }
        public string ShipViaCode { get; set; }
        public string PayTermsCode { get; set; }
        public string Payterms { get; set; }
        public int? RMANumber { get; set; }
        public int? InvoiceNumber { get; set; }
    }

    public class ARCash
    {
        public int PayNumber { get; set; }
        public int? SONumber { get; set; }
        public int CustomerNumber { get; set; }
        public decimal PaidAmount { get; set; }
        public DateTime? PaidDate { get; set; }
        public string ReferenceNumber { get; set; }
        public string PayTermsCode { get; set; }
        public string PayTerms { get; set; }
        public string Bank { get; set; }
        public int? InvoiceNumber { get; set; }
        public string ArType { get; set; }
    }

    [TestClass]
    public class CloudTest
    {
        private string m_db = "pizza_store";
        private string m_schema = "pizzas";
        private int m_id = 290500961;


        [TestMethod]
        public void QueryByIdTest()
        {
            var result = CloudDataHelper.QueryById<ARCash>(m_db, m_schema, m_id.ToString(), "abcabc");
            Assert.IsNull(result);
        }

        [TestMethod]
        public void UpdateData()
        {
            var result = CloudDataHelper.QueryById<SOMaster>(m_db, m_schema, m_id.ToString());
            result.SOAmount = 9527;
            result.CustomerPONumber = "JamesModify";
            CloudDataHelper.Save<SOMaster>(m_db, m_schema, result);
            Thread.Sleep(1000);
            result = CloudDataHelper.QueryById<SOMaster>(m_db, m_schema, m_id.ToString());
            Assert.AreEqual(9527, result.SOAmount);
        }

        [TestMethod]
        public void RemoveData()
        {
            CloudDataHelper.Remove(m_db, m_schema, m_id.ToString());
            
            Thread.Sleep(1000);
            var result = CloudDataHelper.QueryById<SOMaster>(m_db, m_schema, m_id.ToString());
            Assert.IsNull(result);
        }

        [TestMethod]
        public void BatchSave()
        {
            Random random = new Random();
            
            var pizzas = new List<Pizza>();
            for (int i = 1; i <= 100; i++)
            {
                var pizza = new Pizza
                {
                    Category = "Category" + i%3,
                    Description = "This is pizza for batch update test",
                    Id = 100 + i,
                    Name = "Pizza " + i,
                    Price = Decimal.Round(Convert.ToDecimal(random.NextDouble() * 10), 2)
                };
                pizzas.Add(pizza);
            }
            CloudDataHelper.BatchUpdate(m_db, m_schema, pizzas);
        }

        [TestMethod]
        public void ComplicatedQuery()
        {
            
            QueryCondition qc = new QueryCondition();
            qc.FieldConditions.Add(QueryConditionBuilder.BuildCondition(
                QueryOperator.Between,
                "Id",
                100, 120));
            qc.FieldConditions.Add(QueryConditionBuilder.BuildOrCondition(
                QueryOperator.Equal, 
                "Category",
                "Category1"));
            qc.FieldConditions.Add(QueryConditionBuilder.BuildOrCondition(
                QueryOperator.GreaterEqual,
                "Price",
                8));
           
            var results = CloudDataHelper.Query<SOMaster>(m_db, m_schema, qc);
            Assert.AreEqual(9, results.total_rows);
        }
    }

    public class Pizza
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
    }
}
