﻿using System;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.API.Client;
using Newegg.FrameworkAPI.SDK;
using Newegg.FrameworkAPI.SDK.GlobalConfig;

namespace FrameworkAPI.UnitTest
{
    [TestClass]
    public class ConfigAPITest
    {

        [TestMethod]
        public void Config_GetSpecialConfig_Test()
        {
            var response = GlobalConfigHelper.GetConfig("NeweggAccounting", "APIAddress");
            Assert.IsNotNull(response);
            Assert.AreEqual("http://10.16.76.250:999/finance/v1.0", response.Value);
        }

        [TestMethod]
        public void Config_Test()
        {
            var client = new RestAPIClient(SdkConfig.Instance.FrameworkAPIAddress);
            var request = new GlobalConfiguration
            {
                Domain = "BTS",
                Key = "Lon456",
                Value = "test value",
                InUser = "ly61",
                InDate = DateTime.Now
            };
            client.Post<GlobalConfiguration>("/global-configuration", request);
            
            var response = client.Get<GlobalConfiguration>("/global-configuration", request);
            Assert.AreEqual(request.Value, response.Value);
            request.Value = "modify value";
            request.EditUser = "ly61";
            request.EditDate = DateTime.Now;

            client.Put<GlobalConfiguration>("/global-configuration", request);
            response = client.Get<GlobalConfiguration>("/global-configuration", request);
            Assert.AreEqual(request.Value, response.Value);

            client.Delete<GlobalConfiguration>("/global-configuration", request);
            response = client.Get<GlobalConfiguration>("/global-configuration", request);
            Assert.AreEqual(response, null);
        }
    }
}
