﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.FrameworkAPI.SDK.Keystone;
using ServiceStack.Text;

namespace FrameworkAPI.UnitTest
{
    [TestClass]
    public class TestKeystone
    {
        [TestMethod]
        public void HasKeystoneFunctions()
        {
            //var appId = "dfbc65d8-9205-4336-9521-647f450d8b43"; //GDEV
            //var appId = "86a83137-81dc-4fa3-98de-73d49e75b06a"; //GQC
            //var appId = "abe75810-3cd1-454e-adf6-0f7662c9427c"; //PRD



            var appId = "abe75810-3cd1-454e-adf6-0f7662c9427c";
            var functions = new List<string>
            {
                "CP_AuthKey_ApplicationConfig",
                "CR_AuthKey_ReasonNotification",
                "No_Exists"
            };
            var result = KeystoneHelper.HasFunctions("jy25", appId, functions);

            Assert.AreEqual(result.Count, 3);
            Assert.AreEqual(result[0].Result, true);
            Assert.AreEqual(result[1].Result, false);
            Assert.AreEqual(result[2].Result, false);
        }

        [TestMethod]
        public void GetAuthRoleAttribute()
        {
            var appIds = new List<string>();
            appIds.Add("1f173cfc-82e0-4f53-8792-e7ed46c6424f");

            var result = KeystoneHelper.GetAuthRoleAttributes(null, "NESO_Role_CreditRequestLimit", appIds);

            Assert.AreEqual(result.Count, 99);
            Assert.AreEqual(result[0].RoleName, "NESO_Role_CreditRequestLimit");
            Assert.AreEqual(result[0].Type, "CreditRequestLimit");
            Assert.AreEqual(result[1].Name, "500");
        }

        [TestMethod]
        public void GetUsersByFunction()
        {
            var appId = "1DDD87BA-BEDA-4D9B-ADFC-ADB785DCDD91";
            var funcName = "MENU_Sales Order Info_Hold Sales Order";

            var result = KeystoneHelper.GetUsersByFunction(funcName, appId);
            Assert.AreEqual(39, result.Count);
            Assert.AreEqual("az26", result[2].UserId);
        }
    }
}
