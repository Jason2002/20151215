﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.FrameworkAPI.SDK.Profile;

namespace FrameworkAPI.UnitTest
{
    [TestClass]
    public class ProfileTest
    {
        [TestMethod]
        public void SetProfile()
        {
            UserProfile up = new UserProfile();
            up.SystemName = "TestSystem";
            up.UserId = "jy25";
            ProfileContent pc2 = new ProfileContent();
            pc2.Key = "TestKey2";
            pc2.Value = "TestValue2";
            ProfileContent pc3 = new ProfileContent();
            pc3.Key = "TestKey3";
            pc3.Value = "TestValue3";
            up.Profiles = new List<ProfileContent> { pc2, pc3 };
            ProfileHelper.SetProfiles(up);
        }

        [TestMethod]
        public void GetProfile()
        {
            var result = ProfileHelper.GetProfiles("TestSystem", "jy25");

            Assert.AreEqual(result.Profiles.Count, 2);
            Assert.AreEqual(result.Profiles[0].Value, "TestValue2");
        }

        [TestMethod]
        public void BatchGetProfile()
        {
            var query = new BatchProfile {BatchQuery = new List<BatchQueryCondition>()};
            query.BatchQuery.Add(
                new BatchQueryCondition
                {
                    SystemName = "newegg-central",
                    UserId = "jy25",
                    Key = "FM.GridSettings"
                }
                );
            query.BatchQuery.Add(
                new BatchQueryCondition
                {
                    SystemName = "newegg-central",
                    UserId = "zh61",
                }
                );
            var result = ProfileHelper.BatchGetProfile(query);

            Assert.AreEqual(result.Count, 2);
            Assert.AreEqual(result[0].Profiles.Count, 1);
            Assert.AreEqual(result[1].Profiles.Count, 6);
        }

        [TestMethod]
        public void DeleteProfile()
        {
            //ProfileHelper.DeleteProfile("TestSystem", "jy25", "TestKey2");
            ProfileHelper.DeleteProfiles("TestSystem", "jy25");
           
        }
    }
}
