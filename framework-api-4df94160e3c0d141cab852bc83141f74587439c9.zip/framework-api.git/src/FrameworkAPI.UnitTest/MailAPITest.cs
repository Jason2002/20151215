﻿using System;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.API.Client;
using Newegg.FrameworkAPI.SDK.Mail;

namespace FrameworkAPI.UnitTest
{
    [TestClass]
    public class MailAPITest
    {
        [TestMethod]
        public void Mail_SendSmtp_Test()
        {
            MailRequest request = new MailRequest();
            request.Subject = "Mail Unit Test";
            request.From = "neuscsexitsurvey@newegg.com";
            request.To = "james.yang516@gmail.com";
            request.CC = "jy25";//ef85
            request.Body = @"<html><img src='http://www.google.com/images/srpr/logo4w.png'></html>";
            request.ContentType = MailContentType.Html;
            request.IsNeedLog = false;
            request.Priority = MailPriority.Low;
            request.MailType = MailType.Smtp;
            request.SmtpSetting = new SmtpSetting
            {
                BodyEncoding = MailEncoding.UTF8,
                SubjectEncoding = MailEncoding.UTF8,
            };
            var response = MailSender.Send(request);
            System.Diagnostics.Debug.WriteLine(ServiceStack.Text.JsonSerializer.SerializeToString<MailRequest>(request));
            Assert.IsNotNull(response);
            Assert.AreEqual(true, response.IsSendSuccess);
        }

        [TestMethod]
        public void Mail_SendSmtp_Test2()
        {
            MailRequest request = new MailRequest();
            request.Subject = "Mail Unit Test 7";
            request.From = "zeeman.z.huang@newegg.com";
            request.To = "Kevin.Q.Fu@newegg.com;zeeman.z.huang@newegg.com";
            request.Body = @"test";
            request.ContentType = MailContentType.Html;
            request.IsNeedLog = false;
            request.Priority = MailPriority.Low;
            request.MailType = MailType.Smtp;
            request.SmtpSetting = new SmtpSetting
            {
                BodyEncoding = MailEncoding.UTF8,
                SubjectEncoding = MailEncoding.UTF8,
            };
            var response = MailSender.Send(request);
            System.Diagnostics.Debug.WriteLine(ServiceStack.Text.JsonSerializer.SerializeToString<MailRequest>(request));
            Assert.IsNotNull(response);
            Assert.AreEqual(true, response.IsSendSuccess);
        }

        [TestMethod]
        public void Mail_SendSmtp_Test3()
        {
            MailRequest request = new MailRequest();
            request.Subject = "Mail Unit Test - send by group name - prd";
            request.From = "Lon.L.Yang@newegg.com";
            request.To = "Lon.L.Yang@newegg.com";
            request.CC = "";
            //request.CC = "zh61;jy25";
            request.Body = @"Mail Unit Test - send by group name";
            request.ContentType = MailContentType.Text;
            request.IsNeedLog = false;
            request.Priority = MailPriority.Low;
            request.MailType = MailType.Smtp;
            request.SmtpSetting = new SmtpSetting
            {
                BodyEncoding = MailEncoding.UTF8,
                SubjectEncoding = MailEncoding.UTF8,
            };
            var response = MailSender.Send(request);
            System.Diagnostics.Debug.WriteLine(ServiceStack.Text.JsonSerializer.SerializeToString<MailRequest>(request));
            Assert.IsNotNull(response);
            Assert.AreEqual(true, response.IsSendSuccess);
        }

        [TestMethod]
        public void Mail_SendLondonII_Test()
        {
            MailRequest request = new MailRequest();
            request.Subject = "Mail Unit Test";
            request.From = "Lon.L.Yang@newegg.com";
            request.To = "Lon.L.Yang@newegg.com";
            request.Body = "Test mail sent by framework API unit test";
            request.ContentType = MailContentType.Html;
            request.IsNeedLog = true;
            request.Priority = MailPriority.Low;
            request.MailType = MailType.LondongII;
            request.LondonIISetting = new LondonIISetting
            {
                CompanyCode = "1003",
                CountryCode = "USA",
                LanguageCode = "en-US",
                SystemID = "EGG0601003",
            };

            var response = MailSender.Send(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.MailLogUri);
            Assert.AreEqual(true, response.IsSendSuccess);
        }

        [TestMethod]
        public void Mail_SendLondonIITemplate_Test()
        {
            MailRequest request = new MailRequest();
            request.Subject = "Mail Unit Test";
            request.From = "Lon.L.Yang@newegg.com";
            request.To = "Lon.L.Yang@newegg.com";
            request.Body = "Test mail sent by framework API unit test";
            request.ContentType = MailContentType.Html;
            request.IsNeedLog = true;
            request.Priority = MailPriority.Low;
            request.MailType = MailType.LondongII;
            request.LondonIISetting = new LondonIISetting
            {
                CompanyCode = "1003",
                CountryCode = "USA",
                LanguageCode = "en-US",
                SystemID = "EGG0601003",
                TemplateID = "000375",
                MailTemplateVariables = new System.Collections.Generic.List<MailTemplateVariable>
                {
                    new MailTemplateVariable
                    {
                        Key = "#DV_SellerEmail#",
                        Value = "test",
                    },
                     new MailTemplateVariable
                    {
                        Key = "#DV_MarketplaceSellerName#",
                        Value = "test",
                    },
                     new MailTemplateVariable
                    {
                        Key = "#DV_MarketplaceSellerPreviousStatus#",
                        Value = "test",
                    },
                     new MailTemplateVariable
                    {
                        Key = "#DV_MarketplaceSellerCurrentStatus#",
                        Value = "test",
                    },
                },
            };

            var response = MailSender.Send(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.MailLogUri);
            Assert.AreEqual(true, response.IsSendSuccess);
        }
    }
}
