﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Framework.Tools.String;
using Newegg.FrameworkAPI.SDK.CloudData;

namespace FrameworkAPI.UnitTest
{
    public class Log
    {
        public int id { get; set; }
        public string Note { get; set; }
    }

    [TestClass]
    public class CloudTest2
    {
        private string m_store = "zee_wh7_e3";
        private string m_collection = "logs";
        private int m_id = 100;
        private string m_pwd = "123456";

        [TestMethod]
        public void InsertTest()
        {
            Log log = new Log()
            {
                id = m_id,
                Note = "test " + m_id.ToString()
            };
            CloudDataHelper.Insert(m_store, m_collection, log, m_pwd);
        }

        [TestMethod]
        public void UpdateTest()
        {
            Log log = new Log()
            {
                id = m_id,
                Note = "test update " + m_id.ToString()
            };
            CloudDataHelper.Update(m_store, m_collection, log, m_pwd);
        }

        [TestMethod]
        public void SaveTest()
        {
            Log log = new Log()
            {
                id = 101,
                Note = "test save2 101"
            };
            CloudDataHelper.Save(m_store, m_collection, log, m_pwd);
        }

        [TestMethod]
        public void QueryByIdTest()
        {
            var result = CloudDataHelper.QueryById<Log>(m_store, m_collection, m_id.ToString(), m_pwd);
            Assert.IsNull(result);
        }

        [TestMethod]
        public void RemoveTest()
        {
            CloudDataHelper.Remove(m_store, m_collection, m_id.ToString(), m_pwd);
            
            Thread.Sleep(1000);
            var result = CloudDataHelper.QueryById<Log>(m_store, m_collection, m_id.ToString(), m_pwd);
            Assert.IsNull(result);
        }

        public void ComplicatedQuery()
        {
            var qc = new QueryCondition();
            qc.SetPage(1, 50);
            qc.FieldConditions.Add(QueryConditionBuilder.BuildCondition(
                QueryOperator.Between,
                "id",
                100002, 100004));
            qc.ReturnFields = new List<string>
            {
                "id",
                "Note"
            };

            qc.Sort = new SortDescription
            {
                SortField = "id",
                Direction = SortDirection.desc,
            };


            var results = CloudDataHelper.Query<Log>(m_store, m_collection, qc);
        }
    }
}
