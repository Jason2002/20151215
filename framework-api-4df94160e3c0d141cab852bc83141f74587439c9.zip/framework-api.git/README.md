Newegg Framework API
====
在项目开发中，有一些基础服务组件是经常用到的，比如Config、Log。为避免重复造轮子运动，我们将这些组件抽象成公共API，即Framework API。

Config
----
Config API继承和发扬了Newegg Central Global Configuration精髓, 主要信息包括Domain, Key, Value。维护页面延用Newegg Central Control Panel, 配置读取可通过API进行，从而在任意项目中使用。

Keystone
----
目前主要提供给Newkit.js使用，参考[Newkit.js authorize service](http://developer.newegg.org/documentation/newkitjs-developer-guide/service-authorize)

Log
----
Log是每个系统必不可少的部分，Log API写入时采用异步处理，查询操作在Newegg Central Control Panel中进行。

Mail
----
使用邮件的场景很多，比如客户往来、系统预警等。目前Mail API支持SMTP和LondonII两种类型。

Message Publish
----
Message Queue是系统解耦的利器，先天异步化，消除前端访问洪峰，避免后端系统受到剧烈冲击。其重要性得到广泛认可，成为电子商务系统中不可或缺的部分，Newegg Backend基于Apache ActiveMQ已经形成完善的企业消息服务。由ESB Team开发的Message Publish API用于发送消息到Queue中。

Profile
----
目前主要提供给Newkit.js使用，参考[Newkit.js user profile service](http://developer.newegg.org/documentation/newkitjs-developer-guide/service-user-profile)

Framework API SDK
----
基于.Net的项目可以在Nuget上下载SDK包，SDK中封装了相关API的调用，使用起来更方便。

Performance
----
Framework API的数据持久化采用MS SQL Server和Redis作Master/Salve搭配，SQL Server作为权威数据源，Redis提供优秀的读写性能。在PRD环境中，Framework API采取Load Balance部署，各节点之间同步数据只需3~5ms。

License
----
Copyright (c) 2014 Newegg inc. All Rights Reserved.

About us
----
我们是BTS（Backend Tech Support） team。  
欢迎访问我们的[Blog](http://10.16.75.10:8002/)与我们进行交流。

![BTS](http://neg-app-img/MISInternal/DocumentTool/20140304042540930_easyicon_net_128.1394693687.ico)