﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest
{
    public class ItemTest
    {
        public void GetPromotions()
        {

            CustomDataCommand dataCommand = null;
            dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetPromotions");

            using (var sb = new DynamicQuerySqlBuilder(dataCommand.CommandText, dataCommand, null, "RequestID"))
            {
                AddCommonCondition(sb);
                dataCommand.CommandText = sb.BuildQuerySql();
            }
            var result = dataCommand.ExecuteDataTable(); // dataCommand.ExecuteEntityList<Schedule>();
            int totalCount = Convert.ToInt32(dataCommand.GetParameterValue("@TotalCount"));
        }

        private void AddCommonCondition(DynamicQuerySqlBuilder sb)
        {

                //sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
                //    "A.Item",
                //    DbType.String,
                //    "@Item",
                //    QueryConditionOperatorType.Equal,
                //    "60-001-033");

            //sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
            //    "A.CompanyCode",
            //    DbType.Int32,
            //    "@CompanyCode",
            //    QueryConditionOperatorType.Equal,
            //    request.CompanyCode);

            //if (!string.IsNullOrEmpty(request.CountryCode))
            //{
            //    sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
            //         "A.CountryCode",
            //         DbType.StringFixedLength,
            //         "@CountryCode",
            //         QueryConditionOperatorType.Equal,
            //         request.CountryCode == null ? request.CountryCode : request.CountryCode.Trim());
            //}

            //sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
            //        "A.ActiveDate",
            //        DbType.StringFixedLength,
            //        "@EndDate",
            //        QueryConditionOperatorType.LessThanOrEqual,
            //        request.DateTo);

            //sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
            //        "A.Expiration",
            //        DbType.StringFixedLength,
            //        "@StartDate",
            //        QueryConditionOperatorType.MoreThanOrEqual,
            //        request.DateFrom);

            //sb.ConditionConstructor.AddInCondition(QueryConditionRelationType.AND,
            //         "A.Status",
            //         DbType.StringFixedLength,
            //         new List<string> { "", "A" });

            //sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
            //        "A.Type",
            //        DbType.AnsiStringFixedLength,
            //        "@Type",
            //        QueryConditionOperatorType.Equal,
            //        "promotion");

            //sb.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
            //       "A.ThirdPartySiteID",
            //       DbType.Int32,
            //       "@ThirdPartySiteID",
            //       QueryConditionOperatorType.IsNull,
            //       1);
        }
    }
}
