﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Oversea.DataAccess;
using IsolationLevel = System.Transactions.IsolationLevel;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class ListSupportTest
    {
        [TestMethod]
        public void GetList()
        {
            var cmd = DataCommandManager.GetDataCommand("TestListSupport");
            var result = cmd.ExecuteEntityList(new {ids = new int[] {1, 2, 3}});
        }
        
        [TestMethod]
        public void GetList2()
        {
            var cmd = DataCommandManager.GetDataCommand("TestListSupport");
            var p = new DynamicParameters();
            var ids = new int[] {1, 2, 3};
            p.Add("@ids", ids);
            var result = cmd.ExecuteEntityList(p);
        }

        [TestMethod]
        public void GetList3()
        {
            var cmd = DataCommandManager.GetDataCommand("TestListSupportByNchar");

            //nchar
            var ids = new DbString[]
            {
                new DbString(){IsAnsi = false,IsFixedLength = true,Length = 5,Value= "ALFKI"},
                new DbString(){IsAnsi = false,IsFixedLength = true,Length = 5,Value= "ANATR"},
            };

            var result = cmd.ExecuteEntityList(new { ids = ids });
        }

        [TestMethod]
        public void ExecuteList()
        {
            var list = new List<dynamic>();
            for (int i = 0; i < 1000; i++)
            {
                list.Add(new
                {
                    ItemNumber = "ItemNumber" + i.ToString(),
                    UnitPrice = i,
                    InUser = "User" + i.ToString()
                });
            }

            TransactionOptions to = new TransactionOptions();
            to.IsolationLevel = IsolationLevel.ReadCommitted;
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, to))
            {
                var cmd = DataCommandManager.GetDataCommand("BatchTestInsertByList");

                cmd.ExecuteNonQuery(list);

                scope.Complete();
            }
        }
    }
}


