﻿using System;
using DataAccess.UnitTest.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class ProductTest
    {
        [TestMethod]
        public void Product_GetAll_Test()
        {
            var productList = new ProductBiz().GetProducts();
            Assert.IsNotNull(productList);
            Assert.AreNotEqual(0, productList.Count);
        }

        [TestMethod]
        public void Product_GetByID_Test()
        {
            int id = 12;
            var productList = new ProductBiz().GetProducts(id);
            Assert.IsNotNull(productList);
            Assert.AreEqual(1, productList.Count);
            Assert.AreEqual(38.00, productList[0].UnitPrice);
        }

        [TestMethod]
        public void Product_GetProductHitCount_Test()
        {
            int id = 22;
            var productList = new ProductBiz().GetProductOrderHitCount(id);
            Assert.AreEqual(18, productList);
        }
    }
}
