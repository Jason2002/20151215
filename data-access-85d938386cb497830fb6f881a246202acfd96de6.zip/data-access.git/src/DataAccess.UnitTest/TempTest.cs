﻿using System;
using DataAccess.UnitTest.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Oversea.DataAccess;
using System.Collections.Generic;
using DataAccess.UnitTest.Models;
using ServiceStack.Text;

namespace DataAccess.UnitTest
{

    [TestClass]
    public class TempTest
    {
        public TempTest()
        {
            Func<object, dynamic> func = new Func<object, dynamic>(Get);
            DataCommandManager.RegisterMockFunction("GetOrderAmountWithPreDefineParameter", func);
        }
        
        [TestMethod]
        public void Temp_Test()
        {
            new Temp().Test();            
        }

        [TestMethod]
        public void Getnull()
        {
            new Temp().GetNULL();
        }

        [TestMethod]
        public void Getnull2()
        {
            var command = DataCommandManager.GetDataCommand("GetOrderAmountWithPreDefineParameter");
            var obj = command.ExecuteEntityList<CategoryEntity>();
            Console.WriteLine(obj.ToJson());
        }

        public object Get(dynamic param = null)
        {
            CategoryEntity entity = new CategoryEntity()
            {
                CategoryID = param.num1 + param.num2                
            };
            List<CategoryEntity> list = new List<CategoryEntity>();
            list.Add(entity);
            return list;
        }
    }
}
