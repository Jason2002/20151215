﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.UnitTest.Biz;
using DataAccess.UnitTest.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Oversea.DataAccess;
using Newegg.Oversea.DataAccess.RandomData;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class MockTest
    {
        [TestMethod]
        public void MockCustomer_GetByID_Test()
        {
            DataCommandManager.RegisterMockFunction("GetCustomerByCustomerID", MockCustomer);

            string id = "ERNSH";
            var customer = new CustomerBiz().GetCustomerByID_SQLParameter(id);

            Assert.IsNotNull(customer);
            Assert.AreEqual(id, customer.CustomerID);

            customer = new CustomerBiz().GetCustomerByID_DynamicParameter(id);

            Assert.IsNotNull(customer);
            Assert.AreEqual(id, customer.CustomerID);
        }

        public object MockCustomer(dynamic parameter)
        {
            string id = string.Empty;
            var para = parameter as DynamicParameters;
            if (para != null)
            {
                id = para.GetParameterValue("ID").ToString();
            }
            else
            {
                id = parameter.ID;
            }
            var entity = new Randomzer<CustomerEntity>().GetRandomElement();
            entity.CustomerID = id;
            return entity;
        }
    }
}
