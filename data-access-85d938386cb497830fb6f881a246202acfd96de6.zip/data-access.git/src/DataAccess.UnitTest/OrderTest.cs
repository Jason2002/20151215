﻿using System;
using DataAccess.UnitTest.Biz;
using DataAccess.UnitTest.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class OrderTest
    {
        [TestMethod]
        public void Order_GetAll_Test()
        {
            var orderList = new OrderBiz().GetAllOrders();
            Assert.IsNotNull(orderList);
            Assert.AreNotEqual(0, orderList.Count);
            Assert.IsNotNull(orderList[0].Customer);
        }

        [TestMethod]
        public void Order_GetByDateRange_Test()
        {
            DateTime fromDate = new DateTime(1990, 1, 1);
            DateTime toDate = new DateTime(2010, 1, 1);
            var orderList = new OrderBiz().QueryOrderWithDetailByOrderDate(fromDate, toDate);
            Assert.IsNotNull(orderList);
            Assert.AreNotEqual(0, orderList.Count);
            Assert.IsNotNull(orderList[0].Customer);
            Assert.IsNotNull(orderList[0].OrderDetail);
        }

        [TestMethod]
        public void Order_GetOrderAndDetail_Test()
        {
            OrderEntity order = null;
            List<OrderDetailEntity> detail = null;
            //for (int i = 0; i < 20; i++)
            //{
                new OrderBiz().GetOrderAndDetail(10249, out order, out detail);
            //}
            Assert.IsNotNull(order);
            Assert.IsNotNull(detail);
            Assert.AreNotEqual(0, detail.Count);
        }

        [TestMethod]
        public void Order_GetOrderAmount_Test()
        {
            var amount = new OrderBiz().GetOrderAmount(513);
            Assert.AreEqual(627.4038M, amount);
        }

        [TestMethod]
        public void Order_GetOrderAmountWithPredefinePramater_Test()
        {
            var amount = new OrderBiz().GetOrderAmountWithPreDefineParameter(513);
            Assert.AreEqual(627.4038M, amount);
        }

        [TestMethod]
        public void Order_CreateNewOrderWithDetail_Test()
        {
            var product = new ProductBiz().GetProducts(22).First();
            var customer = new CustomerBiz().GetCustomerByID("BERGS");
            var order = new OrderEntity
            {
                CustomerID = customer.CustomerID,
                EmployeeID = 5,
                Freight = 99.99,
                OrderDate = DateTime.Now.AddDays(-1),
                RequiredDate = DateTime.Now.AddDays(1),
                ShipAddress = "Unit Test Address",
                ShipCity = "ChengDu",
                ShipCountry = "China",
                ShipName = "TianFu",
                ShippedDate = DateTime.Now,
                ShipPostalCode = "610041",
                ShipVia = 3,
            };

            List<OrderDetailEntity> details = new List<OrderDetailEntity>();
            details.Add(new OrderDetailEntity
            {
                Discount = 0.25,
                ProductID = product.ProductID,
                Quantity = 2,
                UnitPrice = product.UnitPrice,
            });

            int id = new OrderBiz().CreateNewOrder(order, details);

            OrderEntity resultOrder;
            List<OrderDetailEntity> resultDetail;
            new OrderBiz().GetOrderAndDetail(id, out resultOrder, out resultDetail);
            Assert.IsNotNull(resultOrder);
            Assert.AreEqual("ChengDu", resultOrder.ShipCity);
            Assert.IsNotNull(resultDetail);
            Assert.AreEqual(1, resultDetail.Count);
        }

        [TestMethod]
        public void Order_CreateMultipleNewOrders_Test()
        {
            List<OrderEntity> orders = new List<OrderEntity>();
            var product = new ProductBiz().GetProducts(22).First();
            var customer = new CustomerBiz().GetCustomerByID("BERGS");
            var order = new OrderEntity
            {
                CustomerID = customer.CustomerID,
                EmployeeID = 5,
                Freight = 99.99,
                OrderDate = DateTime.Now.AddDays(-1),
                RequiredDate = DateTime.Now.AddDays(1),
                ShipAddress = "Unit Test Address",
                ShipCity = "ChengDu",
                ShipCountry = "China",
                ShipName = "TianFu",
                ShippedDate = DateTime.Now,
                ShipPostalCode = "610041",
                ShipVia = 3,
            };

            orders.Add(order);

            var order2 = new OrderEntity
            {
                CustomerID = customer.CustomerID,
                EmployeeID = 5,
                Freight = 99.99,
                OrderDate = DateTime.Now.AddDays(-1),
                RequiredDate = DateTime.Now.AddDays(1),
                ShipAddress = "Unit Test Address",
                ShipCity = "ChengDu",
                ShipCountry = "China",
                ShipName = "TianFu",
                ShippedDate = DateTime.Now,
                ShipPostalCode = "610041",
                ShipVia = 3,
            };

            orders.Add(order2);

            int createdCount = new OrderBiz().CreateMultipleNewOrder(orders);
            Assert.AreEqual(2, createdCount);
        }

        [TestMethod]
        public void Order_GetOrderByDynamicQuerySqlBuilder() 
        {
            var result = new OrderBiz().GetOrderByDynamicQuerySqlBuilder(null, "SUPRD", null, new PagingInfoEntity()
            {
                MaximumRows = 30,
                SortField = "OrderDate",
                StartRowIndex = 1,
            });
            Assert.IsNotNull(result);
            Assert.AreEqual(42, result.Count);
            Console.WriteLine(result.Count);
        }

        [TestMethod]
        public void GetOrdersByDate()
        {
            CustomDataCommand dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetOrdersByDate");

            using (DynamicQuerySqlBuilder sqlBuilder = new DynamicQuerySqlBuilder(
               dataCommand.CommandText, dataCommand, new PagingInfoEntity(), "CustomerID ASC,OrderDate DESC"))
            {
                sqlBuilder.ConditionConstructor.AddCustomCondition(QueryConditionRelationType.AND,
                    "OrderDate>@OrderDate");
                dataCommand.AddInputParameter("OrderDate", System.Data.DbType.DateTime);
                dataCommand.SetParameterValue("OrderDate", new DateTime(2009,7,30));

                //查询数据
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();

                var result = dataCommand.ExecuteEntityList<OrderEntity>();
                Assert.IsNotNull(result);
                Assert.AreEqual(73, result.Count);
            }

        }

        [TestMethod]
        public void GetOrdersByDate2()
        {
            CustomDataCommand dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetOrdersByDate2");

            using (DynamicQuerySqlBuilder sqlBuilder = new DynamicQuerySqlBuilder(
               dataCommand.CommandText, dataCommand, new PagingInfoEntity(), "OrderDate"))
            {
                dataCommand.SetParameterValue("@OrderDate", new DateTime(2009, 7, 30));

                //查询数据
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();

                var result = dataCommand.ExecuteEntityList<OrderEntity>();
                Assert.IsNotNull(result);
                Assert.AreEqual(73, result.Count);
            }

        }
    }
}
