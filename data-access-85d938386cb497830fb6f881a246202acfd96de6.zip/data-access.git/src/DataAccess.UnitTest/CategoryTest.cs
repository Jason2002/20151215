﻿using System;
using DataAccess.UnitTest.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class CategoryTest
    {
        [TestMethod]
        public void Category_GetByName_Test()
        {
            var results = new CategoryBiz().GetCategoryByName("Char");
            Assert.AreEqual(5, results.Count);
        }
    }
}
