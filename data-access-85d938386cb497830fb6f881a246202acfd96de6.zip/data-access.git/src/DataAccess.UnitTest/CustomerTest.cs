﻿using System;
using DataAccess.UnitTest.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        public void Customer_GetAll_Test()
        {
            var customerList = new CustomerBiz().GetAllCustomers();
            Assert.IsNotNull(customerList);
            //Assert.AreNotEqual(0, customerList.Count);

            //customerList = new CustomerBiz().GetAllCustomers2();
            //Assert.IsNotNull(customerList);
            //Assert.AreNotEqual(0, customerList.Count);

            //customerList = new CustomerBiz().GetAllCustomers();
            //Assert.IsNotNull(customerList);
            //Assert.AreNotEqual(0, customerList.Count);
        }

        [TestMethod]
        public void Customer_GetByID_Test()
        {
            string id = "ERNSH";
            var customer = new CustomerBiz().GetCustomerByID(id);
            Assert.IsNotNull(customer);
            Assert.AreEqual("Ernst Handel", customer.CompanyName);
        }
    }
}
