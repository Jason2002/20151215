﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class BatchTest
    {
        [TestMethod]
        public void Insert_Test()
        {
            List<BatchTestInfo> list = new List<BatchTestInfo>();

            for (int i = 0; i < 10; i++)
            {
                list.Add(new BatchTestInfo()
                {
                    Id = i,
                    Id2 = i * 10,
                    Name = i.ToString()
                });
            }

            var dataCommand = DataCommandManager.GetDataCommand("BatchTestInsert");
            dataCommand.ExecuteNonQuery(list);
        }

        [TestMethod]
        public void Delete_Test()
        {
            List<BatchTestInfo> list = new List<BatchTestInfo>();

            for (int i = 0; i < 10; i++)
            {
                list.Add(new BatchTestInfo()
                {
                    Id = i,
                    Id2 = i * 10,
                    Name = i.ToString()
                });
            }

            var dataCommand = DataCommandManager.GetDataCommand("BatchTestDelete");
            dataCommand.ExecuteNonQuery(list);
        }

        [TestMethod]
        public void BulkCopyWithTable()
        {
            var table = new DataTable();
            table.Columns.Add("Id");
            table.Columns.Add("Id2");
            table.Columns.Add("Name");
            for (int i = 0; i < 100000; i++)
            {
                var row = table.NewRow();
                row["Id"] = i;
                row["Id2"] = i + 1;
                row["Name"] = "test" + i;
                table.Rows.Add(row);
            }
            var cmd = DataCommandManager.CreateCustomDataCommand("Local");
            cmd.ExecuteBulkCopy("BatchTest", table);
        }

        [TestMethod]
        public void BulkCopyWithList()
        {
            var list = new List<BatchTestInfo>();
            for (int i = 0; i < 100000; i++)
            {
                var temp = new BatchTestInfo
                {
                    Id = i,
                    Id2 = i + 1,
                    Name = "test" + i
                };
                list.Add(temp);
            }
            var cmd = DataCommandManager.CreateCustomDataCommand("Local");
            cmd.ExecuteBulkCopy("BatchTest", list);
        }

        public class BatchTestInfo
        {
            public int Id { get; set; }
            public int Id2 { get; set; }
            public string Name { get; set; }

            public void Test()
            {
                Console.WriteLine("test");
            }
        }
    }
}
