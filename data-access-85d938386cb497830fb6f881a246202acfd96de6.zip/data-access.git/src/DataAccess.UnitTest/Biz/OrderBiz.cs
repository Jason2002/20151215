﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Transactions;
using DataAccess.UnitTest.Models;
using Newegg.Oversea.DataAccess;
using ServiceStack.Text;

namespace DataAccess.UnitTest.Biz
{
    public class OrderBiz
    {
        public List<OrderEntity> GetAllOrders()
        {
            var command = DataCommandManager.GetDataCommand("GetAllOrdersWithCustomer");

            var test = command.ExecuteEntityList();
            var json = test.ToJson();

            return command.ExecuteEntityList<OrderEntity, CustomerEntity, OrderEntity>(
                (order, customer) =>
                {
                    order.Customer = customer;
                    return order;
                },
                null, "CustomerID");
        }

        public List<OrderEntity> GetOrderByDynamicQuerySqlBuilder(int? id = null, string customerID = null, DateTime? OrderDate = null, PagingInfoEntity pagingEntity = null) 
        {
            var obj = new List<object>();
            obj.Add("SUPRD");
            obj.Add("MORGK");
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetOrderByDynamicQuerySqlBuilder2");            
            List<OrderEntity> result = new List<OrderEntity>();
            using (DynamicQuerySqlBuilder builder = new DynamicQuerySqlBuilder(command.CommandText, command, pagingEntity, "OrderID"))
            {
                if (id != null)
                {
                    builder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "OrderID", 
                        DbType.Int32, "@OrderID", QueryConditionOperatorType.Equal, id.Value);
                }
                if (customerID != null && customerID.Trim().Length > 0)
                {
                    builder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "CustomerID",
                        DbType.String, "@CustomerID", QueryConditionOperatorType.In, obj, 5);
                }
                if (OrderDate != null)
                {
                    builder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "OrderDate", 
                        DbType.DateTime, "@OrderDate", QueryConditionOperatorType.MoreThanOrEqual, OrderDate.Value);
                }
                command.CommandText = builder.BuildQuerySql();
                result = command.ExecuteEntityList<OrderEntity>();
            }
            return result;
        }

        //使用动态参数
        //指定实体映射关系返回
        public List<OrderEntity> QueryOrderWithDetailByOrderDate(DateTime fromDate, DateTime toDate)
        {
            var command = DataCommandManager.GetDataCommand("GetOrdersByOrderDateWithOrderDetail");
            return command.ExecuteEntityList<OrderEntity, OrderDetailEntity, CustomerEntity, OrderEntity>(
                (order, detail, customer) =>
                {
                    order.OrderDetail = detail;
                    order.Customer = customer;
                    return order;
                },
                    new { From = fromDate, To = toDate },
                    "OrderID,CustomerID"
                    );
        }

        //返回多个结果集
        public void GetOrderAndDetail(int orderID, out OrderEntity order, out List<OrderDetailEntity> detail)
        {
            var command = DataCommandManager.GetDataCommand("GetOrderAndDetailByOrderID");
            order = null;
            detail = null;
            using (GridReader reader = command.ExecuteMultiple(new { ID = orderID }))
            {
                var orders = reader.Read<OrderEntity>();
                var details = reader.Read<OrderDetailEntity>();
                if (orders.Count() > 0)
                {
                    order = orders.First();
                }
                if (details.Count() > 0)
                {
                    detail = details.ToList();
                }
            }
        }

        //使用实体作为参数
        public int CreateNewOrder(OrderEntity order, List<OrderDetailEntity> details)
        {
            using (TransactionScope ts = new TransactionScope())
            {
                var command = DataCommandManager.GetDataCommand("InsertOrder");
                int orderId = command.ExecuteScalar<int>(order);

                details.ForEach(d => d.OrderID = orderId);
                details.ForEach(d =>
                    {
                        var detailCommand = DataCommandManager.GetDataCommand("InsertOrderDetail");
                        detailCommand.ExecuteNonQuery(d);
                    });

                ts.Complete();

                return orderId;
            }
        }

        //使用实体作为参数，同一条语句执行多次
        public int CreateMultipleNewOrder(List<OrderEntity> orders)
        {
            using (TransactionScope ts = new TransactionScope())
            {
                var command = DataCommandManager.GetDataCommand("InsertOrder");
                int createdCount = command.ExecuteNonQuery(orders);

                ts.Complete();

                return createdCount;
            }
        }


        public decimal GetOrderAmount(int orderID)
        {
            var command = DataCommandManager.GetDataCommand("GetOrderAmount");
            var p = new DynamicParameters();
            p.Add("@OrderID", orderID);
            p.Add("@Amount", dbType: DbType.Decimal, direction: ParameterDirection.Output, size: 14, precision: 12, scale: 4);
            command.ExecuteNonQuery(p);

            var amount = p.Get<decimal>("@Amount");

            return amount;

        }

        public decimal GetOrderAmountWithPreDefineParameter(int orderID)
        {
            var command = DataCommandManager.GetDataCommand("GetOrderAmountWithPreDefineParameter");
            command.SetParameterValue("@OrderID", orderID);
            command.ExecuteNonQuery();

            var amount = command.GetParameterValue<decimal>("@Amount");

            return amount;

        }
    }
}
