﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.UnitTest.Models;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest.Biz
{
    public class CustomerBiz
    {
        public List<CustomerEntity> GetAllCustomers()
        {
            var command = DataCommandManager.GetDataCommand("GetAllCustomers");
            var results = command.ExecuteEntityList<dynamic>();

            return results.Select(r => new CustomerEntity
            {
                CustomerID = r.CustomerID,
                CharCustomerID = r.CharCustomerID,
                age = r.age
            }).ToList();
        }

        public List<CustomerEntity> GetAllCustomers2()
        {
            var command = DataCommandManager.GetDataCommand("GetAllCustomers", "Northwind2");
            return command.ExecuteEntityList<CustomerEntity>();
        }

        public CustomerEntity GetCustomerByID(string customerID)
        {
            var command = DataCommandManager.GetDataCommand("GetCustomerByCustomerID");
            command.SetParameterValue("@ID", customerID);
            return command.ExecuteEntity<CustomerEntity>();
        }

        public CustomerEntity GetCustomerByID_SQLParameter(string customerID)
        {
            var command = DataCommandManager.GetDataCommand("GetCustomerByCustomerID");
            command.SetParameterValue("@ID", customerID);
            return command.ExecuteEntity<CustomerEntity>();
        }

        public CustomerEntity GetCustomerByID_DynamicParameter(string customerID)
        {
            var command = DataCommandManager.GetDataCommand("GetCustomerByCustomerID");
            return command.ExecuteEntity<CustomerEntity>(new {ID = customerID});
        }
    }
}
