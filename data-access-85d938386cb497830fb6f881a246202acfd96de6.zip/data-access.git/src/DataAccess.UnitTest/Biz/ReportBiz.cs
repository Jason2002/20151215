﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest.Biz
{
    public class ReportBiz
    {
        public DataTable GetSalesReport(DateTime fromDate, DateTime toDate)
        {
            var command = DataCommandManager.GetDataCommand("GetSalesReport");
            return command.ExecuteDataTable(new { Beginning_Date = fromDate, Ending_Date = toDate });
        }

        public DataTable GetSalesReportCustomizeSql(DateTime fromDate, DateTime toDate)
        {
            var command = DataCommandManager.CreateCustomDataCommand("Northwind", CommandType.StoredProcedure);
            command.CommandText = "dbo.[Employee Sales by Country]";
            return command.ExecuteDataTable(new { Beginning_Date = fromDate, Ending_Date = toDate });
        }
    }
}
