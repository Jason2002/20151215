﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Oversea.DataAccess;
using DataAccess.UnitTest.Models;

namespace DataAccess.UnitTest.Biz
{
    public class Temp
    {        
        public void Test()
        {
            var datacommand = DataCommandManager.GetDataCommand("GetEggPointInfo2");
            decimal Length = 3;
            decimal Width = 2;
            decimal Height = 1;

            datacommand.SetParameterValue("Length",Length);
            datacommand.SetParameterValue("Width", Width);
            datacommand.SetParameterValue("Height", Height);

            var result = datacommand.ExecuteDataSet();
        }

        public void GetNULL()
        {
            var datacommand = DataCommandManager.GetDataCommand("ReturnNull");
            var result = datacommand.ExecuteEntityList();
        }

        public List<OrderEntity> GetNULL2()
        {
            var dataCommand = DataCommandManager.GetDataCommand("MultiMapping2");
            var obj = dataCommand.ExecuteEntityList<OrderEntity, OrderDetailEntity, CustomerEntity, ProductEntity, OrderEntity>(
                (order, detail,custom,product) =>
                {
                    order.OrderDetail = detail;
                    order.Customer = custom;
                    return order;
                },
                null,//new { From = DateTime.Parse("2013-02-05"), To = DateTime.Parse("2013-02-22") },
                "OrderID,CustomerID,ProductID"
                );
            return obj as List<OrderEntity>;
        }
    }
}
