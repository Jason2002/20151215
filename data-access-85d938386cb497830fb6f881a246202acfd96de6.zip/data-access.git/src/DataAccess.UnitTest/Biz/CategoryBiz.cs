﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.UnitTest.Models;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest.Biz
{
    public class CategoryBiz
    {
        public List<CategoryEntity> GetCategoryByName(string name)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetCategoryByName");
            command.CommandText += " where NewCharColumn like @Name";
            //return command.ExecuteEntityList<CategoryEntity>(
            //    new
            //    {
            //        Name = new DbString
            //        {
            //            Value = name,
            //            IsAnsi = true,
            //            IsFixedLength = false,
            //            Length = 100
            //        }
            //    });

            command.AddInputParameter("@Name", System.Data.DbType.AnsiString, name + "%");

            return command.ExecuteEntityList<CategoryEntity>();
        }
    }
}
