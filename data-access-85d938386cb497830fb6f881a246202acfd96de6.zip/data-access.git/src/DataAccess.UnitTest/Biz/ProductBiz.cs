﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.UnitTest.Models;
using Newegg.Oversea.DataAccess;

namespace DataAccess.UnitTest.Biz
{
    public class ProductBiz
    {
        public List<ProductEntity> GetProducts(int? id = null)
        {
            if (id.HasValue)
            {
                var command = DataCommandManager.CreateCustomDataCommandFromConfig("GetProductPrice");
                command.CommandText += " where ProductID = @ID";
                command.ReplaceParameterValue("@ID", id.Value);
                return command.ExecuteEntityList<ProductEntity>();
            }
            else
            {
                var command = DataCommandManager.GetDataCommand("GetProductPrice");
                return command.ExecuteEntityList<ProductEntity>();
            }
        }

        //输出参数
        public int GetProductOrderHitCount(int productID)
        {
            var command = DataCommandManager.CreateCustomDataCommandFromConfig("ProductOrderHist");
            command.AddInputParameter("@ProductID", System.Data.DbType.Int32, productID);
            command.AddOutParameter("@HitCount", System.Data.DbType.Int32, 4);
            command.ExecuteNonQuery();
            return command.GetParameterValue<int>("@HitCount");
        }
    }
}
