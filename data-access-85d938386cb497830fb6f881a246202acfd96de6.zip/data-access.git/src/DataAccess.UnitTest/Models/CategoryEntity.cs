﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.UnitTest.Models
{
    public class CategoryEntity
    {
        public int CategoryID { get; set; }

        public string CategoryName { get; set; }

        public string Description { get; set; }

        public string CategoryNameNew { get; set; }

        public string CharColumn { get; set; }

        public string NewCharColumn { get; set; }
    }
}
