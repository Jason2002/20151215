﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.UnitTest.Models
{
    public class ProductEntity
    {
        public int ProductID { get; set; }

        public double UnitPrice { get; set; }

        public Guid TestID { get; set; }

        public Guid TestID2 { get; set; }
    }
}
