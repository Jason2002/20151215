﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Oversea.DataAccess.RandomData.Attributes;

namespace DataAccess.UnitTest.Models
{
    public class CustomerEntity
    {
        [RandomText(5)]
        public string CustomerID { get; set; }

        [RandomNumber(20, 50)]
        public int age { get; set; }

        [RandomFirstName]
        public string FirstName { get; set; }

        [RandomLastName]
        public string LastName { get; set; }

        [Identity(1)]
        public int TransactionNumber { get; set; }

        [RandomDateTime("1950-1-1", "2000-1-1")]
        public DateTime Birthday { get; set; }

        [RandomBool]
        public bool IsActive { get; set; }

        public string CharCustomerID { get; set; }

        public string CompanyName { get; set; }

        public string ContactName { get; set; }

        public string ContactTitle { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string Region { get; set; }

        public string PostalCode { get; set; }

        public string Country { get; set; }

        public string Phone { get; set; }

        public string Fax { get; set; }

        
    }
}
