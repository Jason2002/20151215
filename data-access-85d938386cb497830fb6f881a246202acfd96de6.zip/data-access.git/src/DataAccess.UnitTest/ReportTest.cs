﻿using System;
using System.Data;
using DataAccess.UnitTest.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataAccess.UnitTest
{
    [TestClass]
    public class ReportTest
    {
        [TestMethod]
        public void Report_SalesReport_Test()
        {
            DateTime fromDate = new DateTime(1990, 1, 1);
            DateTime toDate = new DateTime(2010, 1, 1);
            DataTable report = new ReportBiz().GetSalesReport(fromDate, toDate);
            Assert.IsNotNull(report);
            Assert.AreNotEqual(0, report.Rows.Count);
        }

        [TestMethod]
        public void Report_SalesReport_TestCustomizeSql()
        {
            DateTime fromDate = new DateTime(1990, 1, 1);
            DateTime toDate = new DateTime(2010, 1, 1);
            DataTable report = new ReportBiz().GetSalesReportCustomizeSql(fromDate, toDate);
            Assert.IsNotNull(report);
            Assert.AreNotEqual(0, report.Rows.Count);
        }
    }
}
