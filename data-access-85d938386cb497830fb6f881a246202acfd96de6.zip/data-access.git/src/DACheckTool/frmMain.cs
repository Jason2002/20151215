﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace DACheckTool
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();

            dataGridView1.AllowUserToAddRows = false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "assembly files (*.dll)|*.dll|executable files (*.exe)|*.exe";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtAssemblyPath.Text = ofd.FileName;
            }
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Class Name", typeof(string));
            dt.Columns.Add("Property Name", typeof(string));
            dt.Columns.Add("DataMapping Name", typeof(string));

            Assembly assembly = Assembly.LoadFrom(txtAssemblyPath.Text);
            foreach (Type classType in assembly.GetTypes())
            {

                if (!classType.IsValueType)
                {
                    foreach (var propType in classType.GetProperties())
                    {
                        var attributes = propType.GetCustomAttributes(true);
                        if (attributes.Length > 0)
                        {
                            var find = attributes.FirstOrDefault(a => a.ToString().Contains("DataMappingAttribute"));
                            if (find != null)
                            {
                                try
                                {
                                    var dataMappingName = find.GetType().GetProperty("ColumnName").GetValue(find, null).ToString();
                                    if (!propType.Name.Equals(dataMappingName, StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        dt.Rows.Add(classType.FullName, propType.Name, dataMappingName);
                                    }
                                }
                                catch { }
                            }
                        }
                    }
                    
                }
            }
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 500;
            dataGridView1.Columns[1].Width = 200;
            dataGridView1.Columns[2].Width = 200;
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Congratulation, no difference was found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

 
    }

}
