﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Newegg.Oversea.DataAccess;

namespace TestForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var command = DataCommandManager.GetDataCommand("GetOrderByDynamicQuerySqlBuilder");
            if (command != null)
            {
                MessageBox.Show("OK");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var command = DataCommandManager.GetDataCommand("GetAllCustomers");
            if (command != null)
            {
                MessageBox.Show("OK");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var command = DataCommandManager.GetDataCommand("GetCustomerByCustomerID");
            if (command != null)
            {
                MessageBox.Show("OK");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var command = DataCommandManager.GetDataCommand("GetAllOrdersWithCustomer");
            if (command != null)
            {
                MessageBox.Show("OK");
            }
        }
    }
}
