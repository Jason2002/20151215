﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Runtime.Remoting;
using System.ComponentModel;
using Newegg.Oversea.DataAccess.Config;
using System.Threading.Tasks;



namespace Newegg.Oversea.DataAccess
{
    public class Trace
    {
        private static string path = string.Empty;
        private static readonly Trace Instance = new Trace();

        private Trace()
        {

        }
        public static Trace GetInstance()
        {
            return Instance;
        }

        public void TraceTaskRun(DataCommandConfig m_config, dynamic commandParameters)
        {
            Task task = new Task(() => { WriteLog(m_config, commandParameters); });
            try
            {
                task.Start();
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void WriteLog(DataCommandConfig m_config, dynamic commandParameters)
        {
            if (ConfigHelper.IfTrace)
            {
                string LogText = string.Empty;
                if (commandParameters is DynamicParameters)
                {
                    DynamicParameters Parameters = new DynamicParameters(commandParameters);
                    LogText = Environment.NewLine + Parameters.ToTraceLog();
                }
                else if (commandParameters is Array)
                {
                    Array array = commandParameters as Array;
                    foreach (var temp in array)
                    {
                        Dictionary<string, object> dictionaryResult = GetDictionary(temp);
                        LogText += DictionaryText(dictionaryResult);
                        LogText += Environment.NewLine;
                    }
                }
                else if (commandParameters is IList)
                {
                    var list = commandParameters as IList;
                    foreach (var item in list)
                    {
                        Dictionary<string, object> dictionaryResult = GetDictionary(item);
                        LogText += DictionaryText(dictionaryResult);
                        LogText += Environment.NewLine;
                    }
                }
                else
                {
                    Dictionary<string, object> dictionaryResult = GetDictionary(commandParameters);
                    LogText = DictionaryText(dictionaryResult);
                }
                LogText = DateTime.Now.ToString() + Environment.NewLine + "Sql:" + m_config.CommandText +
                          Environment.NewLine + "Parameters:" + LogText + Environment.NewLine + Environment.NewLine;
                path = GetFileName(GetLogPath(), m_config.Name);
                FileWrite(LogText);
            }
        }

        private Dictionary<string, object> GetDictionary(dynamic parameters)
        {
            var dictionary = new Dictionary<string, object>();
            foreach (PropertyDescriptor propertyDescriptor in TypeDescriptor.GetProperties(parameters))
            {
                object obj = propertyDescriptor.GetValue(parameters);
                dictionary.Add(propertyDescriptor.Name, obj);
            }
            return dictionary;
        }

        private void FileWrite(string text)
        {
            try
            {
                FileStream LogFile = new FileStream(path, FileMode.Append, FileAccess.Write);
                LogFile.Write(Encoding.Default.GetBytes(text), 0, text.Length);
                LogFile.Close();
            }
            catch (IOException e)
            {
                throw e;
            }
        }

        private string DictionaryText(Dictionary<string, object> dictionary)
        {
            var result = string.Empty;
            string name = "";
            foreach (var temp in dictionary)
            {
                name += "@" + temp.Key;
                if (temp.Value is Array)
                {
                    Array array = (object)temp.Value as Array;
                    foreach (var text in array)
                    {
                        result += Environment.NewLine + name + "  " + text.GetType().ToString() + " : " + text.ToString();

                    }
                }
                else
                {
                    result += Environment.NewLine + name + "  " + temp.Value.GetType().ToString() + " : " + temp.Value.ToString();
                }
                name = "";
            }
            return result;
        }

        private string GetLogPath()
        {
            string datatime = DateTime.Now.ToString("yyyy-MM-dd");
            var path = ConfigHelper.LogPath + datatime + Path.DirectorySeparatorChar;
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            return path;
        }

        private string GetFileName(string Directory, string CommandName)
        {
            try
            {
                FileStream file = new FileStream(Path.Combine(Directory, CommandName), FileMode.OpenOrCreate, FileAccess.ReadWrite);
                file.Close();
            }
            catch (IOException e)
            {
                throw e;
            }
            return Path.Combine(Directory, CommandName);
        }
    }
}
