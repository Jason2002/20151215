using System;
using System.Configuration;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.Transactions;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Linq;

using Newegg.Oversea.DataAccess.DbProvider;

namespace Newegg.Oversea.DataAccess
{
    #region Connection
    public class ConnectionWrapper : IDisposable
    {
        private DbConnection m_Connection;
        private bool m_DisposeConnection;

        /// <summary>
        ///		Create a new "lifetime" container for a <see cref="DbConnection"/> instance.
        /// </summary>
        /// <param name="connection">The connection</param>
        /// <param name="disposeConnection">
        ///		Whether or not to dispose of the connection when this class is disposed.
        ///	</param>
        public ConnectionWrapper(DbConnection connection, bool disposeConnection)
        {
            this.m_Connection = connection;
            this.m_DisposeConnection = disposeConnection;
        }

        /// <summary>
        ///		Gets the actual connection.
        /// </summary>
        public DbConnection Connection
        {
            get { return m_Connection; }
        }

        #region IDisposable Members

        /// <summary>
        ///		Dispose the wrapped connection, if appropriate.
        /// </summary>
        public void Dispose()
        {
            if (m_DisposeConnection)
            {
                try
                {
                    m_Connection.Close();
                    m_Connection.Dispose();
                }
                catch { }
            }
        }

        #endregion
    }

    public static partial class DbHelper
    {

        internal static void GetConnectionInfo(string databaseName, out string connectionString, out IDbFactory factory)
        {
            ProviderType type;
            ConnectionStringManager.GetConnectionInfo(databaseName, out connectionString, out type);
            factory = DbFactories.GetFactory(type);
        }

        private static ConnectionWrapper GetOpenConnection(string connectionString, IDbFactory factory)
        {
            return GetOpenConnection(connectionString, factory, true);
        }

        private static ConnectionWrapper GetOpenConnection(string connectionString, IDbFactory factory, bool disposeInnerConnection)
        {
            DbConnection connection = TransactionScopeConnections.GetConnection(connectionString, factory);
            if (connection != null)
            {
                return new ConnectionWrapper(connection, false);
            }
            else
            {
                try
                {
                    connection = factory.CreateConnection(connectionString);
                    connection.Open();
                }
                catch
                {
                    if (connection != null)
                    {
                        connection.Close();
                    }
                    throw;
                }
                return new ConnectionWrapper(connection, disposeInnerConnection);
            }
        }

        #endregion

        #region Execute Non Query
        public static int ExecuteNonQuery(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);
            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                int val = SqlMapper.Execute(wrapper.Connection, cmdText, commandParameters, null, timeout, cmdType);
                return val;
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        #endregion

        #region Execute Reader
        public static DbDataReader ExecuteReader(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);
            ConnectionWrapper wrapper = GetOpenConnection(connectionString, dbFactory);
            CommandBehavior cmdBehavior;
            if (Transaction.Current != null)
            {
                cmdBehavior = CommandBehavior.Default;
            }
            else
            {
                cmdBehavior = CommandBehavior.CloseConnection;
            }
            try
            {
                DbDataReader rdr = SqlMapper.QueryReader(wrapper.Connection, cmdText, commandParameters, cmdBehavior, timeout, cmdType);
                
                return rdr;
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
        }
        #endregion

        #region Execute Scalar
        public static object ExecuteScalar(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);

                object result = SqlMapper.QueryScalar(wrapper.Connection, cmdText, commandParameters, null, timeout, cmdType);
                return result;
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }
        #endregion

        #region Execute Data Set and Data Table and Row
        public static DataSet ExecuteDataSet(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                DbDataAdapter sda = dbFactory.CreateDataAdapter();
                DataSet result = SqlMapper.QueryDataSet(wrapper.Connection, cmdText, commandParameters, null, timeout, cmdType, sda);
                return result;
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static DataTable ExecuteDataTable(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                DbDataAdapter sda = dbFactory.CreateDataAdapter();
                DataTable result = SqlMapper.QueryDataTable(wrapper.Connection, cmdText, commandParameters, null, timeout, cmdType, sda);
                return result;
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static DataRow ExecuteDataRow(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            DataTable table = ExecuteDataTable(databaseName, cmdType, cmdText, timeout, commandParameters);
            if (table.Rows.Count == 0)
            {
                return null;
            }
            return table.Rows[0];
        }

        #endregion

        #region Execute Entity

        public static IEnumerable<dynamic> ExecuteEntity(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                return SqlMapper.Query(wrapper.Connection, cmdText, commandParameters, null, true, timeout, cmdType);
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static IEnumerable<T> ExecuteEntity<T>(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                return SqlMapper.Query<T>(wrapper.Connection, cmdText, commandParameters, null, true, timeout, cmdType);

            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static IEnumerable<TReturn> ExecuteEntity<TFirst, TSecond, TReturn>(string databaseName, 
            Func<TFirst, TSecond, TReturn> map,
            CommandType cmdType, string cmdText, int timeout, dynamic commandParameters, string splitOn = "TransactionNumber")
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);

                return SqlMapper.Query<TFirst, TSecond, TReturn>(wrapper.Connection, cmdText, map, commandParameters, null, true, splitOn, timeout, cmdType);
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static IEnumerable<TReturn> ExecuteEntity<TFirst, TSecond, TThird, TReturn>(string databaseName, CommandType cmdType, 
            Func<TFirst, TSecond, TThird, TReturn> map,
            string cmdText, int timeout, dynamic commandParameters, string splitOn = "TransactionNumber")
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);

                return SqlMapper.Query<TFirst, TSecond, TThird, TReturn>(wrapper.Connection, cmdText, map, commandParameters, null, true, splitOn, timeout, cmdType);
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static IEnumerable<TReturn> ExecuteEntity<TFirst, TSecond, TThird, TFourth, TReturn>(string databaseName,
            Func<TFirst, TSecond, TThird, TFourth, TReturn> map,
            CommandType cmdType, string cmdText, int timeout,
            dynamic commandParameters, string splitOn = "TransactionNumber")
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);

                return SqlMapper.Query<TFirst, TSecond, TThird, TFourth, TReturn>(wrapper.Connection, cmdText, map, commandParameters, null, true, splitOn, timeout, cmdType);
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        public static IEnumerable<TReturn> ExecuteEntity<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(string databaseName,
            Func<TFirst, TSecond, TThird, TFourth, TFifth, TReturn> map,
            CommandType cmdType, string cmdText, int timeout,
            dynamic commandParameters, string splitOn = "TransactionNumber")
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                return SqlMapper.Query<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(wrapper.Connection, cmdText, map, commandParameters, null, true, splitOn, timeout, cmdType);

            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        #endregion

        #region Multiple Return

        public static GridReader ExecuteMultiple(string databaseName, CommandType cmdType, string cmdText, int timeout, dynamic commandParameters)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                GridReader result = SqlMapper.QueryMultiple(wrapper.Connection, cmdText, commandParameters, null, timeout, cmdType);
                result.Connection = wrapper;
                return result;
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, cmdText, commandParameters);
            }
        }

        #endregion

        #region Bulk Copy

        public static void ExecuteBulkCopy(string databaseName, string tableName, DataTable table)
        {
            IDbFactory dbFactory;
            string connectionString;
            GetConnectionInfo(databaseName, out connectionString, out dbFactory);

            ConnectionWrapper wrapper = null;
            try
            {
                wrapper = GetOpenConnection(connectionString, dbFactory);
                using (var sqlBulkCopy = new SqlBulkCopy((SqlConnection)wrapper.Connection))
                {
                    foreach (var col in table.Columns)
                    {
                        sqlBulkCopy.ColumnMappings.Add(col.ToString(), col.ToString());
                    }
                    sqlBulkCopy.DestinationTableName = tableName;
                    sqlBulkCopy.WriteToServer(table);
                }
            }
            catch (Exception ex)
            {
                throw new DataAccessException(ex, connectionString, "ExecuteBulkCopy", null);
            }
            finally
            {
                if (wrapper != null)
                {
                    wrapper.Dispose();
                }
            }
        }

        #endregion
    }
}