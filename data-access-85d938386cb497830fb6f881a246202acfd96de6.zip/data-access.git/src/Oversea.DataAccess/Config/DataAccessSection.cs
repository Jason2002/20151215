﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Xml;

namespace Newegg.Oversea.DataAccess.Config
{
    public class DataAccessSection : IConfigurationSectionHandler
    {
        private const string SQL_CONFIG_LIST_FILE_ATTR = "sqlConfigListFile";
        private const string LOG_PATH_ATTR = "logPath";
        private const string DATABASE_LIST_FILE_ATTR = "databaseListFile";
        private const string EXCEPTION_LEVEL = "exceptionLevel";
        private const string CONFIG_DIRECTORY_ATTR = "configDirectory";
        private const string USE_MOCK_ATTR = "useMock";
        private const string IF_TRACE_ATTR = "IfTrace";

        public object Create(object parent, object configContext, XmlNode section)
        {
            DataAccessSetting da = new DataAccessSetting();
            if (section != null && section.Attributes != null)
            {
                if (section.Attributes[SQL_CONFIG_LIST_FILE_ATTR] != null
                    && section.Attributes[SQL_CONFIG_LIST_FILE_ATTR].Value != null
                    && section.Attributes[SQL_CONFIG_LIST_FILE_ATTR].Value.Trim().Length > 0)
                {
                    da.SqlConfigListFilePath = section.Attributes[SQL_CONFIG_LIST_FILE_ATTR].Value.Trim();
                }
                if (section.Attributes[LOG_PATH_ATTR] != null
                   && section.Attributes[LOG_PATH_ATTR].Value != null
                   && section.Attributes[LOG_PATH_ATTR].Value.Trim().Length > 0)
                {
                    da.LogPath = section.Attributes[LOG_PATH_ATTR].Value.Trim();
                }

                if (section.Attributes[DATABASE_LIST_FILE_ATTR] != null
                    && section.Attributes[DATABASE_LIST_FILE_ATTR].Value != null
                    && section.Attributes[DATABASE_LIST_FILE_ATTR].Value.Trim().Length > 0)
                {
                    da.DatabaseListFilePath = section.Attributes[DATABASE_LIST_FILE_ATTR].Value.Trim();
                }

                if (section.Attributes[EXCEPTION_LEVEL] != null
                       && section.Attributes[EXCEPTION_LEVEL].Value != null
                       && section.Attributes[EXCEPTION_LEVEL].Value.Trim().Length > 0)
                {
                    da.ExceptionLevel = (ExceptionLevels)Enum.Parse(typeof(ExceptionLevels), section.Attributes[EXCEPTION_LEVEL].Value.Trim());
                }
                else
                {
                    da.ExceptionLevel = ExceptionLevels.Safety;
                }

                if (section.Attributes[CONFIG_DIRECTORY_ATTR] != null
                    && section.Attributes[CONFIG_DIRECTORY_ATTR].Value != null
                    && section.Attributes[CONFIG_DIRECTORY_ATTR].Value.Trim().Length > 0)
                {
                    da.ConfigDirectory = section.Attributes[CONFIG_DIRECTORY_ATTR].Value.Trim();
                }

                if (section.Attributes[USE_MOCK_ATTR] != null
                    && section.Attributes[USE_MOCK_ATTR].Value != null
                    && section.Attributes[USE_MOCK_ATTR].Value.Trim().Length > 0)
                {
                    da.UseMock = section.Attributes[USE_MOCK_ATTR].Value.Trim() == "true" ? true : false;
                }
                else
                {
                    da.UseMock = false;
                }
                if (section.Attributes[IF_TRACE_ATTR] != null
                    && section.Attributes[IF_TRACE_ATTR].Value != null
                    && section.Attributes[IF_TRACE_ATTR].Value.Trim().Length > 0)
                {
                    da.IfTrace = section.Attributes[IF_TRACE_ATTR].Value.Trim() == "true" ? true : false;
                }
                else
                {
                    da.IfTrace = false;
                }
            }
            return da;
        }
    }

    public class DataAccessSetting
    {
        public string SqlConfigListFilePath
        {
            get;
            set;
        }
        public string LogPath
        {
            get;
            set;
        }
        public string DatabaseListFilePath
        {
            get;
            set;
        }

        public ExceptionLevels ExceptionLevel
        {
            get; 
            set;
        }

        public string ConfigDirectory
        {
            get;
            set;
        }

        public bool UseMock
        {
            get;
            set;
        }
        public bool IfTrace
        {
            get;
            set;
        }
    }

    public enum ExceptionLevels
    {
        Full,
        Safety
    }
}
