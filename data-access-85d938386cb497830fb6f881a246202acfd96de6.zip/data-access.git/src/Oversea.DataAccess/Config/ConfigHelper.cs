﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Configuration;
using System.Collections.Concurrent;

namespace Newegg.Oversea.DataAccess.Config
{
    internal static class ConfigHelper
    {
        private const string NODE_NAME = "dataAccess";
        private const string DEFAULT_SQL_CONFIG_LIST_FILE_PATH = "Configuration/Data/DbCommandFiles.config";
        private const string DEFAULT_LOG_FILE_PATH = "Log/";
        private const string DEFAULT_DATABASE_LIST_FILE_PATH = "Configuration/Data/Database.config";

        private static string s_ConfigFolder = null;
        private static List<string> s_allFiles = null;
        private static DataAccessSetting s_Setting = ConfigurationManager.GetSection(NODE_NAME) as DataAccessSetting;
        internal static DataAccessSetting GetSettings()
        {
            return s_Setting;
        }

        public static string ConfigFolder
        {
            get
            {
                if (s_ConfigFolder == null)
                {
                    s_ConfigFolder = Path.GetDirectoryName(SqlConfigListFilePath);
                }
                return s_ConfigFolder;
            }
        }

        public static bool IsAutoConfig
        {
            get
            {
                return (s_Setting != null && !string.IsNullOrEmpty(s_Setting.ConfigDirectory));
            }
        }

        public static List<string> AllFiles
        {
            get
            {
                if (s_allFiles == null)
                {
                    AutoLoadFiles(new DirectoryInfo(ConfigDirectory));
                }
                return s_allFiles;
            }
            set
            {
                s_allFiles = null;
            }
        }

        public static string ConfigDirectory
        {
            get
            {
                string configdir = s_Setting == null ? null : s_Setting.ConfigDirectory;
                if (configdir == null || configdir.Trim().Length <= 0)
                {
                    return null;
                }
                string p = Path.GetPathRoot(configdir);
                if (p == null || p.Trim().Length <= 0)
                {
                    return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, configdir);
                }
                return configdir;
            }
        }

        public static bool UseMock
        {
            get
            {
                return s_Setting != null && s_Setting.UseMock;
            }
        }
        public static bool IfTrace
        {
            get
            {
                return s_Setting != null && s_Setting.IfTrace;
            }
        }

        public static string SqlConfigListFilePath
        {
            get
            {
                string path = s_Setting == null ? null : s_Setting.SqlConfigListFilePath;
                if (path == null || path.Trim().Length <= 0)
                {
                    path = DEFAULT_SQL_CONFIG_LIST_FILE_PATH;
                }
                string p = Path.GetPathRoot(path);
                if (p == null || p.Trim().Length <= 0) // 说明是相对路径
                {
                    return Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, path);
                }
                return path;
            }
        }
        public static string LogPath  
        {
            get
            {
                string path = s_Setting == null ? null : s_Setting.LogPath;
                if (path == null || path.Trim().Length <= 0)
                {
                    path = DEFAULT_LOG_FILE_PATH;
                }
                string p = Path.GetPathRoot(path);
                if (p == null || p.Trim().Length <= 0) // 说明是相对路径
                {
                    return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);
                }
                return path;
            }
        }

        public static string DatabaseListFilePath
        {
            get
            {
                string path = s_Setting == null ? null : s_Setting.DatabaseListFilePath;
                if (path == null || path.Trim().Length <= 0)
                {
                    path = DEFAULT_DATABASE_LIST_FILE_PATH;
                }
                string p = Path.GetPathRoot(path);
                if (p == null || p.Trim().Length <= 0) // 说明是相对路径
                {
                    return Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, path);
                }
                return path;
            }
        }

        public static ExceptionLevels ExceptionLevel
        {
            get
            {
                if (s_Setting == null) return ExceptionLevels.Full;
                return s_Setting.ExceptionLevel;
            }
        }


        private static T LoadFromXml<T>(string fileName)
        {
            //FileStream fs = null;
            //try
            //{
            //XmlSerializer serializer = new XmlSerializer(typeof(T));
            //fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            //return (T)serializer.Deserialize(fs);

            using (StreamReader sr = new StreamReader(fileName))
            {
                return XmlSerializerHelper.XmlDeserialize<T>(sr.ReadToEnd());
            }
            //}
            //finally
            //{
            //    if (fs != null)
            //    {
            //        fs.Close();
            //    }
            //}
        }

        public static DataCommandFileList LoadSqlConfigListFile()
        {
            if (IsAutoConfig)
            {
                var fileList = new DataCommandFileList();
                var allFiles = new List<DataCommandFileList.DataCommandFile>();
                foreach (var f in AllFiles)
                {
                    var temp = LoadFromXml<DataCommandFileList>(f);
                    if (temp != null && temp.FileList != null)
                    {
                        FileInfo fi = new FileInfo(f);
                        var dr = fi.Directory.FullName;
                        allFiles.AddRange(temp.FileList.Select(d =>
                        {
                            string path = d.FileName;
                            string root = Path.GetPathRoot(path);
                            if (root == null || root.Trim().Length <= 0)
                            {
                                path = Path.Combine(dr, path);
                            }
                            d.FileName =  path;
                            return d;
                        }).ToList());
                    }
                }
                fileList.FileList = allFiles.ToArray();
                return fileList;
            }
            else
            {
                return LoadFromXml<DataCommandFileList>(SqlConfigListFilePath);
            }
        }

        public static DatabaseList LoadDatabaseListFile()
        {
            if (IsAutoConfig)
            {
                var dblist = new DatabaseList(); //对应Database.config文件
                var allInstances = new List<DatabaseInstance>();
                foreach (var f in AllFiles)
                {
                    var temp = LoadFromXml<DatabaseList>(f);//加载Database.config文件databaselist节点的信息
                    if (temp != null && temp.DatabaseInstances != null)
                    {
                        allInstances.AddRange(temp.DatabaseInstances.Select(d => d).ToList());
                    }
                }
                dblist.DatabaseInstances = allInstances.ToArray();
                return dblist;
            }              
            else
            {
                return LoadFromXml<DatabaseList>(DatabaseListFilePath);//加载Database.config文件databaselist节点的信息
            }
        }

        private static void AutoLoadFiles(DirectoryInfo filedir)
        {
            foreach (FileSystemInfo file in filedir.GetFileSystemInfos("*"))
            {
                if (file is FileInfo)
                {
                    if (file.Extension.Equals(".config", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (s_allFiles == null)
                        {
                            s_allFiles = new List<string>();
                        }
                        s_allFiles.Add(file.FullName);
                    }
                }
                else if (file is DirectoryInfo)
                {
                    AutoLoadFiles(file as DirectoryInfo);
                }
            }
        } //create by lon.use it to load all files

        public static DataOperations LoadDataCommandList(string filePath)
        {
            return LoadFromXml<DataOperations>(filePath);
        }
    }

    public static class XmlSerializerHelper
    {

        private static ConcurrentDictionary<Type, XmlSerializer> _cache;
        private static XmlSerializerNamespaces _defaultNamespace;

        static XmlSerializerHelper()
        {
            _defaultNamespace = new XmlSerializerNamespaces();
            _defaultNamespace.Add(string.Empty, string.Empty);

            _cache = new ConcurrentDictionary<Type, XmlSerializer>();
        }


        private static XmlSerializer GetSerializer<T>()
        {
            var type = typeof(T);
            return _cache.GetOrAdd(type, XmlSerializer.FromTypes(new[] { type }).FirstOrDefault());
        }


        public static string XmlSerialize<T>(this T obj)
        {
            using (var memoryStream = new MemoryStream())
            {
                GetSerializer<T>().Serialize(memoryStream, obj, _defaultNamespace);
                return Encoding.UTF8.GetString(memoryStream.GetBuffer());
            }
        }

        public static T XmlDeserialize<T>(this string xml)
        {
            using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(xml)))
            {
                try
                {
                    var obj = GetSerializer<T>().Deserialize(memoryStream);
                    return obj == null ? default(T) : (T)obj;
                }
                catch { return default(T); }
            }
        }
    }
}
