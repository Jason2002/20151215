﻿using System;
using System.ComponentModel;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Newegg.Oversea.DataAccess.Config;
using System.Data;
using System.Data.Common;
using Newegg.Oversea.DataAccess.DbProvider;
using System.Data.SqlClient;

namespace Newegg.Oversea.DataAccess
{
    public class DataCommand
    {
        private DataCommandConfig m_Config;
        protected DataCommandConfig Config
        {
            get { return m_Config; }
        }
        private IDbFactory m_Factory;      
        private DynamicParameters m_DbParameterList;
        private List<Param> m_configParameterList;

        internal DataCommand(DataCommandConfig config)
        {
            m_Config = config.Clone();
            IDbFactory factory;
            string conn;
            DbHelper.GetConnectionInfo(m_Config.Database, out conn, out factory);
            m_Factory = factory;
            m_configParameterList = CreateParameters();
            m_DbParameterList = new DynamicParameters();
            AutoAddOutputParameter();
        }

        public int CommandTimeout
        {
            get { return Config.TimeOut; }
            set { Config.TimeOut = value; }
        }

        #region Parameters

        internal bool HasDefinedParameter(string name)
        {
            if (!name.StartsWith("@"))
            {
                name = "@" + name;
            }
            return m_configParameterList.Exists(p => p.Name == name);
        }

        private List<Param> CreateParameters()
        {
            if (m_Config == null || m_Config.Parameters == null || m_Config.Parameters.Param == null || m_Config.Parameters.Param.Length <= 0)
            {
                return new List<Param>(0);
            }
            return m_Config.Parameters.Param.ToList();
        }

        private string PrecheckParamaterName(string paramName)
        {
            if (!paramName.StartsWith("@"))
            {
                paramName = "@" + paramName;
            }
            return paramName;
        }

        protected void InnerAddInputParameter(string name, DbType dbType, object value, int? size = null)
        {
            name = PrecheckParamaterName(name);
            m_DbParameterList.Add(name, value, dbType, ParameterDirection.Input, size);
        }

        protected void InnerAddInputParameter(string name, DbType dbType)
        {
            name = PrecheckParamaterName(name);
            m_DbParameterList.Add(name, null, dbType, ParameterDirection.Input);
        }

        protected void InnerAddOutParameter(string name, DbType dbType, int size)
        {
            name = PrecheckParamaterName(name);
            m_DbParameterList.Add(name, null, dbType, ParameterDirection.Output, size);
        }

        public void ReplaceParameterValue(string paramName, object paramValue)
        {
            m_Config.CommandText = m_Config.CommandText.Replace(paramName, paramValue.ToString());
        }

        public object GetParameterValue(string paramName)
        {
            return m_DbParameterList.Get<object>(paramName);
        }

        public T GetParameterValue<T>(string paramName)
        {
            return m_DbParameterList.Get<T>(paramName);
        }

        public void SetParameterValue(string paramName, object val)
        {
            if (m_DbParameterList.IsExists(paramName))
            {
                m_DbParameterList.Add(paramName, val);
                return;
            }

            paramName = PrecheckParamaterName(paramName);
            var preDefine = m_configParameterList.FirstOrDefault(p => p.Name.Equals(paramName, StringComparison.InvariantCultureIgnoreCase));
            if (preDefine != null)
            {
                int? size = null;
                if (preDefine.Size != -1)
                {
                    size = preDefine.Size;
                }
                byte? precision = null;
                if (preDefine.Precision != 0)
                {
                    precision = preDefine.Precision;
                }
                byte? scale = null;
                if (preDefine.Scale != 0)
                {
                    scale = preDefine.Scale;
                }
                m_DbParameterList.Add(preDefine.Name, val, preDefine.DbType, preDefine.Direction, size, precision, scale);
            }
        }

        private void AutoAddOutputParameter()
        {
            var preDefine = m_configParameterList.Where(p => p.Direction == ParameterDirection.Output || p.Direction == ParameterDirection.ReturnValue);
            if (preDefine.Count() > 0)
            {
                preDefine.ToList().ForEach(p =>
                {
                    m_DbParameterList.Add(p.Name, null, p.DbType, p.Direction, p.Size, p.Precision, p.Scale);
                });
            }
        }

        #endregion

        #region ExecuteNonQuery
        public int ExecuteNonQuery(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (int)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                return DbHelper.ExecuteNonQuery(m_Config.Database, m_Config.CommandType, m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region ExecuteScalar

        public object ExecuteScalar(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                return DbHelper.ExecuteScalar(m_Config.Database, m_Config.CommandType, m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        public T ExecuteScalar<T>(dynamic parameter = null)
        {
            return (T)ExecuteScalar(parameter);
        }
        #endregion

        #region ExecuteDataReader

        public DbDataReader ExecuteDataReader(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (DbDataReader)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                return DbHelper.ExecuteReader(m_Config.Database, m_Config.CommandType, m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region ExecuteDataSet
        public DataSet ExecuteDataSet(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (DataSet)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                return DbHelper.ExecuteDataSet(m_Config.Database, m_Config.CommandType, m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region ExecuteDataTable

        public DataTable ExecuteDataTable(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (DataTable)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                return DbHelper.ExecuteDataTable(m_Config.Database, m_Config.CommandType, m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region ExecuteDataRow

        public DataRow ExecuteDataRow(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (DataRow)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                return DbHelper.ExecuteDataRow(m_Config.Database, m_Config.CommandType, m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region ExecuteEntity<T>        

        public T ExecuteEntity<T>(dynamic parameter = null) where T : class, new()
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (T)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<T> result = DbHelper.ExecuteEntity<T>(m_Config.Database, m_Config.CommandType,
                    m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
                if (result.Count() > 0)
                {
                    return result.First();
                }
                else
                {
                    return null;
                }
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region ExecuteEntityList<T, C>

        public List<T> ExecuteEntityList<T>(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (List<T>)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<T> result = DbHelper.ExecuteEntity<T>(m_Config.Database, m_Config.CommandType,
                    m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
                else
                {
                    return new List<T>();
                }
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        public List<TReturn> ExecuteEntityList<TFirst, TSecond, TReturn>(Func<TFirst, TSecond, TReturn> map,
            dynamic parameter = null, string splitOn = "TransactionNumber")
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (List<TReturn>)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<TReturn> result = DbHelper.ExecuteEntity<TFirst, TSecond, TReturn>(m_Config.Database,
                    map, m_Config.CommandType, m_Config.CommandText, m_Config.TimeOut,
                    parameter == null ? m_DbParameterList : parameter, splitOn);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
                else
                {
                    return new List<TReturn>();
                }
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        public List<TReturn> ExecuteEntityList<TFirst, TSecond, TThird, TReturn>(
            Func<TFirst, TSecond, TThird, TReturn> map, dynamic parameter = null, string splitOn = "TransactionNumber")
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (List<TReturn>)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<TReturn> result = DbHelper.ExecuteEntity<TFirst, TSecond, TThird, TReturn>(
                    m_Config.Database, m_Config.CommandType,
                    map, m_Config.CommandText, m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter,
                    splitOn);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
                else
                {
                    return new List<TReturn>();
                }
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        public List<TReturn> ExecuteEntityList<TFirst, TSecond, TThird, TFourth, TReturn>(
            Func<TFirst, TSecond, TThird, TFourth, TReturn> map, dynamic parameter = null,
            string splitOn = "TransactionNumber")
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (List<TReturn>)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<TReturn> result =
                    DbHelper.ExecuteEntity<TFirst, TSecond, TThird, TFourth, TReturn>(m_Config.Database,
                        map, m_Config.CommandType, m_Config.CommandText, m_Config.TimeOut,
                        parameter == null ? m_DbParameterList : parameter, splitOn);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
                else
                {
                    return new List<TReturn>();
                }
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        public List<TReturn> ExecuteEntityList<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(
            Func<TFirst, TSecond, TThird, TFourth, TFifth, TReturn> map, dynamic parameter = null,
            string splitOn = "TransactionNumber")
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (List<TReturn>)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<TReturn> result =
                    DbHelper.ExecuteEntity<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(m_Config.Database,
                        map, m_Config.CommandType, m_Config.CommandText, m_Config.TimeOut,
                        parameter == null ? m_DbParameterList : parameter, splitOn);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
                else
                {
                    return new List<TReturn>();
                }
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        public List<dynamic> ExecuteEntityList(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (List<dynamic>)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                IEnumerable<dynamic> result = DbHelper.ExecuteEntity(m_Config.Database, m_Config.CommandType,
                    m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
                else
                {
                    return new List<dynamic>();
                }
            }
            catch (DataAccessException exception)
            {                
                throw new DataCommandException(exception, m_Config);                
            }
        }

        #endregion

        #region ExecuteMultiple

        public GridReader ExecuteMultiple(dynamic parameter = null)
        {
            try
            {
                object mockResult;
                if (TryMock(m_Config.Name, parameter == null ? m_DbParameterList : parameter, out mockResult))
                {
                    return (GridReader)mockResult;
                }
                Trace.GetInstance().TraceTaskRun(m_Config, parameter == null ? m_DbParameterList : parameter);
                GridReader result = DbHelper.ExecuteMultiple(m_Config.Database, m_Config.CommandType,
                    m_Config.CommandText,
                    m_Config.TimeOut, parameter == null ? m_DbParameterList : parameter);
                return result;
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }

        #endregion

        #region BulkCopy

        public void ExecuteBulkCopy<T>(string tableName, List<T> data) where T : class, new()
        {
            var properties = TypeDescriptor.GetProperties(typeof (T));
            var table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
            {
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }
            foreach (var item in data)
            {
                var row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                {
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                }
                table.Rows.Add(row);
            }
            ExecuteBulkCopy(tableName, table);
        }

        public void ExecuteBulkCopy(string tableName, DataTable table)
        {
            try
            {
                DbHelper.ExecuteBulkCopy(m_Config.Database, tableName, table);
            }
            catch (DataAccessException exception)
            {
                throw new DataCommandException(exception, m_Config);
            }
        }
        #endregion

        #region TryMock
        private bool TryMock(string command, dynamic parameter, out object result)
        {
            result = null;
            if (ConfigHelper.UseMock && DataCommandManager.s_MockFunction.ContainsKey(command))
            {
                var func = DataCommandManager.s_MockFunction[command];
                result = func(parameter);
                return true;
            }
            return false;
        }
        #endregion

    }

}
