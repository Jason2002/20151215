using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.IO;
using Microsoft.SqlServer.Server;
using Newegg.Oversea.DataAccess.Config;

namespace Newegg.Oversea.DataAccess.DbProvider
{
    [Serializable]
    public class DataAccessException : ApplicationException
    {
        internal string ConnectionString { get; private set; }
        internal string SqlScript { get; private set; }
        internal object Parameters { get; private set; }

        protected DataAccessException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        protected DataAccessException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public DataAccessException(Exception innerException, string connectionStr, string sqlText,
            object commandParameters)
            : base(BuildMessage(innerException.Message, connectionStr, sqlText, commandParameters), innerException)
        {
            this.ConnectionString = connectionStr;
            this.SqlScript = sqlText;
            this.Parameters = commandParameters;
        }

        private static string BuildMessage(string errorMsg, string connectionStr, string sqlText,
            object commandParameters)
        {
            return InternalBuildMessage(errorMsg, connectionStr, sqlText, commandParameters);
        }

        private static string InternalBuildMessage(string errorMsg, string connectionStr, string sqlText, object commandParameters)
        {
            StringBuilder msg = new StringBuilder();
            msg.AppendFormat("{0}\r\n", errorMsg);
            if (ConfigHelper.ExceptionLevel == ExceptionLevels.Full)
            {
                msg.AppendFormat("<<Connection String>> : {0}\r\n", connectionStr);
                msg.AppendFormat("<<SQL Script>> : {0}\r\n", sqlText);
                if (commandParameters != null)
                {
                    string paramMessage = ExceptionHelper.BuildParametersMessage(commandParameters);
                    if (!string.IsNullOrWhiteSpace(paramMessage))
                    {
                        msg.Append("<<SQL Parameter(s)>> :\r\n");
                        msg.Append(paramMessage);
                    }
                }
            }
            return msg.ToString();
        }
    }

    [Serializable]
    public class DataCommandException : ApplicationException
    {
        internal DataAccessException DataAccessException 
        {
            get
            {
                return this.InnerException as DataAccessException;
            }
        }

        internal DataCommandConfig Config { get; private set; }

        internal DataCommandException(DataAccessException daException, DataCommandConfig config)
            : base(BuildMessage(daException, config), daException)
        {
            this.Config = config;
        }

        private static string BuildMessage(DataAccessException daException, DataCommandConfig config)
        {
            string errorMsg = "Data Command Exception";
            if (daException.InnerException != null)
            {
                errorMsg = daException.InnerException.Message;
            }

            StringBuilder msg = new StringBuilder();
            msg.AppendFormat("{0}\r\n", errorMsg);

            msg.AppendFormat("<<Connection Name>> : {0}\r\n", config.Database);
            if (ConfigHelper.ExceptionLevel == ExceptionLevels.Full)
            {
                msg.AppendFormat("<<Connection String>> : {0}\r\n", daException.ConnectionString);
            }

            msg.AppendFormat("<<Script Name>> : {0}\r\n", config.Name);
            if (ConfigHelper.ExceptionLevel == ExceptionLevels.Full)
            {
                msg.AppendFormat("<<SQL Script>> : {0}\r\n", daException.SqlScript);
            }

            if (daException.Parameters != null)
            {
                string paramMessage = ExceptionHelper.BuildParametersMessage(daException.Parameters);
                if (!string.IsNullOrWhiteSpace(paramMessage))
                {
                    msg.Append("<<SQL Parameter(s)>> :\r\n");
                    msg.Append(paramMessage);
                }
            }

            return msg.ToString();
        }
    }

    internal static class ExceptionHelper
    {
        public static string BuildParametersMessage(object commandParameters)
        {
            if (commandParameters == null) return string.Empty;
            if (commandParameters is DynamicParameters) return commandParameters.ToString();

            try
            {
                StringBuilder sb = new StringBuilder(5000);
                XmlSerializer ser = new XmlSerializer(commandParameters.GetType());
                using (TextWriter writer = new StringWriter(sb))
                {
                    ser.Serialize(writer, commandParameters);
                    return writer.ToString();
                }
            }
            catch
            {
                return commandParameters.ToString();
            }
        }
    }
}