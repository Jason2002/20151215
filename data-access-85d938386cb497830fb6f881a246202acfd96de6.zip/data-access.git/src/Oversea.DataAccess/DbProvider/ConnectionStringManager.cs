using System;
using System.Text;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.Concurrent;
using Newegg.Oversea.DataAccess.Config;

namespace Newegg.Oversea.DataAccess.DbProvider
{
    public static class ConnectionStringManager
    {
        private static ConcurrentDictionary<string, ConnStrSetting> s_ConnStrMaps = new ConcurrentDictionary<string, ConnStrSetting>();

        private static ConcurrentDictionary<string, string> s_connectionStringDic;


        internal static void ClearCache()
        {
            s_ConnStrMaps.Clear();
            s_connectionStringDic = null;
        }

        internal static void GetConnectionInfo(string databaseName, out string connectionString, out ProviderType providerType)
        {
            if (s_ConnStrMaps.Count == 0)
            {
                DataCommandManager.LoadDatabaseInfo();
            }

            if (!s_ConnStrMaps.ContainsKey(databaseName))
            {
                throw new ApplicationException("Can't find the info of database '" + databaseName + "'. It hasn't been configurated.");
            }
            ConnStrSetting conn = s_ConnStrMaps[databaseName];
            connectionString = conn.ConnectionString;
            providerType = conn.ProviderType;
        }

        public static string GetConnectionString(string databaseName)
        {
            InitConnectionStringDic();

            string conncetionString = String.Empty;

            bool found = s_connectionStringDic.TryGetValue(databaseName, out conncetionString);
            if (found)
            {
                if (conncetionString != null && conncetionString.Trim().Length > 0)
                {
                    conncetionString = DataCommandManager.Decrypt(conncetionString);
                }
                else
                {
                    throw new ConfigurationErrorsException(String.Format("{0} [database:name] element connectionString is null or empty in Database.config, please check the config file.", databaseName));
                }
            }
            else
            {
                throw new ConfigurationErrorsException(String.Format(" Try get {0} [database:name] element connectionString failed in Database.config, please check the config file.", databaseName));
            }

            return conncetionString;
        }

        private static void InitConnectionStringDic()
        {
            if (s_connectionStringDic == null)
            {
                s_connectionStringDic = new ConcurrentDictionary<string, string>();
                DatabaseList dbList = ConfigHelper.LoadDatabaseListFile();
                if (dbList != null && dbList.DatabaseInstances != null && dbList.DatabaseInstances.Length > 0)
                {
                    foreach (var db in dbList.DatabaseInstances)
                    {
                        if (!s_connectionStringDic.ContainsKey(db.Name))
                        {
                            s_connectionStringDic.TryAdd(db.Name, db.ConnectionString);
                        }
                    }
                }
            }
        }

        public static void SetConnectionString(string databaseName, string connStr, string providerName)
        {
            ProviderType providerType = ConvertProviderNameToType(providerName, databaseName, connStr);
            SetConnectionString(databaseName, connStr, providerType);
        }

        public static void SetConnectionString(string databaseName, string connStr, ProviderType providerType)
        {
            ConnStrSetting tmp = new ConnStrSetting(databaseName, connStr, providerType);
            if (s_ConnStrMaps.ContainsKey(databaseName))
            {
                s_ConnStrMaps[databaseName] = tmp;
            }
            else
            {
                s_ConnStrMaps.TryAdd(databaseName, tmp);
            }
        }

        public static void SetSqlServerConnectionString(string databaseName, string connStr)
        {
            SetConnectionString(databaseName, connStr, ProviderType.SqlServer);
        }

        private static ProviderType ConvertProviderNameToType(string providerName, string databaseName, string connStr)
        {
            if (providerName == null || providerName.Trim().Length <= 0)
            {
                return ProviderType.SqlServer;
            }
            string name = providerName.Trim().ToLower();
            switch (name)
            {
                case "sqlserver":
                    return ProviderType.SqlServer;
                case "odbc":
                    return ProviderType.Odbc;
                case "oledb":
                    return ProviderType.OleDb;
                default:
                    throw new ConfigurationErrorsException("Not support this database provider '" + providerName + "' for database whose name is '" + databaseName + "' and connection string is '" + connStr + "'.");
            }
        }

        private class ConnStrSetting
        {
            private string m_Name;
            private string m_ConnectionString;
            private ProviderType m_ProviderType;

            public ConnStrSetting(string name, string connStr, ProviderType proType)
            {
                m_Name = name;
                m_ConnectionString = connStr;
                m_ProviderType = proType;
            }

            public string Name
            {
                get
                {
                    return m_Name;
                }
            }

            public string ConnectionString
            {
                get
                {
                    return m_ConnectionString;
                }
            }

            public ProviderType ProviderType
            {
                get
                {
                    return m_ProviderType;
                }
            }
        }
    }
}
