﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace Newegg.Oversea.Framework.Entity
{
    [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
    [Obsolete("This attribute is no longer used", false)]
    public class DataMappingAttribute : Attribute
    {
        private string m_ColumnName;
        private DbType m_DbType;

        public DataMappingAttribute(string columnName, DbType dbType)
        {
            m_ColumnName = columnName;
            m_DbType = dbType;
        }

        public string ColumnName
        {
            get { return m_ColumnName; }
        }

        public DbType DbType
        {
            get { return m_DbType; }
        }
    }
}
