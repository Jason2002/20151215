﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newegg.Oversea.DataAccess.Config;
using Newegg.Oversea.DataAccess.DbProvider;

namespace Newegg.Oversea.DataAccess
{
    public class DAConfigFileWatcher : FileWatcherBase
    {
        protected override string GetWatchFolderPath()
        {
            string dbListPath = string.Empty;
            if (ConfigHelper.ConfigDirectory != null)
            {
                dbListPath = ConfigHelper.ConfigDirectory;
            }
            else
            {
                dbListPath = ConfigHelper.DatabaseListFilePath;
            }
            string watchFolderPath = dbListPath.Substring(0, dbListPath.LastIndexOf("\\"));
            return watchFolderPath;
        }

        protected override string GetWatchFileFilter()
        {
            return "*.config";
        }

        protected override void ProcessLoadFile(string filePath)
        {
            base.ProcessLoadFile(filePath);
            ClearCache();

        }

        protected override void ProceeeRemoveFile(string filePath)
        {
            base.ProceeeRemoveFile(filePath);
            ClearCache();
        }

        private void ClearCache()
        {
            ConnectionStringManager.ClearCache();
            DataCommandManager.ClearCache();
        }
    }
}
