﻿namespace Newegg.Oversea.DataAccess.RandomData.Attributes
{
    public interface IRandomGenerator
    {
        object GenerateValue();
    }
}