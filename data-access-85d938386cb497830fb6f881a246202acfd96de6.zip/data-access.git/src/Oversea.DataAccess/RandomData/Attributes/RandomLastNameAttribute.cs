﻿using System;
using Newegg.Oversea.DataAccess.RandomData.Helpers;

namespace Newegg.Oversea.DataAccess.RandomData.Attributes
{
    public class RandomLastNameAttribute : Attribute, IRandomGenerator
    {
        public object GenerateValue()
        {
            var lnGenerator = LastNameGenerator.Instance;
            var randomNum = RandomNumberGenerator.Instance.NextRandom(lnGenerator.Count);
            return lnGenerator.GetLastName(randomNum);
        }
    }
}