﻿using System;
using Newegg.Oversea.DataAccess.RandomData.Helpers;

namespace Newegg.Oversea.DataAccess.RandomData.Attributes
{
    public class IdentityAttribute : Attribute, IRandomGenerator
    {
        private readonly int _step;
        public IdentityAttribute(int step)
        {
            _step = step;
        }

        public object GenerateValue()
        {
            return IdentityGenerator.Instance.GetNextNum(_step);
        }
    }
}