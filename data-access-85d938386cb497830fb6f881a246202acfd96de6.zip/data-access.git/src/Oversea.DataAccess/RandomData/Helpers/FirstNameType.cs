﻿namespace Newegg.Oversea.DataAccess.RandomData.Helpers
{
    public enum FirstNameType
    {
        MALE, FEMALE
    }
}