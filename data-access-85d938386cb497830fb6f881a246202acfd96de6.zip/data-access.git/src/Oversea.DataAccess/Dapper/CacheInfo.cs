﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;

namespace Newegg.Oversea.DataAccess
{
    /// <summary>
    /// This is a micro-cache; suitable when the number of terms is controllable (a few hundred, for example),
    /// and strictly append-only; you cannot change existing values. All key matches are on **REFERENCE**
    /// equality. The type is fully thread-safe.
    /// </summary>
    internal class CacheInfo
    {
        public DeserializerState Deserializer { get; set; }
        public Func<IDataReader, object>[] OtherDeserializers { get; set; }
        public Action<IDbCommand, object> ParamReader { get; set; }
        private int hitCount;
        public int GetHitCount() { return Interlocked.CompareExchange(ref hitCount, 0, 0); }
        public void RecordHit() { Interlocked.Increment(ref hitCount); }
    }
}
