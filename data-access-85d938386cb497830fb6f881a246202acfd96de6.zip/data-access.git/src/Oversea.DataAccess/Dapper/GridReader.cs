﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Newegg.Oversea.DataAccess
{
    /// <summary>
    /// The grid reader provides interfaces for reading multiple result sets from a Dapper query 
    /// </summary>
    public class GridReader : IDisposable
    {
        private IDataReader reader;
        private IDbCommand command;
        private Identity identity;
        private ConnectionWrapper conn;
        public ConnectionWrapper Connection
        {
            get
            {
                return conn;
            }
            set
            {
                conn = value;
            }
        }

        internal GridReader(IDbCommand command, IDataReader reader, Identity identity)
        {
            this.command = command;
            this.reader = reader;
            this.identity = identity;
        }



        /// <summary>
        /// Read the next grid of results, returned as a dynamic object
        /// </summary>
        public IEnumerable<dynamic> Read(bool buffered = true)
        {
            return Read<DapperRow>(buffered);
        }

        /// <summary>
        /// Read the next grid of results
        /// </summary>

        public IEnumerable<T> Read<T>(bool buffered = true)
        {
            if (reader == null) throw new ObjectDisposedException(GetType().FullName, "The reader has been disposed; this can happen after all data has been consumed");
            if (consumed) throw new InvalidOperationException("Query results must be consumed in the correct order, and each result can only be consumed once");
            var typedIdentity = identity.ForGrid(typeof(T), gridIndex);
            CacheInfo cache = SqlMapper.GetCacheInfo(typedIdentity);
            var deserializer = cache.Deserializer;

            int hash = SqlMapper.GetColumnHash(reader);
            if (deserializer.Func == null || deserializer.Hash != hash)
            {
                deserializer = new DeserializerState(hash, SqlMapper.GetDeserializer(typeof(T), reader, 0, -1, false));
                cache.Deserializer = deserializer;
            }
            consumed = true;
            var result = ReadDeferred<T>(gridIndex, deserializer.Func, typedIdentity);
            return buffered ? result.ToList() : result;
        }

        private IEnumerable<TReturn> MultiReadInternal<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(object func, string splitOn)
        {
            var identity = this.identity.ForGrid(typeof(TReturn), new Type[] { 
                    typeof(TFirst), 
                    typeof(TSecond),
                    typeof(TThird),
                    typeof(TFourth),
                    typeof(TFifth)
                }, gridIndex);
            try
            {
                foreach (var r in SqlMapper.MultiMapImpl<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(null, null, func, null, null, splitOn, null, null, reader, identity))
                {
                    yield return r;
                }
            }
            finally
            {
                NextResult();
            }
        }


        /// <summary>
        /// Read multiple objects from a single recordset on the grid
        /// </summary>
        public IEnumerable<TReturn> Read<TFirst, TSecond, TReturn>(Func<TFirst, TSecond, TReturn> func, string splitOn = "id", bool buffered = true)
        {
            var result = MultiReadInternal<TFirst, TSecond, DontMap, DontMap, DontMap, TReturn>(func, splitOn);
            return buffered ? result.ToList() : result;
        }

        /// <summary>
        /// Read multiple objects from a single recordset on the grid
        /// </summary>
        public IEnumerable<TReturn> Read<TFirst, TSecond, TThird, TReturn>(Func<TFirst, TSecond, TThird, TReturn> func, string splitOn = "id", bool buffered = true)
        {
            var result = MultiReadInternal<TFirst, TSecond, TThird, DontMap, DontMap, TReturn>(func, splitOn);
            return buffered ? result.ToList() : result;
        }


        /// <summary>
        /// Read multiple objects from a single record set on the grid
        /// </summary>
        public IEnumerable<TReturn> Read<TFirst, TSecond, TThird, TFourth, TReturn>(Func<TFirst, TSecond, TThird, TFourth, TReturn> func, string splitOn = "id", bool buffered = true)
        {
            var result = MultiReadInternal<TFirst, TSecond, TThird, TFourth, DontMap, TReturn>(func, splitOn);
            return buffered ? result.ToList() : result;
        }




        /// <summary>
        /// Read multiple objects from a single record set on the grid
        /// </summary>
        public IEnumerable<TReturn> Read<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(Func<TFirst, TSecond, TThird, TFourth, TFifth, TReturn> func, string splitOn = "id", bool buffered = true)
        {
            var result = MultiReadInternal<TFirst, TSecond, TThird, TFourth, TFifth, TReturn>(func, splitOn);
            return buffered ? result.ToList() : result;
        }

        private IEnumerable<T> ReadDeferred<T>(int index, Func<IDataReader, object> deserializer, Identity typedIdentity)
        {
            try
            {
                while (index == gridIndex && reader.Read())
                {
                    yield return (T)deserializer(reader);
                }
            }
                finally // finally so that First etc progresses things even when multiple rows
            {
                if (index == gridIndex)
                {
                    NextResult();
                }
            }
        }
        private int gridIndex, readCount;
        private bool consumed;
        private void NextResult()
        {
            if (reader.NextResult())
            {
                readCount++;
                gridIndex++;
                consumed = false;
            }
            else
            {
                // happy path; close the reader cleanly - no
                // need for "Cancel" etc
                reader.Dispose();
                reader = null;

                Dispose();
            }

        }
        /// <summary>
        /// Dispose the grid, closing and disposing both the underlying reader and command.
        /// </summary>
        public void Dispose()
        {
            if (reader != null)
            {
                if (!reader.IsClosed && command != null) command.Cancel();
                reader.Dispose();
                reader = null;
            }
            if (conn != null)
            {
                conn.Dispose();
            }
            if (command != null)
            {
                command.Dispose();
                command = null;
            }
        }
    }
}
