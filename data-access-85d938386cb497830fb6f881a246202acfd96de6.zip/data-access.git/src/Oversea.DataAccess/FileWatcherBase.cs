﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace Newegg.Oversea.DataAccess
{
    public interface IStartup
    {
        void Start();
    }

    public interface IShutdown
    {
        void Shut();
    }

    public abstract class FileWatcherBase : IStartup, IShutdown
    {
        private FileSystemWatcher m_Watcher;
        private Timer s_Timer;
        protected const int TimeoutMillis = 500; // 0.5 second
        private List<string> s_LoadFileList = new List<string>();
        private List<string> s_RemoveFileList = new List<string>();
        protected object s_SyncLoadObj = new object();
        protected object s_SyncRemoveObj = new object();
        protected string s_ResouceBaseFolder;

        public FileWatcherBase()
        {
            s_Timer = new Timer(new TimerCallback(FileChanged_TimerChanged), null, Timeout.Infinite, Timeout.Infinite);
        }

        protected abstract string GetWatchFolderPath();


        protected virtual string GetWatchFileFilter()
        {
            return "*.xml";
        }
        protected virtual void InitDataBeginWatch(string folderPath, string fileFilter)
        {
            // do nothing
        }

        protected virtual void ProcessLoadFile(string filePath)
        {
            // do nothing
        }
        protected virtual void ProceeeRemoveFile(string filePath)
        {
            // do nothing
        }


        #region IStartup methods

        public void Start()
        {
            this.BeginWatch();
        }

        #endregion


        #region IShutdown methods

        public void Shut()
        {
            this.EndWatch();
        }

        #endregion


        public void BeginWatch()
        {
            string folderPath = GetWatchFolderPath();
            string filter = GetWatchFileFilter();

            if (m_Watcher != null)
            {
                DisposeWatcher(m_Watcher);
            }
            folderPath = new DirectoryInfo(folderPath).FullName;
            s_ResouceBaseFolder = folderPath.ToUpper();
            m_Watcher = new FileSystemWatcher();

            m_Watcher.Deleted += new FileSystemEventHandler(Watcher_Deleted);
            m_Watcher.Renamed += new RenamedEventHandler(Watcher_Renamed);
            m_Watcher.Changed += new FileSystemEventHandler(Watcher_Changed);
            m_Watcher.Created += new FileSystemEventHandler(Watcher_Created);

            //监控路径（文件夹）
            m_Watcher.Path = folderPath;
            //是否包含子目录
            m_Watcher.IncludeSubdirectories = true;
            //如果filter为文件名称则表示监控该文件，如果为*.txt则表示要监控指定目录当中的所有.txt文件,如果为*.*表示所有的文件
            m_Watcher.Filter = filter;
            m_Watcher.NotifyFilter = NotifyFilters.LastWrite
                                            | NotifyFilters.FileName
                                            | NotifyFilters.Size;

            //开始初始化所有需要监控的文件
            InitDataBeginWatch(folderPath, filter);

            //begin watching.
            m_Watcher.EnableRaisingEvents = true;
        }

        public void EndWatch()
        {
            if (m_Watcher != null)
            {
                DisposeWatcher(m_Watcher);
                m_Watcher = null;
            }
        }

        private void AddLoadFile(string filePath)
        {
            string path = filePath.ToUpper();
            if (!s_LoadFileList.Contains(path))
            {
                lock (s_SyncLoadObj)
                {
                    if (!s_LoadFileList.Contains(path))
                    {
                        s_LoadFileList.Add(path);
                    }
                }
            }
        }

        private void AddRemoveFile(string filePath)
        {
            string path = filePath.ToUpper();
            if (!s_RemoveFileList.Contains(path))
            {
                lock (s_SyncRemoveObj)
                {
                    if (!s_RemoveFileList.Contains(path))
                    {
                        s_RemoveFileList.Add(path);
                    }
                }
            }
        }

        private void FileChanged_TimerChanged(object state)
        {
            // 处理待加载入内存的资源文件列表
            if (s_LoadFileList.Count > 0)
            {
                lock (s_SyncLoadObj)
                {
                    if (s_LoadFileList.Count > 0)
                    {
                        List<string> tmp = new List<string>(s_LoadFileList);
                        foreach (var filePath in tmp)
                        {
                            ProcessLoadFile(filePath);
                        }
                        s_LoadFileList.Clear();
                    }
                }
            }

            // 处理待从内存移除的资源文件列表
            if (s_RemoveFileList.Count > 0)
            {
                lock (s_SyncRemoveObj)
                {
                    if (s_RemoveFileList.Count > 0)
                    {
                        List<string> tmp = new List<string>(s_RemoveFileList);
                        foreach (var filePath in tmp)
                        {
                            ProceeeRemoveFile(filePath);
                        }
                        s_RemoveFileList.Clear();
                    }
                }
            }
        }

        private void Watcher_Created(object sender, FileSystemEventArgs e)
        {
            AddLoadFile(e.FullPath);
            s_Timer.Change(TimeoutMillis, Timeout.Infinite);
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            AddLoadFile(e.FullPath);
            s_Timer.Change(TimeoutMillis, Timeout.Infinite);
        }

        private void Watcher_Renamed(object sender, RenamedEventArgs e)
        {
            AddLoadFile(e.FullPath);
            AddRemoveFile(e.OldFullPath);
            s_Timer.Change(TimeoutMillis, Timeout.Infinite);
        }

        private void Watcher_Deleted(object sender, FileSystemEventArgs e)
        {
            AddRemoveFile(e.FullPath);
            s_Timer.Change(TimeoutMillis, Timeout.Infinite);
        }

        private void DisposeWatcher(FileSystemWatcher watcher)
        {
            watcher.EnableRaisingEvents = false;
            watcher.Deleted -= Watcher_Deleted;
            watcher.Renamed -= Watcher_Renamed;
            watcher.Changed -= Watcher_Changed;
            watcher.Created -= Watcher_Created;
            watcher.Dispose();
        }
    }
}
