﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.FrameworkAPI.SDK.MQ;

namespace Newegg.Framework.RedisCloud
{
    public class RedisCloudNotify
    {
        public void Hset(string msgTypeName, ulong ridc, int dbid, string hashId, string entryKey, string entryValue)
        {
            var request = new RedisCloudHsetRequest();
            request.Ridc = ridc;
            request.DBID = dbid;
            request.Key = hashId;
            request.Value = new KeyValuePair<string, string>(entryKey, entryValue);
            this.Send(msgTypeName, request);
        }

        public void Hmset(string msgTypeName, ulong ridc, int dbid, string hashId, IEnumerable<KeyValuePair<string, string>> keyValuePairs)
        {
            var request = new RedisCloudHmsetRequest();
            request.Ridc = ridc;
            request.DBID = dbid;
            request.Key = hashId;
            request.Value = keyValuePairs;
            this.Send(msgTypeName, request);
        }

        public void Hdel(string msgTypeName, ulong ridc, int dbid, string hashId, params string[] entryKeys)
        {
            var request = new RedisCloudHdelRequest();
            request.Ridc = ridc;
            request.DBID = dbid;
            request.Key = hashId;
            request.Value = entryKeys;
            this.Send(msgTypeName, request);
        }

        public void Del(string msgTypeName, ulong ridc, int dbid, params string[] keys)
        {
            var request = new RedisCloudDelRequest();
            request.Ridc = ridc;
            request.DBID = dbid;
            request.Key = keys;
            this.Send(msgTypeName, request);
        }

        public void Set(string msgTypeName, ulong ridc, int dbid, string key, string value)
        {
            var request = new RedisCloudSetRequest
            {
                Ridc = ridc, 
                DBID = dbid, 
                Key = key, 
                Value = value
            };
            this.Send(msgTypeName, request);
        }

        public void Mset(string msgTypeName, ulong ridc, int dbid, IEnumerable<KeyValuePair<string, string>> keyValuePairs)
        {
            var request = new RedisCloudMsetRequest
            {
                Ridc = ridc,
                DBID = dbid,
                Mutations = keyValuePairs
            };
            this.Send(msgTypeName, request);
        }

        public void Send(string msgTypeName, RedisCloudBaseRequest request)
        {
            if (!string.IsNullOrWhiteSpace(msgTypeName))
            {
                var publishResult = MessagePublisher.SendMessageJson(request, msgTypeName, string.Empty);
                if (!publishResult.IsSucceed)
                {
                    throw new ApplicationException("Send message failed: " + publishResult.ErrorMessage);
                }
            }
        }
    }
}
