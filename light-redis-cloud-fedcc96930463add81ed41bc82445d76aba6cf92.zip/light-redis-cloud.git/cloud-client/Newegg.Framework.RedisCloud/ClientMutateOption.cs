﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.RedisCloud
{
    [Flags]
    public enum ClientMutateOption
    {
        Local = 1 << 0,
        Message = 1 << 1
    }
}
