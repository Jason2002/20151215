﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using Newegg.Framework.RedisCloud.Attributes;
using ServiceStack.Common;
using ServiceStack.Redis;
using ServiceStack.Text;

namespace Newegg.Framework.RedisCloud
{
    public class RedisCloudClient
    {
        private IRedisClientsManager m_redisClientsManager = null;
        private RedisCloudNotify m_redisCloudNotify = new RedisCloudNotify();

        private ClientMutateOption MutateOption { get; set; }

        public string MsgTypeName { get; set; }

        public int Db { get; set; }

        public RedisCloudClient(IRedisClientsManager rcm, int db,
            ClientMutateOption mutateOption = ClientMutateOption.Local | ClientMutateOption.Message)
        {
            m_redisClientsManager = rcm;
            MutateOption = mutateOption;
            Db = db;
        }

        public void SetEntryInHash<T>(string hashId, T entity)
        {
            string entryKey = GetPrimaryKeyValue(entity);
            string entryValue = entity.ToJson();

            //如果field是哈希表中的一个新建域，并且值设置成功，返回1。
            //如果哈希表中域field已经存在且旧值已被新值覆盖，返回0。
            Mutate(
                (IRedisTransaction trans) =>
                {
                    trans.QueueCommand(rc => rc.SetEntryInHash(hashId, entryKey, entryValue));
                },
                (ulong ridc) => { m_redisCloudNotify.Hset(MsgTypeName, ridc, Db, hashId, entryKey, entryValue); });
        }

        public void SetRangeInHash<T>(string hashId, IEnumerable<T> entities)
        {
            Dictionary<string, string> keyValuePairs = new Dictionary<string, string>();
            foreach (var entity in entities)
            {
                string key = GetPrimaryKeyValue(entity);
                if (false == keyValuePairs.ContainsKey(key))
                {
                    keyValuePairs.Add(key, entity.ToJson());
                }
            }

            Mutate(
                (IRedisTransaction trans) => { trans.QueueCommand(rc => rc.SetRangeInHash(hashId, keyValuePairs)); },
                (ulong ridc) => { m_redisCloudNotify.Hmset(MsgTypeName, ridc, Db, hashId, keyValuePairs); });
        }

        public void Delete(string key)
        {
            this.Delete(new List<string>() { key });
        }

        public void Delete(List<string> keys)
        {
            Mutate(
                (IRedisTransaction trans) => { trans.QueueCommand(rc => rc.RemoveEntry(keys.ToArray())); },
                (ulong ridc) => { m_redisCloudNotify.Del(MsgTypeName, ridc, Db, keys.ToArray()); });
        }

        [Obsolete]
        public void RemoveEntry(params string[] keys)
        {
            Mutate(
                (IRedisTransaction trans) => { trans.QueueCommand(rc => rc.RemoveEntry(keys)); },
                (ulong ridc) => { m_redisCloudNotify.Del(MsgTypeName, ridc, Db, keys); });
        }

        public void RemoveEntryFromHash(string hashId, params string[] entryKeys)
        {
            Mutate(
                (IRedisTransaction trans) =>
                {
                    //try pipeline 
                    foreach (var entryKey in entryKeys)
                    {
                        trans.QueueCommand(rc => rc.RemoveEntryFromHash(hashId, entryKey));
                    }
                },
                (ulong ridc) => { m_redisCloudNotify.Hdel(MsgTypeName, ridc, Db, hashId, entryKeys); });
        }

        public void RemoveEntryFromHash<T>(string hashId, T entity)
        {
            string entryKey = GetPrimaryKeyValue(entity);
            this.RemoveEntryFromHash(hashId, entryKey);
        }

        public void Set(string key, string value)
        {
            Mutate(
                (IRedisTransaction trans) =>
                {
                    trans.QueueCommand(rc => rc.SetEntry(key, value));
                },
                (ulong ridc) => m_redisCloudNotify.Set(MsgTypeName, ridc, Db, key, value));
        }

        public void SetEntity<T>(T entity)
        {
            this.Set(GetPrimaryKeyValue(entity), entity.ToJson());
        }

        public void Set(IEnumerable<KeyValuePair<string,string>> keyValues)
        {
            Mutate(
                (IRedisTransaction trans) =>
                {
                    foreach (var kv in keyValues)
                    {
                        trans.QueueCommand(rc => rc.SetEntry(kv.Key, kv.Value));
                    }
                },
                (ulong ridc) => m_redisCloudNotify.Mset(MsgTypeName, ridc, Db, keyValues));
        }

        public void SetEntityList<T>(IEnumerable<T> entities)
        {
            var keyValues = new Dictionary<string, string>();
            foreach (var entity in entities)
            {
                keyValues.Add(GetPrimaryKeyValue(entity), entity.ToJson());
            }

            this.Set(keyValues);
        }

        public string Get(string key)
        {
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                return redisClient.GetValue(key);
            }
        }

        public T GetEntity<T>(string key)
        {
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                return redisClient.Get<T>(key);
            }
        }

        public List<T> GetEntityList<T>(List<string> keys)
        {
            if (keys.IsEmpty()) return new List<T>();
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                return redisClient.GetAll<T>(keys).Values.Where(v => v != null).ToList();
            }
        }

        public Dictionary<string, string> GetValuesMap(List<string> keys)
        {
            if (keys.IsEmpty()) return new Dictionary<string, string>();
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                return redisClient.GetValuesMap(keys);
            }
        }

        public Dictionary<string, T> GetValuesMap<T>(List<string> keys)
        {
            if (keys.IsEmpty()) return new Dictionary<string, T>();
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                return redisClient.GetValuesMap<T>(keys);
            }
        }

        public T GetValueFromHash<T>(string hashId, string entryKey)
        {
            string redisValue = string.Empty;
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                redisValue = redisClient.GetValueFromHash(hashId, entryKey);
            }

            if (string.IsNullOrWhiteSpace(redisValue))
            {
                return default(T);
            }
            return redisValue.FromJson<T>();
        }

        public IList<T> GetValuesFromHash<T>(string hashId, params string[] keys)
        {
            IList<string> redisValues = null;
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                redisValues = redisClient.GetValuesFromHash(hashId, keys);
            }
            var results = new List<T>();
            foreach (var value in redisValues)
            {
                results.Add(value.FromJson<T>());
            }

            return results;
        }

        public List<T> GetHashValues<T>(string hashId)
        {
            List<string> redisValues = null;
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                redisValues = redisClient.GetHashValues(hashId);
            }

            var results = new List<T>();
            foreach (var value in redisValues)
            {
                results.Add(value.FromJson<T>());
            }

            return results;
        }

        public List<string> GetHashKeys(string hashId)
        {
            using (IRedisClient redisClient = m_redisClientsManager.GetReadOnlyClient())
            {
                return redisClient.GetHashKeys(hashId);
            }
        }

        private static string GetPrimaryKeyValue<T>(T entity)
        {
            var properties =
                typeof (T).GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
            PropertyInfo propInfoRes =
                properties.FirstOrDefault(
                    property => property.GetCustomAttributes(typeof (PrimaryKeyAttribute), false).Length > 0);
            if (propInfoRes == null)
            {
                throw new ApplicationException("not found primary key value.");
            }
            return propInfoRes.GetValue(entity, null).ToString();
        }

        private void Mutate(Action<IRedisTransaction> writeLocalAction, Action<ulong> sendMessageAction)
        {
            if (((MutateOption & ClientMutateOption.Local) == ClientMutateOption.Local)
                && ((MutateOption & ClientMutateOption.Message) == ClientMutateOption.Message))
            {
                using (IRedisClient redisClient = m_redisClientsManager.GetClient())
                {
                    ulong ridc = Crc32Helper.GetCrc32Hash(redisClient);
                    using (var trans = redisClient.CreateTransaction())
                    {
                        writeLocalAction(trans);
                        sendMessageAction(ridc);

                        trans.Commit();
                    }
                }
            }
            else if ((MutateOption & ClientMutateOption.Local) == ClientMutateOption.Local)
            {
                using (IRedisClient redisClient = m_redisClientsManager.GetClient())
                using (var trans = redisClient.CreateTransaction())
                {
                    writeLocalAction(trans);

                    trans.Commit();
                }
            }
            else if ((MutateOption & ClientMutateOption.Message) == ClientMutateOption.Message)
            {
                sendMessageAction(0);
            }
        }
    }

    #region units test

    internal class ZeeEntity
    {
        [PrimaryKey]
        public string Id { get; set; }

        public string Name { get; set; }
    }

    internal class Test_RedisCloudClient
    {
        private RedisCloudClient client = CloudClientFactory.GetCloudClient();

        public Test_RedisCloudClient()
        {
            client.MsgTypeName = "NcfProfileSyncNotify";
        }

        private void Test_SetEntryInHash()
        {
            ZeeEntity zee = new ZeeEntity()
            {
                Id = "HZd123",
                Name = "zeeman140117"
            };


            string hashId = "urn:ZeeEntities";

            for (int i = 0; i < 1; i++)
            {
                client.SetEntryInHash<ZeeEntity>(hashId, zee);
            }

            //hashId = "urn:ZeeEntities2";

            //client.SetEntryInHash<ZeeEntity>(hashId, zee);
        }

        private void Test_SetRangeInHash()
        {
            List<ZeeEntity> list = new List<ZeeEntity>();

            ZeeEntity zee = new ZeeEntity()
            {
                Id = "100",
                Name = "zeeman"
            };
            list.Add(zee);

            zee = new ZeeEntity()
            {
                Id = "300",
                Name = "zeeman3"
            };
            list.Add(zee);

            string hashId = "urn:ZeeEntities";

            client.SetRangeInHash<ZeeEntity>(hashId, list);
        }

        private void Test_GetValueFromHash()
        {
            RedisCloudClient client = CloudClientFactory.GetCloudClient();
            string hashId = "urn:ZeeEntities";

            var result = client.GetValueFromHash<ZeeEntity>(hashId, "100");
        }

        private void Test_RemoveEntryFromHash()
        {
            //string hashId = "urn:ZeeEntities";

            //client.RemoveEntryFromHash<ZeeEntity>(hashId, "100");
            string hashId = "urn:Configuration";
            client.RemoveEntryFromHash(hashId, "1282");
        }

        private void Test_GetHashValues()
        {
            RedisCloudClient client = CloudClientFactory.GetCloudClient();
            string hashId = "urn:ZeeEntities";

            var result = client.GetHashValues<ZeeEntity>(hashId);
        }

        private void Test_RemoveEntry()
        {
            string hashId = "urn:ZeeEntities";
            string hashId2 = "urn:ZeeEntities2";
            client.RemoveEntry(hashId, hashId2);
        }

        private void Test_Set()
        {
            ZeeEntity zee = new ZeeEntity()
            {
                Id = "zee1000",
                Name = "zeeman. from units testing 1000"
            };
            client.SetEntity(zee);

            var result = client.GetEntity<ZeeEntity>(zee.Id);
        }

        private void Test_Set2()
        {
            client.Set("zee10001", "zeeman. from units testing 10001");

            var result = client.GetEntity<string>("zee10001");

            var result2 = client.Get("zee10001");
        }

        private void Test_Del()
        {
            client.RemoveEntry("zee10000s");

            client.Delete("zee20000s");

            var result2 = client.Get("zee20000s");
        }

        private void Test_Mset()
        {
            List<ZeeEntity> list = new List<ZeeEntity>();

            ZeeEntity zee1 = new ZeeEntity()
            {
                Id = "zee10000s",
                Name = "zee10000s name 1"
            };
            list.Add(zee1);

            ZeeEntity zee2 = new ZeeEntity()
            {
                Id = "zee20000s",
                Name = "zee2000s name 2"
            };
            list.Add(zee2);

            client.SetEntityList(list);

            var result = client.GetValuesMap<ZeeEntity>(new List<string>() {zee1.Id, zee2.Id});

            var result2 = client.GetEntityList<ZeeEntity>(new List<string>() { zee1.Id, zee2.Id });

            var result3 = client.GetEntityList<ZeeEntity>(new List<string>() { "xxxxx" });
        }

        private void Test_Mset2()
        {
            var keyValues = new Dictionary<string, string>();

            keyValues.Add("zee10000kv", "zee10000kv name");
            keyValues.Add("zee20000kv", "zee20000kv name");

            client.Set(keyValues);

            var result = client.GetValuesMap(new List<string>() { "zee1000kv", "zee2000kv" });

        }

        private void Test_Get()
        {
            var result = client.GetEntity<string>("zeetest");
        }

        private void Test_Mget()
        {
            List<string> keys = new List<string>();
            keys.Add("zeetest");
            keys.Add("zeetest1");
            var result = client.GetValuesMap<string>(keys);
        }
    }

    #endregion
}