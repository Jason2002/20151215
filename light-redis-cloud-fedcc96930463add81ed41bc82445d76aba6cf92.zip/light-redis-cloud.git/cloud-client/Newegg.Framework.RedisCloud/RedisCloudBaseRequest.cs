﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Framework.RedisCloud
{
    public abstract class RedisCloudBaseRequest
    {
        /// <summary>
        /// run_id crc32
        /// </summary>
        public ulong Ridc { get; set; }

        public int DBID { get; set; }

        public string Command { get; set; }
    }

    public class RedisCloudHsetRequest : RedisCloudBaseRequest
    {
        public RedisCloudHsetRequest()
        {
            this.Command = "hset";
        }

        public string Key { get; set; }
        public KeyValuePair<string, string> Value { get; set; }
    }

    public class RedisCloudHmsetRequest : RedisCloudBaseRequest
    {
        public RedisCloudHmsetRequest()
        {
            this.Command = "hmset";
        }

        public string Key { get; set; }
        public IEnumerable<KeyValuePair<string, string>> Value { get; set; }
    }

    public class RedisCloudHdelRequest : RedisCloudBaseRequest
    {
        public RedisCloudHdelRequest()
        {
            this.Command = "hdel";
        }

        public string Key { get; set; }
        public IEnumerable<string> Value { get; set; }
    }

    public class RedisCloudDelRequest : RedisCloudBaseRequest
    {
        public RedisCloudDelRequest()
        {
            this.Command = "del";
        }

        public IEnumerable<string> Key { get; set; }
    }

    public class RedisCloudSetRequest : RedisCloudBaseRequest
    {
        public RedisCloudSetRequest()
        {
            this.Command = "set";
        }

        public string Key { get; set; }

        public string Value { get; set; }
    }

    public class RedisCloudMsetRequest : RedisCloudBaseRequest
    {
        public RedisCloudMsetRequest()
        {
            this.Command = "mset";
        }

        public IEnumerable<KeyValuePair<string, string>> Mutations { get; set; }
    }
}
