﻿/******************************************************************
* Copyright (c): 	2013 NESC All Rights Reserved.
* CLR版本: 			4.0.30319.17929
* 命名空间名称: 	Newegg.Oversea.Silverlight.ControlPanel.Service.DataAccess
* 文件名: 			RedisClientExtension
* 创建人：  		rx51
* 创建时间: 		12/26/2013 9:04:14 AM
******************************************************************/

using System;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections;
using System.Configuration;
using System.Collections.Generic;

using ServiceStack.Text;
using ServiceStack.Redis;
using ServiceStack.DataAccess;
using Newegg.Framework.RedisCloud.Attributes;

namespace Newegg.Framework.RedisCloud
{
    internal sealed class RedisClientExtension<T> : IBasicPersistenceProvider<T>
    {
        #region variable parameter
        private static RedisCloudElement _redisCloudElement;

        private readonly BasicRedisClientManager m_clientmanager;

        private readonly IRedisClient m_client;

        private static readonly string _typeIdsSetIdentity = "TypeIdsSetIdentity";

        private readonly string _typedIdsSetKey;
        #endregion

        #region constructor
        static RedisClientExtension()
        {
            var redisCloudConfiguration = ConfigurationManager.GetSection("redisCloudConfiguration") as RedisCloudConfiguration;
            _redisCloudElement = redisCloudConfiguration.Clouds[redisCloudConfiguration.DefaultCloud];
        }

        private RedisClientExtension()
        {
            string[] readWrite = _redisCloudElement.ReadWriteHosts.ToStringArray();
            m_clientmanager = new BasicRedisClientManager(readWrite, null, _redisCloudElement.InitalDb);
            m_client = m_clientmanager.GetClient();
            _typedIdsSetKey = UrnId.Create<T>(_typeIdsSetIdentity);
        }

        public int Db
        {
            get
            {
                return m_clientmanager.Db;
            }
        }
        #endregion

        #region private method
        private void DeleteKeyFromSet(string key)
        {
            m_client.RemoveItemFromSet(_typedIdsSetKey, key);
        }

        private bool DeleteByKey(string key)
        {
            bool res = m_client.Remove(key);
            if (res)
            {
                DeleteKeyFromSet(key);
            }
            return res;
        }
        #endregion

        #region public method
        public string GetPrimaryKeyValue(T entity)
        {
            PropertyInfo propInfoRes = null;
            var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
            foreach (var property in properties)
            {
                if (property.GetCustomAttributes(typeof(PrimaryKeyAttribute), false).Length > 0)
                {
                    propInfoRes = property;
                    break;
                }
            }
            if (propInfoRes == null)
            {
                throw new ApplicationException("not found primary key value.");
            }
            return propInfoRes.GetValue(entity, null).ToString();
        }

        public string GetUrn(T entity)
        {
            return UrnId.Create<T>(GetPrimaryKeyValue(entity));
        }

        public string GetUrn(object id)
        {
            string key;
            if (id is T)
            {
                key = GetUrn((T)id);
            }
            else if (id is System.String || id is Guid || id is int || id is long)
            {
                key = UrnId.Create<T>(id.ToString());
            }
            else
            {
                throw new ArgumentException("typeof id must be string or T");
            }
            return key;
        }

        public void Delete(T entity)
        {
            if (null == entity) return;
            var key = GetUrn(entity);
            DeleteByKey(key);
        }
        public void DeleteAll()
        {
            var allKeys = m_client.GetAllItemsFromSet(_typedIdsSetKey);
            foreach (var key in allKeys)
            {
                DeleteByKey(key);
            }
        }
        public void DeleteById(object id)
        {
            if (null == id) return;
            var key = GetUrn(id);
            DeleteByKey(key);
        }
        public void DeleteByIds(IEnumerable ids)
        {
            foreach (var id in ids ?? Enumerable.Empty<object>())
            {
                DeleteById(id);
            }
        }
        public IList<T> GetAll()
        {
            var allKeys = m_client.GetAllItemsFromSet(_typedIdsSetKey);
            return m_client.GetValues<T>(allKeys.ToList());
        }
        public T GetById(object id)
        {
            if (null == id) return default(T);
            var key = GetUrn(id);
            return m_client.Get<T>(key);
        }
        public IList<T> GetByIds(IEnumerable ids)
        {
            var resultlist = new List<T>();
            foreach (var id in ids ?? Enumerable.Empty<object>())
            {
                var value = GetById(id);
                if (null != value)
                {
                    resultlist.Add(value);
                }
            }
            return resultlist;
        }
        public T Store(T entity)
        {
            if (null == entity) return default(T);
            var key = GetUrn(entity);
            if (!m_client.Set<T>(key, entity))
            {
                entity = default(T);
            }
            else
            {
                m_client.AddItemToSet(_typedIdsSetKey, key);
            }
            return entity;
        }
        public void StoreAll(IEnumerable<T> entities)
        {
            foreach (var entity in entities ?? Enumerable.Empty<T>())
            {
                Store(entity);
            }
        }

        public bool SetEntryInHash(string hashId, string key, string value)
        {
            return m_client.SetEntryInHash(hashId, key, value);
        }

        public void SetRangeInHash(string hashId, IEnumerable<KeyValuePair<string, string>> keyValuePairs)
        {
            m_client.SetRangeInHash(hashId, keyValuePairs);
        }

        public bool RemoveEntryFromHash(string hashId, string key)
        {
            return m_client.RemoveEntryFromHash(hashId, key);
        }

        public List<string> GetValuesFromHash(string hashId, params string[] keys)
        {
            return m_client.GetValuesFromHash(hashId, keys);
        }

        public string GetValueFromHash(string hashId, string key)
        {
            return m_client.GetValueFromHash(hashId, key);
        }

        public List<string> GetHashKeys(string hashId)
        {
            return m_client.GetHashKeys(hashId);
        }

        public List<string> GetHashValues(string hashId)
        {
            return m_client.GetHashValues(hashId);
        }

        [Obsolete("Does nothing currently", true)]
        public void Dispose() { }
        #endregion
    }

    #region units test
    /*
    [TestFixture]
    public class RedisClientExtensionTest
    {
        public class TestEntity
        {
            public string DisplayName { get; set; }

            public string Description { get; set; }

            [PrimaryKey]
            public Guid TestEntityId { get; set; }

            public int ReferenceCount { get; set; }
        }

        private IList<TestEntity> testobjlist = null;
        private readonly int listCount = 2;

        [TestFixtureSetUp]
        public void InitBeforeAllTests()
        {
            testobjlist = new List<TestEntity>();
            for (int i = 0; i < listCount; i++)
            {
                TestEntity testobj = new TestEntity();
                testobj.TestEntityId = Guid.NewGuid();
                testobj.ReferenceCount++;
                testobjlist.Add(testobj);
            }
        }

        [TestFixtureTearDown]
        public void DeInitBeforeAllTests()
        {
            for (int i = listCount - 1; i > -1; i--)
            {
                testobjlist.RemoveAt(i);
            }
            testobjlist = null;
        }

        [Test]
        public void TestStoreAndGetById()
        {
            TestEntity storeRes;
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.Store(null);
            Assert.IsNull(storeRes);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.Store(testobjlist[0]);
            Assert.AreEqual(storeRes, testobjlist[0]);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetById(null);
            Assert.IsNull(storeRes);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetById(testobjlist[0]);
            Assert.NotNull(storeRes);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetById(testobjlist[0].TestEntityId);
            Assert.NotNull(storeRes);
            TSingleton<RedisClientExtension<TestEntity>>.Instance.Delete(testobjlist[0]);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetById(testobjlist[0].TestEntityId);
            Assert.Null(storeRes);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.Store(testobjlist[1]);
            Assert.NotNull(storeRes);
            TSingleton<RedisClientExtension<TestEntity>>.Instance.DeleteById(testobjlist[1].TestEntityId);
            storeRes = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetById(testobjlist[1].TestEntityId);
            Assert.Null(storeRes);
        }

        [Test]
        public void TestStoreAllAndGetAll()
        {
            TSingleton<RedisClientExtension<TestEntity>>.Instance.StoreAll(null);
            TSingleton<RedisClientExtension<TestEntity>>.Instance.StoreAll(new List<TestEntity>());
            TSingleton<RedisClientExtension<TestEntity>>.Instance.StoreAll(testobjlist);
            IList<TestEntity> getlist = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetAll();
            for (int i = 0; i < getlist.Count; i++)
            {
                Assert.NotNull(getlist[i]);
            }
            getlist = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetByIds(null);
            Assert.AreEqual(getlist.Count, 0);
            getlist = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetByIds(new List<TestEntity>());
            Assert.AreEqual(getlist.Count, 0);
            getlist = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetByIds(testobjlist);
            for (int i = 0; i < getlist.Count; i++)
            {
                Assert.NotNull(getlist[i]);
            }
            TSingleton<RedisClientExtension<TestEntity>>.Instance.DeleteAll();
            getlist = TSingleton<RedisClientExtension<TestEntity>>.Instance.GetAll();
            Assert.AreEqual(0, getlist.Count);
        }
    }
    */
    #endregion
}
