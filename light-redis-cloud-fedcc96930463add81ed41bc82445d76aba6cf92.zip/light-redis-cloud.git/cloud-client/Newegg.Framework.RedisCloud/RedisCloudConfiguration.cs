﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Newegg.Framework.RedisCloud
{
    //<redisClientManager maxWritePoolSize="5" maxReadPoolSize="5" autoStart="true" />
    public class RedisCloudConfiguration : ConfigurationSection
    {
        [ConfigurationProperty("defaultCloud", IsRequired = false)]
        public string DefaultCloud
        {
            get
            {
                return (string)this["defaultCloud"];
            }
            set
            {
                this["defaultCloud"] = value;
            }
        }

        [ConfigurationProperty("clouds")]
        public RedisCloudCollection Clouds
        {
            get
            {
                return (RedisCloudCollection)this["clouds"];
            }
        }
    }

    public class RedisCloudCollection : ConfigurationElementCollection
    {
        public RedisCloudElement this[int index]
        {
            get
            {
                return base.BaseGet(index) as RedisCloudElement;
            }
        }

        public new RedisCloudElement this[string name]
        {
            get
            {
                return base.BaseGet(name) as RedisCloudElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new RedisCloudElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((RedisCloudElement)element).CloudName;
        }
    }

    public class RedisCloudElement : ConfigurationElement
    {
        [ConfigurationProperty("initalDb", DefaultValue = 0, IsRequired = false)]
        public int InitalDb
        {
            get
            {
                return (int)this["initalDb"];
            }
            set
            {
                this["initalDb"] = value;
            }
        }

        [ConfigurationProperty("cloudName", IsRequired = true, IsKey = true)]
        public string CloudName
        {
            get
            {
                return ((string)this["cloudName"]);
            }
            set
            {
                this["cloudName"] = value;
            }
        }

        [ConfigurationProperty("readWriteHosts")]
        public RedisHostCollection ReadWriteHosts
        {
            get
            {
                return (RedisHostCollection)this["readWriteHosts"];
            }
        }

        [ConfigurationProperty("readOnlyHosts")]
        public RedisHostCollection ReadOnlyHosts
        {
            get
            {
                return (RedisHostCollection)this["readOnlyHosts"];
            }
        }

        [ConfigurationProperty("redisClientManager")]
        public RedisClientManagerElement RedisClientManager
        {
            get
            {
                return (RedisClientManagerElement)this["redisClientManager"];
            }
        }
    }

    public class RedisHostElement : ConfigurationElement
    {
        [ConfigurationProperty("address", IsRequired = true)]
        public string Address
        {
            get
            {
                return (string)this["address"];
            }
            set
            {
                this["address"] = value;
            }
        }

        [ConfigurationProperty("port", IsRequired = true)]
        public int Port
        {
            get
            {
                return (int)this["port"];
            }
            set
            {
                this["port"] = value;
            }
        }
    }

    public class RedisHostCollection : ConfigurationElementCollection
    {
        public RedisHostElement this[int index]
        {
            get
            {
                return base.BaseGet(index) as RedisHostElement;
            }
        }

        public new RedisHostElement this[string name]
        {
            get
            {
                return base.BaseGet(name) as RedisHostElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new RedisHostElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            var el = ((RedisHostElement)element);
            return string.Format("{0}:{1}", el.Address, el.Port);
        }

        public string[] ToStringArray()
        {
            List<string> result = new List<string>();
            foreach (var host in this)
            {
                var el = ((RedisHostElement)host);
                result.Add(string.Format("{0}:{1}", el.Address, el.Port));
            }

            return result.ToArray();
        }
    }

    public class RedisClientManagerElement : ConfigurationElement
    {
        [ConfigurationProperty("maxWritePoolSize", IsRequired = true)]
        public int MaxWritePoolSize
        {
            get
            {
                return (int)this["maxWritePoolSize"];
            }
            set
            {
                this["maxWritePoolSize"] = value;
            }
        }

        [ConfigurationProperty("maxReadPoolSize", IsRequired = true)]
        public int MaxReadPoolSize
        {
            get
            {
                return (int)this["maxReadPoolSize"];
            }
            set
            {
                this["maxReadPoolSize"] = value;
            }
        }

        [ConfigurationProperty("autoStart", IsRequired = true)]
        public bool AutoStart
        {
            get
            {
                return (bool)this["autoStart"];
            }
            set
            {
                this["autoStart"] = value;
            }
        }

    }

    class Test_Configuration
    {
        private void Test_Get()
        {
            var redisSection = ConfigurationManager.GetSection("redisCloudConfiguration") as RedisCloudConfiguration;
        }
    }
}
