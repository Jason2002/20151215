﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Configuration;
using System.Linq;
using System.Text;
using ServiceStack.Common;
using ServiceStack.Redis;

namespace Newegg.Framework.RedisCloud
{
    public static class CloudClientFactory
    {
        private static readonly RedisCloudConfiguration _redisCloudConfiguration = null;
        private static readonly ConcurrentDictionary<string, IRedisClientsManager> prcms = new ConcurrentDictionary<string, IRedisClientsManager>();

        static CloudClientFactory()
        {
            _redisCloudConfiguration = ConfigurationManager.GetSection("redisCloudConfiguration") as RedisCloudConfiguration;
        }

        public static RedisCloudClient GetCloudClient(ClientMutateOption mutateOption = ClientMutateOption.Local | ClientMutateOption.Message)
        {
            return GetCloudClient(_redisCloudConfiguration.DefaultCloud, mutateOption);
        }

        public static RedisCloudClient GetCloudClient(string cloudName, ClientMutateOption mutateOption = ClientMutateOption.Local | ClientMutateOption.Message)
        {
            var redisCloudElement = _redisCloudConfiguration.Clouds[cloudName];
            var prcm = CreateRedisManager(redisCloudElement);
            return new RedisCloudClient(prcm, redisCloudElement.InitalDb, mutateOption);
        }

        /// <summary>
        /// 创建Redis连接池管理对象
        /// </summary>
        private static IRedisClientsManager CreateRedisManager(RedisCloudElement redisCloudElement)
        {
            if (prcms.ContainsKey(redisCloudElement.CloudName))
            {
                return prcms[redisCloudElement.CloudName];
            }
            else
            {
                //支持读写分离，均衡负载
                var prcm = new BasicRedisClientManager(
                    redisCloudElement.ReadWriteHosts.ToStringArray(), //读写服务器
                    redisCloudElement.ReadOnlyHosts.ToStringArray(), //只读服务器
                    redisCloudElement.InitalDb);
                //new RedisClientManagerConfig
                //{
                //    MaxWritePoolSize = redisCloudElement.RedisClientManager.MaxWritePoolSize, //"写"链接池数
                //    MaxReadPoolSize = redisCloudElement.RedisClientManager.MaxReadPoolSize, //"读"链接池数
                //    AutoStart = redisCloudElement.RedisClientManager.AutoStart,
                //},

                prcms.TryAdd(redisCloudElement.CloudName, prcm);
                return prcm;
            }
        }
    }
}
