﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web.Http;
using DocumentTool.Services;

namespace DocumentTool.Converter.Console.Controllers
{
    public class DocumentController : ApiController
    {
        private readonly string _path = ConfigurationManager.AppSettings.Get("documentPath");

        public object Post(int id, [FromBody]Document document)
        {
            try
            {
                var source =_path+("/doc/" + id + ".rtf");
                var target = _path+("/pdf/" + id + ".pdf");

                using (var content = new MemoryStream())
                {
                    CompressHelper.Decomparess(document.Content, content);
                    using (var fs = new FileStream(source, FileMode.Create, FileAccess.ReadWrite))
                    {
                        content.WriteTo(fs);
                    }
                }

                if (System.IO.File.Exists(target))
                {
                    File.Delete(target);
                }
                FileConverter.WordToPdf(source, target);
                FileConverter.PdfToSwf(target, _path+("/swf/" + id + ".swf"));

                //删除Sub Doc Directory
                var docpath =_path+("/doc/" + id);
                var pdfpath = _path + ("/pdf/" + id);
                var swfpath = _path + ("/swf/" + id);
                if(Directory.Exists(docpath))
                {
                    Directory.Delete(docpath,true);
                }
                if (Directory.Exists(pdfpath))
                {
                    Directory.Delete(pdfpath, true);
                }
                if (Directory.Exists(swfpath))
                {
                    Directory.Delete(swfpath, true);
                }

                System.Console.WriteLine(DateTime.Now.ToString("G") + " [" + id + "] Convert complete.");

                return new { result = true};
            }
            catch (Exception e)
            {
                System.Console.WriteLine(DateTime.Now.ToString("G") + " [" + id + "] Convert fail. " + e.Message);
                return new { result = false, reason = id + ": "+e.Message };
            }
        }

        public object GetConvertSub(int id, string path)
        {
            try
            {
                var docpath = _path + ("/doc/" + id);
                var pdfpath = _path + ("/pdf/" + id);
                var swfpath = _path + ("/swf/" + id);

                var extension = Path.GetExtension(path);
                var filename = Path.GetFileNameWithoutExtension(path);
                var docfilepath = docpath + "/" + Path.GetFileName(path);
                var pdffilepath = pdfpath + "/" + filename + ".pdf";
                var swffilepath = swfpath + "/" + filename + ".swf";

                if (!Directory.Exists(docpath))
                {
                    Directory.CreateDirectory(docpath);
                }
                if (!Directory.Exists(pdfpath))
                {
                    Directory.CreateDirectory(pdfpath);
                }
                if (!Directory.Exists(swfpath))
                {
                    Directory.CreateDirectory(swfpath);
                }

                if (path.StartsWith("http"))
                {
                    new WebClient().DownloadFile(path, docfilepath);
                }
                else
                {
                    File.Copy(path, docfilepath, true);
                }

                if (System.IO.File.Exists(pdffilepath))
                {
                    File.Delete(pdffilepath);
                }
                if (extension == null)
                {
                    throw new Exception("File extension is null.");
                }
                if (extension.Equals(".doc") || extension.Equals(".docx") || extension.Equals(".rtf"))
                {
                    FileConverter.WordToPdf(docfilepath, pdffilepath);
                }
                else if (extension.Equals(".ppt") || extension.Equals(".pptx"))
                {
                    FileConverter.PptToPdf(docfilepath, pdffilepath);
                }
                else if (extension.Equals(".xls") || extension.Equals(".xlsx"))
                {
                    pdffilepath = System.IO.Path.GetDirectoryName(pdffilepath) + "/" + System.IO.Path.GetFileNameWithoutExtension(pdffilepath) + ".htm";
                    FileConverter.ExcelToPdf(docfilepath, pdffilepath);
                    System.IO.File.Copy(pdffilepath, swfpath + "/" + filename + ".htm", true);
                    CopyDirectory(pdfpath + "/" + filename + ".files", swfpath + "/" + filename + ".files");
                    CopyDirectory(pdfpath + "/" + filename + "_files", swfpath + "/" + filename + "_files");
                    System.Console.WriteLine(DateTime.Now.ToString("G") + " [" + id + "] Convert Sub complete.[" + path + "]");
                    return true;
                }
                else if (extension.Equals(".msg"))
                {
                    pdffilepath = System.IO.Path.GetDirectoryName(pdffilepath) + "/" + System.IO.Path.GetFileNameWithoutExtension(pdffilepath) + ".htm";
                    FileConverter.MsgToHtml(docfilepath, pdffilepath);
                    System.IO.File.Copy(pdffilepath, swfpath + "/" + filename + ".htm", true);
                    CopyDirectory(pdfpath + "/" + filename + ".files", swfpath + "/" + filename + ".files");
                    CopyDirectory(pdfpath + "/" + filename + "_files", swfpath + "/" + filename + "_files");
                    System.Console.WriteLine(DateTime.Now.ToString("G") + " [" + id + "] Convert Sub complete.[" + path + "]");
                    return true;
                }
                else if (extension.Equals(".pdf"))
                {
                    System.IO.File.Copy(docfilepath, pdffilepath, true);
                }

                FileConverter.PdfToSwf(pdffilepath, swffilepath);

                System.Console.WriteLine(DateTime.Now.ToString("G") + " [" + id + "] Convert Sub complete.[" + path + "]");

                return true;
            }
            catch (Exception e)
            {
                System.Console.WriteLine(DateTime.Now.ToString("G") + " [" + id + "] Convert Sub fail.[" + path + "] "+e.Message);
                return id + "(" + path + "): " + e.Message;
            }
        }

        private static void CopyDirectory(String sourcePath, String destinationPath)
        {
            if(!Directory.Exists(sourcePath))return;
            DirectoryInfo info = new DirectoryInfo(sourcePath);
            Directory.CreateDirectory(destinationPath);
            foreach (FileSystemInfo fsi in info.GetFileSystemInfos())
            {
                String destName = Path.Combine(destinationPath, fsi.Name);

                if (fsi is System.IO.FileInfo)
                    File.Copy(fsi.FullName, destName,true);
                else
                {
                    if (!Directory.Exists(destName))
                        Directory.CreateDirectory(destName);
                    CopyDirectory(fsi.FullName, destName);
                }
            }
        }
    }

    public class Document
    {
        public string Content { get; set; }
    }

}
