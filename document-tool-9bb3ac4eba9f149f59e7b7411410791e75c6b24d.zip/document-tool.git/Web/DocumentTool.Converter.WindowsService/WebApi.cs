﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Web.Http;
using Microsoft.Owin.Hosting;
using Owin;

namespace DocumentTool.Converter.WindowsService
{
    public partial class WebApi : ServiceBase
    {
        private IDisposable _task;

        public WebApi()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string baseAddress = "http://localhost:9001/";
            _task = WebApp.Start<Startup>(baseAddress);
        }

        protected override void OnStop()
        {
        }
    }

    public class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            var config = new HttpConfiguration();
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            appBuilder.UseWebApi(config);
        }
    } 
}
