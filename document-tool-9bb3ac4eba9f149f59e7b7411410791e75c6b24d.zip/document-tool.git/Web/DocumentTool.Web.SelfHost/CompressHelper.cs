﻿using System;
using System.IO;

namespace DocumentTool.Web.SelfHost
{
    public static class CompressHelper
    {
        public static string CompressContent(MemoryStream original)
        {
            using (MemoryStream contentStream = new MemoryStream())
            {
                int nSize = 3 * 1024 * 1024;
                byte[] decompressBuffer = new byte[nSize];
                string content = string.Empty;
                int nSizeIncept;
                using (
                    System.IO.Compression.DeflateStream comStream =
                        new System.IO.Compression.DeflateStream(contentStream, System.IO.Compression.CompressionMode.Compress, true))
                {

                    original.Seek(0, SeekOrigin.Begin);

                    while ((nSizeIncept = original.Read(decompressBuffer, 0, nSize)) != 0)
                    {
                        comStream.Write(decompressBuffer, 0, nSizeIncept);
                    }
                }
                decompressBuffer = contentStream.ToArray();

                return Convert.ToBase64String(decompressBuffer);

            }
        }


        public static void Decomparess(string source, MemoryStream content)
        {
            byte[] buffer = Convert.FromBase64String(source);
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            {
                ms.Write(buffer, 0, buffer.Length);
                ms.Position = 0;
                using (System.IO.Compression.DeflateStream stream = new System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Decompress))
                {
                    stream.Flush();

                    int nSize = 3 * 1024 * 1024;
                    byte[] decompressBuffer = new byte[nSize];
                    int readTimes = 1;
                    int nSizeIncept;
                    while ((nSizeIncept = stream.Read(decompressBuffer, 0, nSize)) != 0 || readTimes < 3)
                    {
                        readTimes++;
                        if (nSizeIncept == 0)
                        {
                            continue;
                        }
                        content.Write(decompressBuffer, 0, nSizeIncept);
                    }
                }
            }

        }
    }
}
