﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Bean.B.Deng
 * Create Date:  2013-09-04
 * Usage:   格式转换类
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Excel = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Configuration;

namespace Newegg.DocViewer.Service
{
    public class FileConverter
    {
        /// <summary>
        /// Msg转Html
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="targetPath"></param>
        /// <returns></returns>
        public static bool MsgToHtml(string sourcePath, string targetPath)
        {
            bool result;
            Outlook.ApplicationClass outlookApplication = new Outlook.ApplicationClass();
            Outlook.MailItem outlookMailItem = null;
            try
            {
                outlookMailItem = (Outlook.MailItem)outlookApplication.Session.OpenSharedItem(sourcePath);

                if (outlookMailItem != null)
                {
                    outlookMailItem.SaveAs(targetPath, Outlook.OlSaveAsType.olHTML);
                }
                result = true;
            }
            finally
            {
                if (outlookMailItem != null)
                {
                    outlookMailItem.Close(Outlook.OlInspectorClose.olDiscard);
                }

                if (outlookApplication != null)
                {
                    outlookApplication.Quit();
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return result;
        }

        /// <summary>
        /// Excel转Pdf
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="targetPath"></param>
        /// <returns></returns>
        public static bool ExcelToPdf(string sourcePath, string targetPath)
        {
            bool result;
            Excel.ApplicationClass excelApplication = new Excel.ApplicationClass();
            Excel.Workbook excelWorkbook = null;
            try
            {
                excelWorkbook = excelApplication.Workbooks.Open(sourcePath);

                if (excelWorkbook != null)
                {
                    excelWorkbook.ExportAsFixedFormat(Excel.XlFixedFormatType.xlTypePDF, Filename: targetPath);
                }
                result = true;
            }
            finally
            {
                if (excelWorkbook != null)
                {
                    excelWorkbook.Close(SaveChanges: false);
                }
                if (excelApplication != null)
                {
                    excelApplication.Quit();//这里Excel进程关不掉
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return result;

        }

        /// <summary>
        /// PPT转Pdf
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="targetPath"></param>
        /// <returns></returns>
        public static bool PptToPdf(string sourcePath, string targetPath)
        {
            bool result;
            PowerPoint.ApplicationClass pptApplication = new PowerPoint.ApplicationClass();
            PowerPoint.Presentation pptPresentation = null;
            try
            {
                pptPresentation = pptApplication.Presentations.Open(sourcePath, WithWindow: Microsoft.Office.Core.MsoTriState.msoFalse);

                if (pptPresentation != null)
                {
                    pptPresentation.ExportAsFixedFormat(targetPath, PowerPoint.PpFixedFormatType.ppFixedFormatTypePDF);
                }
                result = true;
            }
            finally
            {
                if (pptPresentation != null)
                {
                    pptPresentation.Close();
                }
                if (pptApplication != null)
                {
                    pptApplication.Quit();
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return result;

        }

        /// <summary>
        /// Word转Pdf
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="targetPath"></param>
        /// <returns></returns>
        public static bool WordToPdf(string sourcePath, string targetPath)
        {
            bool result;
            Word.ApplicationClass wordApplication = new Word.ApplicationClass();
            Word.Document wordDocument = null;
            try
            {
                object paramSourceDocPath = sourcePath;

                wordDocument = wordApplication.Documents.Open(ref paramSourceDocPath);

                if (wordDocument != null)
                {
                    wordDocument.ExportAsFixedFormat(targetPath, Word.WdExportFormat.wdExportFormatPDF, OptimizeFor: Word.WdExportOptimizeFor.wdExportOptimizeForOnScreen);
                }
                result = true;
            }
            finally
            {
                if (wordDocument != null)
                {
                    wordDocument.Close(SaveChanges: false);
                }
                if (wordApplication != null)
                {
                    wordApplication.Quit();
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return result;

        }

        /// <summary>
        /// Pdf转Swf
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public static String PdfToSwf(string sourcePath, string targetPath, String page = null)
        {
            String output = "";
            String pdfFilePath = sourcePath;
            String swfFilePath = targetPath;
            String command = "";

            if (page != null && page.Length > 0)
                command = ConfigurationManager.AppSettings.Get("PdfToSwfSplitPagesCommand");
            else
                command = ConfigurationManager.AppSettings.Get("PdfToSwfSingleDocCommand");

            command = command.Replace("{path.pdf}", pdfFilePath);
            command = command.Replace("{path.swf}", swfFilePath);

            try
            {
                if (!IsNotConverted(pdfFilePath, swfFilePath))
                {
                    return "[Converted]";
                }
            }
            catch (Exception ex)
            {
                return "[" + ex.Message + "]";
            }

            int return_var = 0;
            String pagecommand = "";

            if (page != null && page.Length > 0)
            {
                pagecommand = command.Replace("%", page);
                pagecommand += " -p " + page;
            }

            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.FileName = command.Substring(0, command.IndexOf(".exe") + 5);
            command = command.Substring(command.IndexOf(".exe") + 5);

            if (page != null && page.Length > 0)
                proc.StartInfo.Arguments = pagecommand.Substring(pagecommand.IndexOf(".exe") + 5);
            else
                proc.StartInfo.Arguments = command;

            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            proc.StartInfo.CreateNoWindow = true;
            proc.StartInfo.RedirectStandardOutput = true;

            if (proc.Start())
            {
                output = proc.StandardOutput.ReadToEnd();
                proc.WaitForExit();
                proc.Close();
                return_var = 0;

                if (page != null && page.Length > 0)
                {
                    System.Diagnostics.Process proc2 = new System.Diagnostics.Process();
                    proc2.StartInfo.FileName = proc.StartInfo.FileName;
                    proc2.StartInfo.Arguments = command;
                    proc2.StartInfo.UseShellExecute = true;
                    proc2.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    proc2.StartInfo.CreateNoWindow = true;
                    proc2.Start();
                }
            }
            else
                return_var = -1;

            if (return_var == 0)
                return "[Converted]";
            else
                return
                    "Error converting document, make sure the conversion tool is installed and that correct user permissions are applied to the SWF Path directory";
        }


        public static Boolean IsNotConverted(String originFilePath, String convertedFilePath)
        {
            if (!File.Exists(originFilePath))
                throw new Exception("Document does not exist");

            if (convertedFilePath == null)
                throw new Exception("Document output file name not set");

            else
            {
                if (!File.Exists(convertedFilePath))
                {
                    return true;
                }
                else if (new System.IO.FileInfo(originFilePath).LastWriteTime > new System.IO.FileInfo(convertedFilePath).LastWriteTime)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
