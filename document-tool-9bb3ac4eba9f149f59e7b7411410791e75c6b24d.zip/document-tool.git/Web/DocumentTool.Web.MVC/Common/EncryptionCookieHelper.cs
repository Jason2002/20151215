﻿
namespace DocumentTool.Web.MVC
{
    public class EncryptionCookieHelper
    {
        public static void Add(string key, string value)
        {
            Add(key, value, -1);
        }

        public static void Add(string key, string value, int day)
        {
            key = EncryptKey(key);
            value = EncryptValue(value);
            CookieHelper.Add(key, value, day);
        }

        public static void Remove(string key)
        {
            key = EncryptKey(key);
            CookieHelper.Remove(key);
        }

        public static string Load(string key)
        {
            key = EncryptKey(key);
            var value = CookieHelper.Load(key);
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }
            else
            {
                return EncryptStringHelper.Decrypt(value);
            }
        }

        private static string EncryptKey(string o)
        {
            return EncryptStringHelper.Encrypt(o).Replace("=", string.Empty);
        }

        private static string EncryptValue(string o)
        {
            return EncryptStringHelper.Encrypt(o);
        }
    }
}