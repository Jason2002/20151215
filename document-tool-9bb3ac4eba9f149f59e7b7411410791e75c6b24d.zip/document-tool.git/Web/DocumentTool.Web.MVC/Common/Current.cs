﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessProcess.ServiceImp;

namespace DocumentTool.Web.MVC.Controllers
{
    public class Current 
    {
        public static User User
        {
            get
            {
                return new User
                {
                    UserName = EncryptionCookieHelper.Load("__Username__"),
                    FullName = EncryptionCookieHelper.Load("__FullName__"),
                    Email = EncryptionCookieHelper.Load("__Email__"),
                    Password = EncryptionCookieHelper.Load("__Pwd__"),
                };
            }
            set
            {
                if (value != null)
                {
                    //登录
                    if (value.IsRememberMe.HasValue && value.IsRememberMe.Value)
                    {
                        EncryptionCookieHelper.Add("__Username__", value.UserName, 180);
                        EncryptionCookieHelper.Add("__FullName__", value.FullName, 180);
                        EncryptionCookieHelper.Add("__Email__", value.Email, 180);
                        EncryptionCookieHelper.Add("__Pwd__", value.Password, 180);
                    }
                    else
                    {
                        EncryptionCookieHelper.Add("__Username__", value.UserName);
                        EncryptionCookieHelper.Add("__FullName__", value.FullName);
                        EncryptionCookieHelper.Add("__Email__", value.Email);
                        EncryptionCookieHelper.Add("__Pwd__", value.Password);
                    }
                }
                else
                {
                    //注销
                    EncryptionCookieHelper.Remove("__Username__");
                    EncryptionCookieHelper.Remove("__FullName__");
                    EncryptionCookieHelper.Remove("__Email__");
                    EncryptionCookieHelper.Remove("__Avatar__");
                    EncryptionCookieHelper.Remove("__Pwd__");
                }
            }
        }

        /// <summary>
        /// 是否已登录
        /// </summary>
        public static bool IsLogin
        {
            get
            {
                return !string.IsNullOrEmpty(User.FullName);
            }
        }
    }

    public class User
    {
        public Guid UserId { get; set; }

        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public bool? IsRememberMe { get; set; }
    }
}
