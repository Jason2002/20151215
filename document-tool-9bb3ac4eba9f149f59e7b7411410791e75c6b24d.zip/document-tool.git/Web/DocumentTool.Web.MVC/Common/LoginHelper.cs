﻿using System;
using System.IO;
using System.Net;
using System.Text;
using DocumentTool.Web.MVC;
using DocumentTool.Web.MVC.Controllers;
using Newtonsoft.Json;

namespace Newegg.Contract.Web.Mvc
{
    public class LoginHelper
    {
        private const string URL_AUTHENTICATION = "http://apis.newegg.org/common/v1/domain/security/authentication";
        private const string URL_GET_USER = "http://apis.newegg.org/common/v1/domain/user/{0}";

        public static User Login(User user)
        {
            var postData = JsonConvert.SerializeObject(new User
                {
                    UserName = user.UserName,
                    Password = user.Password,
                });
            var result = RequestHelper.Request<DomainUserAuthenticationInfo>(URL_AUTHENTICATION, "PUT", postData);
            if (result.Result)
            {
                var loginUser = RequestHelper.Request<User>(string.Format(URL_GET_USER, result.UserName));
                if (loginUser != null)
                {
                    user.FullName = loginUser.FullName;
                    user.Email = loginUser.Email;
                    Current.User = user;
                }
                return user;
            }
            throw new Exception("UserName or Password is error.");
        }

        public class DomainUserAuthenticationInfo
        {
            public string UserName { get; set; }
            public string Password { get; set; }
            public bool Result { get; set; }
        }
    }
}