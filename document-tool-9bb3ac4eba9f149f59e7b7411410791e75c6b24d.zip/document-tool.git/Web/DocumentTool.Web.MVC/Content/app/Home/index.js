﻿
angular.module('home', []).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider;
  }
]).controller('HomeController', ["$scope", "$http", "$location", "$window", function($scope, $http, $location, $window) {}]);
