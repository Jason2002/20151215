﻿var interceptor;

angular.module("app", ['home', 'document', 'documentconvert', 'formatFilters', 'ui.utils', 'ui.bootstrap', 'spin.js']).config([
  "$locationProvider", "$routeProvider", "$httpProvider", function($locationProvider, $routeProvider, $httpProvider) {
    $httpProvider.responseInterceptors.push(interceptor);
    $locationProvider.html5Mode(false).hashPrefix('!');
    return $routeProvider.otherwise({
      redirectTo: "/document/74"
    });
  }
]);

angular.module('app').controller('GlobalController', [
  "$scope", "$http", "$location", "$window", function($scope, $http, $location, $window) {
    $scope.login = function() {
      $scope.submitting = true;
      $scope.error = '';
      return $http.post("/home/login", $scope.user).success(function(data) {
        if (data.result) {
          $scope.submitting = false;
          return $window.location.href = '/';
        } else {
          $scope.submitting = false;
          $scope.user.Password = '';
          return $scope.error = data.reason;
        }
      }).error(function(error) {
        return $scope.submitting = false;
      });
    };
    return $scope.signout = function() {
      return $http.post("/home/logout").success(function(data) {
        return $window.location.reload();
      });
    };
  }
]);

interceptor = [
  "$rootScope", "$q", function(scope, $q) {
    var error, success;
    success = function(response) {
      return response;
    };
    error = function(response) {
      debugger;
      var status;
      status = response.status;
      if (status === 401) {
        window.location = "/login";
      } else if (status === 400) {
        message.error(response.Message);
      } else if (status === 500) {
        alert(response.Message);
      }
      return $q.reject(response);
    };
    return function(promise) {
      return promise.then(success, error);
    };
  }
];

angular.module("app-login", []);
