﻿var GlobalController;

GlobalController = [
  "$scope", "$http", "$location", "$window", function($scope, $http, $location, $window) {
    $scope.login = function() {
      $scope.submitting = true;
      $scope.error = '';
      return $http.post("/home/login", $scope.user).success(function(data) {
        if (data.result) {
          $scope.submitting = false;
          return $window.location.href = '/';
        } else {
          $scope.submitting = false;
          $scope.user.Password = '';
          return $scope.error = data.reason;
        }
      }).error(function(error) {
        return $scope.submitting = false;
      });
    };
    return $scope.signout = function() {
      return $http.post("/home/logout").success(function(data) {
        return $window.location.reload();
      });
    };
  }
];
