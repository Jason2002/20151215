﻿
angular.module('document', []).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/document/search/:key", {
      templateUrl: "/content/app/document/document.html",
      controller: 'DocumentController'
    }).when("/document/:id", {
      templateUrl: "/content/app/document/document.html",
      controller: 'DocumentController'
    }).when("/document/:id/:sub", {
      templateUrl: "/content/app/document/document.html",
      controller: 'DocumentController'
    });
  }
]).controller('DocumentController', [
  "$scope", "$http", "$routeParams", "$location", "$route", "$window", function($scope, $http, $routeParams, $location, $route, $window) {
    var lastRoute, url;
    $scope.loading = "Loading";
    $scope.id = $routeParams.id;
    $scope.sub = $routeParams.sub;
    $scope.key = $routeParams.key;
    if ($scope.sub) {
      $http.get("/document/check?path=/document/swf/" + $scope.id + "/" + $scope.sub).success(function(data) {
        if (data.type === 'swf') {
          $scope.type = 'swf';
          loadFlexPaperViewer("/document/swf/" + $scope.id + "/" + $scope.sub + ".swf");
        } else if (data.type === 'htm') {
          $scope.type = 'htm';
          $('#frame').attr('src', "/document/swf/" + $scope.id + "/" + $scope.sub + ".htm");
        }
        return $scope.documentExist = true;
      });
    } else if ($scope.id) {
      $http.get("/document/check?path=/document/swf/" + $scope.id).success(function(data) {
        if (data.result) {
          $scope.type = 'swf';
          $scope.documentExist = true;
          return loadFlexPaperViewer("/document/swf/" + $scope.id + ".swf");
        }
      });
    }
    if ($scope.id) {
      $http.get("document/GetSubList/" + $scope.id).success(function(data) {
        return $scope.subfiles = data;
      });
    }
    url = "/document/GetTree";
    if ($scope.key) url = "/document/GetTreeByKey?key=" + $scope.key;
    $http.get(url).success(function(data) {
      var item, list, _i, _len;
      list = {};
      for (_i = 0, _len = data.length; _i < _len; _i++) {
        item = data[_i];
        list[item.name] = item;
      }
      $('#tree').ace_tree({
        dataSource: new DataSourceTree({
          data: list
        }),
        loadingHTML: '<div class="tree-loading"><i class="icon-refresh icon-spin blue"></i></div>',
        'open-icon': 'icon-folder-open',
        'close-icon': 'icon-folder-close',
        'selectable': true,
        'selected-icon': null,
        'unselected-icon': null
      });
      $('#tree').on('opened', function(evt, data) {
        $scope.change(data.id);
        $scope.$parent.breadcrumb = data.name;
        return $scope.$apply();
      });
      $('#tree').on('closed', function(evt, data) {
        $scope.change(data.id);
        $scope.$parent.breadcrumb = data.name;
        return $scope.$apply();
      });
      $('#tree').on('selected', function(evt, data) {
        $scope.change(data.info[0].id);
        $scope.$parent.breadcrumb = data.info[0].name;
        return $scope.$apply();
      });
      return $scope.loading = "";
    });
    $scope.$parent.search = function() {
      return $location.path("/document/search/" + $scope.$parent.key);
    };
    $scope.change = function(id) {
      $scope.loading = "Loading";
      if (id) $scope.id = id;
      $http.get("/document/check?path=/document/swf/" + $scope.id).success(function(data) {
        if (data.result) {
          $scope.type = 'swf';
          $scope.documentExist = true;
          loadFlexPaperViewer("/document/swf/" + $scope.id + ".swf");
        } else {
          $scope.documentExist = false;
        }
        return $scope.loading = "";
      });
      if (id) {
        $http.get("document/GetSubList/" + $scope.id).success(function(data) {
          return $scope.subfiles = data;
        });
      }
      return $location.path('/document/' + $scope.id);
    };
    $scope.subChange = function(sub) {
      $scope.loading = "Loading";
      $scope.sub = sub;
      return $http.get("/document/check?path=/document/swf/" + $scope.id + "/" + $scope.sub).success(function(data) {
        if (data.type === 'swf') {
          $scope.type = 'swf';
          loadFlexPaperViewer("/document/swf/" + $scope.id + "/" + $scope.sub + ".swf");
        } else if (data.type === 'htm') {
          $scope.type = 'htm';
          $('#frame').attr('src', "/document/swf/" + $scope.id + "/" + $scope.sub + ".htm");
        }
        $scope.loading = "";
        return $location.path("/document/" + $scope.id + "/" + sub);
      });
    };
    lastRoute = $route.current;
    return $scope.$on('$locationChangeSuccess', function(event) {
      if ($route.current.params.id) return $route.current = lastRoute;
    });
  }
]);
