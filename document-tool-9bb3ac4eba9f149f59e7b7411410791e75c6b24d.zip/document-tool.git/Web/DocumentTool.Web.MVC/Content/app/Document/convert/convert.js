﻿
angular.module('documentconvert', []).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/convert", {
      templateUrl: "/content/app/document/convert.html",
      controller: 'ConvertController'
    });
  }
]).controller('ConvertController', [
  "$scope", "$http", "$routeParams", function($scope, $http, $routeParams) {
    var list, task;
    list = [];
    $scope.errors = [];
    $http.get("/document/all").success(function(data) {
      list = data;
      $scope.total = data.length;
      $scope.completed = 0;
      return $scope.value = $scope.completed / $scope.total;
    });
    $scope.convert = function() {
      return task(list);
    };
    return task = function(list) {
      var item;
      item = list.shift();
      return $http.get("/document/convert/" + item).success(function(data) {
        if (data.result === false) $scope.errors.push(data.reason);
        $scope.completed++;
        $scope.value = $scope.completed * 100 / $scope.total;
        if (list.length > 0) return task(list);
      });
    };
  }
]);
