﻿var interceptor;

angular.module("app", ['formatFilters', 'ui.utils', 'ui.bootstrap', 'spin.js']).config([
  "$locationProvider", "$routeProvider", "$httpProvider", function($locationProvider, $routeProvider, $httpProvider) {
    $httpProvider.responseInterceptors.push(interceptor);
    $locationProvider.html5Mode(false).hashPrefix('!');
    return $routeProvider.when("/document/convert", {
      templateUrl: "/partials/document/convert.html",
      controller: ConvertController
    }).when("/document/search/:key", {
      templateUrl: "/partials/document/index.html",
      controller: DocumentController
    }).when("/document/:id", {
      templateUrl: "/partials/document/index.html",
      controller: DocumentController
    }).when("/document/:id/:sub", {
      templateUrl: "/partials/document/index.html",
      controller: DocumentController
    }).otherwise({
      redirectTo: "/document/74"
    });
  }
]);

interceptor = [
  "$rootScope", "$q", function(scope, $q) {
    var error, success;
    success = function(response) {
      return response;
    };
    error = function(response) {
      debugger;
      var status;
      status = response.status;
      if (status === 401) {
        window.location = "/login";
      } else if (status === 400) {
        message.error(response.Message);
      } else if (status === 500) {
        alert(response.Message);
      }
      return $q.reject(response);
    };
    return function(promise) {
      return promise.then(success, error);
    };
  }
];

angular.module("app-login", []);
