﻿var myDirectives;

myDirectives = angular.module("customDirectives", []);
