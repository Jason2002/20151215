﻿var DataSourceTree, message;

message = {
  success: function(title, text) {
    return $.gritter.add({
      title: title,
      text: text,
      sticky: false,
      class_name: "gritter"
    });
  },
  error: function(title, text) {
    var msg;
    if (msg === "401") msg = "Unauthorized.";
    return $.gritter.add({
      title: title,
      text: text,
      class_name: "gritter-error",
      sticky: true
    });
  },
  confirm: function(callback) {
    return bootbox.confirm("Are you sure?", function(result) {
      if (result) return callback();
    });
  }
};

DataSourceTree = function(options) {
  this._data = options.data;
  return this._delay = options.delay;
};

DataSourceTree.prototype.data = function(options, callback) {
  var $data, self;
  self = this;
  $data = null;
  if ((!("name" in options)) && (!("type" in options))) {
    $data = this._data;
    callback({
      data: $data
    });
    return;
  } else if ("type" in options && options.type === "folder") {
    if ("additionalParameters" in options && "children" in options.additionalParameters) {
      $data = options.additionalParameters.children;
    } else {
      $data = {};
    }
  }
  if ($data != null) {
    return callback({
      data: $data
    });
  }
};
