﻿
angular.module("formatFilters", []).filter("jsondate", function() {
  return function(input, fmt) {
    return input.Format(fmt);
  };
}).filter("isFuture", function() {
  return function(input) {
    return new Date(input) > new Date();
  };
}).filter('checkmark', function() {
  return function(input) {
    if (input) {
      return '\u2713';
    } else {
      return '\u2718';
    }
  };
}).filter('yesno', function() {
  return function(input) {
    if (input) {
      return 'Yes';
    } else {
      return 'No';
    }
  };
}).filter('convertToHtmlLine', function() {
  return function(input) {
    if (input === null || input === void 0) return input;
    return input.replace(/\n/g, "<br />");
  };
}).filter('formatFileSize', function() {
  return function(bytes) {
    if (bytes === null || bytes === void 0) return bytes;
    if (typeof bytes !== 'number') return '';
    if (bytes >= 1000000000) return (bytes / 1000000000).toFixed(2) + ' GB';
    if (bytes >= 1000000) return (bytes / 1000000).toFixed(2) + ' MB';
    return (bytes / 1000).toFixed(2) + ' KB';
  };
}).filter('ecpectSelfRule', function() {
  return function(input, self) {
    var item, _i, _len, _results;
    if (self === null || self === void 0) return input;
    if (self.RuleId === null || self.RuleId === void 0) return input;
    if (input === null || input === void 0) return input;
    _results = [];
    for (_i = 0, _len = input.length; _i < _len; _i++) {
      item = input[_i];
      if (item.RuleId !== self.RuleId) _results.push(item);
    }
    return _results;
  };
}).filter('exceptSelfUser', function() {
  return function(input, self) {
    var item, _i, _len, _results;
    if (self === null || self === void 0) return input;
    if (self.FullName === null || self.FullName === void 0) return input;
    if (input === null || input === void 0) return input;
    _results = [];
    for (_i = 0, _len = input.length; _i < _len; _i++) {
      item = input[_i];
      if (item.FullName !== self.FullName) _results.push(item);
    }
    return _results;
  };
}).filter('exceptOtherType', function() {
  return function(input, self) {
    var item, _i, _len, _results;
    if (self === null || self === void 0) return input;
    if (input === null || input === void 0) return input;
    _results = [];
    for (_i = 0, _len = input.length; _i < _len; _i++) {
      item = input[_i];
      if (item.Type === self) _results.push(item);
    }
    return _results;
  };
});
