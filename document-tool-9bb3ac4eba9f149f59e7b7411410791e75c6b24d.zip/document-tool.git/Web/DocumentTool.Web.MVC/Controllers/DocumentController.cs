﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Management;
using System.Web.Mvc;
using BusinessProcess.ServiceImp;
using Newegg.Contract.Web.Mvc;
using Newegg.DocViewer.Service;
using Newegg.Framework.Tools.Compress;
using Newtonsoft.Json;
using ServiceDefinetion;
using WebGrease.Css.Extensions;

namespace DocumentTool.Web.MVC.Controllers
{
    public class DocumentController : Controller
    {
        #region View

        public ActionResult GetTree()
        {
            var tree = new CategoryService().GetCategoryTree(Current.User.UserName);
            tree = Order(tree);
            return Json(GetSubCategory(tree), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetTreeByKey(string key)
        {
            var tree = new CategoryService().GetCategoryTree(Current.User.UserName).ToList();

            var docList = new DocumentService().SearchDocuments(key);
            var categoriesList = new List<int>();
            docList.ForEach(p =>
            {
                if (p.DocumentId != null)
                {
                    var category = new DocumentService().GetCategoryIdByDocumentId(p.DocumentId.Value);
                    categoriesList.Add(category);
                }
            });

            SignResult(tree, categoriesList);
            RemoveResult(tree);
            tree = Order(tree);
            return Json(GetSubCategory(tree, isSearch: true), JsonRequestBehavior.AllowGet);
        }

        private List<CategoryEntity> Order(IEnumerable<CategoryEntity> tree)
        {
            tree = tree.OrderBy(p => p.CategoryName);
            foreach (var item in tree)
            {
                Order(item);
            }
            return tree.ToList();
        }

        private void Order(CategoryEntity item)
        {
            if (item != null && item.SubCategories != null)
            {
                item.SubCategories = item.SubCategories.OrderBy(p => p.CategoryName).ToList();
                foreach (var sub in item.SubCategories)
                {
                    Order(sub);
                }
            }
        }

        private void SignResult(IEnumerable<CategoryEntity> tree, List<int> categoriesList)
        {
            if (tree == null) return;

            foreach (var categoryEntity in tree)
            {
                categoryEntity.IsAuthShow = categoriesList.Contains(categoryEntity.CategoryId.Value);
                //若有权限,则也将父节点设置为可见.
                if (categoryEntity.IsAuthShow.Value)
                {
                    SetParentShow(categoryEntity);
                }
                SignResult(categoryEntity.SubCategories, categoriesList);
            }
        }

        private void RemoveResult(List<CategoryEntity> tree)
        {
            if (tree == null) return;

            for (var i = 0; i < tree.Count(); i++)
            {
                if (!tree[i].IsAuthShow.Value)
                {
                    tree.Remove(tree[i]);
                    i--;
                }
                else
                {
                    RemoveResult(tree[i].SubCategories);
                }
            }
        }

        private void SetParentShow(CategoryEntity entity)
        {
            if (entity.Parent != null)
            {
                entity.Parent.IsAuthShow = true;
                SetParentShow(entity.Parent);
            }
        }

        private object GetSubCategory(IEnumerable<CategoryEntity> list, bool isRoot = true, bool isSearch = false)
        {
            if (list == null)
            {
                return new string[] {};
            }
            object result;
            if (isSearch)
            {
                result = from t in list
                    where t.IsAuthShow == true
                    select new
                    {
                        id = t.CategoryId,
                        name = t.CategoryName,
                        type = (t.SubCategories != null && t.SubCategories.Count > 0) ? "folder" : "item",
                        additionalParameters = GetSubCategory(t.SubCategories, false),
                    };
            }
            else
            {
                result = from t in list
                    select new
                    {
                        id = t.CategoryId,
                        name = t.CategoryName,
                        type = (t.SubCategories != null && t.SubCategories.Count > 0) ? "folder" : "item",
                        additionalParameters = GetSubCategory(t.SubCategories, false),
                    };
            }

            if (isRoot)
            {
                return result;
            }
            else
            {
                return new {children = result};
            }
        }

        public ActionResult GetSubList(int id)
        {
            var dir = Server.MapPath("/document/swf/" + id);
            if (!Directory.Exists(dir))
            {
                return Json(new[] {"Main"}, JsonRequestBehavior.AllowGet);
            }
            var files = Directory.GetFiles(dir);
            for (var i = 0; i < files.Length; i++)
            {
                files[i] = Path.GetFileNameWithoutExtension(files[i]);
            }
            var list = files.ToList();
            list.Insert(0, "Main");
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Check(string path)
        {
            if (System.IO.File.Exists(Server.MapPath(path)))
            {
                return Json(new { result = true, type = "swf" }, JsonRequestBehavior.AllowGet);
            }
            if (System.IO.File.Exists(Server.MapPath(path + ".swf")))
            {
                return Json(new { result = true,type="swf" }, JsonRequestBehavior.AllowGet);
            }
            if (System.IO.File.Exists(Server.MapPath(path + ".htm")))
            {
                return Json(new { result = true, type = "htm" }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = false }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Convert

        public ActionResult Convert(int id)
        {
            try
            {
                var document = new DocumentService().GetDocument(id);

                if (document == null || document.DocumentContent == null)
                {
                    return Json(new {result = true}, JsonRequestBehavior.AllowGet);
                }
                var postData = JsonConvert.SerializeObject(new
                    Document()
                {
                    Content = document.DocumentContent,
                });
                var result = RequestHelper.Request<Res>("http://localhost:9000/" + "api/document/" + id, "POST",
                    postData);

                return Json(new {result}, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                return Json(new {result = false, reason = id + ": " + e.Message}, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult ConvertSub(int id, string path)
        {
            try
            {
                var result =
                    RequestHelper.Request<Res>("http://localhost:9000/" + "api/document/" + id + "?path=" + path);
                return Json(new {result}, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                return Json(new {result = false, reason = id + "(" + path + "): " + e.Message},
                    JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult All()
        {
            var tree = new CategoryService().GetCategoryList().Select(p => p.CategoryId);
            return Json(tree, JsonRequestBehavior.AllowGet);
        }

        public class Document
        {
            public string Content { get; set; }
        }

        public class Res
        {
            public string result { get; set; }
            public string reason { get; set; }
        }

        #endregion
    }
}
