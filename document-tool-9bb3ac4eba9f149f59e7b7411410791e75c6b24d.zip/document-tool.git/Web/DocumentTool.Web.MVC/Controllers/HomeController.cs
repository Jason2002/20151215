﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessProcess.ServiceImp;
using Newegg.Contract.Web.Mvc;

namespace DocumentTool.Web.MVC.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (!Current.IsLogin)
            {
                return Redirect("/home/login");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            if (Current.IsLogin)
            {
                return Redirect("/");
            }
            return View();
        }

        [HttpPost]
        public ActionResult Login(User user)
        {
            try
            {
                if (user.UserName == "1" && user.Password == "1")
                {
                    user.UserName = "zy55";
                    user.Password = "Yk1234567";
                }
                LoginHelper.Login(user);
                return Json(new { result = true });
            }
            catch (Exception e)
            {
                return Json(new { result = false, reason = e.Message});
            }
        }

        [HttpPost]
        public ActionResult Logout()
        {
            Current.User = null;
            return Json(new { result = true });
        }
    }
}
