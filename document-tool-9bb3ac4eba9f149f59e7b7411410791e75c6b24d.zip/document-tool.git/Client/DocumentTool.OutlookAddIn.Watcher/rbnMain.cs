﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;

namespace DocumentTool.OutlookAddIn.Watcher
{
    public partial class rbnMain
    {
        private void rbnMain_Load(object sender, RibbonUIEventArgs e)
        {

        }
    }
}
