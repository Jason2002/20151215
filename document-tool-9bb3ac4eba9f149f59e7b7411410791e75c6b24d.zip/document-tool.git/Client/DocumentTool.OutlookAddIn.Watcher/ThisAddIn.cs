﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using System.Windows.Forms;
using System.Reflection;
using DocumentTool.OutlookAddIn.Watcher.BLL;
using DocumentManagementTool.Controller;
using System.Text.RegularExpressions;

namespace DocumentTool.OutlookAddIn.Watcher
{
    public partial class ThisAddIn
    {
        private SortingBLL _sortingBLL = new SortingBLL();
        private Timer _timer = new Timer();
        private static object _syncObj = new object();
        private static RuleList _publishRules = null;

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            try
            {
                CategoryClientProxy categoryClientProxy = new CategoryClientProxy();
                CategoryController categoryController = new CategoryController(categoryClientProxy);

                _publishRules = categoryClientProxy.GetPublishRuleList();

                Application.NewMailEx += Application_NewMailEx;

                //定时器处理收件箱中的邮件 10分钟 
                _timer.Interval = 10 * 60 * 1000;
                _timer.Tick += timer_Tick;
                _timer.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Document Tool Watcher加载错误");
            }
        }

        private void Application_NewMailEx(string EntryIDCollection)
        {
            try
            {
                lock (_syncObj)
                {
                    Outlook.MailItem newMail = (Outlook.MailItem)Application.Session.GetItemFromID(EntryIDCollection, Missing.Value);
                    DoPublishMail(newMail);
                }
            }
            catch (Exception ex)
            {
                LogController.WriteLog(ex);
            }
        }

        private void DoPublishMail(Outlook.MailItem mail)
        {
            if (string.IsNullOrWhiteSpace(mail.Subject))
            {
                return;
            }

            bool isMatchPublishRule = false;
            string subject = mail.Subject.Trim();

            //去除(Info)字样
            if (subject.StartsWith("(Info)", StringComparison.InvariantCultureIgnoreCase))
            {
                subject = subject.Substring("(Info)".Length, subject.Length - "(Info)".Length);
            }

            foreach (var rule in _publishRules)
            {
                Regex regex = new Regex(rule.Section, RegexOptions.Singleline | RegexOptions.IgnoreCase);
                if (regex.IsMatch(subject))
                {
                    string matchValue = regex.Match(subject).Value;

                    //去除标题中间的*Report字样
                    subject = regex.Replace(subject, string.Empty);

                    //格式化标题为：Report-Weekly Report-NESC-SH-WW29-MIS-Leon.S.Zhang
                    subject = string.Concat("Report-", matchValue, "-", subject);

                    isMatchPublishRule = true;
                    break;
                }
            }

            if (isMatchPublishRule)
            {
                //保存邮件
                _sortingBLL.Publish(mail, subject);
            }

            //标记完成
            mail.FlagStatus = Outlook.OlFlagStatus.olFlagComplete;
            mail.Save();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                lock (_syncObj)
                {
                    Outlook.MAPIFolder inbox = Application.ActiveExplorer().Session.GetDefaultFolder(
                        Outlook.OlDefaultFolders.olFolderInbox);
                    Outlook.Items restrictedItems = inbox.Items.Restrict("[FlagStatus] = 0");
                    foreach (Object objItem in restrictedItems)
                    {
                        if (objItem is Outlook.MailItem)
                        {
                            Outlook.MailItem mail = objItem as Outlook.MailItem;
                            DoPublishMail(mail);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
                LogController.WriteLog(ex);
            }
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            _timer.Stop();
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
