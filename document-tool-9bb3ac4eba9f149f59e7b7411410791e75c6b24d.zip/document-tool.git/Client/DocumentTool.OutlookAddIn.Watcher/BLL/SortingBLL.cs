﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using DocumentManagementTool.Controller;
using DocumentManagementTool.ViewModel;
using DocumentTool.OutlookAddIn.BLL;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace DocumentTool.OutlookAddIn.Watcher.BLL
{
    public class SortingBLL
    {
        private MailBLL _mailBLL = new MailBLL();
        private CategoryController _categoryController = null;
        private DocumentController _documentController = null;

        public SortingBLL()
        {
            CategoryClientProxy categoryClientProxy = new CategoryClientProxy();
            _categoryController = new CategoryController(categoryClientProxy);

            DocumentClientProxy documentClientProxy = new DocumentClientProxy();
            _documentController = new DocumentController(documentClientProxy);
        }

        public void Publish(Outlook.MailItem mail, string subject)
        {
            //获取发件人短名
            string senderName = ADHelper.GetShortName(mail.SenderName);
            if (string.IsNullOrWhiteSpace(senderName))
            {
                senderName = "[Job]";
            }

            //上传附件
            string downloadUrls_Att = string.Empty;
            string downloadUrls_Embed = string.Empty;
            IList<AttachmentEntity> atts = null;
            IList<AttachmentDocumentEntity> ads = null;
            _mailBLL.UploadAttachment(mail, ref downloadUrls_Att, ref downloadUrls_Embed, ref atts, ref ads, senderName);

            //构造邮件头信息
            string headerText = _mailBLL.BuildAppendInfo(mail, downloadUrls_Att, downloadUrls_Embed);

            DocumentEntity document = GetDocument(mail, string.Empty, headerText, senderName);

            //依据邮件标题建立Category, 返回最新的CategoryId
            //如果已存在，则获取存在的CategoryId
            int categoryId = GetCategory(subject, senderName);

            int newDocId = _documentController.UpdateDocument(categoryId, document);

            //保存附件信息
            _mailBLL.AddAttachmentInfo(newDocId, atts, ads);

        }

        public int GetCategory(string categoryPath, string editUser)
        {
            int categoryId = 0;

            string[] pathes = categoryPath.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);

            int? parentId = null;
            foreach (var categoryName in pathes)
            {
                var entity = new CategoryEntity();
                entity.CategoryName = categoryName;
                entity.ParentId = parentId;
                entity.EditUser = editUser;
                entity.EditDate = DateTime.Now;
                entity.Status = "A";
                entity = _categoryController.AddNewIfNotExists(entity);

                parentId = entity.CategoryId;
                categoryId = entity.CategoryId.Value;
            }

            return categoryId;
        }

        public DocumentEntity GetDocument(Outlook.MailItem mail, string keywords, string headerText, string editUser)
        {
            DocumentEntity document = new DocumentEntity();
            document = new DocumentEntity();
            document.Status = "A";
            document.DocumentId = null;

            byte[] buffer = _mailBLL.GetDocumentContent(mail, headerText, string.Empty);
            if (buffer == null) return null;

            using (MemoryStream stream = new MemoryStream(buffer))
            {
                document.DocumentContent = CompressHelper.CompressContent(stream);
            }
            document.EditDate = DateTime.Now;
            document.EditUser = editUser;
            document.DocumentKeywords = keywords;

            return document;
        }
    }
}
