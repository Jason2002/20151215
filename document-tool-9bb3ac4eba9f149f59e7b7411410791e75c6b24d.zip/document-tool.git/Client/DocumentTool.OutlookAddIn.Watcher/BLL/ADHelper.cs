﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;

namespace DocumentTool.OutlookAddIn.Watcher.BLL
{
    public static class ADHelper
    {
        public static string GetShortName(string displayName)
        {
            //displayName = "Vincent.W.Wu (mis.cncd02.Newegg) 42109";

            if (string.IsNullOrWhiteSpace(displayName)) return null;

            string filter = "(&(objectCategory=User)(DisplayName={0}))";
            DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://ABS_CORP");
            using (DirectorySearcher ds = new DirectorySearcher(directoryEntry))
            {
                ds.Filter = string.Format(filter, displayName);
                SearchResult sr = ds.FindOne();
                if (sr == null) return null;

                return sr.GetDirectoryEntry().Properties["sAMAccountName"].Value.ToString();
            }
        }
    }
}
