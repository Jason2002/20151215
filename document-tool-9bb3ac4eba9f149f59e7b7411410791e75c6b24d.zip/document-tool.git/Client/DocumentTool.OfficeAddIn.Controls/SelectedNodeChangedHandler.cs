﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentManagementTool.ViewModel;

namespace DocumentTool.OfficeAddIn.Controls
{
    public delegate void SelectedNodeChangedHandler(object sender, TreeNodeEventArgs e);

    public class TreeNodeEventArgs : EventArgs
    {
        public TreeNodeEventArgs(DocumentCategory category, DocumentEntity document)
        {
            Category = category;
            Document = document;
        }

        public DocumentCategory Category { get; private set; }

        public DocumentEntity Document { get; private set; }
    }
}
