﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentManagementTool.Controller
{
    public class DocumentController
    {
        private DocumentClientProxy m_proxy;

        public DocumentController(DocumentClientProxy proxy)
        {
            m_proxy = proxy;
        }

        public DocumentEntity GetDocumentByCategoryId(int categoryId)
        {
            DocumentEntity entity = m_proxy.GetDocument(categoryId);
            return entity;
        }

        public DocumentEntity GetDocumentWithoutContentByCategoryId(int categoryId)
        {
            DocumentEntity entity = m_proxy.GetDocumentWithoutContent(categoryId);
            return entity;
        }

        public int UpdateDocument(int categoryId, DocumentEntity document)
        {
            return m_proxy.ModifyDocument(categoryId, document);
        }

        public List<DocumentEntity> SearchDocuments(string keywords)
        {
            return m_proxy.SearchDocuments(keywords).ToList();
        }

        public int GetCategoryIdByDocument(int documentId)
        {
            return m_proxy.GetCategoryIdByDocumentId(documentId);
        }

        public List<DocumentEntity> GetHistoryInfo(int categoryId)
        {
            return m_proxy.GetHistoryDocuments(categoryId);
        }

        public IEnumerable<DocumentEntity> GetLatestUpdateDocument(int count)
        {
            return m_proxy.GetLatestUpdateDocument(count);
        }
    }
}
