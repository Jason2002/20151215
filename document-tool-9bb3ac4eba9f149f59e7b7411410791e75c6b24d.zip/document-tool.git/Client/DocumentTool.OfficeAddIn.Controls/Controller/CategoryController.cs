﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentManagementTool.Controller
{
    public class CategoryController
    {
        private CategoryClientProxy m_proxy;

        public CategoryController(CategoryClientProxy proxy)
        {
            m_proxy = proxy;
        }

        public void AddCategory(CategoryEntity current)
        {            
            m_proxy.ModifyCategory(current);
        }

        public void DeleteCategory(int categoryId, string userName)
        {
            m_proxy.DeleteCategory(categoryId, userName);
        }

        public void UpdateCategoryParent(int parentId, int categoryId, string userName)
        {
            m_proxy.UpdateCategoryParent(parentId, categoryId, userName);
        }

        public void RanameCategory(CategoryEntity item)
        {
            m_proxy.ModifyCategory(item);
        }

        public CategoryEntity AddNewIfNotExists(CategoryEntity entity)
        {
            return m_proxy.AddNewIfNotExists(entity);
        }
    }
}
