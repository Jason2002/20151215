﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using Newegg.DFIS.Uploader;
using DocumentTool.OfficeAddIn.Controls.Common;

namespace DocumentManagementTool.Controller
{
    public static class AttachmentController
    {
        static string url = ConfigurationManager.AppSettings["UploadWebUrl"];
        static string userName = ConfigurationManager.AppSettings["UploadUserName"];
        static string fileType = ConfigurationManager.AppSettings["UploadFileType"];
        static string fileGroup = ConfigurationManager.AppSettings["UploadFileGroup"];
        static string downloadUrl = ConfigurationManager.AppSettings["DownloadingWebUrl"];

        private static AttachmentClientProxy m_proxy = new AttachmentClientProxy();

        public static string UploadAttachment(string uploadFile)
        {
            string returnUrl = string.Empty;

            string newName = GetFileName(uploadFile);
            //using (FileStream fileStream = new FileStream(uploadFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            //{
            HttpUploader.UploadFile(url, fileGroup, fileType, newName, uploadFile, string.Empty, userName, UploadMethod.Update);
            //}

            returnUrl = downloadUrl + fileGroup + "/" + fileType + "/" + newName;

            return returnUrl;
        }

        public static AttachmentEntity FindAttachmentByHash(string hashCode, string fileName)
        {
            return m_proxy.FindAttachmentByHash(hashCode, fileName);
        }

        private static string GetFileName(string originalFile)
        {
            DateTime date = DateTime.Now;

            FileInfo file = new FileInfo(originalFile);

            //string newName = string.Format("{0}_{1}{2}", file.Name.Substring(0, file.Name.LastIndexOf('.')), date.ToString("yyyyMMddHHmmss"), file.Extension);
            string newName = file.Name;
            newName = newName.Replace(" ", "_");

            return newName;
        }

        public static void AddAttachment(int documentId, AttachmentEntity current)
        {
            m_proxy.AddAttachment(documentId, current);
        }

        public static void AddAttachmentDocument(AttachmentDocumentEntity current)
        {
            m_proxy.AddAttachmentDocument(current);
        }
    }
}
