﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace DocumentManagementTool.ViewModel
{
    public class DocumentCategory
    {
        private readonly ObservableCollection<DocumentCategory> subCategories = new ObservableCollection<DocumentCategory>();

        private string categoryName = String.Empty;

        public int CategoryId { get; set; }

        private DocumentCategory parentCategory;

        public CategoryEntity Entity { get; set; }

        /// <summary>
        /// The nested categories.
        /// </summary>
        public ObservableCollection<DocumentCategory> SubCategories
        {
            get { return subCategories; }
        }


        /// <summary>
        /// The name of the category. This sample also used
        /// the name as the category key.
        /// </summary>
        public string CategoryName
        {
            get { return categoryName; }
            set { categoryName = value; }
        }




        /// <summary>
        /// The parent category, if any. If this is
        /// a top-level category, this property returns null.
        /// </summary>
        public DocumentCategory ParentCategory
        {
            get { return parentCategory; }
            set { parentCategory = value; }
        }

        public string Path
        {
            get { return GetCategoryPath(this); }
        }

        /// <summary>
        /// Creates a category without a parent.
        /// </summary>
        /// <param name="categoryName">The category's name.</param>
        public DocumentCategory(CategoryEntity category)
            : this(category, null)
        {
        }



        /// <summary>
        /// Creates a category for a given parent. This sets the
        /// <see cref="ParentCategory"/> reference, but does not
        /// automatically add the category to the parent's
        /// <see cref="SubCategories"/> collection.
        /// </summary>
        /// <param name="categoryName">The category's name.</param>
        /// <param name="parentCategory">The parent category, if any.</param>
        public DocumentCategory(CategoryEntity category, DocumentCategory parentCategory)
        {
            this.categoryName = category.CategoryName;
            this.CategoryId = category.CategoryId ?? 0;
            this.Entity = category;
            this.parentCategory = parentCategory;
        }

        /// <summary>
        /// Returns a string with the <see cref="CategoryName"/>.
        /// </summary>
        /// <returns>The category name.</returns>
        public override string ToString()
        {
            return "Category: " + categoryName;
        }

        private string GetCategoryPath(DocumentCategory category)
        {
            string parentPath = null;
            if (category.ParentCategory != null)
            {
                parentPath = GetCategoryPath(category.ParentCategory);
            }

            return parentPath + "/" + category.CategoryName;
        }

    }
}
