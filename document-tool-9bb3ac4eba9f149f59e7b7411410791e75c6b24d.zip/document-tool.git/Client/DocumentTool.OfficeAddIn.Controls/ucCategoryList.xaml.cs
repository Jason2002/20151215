﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Hardcodet.Wpf.GenericTreeView;
using DocumentManagementTool.ViewModel;
using System.Windows.Threading;
using DocumentManagementTool.Controller;
using System.Runtime.CompilerServices;
using DocumentManagementTool;
using DocumentTool.OfficeAddIn.Controls.Common;
using System.ComponentModel;

namespace DocumentTool.OfficeAddIn.Controls
{
    /// <summary>
    /// Interaction logic for ucCategoryList.xaml
    /// </summary>
    public partial class ucCategoryList : UserControl
    {
        CategoryClientProxy m_categoryProxy;
        DocumentClientProxy m_documentProxy;
        MessageClientProxy m_messageProxy;
        UserRightsClientProxy m_userProxy;
        CategoryController m_categoryController;
        DocumentController m_documentController;
        DocumentEntity m_currentDocument = null;
        DispatcherTimer m_timer;
        string m_userName;
        UserOperationRights m_userOperation;
        bool m_isFirstLoad = true;

        public event SelectedNodeChangedHandler OnSelectedNodeChanged;

        public ucCategoryList()
        {
            InitializeComponent();
        }

        public DocumentController DocumentController
        {
            get { return m_documentController; }
        }

        public string DefaultNewCategoryName { get; set; }

        private void OnSelectedItemChanged(object sender, RoutedTreeItemEventArgs<DocumentCategory> e)
        {
            try
            {
                if (e.NewItem != null && e.OldItem != null && e.NewItem.CategoryId == e.OldItem.CategoryId)
                {
                    return;
                }

                if (e.NewItem is DocumentCategory)
                {
                    DocumentCategory category = e.NewItem;
                    if (CanViewDocument(category))
                    {
                        m_currentDocument = m_documentController.GetDocumentWithoutContentByCategoryId(category.CategoryId);
                    }
                }
                else
                {
                    m_currentDocument = null;
                }


                if (OnSelectedNodeChanged != null)
                {
                    OnSelectedNodeChanged(this, new TreeNodeEventArgs(e.NewItem, m_currentDocument));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanViewDocument(DocumentCategory item)
        {
            if (m_userOperation.IsAdmin)
            {
                return true;
            }
            return !item.Entity.AuthViewResult;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (DesignerProperties.GetIsInDesignMode(this)) return;

            if (m_isFirstLoad)
            {
                string user = System.Environment.UserName;

                m_userName = user;
                m_timer = new DispatcherTimer();
                m_timer.Interval = TimeSpan.FromMilliseconds(200);
                m_timer.Tick += new EventHandler(m_timer_Tick);
                m_timer.Start();

                m_isFirstLoad = false;
            }
        }

        private void m_timer_Tick(object sender, EventArgs e)
        {
            PrepareConnect();
            m_timer.Stop();
        }

        private void PrepareConnect()
        {
            try
            {
                m_messageProxy = new MessageClientProxy();
                m_documentProxy = new DocumentClientProxy();
                m_categoryProxy = new CategoryClientProxy();
                m_userProxy = new UserRightsClientProxy();
                txtEvent.Text = m_messageProxy.SayHi(m_userName);
                m_userOperation = m_userProxy.GetUserOperationRightsById(m_userName);
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Connect remote error...";
                LogController.WriteLog(ex);
                return;
            }
            m_categoryController = new CategoryController(m_categoryProxy);
            m_documentController = new DocumentController(m_documentProxy);
            RefreshTree(false);
            DocumentTree.RootNode.IsExpanded = true;
            //m_isFirstLoad = false;
        }


        [MethodImpl(MethodImplOptions.Synchronized)]
        public void RefreshTree(bool fromBackground)
        {
            try
            {
                DocumentCategory current = null;
                if (fromBackground)
                {
                    current = DocumentTree.SelectedItem as DocumentCategory;
                }
                DocumentTree.Items = new DocumentModel(m_categoryProxy, m_userName).Categories;
                if (current != null)
                {
                    DocumentTree.TryFindNode(current).IsExpanded = true;

                }
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Refresh category error";
                LogController.WriteLog(ex);
            }

        }

        #region Category Manage

        private bool IsRootCategory(DocumentCategory item)
        {
            return item.CategoryName == "Root";
        }

        public DocumentCategory GetCommandItem()
        {
            //get the processed item
            ContextMenu menu = DocumentTree.NodeContextMenu;
            if (menu.IsVisible)
            {
                //a context menu was clicked
                TreeViewItem treeNode = (TreeViewItem)menu.PlacementTarget;
                if (DocumentTree.RootNode == treeNode)
                {
                    return new DocumentCategory(new CategoryEntity { CategoryId = 0, AuthEditResult = true, AuthViewResult = true, CategoryName = "Root" });
                }
                return (DocumentCategory)treeNode.Header;
            }
            else
            {
                //the context menu is closed - the user has pressed a shortcut
                return DocumentTree.SelectedItem;
            }
        }

        private void AddCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory parent = GetCommandItem();

            //create a sub category
            CategoryEntity newCategory = ShowInputDialog(null, IsRootCategory(parent), DefaultNewCategoryName);
            if (newCategory == null || string.IsNullOrEmpty(newCategory.CategoryName))
            {
                e.Handled = true;
                return;
            }
            newCategory.EditUser = m_userName;
            if (!IsRootCategory(parent))
            {
                newCategory.ParentId = parent.CategoryId;
            }
            try
            {
                m_categoryController.AddCategory(newCategory);
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Add category error";
                LogController.WriteLog(ex);
            }

            RefreshTree(false);
            //make sure the parent is expanded
            if (!IsRootCategory(parent))
            {
                DocumentTree.TryFindNode(parent).IsExpanded = true;
            }

            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            //Important - mark the event as handled
            e.Handled = true;
        }

        private CategoryEntity ShowInputDialog(DocumentCategory category, bool isRoot, string defaultName)
        {
            InputDialog dlg = null;
            if (string.IsNullOrEmpty(defaultName))
            {
                dlg = new InputDialog(category, isRoot);
            }
            else
            {
                dlg = new InputDialog(category, isRoot, defaultName);
            }
            var interopHelper = new System.Windows.Interop.WindowInteropHelper(dlg)
            {
                Owner = this.FindForm().Handle
            };

            //dlg.Owner = this;
            //Shadow.Visibility = Visibility.Visible;
            if (dlg.ShowDialog().Value)
            {
                //Shadow.Visibility = Visibility.Collapsed;
                return dlg.GetSetupInfo();
            }
            else
            {
                //Shadow.Visibility = Visibility.Collapsed;
                return null;
            }
        }

        private void EvaluateCanAdd(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();

            e.CanExecute = CanEdit(item);
            e.Handled = true;
        }

        public bool CanPublish
        {
            get
            {
                DocumentCategory current = DocumentTree.SelectedItem;
                return (current != null) && CanEdit(current);
            }
        }

        private bool CanEdit(DocumentCategory item)
        {

            if (m_userOperation.IsAdmin)
            {
                return true;
            }
            return !item.Entity.AuthEditResult;
        }

        private void EvaluateCanRename(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();

            if (!IsRootCategory(item) && CanEdit(item))
            {
                if (item.ParentCategory == null)
                {
                    e.CanExecute = m_userOperation.IsAdmin;
                }
                else
                {
                    e.CanExecute = true;
                }
                e.Handled = true;
            }
        }

        private void RenameCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            //create a sub category
            CategoryEntity modified = ShowInputDialog(item, item.ParentCategory == null, null);
            if (modified == null || string.IsNullOrEmpty(modified.CategoryName))
            {
                e.Handled = true;
                return;
            }
            modified.EditUser = m_userName;
            try
            {
                m_categoryController.RanameCategory(modified);
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Rename category error";
                LogController.WriteLog(ex);
            }
            RefreshTree(false);
            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            //Important - mark the event as handled
            e.Handled = true;
        }

        private void EvaluateCanDelete(object sender, CanExecuteRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            if (!IsRootCategory(item) && CanEdit(item) && (item.SubCategories == null || item.SubCategories.Count == 0))
            {
                e.CanExecute = true;
            }

            e.Handled = true;
        }

        private void DeleteCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get item
            DocumentCategory item = GetCommandItem();

            if (MessageBox.Show("Delete category will also delete document which belongs to it. Continue?", "Confirm", MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.OK)
            {


                //remove from parent
                try
                {
                    m_categoryController.DeleteCategory(item.CategoryId, m_userName);
                }
                catch (Exception ex)
                {
                    txtEvent.Text = "Delete category error";
                    LogController.WriteLog(ex);
                }
                RefreshTree(false);
                //item.ParentCategory.SubCategories.Remove(item);
                DocumentCategory parent = item.ParentCategory;
                if (parent != null)
                {
                    if (parent.SubCategories.Count > 0)
                    {
                        DocumentTree.TryFindNode(parent).IsExpanded = true;
                    }
                    else
                    {
                        DocumentTree.TryFindNode(parent).IsExpanded = false;
                    }
                    DocumentTree.SelectedItem = parent;
                }
            }
            //mark event as handled

            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            e.Handled = true;
        }

        private void EvaluateCanCut(object sender, CanExecuteRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            if (CanEdit(item) && !IsRootCategory(item) && item.ParentCategory != null)
            {
                e.CanExecute = true;
            }

            e.Handled = true;
        }

        private void CutCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            this.CuttedCategory = item;
        }

        private void EvaluateCanPaste(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();
            if (!IsRootCategory(item) && CanEdit(item) && this.CuttedCategory != null)
            {
                e.CanExecute = true;
            }

            e.Handled = true;
        }

        private void PasteCategory(object sender, ExecutedRoutedEventArgs e)
        {
            DocumentCategory cutted = this.CuttedCategory;
            if (cutted != null)
            {
                DocumentCategory item = GetCommandItem();
                if (item.ParentCategory != null && item.ParentCategory.CategoryId == cutted.CategoryId)
                {
                    MessageBox.Show("Can not paste here.");
                    return;
                }

                if (cutted.ParentCategory.CategoryId == item.CategoryId)
                {
                    this.CuttedCategory = null;
                    return;
                }
                try
                {
                    m_categoryController.UpdateCategoryParent(item.CategoryId, cutted.CategoryId, m_userName);
                }
                catch (Exception ex)
                {
                    txtEvent.Text = "Paste category error";
                    LogController.WriteLog(ex);
                }
                RefreshTree(false);
                this.CuttedCategory = null;
                TreeLayout layout = DocumentTree.GetTreeLayout();
                DocumentTree.Refresh(layout);
                e.Handled = true;
            }
        }

        private void EvaluateCanReload(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;

            e.Handled = true;
        }

        private void ReloadCategory(object sender, ExecutedRoutedEventArgs e)
        {
            RefreshTree(false);
            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            e.Handled = true;
        }


        public DocumentCategory CuttedCategory
        {
            get
            {
                if (AppDomain.CurrentDomain.GetData("CuttedCategory") != null)
                {
                    return (DocumentCategory)AppDomain.CurrentDomain.GetData("CuttedCategory");
                }
                else
                {
                    return null;
                }
            }
            set
            {
                AppDomain.CurrentDomain.SetData("CuttedCategory", value);
            }
        }

        #endregion

        private void UserControl_Unloaded(object sender, RoutedEventArgs e)
        {
            //if (m_timer != null)
            //{
            //    m_timer.Stop();
            //}
            //try
            //{
            //    m_messageProxy.SayGoodbye(m_userName);
            //}
            //catch (Exception ex)
            //{
            //    LogController.WriteLog(ex);
            //    return;
            //}
        }
    }
}
