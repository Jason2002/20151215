﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO.Packaging;
using System.IO;

namespace DocumentTool.OfficeAddIn.Controls.Common
{
    public class OfficeFileExtractor
    {
        string embeddingPartString;

        /// <summary>
        /// This method extracts the files to the folder mentioned in the Destination Folder text box.
        /// If the extracted file is a structured storage, it will be sent to Ole10Native.ExtractFile() method 
        /// to extract the actual contents.
        /// </summary>
        /// <param name="sourceFile"></param>
        /// <param name="destFolder"></param>
        public bool Extract(string sourceFile, string destFolder, string fileExtension)
        {
            if (string.IsNullOrEmpty(sourceFile) || string.IsNullOrEmpty(destFolder))
            {
                throw new ApplicationException("The source file and destination folder cannot be empty");
            }
            if (!File.Exists(sourceFile))
            {
                throw new ApplicationException("The file does not exist");
            }

            IList<string> partUriList = Scan(sourceFile, fileExtension);
            if (partUriList == null) return false;

            // Open the package and loop through parts 
            // Check if the part uri to find if it contains the selected items in checked list box
            Package pkg = Package.Open(sourceFile);
            foreach (PackagePart pkgPart in pkg.GetParts())
            {
                for (int i = 0; i < partUriList.Count; i++)
                {
                    if (pkgPart.Uri.ToString().Contains(partUriList[i]))
                    {
                        // Get the file name
                        string fileName1 = pkgPart.Uri.ToString().Remove(0, embeddingPartString.Length);

                        // Get the stream from the part

                        System.IO.Stream partStream = pkgPart.GetStream();
                        string filePath = destFolder + "\\" + fileName1;

                        // Write the steam to the file.
                        System.IO.FileStream writeStream = new System.IO.FileStream(filePath, FileMode.Create, FileAccess.Write);
                        ReadWriteStream(pkgPart.GetStream(), writeStream);

                        // If the file is a structured storage file stored as a oleObjectXX.bin file
                        // Use Ole10Native class to extract the contents inside it.
                        if (fileName1.Contains("oleObject"))
                        {
                            // The Ole10Native class is defined in Ole10Native.cs file
                            Ole10Native.ExtractFile(filePath, destFolder);
                        }
                    }
                }

            }
            pkg.Close();

            //foreach (string filename in Directory.GetFiles(destFolder, "*.bin"))
            //{
            //    File.Delete(filename);
            //}

            if (Directory.GetFiles(destFolder).Count(f => Path.GetExtension(f) != ".bin") == 0) return false;

            return true;
        }

        /// <summary>
        /// This event scans through the file to check if there is any files embedded in it.
        /// If there is any, it will add the name of the file in the checked list box
        /// </summary>
        /// <param name="sourceFile"></param>
        private IList<string> Scan(string sourceFile, string fileExtension)
        {
            string fileName = sourceFile;
            if (sourceFile == string.Empty || !System.IO.File.Exists(fileName))
            {
                throw new ApplicationException("The file does not exist");
            }

            // Open the package file
            Package pkg = Package.Open(fileName);

            System.IO.FileInfo fi = new System.IO.FileInfo(fileName);

            string extension = fileExtension;//fi.Extension.ToLower();

            if ((extension == ".docx") || (extension == ".dotx") || (extension == ".docm") || (extension == ".dotm"))
            {
                embeddingPartString = "/word/embeddings/";
            }
            else if ((extension == ".xlsx") || (extension == ".xlsm") || (extension == ".xltx") || (extension == ".xltm"))
            {
                embeddingPartString = "/excel/embeddings/";
            }
            else
            {
                embeddingPartString = "/ppt/embeddings/";
            }

            IList<string> result = new List<string>();

            // Get the embedded files names.
            foreach (PackagePart pkgPart in pkg.GetParts())
            {
                if (pkgPart.Uri.ToString().StartsWith(embeddingPartString))
                {
                    //string fileName1 = pkgPart.Uri.ToString().Remove(0, embeddingPartString.Length);
                    //result.Add(fileName1);
                    result.Add(pkgPart.Uri.ToString());
                }
            }
            pkg.Close();

            if (result.Count == 0) return null;

            return result;
        }

        /// <summary>
        /// ReadWriteStream method is used to extract the files from the document to a temporary location
        /// If the extracted file is a structured storage, it will be sent to the ExtractFile method to extract the actual content
        /// </summary>
        /// <param name="readStream"></param>
        /// <param name="writeStream"></param>
        private void ReadWriteStream(Stream readStream, Stream writeStream)
        {
            int Length = 256;
            Byte[] buffer = new Byte[Length];
            int bytesRead = readStream.Read(buffer, 0, Length);
            // write the required bytes
            while (bytesRead > 0)
            {
                writeStream.Write(buffer, 0, bytesRead);
                bytesRead = readStream.Read(buffer, 0, Length);
            }
            readStream.Close();
            writeStream.Close();
        }
    }
}
