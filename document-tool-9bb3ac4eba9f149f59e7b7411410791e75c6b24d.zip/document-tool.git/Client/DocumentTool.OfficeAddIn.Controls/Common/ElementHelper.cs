﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Interop;
using System.Windows;
using System.Windows.Media;
using System.Windows.Forms.Integration;

namespace DocumentTool.OfficeAddIn.Controls.Common
{
    public static class ElementHelper
    {
        /// <summary>
        /// 在WinForm窗口包含WPF控件的场景下，获取所在的窗口句柄。
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static Form FindForm(this Visual element)
        {
            HwndSource wpfHandle = PresentationSource.FromVisual(element) as HwndSource;

            if (wpfHandle == null)
            {
                return null;
            }

            ElementHost elementHost = Control.FromChildHandle(wpfHandle.Handle) as ElementHost;
            return elementHost.FindForm();
        }
    }
}
