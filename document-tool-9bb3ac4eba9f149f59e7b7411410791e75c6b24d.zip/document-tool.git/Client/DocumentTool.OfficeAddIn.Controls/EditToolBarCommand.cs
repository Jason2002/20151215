﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace DocumentManagementTool
{
    public static class EditToolBarCommand
    {
        public static RoutedUICommand AddDocument;

        public static RoutedUICommand EditDocument;

        public static RoutedUICommand SaveDocument;

        public static RoutedUICommand CancelEdit;

        public static RoutedCommand ShowHistory;

        public static RoutedCommand UploadAttach;

        static EditToolBarCommand()
        {
            InputGestureCollection inputAdd = new InputGestureCollection();
            AddDocument = new RoutedUICommand("Add Document", "AddDocument", typeof(EditToolBarCommand), inputAdd);

            InputGestureCollection inputEdit = new InputGestureCollection();
            EditDocument = new RoutedUICommand("Edit Document", "EditDocument", typeof(EditToolBarCommand), inputEdit);

            InputGestureCollection inputSave = new InputGestureCollection();
            SaveDocument = new RoutedUICommand("Save Document", "SaveDocument", typeof(EditToolBarCommand), inputSave);

            InputGestureCollection inputCancel = new InputGestureCollection();
            CancelEdit = new RoutedUICommand("Cancel Edit", "CancelEdit", typeof(EditToolBarCommand), inputCancel);

            InputGestureCollection inputHistory = new InputGestureCollection();
            ShowHistory = new RoutedUICommand("Show History Info", "ShowHistory", typeof(EditToolBarCommand), inputHistory);

            InputGestureCollection upload = new InputGestureCollection();
            UploadAttach = new RoutedUICommand("Upload Attachment", "UploadAttach", typeof(EditToolBarCommand), upload);
        }

        
    }

    public static class MenuTreeCommand
    {
        public static RoutedUICommand NewCategory;
        public static RoutedUICommand DeleteCategory;
        public static RoutedUICommand CutCategory;
        public static RoutedUICommand PasteCategory;
        public static RoutedUICommand ReplaceCategory;
        public static RoutedUICommand ReloadCategory;

        static MenuTreeCommand()
        {
            InputGestureCollection newCategory = new InputGestureCollection();
            NewCategory = new RoutedUICommand("Add Subcategory", "NewCategory", typeof(MenuTreeCommand), newCategory);

            InputGestureCollection deleteCategory = new InputGestureCollection();
            DeleteCategory = new RoutedUICommand("Remove Category", "DeleteCategory", typeof(MenuTreeCommand), deleteCategory);

            InputGestureCollection cutCategory = new InputGestureCollection();
            CutCategory = new RoutedUICommand("Cut Category", "CutCategory", typeof(MenuTreeCommand), cutCategory);

            InputGestureCollection pasteCategory = new InputGestureCollection();
            PasteCategory = new RoutedUICommand("Paste Category", "PasteCategory", typeof(MenuTreeCommand), pasteCategory);

            InputGestureCollection replaceCategory = new InputGestureCollection();
            ReplaceCategory = new RoutedUICommand("Rename Subcategory", "ReplaceCategory", typeof(MenuTreeCommand), replaceCategory);

            InputGestureCollection reloadCategory = new InputGestureCollection();
            ReloadCategory = new RoutedUICommand("Reload Category", "ReloadCategory", typeof(MenuTreeCommand), reloadCategory);
        }
    }
}
