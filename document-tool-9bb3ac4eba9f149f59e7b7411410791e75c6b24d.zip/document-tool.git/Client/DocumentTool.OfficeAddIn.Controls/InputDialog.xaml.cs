﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.ViewModel;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for InputDialog.xaml
    /// </summary>
    public partial class InputDialog : Window
    {
        public DocumentCategory DefaultCategory { get; private set; }
        private bool m_isRoot = false;

        public InputDialog(DocumentCategory category, bool isRoot)
        {
            if (category == null)
            {
                DefaultCategory = new DocumentCategory(new CategoryEntity { IsAuthEdit = true, IsAuthShow = false });
            }
            else
            {
                DefaultCategory = category;
            }
            m_isRoot = isRoot;
            InitializeComponent();
            txtCategory.Focus();
        }

        public InputDialog(DocumentCategory category, bool isRoot, string defaultName)
            : this(category, isRoot)
        {
            DefaultCategory.CategoryName = defaultName;
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (m_isRoot)
            {
                spAuth.Visibility = Visibility.Visible;
                chkView.IsChecked = DefaultCategory.Entity.IsAuthShow.Value;
                chkEdit.IsChecked = DefaultCategory.Entity.IsAuthEdit.Value;
            }
            else
            {
                spAuth.Visibility = Visibility.Hidden;
            }
            txtCategory.Text = DefaultCategory.CategoryName;
            
        }

        public CategoryEntity GetSetupInfo()
        {
            CategoryEntity entity = new CategoryEntity();
            entity.CategoryId = DefaultCategory.Entity.CategoryId;
            entity.CategoryName = txtCategory.Text;
            if (m_isRoot)
            {
                entity.IsAuthShow = chkView.IsChecked;
                entity.IsAuthEdit = chkEdit.IsChecked;
            }
            entity.Status = "A";
            entity.EditDate = DateTime.Now;
            return entity;
        }
    }
}
