﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Channels;


#region Service Define

[ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public interface IMessageService
{
    [OperationContract]
    string SayHi(string userName);

    [OperationContract]
    void SayGoodbye(string userName);

    [OperationContract]
    List<LogEntity> GetRecentlyLog(int lastID);
}

[ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public interface ICategoryService
{
    [OperationContract]
    IEnumerable<CategoryEntity> GetCategoryTree(string uid);

    [OperationContract]
    void ModifyCategory(CategoryEntity category);

    [OperationContract]
    void UpdateCategoryParent(int parentId, int categoryId, string userName);

    [OperationContract]
    void DeleteCategory(int categoryId, string userName);

    [OperationContract]
    CategoryEntity AddNewIfNotExists(CategoryEntity entity);

    [OperationContract]
    RuleList GetPublishRuleList();
}

[ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public interface IDocumentService
{
    [OperationContract]
    int ModifyDocument(int categoryId, DocumentEntity document);

    [OperationContract]
    void DeleteDocument(int categoryId);

    [OperationContract]
    DocumentEntity GetDocument(int categoryId);

    [OperationContract]
    DocumentEntity GetDocumentById(int documentId);

    [OperationContract]
    DocumentEntity GetDocumentWithoutContent(int categoryId);

    [OperationContract]
    List<DocumentEntity> GetHistoryDocuments(int categoryId);

    [OperationContract]
    IEnumerable<DocumentEntity> SearchDocuments(string keywords);

    [OperationContract]
    int GetCategoryIdByDocumentId(int documentId);

    [OperationContract]
    IEnumerable<DocumentEntity> GetLatestUpdateDocument(int count);
}

[ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public interface IUserService
{
    [OperationContract]
    List<UserRightsEntity> GetUserRightsById(string uid);

    [OperationContract]
    void AddUserRights(List<UserRightsEntity> rights, string uid);

    [OperationContract]
    UserOperationRights GetUserOperationRightsById(string uid);
}

[ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public interface IAttachmentService
{
    [OperationContract]
    void AddAttachment(int documentId, AttachmentEntity entity);

    [OperationContract]
    void AddAttachmentDocument(AttachmentDocumentEntity entity);

    [OperationContract]
    AttachmentEntity FindAttachmentByHash(string hashCode, string fileName);
}

[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class CategoryEntity
{
    [DataMember]
    public int? CategoryId { get; set; }

    [DataMember]
    public string CategoryName { get; set; }

    [DataMember]
    public string EditUser { get; set; }

    [DataMember]
    public DateTime EditDate { get; set; }

    [DataMember]
    public string Status { get; set; }

    [DataMember]
    public bool? IsAuthEdit { get; set; }

    [DataMember]
    public bool? IsAuthShow { get; set; }

    [DataMember]
    public bool AuthEditResult { get; set; }

    [DataMember]
    public bool AuthViewResult { get; set; }

    [DataMember]
    public int? ParentId { get; set; }

    [DataMember]
    public List<CategoryEntity> SubCategories { get; set; }

    [DataMember]
    public List<DocumentEntity> Documents { get; set; }
}

[Serializable]
[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class DocumentEntity
{
    [DataMember]
    public int? DocumentId { get; set; }

    [DataMember]
    public string DocumentContent { get; set; }

    [DataMember]
    public string SearchName { get; set; }

    [DataMember]
    public string SearchAttUrl { get; set; }

    [DataMember]
    public string DocumentKeywords { get; set; }

    [DataMember]
    public string EditUser { get; set; }

    [DataMember]
    public DateTime EditDate { get; set; }

    [DataMember]
    public string Version { get; set; }

    [DataMember]
    public string Status { get; set; }

    public bool GenerateFlag { get; set; }
}

[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class LogEntity
{
    [DataMember]
    public int TransactionNumber { get; set; }

    [DataMember]
    public string UserID { get; set; }

    [DataMember]
    public string LogContent { get; set; }

    [DataMember]
    public string LogType { get; set; }

    [DataMember]
    public System.DateTime LogDate { get; set; }

}

[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class UserRightsEntity
{
    [DataMember]
    public int TransactionNumber { get; set; }

    [DataMember]
    public string UserID { get; set; }

    [DataMember]
    public int RootID { get; set; }

    [DataMember]
    public bool CanView { get; set; }

    [DataMember]
    public bool CanEdit { get; set; }

    [DataMember]
    public string EditUser { get; set; }

    [DataMember]
    public bool IsOwner { get; set; }

    [DataMember]
    public System.DateTime EditDate { get; set; }

    public string RootName { get; set; }

    public bool CanSet { get; set; }

}

[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class UserOperationRights
{
    [DataMember]
    public bool IsAdmin { get; set; }

    [DataMember]
    public bool IsOwner { get; set; }

    [DataMember]
    public List<int> OwnerCategoryID { get; set; }
}

[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class AttachmentEntity
{
    [DataMember]
    public int AttachmentId { get; set; }

    [DataMember]
    public string FileName { get; set; }

    [DataMember]
    public string DownloadUrl { get; set; }

    [DataMember]
    public string HashCode { get; set; }

    [DataMember]
    public string EditUser { get; set; }

    [DataMember]
    public DateTime EditDate { get; set; }

    [DataMember]
    public bool GenerateFlag { get; set; }
}

[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class AttachmentDocumentEntity
{
    [DataMember]
    public int AttachmentId { get; set; }

    [DataMember]
    public int DocumentId { get; set; }

    [DataMember]
    public string EditUser { get; set; }

    [DataMember]
    public DateTime EditDate { get; set; }
}

[Serializable]
[CollectionDataContract(Name = "Rules", ItemName = "Rule", Namespace = "http://newegg.com/DocumentManagementTool")]
public class RuleList : List<Rule>
{

}

[Serializable]
[DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
public class Rule
{
    [DataMember]
    public string Section { get; set; }
}

#endregion

public partial class MessageClientProxy : ClientBase<IMessageService>, IMessageService
{

    #region IMessageService Members

    public string SayHi(string userName)
    {
        return Channel.SayHi(userName);
    }

    public void SayGoodbye(string userName)
    {
        Channel.SayGoodbye(userName);
    }

    public List<LogEntity> GetRecentlyLog(int lastID)
    {
        return Channel.GetRecentlyLog(lastID);
    }

    #endregion
}

public partial class DocumentClientProxy : ClientBase<IDocumentService>, IDocumentService
{

    #region IDocumentService Members

    public int ModifyDocument(int categoryId, DocumentEntity document)
    {
        return Channel.ModifyDocument(categoryId, document);
    }

    public void DeleteDocument(int categoryId)
    {
        Channel.DeleteDocument(categoryId);
    }

    public DocumentEntity GetDocument(int categoryId)
    {
        return Channel.GetDocument(categoryId);
    }

    public DocumentEntity GetDocumentById(int documentId)
    {
        return Channel.GetDocumentById(documentId);
    }

    public DocumentEntity GetDocumentWithoutContent(int categoryId)
    {
        return Channel.GetDocumentWithoutContent(categoryId);
    }

    public IEnumerable<DocumentEntity> SearchDocuments(string keywords)
    {
        return Channel.SearchDocuments(keywords);
    }

    public int GetCategoryIdByDocumentId(int documentId)
    {
        return Channel.GetCategoryIdByDocumentId(documentId);
    }

    public List<DocumentEntity> GetHistoryDocuments(int categoryId)
    {
        return Channel.GetHistoryDocuments(categoryId);
    }

    public IEnumerable<DocumentEntity> GetLatestUpdateDocument(int count)
    {
        return Channel.GetLatestUpdateDocument(count);
    }

    #endregion
}

public partial class CategoryClientProxy : ClientBase<ICategoryService>, ICategoryService
{
    #region ICategoryService Members

    public IEnumerable<CategoryEntity> GetCategoryTree(string uid)
    {
        return Channel.GetCategoryTree(uid);
    }

    public void ModifyCategory(CategoryEntity category)
    {
        Channel.ModifyCategory(category);
    }

    public void UpdateCategoryParent(int parentId, int categoryId, string userName)
    {
        Channel.UpdateCategoryParent(parentId, categoryId, userName);
    }

    public void DeleteCategory(int categoryId, string userName)
    {
        Channel.DeleteCategory(categoryId, userName);
    }

    public CategoryEntity AddNewIfNotExists(CategoryEntity entity)
    {
        return Channel.AddNewIfNotExists(entity);
    }

    public RuleList GetPublishRuleList()
    {
        return Channel.GetPublishRuleList();
    }

    #endregion
}

public partial class UserRightsClientProxy : ClientBase<IUserService>, IUserService
{
    #region IUserService Members

    public List<UserRightsEntity> GetUserRightsById(string uid)
    {
        return Channel.GetUserRightsById(uid);
    }

    public void AddUserRights(List<UserRightsEntity> rights, string uid)
    {
        Channel.AddUserRights(rights, uid);
    }

    public UserOperationRights GetUserOperationRightsById(string uid)
    {
        return Channel.GetUserOperationRightsById(uid);
    }

    #endregion
}

public partial class AttachmentClientProxy : ClientBase<IAttachmentService>, IAttachmentService
{
    #region IAttachmentService Members

    public void AddAttachment(int documentId, AttachmentEntity entity)
    {
        Channel.AddAttachment(documentId, entity);
    }

    public void AddAttachmentDocument(AttachmentDocumentEntity entity)
    {
        Channel.AddAttachmentDocument(entity);
    }

    public AttachmentEntity FindAttachmentByHash(string hashCode, string fileName)
    {
        return Channel.FindAttachmentByHash(hashCode, fileName);
    }

    #endregion
}


