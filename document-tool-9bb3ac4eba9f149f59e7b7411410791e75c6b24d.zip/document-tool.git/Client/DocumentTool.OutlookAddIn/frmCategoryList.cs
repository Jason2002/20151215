﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Outlook = Microsoft.Office.Interop.Outlook;
using Microsoft.Office.Tools.Outlook;
using DocumentManagementTool.Controller;
using DocumentManagementTool.ViewModel;
using DocumentTool.OfficeAddIn.Controls;
using DocumentTool.OutlookAddIn.BLL;

namespace DocumentTool.OutlookAddIn
{
    public partial class frmCategoryList : Form
    {
        private Outlook.Application app = null;
        private string _userName = string.Empty;
        private DocumentEntity _document;
        private bool _isFirstLoad = true;
        private MailBLL _mailBLL = new MailBLL();

        public frmCategoryList()
        {
            InitializeComponent();
        }

        public Outlook.MailItem Mail { get; set; }

        private void frmCategoryList_Load(object sender, EventArgs e)
        {
            if (DesignMode) return;

            app = Globals.ThisAddIn.Application;
            _userName = System.Environment.UserName;
            ucCategoryTree.DefaultNewCategoryName = Mail.Subject;

            if (_isFirstLoad)
            {
                ucCategoryTree.OnSelectedNodeChanged += new SelectedNodeChangedHandler(ucCategoryTree_OnSelectedNodeChanged);
                btnOK.Enabled = false;
            }

            _isFirstLoad = false;
        }

        private void ucCategoryTree_OnSelectedNodeChanged(object sender, TreeNodeEventArgs e)
        {
            if (e.Document != null)
            {
                _document = e.Document;
                txtKeywords.Text = e.Document.DocumentKeywords;
            }
            else
            {
                _document = null;
                txtKeywords.Text = string.Empty;
            }

            bool canPublish = e.Category != null && ucCategoryTree.CanPublish;
            btnOK.Enabled = canPublish;
            txtKeywords.ReadOnly = !canPublish;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                //上传附件
                string downloadUrls_Att = string.Empty;
                string downloadUrls_Embed = string.Empty;
                IList<AttachmentEntity> atts = null;
                IList<AttachmentDocumentEntity> ads = null;
                _mailBLL.UploadAttachment(Mail, ref downloadUrls_Att, ref downloadUrls_Embed, ref atts, ref ads);

                //构造邮件头信息
                string headerText = _mailBLL.BuildAppendInfo(Mail, downloadUrls_Att, downloadUrls_Embed);

                //发布邮件
                int newDocId = SaveDocument(ucCategoryTree.GetCommandItem(), headerText);

                //保存附件信息
                _mailBLL.AddAttachmentInfo(newDocId, atts, ads);

                MessageBox.Show("publish succeeded.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LogController.WriteLog(ex);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        public int SaveDocument(DocumentCategory category, string headerText)
        {
            DocumentEntity entity = GetDocument(headerText);
            if (entity == null) throw new ApplicationException("not found data.");

            entity.EditUser = _userName;
            entity.EditDate = DateTime.Now;

            return ucCategoryTree.DocumentController.UpdateDocument(category.CategoryId, entity);
        }

        public DocumentEntity GetDocument(string headerText)
        {
            if (_document == null)
            {
                _document = new DocumentEntity();
                _document.Status = "A";
                _document.DocumentId = null;
            }

            byte[] buffer = _mailBLL.GetDocumentContent(Mail, headerText, string.Empty);
            if (buffer == null) return null;

            using (MemoryStream stream = new MemoryStream(buffer))
            {
                _document.DocumentContent = CompressHelper.CompressContent(stream);
            }
            _document.EditDate = DateTime.Now;
            _document.EditUser = _userName;
            _document.DocumentKeywords = txtKeywords.Text.Trim();

            return _document;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

    }
}
