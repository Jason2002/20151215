﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using Microsoft.Office.Interop.Outlook;

namespace DocumentTool.OutlookAddIn
{
    public partial class rbnMain
    {
        private Outlook.Application app = null;
        private frmCategoryList _frmCategoryList = new frmCategoryList();

        private void rbnMain_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void btnPublish_Click(object sender, RibbonControlEventArgs e)
        {
            app = Globals.ThisAddIn.Application;

            Outlook.Explorer currentExplorer = app.ActiveExplorer();
            if (currentExplorer.Selection.Count == 0) return;

            object selObject = currentExplorer.Selection[1];

            MailItem mail = selObject as MailItem;
            if (mail == null)
            {
                MessageBox.Show("non-mail item not supported.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            _frmCategoryList.Mail = mail;
            _frmCategoryList.ShowDialog();
        }
    }
}
