﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using Outlook = Microsoft.Office.Interop.Outlook;
using Word = Microsoft.Office.Interop.Word;
using System.Windows.Forms;
using System.Drawing;
using DocumentTool.OfficeAddIn.Controls.Common;
using DocumentManagementTool.Controller;

namespace DocumentTool.OutlookAddIn.BLL
{
    public class MailBLL
    {
        private const string PR_ATTACH_DATA_BIN = "http://schemas.microsoft.com/mapi/proptag/0x37010102";

        public void UploadAttachment(Outlook.MailItem mail, ref string downloadUrls_Att,
            ref string downloadUrls_Embed, ref IList<AttachmentEntity> atts, ref IList<AttachmentDocumentEntity> ads,
            string editUser = null)
        {
            atts = new List<AttachmentEntity>();
            ads = new List<AttachmentDocumentEntity>();
            if (string.IsNullOrWhiteSpace(editUser))
            {
                editUser = Environment.UserName;
            }

            //保存附件信息
            if (mail.Attachments.Count > 0)
            {
                bool isHasOlePackage = false;

                string downloadUrl = string.Empty;
                for (int i = 1; i <= mail.Attachments.Count; i++)
                {
                    if (mail.Attachments[i].Type == Outlook.OlAttachmentType.olOLE) continue;

                    if (mail.Attachments[i].FileName.EndsWith(".emz")
                        || mail.Attachments[i].FileName.EndsWith(".mso"))
                    {
                        isHasOlePackage = true;
                        continue;
                    }

                    //获取附件字节流
                    byte[] att_buffer = ReadAttBytes(mail.Attachments[i]);

                    //通过Hash比较附件已存在则不用上传
                    string hashCode = HashHelper.SHA1File(att_buffer);
                    string attfileName = mail.Attachments[i].FileName;
                    AttachmentEntity att = AttachmentController.FindAttachmentByHash(hashCode, attfileName);
                    if (att == null)
                    {
                        //上传附件
                        downloadUrl = DfisBLL.UploadAttachment(mail.Attachments[i].FileName, att_buffer);

                        att = new AttachmentEntity();
                        att.FileName = attfileName;
                        att.DownloadUrl = downloadUrl;
                        att.HashCode = hashCode;
                        att.EditUser = editUser;
                        att.EditDate = DateTime.Now;
                        att.GenerateFlag = false;
                        atts.Add(att);
                    }
                    else
                    {
                        downloadUrl = att.DownloadUrl;

                        AttachmentDocumentEntity ad = new AttachmentDocumentEntity();
                        ad.AttachmentId = att.AttachmentId;
                        ad.EditUser = editUser;
                        ad.EditDate = DateTime.Now;

                        ads.Add(ad);
                    }

                    //构造附件下载地址
                    if (mail.Attachments[i].Type == Outlook.OlAttachmentType.olByValue)
                    {
                        downloadUrls_Att += string.Concat(Environment.NewLine,
                            new string(' ', 4), downloadUrl);
                    }
                    else
                    {
                        downloadUrls_Embed += string.Concat(Environment.NewLine,
                            new string(' ', 4), downloadUrl);
                    }
                }

                //处理OLE对象，即从Word内嵌对象Copy到邮件正文中的对象
                if (isHasOlePackage)
                {
                    //转换正文为Word文件
                    Word.Document wordDoc = (Word.Document)mail.GetInspector.WordEditor;
                    object fileName = Path.GetTempFileName();
                    object fileFormat = Word.WdSaveFormat.wdFormatDocumentDefault;
                    object missing = Type.Missing;
                    wordDoc.SaveAs(ref fileName, ref fileFormat, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

                    //从Word文件中提取数据
                    string sourceFile = fileName.ToString();
                    string destFolder = GetTempFolder();
                    OfficeFileExtractor officeFileExtractor = new OfficeFileExtractor();

                    if (officeFileExtractor.Extract(sourceFile, destFolder, ".docx"))
                    {
                        foreach (string file in (Directory.GetFiles(destFolder).Where(f => Path.GetExtension(f) != ".bin")))
                        {
                            //通过Hash比较附件已存在则不用上传
                            string hashCode = HashHelper.SHA1File(file);
                            string attfileName = Path.GetFileName(file);
                            AttachmentEntity att = AttachmentController.FindAttachmentByHash(hashCode, attfileName);
                            if (att == null)
                            {
                                //上传附件
                                downloadUrl = DfisBLL.UploadAttachment(file);

                                att = new AttachmentEntity();
                                att.FileName = attfileName;
                                att.DownloadUrl = downloadUrl;
                                att.HashCode = hashCode;
                                att.EditUser = editUser;
                                att.EditDate = DateTime.Now;
                                att.GenerateFlag = false;
                                atts.Add(att);
                            }
                            else
                            {
                                downloadUrl = att.DownloadUrl;

                                AttachmentDocumentEntity ad = new AttachmentDocumentEntity();
                                ad.AttachmentId = att.AttachmentId;
                                ad.EditUser = editUser;
                                ad.EditDate = DateTime.Now;

                                ads.Add(ad);
                            }

                            downloadUrls_Embed += string.Concat(Environment.NewLine,
                               new string(' ', 4), downloadUrl);
                        }
                    }
                }
            }

            if (atts.Count == 0) atts = null;
            if (ads.Count == 0) ads = null;
            //if (atts.Count == 0) return null;
            //return atts;
        }

        /// <summary>
        /// 写入附件信息到数据库
        /// </summary>
        /// <param name="documentId"></param>
        /// <param name="atts"></param>
        public void AddAttachmentInfo(int documentId, IList<AttachmentEntity> atts, IList<AttachmentDocumentEntity> ads)
        {
            if (atts != null)
            {
                foreach (AttachmentEntity att in atts)
                {
                    //att.DocumentId = documentId;
                    AttachmentController.AddAttachment(documentId, att);
                }
            }
            if (ads != null)
            {
                foreach (AttachmentDocumentEntity ad in ads)
                {
                    ad.DocumentId = documentId;
                    AttachmentController.AddAttachmentDocument(ad);
                }
            }
        }

        private string GetTempFolder()
        {
            // 系统临时文件夹
            string tempPath = Path.GetTempPath();
            string folderPath = string.Empty;

            do
            {
                folderPath = string.Concat(tempPath, "{", Guid.NewGuid().ToString(), "}");
            } while (Directory.Exists(folderPath));

            Directory.CreateDirectory(folderPath);
            return folderPath;
        }

        /// <summary>
        /// 获取附件字节流
        /// </summary>
        /// <param name="att"></param>
        /// <returns></returns>
        public byte[] ReadAttBytes(Outlook.Attachment att)
        {
            if (att.Type == Outlook.OlAttachmentType.olOLE) return null;

            byte[] att_buffer = null;
            if (att.Type == Outlook.OlAttachmentType.olByValue)
            {
                att_buffer = att.PropertyAccessor.GetProperty(PR_ATTACH_DATA_BIN) as byte[];
            }
            else
            {
                string tempfile = Path.GetTempFileName();
                att.SaveAsFile(tempfile);
                att_buffer = File.ReadAllBytes(tempfile);
                File.Delete(tempfile);
            }
            return att_buffer;
        }

        /// <summary>
        /// 构造附加信息
        /// </summary>
        /// <param name="mail"></param>
        /// <param name="downloadUrls_Att">普通附件下载URL</param>
        /// <param name="downloadUrls_Embed">内嵌附件下载URL</param>
        /// <returns></returns>
        public string BuildAppendInfo(Outlook.MailItem mail, string downloadUrls_Att, string downloadUrls_Embed)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(new string('=', 65));
            sb.Append("Subject: ");
            sb.AppendLine(mail.Subject);
            sb.Append("From: ");
            sb.AppendLine(mail.SenderName);
            sb.Append("To: ");
            sb.AppendLine(mail.To);
            if (!string.IsNullOrEmpty(mail.CC))
            {
                sb.Append("Cc: ");
                sb.AppendLine(mail.CC);
            }
            if (!string.IsNullOrEmpty(mail.BCC))
            {
                sb.Append("Bcc: ");
                sb.AppendLine(mail.BCC);
            }
            sb.Append("Sent: ");
            sb.AppendLine(mail.SentOn.Year > DateTime.Now.Year ? "(N/A)" : mail.SentOn.ToString());
            if (!string.IsNullOrEmpty(downloadUrls_Att))
            {
                sb.Append("Attachments:");
                sb.Append(downloadUrls_Att);
                sb.AppendLine();
            }
            if (!string.IsNullOrEmpty(downloadUrls_Embed))
            {
                sb.Append("Embedded Attachments:");
                sb.Append(downloadUrls_Embed);
                sb.AppendLine();
            }
            sb.AppendLine(new string('=', 65));

            return sb.ToString();
        }

        /// <summary>
        /// 依据指字的邮件项获取发布内容
        /// </summary>
        /// <param name="mail"></param>
        /// <param name="headerText"></param>
        /// <param name="footerText"></param>
        /// <returns></returns>
        public byte[] GetDocumentContent(Outlook.MailItem mail, string headerText, string footerText)
        {
            //使用Mail.RTFBody获取文档内容会丢失部分格式，所以这里还是采用剪贴板方式。

            //复制文档内容到剪贴板
            Word.Document wordDoc = (Word.Document)mail.GetInspector.WordEditor;
            wordDoc.Content.Copy();

            using (RichTextBox rtb = new RichTextBox())
            {
                //添加头部信息
                rtb.AppendText(headerText);
                rtb.SelectAll();
                rtb.SelectionFont = new Font("Courier New", 11);
                rtb.SelectionColor = Color.Green;

                //添加正文
                rtb.Select(rtb.TextLength, 0);
                rtb.Paste();
                Clipboard.Clear();

                //添加尾部信息
                rtb.SelectionFont = new Font("Courier New", 11);
                rtb.SelectionColor = Color.Green;
                rtb.AppendText(footerText);

                using (System.IO.MemoryStream stream = new MemoryStream())
                {
                    rtb.SaveFile(stream, RichTextBoxStreamType.RichText);
                    return stream.ToArray();
                }
            }
        }

        /// <summary>
        /// 是否内嵌附件
        /// </summary>
        /// <param name="mail"></param>
        /// <param name="attachment"></param>
        /// <returns></returns>
        public bool isEmbeddedAttachment(Outlook.MailItem mail, Outlook.Attachment attachment)
        {
            //纯文本邮件没有内联附件
            if (mail.BodyFormat == Outlook.OlBodyFormat.olFormatPlain) return false;


            if (attachment.Type != Outlook.OlAttachmentType.olByValue)
            {
                return true;
            }

            string ATTACH_CONTENT_ID =
                     @"http://schemas.microsoft.com/mapi/proptag/0x3712001E";
            string ATTACH_CONTENT_LOCATION =
                     @"http://schemas.microsoft.com/mapi/proptag/0x3713001E";
            if (attachment.PropertyAccessor.GetProperty(ATTACH_CONTENT_ID).ToString()
                  != string.Empty ||
               attachment.PropertyAccessor.GetProperty(ATTACH_CONTENT_LOCATION).ToString()
                  != string.Empty)
            {
                return true;
            }

            string ATTACH_METHOD =
                     @"http://schemas.microsoft.com/mapi/proptag/0x37050003";
            if ((int)attachment.PropertyAccessor.GetProperty(ATTACH_METHOD) == 6)
            {
                return true;
            }

            string ATTACH_FLAGS =
                     @"http://schemas.microsoft.com/mapi/proptag/0x37140003";
            if ((int)attachment.PropertyAccessor.GetProperty(ATTACH_FLAGS) == 4)
            {
                return true;
            }

            return false;
        }
    }
}
