﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DocumentManagementTool.Controller
{
    public class LogController
    {
        public static void WriteLog(Exception err)
        {
            string filePath = System.AppDomain.CurrentDomain.BaseDirectory + "\\Log\\";
            if (!System.IO.Directory.Exists(filePath))
            {
                System.IO.Directory.CreateDirectory(filePath);
            }
            filePath += System.DateTime.Now.ToString("yyyy-MM-dd") + "--error.txt";
            FileInfo file = new FileInfo(filePath);
            StreamWriter writer = new StreamWriter(file.Open(FileMode.Append, FileAccess.Write, FileShare.ReadWrite));
            writer.WriteLine("(" + System.DateTime.Now.ToString() + ") " + " :");
            writer.WriteLine(err.Message);
            writer.WriteLine();
            writer.Flush();
            writer.Close();
        }

        public static void WriteText(string message, int type)
        {
            string filePath = System.AppDomain.CurrentDomain.BaseDirectory + "\\LogText\\";
            if (!System.IO.Directory.Exists(filePath))
            {
                System.IO.Directory.CreateDirectory(filePath);
            }
            if (type == 1)
            {
                filePath += System.DateTime.Now.ToString("yyyy-MM-dd") + "--xml.txt";
            }
            if (type == 2)
            {
                filePath += System.DateTime.Now.ToString("yyyy-MM-dd") + "--binary.txt";
            }
            FileInfo file = new FileInfo(filePath);
            StreamWriter writer = new StreamWriter(file.Open(FileMode.Append, FileAccess.Write, FileShare.ReadWrite));
            writer.WriteLine(message);
            writer.WriteLine();
            writer.Flush();
            writer.Close();
        }
    }
}
