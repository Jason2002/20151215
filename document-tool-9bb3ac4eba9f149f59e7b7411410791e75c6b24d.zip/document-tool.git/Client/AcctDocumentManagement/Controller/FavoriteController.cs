﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentManagementTool.Controller
{
    public class FavoriteController
    {
        private FavoriteClientProxy m_proxy;
        private List<FavoriteEntity> m_favorites = new List<FavoriteEntity>();

        public FavoriteController(FavoriteClientProxy proxy, string userID)
        {
            m_proxy = proxy;

            var result = m_proxy.GetFavorites(userID);
            if (result != null)
            {
                m_favorites = result.ToList();
            }
        }

        public int AddFavorite(FavoriteEntity favoriteEntity)
        {
            int newid = m_proxy.AddFavorite(favoriteEntity);
            favoriteEntity.TransactionNumber = newid;
            m_favorites.Add(favoriteEntity);
            return newid;
        }

        public void DeleteFavorite(string userID, int categoryID)
        {
            var tempFav = (from f in m_favorites
                           where f.UserID == userID && f.CategoryId == categoryID
                           select f).FirstOrDefault();
            if (tempFav != null)
            {
                m_proxy.DeleteFavorite(tempFav.TransactionNumber);
                m_favorites.Remove(tempFav);
            }
        }

        public bool IsExists(string userID, int categoryID)
        {
            var tempFav = (from f in m_favorites
                           where f.UserID == userID && f.CategoryId == categoryID
                           select f).FirstOrDefault();
            return tempFav != null;
        }

        public IEnumerable<FavoriteEntity> GetFavorites()
        {
            return m_favorites;
        }
    }
}
