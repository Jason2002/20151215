﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;

namespace DocumentManagementTool.ViewModel
{
    [Serializable]
    public class CategoryPrivilegeModel : INotifyPropertyChanged
    {
        public CategoryPrivilegeModel()
        {
        }

        public CategoryPrivilegeModel(CategoryPrivilegeModel parent)
        {
            this.m_parent = parent;
        }

        public int CategoryID { get; set; }

        private string m_categoryName = string.Empty;
        public string CategoryName
        {
            get
            {
                return m_categoryName;
            }
            set
            {
                if (value.Length > 80)
                {
                    m_categoryName = value.Substring(0, 80) + "...";
                }
                else
                {
                    m_categoryName = value;
                }
                m_CategoryNameToolTip = value;
            }
        }

        private string m_CategoryNameToolTip = string.Empty;
        public string CategoryNameToolTip
        {
            get { return m_CategoryNameToolTip; }
        }

        public bool IsOwner
        {
            get
            {
                return (Permission & PrivilegeAction.Owner) == PrivilegeAction.Owner;
            }
            set
            {
                if (value == IsOwner) return;
                if (value)
                {
                    if (Permission == null)
                        m_Permission = PrivilegeAction.Owner;
                    else
                        m_Permission = Permission | PrivilegeAction.Owner;
                }
                else
                {
                    m_Permission &= ~PrivilegeAction.Owner;
                }

                this.IsView = this.IsOwner;
                this.IsEdit = this.IsOwner;
                this.IsAllowSetView = !this.IsOwner;
                this.IsAllowSetEdit = !this.IsOwner;

                OnPropertyChanged("IsOwner");
            }
        }

        public bool IsView
        {
            get
            {
                return (Permission & PrivilegeAction.View) == PrivilegeAction.View;
            }
            set
            {
                if (value == IsView) return;
                if (value)
                {
                    if (Permission == null)
                        m_Permission = PrivilegeAction.View;
                    else
                        m_Permission = Permission | PrivilegeAction.View;
                }
                else
                {
                    m_Permission &= ~PrivilegeAction.View;
                }
                OnPropertyChanged("IsView");
            }
        }

        public bool IsEdit
        {
            get
            {
                return (Permission & PrivilegeAction.Edit) == PrivilegeAction.Edit;
            }
            set
            {
                if (value == IsEdit) return;
                if (value)
                {
                    if (Permission == null)
                        m_Permission = PrivilegeAction.Edit;
                    else
                        m_Permission = Permission | PrivilegeAction.Edit;
                }
                else
                {
                    m_Permission &= ~PrivilegeAction.Edit;
                }

                this.IsView = this.IsEdit;
                this.IsAllowSetView = !this.IsEdit;

                OnPropertyChanged("IsEdit");
            }
        }

        private PrivilegeAction? m_Permission;
        public PrivilegeAction? Permission
        {
            get { return m_Permission; }
            //set
            //{
            //    if (m_Permission != value)
            //    {
            //        m_Permission = value;

            //        OnPropertyChanged("IsOwner");
            //        OnPropertyChanged("IsView");
            //        OnPropertyChanged("IsEdit");
            //        OnPropertyChanged("IsAllowSetOwner");
            //        OnPropertyChanged("IsAllowSetView");
            //        OnPropertyChanged("IsAllowSetEdit");
            //    }
            //}
        }

        private bool m_IsAllowSetOwner = true;
        public bool IsAllowSetOwner
        {
            get { return m_IsAllowSetOwner; }
            set
            {
                if (m_IsAllowSetOwner != value)
                {
                    m_IsAllowSetOwner = value;
                    OnPropertyChanged("IsAllowSetOwner");
                }
            }
        }

        private bool m_IsAllowSetView = true;
        public bool IsAllowSetView
        {
            get { return m_IsAllowSetView; }
            set
            {
                if (m_IsAllowSetView != value)
                {
                    m_IsAllowSetView = value;
                    OnPropertyChanged("IsAllowSetView");
                }
            }
        }

        private bool m_IsAllowSetEdit = true;
        public bool IsAllowSetEdit
        {
            get { return m_IsAllowSetEdit; }
            set
            {
                if (m_IsAllowSetEdit != value)
                {
                    m_IsAllowSetEdit = value;
                    OnPropertyChanged("IsAllowSetEdit");
                }
            }
        }

        private Visibility m_CheckBoxVisibility = Visibility.Visible;
        public Visibility CheckBoxVisibility
        {
            get { return m_CheckBoxVisibility; }
            set
            {
                if (m_CheckBoxVisibility != value)
                {
                    m_CheckBoxVisibility = value;
                    OnPropertyChanged("CheckBoxVisibility");
                }
            }
        }

        public Visibility OwnerVisibility
        {
            get
            {
                if (this.Parent == null
                    || this.Parent.Parent == null)
                {
                    return Visibility.Visible;
                }
                else
                {
                    return Visibility.Collapsed;
                }
            }
        }

        public bool IsExpanded {
            get {
                return (this.Parent == null
                        || this.Parent.Parent == null);
            }
        }

        public List<CategoryPrivilegeModel> SubItems { get; set; }

        #region Level

        // Returns the number of nodes in the longest path to a leaf

        public int Depth
        {
            get
            {
                int max;
                if (SubItems == null || SubItems.Count == 0)
                    max = 0;
                else
                    max = (int)SubItems.Max(r => r.Depth);
                return max + 1;
            }
        }

        private CategoryPrivilegeModel m_parent;

        public CategoryPrivilegeModel Parent
        {
            get { return m_parent; }
            set { m_parent = value; }
        }

        // Returns the maximum depth of all siblings

        public int Level
        {
            get
            {
                if (m_parent == null)
                    return Depth;
                return m_parent.Level - 1;
            }
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class LevelConverter : DependencyObject, IMultiValueConverter
    {
        public object Convert(
            object[] values, Type targetType,
            object parameter, CultureInfo culture)
        {
            int level = (int)values[0];
            double indent = (double)values[1];
            return indent * level;
        }

        public object[] ConvertBack(
            object value, Type[] targetTypes,
            object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
