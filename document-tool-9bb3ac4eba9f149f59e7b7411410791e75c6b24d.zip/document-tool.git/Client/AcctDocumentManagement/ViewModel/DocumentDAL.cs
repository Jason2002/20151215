﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace DocumentManagementTool.ViewModel
{
    public static class DocumentDAL
    {
        public static ObservableCollection<DocumentCategory> CreateTree(CategoryClientProxy proxy, string uid)
        {

            ObservableCollection<DocumentCategory> list = new ObservableCollection<DocumentCategory>();
            try
            {
                IEnumerable<CategoryEntity> categories = proxy.GetCategoryTree(uid).OrderBy(item => item.CategoryName);
                //DocumentCategory root = GetRootCategory();
                //list.Add(root);
                foreach (var item in categories)
                {
                    //root.SubCategories.Add(TransferEntity(item, root));
                    list.Add(TransferEntity(item, null));
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return list;
        }

        private static DocumentCategory TransferEntity(CategoryEntity entity, DocumentCategory parent)
        {
            DocumentCategory category = new DocumentCategory(entity);
            category.ParentCategory = parent;
            if (entity.SubCategories != null && entity.SubCategories.Count > 0)
            {
                entity.SubCategories.ForEach(e => category.SubCategories.Add(TransferEntity(e, category)));
            }
            return category;
        }

        private static DocumentCategory GetRootCategory()
        {
            CategoryEntity entity = new CategoryEntity
            {
                CategoryId = 0,
                CategoryName = "MIS Document"
            };
            DocumentCategory category = new DocumentCategory(entity);
            return category;
        }
    }
}
