﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace DocumentManagementTool.ViewModel
{
    public class DocumentModel : INotifyPropertyChanged
    {
        private ObservableCollection<DocumentCategory> categories;

        public ObservableCollection<DocumentCategory> Categories
        {
            get { return categories; }
            set
            {
                categories = value;
                RaisePropertyChangedEvent("Categories");
            }
        }


        /// <summary>
        /// Refreshes the data.
        /// </summary>
        public void RefreshData(CategoryClientProxy proxy, string uid)
        {
            Categories = DocumentDAL.CreateTree(proxy, uid);
        }


        ///<summary>
        ///Occurs when a property value changes.
        ///</summary>
        public event PropertyChangedEventHandler PropertyChanged;


        /// <summary>
        /// Fires the <see cref="PropertyChanged"/> event for a
        /// given property.
        /// </summary>
        /// <param name="propertyName">The changed property.</param>
        private void RaisePropertyChangedEvent(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        public DocumentModel(CategoryClientProxy proxy, string uid)
        {
            RefreshData(proxy, uid);
        }

        public DocumentCategory TryFindCategoryByName(string categoryName)
        {
            return TryFindCategoryByName(null, categoryName);
        }


        public DocumentCategory TryFindCategoryByName(DocumentCategory parent, string categoryName)
        {
            ObservableCollection<DocumentCategory> cats;
            cats = parent == null ? categories : parent.SubCategories;
            foreach (DocumentCategory category in cats)
            {
                if (category.CategoryName == categoryName)
                {
                    return category;
                }
                else
                {
                    DocumentCategory cat = TryFindCategoryByName(category, categoryName);
                    if (cat != null) return cat;
                }
            }

            return null;
        }
    }
    
}
