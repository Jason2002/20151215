﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Hardcodet.Wpf.GenericTreeView;
using DocumentManagementTool.ViewModel;
using System.Diagnostics;
using System.ServiceModel;
using DocumentManagementTool.Controller;
using System.Windows.Threading;
using System.Net;
using System.Configuration;
using System.Runtime.CompilerServices;
using DocumentManagementTool.Common;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class MainForm : Window
    {
        CategoryClientProxy m_categoryProxy;
        DocumentClientProxy m_documentProxy;
        MessageClientProxy m_messageProxy;
        UserRightsClientProxy m_userProxy;
        FavoriteClientProxy m_favoriteProxy;
        CategoryController m_categoryController;
        DocumentController m_documentController;
        FavoriteController m_favoriteController;
        DocumentEntity m_currentDocument = null;
        DispatcherTimer m_timer;
        string m_userName;

        int m_lastID = 0;
        UserOperationRights m_userOperation;

        public DocumentCategory CuttedCategory
        {
            get
            {
                if (AppDomain.CurrentDomain.GetData("CuttedCategory") != null)
                {
                    return (DocumentCategory)AppDomain.CurrentDomain.GetData("CuttedCategory");
                }
                else
                {
                    return null;
                }
            }
            set
            {
                AppDomain.CurrentDomain.SetData("CuttedCategory", value);
            }
        }
        //private bool m_isFirstLoad = true;

        public MainForm()
        {
            WriteTraceLog(new string('-', 80));
            WriteTraceLog("Initialize begin");

            InitializeComponent();

            WriteTraceLog("Initialize end");
        }

        private void ShowAboutDialog(object sender, RoutedEventArgs e)
        {
            AboutDialog dlg = new AboutDialog();
            dlg.Owner = this;
            Shadow.Visibility = Visibility.Visible;
            dlg.ShowDialog();
            Shadow.Visibility = Visibility.Collapsed;
        }

        private bool CanEdit(DocumentCategory item)
        {

            if (m_userOperation.IsAdmin)
            {
                return true;
            }
            return !item.Entity.AuthEditResult;
        }

        private bool CanViewDocument(DocumentCategory item)
        {
            if (m_userOperation.IsAdmin)
            {
                return true;
            }
            return !item.Entity.AuthViewResult;
        }

        private bool IsRootCategory(DocumentCategory item)
        {
            return item.CategoryName == "Root";
        }

        private void AddCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory parent = GetCommandItem();

            //create a sub category
            CategoryEntity newCategory = ShowInputDialog(null, IsRootCategory(parent));
            if (newCategory == null || string.IsNullOrEmpty(newCategory.CategoryName))
            {
                e.Handled = true;
                return;
            }
            newCategory.EditUser = m_userName;
            if (!IsRootCategory(parent))
            {
                newCategory.ParentId = parent.CategoryId;
            }
            try
            {
                m_categoryController.AddCategory(newCategory);
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Add category error";
                LogController.WriteLog(ex);
            }

            RefreshTree(false);
            //make sure the parent is expanded
            if (!IsRootCategory(parent))
            {
                DocumentTree.TryFindNode(parent).IsExpanded = true;
            }

            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            //Important - mark the event as handled
            e.Handled = true;
        }

        private void EvaluateCanAdd(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();

            e.CanExecute = CanEdit(item);
            e.Handled = true;
        }

        private void EvaluateCanRename(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();

            if (!IsRootCategory(item) && CanEdit(item))
            {
                if (item.ParentCategory == null)
                {
                    e.CanExecute = m_userOperation.IsAdmin;
                }
                else
                {
                    e.CanExecute = true;
                }
                e.Handled = true;
            }
        }

        private void RenameCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            //create a sub category
            CategoryEntity modified = ShowInputDialog(item, item.ParentCategory == null);
            if (modified == null || string.IsNullOrEmpty(modified.CategoryName))
            {
                e.Handled = true;
                return;
            }
            modified.EditUser = m_userName;
            try
            {
                m_categoryController.RanameCategory(modified);
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Rename category error";
                LogController.WriteLog(ex);
            }
            RefreshTree(false);
            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            //Important - mark the event as handled
            e.Handled = true;
        }

        private void EvaluateCanDelete(object sender, CanExecuteRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            if (!IsRootCategory(item) && CanEdit(item) && (item.SubCategories == null || item.SubCategories.Count == 0))
            {
                e.CanExecute = true;
            }

            e.Handled = true;
        }

        private void DeleteCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get item
            DocumentCategory item = GetCommandItem();

            if (MessageBox.Show("Delete category will also delete document which belongs to it. Continue?", "Confirm", MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.OK)
            {


                //remove from parent
                try
                {
                    m_categoryController.DeleteCategory(item.CategoryId, m_userName);
                }
                catch (Exception ex)
                {
                    txtEvent.Text = "Delete category error";
                    LogController.WriteLog(ex);
                }
                RefreshTree(false);
                //item.ParentCategory.SubCategories.Remove(item);
                DocumentCategory parent = item.ParentCategory;
                if (parent != null)
                {
                    if (parent.SubCategories.Count > 0)
                    {
                        DocumentTree.TryFindNode(parent).IsExpanded = true;
                    }
                    else
                    {
                        DocumentTree.TryFindNode(parent).IsExpanded = false;
                    }
                    DocumentTree.SelectedItem = parent;
                }
            }
            //mark event as handled

            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            e.Handled = true;
        }

        private void EvaluateCanCut(object sender, CanExecuteRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            if (CanEdit(item) && !IsRootCategory(item) && item.ParentCategory != null)
            {
                e.CanExecute = true;
            }

            e.Handled = true;
        }

        private void CutCategory(object sender, ExecutedRoutedEventArgs e)
        {
            //get the processed item
            DocumentCategory item = GetCommandItem();

            this.CuttedCategory = item;
        }

        private void EvaluateCanPaste(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();
            if (!IsRootCategory(item) && CanEdit(item) && this.CuttedCategory != null)
            {
                e.CanExecute = true;
            }

            e.Handled = true;
        }

        private void PasteCategory(object sender, ExecutedRoutedEventArgs e)
        {
            DocumentCategory cutted = this.CuttedCategory;
            if (cutted != null)
            {
                DocumentCategory item = GetCommandItem();
                if (item.ParentCategory != null && item.ParentCategory.CategoryId == cutted.CategoryId)
                {
                    MessageBox.Show("Can not paste here.");
                    return;
                }

                if (cutted.ParentCategory.CategoryId == item.CategoryId)
                {
                    this.CuttedCategory = null;
                    return;
                }
                try
                {
                    m_categoryController.UpdateCategoryParent(item.CategoryId, cutted.CategoryId, m_userName);
                }
                catch (Exception ex)
                {
                    txtEvent.Text = "Paste category error";
                    LogController.WriteLog(ex);
                }
                RefreshTree(false);
                this.CuttedCategory = null;
                TreeLayout layout = DocumentTree.GetTreeLayout();
                DocumentTree.Refresh(layout);
                e.Handled = true;
            }
        }

        private void EvaluateCanReload(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;

            e.Handled = true;
        }

        private void ReloadCategory(object sender, ExecutedRoutedEventArgs e)
        {
            RefreshTree(false);
            TreeLayout layout = DocumentTree.GetTreeLayout();
            DocumentTree.Refresh(layout);
            e.Handled = true;
        }

        private void EvaluateCanSecurity(object sender, CanExecuteRoutedEventArgs e)
        {
            DocumentCategory item = GetCommandItem();
            if (!IsRootCategory(item))
            {
                if (m_userOperation.IsAdmin)
                {
                    e.CanExecute = true;
                }
                else if (m_userOperation.IsOwner 
                    && (item.IsHasPermissionRecurisive(PrivilegeAction.Owner)))
                {
                    e.CanExecute = true;
                }
            }

            e.Handled = true;
        }

        private void SecurityCategory(object sender, ExecutedRoutedEventArgs e)
        {
            CategoryPermission categoryPermission = new CategoryPermission(GetCommandItem());
            categoryPermission.Owner = this;
            categoryPermission.ShowDialog();
            e.Handled = true;
        }


        private void BindDefault()
        {
            WriteTraceLog("GetLatestUpdateDocument begin");
            if (m_documentController == null) return;
            IEnumerable<DocumentEntity> latestdocuments = m_documentController.GetLatestUpdateDocument(30);
            ucLatestUpdateDocument.listBox1.Items.Clear();
            foreach (DocumentEntity item in latestdocuments)
            {
                ucLatestUpdateDocument.listBox1.Items.Add(item);
            }
            WriteTraceLog("GetLatestUpdateDocument end");
        }

        private void OnSelectedItemChanged(object sender, RoutedTreeItemEventArgs<DocumentCategory> e)
        {
            if ((sender as DocumentTree).RootNode.IsSelected)
            {
                BindDefault();
                defaultGrid.Visibility = Visibility.Visible;
                contentGrid.Visibility = Visibility.Collapsed;
                favoriteGrid.Visibility = Visibility.Collapsed;
            }
            else
            {
                defaultGrid.Visibility = Visibility.Collapsed;
                contentGrid.Visibility = Visibility.Visible;
                favoriteGrid.Visibility = Visibility.Collapsed;
            }
            if (e.NewItem != null && e.OldItem != null && e.NewItem.CategoryId == e.OldItem.CategoryId)
            {
                return;
            }

            if (ucEditDocument.Mode == DocumentManagementTool.UserControls.EditMode.Edit)
            {
                if (MessageBoxResult.Yes == MessageBox.Show("Document has not been saved. Do you want to save it befor continue?", "Message", MessageBoxButton.YesNo, MessageBoxImage.Information))
                {
                    SaveDocument(e.OldItem, false);
                }
            }

            m_currentDocument = null;
            ucEditDocument.ClearContent();
            SetFavoriteImage();
            if (e.NewItem is DocumentCategory)
            {
                DocumentCategory category = e.NewItem;
                if (CanViewDocument(category))
                {
                    this.Cursor = Cursors.Wait;
                    QueryDocumentForShow(category);
                }
            }
        }

        private void QueryDocumentForShow(DocumentCategory category)
        {
            try
            {
                if (category == null)
                {
                    ucEditDocument.ClearContent();
                    return;
                }
                m_currentDocument = m_documentController.GetDocumentByCategoryId(category.CategoryId);

                if (m_currentDocument != null)
                {
                    ucEditDocument.ShowContent(m_currentDocument, m_userName, DocumentManagementTool.UserControls.EditMode.Read);
                    tbLastEditDate.Text = string.Format("Last edit by {0} in {1}", m_currentDocument.EditUser,
                        m_currentDocument.EditDate.ToString("yyyy-MM-dd HH:mm:ss"));

                    _attachmentList.Clear();
                    _attachmentDocumentList.Clear();
                }
                else
                {
                    ucEditDocument.ClearContent();
                    tbLastEditDate.Text = string.Empty;
                }

                SetFavoriteImage();
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Query document error";
                LogController.WriteLog(ex);
            }
            finally
            {
                Cursor = Cursors.Arrow;
            }
        }

        private DocumentCategory GetCommandItem()
        {
            //get the processed item
            ContextMenu menu = DocumentTree.NodeContextMenu;
            if (menu.IsVisible)
            {
                //a context menu was clicked
                TreeViewItem treeNode = (TreeViewItem)menu.PlacementTarget;
                if (DocumentTree.RootNode == treeNode)
                {
                    return new DocumentCategory(new CategoryEntity { CategoryId = 0, AuthEditResult = true, AuthViewResult = true, CategoryName = "Root" });
                }
                return (DocumentCategory)treeNode.Header;
            }
            else
            {
                //the context menu is closed - the user has pressed a shortcut
                return DocumentTree.SelectedItem;
            }
        }

        private CategoryEntity ShowInputDialog(DocumentCategory category, bool isRoot)
        {
            InputDialog dlg = new InputDialog(category, isRoot);
            dlg.Owner = this;
            Shadow.Visibility = Visibility.Visible;
            if (dlg.ShowDialog().Value)
            {
                Shadow.Visibility = Visibility.Collapsed;
                return dlg.GetSetupInfo();
            }
            else
            {
                Shadow.Visibility = Visibility.Collapsed;
                return null;
            }

        }

        private void ShowHistory(DocumentCategory category)
        {
            if (category == null)
            {
                return;
            }
            else
            {
                List<DocumentEntity> entities = m_documentController.GetHistoryInfo(category.CategoryId);
                DocumentHistory dlg = new DocumentHistory(entities, category);
                dlg.Owner = this;
                dlg.DocumentController = m_documentController;
                Shadow.Visibility = Visibility.Visible;
                dlg.ShowDialog();
                Shadow.Visibility = Visibility.Collapsed;
            }
        }

        public List<AttachmentEntity> _attachmentList = new List<AttachmentEntity>();
        public List<AttachmentDocumentEntity> _attachmentDocumentList = new List<AttachmentDocumentEntity>();

        private void ShowUpload()
        {
            //if (m_currentDocument == null) return;

            //UploadAttachment window = new UploadAttachment(m_currentDocument.DocumentId.Value);
            UploadAttachment window = new UploadAttachment();
            window.Owner = this;
            Shadow.Visibility = Visibility.Visible;
            bool? result = window.ShowDialog();
            Shadow.Visibility = Visibility.Collapsed;
            if (result.HasValue && result.Value)
            {
                if (window.AttachmentDocument == null)
                {
                    _attachmentList.Add(window.Attachment);
                }
                else
                {
                    _attachmentDocumentList.Add(window.AttachmentDocument);
                }

                string text = string.Format("Attachment: {0}", window.DownloadURL);
                ucEditDocument.AppendText(text);
            }
        }

        private void EditToolBar_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            RoutedUICommand command = e.Command as RoutedUICommand;
            var currentCategory = ActivatedCategory;
            if (command == null)
            {
                return;
            }

            if (command.Name.Equals("AddDocument") || command.Name.Equals("EditDocument"))
            {
                ucEditDocument.ShowContent(m_currentDocument, m_userName, DocumentManagementTool.UserControls.EditMode.Edit);
            }
            if (command.Name.Equals("EditInWord"))
            {
                EditInWord();
            }
            if (command.Name.Equals("SaveDocument"))
            {
                SaveDocument(GetCommandItem(), true);
            }
            if (command.Name.Equals("CancelEdit"))
            {
                if (m_currentDocument != null)
                {
                    ucEditDocument.ShowContent(m_currentDocument, m_userName, DocumentManagementTool.UserControls.EditMode.Read);
                }
                else
                {
                    ucEditDocument.ClearContent();
                }
            }
            if (command.Name.Equals("ShowHistory"))
            {
                ShowHistory(currentCategory);
            }

            if (command.Name.Equals("UploadAttach"))
            {
                ShowUpload();
            }

            if (command.Name.Equals("EditFavorite"))
            {
                ChangeFavorite();
            }
        }

        private void ChangeFavorite()
        {
            var cat = ActivatedCategory;
            if (cat == null) return;

            if (m_favoriteController.IsExists(m_userName, cat.CategoryId))
            {
                m_favoriteController.DeleteFavorite(m_userName, cat.CategoryId);
            }
            else
            {
                FavoriteEntity fav = new FavoriteEntity();
                fav.UserID = m_userName;
                fav.CategoryId = cat.CategoryId;
                fav.Name = cat.CategoryName;
                fav.EditUser = m_userName;
                m_favoriteController.AddFavorite(fav);
            }

            SetFavoriteImage();

            RefreshFavorites();
        }

        private void SetFavoriteImage()
        {
            if (ActivatedCategory == null) return;
            Uri uri = null;
            if (m_favoriteController.IsExists(m_userName, ActivatedCategory.CategoryId))
            {
                uri = new Uri("pack://application:,,,/images/favorite.png");
            }
            else
            {
                uri = new Uri("pack://application:,,,/images/favorite_add.png");
            }
            var source = new BitmapImage(uri);
            imgFavorite.Source = source;
        }

        private DocumentCategory ActivatedCategory
        {
            get
            {
                return DocumentTree.SelectedItem;
            }
        }

        private void EditInWord()
        {
            var category = GetCommandItem();
            if (category == null) return;

            this.Cursor = Cursors.Wait;
            try
            {
                WordHelper.NewFile(ucEditDocument.richTextBox1);
            }
            finally
            {
                this.Cursor = Cursors.Arrow;
            }
        }

        public void SaveDocument(DocumentCategory category, bool isShowNow)
        {
            DocumentEntity entity = ucEditDocument.GetDocument();

            //检查版本冲突
            DocumentEntity latestDocument = m_documentController.GetDocumentWithoutContentByCategoryId(category.CategoryId);
            if (latestDocument != null
                && Convert.ToDecimal(latestDocument.Version) > Convert.ToDecimal(entity.Version))
            {
                if (MessageBox.Show("The local version of this document is out of date.Would you like to continue saving your changes?",
                    "warning", MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.Cancel)
                {
                    return;
                }
            }

            entity.EditUser = m_userName;
            entity.EditDate = DateTime.Now;
            try
            {
                int documentID = m_documentController.UpdateDocument(category.CategoryId, entity);

                if (this._attachmentList.Count > 0)
                {
                    foreach (var att in _attachmentList)
                    {
                        AttachmentController.AddAttachment(documentID, att);
                    }
                    _attachmentList.Clear();
                }
                if (this._attachmentDocumentList.Count > 0)
                {
                    foreach (var attdoc in _attachmentDocumentList)
                    {
                        attdoc.DocumentId = documentID;
                        AttachmentController.AddAttachmentDocument(attdoc);
                    }
                    _attachmentDocumentList.Clear();
                }

                ucEditDocument.ClearContent();
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Save error";
                LogController.WriteLog(ex);
            }

            if (isShowNow)
            {
                QueryDocumentForShow(category);
            }
        }

        private void m_timer_Tick(object sender, EventArgs e)
        {
            try
            {
                List<LogEntity> lastMessage = m_messageProxy.GetRecentlyLog(m_lastID);
                if (lastMessage == null || lastMessage.Count == 0)
                {
                    return;
                }

                HandlerMessage(lastMessage);
            }
            catch
            {

            }
        }

        private void HandlerMessage(List<LogEntity> messages)
        {
            List<LogEntity> orderedMessages = messages.OrderByDescending(m => m.TransactionNumber).ToList();
            bool isNeedRefreshTree = false;
            if (orderedMessages.Exists(delegate(LogEntity m)
            {
                return m.LogType == "C" && !m.UserID.Equals(m_userName, StringComparison.InvariantCultureIgnoreCase);
            }))
            {
                isNeedRefreshTree = true;
            }

            LogEntity recently = orderedMessages.FirstOrDefault(m => !m.UserID.Equals(m_userName, StringComparison.InvariantCultureIgnoreCase));
            if (recently != null)
            {
                txtEvent.Text = recently.LogContent;
            }
            m_lastID = orderedMessages.First().TransactionNumber;

            if (isNeedRefreshTree)
            {
                RefreshTree(true);
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void RefreshTree(bool fromBackground)
        {
            try
            {
                WriteTraceLog("refresh tree begin");
                DocumentCategory current = null;
                if (fromBackground)
                {
                    current = DocumentTree.SelectedItem as DocumentCategory;
                }
                DocumentTree.Items = new DocumentModel(m_categoryProxy, m_userName).Categories;
                if (current != null)
                {
                    DocumentTree.TryFindNode(current).IsExpanded = true;
                }
                WriteTraceLog("refresh tree end");
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Refresh category error";
                LogController.WriteLog(ex);
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        private void RefreshFavorites()
        {
            try
            {
                WriteTraceLog("refresh favorite begin");
                var taskRefreshFavorites = Task<IEnumerable<FavoriteEntity>>.Factory.StartNew(() =>
                {
                    return m_favoriteController.GetFavorites();
                });
                var favorites = taskRefreshFavorites.Result;

                ucFavoriteDocument.listBox1.Items.Clear();
                foreach (var item in favorites)
                {
                    var cat = GetTreeItemById(item.CategoryId);
                    if (cat != null)
                    {
                        item.Path = string.Concat(new string(' ', 6), cat.Path);
                        item.EditUser = cat.Entity.EditUser;
                        item.EditDate = cat.Entity.EditDate;
                    }
                    ucFavoriteDocument.listBox1.Items.Add(item);
                }
                WriteTraceLog("refresh favorite end");
            }
            catch (Exception ex)
            {
                txtEvent.Text = "Refresh favorites error";
                LogController.WriteLog(ex);
            }
        }

        private void EditToolBar_CanAdd(object sender, CanExecuteRoutedEventArgs e)
        {
            if (ucEditDocument == null)
            {
                e.CanExecute = false;
                return;
            }
            else
            {
                DocumentCategory current = ActivatedCategory;

                if (current == null || !CanEdit(current))
                {
                    e.CanExecute = false;
                    return;
                }
                e.CanExecute = ucEditDocument.Mode == DocumentManagementTool.UserControls.EditMode.None;
            }
        }

        private void EditToolBar_CanEdit(object sender, CanExecuteRoutedEventArgs e)
        {
            if (ucEditDocument == null)
            {
                e.CanExecute = false;
                return;
            }

            DocumentCategory current = ActivatedCategory;
            if (current != null && CanEdit(current))
            {
                e.CanExecute = ucEditDocument.Mode == DocumentManagementTool.UserControls.EditMode.Read;
            }
            else
            {
                e.CanExecute = false;
            }

        }

        private void EditToolBar_CanShowHistroy(object sender, CanExecuteRoutedEventArgs e)
        {
            if (ucEditDocument == null)
            {
                e.CanExecute = false;
                return;
            }

            DocumentCategory current = ActivatedCategory;
            if (current != null)
            {
                e.CanExecute = !(ucEditDocument.Mode == DocumentManagementTool.UserControls.EditMode.None);
            }
            else
            {
                e.CanExecute = false;
            }

        }

        private void EditToolBar_CanUpload(object sender, CanExecuteRoutedEventArgs e)
        {
            if (ucEditDocument == null)
            {
                e.CanExecute = false;
                return;
            }

            DocumentCategory current = ActivatedCategory; //DocumentTree.SelectedItem;
            if (current != null)
            {
                e.CanExecute = ucEditDocument.Mode == DocumentManagementTool.UserControls.EditMode.Edit;
            }
            else
            {
                e.CanExecute = false;
            }

        }

        private void EditToolBar_CanEditFavorite(object sender, CanExecuteRoutedEventArgs e)
        {
            if (ucEditDocument == null)
            {
                e.CanExecute = false;
                return;
            }
            else
            {
                if (DocumentTree.RootNode.IsSelected)
                {
                    e.CanExecute = false;
                    return;
                }
                e.CanExecute = DocumentTree.SelectedItem != null;
            }
        }

        private void EditToolBar_CanSave(object sender, CanExecuteRoutedEventArgs e)
        {
            if (ucEditDocument == null)
            {
                e.CanExecute = false;
            }
            else
            {
                e.CanExecute = ucEditDocument.Mode == DocumentManagementTool.UserControls.EditMode.Edit;
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (m_timer != null)
            {
                m_timer.Stop();
            }
            try
            {
                m_messageProxy.SayGoodbye(m_userName);
            }
            catch (Exception ex)
            {
                LogController.WriteLog(ex);
                return;
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Cursor = Cursors.Wait;

                searchResultsList.ItemsSource = null;
                List<DocumentEntity> entities = m_documentController.SearchDocuments(txtSearchKeywords.Text.Trim());
                searchResultsList.Items.Clear();

                searchResultsList.ItemsSource = entities;
                searchResultsList.DisplayMemberPath = "SearchName";

            }
            catch (Exception ex)
            {
                txtEvent.Text = "Search content error.";
                LogController.WriteLog(ex);
            }
            finally
            {
                Cursor = Cursors.Arrow;
            }


        }

        private void appointmentList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DocumentEntity document = searchResultsList.SelectedItem as DocumentEntity;
            if (document == null)
            {
                return;
            }
            else
            {
                int categoryId = m_documentController.GetCategoryIdByDocument(document.DocumentId.Value);

                FocusCategory(categoryId, document.SearchAttUrl);
            }
        }

        private void FocusCategory(int categoryId, string attUrl)
        {
            try
            {
                Cursor = Cursors.Wait;

                DocumentCategory entity = GetTreeItemById(categoryId);

                if (entity != null)
                {
                    DocumentTree.SelectedItem = entity;
                    TreeLayout layout = DocumentTree.GetTreeLayout();
                    DocumentTree.Refresh(layout);

                    tbControl.SelectedIndex = 0;

                    if (!string.IsNullOrEmpty(attUrl))
                    {
                        ucEditDocument.Find(attUrl);
                    }

                    defaultGrid.Visibility = Visibility.Collapsed;
                    contentGrid.Visibility = Visibility.Visible;
                    favoriteGrid.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {
                LogController.WriteLog(ex);
            }
            finally
            {
                Cursor = Cursors.Arrow;
            }
        }

        private DocumentCategory GetTreeItemById(int categoryId)
        {
            DocumentCategory entity = null;

            foreach (var item in DocumentTree.Items)
            {
                if (item.CategoryId == categoryId)
                {
                    entity = item;
                    break;
                }

                if (item.SubCategories != null && item.SubCategories.Count > 0)
                {
                    entity = GetTreeItemByKey(categoryId, item);
                    if (entity != null)
                        break;
                }
            }
            return entity;
        }


        private DocumentCategory GetTreeItemByKey(int categoyId, DocumentCategory parent)
        {
            foreach (var item in parent.SubCategories)
            {
                if (item.CategoryId == categoyId)
                {
                    return item;
                }

                if (item.SubCategories != null && item.SubCategories.Count > 0)
                {
                    DocumentCategory temp = GetTreeItemByKey(categoyId, item);
                    if (temp != null) return temp;
                }
            }
            return null;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            WriteTraceLog("Load begin");
            string user = ConfigurationManager.AppSettings["UserName"];
            if (string.IsNullOrEmpty(user))
            {
                user = System.Environment.UserName;
            }
            this.WindowState = WindowState.Maximized;
            m_userName = user;
            m_timer = new DispatcherTimer();
            m_timer.Tick += new EventHandler(m_timer_Tick);
            m_timer.Interval = TimeSpan.FromMinutes(3);
            m_timer.Start();
            txtEvent.Text = "Connect remote server...";
            //Shadow.Visibility = Visibility.Visible;
            PrepareConnect();

            WriteTraceLog("Load end");
        }

        private void PrepareConnect()
        {
            WriteTraceLog("PrepareConnect begin");

            m_messageProxy = new MessageClientProxy();
            m_documentProxy = new DocumentClientProxy();
            m_categoryProxy = new CategoryClientProxy();
            m_userProxy = new UserRightsClientProxy();
            m_favoriteProxy = new FavoriteClientProxy();

            m_categoryController = new CategoryController(m_categoryProxy);
            m_documentController = new DocumentController(m_documentProxy);
            m_favoriteController = new FavoriteController(m_favoriteProxy, m_userName);

            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Send,
              new Action(() =>
              {
                  try
                  {
                      RefreshTree(false);
                      DocumentTree.RootNode.IsExpanded = true;
                  }
                  catch (Exception ex)
                  {
                      txtEvent.Text = "Connect remote error...";
                      LogController.WriteLog(ex);
                      return;
                  }
              }));


            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                new Action(() =>
                {
                    try
                    {
                        RefreshFavorites();

                        txtEvent.Text = m_messageProxy.SayHi(m_userName);

                        WriteTraceLog("GetRights begin");
                        m_userOperation = m_userProxy.GetUserOperationRightsById(m_userName);
                        if (m_userOperation.IsAdmin || m_userOperation.IsOwner)
                        {
                            btnUser.Visibility = Visibility.Visible;
                        }
                        WriteTraceLog("GetRights end");

                        BindDefault();
                    }
                    catch (Exception ex)
                    {
                        txtEvent.Text = "Connect remote error...";
                        LogController.WriteLog(ex);
                        return;
                    }
                }));


            WriteTraceLog("PrepareConnect end");
        }

        private void btnUser_Click(object sender, RoutedEventArgs e)
        {
            List<DocumentCategory> tree = DocumentTree.Items.ToList();
            //MaintainUser dlg = new MaintainUser(m_userName, m_userOperation, tree);
            MaintainUser2 dlg = new MaintainUser2(m_userName, m_userOperation, tree);
            dlg.Owner = this;
            Shadow.Visibility = Visibility.Visible;
            dlg.ShowDialog();
            Shadow.Visibility = Visibility.Collapsed;
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            TextBoxDialog dlg = new TextBoxDialog();
            dlg.Owner = this;
            dlg.TextBlock1.Text = "Please enter document id:";
            if (dlg.ShowDialog() == true)
            {
                int documentId;
                int.TryParse(dlg.txtTextBox1.Text.Trim(), out documentId);
                //if (documentId == 0)
                //{
                //    AnimationMessageBox message = new AnimationMessageBox("please input number format.");
                //    message.Show();
                //    return;
                //}
                FocusCategory(documentId, null);
            }
        }

        private void ucLatestUpdateDocument_HyperlinkClick(object sender, RoutedEventArgs e)
        {
            int documentId = (Nullable<int>)((sender as Hyperlink).CommandParameter) ?? 0;
            int categoryId = m_documentController.GetCategoryIdByDocument(documentId);

            FocusCategory(categoryId, null);
        }

        private void btnFavorite_Click(object sender, RoutedEventArgs e)
        {
            if (favoriteGrid.Visibility == Visibility.Visible)
            {
                if (DocumentTree.RootNode.IsSelected || DocumentTree.SelectedItem == null)
                {
                    defaultGrid.Visibility = Visibility.Visible;
                    contentGrid.Visibility = Visibility.Collapsed;
                    favoriteGrid.Visibility = Visibility.Collapsed;
                }
                else
                {
                    defaultGrid.Visibility = Visibility.Collapsed;
                    contentGrid.Visibility = Visibility.Visible;
                    favoriteGrid.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                defaultGrid.Visibility = Visibility.Collapsed;
                contentGrid.Visibility = Visibility.Collapsed;
                favoriteGrid.Visibility = Visibility.Visible;
            }
        }

        private void ucFavoriteDocument_HyperlinkClick(object sender, RoutedEventArgs e)
        {
            int categoryId = (Nullable<int>)((sender as Hyperlink).CommandParameter) ?? 0;

            FocusCategory(categoryId, null);
        }

        public void WriteTraceLog(string message)
        {
            //LogController.WriteText(string.Format("{0} {1}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff"), message), 1);
        }
    }
}
