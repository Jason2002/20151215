﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using DocumentManagementTool.UserControls;
using DocumentManagementTool.Controller;
using System.IO;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for ViewDocument.xaml
    /// </summary>
    public partial class ViewDocument : Window
    {
        private DocumentEntity _document1 = null;

        public ViewDocument()
        {
            InitializeComponent();
        }

        public ViewDocument(DocumentEntity document1)
            : this()
        {
            _document1 = document1;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TextRange textRange;

            //载入文档内容
            textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
            using (MemoryStream content = new MemoryStream())
            {
                CompressHelper.Decomparess(_document1.DocumentContent, content);
                textRange.Load(content, DataFormats.Rtf);
            }

            //版本信息
            tbVersionInfo1.Text = string.Format("{0} edit document at {1}.(Version: {2})",
                _document1.EditUser, _document1.EditDate, _document1.Version);
        }
    }
}
