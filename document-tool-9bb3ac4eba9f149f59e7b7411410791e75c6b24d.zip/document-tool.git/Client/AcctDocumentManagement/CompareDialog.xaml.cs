﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.UserControls;
using DocumentManagementTool.Controller;
using System.IO;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for CompareDialog.xaml
    /// </summary>
    public partial class CompareDialog : Window
    {
        private DocumentEntity _document1 = null;
        private DocumentEntity _document2 = null;

        public CompareDialog()
        {
            InitializeComponent();
        }

        public CompareDialog(DocumentEntity document1, DocumentEntity document2)
            : this()
        {
            _document1 = document1;
            _document2 = document2;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TextRange textRange;
                
            //载入文档内容
            textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
            using (MemoryStream content = new MemoryStream())
            {
                CompressHelper.Decomparess(_document1.DocumentContent, content);
                textRange.Load(content, DataFormats.Rtf);
            }

            textRange = new TextRange(richTextBox2.Document.ContentStart, richTextBox2.Document.ContentEnd);
            using (MemoryStream content = new MemoryStream())
            {
                CompressHelper.Decomparess(_document2.DocumentContent, content);
                textRange.Load(content, DataFormats.Rtf);
            }

            //版本信息
            tbVersionInfo1.Text = string.Format("{0} edit document at {1}.(Version: {2})",
                _document1.EditUser, _document1.EditDate, _document1.Version);
            tbVersionInfo2.Text = string.Format("{0} edit document at {1}.(Version: {2})",
                _document2.EditUser, _document2.EditDate, _document2.Version);
        }

        private void cbSyncScrolling_Checked(object sender, RoutedEventArgs e)
        {
            //同步滚动
            Style style = new Style();
            style.TargetType = typeof(ScrollViewer);
            style.Setters.Add(new Setter(ScrollSynchronizer.ScrollGroupProperty, "Group1"));
            grdData.Resources.Add(typeof(ScrollViewer), style);
        }

        private void cbSyncScrolling_Unchecked(object sender, RoutedEventArgs e)
        {
            //取消同步滚动
            grdData.Resources.Remove(typeof(ScrollViewer));
        }
    }
}
