﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.ViewModel;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for TextBoxDialog.xaml
    /// </summary>
    public partial class TextBoxDialog : Window
    {
        public TextBoxDialog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// get 
        /// </summary>
        public TextBox TextBox1
        {
            get { return this.txtTextBox1; }
        }

        /// <summary>
        /// get
        /// </summary>
        public TextBlock TextBlock1
        {
            get { return this.txtTextBlock1; }
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.txtTextBox1.Focus();
        }
    }
}
