﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentManagementTool.ViewModel;
using Hardcodet.Wpf.GenericTreeView;

namespace DocumentManagementTool
{
    public class DocumentTree : TreeViewBase<DocumentCategory>
    {
        public override ICollection<DocumentCategory> GetChildItems(DocumentCategory parent)
        {
            return parent.SubCategories;
        }

        public override string GetItemKey(DocumentCategory item)
        {
            return item.CategoryId.ToString();
        }

        public override DocumentCategory GetParentItem(DocumentCategory item)
        {
            return item.ParentCategory;
        }
    }
}
