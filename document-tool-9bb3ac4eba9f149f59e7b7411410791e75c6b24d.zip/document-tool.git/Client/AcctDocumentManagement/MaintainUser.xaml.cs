﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.ViewModel;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for MaintainUser.xaml
    /// </summary>
    public partial class MaintainUser : Window
    {
        string m_uid;
        UserOperationRights m_userOperation;
        UserOperationRights m_findOperation;
        List<DocumentCategory> m_categories;
        List<UserRightsEntity> m_results;
        UserRightsClientProxy m_userProxy;
        public MaintainUser(string uid, UserOperationRights editUserInfo, List<DocumentCategory> categories)
        {
            m_uid = uid;
            m_userOperation = editUserInfo;
            m_categories = categories;
            m_userProxy = new UserRightsClientProxy();
            m_results = new List<UserRightsEntity>();
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lbRights.Visibility = Visibility.Collapsed;
        }

        private void InitRights(List<UserRightsEntity> current)
        {
            current.ForEach(c =>
                {
                    var found = m_results.FirstOrDefault(r => r.RootID == c.RootID);
                    if (found != null)
                    {
                        found.CanEdit = c.CanEdit;
                        found.CanView = c.CanView;
                        found.IsOwner = c.IsOwner;
                    }
                });
        }

        private void InitOwner()
        {
            if (m_userOperation.IsOwner)
            {
                m_userOperation.OwnerCategoryID.ForEach(c =>
                {
                    var found = m_results.FirstOrDefault(r => r.RootID == c);
                    if (found != null)
                    {
                        found.CanSet = true;
                    }
                });
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (chbAdmin.IsChecked.Value)
            {
                List<UserRightsEntity> admin = new List<UserRightsEntity>();
                admin.Add(new UserRightsEntity { CanEdit = true, CanView = true, RootID = 0, EditUser = m_uid, UserID = txtUserID.Text.Trim(), EditDate = DateTime.Now });
                m_userProxy.AddUserRights(admin, txtUserID.Text.Trim());
            }
            else
            {
                m_results.RemoveAll(r =>
                    {
                        return !r.CanView && !r.CanEdit;
                    });
                m_userProxy.AddUserRights(m_results, txtUserID.Text.Trim());
            }
            DialogResult = true;   
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void GetAllRights()
        {
            m_results.Clear();
            
            m_categories.ForEach(c => m_results.Add(new UserRightsEntity 
            { 
                RootID = c.CategoryId,
                RootName = c.CategoryName,
                CanView = m_findOperation.IsAdmin,
                CanEdit = m_findOperation.IsAdmin,
                IsOwner = m_findOperation.IsAdmin,
                CanSet = m_userOperation.IsAdmin,
                EditUser = m_uid,
                EditDate = DateTime.Now,
                UserID = txtUserID.Text.Trim()
            }));

            chbAdmin.IsChecked = m_findOperation.IsAdmin;
            lbRights.IsEnabled = !chbAdmin.IsChecked.Value;
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            FindUser();
        }

        private void FindUser()
        {
            List<UserRightsEntity> current = m_userProxy.GetUserRightsById(txtUserID.Text.Trim());
            m_findOperation = new UserRightsClientProxy().GetUserOperationRightsById(txtUserID.Text.Trim());
            GetAllRights();
            if (current != null && current.Count > 0)
            {
                InitRights(current);
            }
            InitOwner();
            lbRights.ItemsSource = null;
            lbRights.ItemsSource = m_results;
            lbRights.Visibility = Visibility.Visible;
            chbAdmin.IsEnabled = m_userOperation.IsAdmin;
        }

        private void chbAdmin_Checked(object sender, RoutedEventArgs e)
        {
            if (m_results.Count > 0)
            {
                m_findOperation.IsAdmin = chbAdmin.IsChecked.Value;
                GetAllRights();
                lbRights.ItemsSource = null;
                lbRights.ItemsSource = m_results;
                lbRights.IsEnabled = !chbAdmin.IsChecked.Value;
            }
        }

        private void txtUserID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                FindUser();
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox chkOwner = (CheckBox)sender;
            UserRightsEntity entity = chkOwner.DataContext as UserRightsEntity;
            if (entity != null)
            {
                entity.CanEdit = entity.IsOwner;
                entity.CanView = entity.IsOwner;
            }
            Grid grid = (Grid)chkOwner.Parent;
            foreach (var child in grid.Children)
            {
                CheckBox chkBox = child as CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = entity.IsOwner;
                }
            }
        }
    }
}
