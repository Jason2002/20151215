﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.ViewModel;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for CategoryPermission.xaml
    /// </summary>
    public partial class CategoryPermission : Window
    {
        private DocumentCategory m_DocumentCategory;
        private PrivilegeClientProxy m_privilegeProxy;
        public CategoryPermission(DocumentCategory item)
        {
            InitializeComponent();

            m_DocumentCategory = item;
            m_privilegeProxy = new PrivilegeClientProxy();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            List<CategoryPrivilegeModel> privileges = new List<CategoryPrivilegeModel>();
            GetPermissionRecurisive(m_DocumentCategory, privileges);

            CategoryPrivilegeModel root = new CategoryPrivilegeModel(null);
            root.CategoryName = "MIS Document";
            root.IsAllowSetEdit = false;
            root.IsAllowSetOwner = false;
            root.IsAllowSetView = false;
            root.CheckBoxVisibility = Visibility.Collapsed;
            privileges.ForEach(p => p.Parent = root);
            root.SubItems = new List<CategoryPrivilegeModel>();
            root.SubItems.AddRange(privileges);
            treeGrid.DataContext = new CategoryPrivilegeModel[] { root }.ToList();
        }

        private void GetPermissionRecurisive(DocumentCategory item, List<CategoryPrivilegeModel> privileges)
        {
            if (item == null) return;

            CategoryPrivilegeModel cpm = new CategoryPrivilegeModel();
            cpm.CategoryID = item.CategoryId;
            cpm.CategoryName = item.Path;
            cpm.CheckBoxVisibility = Visibility.Collapsed;

            //获取该category的权限加入SubItems
            var list = m_privilegeProxy.GetListByCategoryID(item.CategoryId);
            if (list != null && list.Count > 0)
            {
                privileges.Insert(0, cpm);
                cpm.SubItems = new List<CategoryPrivilegeModel>();

                foreach (var cp in list)
                {
                    cpm.SubItems.Add(new CategoryPrivilegeModel(cpm)
                    {
                        CategoryName = cp.AcctName,
                        CheckBoxVisibility = Visibility.Visible,
                        IsOwner = (cp.Permission & PrivilegeAction.Owner) == PrivilegeAction.Owner,
                        IsView = (cp.Permission & PrivilegeAction.View) == PrivilegeAction.View,
                        IsEdit = (cp.Permission & PrivilegeAction.Edit) == PrivilegeAction.Edit,
                    });
                }
            }

            if (item.ParentCategory != null)
            {
                GetPermissionRecurisive(item.ParentCategory, privileges);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
