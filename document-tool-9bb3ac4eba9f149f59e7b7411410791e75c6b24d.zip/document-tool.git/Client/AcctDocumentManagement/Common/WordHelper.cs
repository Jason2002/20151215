﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Windows;

namespace DocumentManagementTool.Common
{
    public static class WordHelper
    {
        /// <summary>
        /// 使用Word比较文件
        /// </summary>
        /// <param name="sourceFile"></param>
        /// <param name="destinationFile"></param>
        public static void CompareUsingWord(string sourceFile, string destinationFile)
        {
            object missing = System.Reflection.Missing.Value;
            Word.Application wordApp = null;
            Word.Document doc = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = true;

                Object confirmConversions = false;

                object source = sourceFile;
                doc = wordApp.Documents.Open(ref source, ref confirmConversions, true, false,
                    ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                doc.TrackRevisions = false;
                doc.ShowRevisions = false;
                doc.PrintRevisions = false;

                doc.Compare(destinationFile, ref missing,
                    Word.WdCompareTarget.wdCompareTargetNew, true, true, false, false, false);

                wordApp.Activate();
                wordApp.WindowState = Word.WdWindowState.wdWindowStateMaximize;
            }
            catch (COMException ex)
            {
                try
                {
                    doc.Close(ref missing, ref missing, ref missing);
                    wordApp.Quit(ref missing, ref missing, ref missing);
                }
                catch
                {
                }

                MessageBox.Show("You must have Word 2010 installed to use compare feature."
                    + System.Environment.NewLine + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// 保存文本为RTF文件
        /// </summary>
        /// <param name="text"></param>
        /// <param name="path"></param>
        public static void SaveToFile(string text, string path)
        {
            byte[] buffer = Convert.FromBase64String(text);
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            using (System.IO.MemoryStream content = new MemoryStream())
            {
                ms.Write(buffer, 0, buffer.Length);
                ms.Position = 0;
                using (System.IO.Compression.DeflateStream stream = new System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Decompress))
                {
                    stream.Flush();

                    int nSize = 3 * 1024 * 1024;
                    byte[] decompressBuffer = new byte[nSize];
                    int readTimes = 1;
                    int nSizeIncept;
                    while ((nSizeIncept = stream.Read(decompressBuffer, 0, nSize)) != 0 || readTimes < 3)
                    {
                        readTimes++;
                        if (nSizeIncept == 0)
                        {
                            continue;
                        }
                        content.Write(decompressBuffer, 0, nSizeIncept);
                    }
                }
                content.Position = 0;
                using (System.Windows.Forms.RichTextBox rtb = new System.Windows.Forms.RichTextBox())
                {
                    rtb.LoadFile(content, System.Windows.Forms.RichTextBoxStreamType.RichText);
                    rtb.SaveFile(path, System.Windows.Forms.RichTextBoxStreamType.RichText);
                }
            }
        }

        public static void NewFile(System.Windows.Forms.RichTextBox rtb)
        {
            object missing = System.Reflection.Missing.Value;
            Word.Application wordApp = null;
            Word.Document doc = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = true;

                doc = wordApp.Documents.Add(ref missing, ref missing, ref missing, ref missing);
                using (System.Windows.Forms.RichTextBox rtb2 = new System.Windows.Forms.RichTextBox())
                {
                    rtb2.Rtf = rtb.Rtf;
                    rtb2.SelectAll();
                    rtb2.Copy();
                }
                doc.Content.Paste();

                wordApp.Activate();
                wordApp.WindowState = Word.WdWindowState.wdWindowStateMaximize;
            }
            catch (COMException ex)
            {
                try
                {
                    doc.Close(ref missing, ref missing, ref missing);
                    wordApp.Quit(ref missing, ref missing, ref missing);
                }
                catch
                {
                }

                MessageBox.Show("You must have Word 2010 installed to use compare feature."
                    + System.Environment.NewLine + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// 在Word中打开文件
        /// </summary>
        /// <param name="sourceFile"></param>
        public static void OpenFile(string sourceFile)
        {
            object missing = System.Reflection.Missing.Value;
            Word.Application wordApp = null;
            Word.Document doc = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = true;

                Object confirmConversions = false;

                object source = sourceFile;
                doc = wordApp.Documents.Open(ref source, ref confirmConversions, true, false,
                    ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                wordApp.Activate();
                wordApp.WindowState = Word.WdWindowState.wdWindowStateMaximize;
            }
            catch (COMException ex)
            {
                try
                {
                    doc.Close(ref missing, ref missing, ref missing);
                    wordApp.Quit(ref missing, ref missing, ref missing);
                }
                catch
                {
                }

                MessageBox.Show("You must have Word 2010 installed to use compare feature."
                    + System.Environment.NewLine + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
