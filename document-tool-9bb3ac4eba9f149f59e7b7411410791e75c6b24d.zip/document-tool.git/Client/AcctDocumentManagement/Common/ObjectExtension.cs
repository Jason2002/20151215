﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace DocumentManagementTool.Common
{
    public static class ObjectExtension
    {
        public static T DeepClone<T>(this T data) where T : class
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, data);
            ms.Position = 0;
            T obj = bf.Deserialize(ms) as T;
            ms.Close();
            return obj;
        }
    }
}
