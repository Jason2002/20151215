﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using DocumentManagementTool.Controller;
using DocumentManagementTool.Common;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for UploadAttachment.xaml
    /// </summary>
    public partial class UploadAttachment : Window
    {
        public UploadAttachment()
        {
            InitializeComponent();
        }

        private string m_downloadUrl = string.Empty;
        public string DownloadURL { get { return m_downloadUrl; } }

        public AttachmentEntity Attachment { get; private set; }
        public AttachmentDocumentEntity AttachmentDocument { get; private set; }

        private void btnChooseFile_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.OpenFileDialog dialog = new System.Windows.Forms.OpenFileDialog();
            dialog.Filter = "All Files|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtFile.Text = dialog.FileName;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            FileInfo file = new FileInfo(txtFile.Text);
            if (!file.Exists)
            {
                MessageBox.Show("Invalid file, please choose again");
                return;
            }

            long max = 20 * 1024 * 1024;

            if (file.Length > max)
            {
                MessageBox.Show("File size more than 20M, please choose again");
                return;
            }

            try
            {
                //通过Hash比较附件已存在则不用上传
                string hashCode = HashHelper.SHA1File(txtFile.Text);
                this.Attachment = AttachmentController.FindAttachmentByHash(hashCode, file.Name);
                if (Attachment == null)
                {
                    m_downloadUrl = AttachmentController.UploadAttachment(txtFile.Text);

                    Attachment = new AttachmentEntity();
                    Attachment.FileName = file.Name;
                    Attachment.DownloadUrl = m_downloadUrl;
                    Attachment.HashCode = hashCode;
                    Attachment.EditUser = Environment.UserName;
                    Attachment.EditDate = DateTime.Now;
                    Attachment.GenerateFlag = false;
                }
                else
                {
                    m_downloadUrl = Attachment.DownloadUrl;

                    this.AttachmentDocument = new AttachmentDocumentEntity();
                    this.AttachmentDocument.AttachmentId = Attachment.AttachmentId;
                    this.AttachmentDocument.EditUser = Environment.UserName;
                    this.AttachmentDocument.EditDate = DateTime.Now;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Upload failed, error:{0}", ex.Message));
                return;
            }

            DialogResult = true;

        }
    }
}
