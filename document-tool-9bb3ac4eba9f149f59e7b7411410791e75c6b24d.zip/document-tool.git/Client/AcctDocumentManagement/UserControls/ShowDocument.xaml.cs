﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Markup;

namespace DocumentManagementTool.UserControls
{
    /// <summary>
    /// Interaction logic for ShowDocument.xaml
    /// </summary>
    public partial class ShowDocument : UserControl
    {
        private DocumentEntity m_document = null;
        
        public ShowDocument()
        {
            InitializeComponent();
        }

        private bool m_hasDocument = false;

        public bool HasDocument
        {
            get { return m_hasDocument; }
            set { m_hasDocument = value; }
        }

        public DocumentEntity Document
        {
            get { return m_document; }
            set { m_document = value; }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            ClearContent();
        }

        
         public void ShowContent(DocumentEntity document)
        {
            try
            {
                m_document = document;
                byte[] newByte = Convert.FromBase64String(document.DocumentContent);
                FlowDocument flowDocument = new FlowDocument();
                TextRange range;
                range = new TextRange(flowDocument.ContentStart, flowDocument.ContentEnd);
                using (MemoryStream content = new MemoryStream(newByte))
                {
                    content.Seek(0, SeekOrigin.Begin);
                    if (range.CanLoad(DataFormats.XamlPackage))
                        range.Load(content, DataFormats.XamlPackage);
                    fdReader.Document = flowDocument;

                }
                txtKeywords.Text = document.DocumentKeywords;
                txtKeyLabel.Text = "Keywords";
                m_hasDocument = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                m_hasDocument = false;
            }

        }
        

        public void ClearContent()
        {
            m_hasDocument = false;
            txtKeywords.Text = string.Empty;
            txtKeyLabel.Text = string.Empty;
            
            //spKeywords.Visibility = Visibility.Collapsed;
            fdReader.Document = null;
        }
    }
}
