﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using DocumentManagementTool.Controller;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace DocumentManagementTool.UserControls
{
    /// <summary>
    /// Interaction logic for DocumentEditor.xaml
    /// </summary>
    public partial class DocumentEditor : UserControl
    {
        private DocumentEntity m_document;

        private string m_userName;

        public EditMode Mode { get; set; }

        public DocumentEditor()
        {
            InitializeComponent();

            this.InitializeClipboardGroup();
            this.InitializeFontGroup();
            this.InitializeParagraphGroup();
            this.InitializeViewZoomGroup();
            this.InitializeUndoRedo();
            this.SetReadOnly(true);
        }

        public void AppendText(string text)
        {
            if (Mode == EditMode.Edit)
            {
                richTextBox1.AppendText("\r\n" + text + "\r\n");
            }
        }


        public DocumentEntity GetDocument()
        {
            if (m_document == null)
            {
                m_document = new DocumentEntity();
                m_document.Status = "A";
                m_document.DocumentId = null;
            }

            using (MemoryStream mStream = new MemoryStream())
            {
                richTextBox1.SaveFile(mStream, System.Windows.Forms.RichTextBoxStreamType.RichText);

                string content = CompressHelper.CompressContent(mStream);
                m_document.DocumentContent = content;
            }
            m_document.EditDate = DateTime.Now;
            m_document.EditUser = m_userName;
            m_document.DocumentKeywords = txtKeywords.Text.Trim();

            //LogController.WriteText(m_document.SerializerToXml(), 1);
            //LogController.WriteText(m_document.SerializerToBinary(), 2);
            return m_document;
        }

        public void ShowContent(DocumentEntity document, string userName, EditMode mode)
        {
            m_userName = userName;
            Mode = mode;
            SetReadOnly(!(mode == EditMode.Edit));
            if (document != null)
            {
                //richTextBox1.Hide();
                m_document = document;
                using (MemoryStream content = new MemoryStream())
                {
                    CompressHelper.Decomparess(document.DocumentContent, content);
                    richTextBox1.Clear();
                    content.Position = 0;
                    if (content.Length > 0)
                    {
                        richTextBox1.LoadFile(content, System.Windows.Forms.RichTextBoxStreamType.RichText);
                    }
                }
                txtKeywords.Text = m_document.DocumentKeywords;
                txtBlockKeywords.Text = m_document.DocumentKeywords;

                //匹配并处理链接，防止中文URL链接被截断。
                //Regex regex = new Regex(@"http(s)?://([\w-]+\.)*[\w-]+(/[\w- ./?%&=\p{P}]*)?", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                Regex regex = new Regex(@"http(s)?://[^\s]*", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                Regex regex_chinese = new Regex(@"[\u4e00-\u9fa5]", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                var mc = regex.Matches(richTextBox1.Text);
                //从后往前替换，降低屏幕闪烁
                for (int i = mc.Count - 1; i >= 0; i--)
                {
                    Match m = mc[i];
                    if (regex_chinese.Matches(m.Value).Count > 0)
                    {
                        richTextBox1.Select(m.Index, m.Length);
                        richTextBox1.SelectedText = string.Empty;
                        richTextBox1.InsertLink(m.Value, m.Index);
                    }
                }
                richTextBox1.Select(0, 0);
                //richTextBox1.Show();
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        public void ClearContent()
        {
            txtKeywords.Text = string.Empty;
            txtBlockKeywords.Text = string.Empty;
            m_document = null;
            richTextBox1.Clear();
            Mode = EditMode.None;
            this.SetReadOnly(true);
        }

        private void SetReadOnly(bool isReadOnly)
        {
            CutButton.IsEnabled = !isReadOnly;
            CopyButton.IsEnabled = !isReadOnly;
            PasteButton.IsEnabled = !isReadOnly;
            UndoButton.IsEnabled = !isReadOnly;
            RedoButton.IsEnabled = !isReadOnly;
            FontBoldButton.IsEnabled = !isReadOnly;
            FontItalicButton.IsEnabled = !isReadOnly;
            FontUnderlineButton.IsEnabled = !isReadOnly;
            ParagraphAlignLeftButton.IsEnabled = !isReadOnly;
            ParagraphAlignCenterButton.IsEnabled = !isReadOnly;
            ParagraphAlignRightButton.IsEnabled = !isReadOnly;
            IncreaseIndentButton.IsEnabled = !isReadOnly;
            DecreaseIndentButton.IsEnabled = !isReadOnly;
            cmbFont.IsEnabled = !isReadOnly;
            cmbSize.IsEnabled = !isReadOnly;
            txtKeywords.Visibility = isReadOnly ? Visibility.Collapsed : Visibility.Visible;
            txtBlockKeywords.Visibility = isReadOnly ? Visibility.Visible : Visibility.Collapsed;
            richTextBox1.BackColor = isReadOnly ? System.Drawing.Color.LightGray : System.Drawing.SystemColors.Window;
            richTextBox1.ReadOnly = isReadOnly;
        }

        #region RichTextBox

        #region Clipboard Group

        private void InitializeClipboardGroup()
        {
            this.UpdateClipboardGroupBasedOnCurrentTextSelection();

            this.richTextBox1.SelectionChanged += delegate
            {
                this.UpdateClipboardGroupBasedOnCurrentTextSelection();
            };
        }

        private void CutButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Cut();
        }

        private void CopyButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Copy();
        }

        private void PasteButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Paste();
        }

        private void UpdateClipboardGroupBasedOnCurrentTextSelection()
        {
            this.CutButton.IsEnabled = this.CopyButton.IsEnabled =
                !string.IsNullOrEmpty(this.richTextBox1.SelectedText);
        }

        #endregion
        #region Font Group

        private void InitializeFontGroup()
        {
            foreach (var oneFontFamily in Fonts.SystemFontFamilies)
            {
                cmbFont.Items.Add(oneFontFamily.Source);
            }

            foreach (int size in new int[] { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 })
            {
                this.cmbSize.Items.Add(size.ToString());
            }

            this.UpdateFontGroupBasedOnCurrentTextSelection();
            this.richTextBox1.SelectionChanged += delegate
            {
                this.UpdateFontGroupBasedOnCurrentTextSelection();
            };
        }

        private void UpdateFontGroupBasedOnCurrentTextSelection()
        {
            Font font = this.richTextBox1.SelectionFont;
            bool none = font == null;
            FontBoldButton.IsChecked = none ? false : font.Bold;
            FontItalicButton.IsChecked = none ? false : font.Italic;
            FontUnderlineButton.IsChecked = none ? false : font.Underline;
            cmbFont.Text = none ? "" : font.FontFamily.Name;
            cmbSize.Text = none ? "" : font.Size.ToString();
        }

        private void FontFaceComboBox_ChangeCommitted(object sender, EventArgs e)
        {
            if (this.cmbFont.SelectedValue == null || this.cmbFont.SelectedValue.ToString() == "")
            {
                return;
            }
            string fontFamilyName = this.cmbFont.SelectedValue.ToString();
            Font font = this.richTextBox1.SelectionFont;

            if (font == null)
            {
                this.richTextBox1.SelectionFont = new Font(
                fontFamilyName, float.Parse("10.5"));
            }
            else
            {

                this.richTextBox1.SelectionFont = new Font(
                    fontFamilyName,
                    font.Size,
                    font.Style,
                    font.Unit);
            }
        }

        private void FontSizeComboBox_ChangeCommitted(object sender, EventArgs e)
        {
            if (this.cmbSize.SelectedValue == null || this.cmbSize.SelectedValue.ToString() == "")
            {
                return;
            }

            Font font = this.richTextBox1.SelectionFont;

            if (font == null)
            {
                return;
            }

            this.richTextBox1.SelectionFont = new Font(
                font.FontFamily,
                float.Parse(this.cmbSize.SelectedValue.ToString()),
                font.Style,
                GraphicsUnit.Point);
        }

        #region Bold, Italic, Underline, and Strikeout Buttons

        private void FontBoldButton_Click(object sender, EventArgs e)
        {
            ToggleSelectionFontStyle(System.Drawing.FontStyle.Bold);
        }

        private void FontItalicButton_Click(object sender, EventArgs e)
        {
            ToggleSelectionFontStyle(System.Drawing.FontStyle.Italic);
        }

        private void FontUnderlineButton_Click(object sender, EventArgs e)
        {
            ToggleSelectionFontStyle(System.Drawing.FontStyle.Underline);
        }

        void ToggleSelectionFontStyle(System.Drawing.FontStyle fontStyle)
        {
            if (this.richTextBox1.SelectionFont == null)
            {
                MessageBox.Show("Cannot change font style while selected text has more than one font.");
            }
            else
            {

                this.richTextBox1.SelectionFont = new Font(this.richTextBox1.SelectionFont,
                    this.richTextBox1.SelectionFont.Style ^ fontStyle);
            }
        }

        #endregion

        private void WrapButton_Click(object sender, EventArgs e)
        {
            if (WrapButton.IsChecked.Value)
            {
                richTextBox1.WordWrap = true;
            }
            else
            {
                richTextBox1.WordWrap = false;
            }
        }

        #endregion
        #region Paragraph Group

        private void InitializeParagraphGroup()
        {

            this.UpdateParagraphGroupBasedOnCurrentTextSelection();
            this.richTextBox1.SelectionChanged += delegate
            {
                this.UpdateParagraphGroupBasedOnCurrentTextSelection();
            };
        }

        private void UpdateParagraphGroupBasedOnCurrentTextSelection()
        {
            this.UpdateParagraphAlignmentButtons();
        }

        #region Indent Buttons

        private void IncreaseIndentButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionIndent += 30;
        }

        private void DecreaseIndentButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionIndent -= 30;
        }

        #endregion
        #region Alignment Buttons

        private void ParagraphAlignLeftButton_Click(object sender, EventArgs e)
        {
            this.SetParagraphAlignment(System.Windows.Forms.HorizontalAlignment.Left);
        }

        private void ParagraphAlignCenterButton_Click(object sender, EventArgs e)
        {
            this.SetParagraphAlignment(System.Windows.Forms.HorizontalAlignment.Center);
        }

        private void ParagraphAlignRightButton_Click(object sender, EventArgs e)
        {
            this.SetParagraphAlignment(System.Windows.Forms.HorizontalAlignment.Right);
        }

        void SetParagraphAlignment(System.Windows.Forms.HorizontalAlignment alignment)
        {
            this.richTextBox1.SelectionAlignment = alignment;

            this.UpdateParagraphAlignmentButtons();
        }

        private void UpdateParagraphAlignmentButtons()
        {
            System.Windows.Forms.HorizontalAlignment a = this.richTextBox1.SelectionAlignment;
            this.ParagraphAlignLeftButton.IsChecked = a == System.Windows.Forms.HorizontalAlignment.Left;
            this.ParagraphAlignCenterButton.IsChecked = a == System.Windows.Forms.HorizontalAlignment.Center;
            this.ParagraphAlignRightButton.IsChecked = a == System.Windows.Forms.HorizontalAlignment.Right;
        }

        #endregion

        #endregion
        #region View Zoom Group

        private void InitializeViewZoomGroup()
        {
            foreach (int percent in new int[] { 10, 30, 50, 80, 100, 120, 150, 200, 250, 300, 400, 700, 1000 })
            {
                this.ViewZoomCombobox.Items.Add(percent.ToString() + "%");
            }
        }

        private void ViewZoomCombobox_ChangeCommitted(object sender, EventArgs e)
        {
            string s = this.ViewZoomCombobox.SelectedValue.ToString();
            if (string.IsNullOrEmpty(s)) return;
            if (s.EndsWith("%")) s = s.Substring(0, s.Length - 1);
            float percent;
            if (!float.TryParse(s, out percent)) return;
            this.SetZoomFactor(percent / 100);
        }

        private void SetZoomFactor(float zoomFactor)
        {
            this.richTextBox1.ZoomFactor = zoomFactor;
        }

        #endregion
        #region Undo/Redo

        private void InitializeUndoRedo()
        {
            this.UpdateUndoRedoButtons();
            this.richTextBox1.TextChanged += delegate { this.UpdateUndoRedoButtons(); };
        }

        void UpdateUndoRedoButtons()
        {
            this.UndoButton.IsEnabled = this.richTextBox1.CanUndo;
            this.RedoButton.IsEnabled = this.richTextBox1.CanRedo;
        }

        private void UndoButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Undo();
            this.UpdateUndoRedoButtons();
        }

        private void RedoButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Redo();
            this.UpdateUndoRedoButtons();
        }

        #endregion

        private void richTextBox1_LinkClicked(object sender, System.Windows.Forms.LinkClickedEventArgs e)
        {
            Process.Start(e.LinkText);
        }

        #endregion

        #region 查找和高亮
        public void Find(string key)
        {
            Regex r = new Regex(key, RegexOptions.IgnoreCase);

            MatchCollection mc = r.Matches(richTextBox1.Text);
            if (mc.Count == 0) return;

            foreach (Match m in mc)
            {
                richTextBox1.Select(m.Index, m.Length);
                richTextBox1.SelectionColor = System.Drawing.Color.Black;
                richTextBox1.SelectionBackColor = System.Drawing.Color.GreenYellow;
            }

        }
        #endregion
    }

    public enum EditMode
    {
        Read,
        Edit,
        None,
    }

    public static class SerializerHelper
    {
        public static string SerializerToXml(this object serialObject)
        {
            string message = null;
            if (serialObject != null)
            {
                StringBuilder sb = new StringBuilder(1000);
                XmlSerializer ser = new XmlSerializer(serialObject.GetType());

                using (TextWriter writer = new StringWriter(sb))
                {
                    ser.Serialize(writer, serialObject);
                    message = writer.ToString();
                }

                int idxEnd = message.IndexOf("?>");
                if (idxEnd > -1)
                {
                    message = message.Substring(idxEnd + 2);
                }
            }
            return message;
        }

        public static string SerializerToBinary(this object serialObject)
        {
            string result = string.Empty;

            using (MemoryStream ms = new MemoryStream())
            {
                try
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(ms, serialObject);
                    ms.Position = 0;
                    result = System.Text.Encoding.Unicode.GetString(ms.ToArray());
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return result;
        }
    }
}
