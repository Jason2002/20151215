﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.ViewModel;
using DocumentManagementTool.Common;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for MaintainUser2.xaml
    /// </summary>
    public partial class MaintainUser2 : Window
    {
        private string m_uid;
        private UserOperationRights m_userOperation;
        private UserOperationRights m_findOperation;
        private List<DocumentCategory> m_categories;
        private PrivilegeClientProxy m_privilegeProxy;
        private UserRightsClientProxy m_userRightsClientProxy;
        private List<CategoryPrivilegeModel> m_treeData = null;
        private List<CategoryPrivilegeModel> m_treeData_Clean = null;

        public MaintainUser2(string uid, UserOperationRights editUserInfo, List<DocumentCategory> categories)
        {
            InitializeComponent();

            m_uid = uid;
            m_userOperation = editUserInfo;
            m_categories = categories.DeepClone();
            m_privilegeProxy = new PrivilegeClientProxy();
            m_userRightsClientProxy = new UserRightsClientProxy();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            treeGrid.Visibility = Visibility.Collapsed;

            List<CategoryPrivilegeModel> privileges = new List<CategoryPrivilegeModel>();
            GetPrivileges(m_categories, privileges, null);

            CategoryPrivilegeModel root = new CategoryPrivilegeModel(null);
            root.CategoryID = 0;
            root.CategoryName = "MIS Document";
            root.IsAllowSetEdit = false;
            root.IsAllowSetOwner = false;
            root.IsAllowSetView = false;
            privileges.ForEach(p => p.Parent = root);
            root.SubItems = new List<CategoryPrivilegeModel>();
            root.SubItems.AddRange(privileges);
            m_treeData = new CategoryPrivilegeModel[] { root }.ToList();
            m_treeData_Clean = m_treeData.DeepClone();
            treeGrid.DataContext = m_treeData;
        }

        private void GetPrivileges(List<DocumentCategory> categories, List<CategoryPrivilegeModel> privileges, CategoryPrivilegeModel parent)
        {
            foreach (var dc in categories)
            {
                if ((dc.Entity.IsAuthShow.HasValue && !dc.Entity.IsAuthShow.Value)
                    || (dc.Entity.IsAuthEdit.HasValue && !dc.Entity.IsAuthEdit.Value)) continue;

                var privilege = new CategoryPrivilegeModel(parent)
                {
                    CategoryID = dc.CategoryId,
                    CategoryName = dc.CategoryName,
                };

                if (dc.SubCategories != null)
                {
                    privilege.SubItems = new List<CategoryPrivilegeModel>();
                    GetPrivileges(dc.SubCategories.ToList(), privilege.SubItems, privilege);
                }

                privileges.Add(privilege);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (m_treeData == null) return;

            var result = new List<PrivilegeInfo>();
            if (chbAdmin.IsChecked.Value)
            {
                result.Add(new PrivilegeInfo()
                {
                    CategoryID = 0,
                    AcctName = txtUserID.Text.Trim(),
                    AcctType = m_AcctType,
                    Permission = PrivilegeAction.Owner | PrivilegeAction.View | PrivilegeAction.Edit,
                    EditUser = m_uid,
                    EditDate = DateTime.Now
                });
            }
            else
            {
                GetUpdateData(m_treeData, result);
            }

            if (result == null || result.Count == 0)
            {
                m_privilegeProxy.Delete(m_AcctType, txtUserID.Text.Trim());
            }
            else
            {
                m_privilegeProxy.Update(result);
            }

            MessageBox.Show("Save successfully.", "information", MessageBoxButton.OK, MessageBoxImage.Information);
            btnSave.IsEnabled = false;
        }

        public void GetUpdateData(List<CategoryPrivilegeModel> data, List<PrivilegeInfo> result)
        {
            if (data == null) return;

            foreach (var cpi in data)
            {
                if (cpi.CategoryID != 0 && cpi.Permission.HasValue && cpi.Permission != 0)
                {
                    result.Add(new PrivilegeInfo()
                    {
                        CategoryID = cpi.CategoryID,
                        AcctName = txtUserID.Text.Trim(),
                        AcctType = m_AcctType,
                        Permission = cpi.Permission.Value,
                        EditUser = m_uid,
                        EditDate = DateTime.Now
                    });
                }

                if (cpi.SubItems != null)
                {
                    GetUpdateData(cpi.SubItems, result);
                }
            }
        }

        public PrivilegeAcctType m_AcctType = PrivilegeAcctType.User;
        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            //验证帐号信息并确定类型
            PrivilegeAcctType? acctType = m_privilegeProxy.GetAcctType(txtUserID.Text.Trim());
            if (!acctType.HasValue)
            {
                chbAdmin.IsEnabled = false;
                treeGrid.IsEnabled = false;
                btnSave.IsEnabled = false;
                MessageBox.Show("Not found specified name from active directory.", "warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            m_AcctType = acctType.Value;
            m_findOperation = m_userRightsClientProxy.GetUserOperationRightsById(txtUserID.Text.Trim());

            //清除当前界面数据
            ClearData(m_treeData);
            btnSave.IsEnabled = false;

            //获取数据
            List<PrivilegeInfo> list = null;
            if (m_AcctType == PrivilegeAcctType.User)
            {
                list = m_privilegeProxy.GetPrivilegeListByUserSelf(txtUserID.Text.Trim());
            }
            else if (m_AcctType == PrivilegeAcctType.Group)
            {
                list = m_privilegeProxy.GetPrivilegeListByGroupSelf(txtUserID.Text.Trim());
            }
            //if (list != null)
            //{
            //    list.RemoveAll(p => p.CategoryID == 0);
            //}

            LoadData(m_treeData, list);

            if (m_userOperation.IsOwner)
            {
                InitOwner(m_treeData, m_userOperation.OwnerCategoryID);
            }

            treeGrid.Visibility = Visibility.Visible;
            chbAdmin.IsChecked = m_findOperation.IsAdmin;
            treeGrid.IsEnabled = !chbAdmin.IsChecked.Value;
            chbAdmin.IsEnabled = m_userOperation.IsAdmin;
        }

        private void InitOwner(List<CategoryPrivilegeModel> cpiList, List<int> OwnerCategoryID)
        {
            foreach (var cpi in cpiList)
            {
                if (OwnerCategoryID.FirstOrDefault(c => c == cpi.CategoryID) > 0)
                {
                    SetEnabled(cpi, true);
                }

                if (cpi.SubItems != null)
                {
                    InitOwner(cpi.SubItems, OwnerCategoryID);
                }
            }
        }

        private void SetEnabled(CategoryPrivilegeModel cpi, bool isEnabled)
        {
            cpi.IsAllowSetOwner = isEnabled;
            cpi.IsAllowSetView = isEnabled;
            cpi.IsAllowSetEdit = isEnabled;

            if (cpi.SubItems != null)
            {
                foreach (var cp in cpi.SubItems)
                {
                    SetEnabled(cp, isEnabled);
                }
            }
        }

        public void ClearData(List<CategoryPrivilegeModel> cpiList)
        {
            foreach (var cpi in cpiList)
            {
                //cpi.Permission = 0;
                cpi.IsAllowSetOwner = m_userOperation.IsAdmin;
                cpi.IsAllowSetView = m_userOperation.IsAdmin;
                cpi.IsAllowSetEdit = m_userOperation.IsAdmin;
                cpi.IsOwner = false;
                cpi.IsView = false;
                cpi.IsEdit = false;

                if (cpi.SubItems != null)
                {
                    ClearData(cpi.SubItems);
                }
            }
        }

        public void LoadData(List<CategoryPrivilegeModel> cpiList, List<PrivilegeInfo> privileges)
        {
            foreach (var cpi in cpiList)
            {
                var pri = privileges.FirstOrDefault(p => p.CategoryID == cpi.CategoryID);
                if (pri != null)
                {
                    cpi.IsOwner = (pri.Permission & PrivilegeAction.Owner) == PrivilegeAction.Owner;
                    cpi.IsView = (pri.Permission & PrivilegeAction.View) == PrivilegeAction.View;
                    cpi.IsEdit = (pri.Permission & PrivilegeAction.Edit) == PrivilegeAction.Edit;
                    //cpi.Permission = pri.Permission;
                }

                if (cpi.SubItems != null)
                {
                    LoadData(cpi.SubItems, privileges);
                }
            }
        }

        private void chbAdmin_Checked(object sender, RoutedEventArgs e)
        {
            treeGrid.IsEnabled = !chbAdmin.IsChecked.Value;
            btnSave.IsEnabled = true;

            if (!chbAdmin.IsChecked.Value)
            {
                var pri = m_treeData.FirstOrDefault(p => p.CategoryID == 0);
                if (pri != null)
                {
                    pri.IsOwner = false;
                    pri.IsView = false;
                    pri.IsEdit = false;
                }
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            btnSave.IsEnabled = true;
        }

        private void txtUserID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                btnFind_Click(sender, null);
            }
        }
    }
}
