﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DocumentManagementTool.ViewModel;
using DocumentManagementTool.Controller;
using DocumentManagementTool.Common;

namespace DocumentManagementTool
{
    /// <summary>
    /// Interaction logic for DocumentHistory.xaml
    /// </summary>
    public partial class DocumentHistory : Window
    {
        List<DocumentEntity> m_entities;
        DocumentCategory category;

        public DocumentController DocumentController { get; set; }

        public DocumentHistory(List<DocumentEntity> entities, DocumentCategory category)
        {
            m_entities = entities;
            this.category = category;
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtName.Text = category.CategoryName;
            //txtName.Text = string.Format(txtName.Text, category.CategoryName);
            //txtDocIdLable.Text = string.Format(txtDocIdLable.Text, category.CategoryName);
            //txtDocPathLable.Text = string.Format(txtDocPathLable.Text, category.CategoryName);
            //string versionInfo = string.Empty;
            //m_entities.OrderByDescending(m => m.EditDate).ToList().ForEach(d =>
            //    {
            //        versionInfo += string.Format("{0} edit document at {1}.(Version: {2})", d.EditUser, d.EditDate, d.Version) + System.Environment.NewLine;
            //    });
            //txtHistory.Text = versionInfo;

            lbHistory.ItemsSource = m_entities.OrderByDescending(m => m.EditDate).ToList();

            txtDocId.Text = category.CategoryId.ToString();
            txtDocPath.Text = category.Path;


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void TextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            (sender as TextBox).SelectAll();
        }

        private void miView_Click(object sender, RoutedEventArgs e)
        {
            //获取数据并显示比较窗口
            int id1 = (lbHistory.SelectedItems[0] as DocumentEntity).DocumentId.Value;

            DocumentEntity doc1 = DocumentController.GetDocumentById(id1);
            ViewDocument viewDocument = new ViewDocument(doc1);
            viewDocument.Show();
        }

        private void miCompare_Click(object sender, RoutedEventArgs e)
        {
            if (lbHistory.SelectedItems.Count < 2) return;

            //获取数据并显示比较窗口
            int id1 = (lbHistory.SelectedItems[0] as DocumentEntity).DocumentId.Value;
            int id2 = (lbHistory.SelectedItems[1] as DocumentEntity).DocumentId.Value;

            DocumentEntity doc1 = DocumentController.GetDocumentById(id1);
            DocumentEntity doc2 = DocumentController.GetDocumentById(id2);
            CompareDialog compareDialog = new CompareDialog(doc1, doc2);
            compareDialog.Show();
        }

        private void lbHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //限制只能选择两项参与比较
            if (lbHistory.SelectedItems.Count > 2)
            {
                lbHistory.SelectedItems.RemoveAt(0);
            }
        }

        private void miCompareInWord_Click(object sender, RoutedEventArgs e)
        {
            if (lbHistory.SelectedItems.Count < 2) return;

            //获取数据
            int id1 = (lbHistory.SelectedItems[0] as DocumentEntity).DocumentId.Value;
            int id2 = (lbHistory.SelectedItems[1] as DocumentEntity).DocumentId.Value;

            this.Cursor = Cursors.Wait;
            try
            {
                DocumentEntity doc1 = DocumentController.GetDocumentById(id1);
                DocumentEntity doc2 = DocumentController.GetDocumentById(id2);

                string file1 = string.Format("{0}{1}__version{2}__{3}",
                    System.IO.Path.GetTempPath(), doc1.EditUser, doc1.Version.Replace(".", "_"),
                    System.IO.Path.GetFileName(System.IO.Path.GetTempFileName()));
                string file2 = string.Format("{0}{1}__version{2}__{3}",
                    System.IO.Path.GetTempPath(), doc2.EditUser, doc2.Version.Replace(".", "_"),
                    System.IO.Path.GetFileName(System.IO.Path.GetTempFileName()));

                WordHelper.SaveToFile(doc1.DocumentContent, file1);
                WordHelper.SaveToFile(doc2.DocumentContent, file2);

                WordHelper.CompareUsingWord(file2, file1);
            }
            finally
            {
                this.Cursor = Cursors.Arrow;
            }
        }

        private void ContextMenu_Loaded(object sender, RoutedEventArgs e)
        {
            miCompare.IsEnabled = lbHistory.SelectedItems.Count >= 2;
            miCompareInWord.IsEnabled = lbHistory.SelectedItems.Count >= 2;
        }


    }

}
