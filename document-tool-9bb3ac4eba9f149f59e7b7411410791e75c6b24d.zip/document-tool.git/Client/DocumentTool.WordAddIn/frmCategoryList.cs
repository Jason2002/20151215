﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Tools.Word;
using DocumentManagementTool.Controller;
using DocumentManagementTool.ViewModel;
using DocumentTool.OfficeAddIn.Controls;
using DocumentTool.WordAddIn.BLL;

namespace DocumentTool.WordAddIn
{
    public partial class frmCategoryList : Form
    {
        private Word.Application app = null;
        private string _userName = string.Empty;
        private DocumentEntity _document;
        private bool _isFirstLoad = true;
        private WordBLL _wordBLL = new WordBLL();

        public frmCategoryList()
        {
            InitializeComponent();
        }

        private void frmCategoryList_Load(object sender, EventArgs e)
        {
            if (DesignMode) return;

            app = Globals.ThisAddIn.Application;
            _userName = System.Environment.UserName;
            ucCategoryTree.DefaultNewCategoryName = Path.GetFileNameWithoutExtension(app.ActiveDocument.Name);

            if (_isFirstLoad)
            {
                ucCategoryTree.OnSelectedNodeChanged += new SelectedNodeChangedHandler(ucCategoryTree_OnSelectedNodeChanged);
                btnOK.Enabled = false;
            }

            _isFirstLoad = false;
        }

        private void ucCategoryTree_OnSelectedNodeChanged(object sender, TreeNodeEventArgs e)
        {
            if (e.Document != null)
            {
                _document = e.Document;
                txtKeywords.Text = e.Document.DocumentKeywords;
            }
            else
            {
                _document = null;
                txtKeywords.Text = string.Empty;
            }

            bool canPublish = e.Category != null && ucCategoryTree.CanPublish;
            btnOK.Enabled = canPublish;
            txtKeywords.ReadOnly = !canPublish;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                //TODO:比较本地和服务端版本，如服务端存在更高版本，则警告

                //上传附件
                string downloadUrls_Embed = string.Empty;

                IList<AttachmentEntity> atts = null;
                IList<AttachmentDocumentEntity> ads = null;

                if ((Path.GetExtension(app.ActiveDocument.FullName) != ".docx")
                    || app.ActiveDocument.FullName.StartsWith("http://"))
                {
                    //不支持提取附件
                }
                else
                {
                    _wordBLL.UploadAttachment(app.ActiveDocument.FullName, ref downloadUrls_Embed, ref atts, ref ads);
                }

                //构造邮件头信息
                string headerText = _wordBLL.BuildAppendInfo(downloadUrls_Embed);

                //保存正文
                int newDocId = SaveDocument(ucCategoryTree.GetCommandItem(), headerText);

                //保存附件信息
                _wordBLL.AddAttachmentInfo(newDocId, atts, ads);

                MessageBox.Show("publish succeeded.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //txtKeywords.Text = string.Empty;
                //this.Hide();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LogController.WriteLog(ex);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        public int SaveDocument(DocumentCategory category, string headerText)
        {
            DocumentEntity entity = GetDocument(headerText);
            if (entity == null) throw new ApplicationException("not found data.");

            entity.EditUser = _userName;
            entity.EditDate = DateTime.Now;

            return ucCategoryTree.DocumentController.UpdateDocument(category.CategoryId, entity);

            //刷新版本号
            //_document = ucCategoryTree.DocumentController.GetDocumentByCategoryId(category.CategoryId);
        }

        public DocumentEntity GetDocument(string headerText)
        {
            if (_document == null)
            {
                _document = new DocumentEntity();
                _document.Status = "A";
                _document.DocumentId = null;
            }

            byte[] buffer = _wordBLL.GetDocumentContent(app.ActiveDocument, string.Empty, headerText);
            if (buffer == null) return null;
            using (MemoryStream mStream = new MemoryStream(buffer))
            {
                string content = CompressHelper.CompressContent(mStream);
                _document.DocumentContent = content;
            }
            _document.EditDate = DateTime.Now;
            _document.EditUser = _userName;
            _document.DocumentKeywords = txtKeywords.Text.Trim();

            return _document;
        }

        /*
        public static byte[] ReadAllBytes(String path)
        {
            byte[] bytes;
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                int index = 0;
                long fileLength = fs.Length;
                if (fileLength > Int32.MaxValue)
                    throw new IOException("File too long");
                int count = (int)fileLength; bytes = new byte[count];
                while (count > 0)
                {
                    int n = fs.Read(bytes, index, count);
                    if (n == 0) throw new InvalidOperationException("End of file reached before expected"); index += n; count -= n;
                }
            }
            return bytes;
        }
         * */

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            //this.Hide();
        }


    }
}
