﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using System.IO;

namespace DocumentTool.WordAddIn
{
    public partial class rbnMain
    {
        private Word.Application app = null;
        private frmCategoryList _frmCategoryList = new frmCategoryList();

        private void rbnMain_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void btnPublish_Click(object sender, RibbonControlEventArgs e)
        {
            app = Globals.ThisAddIn.Application;

            if (string.IsNullOrEmpty(Path.GetExtension(app.ActiveDocument.FullName)))
            {
                if (MessageBox.Show("This command publish the disk version of a file to the server. Do you want to save your changes to disk before proceeding?", "warning",
                  MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        app.ActiveDocument.Save();
                        MessageBox.Show("save succeeded", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show("saved failed." + ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }

            //检查文档是否保存。
            if (!app.ActiveDocument.Saved)
            {
                if (MessageBox.Show("This command publish the disk version of a file to the server. Do you want to save your changes to disk before proceeding?", "warning",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        app.ActiveDocument.Save();
                        MessageBox.Show("save succeeded", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("saved failed." + ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            _frmCategoryList.ShowDialog();
        }
    }
}
