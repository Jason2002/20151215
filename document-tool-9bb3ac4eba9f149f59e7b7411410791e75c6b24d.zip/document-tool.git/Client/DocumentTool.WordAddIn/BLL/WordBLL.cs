﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using DocumentTool.OfficeAddIn.Controls.Common;
using Word = Microsoft.Office.Interop.Word;
using System.Windows.Forms;
using System.Drawing;
using DocumentManagementTool.Controller;

namespace DocumentTool.WordAddIn.BLL
{
    public class WordBLL
    {
        public void UploadAttachment(string sourceFile, ref string downloadUrls_Embed,
            ref IList<AttachmentEntity> atts, ref IList<AttachmentDocumentEntity> ads)
        {
            //复制文件，非进程占用文件才能解包
            string tempFile = Path.GetTempFileName();
            File.Copy(sourceFile, tempFile, true);

            string destFolder = GetTempFolder();
            OfficeFileExtractor officeFileExtractor = new OfficeFileExtractor();

            System.IO.FileInfo fi = new System.IO.FileInfo(sourceFile);

            atts = new List<AttachmentEntity>();
            ads = new List<AttachmentDocumentEntity>();
            if (officeFileExtractor.Extract(tempFile, destFolder, fi.Extension))
            {
                string downloadUrl = string.Empty;
                foreach (string file in (Directory.GetFiles(destFolder).Where(f => Path.GetExtension(f) != ".bin")))
                {
                    //通过Hash比较附件已存在则不用上传
                    string hashCode = HashHelper.SHA1File(file);
                    string attfileName = Path.GetFileName(file);
                    AttachmentEntity att = AttachmentController.FindAttachmentByHash(hashCode,attfileName);
                    if (att == null)
                    {
                        //上传附件
                        downloadUrl = DfisBLL.UploadAttachment(file);

                        att = new AttachmentEntity();
                        att.FileName = attfileName;
                        att.DownloadUrl = downloadUrl;
                        att.HashCode = hashCode;
                        att.EditUser = Environment.UserName;
                        att.EditDate = DateTime.Now;
                        att.GenerateFlag = false;
                        atts.Add(att);
                    }
                    else
                    {
                        downloadUrl = att.DownloadUrl;

                        AttachmentDocumentEntity ad = new AttachmentDocumentEntity();
                        ad.AttachmentId = att.AttachmentId;
                        ad.EditUser = Environment.UserName;
                        ad.EditDate = DateTime.Now;

                        ads.Add(ad);
                    }

                    downloadUrls_Embed += string.Concat(Environment.NewLine,
                       new string(' ', 4), downloadUrl);
                }
            }

            if (atts.Count == 0) atts = null;
            if (ads.Count == 0) ads = null;
            //return atts;

            //Directory.Delete(destFolder, true);
        }

        /// <summary>
        /// 写入附件信息到数据库
        /// </summary>
        /// <param name="documentId"></param>
        /// <param name="atts"></param>
        public void AddAttachmentInfo(int documentId, IList<AttachmentEntity> atts, IList<AttachmentDocumentEntity> ads)
        {
            if (atts != null)
            {
                foreach (AttachmentEntity att in atts)
                {
                    //att.DocumentId = documentId;
                    AttachmentController.AddAttachment(documentId, att);
                }
            }
            if (ads != null)
            {
                foreach (AttachmentDocumentEntity ad in ads)
                {
                    ad.DocumentId = documentId;
                    AttachmentController.AddAttachmentDocument(ad);
                }
            }
        }

        private string GetTempFolder()
        {
            // 系统临时文件夹
            string tempPath = Path.GetTempPath();
            string folderPath = string.Empty;

            do
            {
                folderPath = string.Concat(tempPath, "{", Guid.NewGuid().ToString(), "}");
            } while (Directory.Exists(folderPath));

            Directory.CreateDirectory(folderPath);
            return folderPath;
        }

        /// <summary>
        /// 构造附加信息
        /// </summary>
        /// <param name="downloadUrls_Embed">内嵌附件下载URL</param>
        /// <returns></returns>
        public string BuildAppendInfo(string downloadUrls_Embed)
        {
            if (string.IsNullOrEmpty(downloadUrls_Embed)) return string.Empty;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(new string('=', 80));
            if (!string.IsNullOrEmpty(downloadUrls_Embed))
            {
                sb.Append("Embedded Attachments:");
                sb.Append(downloadUrls_Embed);
                sb.AppendLine();
            }
            sb.AppendLine(new string('=', 80));

            return sb.ToString();
        }

        /// <summary>
        /// 依据指字的文档获取发布内容
        /// </summary>
        /// <param name="wordDoc"></param>
        /// <param name="headerText"></param>
        /// <param name="footerText"></param>
        /// <returns></returns>
        public byte[] GetDocumentContent(Word.Document wordDoc, string headerText, string footerText)
        {
            //使用Mail.RTFBody获取文档内容会丢失部分格式，所以这里还是采用剪贴板方式。

            //复制文档内容到剪贴板
            wordDoc.Content.Copy();

            using (RichTextBox rtb = new RichTextBox())
            {
                //添加头部信息
                rtb.AppendText(headerText);
                rtb.SelectAll();
                rtb.SelectionFont = new Font("Courier New", 11);
                rtb.SelectionColor = Color.Green;

                //添加正文
                rtb.Select(rtb.TextLength, 0);
                rtb.Paste();
                Clipboard.Clear();

                //添加尾部信息
                rtb.SelectionFont = new Font("Courier New", 11);
                rtb.SelectionColor = Color.Green;
                rtb.AppendText(footerText);

                using (System.IO.MemoryStream stream = new MemoryStream())
                {
                    rtb.SaveFile(stream, RichTextBoxStreamType.RichText);
                    return stream.ToArray();
                }
            }
        }
    }
}
