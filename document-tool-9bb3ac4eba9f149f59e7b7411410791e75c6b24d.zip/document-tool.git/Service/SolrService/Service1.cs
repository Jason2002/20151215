﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace SolrService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                ProcessStartInfo processInfo = new ProcessStartInfo("startup.bat");
                processInfo.WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory;
                processInfo.WindowStyle = ProcessWindowStyle.Hidden;

                Process p = new Process();
                p.EnableRaisingEvents = true;
                p.StartInfo = processInfo;
                p.Start();
            }
            catch
            {
                throw;
            }
        }

        protected override void OnStop()
        {
            try
            {
                ProcessStartInfo processInfo = new ProcessStartInfo("shutdown.bat");
                processInfo.WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory;
                processInfo.WindowStyle = ProcessWindowStyle.Hidden;

                Process p = new Process();
                p.EnableRaisingEvents = true;
                p.StartInfo = processInfo;
                p.Start();
            }
            catch
            {
                throw;
            }
        }
    }
}
