﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentTool.Jobs;

using Newegg.Oversea.Framework.JobConsole.Client;
using DocumentToolJob;

namespace JobConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                JobContext context = new JobContext();

                Console.WriteLine(DateTime.Now.ToString() + ":start indexing document...");
                DocumentJob job = new DocumentJob();
                job.Run(context);
                if (!string.IsNullOrWhiteSpace(context.Message))
                {
                    Console.WriteLine(context.Message);
                }
                Console.WriteLine(DateTime.Now.ToString() + ":indexing document ok");

                Console.WriteLine(DateTime.Now.ToString() + ":start indexing attachment...");
                AttachmentJob job_att = new AttachmentJob();
                job_att.Run(context);
                if (!string.IsNullOrWhiteSpace(context.Message))
                {
                    Console.WriteLine(context.Message);
                }
                Console.WriteLine(DateTime.Now.ToString() + ":indexing attachment ok");

                Console.WriteLine("please press any key to exit");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadKey();
            }
        }
    }
}
