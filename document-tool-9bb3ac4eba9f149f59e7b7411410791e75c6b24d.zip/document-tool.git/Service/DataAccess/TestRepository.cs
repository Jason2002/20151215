﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace DataAccess
//{
//    public class TestRepository
//    {

//        public TestRepository()
//        {
            
//        }

//        public void TestAddCategory()
//        {
//            Categories category = new Categories();

//            category.Status = "A";
//            category.CategoryName = "Newegg RMA";
//            category.EditDate = DateTime.Now;
//            category.EditUser = "jy25";
//            category.IsRootShowPublic = true;
//            category.IsAuthEdit = true;
//            category.IsAuthShow = false;

//            List<RootRoles> roles = new List<RootRoles>();
//            roles.Add(new RootRoles { EditUser = category.EditUser, EditDate = category.EditDate, Type = "R", KeystoneName = category.CategoryName.Replace(" ", "_") + "_RootView" });
//            roles.Add(new RootRoles { EditUser = category.EditUser, EditDate = category.EditDate, Type = "V", KeystoneName = category.CategoryName.Replace(" ", "_") + "_ViewDocument" });
//            roles.Add(new RootRoles { EditUser = category.EditUser, EditDate = category.EditDate, Type = "E", KeystoneName = category.CategoryName.Replace(" ", "_") + "_EditDocument" });


//            using (DocumentToolEntities context= new DocumentToolEntities())
//            {
//                CategoryRepository repository = new CategoryRepository(context);
//                //repository.AddRootCategory(category, roles);

//                //repository.Save();
//            }
//        }

//        public void TestGetRootCategory()
//        {
//            using (DocumentToolEntities context = new DocumentToolEntities())
//            {
//                CategoryRepository repository = new CategoryRepository(context);
//                //IEnumerable<Categories> results = repository.GetRootCategories();

//                //int count = results.Count();
//            }
//        }
//    }
//}
