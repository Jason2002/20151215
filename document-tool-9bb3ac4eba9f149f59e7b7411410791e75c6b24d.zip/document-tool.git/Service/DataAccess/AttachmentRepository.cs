﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.EntityClient;
using System.Data.SqlClient;

namespace DataAccess
{
    public class AttachmentRepository : RepositoryBase
    {
        public AttachmentRepository(DocumentToolEntities context)
            : base(context)
        {

        }

        public void AddAttachment(AttachmentInfo att)
        {
            m_context.AttachmentInfo.AddObject(att);
        }

        public void AddAttachmentDocument(AttachmentDocument ad)
        {
            m_context.AttachmentDocument.AddObject(ad);
        }

        public IEnumerable<AttachmentInfo> GetAttachmentsWithoutIndex()
        {
            return m_context.AttachmentInfo.Where(a => a.GenerateFlag == false).ToList();
        }

        public void UpdateFlagAttachment(int attachmentId)
        {
            AttachmentInfo att = FindAttachmentById(attachmentId);
            if (att == null) return;
            att.GenerateFlag = true;
        }

        public AttachmentInfo FindAttachmentById(int attachmentId)
        {
            AttachmentInfo att = m_context.AttachmentInfo.Where(a => a.AttachmentId == attachmentId).FirstOrDefault();
            //if (att == null)
            //{
            //    throw new ApplicationException("Attachment does not exists.");
            //}
            return att;
        }

        public AttachmentInfo FindAttachmentByHash(string hashCode, string fileName)
        {
            AttachmentInfo att = m_context.AttachmentInfo.Where(a => a.HashCode == hashCode 
                && a.FileName.Trim() == fileName.Trim()).FirstOrDefault();
            //if (att == null)
            //{
            //    throw new ApplicationException("Attachment does not exists.");
            //}
            return att;
        }

        public List<AttSearchResult> FindActiveDocumentByAttIds(List<int> attachmentIds)
        {
            //注意附件搜索和文档搜索不同，文档修改后每次都会更新solr，而附件只会上传一次，
            //因此solr中保存的documentId可能是已作废版本的，需要找出对应的category的最新的docuemntId.
            //这里不考虑文档修改过程中去掉附件链接的情况

            string sql = @"
                DECLARE @inputText VARCHAR(2000) 
                DECLARE @sep VARCHAR(5) 

                SET @inputText = @attachmentIds
                SET @sep = ',' 

                DECLARE @tbParseResult TABLE 
                  ( 
                     Id    INT IDENTITY(1, 1), 
                     Value NVARCHAR(100) 
                  ) 
                DECLARE @i INT 

                SET @i = 1 

                WHILE ( CHARINDEX(@sep, @inputText) > 0 ) 
                  BEGIN 
                      INSERT INTO @tbParseResult 
                                  (Value) 
                      SELECT LTRIM(RTRIM(SUBSTRING(@inputText, 1, CHARINDEX(@sep, @inputText) - 1))) 

                      SET @inputText = SUBSTRING(@inputText, CHARINDEX(@sep, @inputText) + 1, LEN(@inputText)) 
                      SET @i = @i + 1 
                  END 

                INSERT INTO @tbParseResult 
                            (Value) 
                SELECT LTRIM(RTRIM(@inputText)) 

                DELETE FROM @tbParseResult 
                WHERE  LEN(Value) = 0 

                SELECT DISTINCT d2.[DocumentId]                     AS [DocumentId], 
                                d2.[CateogryId]                     AS [CateogryId], 
                                c.[CategoryName] + '$' + a.FileName AS [CategoryName], 
                                a.DownloadUrl
                FROM   @tbParseResult AS p 
                       INNER JOIN dbo.AttachmentInfo AS a WITH(nolock) 
                               ON p.[Value] = a.[AttachmentId] 
                       INNER JOIN dbo.AttachmentDocument AS ad WITH(nolock) 
                               ON a.[AttachmentId] = ad.[AttachmentId] 
                       INNER JOIN dbo.DocumentInfo AS d1 WITH(nolock) 
                               ON ad.[DocumentId] = d1.[DocumentId] 
                       INNER JOIN dbo.Categories AS c WITH(nolock) 
                               ON d1.CateogryId = c.CategoryId 
                       INNER JOIN dbo.DocumentInfo AS d2 WITH(nolock) 
                               ON c.CategoryId = d2.CateogryId 
                WHERE  d2.[Status] = 'A'   
                ";

            List<AttSearchResult> list = new List<AttSearchResult>();
            using (SqlConnection connection = ((EntityConnection)m_context.Connection).StoreConnection as SqlConnection)
            {
                if (connection.State != System.Data.ConnectionState.Open)
                    connection.Open();

                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@attachmentIds", string.Join(",", attachmentIds));
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        AttSearchResult asr = new AttSearchResult();
                        asr.Document = new DocumentInfo();
                        asr.Document.DocumentId = Convert.ToInt32(reader["DocumentId"]);
                        asr.Document.Categories = new Categories();
                        asr.Document.Categories.CategoryId = Convert.ToInt32(reader["CateogryId"]);
                        asr.Document.Categories.CategoryName = reader["CategoryName"].ToString();
                        asr.DownloadUrl = reader["DownloadUrl"].ToString();
                        list.Add(asr);
                    }
                }

                connection.Close();
            }

            if (list.Count == 0) return null;
            return list;
        }
    }

    public class AttSearchResult
    {
        public DocumentInfo Document { get; set; }

        public string DownloadUrl { get; set; }
    }
}
