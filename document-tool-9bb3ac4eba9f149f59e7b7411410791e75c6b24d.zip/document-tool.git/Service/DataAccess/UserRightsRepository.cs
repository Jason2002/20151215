﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class UserRightsRepository : RepositoryBase
    {
        public UserRightsRepository(DocumentToolEntities context)
            : base(context)
        { }

        //public List<UserRights> GetUserRights(string uid)
        //{
        //    var results = m_context.UserRights.Where(ur => ur.UserID.Equals(uid, StringComparison.InvariantCultureIgnoreCase));
        //    if (results.Count() > 0)
        //    {
        //        return results.ToList();
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}

        //private UserRights GetUserRight(string uid, int rootID)
        //{
        //    var result = m_context.UserRights.FirstOrDefault(ur => ur.UserID == uid && ur.RootID == rootID);
        //    return result;
        //}

        public void DeleteExistsRight(string uid, List<UserRights> newRights)
        {
            var results = m_context.UserRights.Where(ur => ur.UserID == uid);
            if (results.Count() > 0)
            {
                results.ToList().ForEach(ur =>
                    {
                        var exists = newRights.FirstOrDefault(nr => nr.RootID == ur.RootID);
                        if (exists != null)
                        {
                            m_context.UserRights.DeleteObject(ur);
                        }
                    });
            }
        }

        public void AddUserRights(List<UserRights> urRights)
        {
            urRights.ForEach(ur =>
                {
                    m_context.UserRights.AddObject(ur);
                });
        }
    }
}
