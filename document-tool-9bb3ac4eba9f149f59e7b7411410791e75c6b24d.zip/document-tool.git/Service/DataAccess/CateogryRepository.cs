﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace DataAccess
{
    public class CategoryRepository : RepositoryBase
    {
        public CategoryRepository(DocumentToolEntities context)
            : base(context)
        {

        }

        public Categories FindCategoryById(int categoryId)
        {
            Categories category = m_context.Categories.Where(c => c.CategoryId == categoryId).FirstOrDefault();
            if (category == null)
            {
                throw new Exception("Category does not exists");
            }
            return category;
        }
    }

    public partial class Categories
    {
        public List<Categories> SubCategories { get; set; }
        public bool AuthEditResult { get; set; }
        public bool AuthViewResult { get; set; }
    }
}
