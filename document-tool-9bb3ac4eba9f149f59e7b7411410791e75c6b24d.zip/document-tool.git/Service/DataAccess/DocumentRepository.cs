﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.EntityClient;

namespace DataAccess
{
    public class DocumentRepository : RepositoryBase
    {
        public DocumentRepository(DocumentToolEntities context)
            : base(context)
        {
        }

        public void VoidDocument(int documentId)
        {
            DocumentInfo doc = FindDocumentById(documentId);
            doc.Status = "V";
        }

        public void UpdateFlagDocument(int documentId)
        {
            DocumentInfo doc = FindDocumentById(documentId);
            doc.GenerateFlag = true;
        }

        public DocumentInfo FindDocumentById(int documentId)
        {
            DocumentInfo doc = m_context.DocumentInfo.Include("DocumentContent").Where(d => d.DocumentId == documentId).FirstOrDefault();
            if (doc == null)
            {
                throw new Exception("Document does not exists.");
            }
            return doc;
        }

        public DocumentInfo FindActiveDocumentById(int documentId)
        {
            DocumentInfo doc = m_context.DocumentInfo.Include("Categories").Where(d => d.DocumentId == documentId && d.Status.Equals("A", StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();

            return doc;
        }

        public List<DocumentInfo> FindActiveDocumentByIds(List<int> documentIds)
        {
            string sql = @"
                DECLARE @inputText VARCHAR(2000) 
                DECLARE @sep VARCHAR(5) 

                SET @inputText = @documentIds
                SET @sep = ',' 

                DECLARE @tbParseResult TABLE 
                  ( 
                     Id    INT IDENTITY(1, 1), 
                     Value NVARCHAR(100) 
                  ) 
                DECLARE @i INT 

                SET @i = 1 

                WHILE ( CHARINDEX(@sep, @inputText) > 0 ) 
                  BEGIN 
                      INSERT INTO @tbParseResult 
                                  (Value) 
                      SELECT LTRIM(RTRIM(SUBSTRING(@inputText, 1, CHARINDEX(@sep, @inputText) - 1))) 

                      SET @inputText = SUBSTRING(@inputText, CHARINDEX(@sep, @inputText) + 1, LEN(@inputText)) 
                      SET @i = @i + 1 
                  END 

                INSERT INTO @tbParseResult 
                            (Value) 
                SELECT LTRIM(RTRIM(@inputText)) 

                DELETE FROM @tbParseResult 
                WHERE  LEN(Value) = 0 

                SELECT d.[DocumentId]   AS [DocumentId], 
                       d.[CateogryId]   AS [CateogryId], 
                       c.[CategoryName] AS [CategoryName] 
                FROM   [dbo].[documentinfo] AS d WITH(nolock) 
                       INNER JOIN @tbParseResult AS p 
                               ON p.[Value] = d.[DocumentId] 
                       INNER JOIN [dbo].[categories] AS c WITH(nolock) 
                               ON d.[CateogryId] = c.[CategoryId] 
                WHERE  d.[Status] = 'A'  
                ";

            List<DocumentInfo> list = new List<DocumentInfo>();
            using (SqlConnection connection = ((EntityConnection)m_context.Connection).StoreConnection as SqlConnection)
            {
                if (connection.State != System.Data.ConnectionState.Open)
                    connection.Open(); 

                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@documentIds", string.Join(",", documentIds));
                using (var reader = command.ExecuteReader()) 
                {
                    while (reader.Read()) 
                    {
                        DocumentInfo document = new DocumentInfo();
                        document.DocumentId = Convert.ToInt32(reader["DocumentId"]);
                        document.Categories = new Categories();
                        document.Categories.CategoryId = Convert.ToInt32(reader["CateogryId"]);
                        document.Categories.CategoryName = reader["CategoryName"].ToString();
                        list.Add(document);
                    } 
                }

                connection.Close(); 
            }

            if (list.Count == 0) return null;
            return list;
        }

        public void AddDocumentInfo(int categoryID, DocumentInfo doc, DocumentContent content)
        {
            CategoryRepository cr = new CategoryRepository(m_context);
            Categories category = cr.FindCategoryById(categoryID);

            doc.Categories = category;
            m_context.DocumentInfo.AddObject(doc);
            content.DocumentInfo = doc;
            m_context.DocumentContent.AddObject(content);
        }

        public void DeleteDocument(int categoryId)
        {
            List<DocumentInfo> documents = GetHistoryDocuments(categoryId);
            foreach (var item in documents)
            {
                this.VoidDocument(item.DocumentId);
            }
        }

        public List<DocumentInfo> GetHistoryDocuments(int categoryId)
        {
            return m_context.DocumentInfo.Where(d => d.Categories.CategoryId == categoryId).ToList();
        }

        public DocumentInfo GetDocuments(int categoryId)
        {
            return m_context.DocumentInfo.Include("DocumentContent").Where(d => d.Categories.CategoryId == categoryId && d.Status == "A").FirstOrDefault();
        }

        public DocumentInfo GetDocumentById(int documentId)
        {
            return m_context.DocumentInfo.Include("DocumentContent").Where(d => d.DocumentId == documentId).FirstOrDefault();
        }

        public DocumentInfo GetDocumentsWithoutContent(int categoryId)
        {
            var document_thin = (from d in m_context.DocumentInfo
                                 join c in m_context.DocumentContent
                                 on d.DocumentId equals c.DocumentId
                                 where d.CateogryId == categoryId
                                 && d.Status == "A"
                                 select new
                                 {
                                     DocumentId = d.DocumentId,
                                     Status = d.Status,
                                     Version = d.Version,
                                     DocumentKeywords = c.DocumentKeywords
                                 }).FirstOrDefault();
            if (document_thin == null) return null;

            DocumentInfo documentInfo = new DocumentInfo();
            documentInfo.DocumentId = document_thin.DocumentId;
            documentInfo.Status = document_thin.Status;
            documentInfo.Version = document_thin.Version;
            documentInfo.DocumentContent = new DocumentContent()
            {
                DocumentKeywords = document_thin.DocumentKeywords
            };

            return documentInfo;
        }

        public IEnumerable<DocumentInfo> GetDocumentsWithoutIndex()
        {
            return m_context.DocumentInfo.Include("DocumentContent").Where(d => d.GenerateFlag == false).ToList();
        }

        public IEnumerable<DocumentInfo> GetDocumentsWithoutIndex(int topNumber)
        {
            return m_context.DocumentInfo.Include("DocumentContent")
                .Where(d => d.GenerateFlag == false)
                .OrderBy(d => d.EditDate)
                .Take(topNumber)
                .ToList();
        }

        public List<DocumentInfo> GetLatestUpdateDocument(int count)
        {
            List<DocumentInfo> list = m_context.DocumentInfo.Include("Categories").Where(d => d.Status == "A").OrderByDescending(d => d.EditDate).Take(count).ToList();

            return list;
        }

        /// <summary>
        /// 依据一组documentId(包括作废版本)获取对应的最新的documentId
        /// </summary>
        /// <param name="documentIds"></param>
        /// <returns></returns>
        public List<int> GetLatestDocumentIds(List<int> documentIds)
        {
            string sql = @"
                DECLARE @inputText VARCHAR(2000) 
                DECLARE @sep VARCHAR(5) 

                SET @inputText = @documentIds
                SET @sep = ',' 

                DECLARE @tbParseResult TABLE 
                  ( 
                     Id    INT IDENTITY(1, 1), 
                     Value NVARCHAR(100) 
                  ) 
                DECLARE @i INT 

                SET @i = 1 

                WHILE ( CHARINDEX(@sep, @inputText) > 0 ) 
                  BEGIN 
                      INSERT INTO @tbParseResult 
                                  (Value) 
                      SELECT LTRIM(RTRIM(SUBSTRING(@inputText, 1, CHARINDEX(@sep, @inputText) - 1))) 

                      SET @inputText = SUBSTRING(@inputText, CHARINDEX(@sep, @inputText) + 1, LEN(@inputText)) 
                      SET @i = @i + 1 
                  END 

                INSERT INTO @tbParseResult 
                            (Value) 
                SELECT LTRIM(RTRIM(@inputText)) 

                DELETE FROM @tbParseResult 
                WHERE  LEN(Value) = 0 

                SELECT DISTINCT d2.[DocumentId] 
                FROM   @tbParseResult AS p 
                       INNER JOIN dbo.documentinfo AS d1 WITH(nolock) 
                               ON p.[Value] = d1.[DocumentId] 
                       INNER JOIN dbo.categories AS c WITH(nolock) 
                               ON d1.CateogryId = c.CategoryId 
                       INNER JOIN dbo.documentinfo AS d2 WITH(nolock) 
                               ON c.CategoryId = d2.CateogryId 
                WHERE  d2.[Status] = 'A'  
                ";

            List<int> list = new List<int>();
            using (SqlConnection connection = ((EntityConnection)m_context.Connection).StoreConnection as SqlConnection)
            {
                if (connection.State != System.Data.ConnectionState.Open)
                    connection.Open();

                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@documentIds", string.Join(",", documentIds));
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(Convert.ToInt32(reader["DocumentId"]));
                    }
                }

                connection.Close();
            }

            if (list.Count == 0) return null;
            return list;
        }
    }
}
