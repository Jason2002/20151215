﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class FavoriteRepository : RepositoryBase
    {
        public FavoriteRepository(DocumentToolEntities context)
            : base(context)
        {

        }

        public void AddFavorite(FavoriteInfo fi)
        {
            if (m_context.FavoriteInfo.Where(f => f.Name == fi.Name).Count() > 0) return;

            m_context.FavoriteInfo.AddObject(fi);
        }

        public void DeleteFavorite(int id)
        {
            var results = m_context.FavoriteInfo.Where(f => f.TransactionNumber == id);
            if (results.Count() > 0)
            {
                foreach (var fav in results)
                {
                    m_context.FavoriteInfo.DeleteObject(fav);
                }
            }
        }

        public List<FavoriteInfo> GetFavorites(string userID)
        {
            return m_context.FavoriteInfo.Where(f => f.UserID == userID).ToList();
        }

        public List<Categories> GetFavoritesAsCat(string userID)
        {
            return (from favorites in m_context.FavoriteInfo
                   join category in m_context.Categories on favorites.CategoryId equals category.CategoryId
                   where favorites.UserID == userID  && category.Status ==  "A"
                   select category).ToList();
        }
    }
}
