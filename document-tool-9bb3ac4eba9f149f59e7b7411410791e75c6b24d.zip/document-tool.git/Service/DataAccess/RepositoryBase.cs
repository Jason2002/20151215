﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class RepositoryBase
    {
        protected DocumentToolEntities m_context;

        public RepositoryBase(DocumentToolEntities context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }
            m_context = context;
        }

        public void Save()
        {
            m_context.SaveChanges();
        }
    }
}
