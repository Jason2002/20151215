﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class LogRepository : RepositoryBase
    {
        public LogRepository(DocumentToolEntities context)
            : base(context)
        { }

        public List<LogMessage> GetRecentlyLog(int lastLogID)
        {
            if (lastLogID == 0)
            {
                var result = m_context.LogMessage.OrderByDescending(l => l.TransactionNumber).FirstOrDefault();
                if (result != null)
                {
                    var found = new List<LogMessage>();
                    found.Add(result);
                    return found;
                }
            }
            else
            {
                var result = m_context.LogMessage.Where(l => l.TransactionNumber > lastLogID);
                if (result.Count() > 0)
                {
                    return result.ToList();
                }
            }

            return new List<LogMessage>();

        }

        public void AddNewLog(LogMessage log)
        {
            m_context.LogMessage.AddObject(log);
        }
    }
}
