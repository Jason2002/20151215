﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.Text;
using System.Windows.Forms;
using BusinessProcess.BusinessRule;
using BusinessProcess.ServiceImp;
using BusinessProcess.Utilities;
using DevExpress.XtraRichEdit;
using Microsoft.Exchange.WebServices.Data;
using Newegg.Oversea.Framework.JobConsole.Client;
using ServiceDefinetion;

namespace DocumentToolJob
{
    public class MailSortingJob : IJobAction
    {
        string emailAddress = "zeeman.z.huang@newegg.com";
        string userName = "zh61";
        string password = "***";
        string domain = "abs_corp";

        public void Run(JobContext context)
        {
            MailGetter mg = new MailGetter();
            mg.OpenAccount(emailAddress, domain, userName, password);
            var mailList = mg.GetMails();
            if (mailList == null || mailList.Count == 0) return;

            DocumentService documentService = new DocumentService();
            AttachmentService attachmentService = new AttachmentService();
            foreach (var mail in mailList)
            {
                //mail.Body.BodyType==BodyType.HTML

                if (!mail.Subject.StartsWith("WeeklyReport", StringComparison.InvariantCultureIgnoreCase)) continue;

                //抽取标题和Tag
                int startTagIndex = mail.Subject.IndexOf('(');
                int endTagIndex = mail.Subject.IndexOf(')');
                if (startTagIndex == -1 || endTagIndex == -1) continue;

                byte[] buffer = GetDocumentContent(mail.Body.Text);
                if (buffer == null) continue;

                DocumentEntity document = new DocumentEntity();
                document.Status = "A";
                document.DocumentId = null;
                using (MemoryStream stream = new MemoryStream(buffer))
                {
                    document.DocumentContent = CompressHelper.CompressContent(stream);
                }
                document.EditUser = "[Job]";
                document.EditDate = DateTime.Now;               

                string subject = mail.Subject.Substring(0, startTagIndex);
                string tag = mail.Subject.Substring(startTagIndex + 1, endTagIndex - startTagIndex - 1);

                var categoryId = GetCategory(subject);

                //TODO: 添加附件链接

                //保存邮件正文
                document.DocumentKeywords = tag;
                documentService.ModifyDocument(categoryId, document);

                //保存邮件附件
                if (mail.HasAttachments)
                {
                    foreach (var att in mail.Attachments)
                    {
                        if (att is FileAttachment)
                        {
                            using (MemoryStream ms = new MemoryStream())
                            {
                                (att as FileAttachment).Load(ms);
                                string downloadUrl = UploadAttachment(att.Name, ms.ToArray());
                                attachmentService.ConvertToFlash(categoryId, downloadUrl);
                            }
                        }
                    }
                }

                //break;
            }
        }

        public int GetCategory(string categoryPath)
        {
            //(info)WeeklyReport_NESC_CD_20130924

            //categoryPath = "WeeklyReport_NESC_CD_20130926(WeeklyReport_20130926,CD)";
            int categoryId = 0;//WeeklyReport_NESC_CD_20130901

            string[] pathes = categoryPath.Split('_');

            //因为服务端有缓存，所以直接调用WCF服务更新
            CategoryServiceProxy categoryServiceProxy = new CategoryServiceProxy();

            int? parentId = null;
            foreach (var categoryName in pathes)
            {
                var entity = new CategoryEntity();
                entity.CategoryName = categoryName;
                entity.ParentId = parentId;
                entity.EditUser = "[Job]";
                entity.EditDate = DateTime.Now;
                entity.Status = "A";
                entity = categoryServiceProxy.AddNewIfNotExists(entity);

                parentId = entity.CategoryId;
                categoryId = entity.CategoryId.Value;
            }

            return categoryId;
        }

        public string UploadAttachment(string attfileName, byte[] att_buffer)
        {
            string downloadUrl = string.Empty;

            //通过Hash比较附件已存在则不用上传
            string hashCode = HashHelper.SHA1File(att_buffer);

            AttachmentService attachmentService = new AttachmentService();
            AttachmentEntity att = attachmentService.FindAttachmentByHash(hashCode, attfileName);
            if (att == null)
            {
                //上传附件
                downloadUrl = DfisBLL.UploadAttachment(attfileName, att_buffer);

                att = new AttachmentEntity();
                att.FileName = attfileName;
                att.DownloadUrl = downloadUrl;
                att.HashCode = hashCode;
                att.EditUser = Environment.UserName;
                att.EditDate = DateTime.Now;
                att.GenerateFlag = false;
            }
            else
            {
                downloadUrl = att.DownloadUrl;

                AttachmentDocumentEntity ad = new AttachmentDocumentEntity();
                ad.AttachmentId = att.AttachmentId;
                ad.EditUser = Environment.UserName;
                ad.EditDate = DateTime.Now;
            }

            return downloadUrl;
        }

        public byte[] GetDocumentContent(string body)
        {
            using (RichEditControl rtb = new RichEditControl())
            {
                WebBrowser wb = new WebBrowser();

                wb.Navigate("about:blank");
                wb.Document.Write(body);

                wb.Document.ExecCommand("SelectAll", false, null);
                wb.Document.ExecCommand("Copy", false, null);

                rtb.SelectAll();
                rtb.Paste();

                using (MemoryStream stream = new MemoryStream())
                {
                    //rtb.SaveFile(stream, RichTextBoxStreamType.RichText);
                    rtb.SaveDocument(stream, DocumentFormat.Rtf);
                    return stream.ToArray();
                }
            }
        }

    }

    public partial class CategoryServiceProxy : ClientBase<ICategoryService>, ICategoryService
    {
        public CategoryEntity AddNewIfNotExists(CategoryEntity entity)
        {
            return Channel.AddNewIfNotExists(entity);
        }

        public IEnumerable<CategoryEntity> GetCategoryTree(string uid)
        {
            throw new NotImplementedException();
        }

        public void ModifyCategory(CategoryEntity category)
        {
            throw new NotImplementedException();
        }

        public void UpdateCategoryParent(int parentId, int categoryId, string userName)
        {
            throw new NotImplementedException();
        }

        public void DeleteCategory(int categoryId, string userName)
        {
            throw new NotImplementedException();
        }
    }

}
