﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess;
using System.IO;

namespace DocumentToolJob.Logic
{
    public class DocumentBLL
    {
        public IEnumerable<DocumentInfo> GetDocumentsWithoutIndex(int topNumber)
        {
            using (DocumentToolEntities context = new DocumentToolEntities())
            {
                DocumentRepository rep = new DocumentRepository(context);
                return rep.GetDocumentsWithoutIndex(topNumber).ToList();
            }
        }

        public void UpdateDocumentAfterGenerateIndex(int documentId)
        {
            using (DocumentToolEntities context = new DocumentToolEntities())
            {
                DocumentRepository rep = new DocumentRepository(context);
                rep.UpdateFlagDocument(documentId);
                rep.Save();
            }
        }

        public string ConvertToString(string source)
        {
            byte[] buffer = Convert.FromBase64String(source);
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            using (System.IO.MemoryStream content = new MemoryStream())
            {
                ms.Write(buffer, 0, buffer.Length);
                ms.Position = 0;
                using (System.IO.Compression.DeflateStream stream = new System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Decompress))
                {
                    stream.Flush();

                    int nSize = 3 * 1024 * 1024;
                    byte[] decompressBuffer = new byte[nSize];
                    int readTimes = 1;
                    int nSizeIncept;
                    while ((nSizeIncept = stream.Read(decompressBuffer, 0, nSize)) != 0 || readTimes < 3)
                    {
                        readTimes++;
                        if (nSizeIncept == 0)
                        {
                            continue;
                        }
                        content.Write(decompressBuffer, 0, nSizeIncept);
                    }
                }
                content.Position = 0;
                System.Windows.Forms.RichTextBox rtb = new System.Windows.Forms.RichTextBox();
                rtb.LoadFile(content, System.Windows.Forms.RichTextBoxStreamType.RichText);
                return rtb.Text;
            }
        }
    }
}
