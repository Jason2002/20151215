﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SolrNet;
using System.IO;
using DataAccess;
using System.Net;

namespace DocumentToolJob.Logic
{
    public class AttachmentBLL
    {
        private static WebClient _webClient = new WebClient();

        /// <summary>
        /// 获取附件列表信息
        /// </summary>
        /// <returns></returns>
        public List<AttachmentInfo> GetAttachmentsWithoutIndex()
        {
            using (DocumentToolEntities context = new DocumentToolEntities())
            {
                AttachmentRepository rep = new AttachmentRepository(context);
                return rep.GetAttachmentsWithoutIndex().ToList();
            }
        }

        /// <summary>
        /// 更新索引标志
        /// </summary>
        /// <param name="attachmentId"></param>
        public void UpdateDocumentAfterGenerateIndex(int attachmentId)
        {
            using (DocumentToolEntities context = new DocumentToolEntities())
            {
                AttachmentRepository rep = new AttachmentRepository(context);
                rep.UpdateFlagAttachment(attachmentId);
                rep.Save();
            }
        }

        /// <summary>
        /// 从DFIS下载文件并导入Solr
        /// </summary>
        /// <param name="solr"></param>
        /// <param name="att"></param>
        public void AddFile(ISolrOperations<AttachmentInfo> solr, AttachmentInfo att)
        {
            byte[] buffer = _webClient.DownloadData(att.DownloadUrl);
            using (Stream stream = new MemoryStream(buffer))
            {
                var response = solr.Extract(new ExtractParameters(stream, att.AttachmentId.ToString(), att.FileName)
                {
                    ExtractFormat = ExtractFormat.Text,
                    ExtractOnly = false,
                    Fields = new[] 
                    { 
                        //new ExtractField("docid", att.DocumentId.ToString()), 
                        new ExtractField("filename", att.FileName), 
                        new ExtractField("url", att.DownloadUrl),
                        new ExtractField("filetype", Path.GetExtension(att.FileName)),
                        new ExtractField("edituser", att.EditUser),
                        new ExtractField("editdate", att.EditDate.ToString("yyyy-MM-dd HH:mm:ss"))
                    }
                });
            }
        }
    }
}
