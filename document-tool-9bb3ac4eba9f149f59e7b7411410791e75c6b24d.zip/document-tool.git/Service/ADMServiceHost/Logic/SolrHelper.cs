﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess;
using SolrNet;
using System.Configuration;
using Microsoft.Practices.ServiceLocation;

namespace DocumentToolJob.Logic
{
    public class SolrHelper
    {
        private static ISolrOperations<AttachmentInfo> attachmentInstance;

        static SolrHelper()
        {
            Startup.Init<AttachmentInfo>(ConfigurationManager.AppSettings["AttachmentSolrUrl"]);
        }

        public static ISolrOperations<AttachmentInfo> AttachmentInstance
        {
            get
            {
                if (attachmentInstance == null)
                {
                    attachmentInstance = ServiceLocator.Current.GetInstance<ISolrOperations<AttachmentInfo>>();
                    return attachmentInstance;
                }
                else
                {
                    return attachmentInstance;
                }
            }
        }
    }
}
