﻿using System;
using System.Collections.Generic;
using ServiceDefinetion;
using System.Threading;
using Newegg.Oversea.Framework.JobConsole.Client;
using System.ServiceModel;

namespace DocumentToolJob
{
    public class AutoGenerateIndexFiles : IJobAction
    {
        public void Run(JobContext context)
        {
            IndexServiceProxy client = new IndexServiceProxy();
            client.GenerateDocumentIndex();
        }
    }

    public partial class IndexServiceProxy : ClientBase<IIndexService>, IIndexService
    {
        public void GenerateDocumentIndex()
        {
            Channel.GenerateDocumentIndex();
        }
    }

}
