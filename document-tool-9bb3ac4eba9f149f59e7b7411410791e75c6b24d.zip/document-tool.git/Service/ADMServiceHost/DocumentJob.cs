﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Oversea.Framework.JobConsole.Client;
using System.Configuration;
using DataAccess;
using SolrNet;
using Microsoft.Practices.ServiceLocation;
using DocumentToolJob.Logic;
using System.Text.RegularExpressions;
using SolrNet.Attributes;
using System.Threading.Tasks;

namespace DocumentToolJob
{
    public class DocumentJob : IJobAction
    {
        private static bool _isFirstLoad = true;

        public void Run(JobContext context)
        {
            if (_isFirstLoad)
            {
                Startup.Init<DocumentSolrInfo>(ConfigurationManager.AppSettings["DocumentSolrUrl"]);
                _isFirstLoad = false;
            }

            DocumentBLL documentBLL = new DocumentBLL();

            int topNumber = 20;
            IEnumerable<DocumentInfo> docs = null;
            Regex regex = new Regex(@"[\x00-\x08]|[\x0b-\x0c]|[\x0e-\x1f]");
            var solr = ServiceLocator.Current.GetInstance<ISolrOperations<DocumentSolrInfo>>();
            while (true)
            {
                //获取数据
                docs = documentBLL.GetDocumentsWithoutIndex(topNumber);
                if (docs.Count() == 0) break;

                foreach (var doc in docs)
                //Parallel.ForEach(docs, doc =>
                {
                    if (doc.DocumentContent != null
                        && !string.IsNullOrWhiteSpace(doc.DocumentContent.DocumentText))
                    {
                        string content = documentBLL.ConvertToString(doc.DocumentContent.DocumentText);
                        if (!string.IsNullOrWhiteSpace(content))
                        {

                            //替换特殊符号
                            content = regex.Replace(content, "");
                            content = content.Replace("<", "&lt;").Replace("&", "&amp;")
                                .Replace("<![CDATA[", "CDATA[[")
                                .Replace("]]>", "]] ");

                            //加入Solr
                            DocumentSolrInfo docSolr = new DocumentSolrInfo();
                            docSolr.DocumentId = doc.DocumentId;
                            docSolr.DocumentText = content;
                            solr.Add(docSolr);
                        }
                    }

                    //更新状态
                    documentBLL.UpdateDocumentAfterGenerateIndex(doc.DocumentId);
                }
                //);

                solr.Commit();

                Console.WriteLine(DateTime.Now.ToString() + ":indexing documents:" + docs.Count().ToString());
            }
            
        }

        public class DocumentSolrInfo
        {
            [SolrField("id")]
            public int DocumentId { get; set; }

            [SolrField("text")]
            public string DocumentText { get; set; }
        }
    }
}
