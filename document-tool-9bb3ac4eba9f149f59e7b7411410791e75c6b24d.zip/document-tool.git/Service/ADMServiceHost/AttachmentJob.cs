﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Oversea.Framework.JobConsole.Client;
using System.Configuration;
using DataAccess;
using SolrNet;
using Microsoft.Practices.ServiceLocation;
using DocumentToolJob.Logic;

namespace DocumentTool.Jobs
{
    public class AttachmentJob : IJobAction
    {
        public void Run(JobContext context)
        {

            AttachmentBLL attachmentBLL = new AttachmentBLL();
            var atts = attachmentBLL.GetAttachmentsWithoutIndex();
            if (atts.Count == 0) return;

            var solr = SolrHelper.AttachmentInstance;
            foreach (AttachmentInfo att in atts)
            {
                try
                {
                    attachmentBLL.AddFile(solr, att);
                    attachmentBLL.UpdateDocumentAfterGenerateIndex(att.AttachmentId);
                }
                catch (System.Net.WebException webEx)
                {
                    //防止网络异常被卡住，如果找不到文件，直接更新标志
                    if (((System.Net.HttpWebResponse)(webEx.Response)).StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        attachmentBLL.UpdateDocumentAfterGenerateIndex(att.AttachmentId);
                    }
                    else
                    {
                        context.Message += Environment.NewLine;
                        context.Message += webEx.ToString();
                    }
                }
                catch (Exception ex)
                {
                    context.Message += Environment.NewLine;
                    context.Message += ex.ToString();
                }
            }
            solr.Commit(); 
        }


    }
}
