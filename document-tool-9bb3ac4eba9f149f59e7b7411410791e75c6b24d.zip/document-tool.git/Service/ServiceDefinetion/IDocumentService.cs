﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface IDocumentService
    {
        [OperationContract]
        int ModifyDocument(int categoryId, DocumentEntity document);

        [OperationContract]
        void DeleteDocument(int categoryId);

        [OperationContract]
        DocumentEntity GetDocument(int categoryId);

        [OperationContract]
        DocumentEntity GetDocumentById(int documentId);

        [OperationContract]
        DocumentEntity GetDocumentWithoutContent(int categoryId);

        [OperationContract]
        IEnumerable<DocumentEntity> GetHistoryDocuments(int categoryId);

        [OperationContract]
        IEnumerable<DocumentEntity> SearchDocuments(string keywords);

        [OperationContract]
        int GetCategoryIdByDocumentId(int documentId);

        [OperationContract]
        IEnumerable<DocumentEntity> GetLatestUpdateDocument(int count);
    }
}
