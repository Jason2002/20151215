﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface IUserService
    {
        [OperationContract]
        List<UserRightsEntity> GetUserRightsById(string uid);

        [OperationContract]
        UserOperationRights GetUserOperationRightsById(string uid);

        [OperationContract]
        void AddUserRights(List<UserRightsEntity> rights, string uid);
    }
}
