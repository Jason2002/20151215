﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ServiceDefinetion
{
    [Serializable]
    [DataContract(Namespace="http://newegg.com/DocumentManagementTool")]
    public class CategoryEntity
    {
        [DataMember]
        public int? CategoryId { get; set; }

        [DataMember]
        public string CategoryName { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public DateTime EditDate { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public PrivilegeAction? Permission { get; set; }
        
        [DataMember]
        public bool? IsAuthEdit { get; set; }

        [DataMember]
        public bool? IsAuthShow { get; set; }

        [DataMember]
        public bool? IsPrivate { get; set; }

        [DataMember]
        public bool AuthEditResult { get; set; }

        [DataMember]
        public bool AuthViewResult { get; set; }

        [DataMember]
        public int? ParentId { get; set; }

        public CategoryEntity Parent { get; set; }

        [DataMember]
        public List<CategoryEntity> SubCategories { get; set; }

        [DataMember]
        public List<DocumentEntity> Documents { get; set; }
    }

    [Serializable]
    [Flags]
    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public enum PrivilegeAction
    {
        [EnumMember]
        Owner = 1 << 0,

        [EnumMember]
        List = 1 << 1,

        [EnumMember]
        View = 1 << 2,

        [EnumMember]
        Edit = 1 << 3
    }

    [Serializable]
    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class PrivilegeInfo
    {
        [DataMember]
        public int TransactionNumber { get; set; }

        [DataMember]
        public int CategoryID { get; set; }

        [DataMember]
        public string AcctName { get; set; }

        [DataMember]
        public PrivilegeAcctType AcctType { get; set; }

        [DataMember]
        public PrivilegeAction Permission { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public DateTime EditDate { get; set; }
    }

    [Serializable]
    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class CategoryPrivilegeInfo
    {
        [DataMember]
        public int CategoryID { get; set; }

        [DataMember]
        public PrivilegeAction Permission { get; set; }
    }

    [Serializable]
    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public enum PrivilegeAcctType
    {
        [EnumMember]
        User = 1,

        [EnumMember]
        Group = 2
    }

    [DataContract(Namespace="http://newegg.com/DocumentManagementTool")]
    public class DocumentEntity
    {
        [DataMember]
        public int? DocumentId { get; set; }
        
        [DataMember]
        public string DocumentContent { get; set; }

        [DataMember]
        public string SearchName { get; set; }

        [DataMember]
        public string SearchAttUrl { get; set; }

        [DataMember]
        public string DocumentKeywords { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public DateTime EditDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public string Status { get; set; }

        public bool GenerateFlag { get; set; }
    }

    [DataContract(Namespace="http://newegg.com/DocumentManagementTool")]
    public class LogEntity
    {
        [DataMember]
        public int TransactionNumber { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public string LogContent { get; set; }

        [DataMember]
        public string LogType { get; set; }

        [DataMember]
        public System.DateTime LogDate { get; set; }

    }

    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class UserRightsEntity
    {
        [DataMember]
        public int TransactionNumber { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public int RootID { get; set; }

        [DataMember]
        public bool CanView { get; set; }

        [DataMember]
        public bool CanEdit { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public bool IsOwner { get; set; }

        [DataMember]
        public System.DateTime EditDate { get; set; }

    }

    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class UserOperationRights
    {
        [DataMember]
        public bool IsAdmin { get; set; }

        [DataMember]
        public bool IsOwner { get; set; }

        [DataMember]
        public List<int> OwnerCategoryID { get; set; }
    }

    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class AttachmentEntity
    {
        [DataMember]
        public int AttachmentId { get; set; }

        [DataMember]
        public int DocumentId { get; set; }

        [DataMember]
        public string FileName { get; set; }

        [DataMember]
        public string DownloadUrl { get; set; }

        [DataMember]
        public string HashCode { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public DateTime EditDate { get; set; }

        [DataMember]
        public bool GenerateFlag { get; set; }
    }

    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class AttachmentDocumentEntity
    {
        [DataMember]
        public int AttachmentId { get; set; }

        [DataMember]
        public int DocumentId { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public DateTime EditDate { get; set; }
    }

    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class FavoriteEntity
    {
        [DataMember]
        public int TransactionNumber { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public int CategoryId { get; set; }

        [DataMember]
        public string EditUser { get; set; }

        [DataMember]
        public DateTime EditDate { get; set; }
    }

    [Serializable]
    [CollectionDataContract(Name = "Rules", ItemName = "Rule", Namespace = "http://newegg.com/DocumentManagementTool")]
    public class RuleList : List<Rule>
    {

    }

    [Serializable]
    [DataContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public class Rule
    {
        [DataMember]
        public string Section { get; set; }
    }
}
