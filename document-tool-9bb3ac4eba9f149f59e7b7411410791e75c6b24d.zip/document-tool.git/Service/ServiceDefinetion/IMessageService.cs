﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface IMessageService
    {
        [OperationContract]
        string SayHi(string userName);

        [OperationContract]
        void SayGoodbye(string userName);

        [OperationContract]
        List<LogEntity> GetRecentlyLog(int lastID);

    }
}
