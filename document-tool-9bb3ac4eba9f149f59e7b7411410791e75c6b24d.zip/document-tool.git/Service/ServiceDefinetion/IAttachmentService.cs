﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface IAttachmentService
    {
        [OperationContract]
        void AddAttachment(int documentId, AttachmentEntity entity);

        [OperationContract]
        void AddAttachmentDocument(AttachmentDocumentEntity entity);

        [OperationContract]
        AttachmentEntity FindAttachmentByHash(string hashCode, string fileName);
    }
}
