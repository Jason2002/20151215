﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface IFavoriteService
    {
        [OperationContract]
        int AddFavorite(FavoriteEntity favoriteEntity);

        [OperationContract]
        void DeleteFavorite(int id);

        [OperationContract]
        IEnumerable<FavoriteEntity> GetFavorites(string userID);

        [OperationContract]
        IEnumerable<CategoryEntity> GetFavoritesAsCat(string userID);
    }
}
