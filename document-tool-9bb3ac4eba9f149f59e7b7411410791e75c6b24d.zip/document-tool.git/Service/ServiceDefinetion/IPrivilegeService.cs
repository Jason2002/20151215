﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface IPrivilegeService
    {
        [OperationContract]
        void Update(List<PrivilegeInfo> privileges);

        [OperationContract]
        void Delete(PrivilegeAcctType acctType, string acctName);

        [OperationContract]
        List<PrivilegeInfo> GetPrivilegeListByUserSelf(string userID);

        [OperationContract]
        List<PrivilegeInfo> GetPrivilegeListByGroupSelf(string groupNames);

        [OperationContract]
        PrivilegeAcctType? GetAcctType(string acctName);

        [OperationContract]
        List<PrivilegeInfo> GetListByCategoryID(int categoryID);
    }
}
