﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ServiceDefinetion
{
    [ServiceContract(Namespace = "http://newegg.com/DocumentManagementTool")]
    public interface ICategoryService
    {
        [OperationContract]
        IEnumerable<CategoryEntity> GetCategoryTree(string uid);

        [OperationContract]
        void ModifyCategory(CategoryEntity category);

        [OperationContract]
        void UpdateCategoryParent(int parentId, int categoryId, string userName);

        [OperationContract]
        void DeleteCategory(int categoryId, string userName);

        [OperationContract]
        CategoryEntity AddNewIfNotExists(CategoryEntity entity);

        [OperationContract]
        RuleList GetPublishRuleList();
    }
}
