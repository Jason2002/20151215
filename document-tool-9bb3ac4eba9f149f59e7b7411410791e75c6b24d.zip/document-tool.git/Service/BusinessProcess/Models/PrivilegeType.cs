﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessProcess.Models
{
    //[Flags]
    //public enum PrivilegeType
    //{
    //    Owner = 1 << 0,
    //    List = 1 << 1,
    //    View = 1 << 2,
    //    Edit = 1 << 3
    //}
}
