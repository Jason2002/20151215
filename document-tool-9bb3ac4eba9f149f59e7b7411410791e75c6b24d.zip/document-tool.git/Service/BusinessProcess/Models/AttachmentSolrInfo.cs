﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolrNet.Attributes;

namespace BusinessProcess.Models
{
    public class AttachmentSolrInfo
    {
        [SolrField("id")]
        public int AttachmentId { get; set; }

        [SolrField("docid")]
        public int DocumentId { get; set; }

        [SolrField("filename")]
        public string FileName { get; set; }

        [SolrField("url")]
        public string DownloadUrl { get; set; }
    }
}
