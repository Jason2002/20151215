﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessProcess.Models
{
    public class AttachmentDocument
    {
        public int TransactionID { get; set; }

        public int AttachmentId { get; set; }

        public int DocumentId { get; set; }

        public String EditUser { get; set; }

        public DateTime EditDate { get; set; }
    }
}
