﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessProcess.Models
{
    public class DocumentInfo
    {
        public int DocumentId { get; set; }

        public int CateogryId { get; set; }

        public String EditUser { get; set; }

        public DateTime EditDate { get; set; }

        public String Version { get; set; }

        public String Status { get; set; }

        public bool GenerateFlag { get; set; }

        public DocumentContent DocumentContent { get; set; }
    }

    public class DocumentContent
    {
        public int DocumentId { get; set; }

        public String DocumentText { get; set; }

        public String DocumentKeywords { get; set; }
    }
}
