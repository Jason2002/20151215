﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessProcess.Models
{
    public class AdGroupInfo
    {
        public string GroupName { get; set; }
    }
}
