﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessProcess.BusinessRule;
using ServiceDefinetion;

namespace BusinessProcess.UnitTest
{
    public class TestCategory
    {
        public void TestAddCategory()
        {
            CategoryFacade cf = new CategoryFacade();

            CategoryEntity ce = new CategoryEntity();
            ce.CategoryName = "PO3";
            ce.EditDate = DateTime.Now;
            ce.EditUser = "jy25";
            ce.Status = "A";
            ce.ParentId = 10;

            cf.AddCategory(ce);

            ce.CategoryName = "PO4";
            ce.EditDate = DateTime.Now;
            ce.EditUser = "jy25";
            ce.Status = "A";
            ce.ParentId = 10;

            cf.AddCategory(ce);

            ce.CategoryName = "RMA3";
            ce.EditDate = DateTime.Now;
            ce.EditUser = "jy25";
            ce.Status = "A";
            ce.ParentId = 11;

            cf.AddCategory(ce);

            ce.CategoryName = "RMA4";
            ce.EditDate = DateTime.Now;
            ce.EditUser = "jy25";
            ce.Status = "A";
            ce.ParentId = 11;

            cf.AddCategory(ce);
        }

        public void GetCategory()
        {
            CategoryFacade cf = new CategoryFacade();
            IEnumerable<CategoryEntity> tree = cf.GetCategoryTree("jy25");

        }

        public void UpdateCategory()
        {
            CategoryFacade cf = new CategoryFacade();
            //CategoryEntity ce = new CategoryEntity();
            //ce.CategoryId = 14;
            //ce.CategoryName = "SO Test";
            //ce.EditDate = DateTime.Now;
            //ce.EditUser = "jy25";
            //ce.Status = "A";
            //cf.UpdateCategory(ce);

            cf.DeleteCategory(14);
        }
    }
}
