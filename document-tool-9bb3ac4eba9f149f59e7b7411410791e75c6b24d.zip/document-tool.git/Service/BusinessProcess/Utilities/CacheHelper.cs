﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Oversea.DataAccess.DbProvider;
using ServiceStack.Redis;
using BusinessProcess.Utilities;

namespace BusinessProcess.Utilities
{
    public static class CacheHelper
    {
        private static PooledRedisClientManager prcm = CacheHelper.CreateRedisManager();
        private static readonly int REDIS_DATABASE_NUMBER = 3;
        private static readonly string _prefix;

        static CacheHelper()
        {
            _prefix = ConnectionStringManager.GetConnectionString("DocumentTool").MD5();
        }

        /// <summary>
        /// 创建Redis连接池管理对象
        /// </summary>
        public static PooledRedisClientManager CreateRedisManager()
        {
            //支持读写分离，均衡负载
            return new PooledRedisClientManager(
                new string[] { APPConfig.RedisAddress }, //读写服务器
                new string[] { APPConfig.RedisAddress }, //只读服务器
                new RedisClientManagerConfig
                {
                    MaxWritePoolSize = 5, //"写"链接池数
                    MaxReadPoolSize = 5, //"读"链接池数
                    AutoStart = true,
                },
                REDIS_DATABASE_NUMBER,
                null, null);
        }

        /// <summary>
        /// 添加数据
        /// </summary>
        public static bool Set<T>(string key, T val)
        {
            key = string.Format("{0}_{1}", _prefix, key);
            using (IRedisClient rds = prcm.GetClient())
            {
                return rds.Set<T>(key, val);
            }
        }


        /// <summary>
        /// 读取数据
        /// </summary>
        public static T Get<T>(string key)
        {
            key = string.Format("{0}_{1}", _prefix, key);
            using (IRedisClient rds = prcm.GetReadOnlyClient())
            {
                return rds.Get<T>(key);
            }
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        public static bool Remove(string key)
        {
            key = string.Format("{0}_{1}", _prefix, key);
            using (IRedisClient rds = prcm.GetClient())
            {
                return rds.Remove(key);
            }
        }
    }
}
