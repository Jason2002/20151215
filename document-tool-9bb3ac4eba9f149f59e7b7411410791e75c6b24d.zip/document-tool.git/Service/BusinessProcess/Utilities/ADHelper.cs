﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices;
using Newegg.API.Client;
using BusinessProcess.BusinessRule;

namespace BusinessProcess.Utilities
{
    public static class ADHelper
    {
        //static string m_filter = "(&(objectCategory=User)(sAMAccountName={0}))";
        public static string GetUserFullName(string uid)
        {
            var adUser = new GroupRightsFacade().GetUserFromAD(uid);
            if (adUser != null)
            {
                return adUser.FullName;//string.Format("{0}.{1}", adUser.FirstName, adUser.LastName);
            }
            return uid;
            //DirectorySearcher ds = new DirectorySearcher()
            //{
            //    SearchRoot = new DirectoryEntry("LDAP://ABS_CORP"),
            //    Filter = String.Format(m_filter, uid)
            //};

            //System.DirectoryServices.SearchResult sr = ds.FindOne();

            //LogWriter logWriter = new LogWriter();
            //if (sr != null)
            //{
            //    DirectoryEntry entry = sr.GetDirectoryEntry();
            //    if (entry != null)
            //    {
            //        string fullName = entry.Properties["name"].Value as String;
            //        logWriter.AddLogEntry(string.Format("user full name:{0}", fullName));
            //        return fullName;
            //    }
            //}

            //logWriter.AddLogEntry(string.Format("not found user from ad:{0}", uid));
            //return uid;
        }

        public static bool IsExistUser(string uid)
        {
            var adUser = new GroupRightsFacade().GetUserFromAD(uid);
            return adUser != null;
        }

        /// <summary>
        /// 指定的Group是否在Active Directory中存在
        /// </summary>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public static bool IsExistGroup(string groupName)
        {
            if (string.IsNullOrWhiteSpace(groupName)) return false;

            string filter = "(&(objectCategory=Group)(cn={0}))";
            DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://ABS_CORP");
            using (DirectorySearcher ds = new DirectorySearcher(directoryEntry))
            {
                ds.Filter = string.Format(filter, groupName);
                SearchResult sr = ds.FindOne();
                return sr != null;
            }
        }

        //private static void test()
        //{
        //    var result = IsExistGroupInAD("* GP team mis nesc cncd fin");
        //}
    }
}
