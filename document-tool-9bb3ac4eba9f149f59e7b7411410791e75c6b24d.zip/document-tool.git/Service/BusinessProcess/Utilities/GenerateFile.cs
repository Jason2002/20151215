﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.Configuration;
using System.IO;
using BusinessProcess.Utilities;
using Newegg.Oversea.Framework.WCF.Exceptions;

namespace BusinessProcess.Utilities
{
    public class GenerateFileHelper
    {
        public DocumentEntity Entity { get; set; }

        public void GenerateFile()
        {
            try
            {
                //string path = ConfigurationManager.AppSettings["IndexPath"];
                //if (string.IsNullOrEmpty(path))
                //{
                //    return;
                //}
                string content = ConvertToString(Entity.DocumentContent);

                //string fileName = string.Empty;
                //fileName = System.IO.Path.Combine(path, Entity.DocumentId.ToString() + ".txt");
                //if (!System.IO.Directory.Exists(path))
                //{
                //    System.IO.Directory.CreateDirectory(path);
                //}
                //FileInfo file = new FileInfo(fileName);
                //using (StreamWriter writer = new StreamWriter(file.Open(FileMode.Append, FileAccess.Write, FileShare.ReadWrite)))
                //{
                //    writer.WriteLine(content);
                //    writer.Flush();
                //}

                new SolrHelper().CreateIndex(Entity.DocumentId ?? 0, content);
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(ex, null);
            }
        }

        public string ConvertToString(string source)
        {
            byte[] buffer = Convert.FromBase64String(source);
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            using (System.IO.MemoryStream content = new MemoryStream())
            {
                ms.Write(buffer, 0, buffer.Length);
                ms.Position = 0;
                using (System.IO.Compression.DeflateStream stream = new System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Decompress))
                {
                    stream.Flush();

                    int nSize = 3 * 1024 * 1024;
                    byte[] decompressBuffer = new byte[nSize];
                    int readTimes = 1;
                    int nSizeIncept;
                    while ((nSizeIncept = stream.Read(decompressBuffer, 0, nSize)) != 0 || readTimes < 3)
                    {
                        readTimes++;
                        if (nSizeIncept == 0)
                        {
                            continue;
                        }
                        content.Write(decompressBuffer, 0, nSizeIncept);
                    }
                }
                content.Position = 0;
                System.Windows.Forms.RichTextBox rtb = new System.Windows.Forms.RichTextBox();
                rtb.LoadFile(content, System.Windows.Forms.RichTextBoxStreamType.RichText);
                return rtb.Text;
            }
        }
    }
}
