﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Hosting;

namespace BusinessProcess.Utilities
{
    [Serializable]
    public class LogWriter
    {
        /// <summary>
        /// Load Log File from App_Data
        /// </summary>
        public LogWriter()
        {
        }

        /// <summary>
        /// Adding a new Log-Entry to the LogData
        /// </summary>
        /// <param name="Created"></param>
        /// <param name="PageTitle"></param>
        public void AddLogEntry(string message)
        {
            string _path = GetDataFilename();
            lock (_path)
            {
                LogEntry entry = new LogEntry();

                //Date
                entry.Created = DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString();

                //Error
                entry.Error = message;

                FileInfo file = new FileInfo(_path);
                using (StreamWriter writer = new StreamWriter(file.Open(FileMode.Append, FileAccess.Write, FileShare.ReadWrite)))
                {
                    writer.WriteLine(ServiceStack.Text.XmlSerializer.SerializeToString<LogEntry>(entry));
                    writer.WriteLine();
                    writer.Flush();
                    writer.Close();
                }
            }
        }

        /// <summary>
        /// Returns file name of the Logfile
        /// </summary>
        /// <returns>string containting path to sidebar data file</returns>
        protected string GetDataFilename()
        {
            string filePath = HostingEnvironment.MapPath("~/Log/");

            if (!Directory.Exists(filePath))
            {
                Directory.CreateDirectory(filePath);
            }

            filePath += System.DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            return filePath;
        }

        /// <summary>
        /// Data-Class for the Log
        /// </summary>
        public class LogEntry
        {
            public string Created;
            public string Error;

            public LogEntry()
            {
                Created = string.Empty;
                Error = string.Empty;
            }
        }
    }
}
