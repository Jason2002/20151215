﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Web;
using System.Xml;

using ServiceDefinetion;
using BusinessProcess.BusinessRule;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace BusinessProcess.Utilities
{
    public class SolrHelper
    {
        private static readonly string SOLRAddress = System.Configuration.ConfigurationManager.AppSettings["solrAddress"];
        public string Update(string xml)
        {
            string url = SOLRAddress.TrimEnd('/') + "/update?commit=true";
            return Request(url, xml);
        }

        public string Selete(string queryParameters)
        {
            string url = SOLRAddress.TrimEnd('/') + "/select/?rows=100&" + queryParameters;

            return Request(url);
        }

        public string Delete(string id)
        {
            return Update(string.Format(@"<delete><id>{0}</id></delete>", id));
        }

        private string Request(string url, string xml = null)
        {
            string method = xml == null ? "GET" : "POST";
            HttpWebRequest request = System.Net.WebRequest.CreateDefault(new Uri(url)) as HttpWebRequest;
            request.ContentType = "text/xml; charset=UTF-8";

            request.Method = method;
            if (method == "POST")
            {
                byte[] data = System.Text.Encoding.GetEncoding("utf-8").GetBytes(xml);
                request.ContentLength = data.Length;
                using (Stream reqStream = request.GetRequestStream())
                {
                    reqStream.Write(data, 0, data.Length);
                }
            }
            using (WebResponse wr = request.GetResponse())
            {
                using (StreamReader sr = new StreamReader(wr.GetResponseStream()))
                {
                    return sr.ReadToEnd();
                }
            }

        }

        public void CreateIndex(int id, string content)
        {
            Regex regex = new Regex(@"[\x00-\x08]|[\x0b-\x0c]|[\x0e-\x1f]");
            content = regex.Replace(content, "");
            content = content.Replace("<", "&lt;").Replace("&", "&amp;")
                .Replace("<![CDATA[", "CDATA[[")
                .Replace("]]>", "]] ");

            string xml = string.Format(@"<add><doc>
  <field name=""id"">{0}</field>
  <field name=""text"">{1}</field>
</doc></add>", id, content);

            this.Update(xml);
        }
        public IEnumerable<DocumentEntity> Search(string keywords)
        {
            //List<DocumentEntity> results = new List<DocumentEntity>();
            List<int> ids = new List<int>();

            string queryString = keywords;
            if (queryString.Length == 0)
            {
                queryString = "*:*";
            }
            queryString = "q=" + HttpUtility.UrlEncode(queryString);
            string result = this.Selete(queryString);

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(result);
            XmlNodeList nodes = xmlDoc.SelectNodes("//result/doc/str[@name='id']");

            foreach (XmlNode xn in nodes)
            {
                int id = 0;
                if (int.TryParse(xn.InnerText, out id))
                {
                    ids.Add(id);
                }
            }

            List<DocumentEntity> results = new List<DocumentEntity>();

            DocumentFacade facade = new DocumentFacade();
            List<DocumentEntity> docs = facade.GetActiveDocumentByIds(ids);
            if (docs != null)
            {
                results.AddRange(facade.GetActiveDocumentByIds(ids));
            }

            //合并附件搜索结果
            AttachmentFacade attFacade = new AttachmentFacade();
            List<int> ids_att = attFacade.Search(keywords);
            if (ids_att != null && ids_att.Count > 0)
            {
                List<DocumentEntity> docs_att = attFacade.GetActiveDocumentByAttIds(ids_att);
                if (docs_att != null)
                {
                    results.AddRange(docs_att);
                }
            }

            return results;
        }
    }
}
