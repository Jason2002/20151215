﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Microsoft.Exchange.WebServices.Data;

namespace BusinessProcess.Utilities
{
    public class MailGetter
    {
        ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
        public void OpenAccount(string emailAddress, string domain, string userName, string password)
        {
            service.Credentials = new NetworkCredential(userName, password, domain);
            service.AutodiscoverUrl(emailAddress);
        }


        public List<Item> GetMails()
        {
            DateTime lastReceivedTime = DateTime.MinValue;
            lastReceivedTime = DateTime.SpecifyKind(lastReceivedTime, DateTimeKind.Utc);
            lastReceivedTime = lastReceivedTime.ToLocalTime().AddSeconds(1);
            FindItemsResults<Item> findResults = service.FindItems(WellKnownFolderName.Inbox,
                 new SearchFilter.IsGreaterThan(EmailMessageSchema.DateTimeReceived, lastReceivedTime),
                new ItemView(int.MaxValue));
            List<Item> items = new List<Item>();
            foreach (Item item in findResults.Items)
            {
                item.Load();
            }
            return findResults.Items.ToList();
        }

        public void MoveMailsDeleted(List<Item> items)
        {
            FindItemsResults<Item> findResults = service.FindItems(WellKnownFolderName.Inbox,
                 new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, "false"),
                new ItemView(int.MaxValue));
            foreach (Item item in findResults.Items)
            {
                if (items.Exists(i => i.Id.UniqueId == item.Id.UniqueId))
                {
                    item.Move(WellKnownFolderName.DeletedItems);
                }
            }

        }

    }
}
