﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessProcess.Models;
using ServiceDefinetion;

namespace BusinessProcess.Utilities
{
    public static class EntityMapping
    {
        #region Documents
        public static IEnumerable<DocumentEntity> ToMessage(List<DocumentInfo> documents)
        {
            List<DocumentEntity> docs = new List<DocumentEntity>();
            documents.ForEach(d => docs.Add(ToMessage(d)));
            return docs;
        }

        public static DocumentEntity ToMessage(DocumentInfo d)
        {
            if (d == null)
            {
                return null;
            }
            DocumentEntity entity = new DocumentEntity();
            entity.DocumentId = d.DocumentId;
            if (d.DocumentContent != null)
            {
                entity.DocumentContent = d.DocumentContent.DocumentText;
                entity.DocumentKeywords = d.DocumentContent.DocumentKeywords;
            }
            //if (d.Categories != null)
            //{
            //    entity.SearchName = d.Categories.CategoryName;
            //}
            entity.EditDate = d.EditDate;
            entity.EditUser = d.EditUser;
            entity.Status = d.Status;
            entity.Version = d.Version;
            entity.GenerateFlag = d.GenerateFlag;
           
            return entity;
        }

        #endregion
    }
}
