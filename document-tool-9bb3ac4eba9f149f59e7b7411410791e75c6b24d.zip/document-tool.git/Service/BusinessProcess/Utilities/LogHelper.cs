﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BusinessProcess.Utilities
{
    public static class LogHelper
    {
        public const string Type_ModifyDocument = "D";
        public const string Type_ModifyCategory = "C";
        public const string Type_Login = "I";
        public const string Type_Logout = "O";

        public static string GetLoginMessage(string uid)
        {
            return string.Format("{0} login to Document Management Tool.", ADHelper.GetUserFullName(uid));
        }

        public static string GetLogoutMessage(string uid)
        {
            return string.Format("{0} logout to Document Management Tool.", ADHelper.GetUserFullName(uid));
        }

        public static string GetAddCategoryMessage(string uid, string categoryname)
        {
            return string.Format("{0} add a new catalog: {1}.", ADHelper.GetUserFullName(uid), categoryname);
        }

        public static string GetModifyCategoryMessage(string uid, string categoryname)
        {
            return string.Format("{0} modify catalog: {1}.", ADHelper.GetUserFullName(uid), categoryname);
        }

        public static string GetAddDocumentMessage(string uid, string categoryname)
        {
            return string.Format("{0} add a new document to catalog: {1}.", ADHelper.GetUserFullName(uid), categoryname);
        }

        public static string GetModifyDocumentMessage(string uid, string categoryname)
        {
            return string.Format("{0} modify document: {1}.", ADHelper.GetUserFullName(uid), categoryname);
        }
    }
}
