﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Newegg.DFIS;
using Newegg.DFIS.Uploader;

namespace BusinessProcess.Utilities
{
    public static class DfisBLL
    {
        static string url = ConfigurationManager.AppSettings["UploadWebUrl"];
        static string userName = ConfigurationManager.AppSettings["UploadUserName"];
        static string fileType = ConfigurationManager.AppSettings["UploadFileType"];
        static string fileGroup = ConfigurationManager.AppSettings["UploadFileGroup"];
        static string downloadUrl = ConfigurationManager.AppSettings["DownloadingWebUrl"];

        public static string UploadAttachment(string fileName, byte[] content)
        {
            string returnUrl = string.Empty;

            string newName = GetFileName(fileName);

            Newegg.DFIS.DFISClient client = new Newegg.DFIS.DFISClient();
            FileDetail detail = new FileDetail();
            detail.Data = content;

            detail.Uri = string.Format("{0}/{1}/{2}/{3}", url, fileGroup, fileType, FileNameEncode(newName));
            detail.Group = fileGroup;
            detail.Type = fileType;
            detail.FileName = newName;
            detail.UserName = userName;
            detail.Overwrite = true;
            detail.Timeout = 30000;

            client.UploadFile(detail);

            //HttpUploader.UploadFile(url, fileGroup, fileType, newName, uploadFile, string.Empty, userName, UploadMethod.Update);

            returnUrl = downloadUrl + fileGroup + "/" + fileType + "/" + newName;

            return returnUrl;
        }

        public static string UploadAttachment(string uploadFile)
        {
            string returnUrl = string.Empty;

            string newName = GetFileName(uploadFile);
            //using (FileStream fileStream = new FileStream(uploadFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            //{
            HttpUploader.UploadFile(url, fileGroup, fileType, newName, uploadFile, string.Empty, userName, UploadMethod.Update);
            //}

            returnUrl = downloadUrl + fileGroup + "/" + fileType + "/" + newName;

            return returnUrl;
        }

        private static string GetFileName(string originalFile)
        {
            FileInfo file = new FileInfo(originalFile);

            //加时间戳防止附件同名覆盖
            string newName = string.Format("{0}.{1}{2}", file.Name.Substring(0, file.Name.Length - file.Extension.Length), GetTimeStamp(), file.Extension);
            //string newName = file.Name;
            newName = newName.Replace(" ", "_").Replace("&", "_");

            return newName;
        }

        private static string FileNameEncode(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                fileName = HttpUtility.UrlEncode(fileName);
                fileName = fileName.Replace("+", " ");
            }
            return fileName;
        }

        /// <summary>   
        /// 获取时间戳   
        /// </summary>   
        /// <returns></returns>   
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }
    }
}
