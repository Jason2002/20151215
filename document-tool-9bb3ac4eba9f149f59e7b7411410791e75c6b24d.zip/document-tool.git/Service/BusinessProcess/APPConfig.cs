﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Newegg.API.Client;
using System.Configuration;

namespace BusinessProcess
{
    public static class APPConfig
    {
        public static string AppKey;
        public static string AccessToken;

        static APPConfig()
        {
            AppKey = ConfigurationManager.AppSettings["AppKey"];
            AccessToken = ConfigurationManager.AppSettings["AccessToken"];
        }

        public static RestAPIClient GetAPIClient()
        {
            RestAPIClient client = new RestAPIClient(ConfigurationManager.AppSettings["ServiceBaseAddress"], ContentTypes.Json);
            client.SetAuthorizationInfo(AppKey, AccessToken);
            client.Proxy = WebRequest.GetSystemWebProxy();
            return client;
        }

        public static RestAPIClient GetViewerClient()
        {
            return new RestAPIClient(ConfigurationManager.AppSettings["WebViewerAddress"], ContentTypes.Json);
        }

        public static string RedisAddress
        {
            get
            {
                return ConfigurationManager.AppSettings["RedisAddress"];
            }
        }
    }
}
