﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class MessageService : IMessageService
    {
        [ErrorHandling]
        public string SayHi(string userName)
        {
            LogFacade lf = new LogFacade();
            lf.AddNewLog(userName, LogHelper.Type_Login, LogHelper.GetLoginMessage(userName));

            return "Hello " + ADHelper.GetUserFullName(userName) + ", welcome use Document Management Tool.";
        }

        [ErrorHandling]
        public void SayGoodbye(string userName)
        {
            LogFacade lf = new LogFacade();
            lf.AddNewLog(userName, LogHelper.Type_Logout, LogHelper.GetLogoutMessage(userName));
        }

        [ErrorHandling]
        public List<LogEntity> GetRecentlyLog(int lastID)
        {
            LogFacade lf = new LogFacade();
            return lf.GetRecentlyLog(lastID);
        }
    }
}
