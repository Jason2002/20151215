﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using ServiceDefinetion;
using BusinessProcess.BusinessRule;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class PrivilegeService : IPrivilegeService
    {
        [ErrorHandling]
        public void Update(List<PrivilegeInfo> privileges)
        {
            new PrivilegeFacade().Update(privileges);
        }

        [ErrorHandling]
        public void Delete(PrivilegeAcctType acctType, string acctName)
        {
            new PrivilegeFacade().Delete(acctType, acctName);
        }

        [ErrorHandling]
        public List<PrivilegeInfo> GetPrivilegeListByUserSelf(string userID)
        {
            return new PrivilegeFacade().GetPrivilegeListByUserSelf(userID);
        }

        [ErrorHandling]
        public List<PrivilegeInfo> GetPrivilegeListByGroupSelf(string groupNames)
        {
            return new PrivilegeFacade().GetPrivilegeListByGroupSelf(groupNames);
        }

        [ErrorHandling]
        public PrivilegeAcctType? GetAcctType(string acctName)
        {
            return new PrivilegeFacade().GetAcctType(acctName);
        }

        [ErrorHandling]
        public List<PrivilegeInfo> GetListByCategoryID(int categoryID)
        {
            return new PrivilegeFacade().GetListByCategoryID(categoryID);
        }
    }
}
