﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class IndexService : IIndexService
    {
        [ErrorHandling]
        public void GenerateDocumentIndex()
        {
            DocumentFacade facade = new DocumentFacade();
            IEnumerable<DocumentEntity> docs = facade.GetDocumentsWithoutIndex();
            //Parallel.ForEach(docs, d =>
            //    {
            foreach (var d in docs)
            {

                GenerateFileHelper gf = new GenerateFileHelper { Entity = d };
                gf.GenerateFile();
                //Thread t = new Thread(new ThreadStart(gf.GenerateFile));

                //t.SetApartmentState(ApartmentState.STA);
                //t.Start();
                //GenerateFile(d);
                facade.UpdateDocumentAfterGenerateIndex(d.DocumentId.Value);
            }
        }
    }
}
