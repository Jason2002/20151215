﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class DocumentService : IDocumentService
    {
        [ErrorHandling]
        public int ModifyDocument(int categoryId, DocumentEntity document)
        {
            DocumentFacade documentFacade = new DocumentFacade();

            //取最新版本
            DocumentEntity latestDocument = documentFacade.GetDocumentsWithoutContent(categoryId);

            int documentId;
            if (latestDocument == null)
            {
                document.Version = "1.0";

                documentId = documentFacade.AddDocument(categoryId, document);
                new LogFacade().AddNewLog(document.EditUser, LogHelper.Type_ModifyDocument, LogHelper.GetAddDocumentMessage(document.EditUser, categoryId.ToString()));
            }
            else
            {
                document.Version = latestDocument.Version;
                document.DocumentId = latestDocument.DocumentId;

                documentId = documentFacade.UpdateDocument(categoryId, document);
                //documentId = document.DocumentId.Value;
                new LogFacade().AddNewLog(document.EditUser, LogHelper.Type_ModifyDocument, LogHelper.GetModifyDocumentMessage(document.EditUser, categoryId.ToString()));
            }

            //通知webviewer做转换动作
            APPConfig.GetViewerClient().Get<object>(string.Format("/Document/Convert/{0}", categoryId), null);

            return documentId;
        }

        [ErrorHandling]
        public void DeleteDocument(int categoryId)
        {
            new DocumentFacade().DeleteDocument(categoryId);
        }

        [ErrorHandling]
        public DocumentEntity GetDocument(int categoryId)
        {
            return new DocumentFacade().GetDocuments(categoryId);
        }

        [ErrorHandling]
        public DocumentEntity GetDocumentById(int documentId)
        {
            return new DocumentFacade().GetDocumentById(documentId);
        }

        [ErrorHandling]
        public DocumentEntity GetDocumentWithoutContent(int categoryId)
        {
            return new DocumentFacade().GetDocumentsWithoutContent(categoryId);
        }

        [ErrorHandling]
        public IEnumerable<DocumentEntity> SearchDocuments(string keywords)
        {
            //return new SearchHelper().Search(keywords);
            return new SolrHelper().Search(keywords);
        }

        [ErrorHandling]
        public int GetCategoryIdByDocumentId(int documentId)
        {
            return new CategoryFacade().GetCategoryIdByDocumentId(documentId);
        }

        [ErrorHandling]
        public IEnumerable<DocumentEntity> GetHistoryDocuments(int categoryId)
        {
            return new DocumentFacade().GetHistoryDocuments(categoryId);
        }

        [ErrorHandling]
        public IEnumerable<DocumentEntity> GetLatestUpdateDocument(int count)
        {
            return new DocumentFacade().GetLatestUpdateDocument(count);
        }
    }
}
