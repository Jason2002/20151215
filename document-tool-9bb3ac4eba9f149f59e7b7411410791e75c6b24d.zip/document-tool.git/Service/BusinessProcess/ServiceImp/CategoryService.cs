﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;
using System.IO;
using ServiceStack.Text;
using System.Web.Hosting;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class CategoryService : ICategoryService
    {
        [ErrorHandling]
        public IEnumerable<CategoryEntity> GetCategoryTree(string uid)
        {
            return new CategoryFacade().GetCategoryTree(uid);
        }

        [ErrorHandling]
        public IEnumerable<CategoryEntity> GetCategoryList()
        {
            return new CategoryFacade().GetCategoryList();
        }

        [ErrorHandling]
        public void ModifyCategory(CategoryEntity category)
        {
            if (category.CategoryId.HasValue)
            {
                new CategoryFacade().UpdateCategory(category);
                new LogFacade().AddNewLog(category.EditUser, LogHelper.Type_ModifyCategory, LogHelper.GetModifyCategoryMessage(category.EditUser, category.CategoryName));
            }
            else
            {
                new CategoryFacade().AddCategory(category);
                new LogFacade().AddNewLog(category.EditUser, LogHelper.Type_ModifyCategory, LogHelper.GetAddCategoryMessage(category.EditUser, category.CategoryName));
            }

        }

        [ErrorHandling]
        public void UpdateCategoryParent(int parentId, int categoryId, string userName)
        {
            new CategoryFacade().UpdateCategoryParent(parentId, categoryId);
            new LogFacade().AddNewLog(userName, LogHelper.Type_ModifyCategory, LogHelper.GetModifyCategoryMessage(userName, categoryId.ToString()));
        }

        [ErrorHandling]
        public void DeleteCategory(int categoryId, string userName)
        {
            new CategoryFacade().DeleteCategory(categoryId);
            new LogFacade().AddNewLog(userName, LogHelper.Type_ModifyCategory, LogHelper.GetModifyCategoryMessage(userName, categoryId.ToString()));
        }

        [ErrorHandling]
        public CategoryEntity AddNewIfNotExists(CategoryEntity entity)
        {
            new CategoryFacade().AddNewIfNotExists(entity);
            return entity;
        }

        [ErrorHandling]
        public RuleList GetPublishRuleList()
        {
            using (StreamReader sr = new StreamReader(HostingEnvironment.MapPath(@"~\PublishRules.config")))
            {
                return sr.ReadToEnd().FromXml<RuleList>();
            }
        }
    }
}
