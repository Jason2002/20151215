﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class FavoriteService : IFavoriteService
    {
        [ErrorHandling]
        public int AddFavorite(FavoriteEntity favoriteEntity)
        {
            FavoriteFacade favFacade = new FavoriteFacade();
            favoriteEntity.EditDate = DateTime.Now;
            return favFacade.AddFavorite(favoriteEntity);
        }

        [ErrorHandling]
        public void DeleteFavorite(int id)
        {
            FavoriteFacade favFacade = new FavoriteFacade();
            favFacade.DeleteFavorite(id);
        }

        [ErrorHandling]
        public IEnumerable<FavoriteEntity> GetFavorites(string userID)
        {
            FavoriteFacade favFacade = new FavoriteFacade();
            return favFacade.GetFavorites(userID);
        }

        [ErrorHandling]
        public IEnumerable<CategoryEntity> GetFavoritesAsCat(string userID)
        {
            FavoriteFacade favFacade = new FavoriteFacade();
            return favFacade.GetFavoritesAsCat(userID);
        }
    }
}
