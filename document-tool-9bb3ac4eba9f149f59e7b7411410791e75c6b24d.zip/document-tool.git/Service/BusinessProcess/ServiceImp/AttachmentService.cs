﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;
using System.Web;
using System.Net;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class AttachmentService : IAttachmentService
    {
        [ErrorHandling]
        public void AddAttachment(int documentId, AttachmentEntity entity)
        {
            AttachmentFacade attFacade = new AttachmentFacade();
            attFacade.AddAttachment(documentId, entity);

            //通知webviewer做转换动作
            CategoryFacade categoryFacade = new CategoryFacade();
            int categoryId = categoryFacade.GetCategoryIdByDocumentId(documentId);

            APPConfig.GetViewerClient().GetAsync<object>(string.Format("/Document/ConvertSub/{0}?path={1}",
                categoryId, HttpUtility.UrlEncode(entity.DownloadUrl)), null, null);
        }

        [ErrorHandling]
        public void AddAttachmentDocument(AttachmentDocumentEntity entity)
        {
            AttachmentFacade attFacade = new AttachmentFacade();
            attFacade.AddAttachmentDocument(entity);

            //通知webviewer做转换动作
            CategoryFacade categoryFacade = new CategoryFacade();
            int categoryId = categoryFacade.GetCategoryIdByDocumentId(entity.DocumentId);
            if (categoryId == 0) return;

            var att = attFacade.GetAttachment(entity.AttachmentId);
            if (att == null) return;

            APPConfig.GetViewerClient().GetAsync<object>(string.Format("/Document/ConvertSub/{0}?path={1}",
                categoryId, HttpUtility.UrlEncode(att.DownloadUrl)), null, null);
        }

        [ErrorHandling]
        public AttachmentEntity FindAttachmentByHash(string hashCode, string fileName)
        {
            AttachmentFacade attFacade = new AttachmentFacade();
            return attFacade.FindAttachmentByHash(hashCode, fileName);
        }
    }
}
