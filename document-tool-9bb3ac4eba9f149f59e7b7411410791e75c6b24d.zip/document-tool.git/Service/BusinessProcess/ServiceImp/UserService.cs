﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using System.ServiceModel;
using BusinessProcess.BusinessRule;
using BusinessProcess.Utilities;
using System.Threading;
using Newegg.Oversea.Framework.WCF.Behaviors;
using Newegg.Oversea.Framework.ExceptionHandler;

namespace BusinessProcess.ServiceImp
{
    [ServiceErrorHandling]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class UserService : IUserService
    {
        [ErrorHandling]
        public List<UserRightsEntity> GetUserRightsById(string uid)
        {
            List<UserRightsEntity> urRights = null;
            new UserRightsFacade().GetUserRights(uid, out urRights);
            if (urRights != null)
            {
                return urRights;
            }
            else
            {
                return new List<UserRightsEntity>();
            }

        }

        [ErrorHandling]
        public void AddUserRights(List<UserRightsEntity> rights, string userid)
        {
            UserRightsFacade urf = new UserRightsFacade();
            urf.AddUserRights(rights, userid);
        }

        [ErrorHandling]
        public UserOperationRights GetUserOperationRightsById(string uid)
        {
            UserRightsFacade urf = new UserRightsFacade();
            return urf.GetUserOperationRightsById(uid);
        }
    }
}
