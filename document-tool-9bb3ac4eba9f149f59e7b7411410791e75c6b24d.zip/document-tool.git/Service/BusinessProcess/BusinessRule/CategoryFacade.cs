﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using BusinessProcess.Utilities;
using System.Transactions;
using Newegg.Oversea.DataAccess;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BusinessProcess.BusinessRule
{
    public class CategoryFacade
    {
        public IEnumerable<CategoryEntity> GetCategoryTree(string uid)
        {
            //for test
            //uid = "zh61";

            List<CategoryEntity> results;

            CategoryDA rep = new CategoryDA();
            results = rep.GetCategory();

            if (results.Count > 0)
            {
                PrivilegeFacade privilegeFacade = new PrivilegeFacade();
                var categoryPrivileges = privilegeFacade.GetCategoryPrivilegeList(uid);
                privilegeFacade.Filter(results, categoryPrivileges);
            }

            return results;
        }

        public List<CategoryEntity> GetCategoryList()
        {
            CategoryDA rep = new CategoryDA();
            return rep.GetCategoryList();
        }

        /*
        #region Filter Categories by user role
        private void FilterCategories(string uid, List<CategoryEntity> categories)
        {
            List<UserRightsEntity> rights;
            RightsType type = new UserRightsFacade().GetUserRights(uid, out rights);
            switch (type)
            {
                case RightsType.Admin:
                    FilterForAdmin(categories);
                    break;
                case RightsType.General:
                    FilterForGeneral(categories);
                    break;
                case RightsType.AuthUser:
                case RightsType.DomainOwner:
                    FilterForAuth(categories, rights);
                    break;
                default:
                    FilterForGeneral(categories);
                    break;
            }
            categories.ForEach(c =>
                {
                    if (c.SubCategories != null && c.SubCategories.Count > 0)
                    {
                        PrepareCategories(c.SubCategories.ToList(), c.AuthViewResult, c.AuthEditResult);
                    }
                });
        }

        private void FilterForAdmin(List<CategoryEntity> categories)
        {
            categories.ForEach(c =>
                {
                    c.AuthEditResult = false;
                    c.AuthViewResult = false;
                });
        }

        private void FilterForGeneral(List<CategoryEntity> categories)
        {
            categories.RemoveAll(c => c.IsAuthShow.HasValue && c.IsAuthShow.Value);
            categories.ForEach(c =>
                {
                    c.AuthEditResult = c.IsAuthEdit ?? false;
                    c.AuthViewResult = c.IsAuthShow ?? false;
                });
        }

        private void FilterForAuth(List<CategoryEntity> categories, List<UserRightsEntity> rights)
        {
            categories.ForEach(c =>
                {
                    var find = rights.FirstOrDefault(r => r.RootID == c.CategoryId);
                    if (find != null)
                    {
                        if (find.IsOwner)
                        {
                            c.AuthViewResult = false;
                            c.AuthEditResult = false;
                        }
                        else
                        {
                            if (c.IsAuthShow.HasValue && c.IsAuthShow.Value)
                            {
                                c.AuthViewResult = !find.CanView;
                            }
                            if (c.IsAuthEdit.HasValue && c.IsAuthEdit.Value)
                            {
                                c.AuthEditResult = !find.CanEdit;
                            }
                        }
                    }
                    else
                    {
                        c.AuthViewResult = c.IsAuthShow ?? false;
                        c.AuthEditResult = c.IsAuthEdit ?? false;
                    }
                });

            categories.RemoveAll(c => c.AuthViewResult);
        }

        private void PrepareCategories(List<CategoryEntity> categories, bool isAuthShow, bool isAuthEdit)
        {
            categories.ForEach(c =>
                {
                    c.AuthEditResult = isAuthEdit;
                    c.AuthViewResult = isAuthShow;
                    if (c.SubCategories != null && c.SubCategories.Count > 0)
                    {
                        PrepareCategories(c.SubCategories.ToList(), isAuthShow, isAuthEdit);
                    }
                });
        }
        #endregion
        */

        public void UpdateCategory(CategoryEntity entity)
        {
            CategoryDA rep = new CategoryDA();
            rep.UpdateCategory(entity);
        }

        public void UpdateCategoryParent(int parentId, int categoryId)
        {
            CategoryDA rep = new CategoryDA();
            rep.UpdateCategoryParent(parentId, categoryId);
        }

        public void AddCategory(CategoryEntity entity)
        {
            CategoryDA rep = new CategoryDA();
            CategoryEntity cate = entity;
            rep.AddNewCategory(cate);
        }

        //如果指定的父节点下不存在则创建，否则返回已存在节点的Id
        public void AddNewIfNotExists(CategoryEntity entity)
        {
            entity.CategoryName = entity.CategoryName.Trim();

            CategoryDA rep = new CategoryDA();
            CategoryEntity cate = entity;
            rep.AddNewIfNotExists(cate);
        }

        public void DeleteCategory(int categoryId)
        {
            CategoryDA rep = new CategoryDA();
            rep.DeleteCateogry(categoryId);
        }

        public int GetCategoryIdByDocumentId(int documentId)
        {
            CategoryDA rep = new CategoryDA();
            return rep.GetCategoryIdByDocumentId(documentId);
        }
    }

    public class CategoryDA
    {
        private readonly string m_cache_category_key = "DocumentTool_Categories_Tree";
        private static object m_syncObj = new object();

        public List<CategoryEntity> GetCategoryList()
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.GetList");
            return dataCommand.ExecuteEntityList<CategoryEntity>();
        }

        public List<CategoryEntity> GetCategory()
        {
            //由于CategoryEntity的Parent属性没有DataMember，无法缓存到Redis中，
            //所以缓存方式改为二进制序列化结果
            var cache_Categories = CacheHelper.Get<byte[]>(m_cache_category_key);
            if (cache_Categories != null)
            {
                using (MemoryStream ms = new MemoryStream(cache_Categories))
                {
                    ms.Position = 0;
                    BinaryFormatter bf = new BinaryFormatter();
                    return bf.Deserialize(ms) as List<CategoryEntity>;
                }
            }

            lock (m_syncObj)
            {
                DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.GetList");
                var results = dataCommand.ExecuteEntityList<CategoryEntity>();

                if (results.Count() > 0)
                {
                    List<CategoryEntity> tree = results.ToList();
                    GenerateTree(tree);
                    tree.RemoveAll(t => t.ParentId.HasValue);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        BinaryFormatter bf = new BinaryFormatter();
                        bf.Serialize(ms, tree);
                        CacheHelper.Set<byte[]>(m_cache_category_key, ms.ToArray());
                    }

                    return tree;
                }
            }

            return new List<CategoryEntity>();
        }

        private void GenerateTree(List<CategoryEntity> categories)
        {
            categories.ForEach(c =>
            {
                var sub = categories.Where(ca => ca.ParentId.HasValue && ca.ParentId.Value == c.CategoryId);
                if (sub.Count() > 0)
                {
                    c.SubCategories = new List<CategoryEntity>();
                    c.SubCategories.AddRange(sub.ToList());
                    c.SubCategories.ForEach(cs => cs.Parent = c);
                    GenerateTree(c.SubCategories);
                }
            });
        }

        public void AddNewCategory(CategoryEntity category)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.AddNew");
            category.CategoryId = dataCommand.ExecuteScalar<int>(category);

            lock (m_syncObj)
            {
                CacheHelper.Remove(m_cache_category_key);
            }
        }

        public void AddNewIfNotExists(CategoryEntity category)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.AddNewIfNotExists");
            category.CategoryId = dataCommand.ExecuteScalar<int>(category);

            lock (m_syncObj)
            {
                CacheHelper.Remove(m_cache_category_key);
            }
        }

        public void UpdateCategory(CategoryEntity newCategory)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.Update");
            dataCommand.ExecuteNonQuery(newCategory);

            lock (m_syncObj)
            {
                CacheHelper.Remove(m_cache_category_key);
            }
        }

        public void UpdateCategoryParent(int parentId, int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.UpdateParent");
            dataCommand.ExecuteNonQuery(new { ParentId = parentId, CategoryId = categoryId });

            lock (m_syncObj)
            {
                CacheHelper.Remove(m_cache_category_key);
            }
        }

        public CategoryEntity FindCategoryById(int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.GetCategory");
            var category = dataCommand.ExecuteEntity<CategoryEntity>(new { CategoryId = categoryId });

            if (category == null)
            {
                throw new Exception("Category does not exists");
            }
            return category;
        }

        public int GetCategoryIdByDocumentId(int documentId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.GetCategoryIdByDocumentId");
            var result = dataCommand.ExecuteScalar<int?>(new { DocumentId = documentId });

            if (result.HasValue)
                return result.Value;
            else
                return 0;
        }

        public void DeleteCateogry(int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Category.IsExistsSub");
            if (dataCommand.ExecuteScalar<int?>(new { CategoryId = categoryId }).HasValue)
            {
                throw new Exception("The category has sub-categories, can't be deleted");
            }

            using (TransactionScope scope = new TransactionScope())
            {
                dataCommand = DataCommandManager.GetDataCommand("Category.Void");
                dataCommand.ExecuteNonQuery(new { CategoryId = categoryId });

                scope.Complete();
            }

            lock (m_syncObj)
            {
                CacheHelper.Remove(m_cache_category_key);
            }
        }
    }
}
