﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using BusinessProcess.Utilities;
using Newegg.Oversea.DataAccess;
using System.Transactions;
using BusinessProcess.Models;

namespace BusinessProcess.BusinessRule
{
    public class DocumentFacade
    {
        public int UpdateDocument(int categoryId, DocumentEntity document)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.Void");
            dataCommand.ExecuteNonQuery(new { DocumentId = document.DocumentId.Value });

            document.Version = (decimal.Parse(document.Version) + 0.1M).ToString();

            return AddDocument(categoryId, document);
        }

        public int AddDocument(int categoryId, DocumentEntity document)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.AddNew");
                document.DocumentId = dataCommand.ExecuteScalar<int>(new
                {
                    CateogryId = categoryId, //注意这里字段名不同
                    EditUser = document.EditUser,
                    EditDate = document.EditDate,
                    Version = document.Version,
                    Status = document.Status,
                    GenerateFlag = 0
                });

                dataCommand = DataCommandManager.GetDataCommand("DocumentContent.AddNew");
                dataCommand.ExecuteNonQuery(new {
                    DocumentId = document.DocumentId,
                    DocumentText = document.DocumentContent,
                    DocumentKeywords = document.DocumentKeywords
                });

                scope.Complete();
            }

            return document.DocumentId.Value;
        }

        public void DeleteDocument(int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.VoidByCategoryId");
            dataCommand.ExecuteNonQuery(new { CategoryId = categoryId });
        }

        public IEnumerable<DocumentEntity> GetHistoryDocuments(int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetByCategoryId");
            return dataCommand.ExecuteEntityList<DocumentEntity>(new { @CategoryId = categoryId });
        }

        public DocumentEntity GetDocuments(int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetContentByCategoryId");
            return dataCommand.ExecuteEntity<DocumentEntity>(new { CategoryId = categoryId });
        }

        public DocumentEntity GetDocumentById(int documentId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetContentByDocumentId");
            return dataCommand.ExecuteEntity<DocumentEntity>(new { DocumentId = documentId });
        }

        public DocumentEntity GetDocumentsWithoutContent(int categoryId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetDocumentsWithoutContent");
            return dataCommand.ExecuteEntity<DocumentEntity>(new { CategoryId = categoryId });
        }

        public IEnumerable<DocumentEntity> GetDocumentsWithoutIndex()
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetDocumentsWithoutIndex");
            return dataCommand.ExecuteEntityList<DocumentEntity>();
        }

        public void UpdateDocumentAfterGenerateIndex(int documentId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.UpdateGenerateFlag");
            dataCommand.ExecuteNonQuery(new { DocumentId = documentId });
        }

        public List<DocumentEntity> GetActiveDocumentByIds(List<int> documentIds)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetActiveDocumentByIds");
            return dataCommand.ExecuteEntityList<DocumentEntity>(new { documentIds = string.Join(",", documentIds) });
        }

        public IEnumerable<DocumentEntity> GetLatestUpdateDocument(int count)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("Document.GetLatestUpdateDocument");
            return dataCommand.ExecuteEntityList<DocumentEntity>(new { TopCount = count });
        }
    }
}
