﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using BusinessProcess.Utilities;
using Newegg.Oversea.DataAccess;

namespace BusinessProcess.BusinessRule
{
    public class LogFacade
    {
        public List<LogEntity> GetRecentlyLog(int lastLogID)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("LogMessage.GetRecentlyLog");
            return dataCommand.ExecuteEntityList<LogEntity>(new { TransactionNumber = lastLogID });
        }

        public void AddNewLog(string uid, string logType, string message)
        {
            var log = new LogEntity { UserID = uid, LogContent = message, LogDate = DateTime.Now, LogType = logType };
            DataCommand dataCommand = DataCommandManager.GetDataCommand("LogMessage.AddNew");
            dataCommand.ExecuteNonQuery(log);
        }
    }
}
