﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessProcess.Utilities;
using ServiceDefinetion;
using Newegg.Oversea.DataAccess;

namespace BusinessProcess.BusinessRule
{
    public class FavoriteFacade
    {
        public int AddFavorite(FavoriteEntity favoriteEntity)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("FavoriteInfo.AddNew");
            return dataCommand.ExecuteScalar<int>(favoriteEntity);
        }

        public void DeleteFavorite(int id)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("FavoriteInfo.Delete");
            dataCommand.ExecuteNonQuery(new { TransactionNumber = id });
        }

        public IEnumerable<FavoriteEntity> GetFavorites(string userID)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("FavoriteInfo.GetList");
            return dataCommand.ExecuteEntityList<FavoriteEntity>(new { UserID = userID });
        }

        public IEnumerable<CategoryEntity> GetFavoritesAsCat(string userID)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("FavoriteInfo.GetCategory");
            return dataCommand.ExecuteEntityList<CategoryEntity>(new { UserID = userID });
        }
    }
}
