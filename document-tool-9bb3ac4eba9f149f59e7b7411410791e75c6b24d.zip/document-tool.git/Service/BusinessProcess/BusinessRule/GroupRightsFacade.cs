﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using BusinessProcess.Models;
using Newegg.API.Client;
using Newegg.Oversea.DataAccess;
using ServiceDefinetion;

namespace BusinessProcess.BusinessRule
{
    public class GroupRightsFacade
    {
        public List<UserRightsEntity> GetGroupRights(string uid)
        {
            var adGroups = GetUserFromAD(uid);
            if (adGroups == null || adGroups.Groups == null || adGroups.Groups.Count == 0)
            {
                return null;
            }

            CustomDataCommand dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GroupRights.GetGroupRights");
            List<UserRightsEntity> rights = null;
            using (DynamicQuerySqlBuilder sqlBuilder = new DynamicQuerySqlBuilder(
                dataCommand.CommandText, dataCommand, null, "ORDER BY 1"))
            {
                //条件参数
                if (adGroups.Groups.Count > 0)
                {
                    sqlBuilder.ConditionConstructor.AddInCondition<string>(QueryConditionRelationType.AND,
                        "[GroupName]", DbType.AnsiString, adGroups.Groups);
                }

                //查询数据
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
                rights = dataCommand.ExecuteEntityList<UserRightsEntity>();
            }

            rights.ForEach(r => r.UserID = uid);

            return rights;
        }

        public AdUserInfo GetUserFromAD(string userName)
        {
            if (userName.StartsWith("[") && userName.EndsWith("]")) return null;

            RestAPIClient client = APPConfig.GetAPIClient();
            try
            {
                return client.Get<AdUserInfo>("/user", new AdUserInfo { UserName = userName });
            }
            catch (WebServiceException wse)
            {
                if (wse.StatusCode == (int)HttpStatusCode.NotFound)
                {
                    return null;
                }
                throw;
            }
        }
    }
}
