﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using Newegg.Oversea.DataAccess;
using System.Transactions;
using System.Data;

namespace BusinessProcess.BusinessRule
{
    public class UserRightsFacade
    {
        public RightsType GetUserRights(string uid, out List<UserRightsEntity> rights)
        {
            //获取组权限
            GroupRightsFacade groupRightsFacade = new GroupRightsFacade();
            List<UserRightsEntity> groupRights = groupRightsFacade.GetGroupRights(uid);
            if (groupRights == null) groupRights = new List<UserRightsEntity>();

            //获取用户权限
            DataCommand dataCommand = DataCommandManager.GetDataCommand("UserRights.GetUserRights");
            rights = dataCommand.ExecuteEntityList<UserRightsEntity>(new { UserID = uid });
            if (rights == null) rights = new List<UserRightsEntity>();

            //合并权限
            rights.AddRange(groupRights);

            RightsType userType = RightsType.General;
            if (rights == null)
            {
                userType = RightsType.General;
            }

            if (rights.Exists(r => r.RootID == 0))
            {
                userType = RightsType.Admin;
            }
            else if (rights.Exists(r => r.IsOwner))
            {
                userType = RightsType.DomainOwner;
            }
            else if (rights == null || rights.Count == 0)
            {
                userType = RightsType.General;
            }
            else
            {
                userType = RightsType.AuthUser;
            }

            return userType;
        }

        public void AddUserRights(List<UserRightsEntity> rights, string uid)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                CustomDataCommand dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("UserRights.Delete");
                using (DynamicQuerySqlBuilder sqlBuilder = new DynamicQuerySqlBuilder(
                    dataCommand.CommandText, dataCommand, null, "ORDER BY 1"))
                {
                    //条件参数
                    if (rights.Count > 0)
                    {
                        sqlBuilder.ConditionConstructor.AddInCondition<int>(QueryConditionRelationType.AND,
                            "[RootID]", DbType.Int32, (from r in rights select r.RootID).ToList());
                    }

                    sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND,
                        "[UserID]", DbType.AnsiString, "@UserID", QueryConditionOperatorType.Equal, uid);

                    //查询数据
                    dataCommand.CommandText = sqlBuilder.BuildQuerySql();
                    dataCommand.ExecuteNonQuery();
                }

                foreach (var right in rights)
                {
                    DataCommand dataCommand_Add = DataCommandManager.GetDataCommand("UserRights.AddNew");
                    dataCommand_Add.ExecuteNonQuery(right);
                }

                scope.Complete();
            }
        }

        public UserOperationRights GetUserOperationRightsById(string uid)
        {
            PrivilegeFacade privilegeFacade = new PrivilegeFacade();
            var categoryPrivileges = privilegeFacade.GetCategoryPrivilegeList(uid);

            List<int> ownerCategory = new List<int>();
            RightsType type = privilegeFacade.GetRightsType(categoryPrivileges, ref ownerCategory);

            UserOperationRights uor = new UserOperationRights();
            if (type == RightsType.Admin)
            {
                uor.IsAdmin = true;
            }
            else if (type == RightsType.DomainOwner)
            {
                    uor.IsOwner = true;
                    uor.OwnerCategoryID = ownerCategory;
            }

            return uor;
        }

    }

    public enum RightsType
    {
        Admin,
        DomainOwner,
        General,
        AuthUser,
    }
}
