﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessProcess.Models;
using Newegg.Oversea.DataAccess;
using ServiceDefinetion;
using System.Transactions;
using Newegg.API.Client;
using BusinessProcess.Utilities;
using System.Net;

namespace BusinessProcess.BusinessRule
{
    public class PrivilegeFacade
    {
        /// <summary>
        /// 更新权限数据
        /// </summary>
        /// <param name="privileges"></param>
        public void Update(List<PrivilegeInfo> privileges)
        {
            var priGroups = from pri in privileges
                            group pri by pri.AcctName into g
                            select new { AcctName = g.Key, AcctType = g.FirstOrDefault().AcctType };

            using (TransactionScope scope = new TransactionScope())
            {
                //删除原有数据
                foreach (var prig in priGroups)
                {
                    DataCommand dataCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.Delete");
                    dataCommand.ExecuteNonQuery(prig);
                }

                //重新写入
                foreach (var pri in privileges)
                {
                    DataCommand addCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.AddNew");
                    addCommand.ExecuteNonQuery(pri);
                }

                scope.Complete();
            }
        }

        /// <summary>
        /// 删除指定用户的权限数据
        /// </summary>
        /// <param name="acctType"></param>
        /// <param name="acctName"></param>
        public void Delete(PrivilegeAcctType acctType, string acctName)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.Delete");
            dataCommand.ExecuteNonQuery(new { AcctName = acctName, AcctType = acctType });
        }

        public List<PrivilegeInfo> GetPrivilegeListByUserSelf(string userID)
        {
            //userID = "zh61";
            //获取权限列表
            DataCommand dataCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.GetList");
            return dataCommand.ExecuteEntityList<PrivilegeInfo>(new { UserID = userID, GroupNames = string.Empty });
        }

        public List<PrivilegeInfo> GetPrivilegeListByGroupSelf(string groupNames)
        {
            //获取权限列表
            //groupNames = "* GP team mis nesc cd fin";
            DataCommand dataCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.GetList");
            return dataCommand.ExecuteEntityList<PrivilegeInfo>(new { UserID = string.Empty, GroupNames = groupNames });
        }

        /// <summary>
        /// 获取指定的user的权限列表
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<PrivilegeInfo> GetPrivilegeList(string userID)
        {
            //从域服务器中获取用户对应的邮件组列表
            string groupNames = string.Empty;
            var adGroups = new GroupRightsFacade().GetUserFromAD(userID);
            if (!(adGroups == null || adGroups.Groups == null || adGroups.Groups.Count == 0))
            {
                groupNames = string.Join(",", adGroups.Groups);
            }

            //获取权限列表
            DataCommand dataCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.GetList");
            return dataCommand.ExecuteEntityList<PrivilegeInfo>(new { UserID = userID, GroupNames = groupNames });
        }

        public PrivilegeAcctType? GetAcctType(string acctName)
        {
            RestAPIClient client = APPConfig.GetAPIClient();

            if (ADHelper.IsExistUser(acctName))
            {
                return PrivilegeAcctType.User;
            }

            if (ADHelper.IsExistGroup(acctName))
            {
                return PrivilegeAcctType.Group;
            }

            return null;
        }

        /// <summary>
        /// 获取指定的category的权限列表
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<PrivilegeInfo> GetListByCategoryID(int categoryID)
        {
            //获取权限列表
            DataCommand dataCommand = DataCommandManager.GetDataCommand("PrivilegeInfo.GetListByCategoryID");
            return dataCommand.ExecuteEntityList<PrivilegeInfo>(new { CategoryID = categoryID });
        }

        /// <summary>
        /// 按指定user获取category和权限的映射关系
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<CategoryPrivilegeInfo> GetCategoryPrivilegeList(string userID)
        {
            //获取指定user的权限列表
            var privileges = GetPrivilegeList(userID);
            if (privileges == null) return null;

            //聚合操作，按category的将权限叠加
            List<CategoryPrivilegeInfo> list = new List<CategoryPrivilegeInfo>();
            foreach (var privilege in privileges)
            {
                var existsCategory = list.Where(p => p.CategoryID == privilege.CategoryID).FirstOrDefault();
                if (existsCategory == null)
                {
                    CategoryPrivilegeInfo cpi = new CategoryPrivilegeInfo()
                    {
                        CategoryID = privilege.CategoryID,
                        Permission = privilege.Permission
                    };
                    list.Add(cpi);
                }
                else
                {
                    existsCategory.Permission = existsCategory.Permission | privilege.Permission;
                }
            }

            return list;
        }

        /// <summary>
        /// 按权限列表获取角色类型
        /// </summary>
        /// <param name="categoryPrivileges"></param>
        /// <param name="ownerCategory"></param>
        /// <returns></returns>
        public RightsType GetRightsType(List<CategoryPrivilegeInfo> categoryPrivileges, ref List<int> ownerCategory)
        {
            RightsType userType = RightsType.General;

            //没有设置权限为普通用户
            if (categoryPrivileges == null || categoryPrivileges.Count == 0)
            {
                userType = RightsType.General;
            }

            //存在categoryID为0的节点为超级管理员
            else if (categoryPrivileges.Exists(cp => cp.CategoryID == 0))
            {
                userType = RightsType.Admin;
            }

            //存在owner权限为domain管理员
            else if (categoryPrivileges.Exists(cp => (cp.Permission & PrivilegeAction.Owner) == PrivilegeAction.Owner))
            {
                ownerCategory = (from cp in categoryPrivileges
                                 where (cp.Permission & PrivilegeAction.Owner) == PrivilegeAction.Owner
                                 select cp.CategoryID
                                ).ToList();//TODO: 为了兼容性最稳健的方式是再加一个条件只获取顶节点
                userType = RightsType.DomainOwner;
            }

            //否则为授权用户
            else
            {
                userType = RightsType.AuthUser;
            }

            return userType;
        }

        /// <summary>
        /// 过滤权限数据，剔除没有权限的category
        /// </summary>
        /// <param name="categories"></param>
        /// <param name="categoryPrivileges"></param>
        public void Filter(List<CategoryEntity> categories, List<CategoryPrivilegeInfo> categoryPrivileges)
        {
            if (categories == null) return;
            if (categoryPrivileges == null) return;

            SetTreePrivilege(categories, categoryPrivileges);

            List<int> ownerCategory = new List<int>();
            RightsType type = GetRightsType(categoryPrivileges, ref ownerCategory);
            switch (type)
            {
                case RightsType.Admin:
                    FilterForAdmin(categories);
                    break;
                case RightsType.General:
                    FilterForGeneral(categories);
                    break;
                case RightsType.AuthUser:
                case RightsType.DomainOwner:
                    FilterForAuth(categories);
                    break;
                default:
                    throw new NotSupportedException();
            }
        }

        /// <summary>
        /// 将权限关联到category
        /// </summary>
        /// <param name="categories"></param>
        /// <param name="categoryPrivileges"></param>
        private void SetTreePrivilege(List<CategoryEntity> categories, List<CategoryPrivilegeInfo> categoryPrivileges)
        {
            foreach (var category in categories)
            {
                var cp = categoryPrivileges.FirstOrDefault(cpt => cpt.CategoryID == category.CategoryId);
                if (cp != null)
                {
                    category.Permission = cp.Permission;
                }

                //递归到每一层
                if (category.SubCategories != null)
                {
                    SetTreePrivilege(category.SubCategories, categoryPrivileges);
                }
            }
        }

        private void FilterForAdmin(List<CategoryEntity> categories)
        {
            //对于Owner私有的Category,默认情况下管理员也无权查看
            //除非是管理员自己的私有Category，或者owner授予了权限
            categories.RemoveAll(c => c.IsPrivate.HasValue
                && c.IsPrivate.Value
                && (!c.Permission.HasValue));

            categories.RemoveAll(c => c.IsPrivate.HasValue 
                && c.IsPrivate.Value 
                && (!((c.Permission.Value & PrivilegeAction.View) == PrivilegeAction.View)));

            foreach (var category in categories)
            {
                category.AuthEditResult = false;
                category.AuthViewResult = false;

                //递归到每一层
                if (category.SubCategories != null)
                {
                    FilterForAdmin(category.SubCategories);
                }
            }
        }

        private void FilterForGeneral(List<CategoryEntity> categories)
        {
            //递归到每一层 如果节点验证编辑和显示字段为false，则可以显示
            //为true则不能显示
            //为null需检查节点权限，如已设置则不能显示，未设置可以显示 

            CheckTreeVisible(categories);

            categories.RemoveAll(c => c.IsAuthShow.HasValue && c.IsAuthShow.Value);
            foreach (var category in categories)
            {
                if (category.IsAuthEdit.HasValue)
                {
                    category.AuthEditResult = category.IsAuthEdit.Value;
                }
                else
                {
                    if (category.Permission.HasValue)
                    {
                        category.AuthEditResult = !((category.Permission.Value & PrivilegeAction.Edit) == PrivilegeAction.Edit);
                    }
                    else
                    {
                        category.AuthEditResult = false;
                    }
                }

                if (category.IsAuthShow.HasValue)
                {
                    category.AuthViewResult = category.IsAuthShow.Value;
                }
                else
                {
                    if (category.Permission.HasValue)
                    {
                        category.AuthViewResult = !((category.Permission.Value & PrivilegeAction.View) == PrivilegeAction.View);
                    }
                    else
                    {
                        category.AuthViewResult = false;
                    }
                }

                //递归到每一层
                if (category.SubCategories != null)
                {
                    FilterForGeneral(category.SubCategories);
                }
            }
        }

        private void FilterForAuth(List<CategoryEntity> categories)
        {
            CheckTreeVisible(categories);

            foreach (var category in categories)
            {
                if (category.Permission.HasValue)
                {
                    if ((category.Permission & PrivilegeAction.Owner) == PrivilegeAction.Owner)
                    {
                        category.AuthViewResult = false;
                        category.AuthEditResult = false;
                    }
                    else
                    {
                        category.AuthViewResult = !((category.Permission & PrivilegeAction.View) == PrivilegeAction.View);
                        category.AuthEditResult = !((category.Permission & PrivilegeAction.Edit) == PrivilegeAction.Edit);
                    }
                }
                else
                {
                    //Privilege没有设置权限，且category没有要求验证权限(IsAuthEdit,IsAuthShow)，则可见可编辑(AuthEditResult = false)
                    if (category.IsAuthEdit.HasValue)
                    {
                        category.AuthEditResult = category.IsAuthEdit.Value;
                    }
                    else
                    {
                        category.AuthEditResult = false;
                    }

                    if (category.IsAuthShow.HasValue)
                    {
                        category.AuthViewResult = category.IsAuthShow.Value;
                    }
                    else
                    {
                        category.AuthViewResult = false;
                    }
                }
            }

            //移除不可见对象
            categories.RemoveAll(c => (c.Permission & PrivilegeAction.List) != PrivilegeAction.List);

            foreach (var category in categories)
            {
                //递归到每一层
                if (category.SubCategories != null)
                {
                    FilterForAuth(category.SubCategories);
                }
            }
        }

        private void CheckTreeVisible(List<CategoryEntity> categories)
        {
            //遍历所有节点，确保有权限的节点可见
            foreach (var category in categories)
            {
                //不验证权限的category自动获得查看和修改权限
                if (category.IsAuthShow.HasValue && !category.IsAuthShow.Value)
                {
                    AppendPermission(category, PrivilegeAction.View);
                }
                if (category.IsAuthEdit.HasValue && !category.IsAuthEdit.Value)
                {
                    AppendPermission(category, PrivilegeAction.Edit);
                }

                //如果当前节点未设置权限，则同父节点的权限一致
                //如果父节点只有List权限，则是同级其它子节点可见需要设置，不能再传递给当前子节点
                if ((!category.Permission.HasValue)
                    && category.Parent != null
                    && category.Parent.Permission != null
                    && category.Parent.Permission != PrivilegeAction.List)
                {
                    category.Permission = category.Parent.Permission;
                }

                if (category.Permission.HasValue)
                {
                    category.Permission = category.Permission | PrivilegeAction.List;
                    SetParentVisible(category);
                }

                if (category.SubCategories != null)
                {
                    CheckTreeVisible(category.SubCategories);
                }
            }
        }

        //设置指定节点的所有祖先节点可见
        private void SetParentVisible(CategoryEntity category)
        {
            if (category == null) return;
            if (category.Parent == null) return;

            AppendPermission(category.Parent, PrivilegeAction.List);

            SetParentVisible(category.Parent);
        }

        private void AppendPermission(CategoryEntity category, PrivilegeAction appendAction)
        {
            if (!category.Permission.HasValue)
            {
                category.Permission = appendAction;
            }
            else
            {
                category.Permission = category.Permission | appendAction;
            }
        }

    }
}
