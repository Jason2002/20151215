﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceDefinetion;
using BusinessProcess.Utilities;
using SolrNet;
using System.Configuration;
using Microsoft.Practices.ServiceLocation;
using SolrNet.Attributes;
using SolrNet.Commands.Parameters;
using Newegg.Oversea.DataAccess;
using System.Transactions;
using BusinessProcess.Models;

namespace BusinessProcess.BusinessRule
{
    public class AttachmentFacade
    {
        private static bool _isFirstLoad = true;

        public void AddAttachment(int documentId, AttachmentEntity entity)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                DataCommand dataCommand = DataCommandManager.GetDataCommand("AttachmentInfo.AddNew");
                entity.AttachmentId = dataCommand.ExecuteScalar<int>(entity);

                dataCommand = DataCommandManager.GetDataCommand("AttachmentDocument.AddNew");
                dataCommand.ExecuteNonQuery(new
                {
                    AttachmentId = entity.AttachmentId,
                    DocumentId = documentId,
                    EditUser = entity.EditUser,
                    EditDate = entity.EditDate
                });

                scope.Complete();
            }
        }

        public void AddAttachmentDocument(AttachmentDocumentEntity entity)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("AttachmentDocument.AddNew");
            dataCommand.ExecuteNonQuery(entity);
        }

        public List<int> Search(string keywords)
        {
            if (_isFirstLoad)
            {
                Startup.Init<AttachmentSolrInfo>(ConfigurationManager.AppSettings["solrAddress_Att"]);
                _isFirstLoad = false;
            }

            ISolrReadOnlyOperations<AttachmentSolrInfo> solr = ServiceLocator.Current.GetInstance<ISolrReadOnlyOperations<AttachmentSolrInfo>>();
            var result = solr.Query(new SolrQueryByField("metadata_all", keywords), new QueryOptions()
            {
                Start = 0,
                Rows = 100
            });

            if (result == null || result.Count == 0) return null;

            List<int> ids = (from a in result select a.AttachmentId).ToList();
            return ids;
        }

        public List<DocumentEntity> GetActiveDocumentByAttIds(List<int> attachmentIds)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("AttachmentInfo.GetActiveDocumentByAttIds");
            return dataCommand.ExecuteEntityList<DocumentEntity>(new { attachmentIds = string.Join(",", attachmentIds) });
        }

        public AttachmentEntity FindAttachmentByHash(string hashCode, string fileName)
        {
            //为了处理文件内容相同文件名字不同的情况下，客户端显示的URL相同的问题
            //这里增加了文件名的比较条件。
            DataCommand dataCommand = DataCommandManager.GetDataCommand("AttachmentInfo.FindAttachmentByHash");
            return dataCommand.ExecuteEntity<AttachmentEntity>(new { HashCode = hashCode, FileName = fileName.Trim() });
        }

        public AttachmentEntity GetAttachment(int attachmentId)
        {
            DataCommand dataCommand = DataCommandManager.GetDataCommand("AttachmentInfo.GetAttachment");
            return dataCommand.ExecuteEntity<AttachmentEntity>(new { AttachmentId = attachmentId });
        }
    }
}
