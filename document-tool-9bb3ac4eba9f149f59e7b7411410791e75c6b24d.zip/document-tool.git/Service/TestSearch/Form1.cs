﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BusinessProcess.Utilities;
using ServiceDefinetion;

namespace TestSearch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtKeywords.Text.Trim()))
            {
                MessageBox.Show("Please input keywords");
                return;
            }

            IEnumerable<DocumentEntity> results = new SearchHelper().Search(txtKeywords.Text.Trim());
            FormateResults(results);
        }

        private void FormateResults(IEnumerable<DocumentEntity> results)
        {
            if (results != null && results.Count() > 0)
            {
                string print = string.Format("Found document counts: {0}", results.Count()) + System.Environment.NewLine;
                results.ToList().ForEach(d =>
                    {
                        print += string.Format("Document ID: {0}", d.DocumentId) + System.Environment.NewLine;
                    });

                txtResults.Text = print;
            }
            else
            {
                txtResults.Text = "No search results found";
            }
        }
    }
}
