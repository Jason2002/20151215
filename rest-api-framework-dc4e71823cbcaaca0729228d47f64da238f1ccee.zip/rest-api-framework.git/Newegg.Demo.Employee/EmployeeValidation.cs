﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Validation;
using FluentValidation;
using Newegg.API.Interfaces;


namespace Newegg.Demo.Employee
{
    //public class AddressValidation : CustomerValidator<EmployeeAddress>
    //{
    //    public AddressValidation()
    //    {
    //        //RuleFor(a => a.Id).NotEmpty();
    //    }
    //}

    public class EmployeeValidation : CustomerValidator<Employee>, IMultipleLanguageValidation
    {
        public EmployeeValidation()
        {
            RuleSet(ApplyTo.Post | ApplyTo.Put,
                () =>
                {
                    RuleFor(e => e.Age, false).GreaterThan(0).InclusiveBetween(20, 35);

                    RuleFor(e => e.Id).GreaterThan(0)
                        .WithMessage("ID must be greater than 0, you input {0}", (e) => e.Id);

                    //RuleFor(e => e.AddressInfo).SetCollectionValidator(new AddressValidation());
                });

            //RuleSet(ApplyTo.Get,
            //    () =>
            //    {
            //        RuleFor(e => e.Name).NotNull().NotEmpty();

            //        RuleFor(e => e.Name).NotNullorEmpty();
            //    });
            
        }

        public string GetErrorMessage(object obj, string resourceCode)
        {
            if (!string.IsNullOrEmpty(resourceCode) && resourceCode == "InvalidEmail")
            {
                return string.Format(EmployeeErrorResource.ResourceManager
                    .GetString(resourceCode, new System.Globalization.CultureInfo(LanguageCode))
                    , ((Employee)obj).Email);
            }
            else
            {
                return string.Empty;
            }
        }

        public string LanguageCode
        {
            get;
            set;
        }
    }
}
