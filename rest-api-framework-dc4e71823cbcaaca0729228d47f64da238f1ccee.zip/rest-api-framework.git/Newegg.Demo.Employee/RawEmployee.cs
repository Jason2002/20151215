﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Exceptions;
using Newegg.API.Models;
using Newegg.API.Attributes;
using Newegg.API.Interfaces;
using System.IO;

namespace Newegg.Demo.Employee
{
    [RestService("/raw-employee")]
    public class RawEmployee : RawRequestDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }

    public class RawEmployeeService : RestServiceBase<RawEmployee>
    {
        public override object OnGet(RawEmployee request)
        {
            throw new HttpError("12323", "This is Test Error");
            return new RawEmployee { Id = 0, Name = "James" };
        }

        public override object OnPut(RawEmployee request)
        {
            //将原始request stream转换为string
            string rawString = this.RequestContext.GetInputStreamAsString();

            //获取原始request stream
            Stream rawStream = this.RequestContext.InputStream;

            return request;
        }

        public override object OnPost(RawEmployee request)
        {
            //将原始request stream转换为string
            string rawString = this.RequestContext.GetInputStreamAsString();

            //获取原始request stream
            Stream rawStream = this.RequestContext.InputStream;

            return request;
        }
    }
}
