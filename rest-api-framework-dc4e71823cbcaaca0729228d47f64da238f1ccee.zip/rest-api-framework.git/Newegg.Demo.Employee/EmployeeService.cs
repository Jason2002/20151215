﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using Newegg.API.Interfaces;
using Newegg.API.Cache;
using Newegg.API.Exceptions;
using Newegg.API.Models;
using Newegg.API.Common;
using Newegg.API.ServiceHost;
using System.Threading.Tasks;
using Newegg.API.Async;
using Newegg.API.HttpExtensions;
using Funq;
using ServiceStack.Text;

namespace Newegg.Demo.Employee
{
    public class TestAdapter : IContainerAdapter
    {

        public T Resolve<T>()
        {
            System.Diagnostics.Debug.WriteLine(typeof(T).Name);
            return default(T);
        }

        public T TryResolve<T>()
        {
            System.Diagnostics.Debug.WriteLine(typeof(T).Name);
            return default(T);
        }
    }

    public class EmployeeService : RestServiceBase<Employee>
    {
        protected override void OnBeforeExecute(Employee request)
        {
            if (request.Id > 0)
            {
                Employee employee = EmployeeDataSource.EmployeeData.FirstOrDefault(e => e.Id == request.Id);
                if (employee == null && this.RequestContext.ExecuteContext.HttpMethod != HttpMethods.Post)
                {
                    throw new HttpError("1001", "Employee not found");
                }
                else if (employee != null && this.RequestContext.ExecuteContext.HttpMethod == HttpMethods.Post)
                {
                    throw new HttpError("1002", "Employee exists");
                }
            }
            
        }

        public override object OnGet(Employee request)
        {
            //var link = new LinkHeader("/employee", LinkRelation.Self);
            //link.Title = "Employee";
            //link.ContentType = ContentType.Json;
            //this.RequestContext.AddLinkHeader(link);

            //return this.RequestContext.ReturnRedirectResponse("/employee/address");

            //return this.RequestContext.ReturnCreatedResponse("/employee/2");

            //return this.RequestContext.ReturnNoResponse();
            //throw new HttpError(HttpStatusCode.BadRequest, "1001", "this is for test ignore codes");
            //var authInfo = this.RequestContext.RequestAuth;
            //string userId = authInfo.UserId;
            
            if (request.Id > 0)
            {
                //var a = "\"Hello World\"";

                //var utf8Bytes = a.ToUtf8Bytes();
                //RequestContext.HttpRes.OutputStream.Write(utf8Bytes, 0, utf8Bytes.Length);
                //RequestContext.HttpRes.Close();
                //return a;
                return this.RequestContext.ToOptimizedResultUsingCache<Employee>(
                UrnId.Create<Employee>(request.Id.ToString()),
                TimeSpan.FromMinutes(20),
                () =>
                {
                    return EmployeeDataSource.EmployeeData.First(e => e.Id == request.Id);
                });
                //DateTime test = DateTime.MaxValue;
                //var final = test.Subtract(DateTime.Now).TotalHours;
                //employee.Handler = new Handler
                //{
                //    ActionMemo = "Create a new employee",
                //    ActionTime = DateTime.Now,
                //    ActionType = "Create",
                //    ActionUserID = "jy25",
                //    ClientTag = "Tag",
                //    SystemSource = "Demo API",
                //};
            }
            else
            {
                if (!string.IsNullOrEmpty(this.RequestContext.ExecuteContext.View)
                    && this.RequestContext.ExecuteContext.View.ToLower() == "dropdown")
                {
                    var list = from em in EmployeeDataSource.EmployeeData
                               select new EmployeeSummary
                               {
                                   Id = em.Id,
                                   Name = em.Name
                               };
                    if (list.Count() > 0)
                    {
                        return list.ToList();
                    }
                }
                var page = this.RequestContext.RequestPageInfo;
                if (page == null)
                {
                    page = new PageInfo { PageIndex = 0, PageSize = 10, SortFields = "Id", Sort="asc" };
                }
                return EmployeeDataSource.EmployeeData.GetSortedList<Employee>(page.SortFields, page.Sort)
                    .Skip(page.PageIndex * page.PageSize).Take(page.PageSize).ToList();
            }
        }

        public override object OnPost(Employee request)
        {
            //request.EditUser = this.RequestContext.UserId;
            request.EditDate = DateTime.Now;
            EmployeeDataSource.EmployeeData.Add(request);

            return this.RequestContext.ToOptimizedResultUsingCache<Employee>(
                    UrnId.Create<Employee>(request.Id.ToString()),
                    TimeSpan.FromMinutes(20),
                    () => request);
        }

        public override object OnPut(Employee request)
        {
            if (request.Id == 0) return default(Employee);
            string cacheKey = UrnId.Create<Employee>(request.Id.ToString());
            this.RequestContext.CheckCacheConflict(cacheKey);

            Employee employee = EmployeeDataSource.EmployeeData.First(e => e.Id == request.Id);
            employee.Name = request.Name;
            employee.Age = request.Age;
            employee.Email = request.Email;
            //employee.EditUser = this.RequestContext.UserId;
            employee.EditDate = DateTime.Now;
            this.RequestContext.UpdateCache<Employee>(cacheKey, employee, TimeSpan.FromMinutes(20));
            return this.RequestContext.ToOptimizedResultUsingCache<Employee>(
                    UrnId.Create<Employee>(request.Id.ToString()),
                    TimeSpan.FromMinutes(20),
                    () =>
                    {
                        return employee;
                    });
        }

        public override object OnDelete(Employee request)
        {
            string cacheKey = UrnId.Create<Employee>(request.Id.ToString());
            this.RequestContext.CheckCacheConflict(cacheKey);

            Employee employee = EmployeeDataSource.EmployeeData.First(e => e.Id == request.Id);
            EmployeeDataSource.EmployeeData.Remove(employee);
            this.RequestContext.RemoveFromCache(cacheKey);

            //testException();
            return RequestContext.ReturnNoResponse();


        }

        private void testException()
        {
            try
            {
                throw new ArgumentException("This is origin exception");
            }
            catch (Exception ex)
            {
                var exx = new Exception("I am Throw", ex);
                throw exx;
            }
            
        }

    }
}
