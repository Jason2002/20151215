﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using Newegg.API.Models;

namespace Newegg.Demo.Employee
{

    [ResponseType(typeof(Employee))]
    
    public class EmployeeSummary
    {
        public int Id { get; set; }
     
        public string Name { get; set; }
    }

    [ResponseType(typeof(Employee))]
    [RestService("/employee")]
    [RestService("/employee/{Id}")]
    //[EmployeeResponseFilter]
    public class Employee
    {
        //public Handler Handler { get; set; }

        public int Id { get; set; }
     
        public string Name { get; set; }
     
        public int Age { get; set; }

        //public decimal? Amount { get; set; }

        //public bool ShouldSerializeAmount { get { return Amount.HasValue; } }

        //public int? MyProperty { get; set; }

        //public bool ShouldSerializeMyProperty() { return MyProperty.HasValue; }
     
        public string Email { get; set; }
     
        public string EditUser { get; set; }
     
        public DateTime EditDate { get; set; }

        public Guid TestID { get; set; }

        public List<EmployeeAddress> AddressInfo { get; set; }
    }

    //[RestService("/employee/address")]
    //[RestService("/employee/{Id}/address")]
    //[ResponseType(typeof(EmployeeAddress))]
    public class EmployeeAddress
    {

        public int Id { get; set; }

        public string Address { get; set; }

        public decimal? Amount { get; set; }

        //public bool ShouldSerializeAmount { get { return Amount.HasValue; } }
    }
}
