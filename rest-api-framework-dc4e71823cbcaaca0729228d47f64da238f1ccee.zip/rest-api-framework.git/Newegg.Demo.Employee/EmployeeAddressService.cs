﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;

namespace Newegg.Demo.Employee
{
    //public class EmployeeAddressService : RestServiceBase<EmployeeAddress>
    //{
    //    public override object OnGet(EmployeeAddress request)
    //    {
    //        return new EmployeeAddress { Id = request.Id, Address = "Demo Address" }; 
    //    }
    //}
}
