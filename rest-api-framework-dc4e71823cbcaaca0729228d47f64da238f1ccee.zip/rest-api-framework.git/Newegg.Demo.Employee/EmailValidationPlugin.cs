﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.API.ServiceHost;
using System.Text.RegularExpressions;

namespace Newegg.Demo.Employee
{
    public class EmailValidationPlugin : IPlugin
    {
        public void Register(AppConfig appHost)
        {
            appHost.Register<EmailValidationPlugin>(this);
        }

        public bool ValidationEmail(string email)
        {
            Regex regex = new Regex(@"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$");
            Match match = regex.Match(email);
            if (match.Success && match.Index == 0 && match.Length == email.Length)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
