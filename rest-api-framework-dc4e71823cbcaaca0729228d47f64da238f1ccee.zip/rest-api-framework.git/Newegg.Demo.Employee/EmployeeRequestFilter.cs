﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;
using Newegg.API.Exceptions;
using Newegg.API.Common;
using Newegg.API.ServiceHost;
using Newegg.API.Logging;
using Newegg.API.HttpExtensions;

namespace Newegg.Demo.Employee
{
    public class EmployeeRequestFilterAttribute : Attribute, IHasRequestFilter
    {
        public int Priority
        {
            get { return 1; }
        }

        public void RequestFilter(API.HttpExtensions.HttpRequestWrapper req,
            API.HttpExtensions.HttpResponseWrapper res, object requestDto)
        {
            
            if (req.HttpMethod == HttpMethods.Post || req.HttpMethod == HttpMethods.Put)
            {
                Employee employee = requestDto as Employee;
                if (employee != null)
                {
                    if (employee.Id < 0)
                    {
                        throw new HttpError("1003", "Employee ID must be greater than 0");
                    }
                    if (employee.Age < 20 || employee.Age > 35)
                    {
                        throw new HttpError("1004", "Employee Age must be between 20 and 35");
                    }
                    

                    //EmailValidationPlugin validator = AppConfig.Instance.TryResolve<EmailValidationPlugin>();
                    //if (!validator.ValidationEmail(employee.Email))
                    //{
                    //    throw new HttpError("1005", "Invalid email address");
                    //}

                }
            }
        }
    }

    public class EmployeeResponseFilterAttribute : Attribute, IHasResponseFilter
    {
        public int Priority
        {
            get { return 1; }
        }

        public void ResponseFilter(API.HttpExtensions.HttpRequestWrapper req, API.HttpExtensions.HttpResponseWrapper res, object response)
        {
            res.StatusCode = (int)System.Net.HttpStatusCode.BadRequest;
            res.WriteTextToResponse("{\"Code\":400,\"Description\":\"缺少或无效的参数: department.\",\"Data\":null}", "text/json");
            res.Close();
        }
    }
}
