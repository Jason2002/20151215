﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Reflection;

namespace Newegg.Demo.Employee
{
    public static class IEnumerableExtension
    {
        public static IEnumerable<T> GetSortedList<T>(this IEnumerable sourceList, string sortField, string sort)
        {
            IEnumerable<T> result = sourceList as IEnumerable<T>;
            try
            {
                if (result == null)
                {
                    return null;
                }

                if (!string.IsNullOrEmpty(sortField))
                {
                    string[] paramPath = sortField.Split('.');
                    Func<T, object> getChildPropertyValue = delegate(T item)
                    {
                        object fromObject = item;
                        foreach (string attributeName in paramPath)
                        {
                            if (string.IsNullOrEmpty(attributeName))
                            {
                                continue;
                            }
                            PropertyInfo childInfo = fromObject.GetType().GetProperty(attributeName);
                            if (childInfo == null)
                            {
                                return null;
                            }
                            fromObject = childInfo.GetValue(fromObject, null);
                        }
                        return fromObject;
                    };

                    switch (sort.ToLower())
                    {
                        case "desc":
                            result = result.OrderByDescending(getChildPropertyValue).ToList();
                            break;
                        default:
                            result = result.OrderBy(getChildPropertyValue).ToList();
                            break;
                    }

                }
            }
            catch
            {
            }
            return result;
        }
    }
}
