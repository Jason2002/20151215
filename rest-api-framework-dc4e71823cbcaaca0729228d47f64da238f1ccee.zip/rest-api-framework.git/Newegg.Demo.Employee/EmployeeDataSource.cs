﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Demo.Employee
{
    public class EmployeeDataSource
    {
        public static List<Employee> EmployeeData;
        static Random random = new Random();

        static EmployeeDataSource()
        {
            SetData();
        }

        private static void SetData()
        {
            EmployeeData = new List<Employee>();
            for (int i = 0; i < 100; i++)
            {
                var newEmp = GetNewEmployee();
                if (!EmployeeData.Exists(e => e.Id == newEmp.Id))
                {
                    EmployeeData.Add(newEmp);
                }
            }
        }

        private static Employee GetNewEmployee()
        {
            Employee e = new Employee();
            e.Id = random.Next(0, 100);
            e.Age = random.Next(20, 35);
            //e.Amount = 10M;
            e.Name = "DemoName, " + e.Id;
            e.Email = e.Name + "@newegg.com";
            e.EditUser = "jy25";
            e.EditDate = DateTime.Now;
            e.TestID = Guid.NewGuid();
            //e.AddressInfo = new List<EmployeeAddress>
            //{
            //    new EmployeeAddress{Amount = 30M}
            //};
            return e;
        }

        public static string AsciiToStr(int asciiCode)
        {
            if (asciiCode < 0 || asciiCode > 255) return null;

            System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();
            byte[] byteArray = new byte[] { (byte)asciiCode };
            string asciiStr = asciiEncoding.GetString(byteArray);

            System.Diagnostics.Debug.WriteLine(asciiStr);
            return asciiStr;
        }
    }
}
