﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Newegg.API.Common;
using Newegg.API.Exceptions;
using Newegg.API.ServiceHost;
using ServiceStack.Text;

namespace Newegg.Demo.Employee
{
    public class AppInit : AppHostBase
    {
        public override void Init()
        {
            this.RegisterValidators(typeof(Employee).Assembly);
            this.SetDefaultPageInfo(20, 1, 100);

            //this.RegisterIgnoreLoggingException(typeof(ValidationError));

            this.RegisterIgnoreLoggingStatusCode(HttpStatusCode.BadRequest);

            this.RequestFilters.Insert(0, (req, res, obj) =>
            {
                if (req.Headers[HttpHeaders.Origin] != null)
                {
                    res.AddHeader(HttpHeaders.AllowOrigin, req.Headers[HttpHeaders.Origin]);
                }
                if (req.Headers[HttpHeaders.RequestHeaders] != null)
                {
                    res.AddHeader(HttpHeaders.AllowHeaders, req.Headers[HttpHeaders.RequestHeaders]);
                }
            });
        }
    }
}
