﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Client
{
    public static class UriHelper
    {
        public static bool HasQueryString(this string uri)
        {
            if (uri.Length == 1 && (uri == "?" || uri == "&"))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
