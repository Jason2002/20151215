﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Newegg.API.Client
{
    public class CommonQueryString
    {
        public string View { get; set; }

        public string Expand { get; set; }

        public string SearchText { get; set; }

        [IgnoreDataMember]
        public bool HasContent
        {
            get
            {
                return !string.IsNullOrEmpty(View)
                    || !string.IsNullOrEmpty(Expand)
                    || !string.IsNullOrEmpty(SearchText);
            }
        }
    }
}
