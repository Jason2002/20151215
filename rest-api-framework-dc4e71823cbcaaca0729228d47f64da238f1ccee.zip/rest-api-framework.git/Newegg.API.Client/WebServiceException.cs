﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceStack.Text;

namespace Newegg.API.Client
{
    public class WebServiceException
            : Exception
    {
        public WebServiceException() { }
        public WebServiceException(string message) : base(message) { }
        public WebServiceException(string message, Exception innerException) : base(message, innerException) { }

        public int StatusCode { get; set; }

        public string StatusDescription { get; set; }

        public ResponseStatus ResponseDto { get; set; }

        private string responseCode;

        private void ParseResponseDto()
        {
            if (ResponseDto == null)
            {
                responseCode = StatusDescription;
                message = base.Message;
                serverStackTrace = base.StackTrace;
                return;
            }
            else
            {
                responseCode = ResponseDto.ResponseCode;
                message = ResponseDto.Message;
                serverStackTrace = ResponseDto.StackTrace;
            }
        }

        public string ResponseCode
        {
            get
            {
                if (responseCode == null)
                {
                    ParseResponseDto();
                }
                return responseCode;
            }
        }

        private string message;
        public string Message
        {
            get
            {
                if (message == null)
                {
                    ParseResponseDto();
                }
                return message;
            }
        }

        private string serverStackTrace;
        public string ServerStackTrace
        {
            get
            {
                if (serverStackTrace == null)
                {
                    ParseResponseDto();
                }
                return serverStackTrace;
            }
        }

        public bool HasValidationError
        {
            get
            {
                if (ResponseDto != null && ResponseDto.ValidationErrors != null && ResponseDto.ValidationErrors.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public List<ValidationErrorResponse> ValidationErrors
        {
            get
            {
                if (HasValidationError)
                {
                    return ResponseDto.ValidationErrors;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
