﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using ServiceStack.Text;
using System.IO;
using System.Threading;
using System.Web;

namespace Newegg.API.Client
{
    public class RestAPIClient
    {
        #region Properties
        const int BufferSize = 4096;
        public string BaseUri { get; set; }
        public string ContentType { get; set; }
        public string ETag { get; set; }
        public CachePolicyType CachePolicy { get; set; }
        public PageInfo Page { get; set; }
        public string Language { get; set; }
        private bool m_handleByAsync = false;
        public string UserId { get; set; }
        public string Authorization { get; set; }
        private CommonQueryString m_commonQuery = new CommonQueryString();
        public string View
        {
            get
            {
                return m_commonQuery.View;
            }
            set
            {
                m_commonQuery.View = value;
            }
        }
        public string Expand
        {
            get
            {
                return m_commonQuery.Expand;
            }
            set
            {
                m_commonQuery.Expand = value;
            }
        }
        public string SearchText
        {
            get
            {
                return m_commonQuery.SearchText;
            }
            set
            {
                m_commonQuery.SearchText = value;
            }
        }
        public IWebProxy Proxy { get; set; }
        private TimeSpan? timeout;
        public TimeSpan? Timeout
        {
            get { return this.timeout; }
            set
            {
                this.timeout = value;
                //this.asyncClient.Timeout = value;
            }
        }

        private Dictionary<string, string> m_customHeaders; 
        
        public DecompressionMethods DecompressionType { get; set; }

        public Func<object, string> RawSerializeFn { get; set; }
        #endregion

        #region Ctor
        public RestAPIClient(string baseURI)
            : this(baseURI, ContentTypes.Json)
        {
        }

        public RestAPIClient(string baseURI, string contentType)
        {
            BaseUri = baseURI;
            ContentType = ContentTypes.GetContentType(contentType);
            CachePolicy = CachePolicyType.None;
        }
        #endregion

        #region Helper Method
        private string GetUrl(string relativeOrAbsoluteUrl)
        {
            return relativeOrAbsoluteUrl.StartsWith("http:")
                || relativeOrAbsoluteUrl.StartsWith("https:")
                     ? relativeOrAbsoluteUrl
                     : CombinePaths(relativeOrAbsoluteUrl);
        }

        private string CombinePaths(params string[] paths)
        {
            StringBuilder sb = new StringBuilder(BaseUri.TrimEnd('/', '\\'));
            foreach (var path in paths)
            {
                if (sb.Length > 0)
                    sb.Append("/");

                sb.Append(path.TrimStart('/', '\\'));
            }

            return sb.ToString();
        }

        private void SerializeToStream(object request, Stream stream)
        {
            if (RawSerializeFn != null)
            {
                var writer = new StreamWriter(stream, new UTF8Encoding(false));
                writer.Write(RawSerializeFn(request));
                writer.Flush();
            }
            else
            {
                switch (ContentType)
                {
                    case ContentTypes.Xml:
                        XmlSimpleSerializer.SerializeToStream(request, stream);
                        return;

                    case ContentTypes.Json:
                        JsonSerializer.SerializeToStream(request, stream);
                        return;

                    case ContentTypes.Jsv:
                        TypeSerializer.SerializeToStream(request, stream);
                        return;
                }
            }
            
        }

        private T DeserializeFromStream<T>(Stream stream)
        {
            switch (ContentType)
            {
                case ContentTypes.Xml:
                    return XmlSimpleSerializer.DeserializeFromStream<T>(stream);

                case ContentTypes.Json:
                    return JsonSerializer.DeserializeFromStream<T>(stream);

                case ContentTypes.Jsv:
                    return TypeSerializer.DeserializeFromStream<T>(stream);
            }
            return default(T);
        }

        private T DeserializeFromString<T>(string input)
        {
            switch (ContentType)
            {
                case ContentTypes.Xml:
                    return XmlSimpleSerializer.DeserializeFromString<T>(input);

                case ContentTypes.Json:
                    return JsonSerializer.DeserializeFromString<T>(input);

                case ContentTypes.Jsv:
                    return TypeSerializer.DeserializeFromString<T>(input);
            }
            return default(T);
        }

        private void SetPolicy(WebRequest request)
        {
            if (this.CachePolicy == CachePolicyType.IfMatch && !string.IsNullOrEmpty(ETag))
            {
                request.Headers.Add(HttpRequestHeader.IfMatch, ETag);
            }
            else if (this.CachePolicy == CachePolicyType.IfNoneMatch && !string.IsNullOrEmpty(ETag))
            {
                request.Headers.Add(HttpRequestHeader.IfNoneMatch, ETag);
            }
        }

        private string CreateQueryString(string httpMethod, object request, string uri)
        {
            string queryString = string.Empty;
            int queryStringIndex = uri.IndexOf('?');
            if (queryStringIndex == -1)
            {
                queryString = "?";
            }
            else
            {
                queryString = "&";
            }

            if (httpMethod == HttpMethod.Get || httpMethod == HttpMethod.Delete)
            {
                if (request != null)
                {
                    queryString += QueryStringSerializer.SerializeToString(request);
                }
                if (Page != null)
                {
                    var pageQueryString = QueryStringSerializer.SerializeToString(Page);
                    if (!string.IsNullOrEmpty(pageQueryString))
                    {
                        if (queryString.HasQueryString())
                        {
                            queryString += "&" + pageQueryString;
                        }
                        else
                        {
                            queryString += pageQueryString;
                        }
                    }
                }
            }

            if (m_commonQuery.HasContent)
            {
                var commonString = QueryStringSerializer.SerializeToString(m_commonQuery);
                if (queryString.HasQueryString())
                {
                    queryString += string.Format("&{0}", commonString);
                }
                else
                {
                    queryString += commonString;
                }
            }

            if (m_handleByAsync)
            {
                if (queryString.HasQueryString())
                {
                    queryString += "&async=true";
                }
                else
                {
                    queryString += "async=true";
                }
            }
            return queryString;
        }

        public void SetAuthorizationInfo(string appKey, string accessToken)
        {
            Authorization = appKey + "&" + accessToken;
        }

        public void SetOAuthToken(string accessToken)
        {
            Authorization = "Bearer " + accessToken;
        }

        public void AddCustomHeader(string name, string value)
        {
            if (m_customHeaders == null)
            {
                m_customHeaders = new Dictionary<string, string>();
            }
            m_customHeaders[name] = value;
        }

        public void ClearCustomHeader()
        {
            if (m_customHeaders == null || m_customHeaders.Count == 0)
            {
                return;
            }
            else
            {
                m_customHeaders.Clear();
            }
        }

        private void SetCustomHeaders(WebRequest request)
        {
            if (m_customHeaders == null || m_customHeaders.Count == 0)
            {
                return;
            }
            else
            {
                foreach (var key in m_customHeaders.Keys)
                {
                    request.Headers.Add(key, m_customHeaders[key]);
                }
            }
        }

        #endregion

        #region Sync Request

        private void HandleResponseException(Exception ex, string requestUri)
        {
            var webEx = ex as WebException;
            if (webEx != null && webEx.Status == WebExceptionStatus.ProtocolError)
            {
                var errorResponse = ((HttpWebResponse)webEx.Response);
                WebServiceException serviceEx = new WebServiceException(errorResponse.StatusDescription)
                {
                    StatusCode = (int)errorResponse.StatusCode,
                    StatusDescription = errorResponse.StatusDescription,
                };

                string message = string.Empty;
                using (var stream = errorResponse.GetResponseStream())
                {
                    using (var ms = new StreamReader(stream, new UTF8Encoding(false)))
                    {
                        message = ms.ReadToEnd();
                    }
                    try
                    {
                        serviceEx.ResponseDto = DeserializeFromString<ResponseStatus>(message);
                        if (serviceEx.ResponseDto.ResponseCode == null)
                        {
                            serviceEx.ResponseDto = new ResponseStatus
                            {
                                ResponseCode = serviceEx.StatusDescription,
                                Message = message,
                            };
                        }
                    }
                    catch (Exception innerEx)
                    {
                        // Oh, well, we tried
                        throw new WebServiceException(message, innerEx)
                        {
                            StatusCode = (int)errorResponse.StatusCode,
                            StatusDescription = errorResponse.StatusDescription,
                        };
                    }
                }
                //Escape deserialize exception handling and throw here
                throw serviceEx;
            }
            else
            {
                throw ex;
            }
        }

        private WebRequest SendRequest(string httpMethod, string requestUri, object request)
        {
            if (httpMethod == null)
                throw new ArgumentNullException("httpMethod");

            var queryString = CreateQueryString(httpMethod, request, requestUri);
            if (!string.IsNullOrEmpty(queryString))
            {
                requestUri += queryString;
            }

            var client = (HttpWebRequest)WebRequest.Create(requestUri);
            client.ServicePoint.Expect100Continue = false;
            client.Accept = ContentType;
            client.Method = httpMethod;
            client.AutomaticDecompression = DecompressionType;
            if (!string.IsNullOrEmpty(Language))
            {
                client.Headers.Add(HttpRequestHeader.AcceptLanguage, Language);
            }
            if (!string.IsNullOrEmpty(Authorization))
            {
                client.Headers.Add(HttpRequestHeader.Authorization, Authorization);
            }
            if (!string.IsNullOrEmpty(UserId))
            {
                client.Headers.Add("X-Client-UserId", UserId);
            }

            this.SetPolicy(client);
            SetCustomHeaders(client);
            if (Proxy != null) client.Proxy = Proxy;
            if (this.Timeout.HasValue) client.Timeout = (int)this.Timeout.Value.TotalMilliseconds;

            if (httpMethod != HttpMethod.Get && httpMethod != HttpMethod.Delete)
            {
                client.ContentType = ContentType;

                using (var requestStream = client.GetRequestStream())
                {
                    SerializeToStream(request, requestStream);
                }
            }

            return client;
        }

        private TResponse Send<TResponse>(string httpMethod, string relativeOrAbsoluteUrl, object request)
        {
            var requestUri = GetUrl(relativeOrAbsoluteUrl);
            var client = SendRequest(httpMethod, requestUri, request);

            try
            {
                var webResponse = client.GetResponse();
                using (var responseStream = webResponse.GetResponseStream())
                {
                    var response = DeserializeFromStream<TResponse>(responseStream);
                    if (!string.IsNullOrEmpty(webResponse.Headers["ETag"]))
                    {
                        ETag = webResponse.Headers["ETag"];
                    }
                    return response;
                }
            }
            catch (Exception ex)
            {
                HandleResponseException(ex, requestUri);
                return default(TResponse);
            }
        }

        public TResponse Get<TResponse>(string relativeOrAbsoluteUrl, object request, bool isAsyncService = false)
        {
            this.ETag = string.Empty;
            m_handleByAsync = isAsyncService;
            return Send<TResponse>(HttpMethod.Get, relativeOrAbsoluteUrl, request);
        }

        public TResponse Delete<TResponse>(string relativeOrAbsoluteUrl, object request, bool isAsyncService = false)
        {
            m_handleByAsync = isAsyncService;
            return Send<TResponse>(HttpMethod.Delete, relativeOrAbsoluteUrl, request);
        }

        public TResponse Post<TResponse>(string relativeOrAbsoluteUrl, object request, bool isAsyncService = false)
        {
            m_handleByAsync = isAsyncService;
            return Send<TResponse>(HttpMethod.Post, relativeOrAbsoluteUrl, request);
        }

        public TResponse Put<TResponse>(string relativeOrAbsoluteUrl, object request, bool isAsyncService = false)
        {
            m_handleByAsync = isAsyncService;
            return Send<TResponse>(HttpMethod.Put, relativeOrAbsoluteUrl, request);
        }

        #endregion

        #region Async Request

        private void SendAsync<TResponse>(string httpMethod, string relativeOrAbsoluteUrl, object request, Action<RequestResult<TResponse>> onFinish)
        {
            var requestUri = GetUrl(relativeOrAbsoluteUrl);

            var queryString = CreateQueryString(httpMethod, request, requestUri);
            if (!string.IsNullOrEmpty(queryString))
            {
                requestUri += queryString;
            }

            var webRequest = (HttpWebRequest)WebRequest.Create(requestUri);
            this.SetPolicy(webRequest);
            SetCustomHeaders(webRequest);
            var requestState = new RequestState<TResponse>
            {
                HttpMethod = httpMethod,
                Url = requestUri,
                WebRequest = webRequest,
                Request = request,
                OnFinish = onFinish
            };

            requestState.StartTimer(this.Timeout.GetValueOrDefault(TimeSpan.FromSeconds(60)));
            SendWebRequestAsync(httpMethod, request, requestState);
        }

        private void SendWebRequestAsync<TResponse>(string httpMethod, object request,
            RequestState<TResponse> requestState)
        {
            var webRequest = requestState.WebRequest;
            var httpGetOrDelete = (httpMethod == "GET" || httpMethod == "DELETE");
            webRequest.Accept = string.Format("{0}, */*", ContentType);
            webRequest.Method = httpMethod;
            webRequest.AutomaticDecompression = DecompressionType;
            if (!string.IsNullOrEmpty(Language))
            {
                webRequest.Headers.Add(HttpRequestHeader.AcceptLanguage, Language);
            }
            if (!string.IsNullOrEmpty(Authorization))
            {
                webRequest.Headers.Add(HttpRequestHeader.Authorization, Authorization);
            }
            if (!string.IsNullOrEmpty(UserId))
            {
                webRequest.Headers.Add("X-Client-UserId", UserId);
            }

            if (!httpGetOrDelete && request != null)
            {
                webRequest.ContentType = ContentType;
                webRequest.BeginGetRequestStream(RequestCallback<TResponse>, requestState);
            }
            else
            {
                webRequest.BeginGetResponse(ResponseCallback<TResponse>, requestState);
            }
        }

        private void RequestCallback<T>(IAsyncResult asyncResult)
        {
            var requestState = (RequestState<T>)asyncResult.AsyncState;
            try
            {
                var req = requestState.WebRequest;

                var postStream = req.EndGetRequestStream(asyncResult);
                SerializeToStream(requestState.Request, postStream);
                postStream.Close();
                requestState.WebRequest.BeginGetResponse(ResponseCallback<T>, requestState);
            }
            catch (Exception ex)
            {
                HandleResponseError(ex, requestState);
            }
        }

        private void ResponseCallback<T>(IAsyncResult asyncResult)
        {
            var requestState = (RequestState<T>)asyncResult.AsyncState;
            try
            {
                var webRequest = requestState.WebRequest;

                requestState.WebResponse = (HttpWebResponse)webRequest.EndGetResponse(asyncResult);

                // Read the response into a Stream object.
                var responseStream = requestState.WebResponse.GetResponseStream();
                requestState.ResponseStream = responseStream;

                responseStream.BeginRead(requestState.BufferRead, 0, BufferSize, ReadCallBack<T>, requestState);
                return;
            }
            catch (Exception ex)
            {
                HandleResponseError(ex, requestState);
            }
        }

        private void ReadCallBack<T>(IAsyncResult asyncResult)
        {
            var requestState = (RequestState<T>)asyncResult.AsyncState;
            try
            {
                var responseStream = requestState.ResponseStream;
                int read = responseStream.EndRead(asyncResult);

                if (read > 0)
                {
                    requestState.BytesData.Write(requestState.BufferRead, 0, read);
                    responseStream.BeginRead(
                        requestState.BufferRead, 0, BufferSize, ReadCallBack<T>, requestState);
                    return;
                }

                Interlocked.Increment(ref requestState.Completed);

                var response = default(T);
                try
                {
                    requestState.BytesData.Position = 0;
                    using (var reader = requestState.BytesData)
                    {
                        response = this.DeserializeFromStream<T>(reader);
                    }
                    if (!string.IsNullOrEmpty(((WebResponse)requestState.WebResponse).Headers["ETag"]))
                    {
                        ETag = ((WebResponse)requestState.WebResponse).Headers["ETag"];
                    }
                    RequestResult<T> result = new RequestResult<T> { Result = response };
                    requestState.HandleFinish(result);
                }
                catch (Exception ex)
                {
                    HandleResponseError(ex, requestState);
                }
                finally
                {
                    responseStream.Close();
                }
            }
            catch (Exception ex)
            {
                HandleResponseError(ex, requestState);
            }
        }

        private void HandleResponseError<TResponse>(Exception exception, RequestState<TResponse> requestState)
        {
            var webEx = exception as WebException;
            if (webEx != null && webEx.Status == WebExceptionStatus.ProtocolError)
            {
                var errorResponse = ((HttpWebResponse)webEx.Response);

                var serviceEx = new WebServiceException(errorResponse.StatusDescription)
                {
                    StatusCode = (int)errorResponse.StatusCode,
                    StatusDescription = errorResponse.StatusDescription
                };

                string message = string.Empty;
                using (var stream = errorResponse.GetResponseStream())
                {
                    using (var ms = new StreamReader(stream, new UTF8Encoding(false)))
                    {
                        message = ms.ReadToEnd();
                    }

                    try
                    {

                        serviceEx.ResponseDto = DeserializeFromString<ResponseStatus>(message);
                        if (serviceEx.ResponseDto.ResponseCode == null)
                        {
                            serviceEx.ResponseDto = new ResponseStatus
                            {
                                ResponseCode = serviceEx.StatusDescription,
                                Message = message,
                            };
                        }
                        RequestResult<TResponse> result = new RequestResult<TResponse> { Error = serviceEx };
                        requestState.HandleFinish(result);

                    }
                    catch (Exception innerEx)
                    {
                        // Oh, well, we tried
                        var serviceInnerEx = new WebServiceException(message, innerEx)
                        {
                            StatusCode = (int)errorResponse.StatusCode,
                            StatusDescription = errorResponse.StatusDescription,
                        };
                        RequestResult<TResponse> result = new RequestResult<TResponse> { Error = serviceInnerEx };
                        requestState.HandleFinish(result);
                    }
                }
                return;
            }
            RequestResult<TResponse> normalResult = new RequestResult<TResponse> { Error = exception };
            requestState.HandleFinish(normalResult);
        }

        public void GetAsync<TResponse>(string relativeOrAbsoluteUrl, object request, Action<RequestResult<TResponse>> onFinish, bool isAsyncService = false)
        {
            this.ETag = string.Empty;
            m_handleByAsync = isAsyncService;
            SendAsync<TResponse>(HttpMethod.Get, relativeOrAbsoluteUrl, request, onFinish);
        }

        public void DeleteAsync<TResponse>(string relativeOrAbsoluteUrl, object request, Action<RequestResult<TResponse>> onFinish, bool isAsyncService = false)
        {
            m_handleByAsync = isAsyncService;
            SendAsync<TResponse>(HttpMethod.Delete, relativeOrAbsoluteUrl, request, onFinish);
        }

        public void PostAsync<TResponse>(string relativeOrAbsoluteUrl, object request, Action<RequestResult<TResponse>> onFinish, bool isAsyncService = false)
        {
            m_handleByAsync = isAsyncService;
            SendAsync<TResponse>(HttpMethod.Post, relativeOrAbsoluteUrl, request, onFinish);
        }

        public void PutAsync<TResponse>(string relativeOrAbsoluteUrl, object request, Action<RequestResult<TResponse>> onFinish, bool isAsyncService = false)
        {
            m_handleByAsync = isAsyncService;
            SendAsync<TResponse>(HttpMethod.Put, relativeOrAbsoluteUrl, request, onFinish);
        }

        #endregion
    }
}
