﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Interfaces
{
    public interface IRestPostService<T>
    {
        object Post(T request);
    }
}
