﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.ServiceHost;

namespace Newegg.API.Interfaces
{
    public interface IPlugin
    {
        void Register(AppConfig appHost);
    }
}
