﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;

namespace Newegg.API.Interfaces
{
    public interface IRequireContext
    {
        HttpRequestContext RequestContext { get; set; }
    }
}
