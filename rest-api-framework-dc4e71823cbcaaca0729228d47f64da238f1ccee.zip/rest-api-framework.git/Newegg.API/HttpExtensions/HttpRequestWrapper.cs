﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Collections.Specialized;
using System.Net;
using System.IO;
using Newegg.API.Common;
using Newegg.API.ServiceHost;
using Newegg.API.Models;

namespace Newegg.API.HttpExtensions
{
    public class HttpRequestWrapper
    {
        private static readonly string physicalFilePath;

        private readonly HttpRequest request;

        static HttpRequestWrapper()
        {
            physicalFilePath = "~";
        }

        public HttpRequest Request
        {
            get { return request; }
        }

        public object OriginalRequest
        {
            get { return request; }
        }

        public HttpRequestWrapper(HttpRequest request)
            : this(null, request)
        {
        }

        public HttpRequestWrapper(string operationName, HttpRequest request)
        {
            this.OperationName = operationName;
            this.request = request;
            RequestTime = DateTime.Now;
        }

        internal DateTime RequestTime { get; set; }

        internal bool IsFromGateway { get; set; }

        public string OperationName { get; set; }

        public string ContentType
        {
            get { return request.ContentType; }
        }

        public string PreconditionIfMatch
        {
            get { return request.Headers[Common.HttpHeaders.IfMatch]; }
        }

        public string PreconditionIfNoneMatch
        {
            get { return request.Headers[Common.HttpHeaders.IfNoneMatch]; }
        }

        private string httpMethod;
        public string HttpMethod
        {
            get
            {
                return httpMethod
                    ?? (httpMethod = request.Headers[Common.HttpHeaders.XHttpMethodOverride] ?? request.HttpMethod);
            }
        }

        RequestAuthInfo m_authInfo;
        public RequestAuthInfo RequestAuth
        {
            get
            {
                return m_authInfo;
            }
            set
            {
                m_authInfo = value;
            }
        }

        public bool IsChunked
        {
            get
            {
                var encoding = request.Headers[HttpHeaders.TransferEncoding];
                if (!string.IsNullOrEmpty(encoding) && encoding.ToLower().Trim() == "chunked")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public string UserAgent
        {
            get { return request.UserAgent; }
        }

        private string responseContentType;
        public string ResponseContentType
        {
            get
            {
                if (responseContentType == null)
                {
                    responseContentType = this.GetResponseContentType();
                }
                return responseContentType;
            }
            set
            {
                this.responseContentType = value;
            }
        }

        private Dictionary<string, Cookie> cookies;
        public IDictionary<string, Cookie> Cookies
        {
            get
            {
                if (cookies == null)
                {
                    cookies = new Dictionary<string, Cookie>();
                    for (var i = 0; i < this.request.Cookies.Count; i++)
                    {
                        var httpCookie = this.request.Cookies[i];
                        var cookie = new Cookie(
                            httpCookie.Name, httpCookie.Value, httpCookie.Path, httpCookie.Domain)
                        {
                            HttpOnly = httpCookie.HttpOnly,
                            Secure = httpCookie.Secure,
                            Expires = httpCookie.Expires,
                        };
                        cookies[httpCookie.Name] = cookie;
                    }
                }
                return cookies;
            }
        }

        public NameValueCollection Headers
        {
            get { return request.Headers; }
        }

        public NameValueCollection QueryString
        {
            get { return request.QueryString; }
        }

        public NameValueCollection FormData
        {
            get { return request.Form; }
        }

        public NameValueCollection ServerVariables
        {
            get { return request.ServerVariables; }
        }

        public string GetRawBody()
        {
            using (var reader = new StreamReader(request.InputStream))
            {
                return reader.ReadToEnd();
            }
        }

        public string RawUrl
        {
            get { return request.RawUrl; }
        }

        private string languageCode;
        public string LanguageCode
        {
            get
            {
                if (languageCode == null)
                {
                    languageCode = request.Headers[HttpHeaders.XAcceptLanguageOverride];

                    if (string.IsNullOrEmpty(languageCode))
                    {
                        languageCode = request.Headers[HttpHeaders.LanguageCode];
                        if (string.IsNullOrEmpty(languageCode))
                        {
                            this.languageCode = AppConfig.Instance.DefaultContentLanguage;
                        }
                    }

                    this.languageCode = this.languageCode.ToLower();

                }
                return languageCode;
            }
        }

        public string AbsoluteUri
        {
            get
            {
                try
                {
                    return request.Url.AbsoluteUri.TrimEnd('/');
                }
                catch (Exception)
                {
                    //fastcgi mono, do a 2nd rounds best efforts
                    return "http://" + request.UserHostName + request.RawUrl;
                }
            }
        }

        public string UserHostAddress
        {
            get { return request.UserHostAddress; }
        }

        public bool IsSecureConnection
        {
            get { return request.IsSecureConnection; }
        }

        public string[] AcceptTypes
        {
            get { return request.AcceptTypes; }
        }

        public string PathInfo
        {
            get { return request.GetPathInfo(); }
        }

        public string UrlHostName
        {
            get { return request.GetUrlHostName(); }
        }

        public Stream InputStream
        {
            get { return request.InputStream; }
        }

        public long ContentLength
        {
            get { return request.ContentLength; }
        }

        public string ApplicationFilePath
        {
            get { return physicalFilePath; }
        }

        public string ApplicationPath
        {
            get { return request.ApplicationPath; }
        }

        private string acceptEncoding;
        public string AcceptEncoding
        {
            get
            {
                if (acceptEncoding == null)
                {
                    acceptEncoding = Request.Headers[HttpHeaders.AcceptEncoding];
                    if (string.IsNullOrEmpty(acceptEncoding))
                    {
                        this.acceptEncoding = "none";
                    }
                    else
                    {
                        this.acceptEncoding = this.acceptEncoding.ToLower();
                    }
                }
                return acceptEncoding;
            }
        }

        public bool AcceptsGzip
        {
            get
            {
                return AcceptEncoding != null && AcceptEncoding.Contains("gzip");
            }
        }

        public bool AcceptsDeflate
        {
            get
            {
                return AcceptEncoding != null && AcceptEncoding.Contains("deflate");
            }
        }
    }
}
