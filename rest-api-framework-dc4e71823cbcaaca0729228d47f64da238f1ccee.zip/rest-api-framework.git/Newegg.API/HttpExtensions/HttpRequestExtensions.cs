﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Newegg.API.Common;
using ServiceStack.Text;
using Newegg.API.ServiceHost;
using Newegg.API.Models;

namespace Newegg.API.HttpExtensions
{
    public static class HttpRequestExtensions
    {
        private static string WebHostDirectoryName = "";

        public static string GetOperationName(this HttpRequest request)
        {
            var pathInfo = request.GetLastPathInfo();
            return GetOperationNameFromLastPathInfo(pathInfo);
        }

        public static string GetOperationNameFromLastPathInfo(string lastPathInfo)
        {
            if (string.IsNullOrEmpty(lastPathInfo)) return null;

            var operationName = lastPathInfo.Substring("/".Length);

            return operationName;
        }

        private static string GetLastPathInfoFromRawUrl(string rawUrl)
        {
            var pathInfo = rawUrl.IndexOf("?") != -1
                ? rawUrl.Substring(0, rawUrl.IndexOf("?"))
                : rawUrl;

            pathInfo = pathInfo.Substring(pathInfo.LastIndexOf("/"));

            return pathInfo;
        }

        public static string GetLastPathInfo(this HttpRequest request)
        {
            var pathInfo = request.PathInfo;
            if (string.IsNullOrEmpty(pathInfo))
            {
                pathInfo = GetLastPathInfoFromRawUrl(request.RawUrl);
            }

            return pathInfo;
        }

        public static string GetUrlHostName(this HttpRequest request)
        {
            try
            {
                return request.Url.Host;
            }
            catch
            {
                return request.UserHostName;
            }
        }

        public static string GetParentBaseUrl(this HttpRequest request)
        {
            var rawUrl = request.RawUrl; // /Cambia3/Temp/Test.aspx/path/info
            var endpointsPath = rawUrl.Substring(0, rawUrl.LastIndexOf('/') + 1);  // /Cambia3/Temp/Test.aspx/path
            return GetAuthority(request) + endpointsPath;
        }

        public static string GetBaseUrl(this HttpRequest request)
        {
            return GetAuthority(request) + request.RawUrl;
        }

        //=> http://localhost:96 ?? ex=> http://localhost
        private static string GetAuthority(HttpRequest request)
        {
            try
            {
                return request.Url.GetLeftPart(UriPartial.Authority);
            }
            catch
            {
                return "http://" + request.UserHostName;
            }
        }

        public static string GetPathInfo(this HttpRequest request)
        {
            if (!string.IsNullOrEmpty(request.PathInfo)) return request.PathInfo.TrimEnd('/');

            //var mode = string.Empty;
            var appPath = string.IsNullOrEmpty(request.ApplicationPath)
                          ? WebHostDirectoryName
                          : request.ApplicationPath.TrimStart('/');

            //mod_mono: /CustomPath35/api//default.htm
            var path = request.Path;
            return GetPathInfo(path, null, appPath);
        }

        public static string GetPathInfo(string fullPath, string mode, string appPath)
        {
            var pathInfo = ResolvePathInfoFromMappedPath(fullPath, mode);
            if (!string.IsNullOrEmpty(pathInfo)) return pathInfo;

            //Wildcard mode relies on this to find work out the handlerPath
            pathInfo = ResolvePathInfoFromMappedPath(fullPath, appPath);
            if (!string.IsNullOrEmpty(pathInfo)) return pathInfo;

            return fullPath;
        }

        public static string ResolvePathInfoFromMappedPath(string fullPath, string mappedPathRoot)
        {
            var sbPathInfo = new StringBuilder();
            var fullPathParts = fullPath.Split('/');
            var isMultipleRoot = string.IsNullOrEmpty(mappedPathRoot) ? false : (mappedPathRoot.Split('/').Length > 1);
            var pathRootFound = false;
            var mappedPart = string.Empty;
            foreach (var fullPathPart in fullPathParts)
            {
                if (pathRootFound)
                {
                    sbPathInfo.Append("/" + fullPathPart);
                }
                else
                {
                    if (isMultipleRoot)
                    {
                        mappedPart += (string.IsNullOrEmpty(mappedPart) ? string.Empty : "/") + fullPathPart;
                        if (string.Equals(mappedPart, mappedPathRoot, StringComparison.InvariantCultureIgnoreCase))
                        {
                            pathRootFound = true;
                        }
                    }
                    else
                    {
                        pathRootFound = string.Equals(fullPathPart, mappedPathRoot, StringComparison.InvariantCultureIgnoreCase);
                    }
                }
            }
            if (!pathRootFound) return null;

            var path = sbPathInfo.ToString();
            return path.Length > 1 ? path.TrimEnd('/') : "/";
        }

        public static bool IsContentType(this HttpRequestWrapper request, string contentType)
        {
            return request.ContentType.StartsWith(contentType, StringComparison.InvariantCultureIgnoreCase);
        }

        public static bool HasAnyOfContentTypes(this HttpRequestWrapper request, params string[] contentTypes)
        {
            if (contentTypes == null || request.ContentType == null) return false;
            foreach (var contentType in contentTypes)
            {
                if (IsContentType(request, contentType)) return true;
            }
            return false;
        }

        public static HttpRequestWrapper GetHttpRequest(this HttpRequest request)
        {
            return new HttpRequestWrapper(null, request);
        }

        public static string GetJsonpCallback(this HttpRequestWrapper httpReq)
        {
            return httpReq == null ? null : httpReq.QueryString["jsonp"];
        }

        public static Dictionary<string, string> GetRequestParams(this HttpRequestWrapper request)
        {
            var map = new Dictionary<string, string>();

            foreach (var name in request.QueryString.AllKeys)
            {
                if (name == null) continue; //thank you ASP.NET
                map[name] = request.QueryString[name];
            }

            if ((request.HttpMethod == HttpMethods.Post || request.HttpMethod == HttpMethods.Put)
                && request.FormData != null)
            {
                foreach (var name in request.FormData.AllKeys)
                {
                    if (name == null) continue; //thank you ASP.NET
                    map[name] = request.FormData[name];
                }
            }

            return map;
        }

        public static PageInfo GetQueryStringPageInfo(this HttpRequestWrapper httpReq)
        {
            PageInfo obj = new PageInfo{PageIndex = AppConfig.Instance.DefaultPageIndex, PageSize = AppConfig.Instance.DefaultPageSize};
            try
            {
                StringMapTypeDeserializer st = new StringMapTypeDeserializer(typeof(PageInfo));
                var p = st.PopulateFromMap(obj, httpReq.GetRequestParams());
                PageInfo page = (PageInfo)p;
                if (page.PageSize > AppConfig.Instance.MaxPageSize)
                {
                    page.PageSize = AppConfig.Instance.MaxPageSize;
                }
                else if (page.PageSize <= 0)
                {
                    page.PageSize = AppConfig.Instance.DefaultPageSize;
                }
                return page;
            }
            catch
            {
                return obj;
            }
            
        }

        public static ExecuteContext GetExecuteContext(this HttpRequestWrapper httpReq)
        {
            ExecuteContext ect = null;
            StringMapTypeDeserializer st = new StringMapTypeDeserializer(typeof(ExecuteContext));
            var obj = st.PopulateFromMap(ect, httpReq.GetRequestParams());
            var result = (ExecuteContext)obj;
            httpReq.GetMessageQueueInfo(result);
            return result;
        }

        public static void GetMessageQueueInfo(this HttpRequestWrapper httpReq, ExecuteContext ec)
        {
            var invokeType = httpReq.Headers.Get(HttpHeaders.MessageInvokeType);
            var callback = httpReq.Headers.Get(HttpHeaders.MessageCallback);
            if (!string.IsNullOrEmpty(invokeType))
            {
                InvokeType iType;
                if (Enum.TryParse(invokeType, true, out iType))
                {
                    ec.InvokeType = iType;
                }
            }

            if (!string.IsNullOrEmpty(callback))
            {
                ec.CallbackUri = callback;
            }
        }

        public static string GetAccessKey(this HttpRequestWrapper httpReq)
        {
            var appkey = httpReq.QueryString["appkey"];
            if (string.IsNullOrEmpty(appkey))
            {
                return string.Empty;
            }
            else
            {
                return appkey.Trim();
            }
        }

        public static string GetAccessToken(this HttpRequestWrapper httpReq)
        {
            var token = httpReq.QueryString["accesstoken"];
            if (string.IsNullOrEmpty(token))
            {
                return string.Empty;
            }
            else
            {
                return token.Trim();
            }
        }

        public static string GetQueryStringContentType(this HttpRequestWrapper httpReq)
        {
            var callback = httpReq.QueryString["callback"];
            if (!string.IsNullOrEmpty(callback)) return ContentType.Json;

            var format = httpReq.QueryString["format"];
            if (format == null)
            {
                const int formatMaxLength = 4;
                var pi = httpReq.PathInfo;
                if (pi == null || pi.Length <= formatMaxLength) return null;
                if (pi[0] == '/') pi = pi.Substring(1);
                format = pi.SplitOnFirst('/')[0];
                if (format.Length > formatMaxLength) return null;
            }

            format = format.SplitOnFirst('.')[0].ToLower();
            if (format.Contains("json")) return ContentType.Json;
            if (format.Contains("xml")) return ContentType.Xml;
            if (format.Contains("jsv")) return ContentType.Jsv;
            if (format.Contains("html")) return ContentType.Html;

            string contentType = string.Empty;

            return contentType;
        }

        public static string GetResponseContentType(this HttpRequestWrapper httpReq)
        {
            var specifiedContentType = GetQueryStringContentType(httpReq);
            if (!string.IsNullOrEmpty(specifiedContentType)) return specifiedContentType;

            var acceptContentTypes = httpReq.AcceptTypes;
            var defaultContentType = httpReq.ContentType;
            if (httpReq.HasAnyOfContentTypes(ContentType.FormUrlEncoded, ContentType.MultiPartFormData))
            {
                defaultContentType = string.Empty;
            }

            //var acceptsAnything = false;
            var hasDefaultContentType = !string.IsNullOrEmpty(defaultContentType);
            if (acceptContentTypes != null)
            {
                var hasPreferredContentTypes = new bool[AppConfig.Instance.PreferredContentTypes.Count];
                foreach (var contentType in acceptContentTypes)
                {
                    //acceptsAnything = acceptsAnything || contentType == "*/*";

                    for (var i = 0; i < AppConfig.Instance.PreferredContentTypes.Count; i++)
                    {
                        if (hasPreferredContentTypes[i]) continue;
                        var preferredContentType = AppConfig.Instance.PreferredContentTypes[i];
                        hasPreferredContentTypes[i] = contentType.StartsWith(preferredContentType, StringComparison.InvariantCultureIgnoreCase);

                        //Prefer Request.ContentType if it is also a preferredContentType
                        if (hasPreferredContentTypes[i] && preferredContentType == defaultContentType)
                            return preferredContentType;
                    }
                }
                for (var i = 0; i < AppConfig.Instance.PreferredContentTypes.Count; i++)
                {
                    if (hasPreferredContentTypes[i]) return AppConfig.Instance.PreferredContentTypes[i];
                }
                //if (acceptsAnything && hasDefaultContentType) return defaultContentType;
            }

            return AppConfig.Instance.DefaultContentType;
        }

    }
}
