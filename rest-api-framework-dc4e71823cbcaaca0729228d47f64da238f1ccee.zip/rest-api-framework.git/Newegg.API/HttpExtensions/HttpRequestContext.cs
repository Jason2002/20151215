﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.ServiceHost;
using System.Web;
using Newegg.API.Common;
using Newegg.API.Models;
using Newegg.API.Cache;
using System.Net;
using Newegg.API.Exceptions;
using Newegg.API.Logging;
using System.Collections.Specialized;
using System.IO;

namespace Newegg.API.HttpExtensions
{
    public class HttpRequestContext
    {
        private readonly HttpRequestWrapper httpReq;
        public HttpRequestWrapper HttpReq
        {
            get
            {
                return httpReq;
            }
        }
        private readonly HttpResponseWrapper httpRes;
        public HttpResponseWrapper HttpRes
        {
            get
            {
                return httpRes;
            }
        }

        public HttpRequestContext(object dto, HttpRequestWrapper httpReq, HttpResponseWrapper httpRes)
        {
            this.Dto = dto;
            this.httpReq = httpReq;
            this.httpRes = httpRes;
        }

        public HttpRequestContext(object dto)
            : this(dto, null, null)
        {

        }

        public ExecuteContext ExecuteContext { get; set; }

        public bool AutoDispose { get; set; }

        public object Dto { get; set; }

        public IDictionary<string, System.Net.Cookie> Cookies
        {
            get { return this.httpReq.Cookies; }
        }

        public string ContentType
        {
            get { return this.httpReq.ContentType; }
        }

        public RequestAuthInfo RequestAuth
        {
            get { return this.httpReq.RequestAuth; }
        }

        private string responseContentType;
        public string ResponseContentType
        {
            get { return responseContentType ?? this.httpReq.ResponseContentType; }
            set { responseContentType = value; }
        }

        //private HttpStatusCode responseCode;
        public HttpStatusCode ResponseCode
        {
            set
            {
                httpRes.StatusCode = (int)value;
            }
        }

        public string GetHeader(string headerName)
        {
            return this.httpReq.Headers.Get(headerName);
        }

        public string LanguageCode
        {
            get
            {
                return this.httpReq.LanguageCode;
            }
        }

        private PageInfo pageInfo;
        public PageInfo RequestPageInfo
        {
            get
            {
                if (pageInfo == null)
                {
                    pageInfo = httpReq.GetQueryStringPageInfo();
                }
                return pageInfo;
            }
        }

        private CachePolicy cachePolicy;
        public CachePolicy CachePolicy
        {
            get
            {
                if (cachePolicy == null)
                {
                    var ifMatch = httpReq.PreconditionIfMatch;
                    var ifNoneMatch = httpReq.PreconditionIfMatch;
                    if (string.IsNullOrEmpty(ifMatch) && string.IsNullOrEmpty(ifNoneMatch))
                    {
                        return null;
                    }
                    else
                    {
                        cachePolicy = new CachePolicy();
                        if (!string.IsNullOrEmpty(ifMatch))
                        {
                            cachePolicy.ETag = ifMatch;
                            cachePolicy.Policy = CachePolicyType.IfMatch;
                        }
                        else
                        {
                            cachePolicy.ETag = ifNoneMatch;
                            cachePolicy.Policy = CachePolicyType.IfNoneMatch;
                        }
                    }
                }
                return cachePolicy;
            }
        }

        

        public string AbsoluteUri
        {
            get
            {
                return this.httpReq != null ? this.httpReq.AbsoluteUri : null;
            }
        }

        public string RawUrl
        {
            get
            {
                return this.httpReq != null ? this.httpReq.RawUrl : null;
            }
        }

        public NameValueCollection QueryString
        {
            get { return httpReq.QueryString; }
        }

        private string ipAddress;
        public string IpAddress
        {
            get
            {
                if (ipAddress == null)
                {
                    ipAddress = GetIpAddress();
                }
                return ipAddress;
            }
        }

        public static string GetIpAddress()
        {
            return HttpContext.Current != null
                ? HttpContext.Current.Request.UserHostAddress
                : null;
        }

        ~HttpRequestContext()
        {
            if (this.AutoDispose)
            {
                Dispose(false);
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }

        public virtual void Dispose(bool disposing)
        {
            if (disposing)
                GC.SuppressFinalize(this);
        }

        #region Cache
        public object ToOptimizedResultUsingCache<T>(string cacheKey, TimeSpan? expireCacheIn, Func<T> objectFactory)
            where T : class
        {
            var cacheClient = CacheFactory.CacheClient;
            CacheEntry cacheResult;
            try
            {
                cacheResult = cacheClient.Get(cacheKey);
            }
            catch (Exception ex)
            {
                LogFactory.Log.Error("Cache Error", ex);
                return objectFactory();
            }
            if (cacheResult != null)
            {
                this.httpRes.AddHeader(HttpHeaders.LastModified, cacheResult.LastModified.ToString("r"));
                this.httpRes.AddHeader(HttpHeaders.ETag, cacheResult.ETag);
                this.httpRes.AddHeader(HttpHeaders.CacheControl, "max-age=" + (expireCacheIn ?? AppConfig.Instance.DefaultExpireTime).TotalSeconds.ToString());
                return cacheResult.Value;
            }
            bool addResult = false;
            if (expireCacheIn.HasValue)
            {
                addResult = cacheClient.Add<T>(cacheKey, objectFactory(), expireCacheIn.Value);
            }
            else
            {
                addResult = cacheClient.Add<T>(cacheKey, objectFactory());
            }

            if (addResult)
            {
                cacheResult = cacheClient.Get(cacheKey);
                if (cacheResult != null)
                {
                    this.httpRes.AddHeader(HttpHeaders.LastModified, cacheResult.LastModified.ToUniversalTime().ToString("r"));
                    this.httpRes.AddHeader(HttpHeaders.ETag, cacheResult.ETag);
                    this.httpRes.AddHeader(HttpHeaders.CacheControl, "max-age=" + (expireCacheIn ?? AppConfig.Instance.DefaultExpireTime).TotalSeconds.ToString());
                    return cacheResult.Value;
                }
            }
            return cacheResult;
        }

        public void UpdateCache<T>(string cacheKey, T obj, TimeSpan? expireCacheIn) where T : class
        {
            try
            {
                var cacheClient = CacheFactory.CacheClient;
                if (expireCacheIn.HasValue)
                {
                    cacheClient.Replace<T>(cacheKey, obj, expireCacheIn.Value);
                }
                else
                {
                    cacheClient.Replace<T>(cacheKey, obj);
                }
            }
            catch (Exception ex)
            {
                LogFactory.Log.Error("Cache Error", ex);
            }
        }

        public void RemoveFromCache(string cacheKey)
        {
            try
            {
                var cacheClient = CacheFactory.CacheClient;
                cacheClient.Remove(cacheKey);
            }
            catch (Exception ex)
            {
                LogFactory.Log.Error("Cache Error", ex);
            }
        }

        public void CheckCacheConflict(string cacheKey)
        {
            var cacheClient = CacheFactory.CacheClient;
            CacheEntry cacheResult;
            try
            {
                cacheResult = cacheClient.Get(cacheKey);
            }
            catch (Exception ex)
            {
                LogFactory.Log.Error("Cache Error", ex);
                return;
            }
            if (cacheResult != null && this.CachePolicy != null)
            {
                if (CachePolicy.Policy == CachePolicyType.IfMatch && CachePolicy.ETag != cacheResult.ETag)
                {
                    throw new HttpError(HttpStatusCode.PreconditionFailed, ErrorCode.EntityVersionNotCorrect, "Entity version not correct");
                }
                else if (CachePolicy.Policy == CachePolicyType.IfNoneMatch && CachePolicy.ETag == cacheResult.ETag)
                {
                    throw new HttpError(HttpStatusCode.PreconditionFailed, ErrorCode.EntityVersionNotCorrect, "Entity version not correct");
                }
            }
        }
        #endregion

        public void AddLinkHeader(LinkHeader link)
        {
            this.httpRes.AddHeader(HttpHeaders.Link, link.ToString());
        }

        public void AddLocationHeader(string locationUri)
        {
            this.httpRes.AddHeader(HttpHeaders.Location, locationUri);
        }

        public object ReturnCreatedResponse(string createdResourceUri)
        {
            return ResponseFactory.CreateCreatedResponse(this, createdResourceUri);
        }

        public object ReturnNoResponse()
        {
            return ResponseFactory.CreateNoResponse(this);
        }

        public object ReturnRedirectResponse(string redirectUri)
        {
            return ResponseFactory.CreateRedirectResponse(this, redirectUri);
        }

        public Stream InputStream
        {
            get { return httpReq.InputStream; }
        }

        public string GetInputStreamAsString()
        {
            return httpReq.GetRawBody();
        }
    }
}
