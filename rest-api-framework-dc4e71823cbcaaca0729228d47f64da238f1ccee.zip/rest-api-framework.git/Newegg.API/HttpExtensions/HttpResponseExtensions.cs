﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Serialization;
using System.IO;
using ServiceStack.Text;
using Newegg.API.Common;
using System.Net;
using Newegg.API.Models;
using Newegg.API.Exceptions;
using Newegg.API.ServiceHost;
using Newegg.API.Common;

namespace Newegg.API.HttpExtensions
{
    public static class HttpResponseExtensions
    {
        public static bool WriteToResponse(this HttpResponseWrapper httpRes, HttpRequestWrapper httpReq, object result)
        {
            if (httpReq.AcceptsGzip || httpReq.AcceptsDeflate)
            {
                return WriteCompressResponse(httpRes, httpReq, result);
            }
            else
            {
                return WriteToResponse(httpRes, httpReq, result, null, null);    
            }
        }

        private static bool WriteCompressResponse(this HttpResponseWrapper httpRes, HttpRequestWrapper httpReq, object result)
        {
            if (result != null && result is ResponseStatus)
            {
                httpRes.StatusCode = (int)((ResponseStatus)result).StatusCode;
                if (((ResponseStatus)result).StatusCode == HttpStatusCode.NoContent
                    ||
                    ((ResponseStatus)result).StatusCode == HttpStatusCode.NotModified)
                {
                    result = null;
                }
            }

            if (result == null) return true;

            var serializer = HttpResponseSerialize.GetStringSerializer(httpReq.ResponseContentType);
            string serializedDto = serializer(result);
            byte[] results = null;
            string compressionType = string.Empty;
            if (httpReq.AcceptsGzip)
            {
                compressionType = "gzip";
                results = serializedDto.GZip();
            }
            else if (httpReq.AcceptsDeflate)
            {
                compressionType = "deflate";
                results = serializedDto.Deflate();
            }
            if (results != null)
            {
                httpRes.ContentType = httpReq.ResponseContentType;
                httpRes.AddHeader(HttpHeaders.ContentEncoding, compressionType);
                httpRes.OutputStream.Write(results, 0, results.Length);
                httpRes.Close();
            }
            return true;
        }

        public static bool WriteToResponse(this HttpResponseWrapper httpRes, HttpRequestWrapper httpReq, object result, byte[] bodyPrefix, byte[] bodySuffix)
        {
            if (result == null) return true;

            var serializationContext = new HttpRequestContext(result, httpReq, httpRes);
            var serializer = HttpResponseSerialize.GetResponseSerializer(httpReq.ResponseContentType);
            return httpRes.WriteToResponse(result, serializer, serializationContext, bodyPrefix, bodySuffix);
        }

        /// <summary>
        /// Writes to response.
        /// </summary>
        /// <param name="response">The response.</param>
        /// <param name="result">Response DTO</param>
        /// <param name="defaultAction">The default action.</param>
        /// <param name="serializerCtx">The serialization context.</param>
        /// <param name="bodyPrefix">Add prefix to response body if any</param>
        /// <param name="bodySuffix">Add suffix to response body if any</param>
        /// <returns></returns>
        public static bool WriteToResponse(this HttpResponseWrapper response, object result, ResponseSerializerDelegate defaultAction, HttpRequestContext serializerCtx, byte[] bodyPrefix, byte[] bodySuffix)
        {
            var defaultContentType = serializerCtx.ResponseContentType;
            try
            {
                if (result == null) return true;

                //Write Global Header
                //foreach (var globalResponseHeader in EndpointHost.Config.GlobalResponseHeaders)
                //{
                //    response.AddHeader(globalResponseHeader.Key, globalResponseHeader.Value);
                //}
                
                var disposableResult = result as IDisposable;
                if (WriteToOutputStream(response, result, bodyPrefix, bodySuffix))
                {
                    response.Flush(); //required for Compression
                    if (disposableResult != null) disposableResult.Dispose();
                    return true;
                }

                //ContentType='text/html' is the default for a HttpResponse
                //Do not override if another has been set
                if (response.ContentType == null || response.ContentType == ContentType.Html)
                {
                    response.ContentType = defaultContentType;
                }
                if (bodyPrefix != null && response.ContentType.IndexOf(ContentType.Json) >= 0)
                {
                    response.ContentType = ContentType.JavaScript;
                }

                //if (EndpointHost.Config.AppendUtf8CharsetOnContentTypes.Contains(response.ContentType))
                //{
                //    response.ContentType += ContentType.Utf8Suffix;
                //}

                var responseText = result as string;
                if (responseText != null)
                {
                    if (bodyPrefix != null) response.OutputStream.Write(bodyPrefix, 0, bodyPrefix.Length);
                    WriteTextToResponse(response, responseText, defaultContentType);
                    if (bodySuffix != null) response.OutputStream.Write(bodySuffix, 0, bodySuffix.Length);
                    return true;
                }

                if (defaultAction == null)
                {
                    throw new ArgumentNullException("defaultAction", string.Format(
                    "As result '{0}' is not a supported responseType, a defaultAction must be supplied",
                    (result != null ? result.GetType().Name : "")));
                }

                if (bodyPrefix != null) response.OutputStream.Write(bodyPrefix, 0, bodyPrefix.Length);
                if (result != null)
                {
                    if (result is ResponseStatus)
                    {
                        response.StatusCode = (int)((ResponseStatus)result).StatusCode;
                        if (((ResponseStatus)result).StatusCode == HttpStatusCode.NoContent
                            ||
                            ((ResponseStatus)result).StatusCode == HttpStatusCode.NotModified
                            )
                        {
                            result = null;
                        }
                    }
                    if (result != null)
                    {
                        defaultAction(serializerCtx, result, response);
                    }
                    
                }
                if (bodySuffix != null) response.OutputStream.Write(bodySuffix, 0, bodySuffix.Length);

                if (disposableResult != null) disposableResult.Dispose();

                return false;
            }
            catch (Exception originalEx)
            {
                try
                {
                    var responseStatus = ErrorUtils.CreateErrorResponse(originalEx, AppConfig.Instance.DebugMode);

                    if (!response.IsClosed)
                    {
                        response.WriteErrorToResponse(defaultContentType, responseStatus);
                    }
                }
                catch
                {
                    throw originalEx;
                }
                return true;
            }
            finally
            {
                response.Close();
            }

        }

        public static bool WriteToOutputStream(HttpResponseWrapper response, object result, byte[] bodyPrefix, byte[] bodySuffix)
        {
            var stream = result as Stream;
            if (stream != null)
            {
                if (bodyPrefix != null) response.OutputStream.Write(bodyPrefix, 0, bodyPrefix.Length);
                stream.WriteTo(response.OutputStream);
                if (bodySuffix != null) response.OutputStream.Write(bodySuffix, 0, bodySuffix.Length);
                return true;
            }

            var bytes = result as byte[];
            if (bytes != null)
            {
                response.ContentType = ContentType.Binary;
                if (bodyPrefix != null) response.OutputStream.Write(bodyPrefix, 0, bodyPrefix.Length);
                response.OutputStream.Write(bytes, 0, bytes.Length);
                if (bodySuffix != null) response.OutputStream.Write(bodySuffix, 0, bodySuffix.Length);
                return true;
            }

            return false;
        }

        public static void WriteErrorToResponse(this HttpResponseWrapper response, string contentType, ResponseStatus responseStatus)
        {
            switch (contentType)
            {
                case ContentType.Xml:
                    WriteXmlErrorToResponse(response, responseStatus);
                    break;
                case ContentType.Json:
                    WriteJsonErrorToResponse(response, responseStatus);
                    break;
                case ContentType.Jsv:
                    WriteJsvErrorToResponse(response, responseStatus);
                    break;
                //case ContentType.Csv:
                //    WriteCsvErrorToResponse(response, responseStatus);
                //    break;
                default:
                    WriteXmlErrorToResponse(response, responseStatus);
                    break;
            }
        }

        private static void WriteErrorTextToResponse(this HttpResponseWrapper response, StringBuilder sb,
            string contentType, HttpStatusCode statusCode)
        {
            response.StatusCode = (int)statusCode;
            WriteTextToResponse(response, sb.ToString(), contentType);
            response.Close();
        }

        public static void WriteTextToResponse(this HttpResponseWrapper response, string text, string defaultContentType)
        {
            try
            {
                //ContentType='text/html' is the default for a HttpResponse
                //Do not override if another has been set
                if (response.ContentType == null || response.ContentType == ContentType.Html)
                {
                    response.ContentType = defaultContentType;
                }

                response.Write(text);
            }
            catch
            {
                throw;
            }
        }

        private static void WriteXmlErrorToResponse(this HttpResponseWrapper response, ResponseStatus responseStatus)
        {
            var sb = new StringBuilder();
            sb.Append(XmlSimpleSerializer.SerializeToString<ResponseStatus>(responseStatus));
            response.WriteErrorTextToResponse(sb, ContentType.Xml, responseStatus.StatusCode);
        }

        private static void WriteJsonErrorToResponse(this HttpResponseWrapper response, ResponseStatus responseStatus)
        {
            var sb = new StringBuilder();
            sb.Append(JsonSerializer.SerializeToString<ResponseStatus>(responseStatus));
            response.WriteErrorTextToResponse(sb, ContentType.Json, responseStatus.StatusCode);
        }

        private static void WriteJsvErrorToResponse(this HttpResponseWrapper response, ResponseStatus responseStatus)
        {
            var sb = new StringBuilder();
            sb.Append(TypeSerializer.SerializeToString<ResponseStatus>(responseStatus));
            response.WriteErrorTextToResponse(sb, ContentType.Jsv, responseStatus.StatusCode);
        }

        //private static void WriteCsvErrorToResponse(this HttpResponseWrapper response, ResponseStatus responseStatus)
        //{
        //    var sb = new StringBuilder();
        //    //sb.Append("ResponseCode,Message,StackTrace \n");
        //    //sb.AppendFormat("{0},", responseStatus.ResponseCode);
        //    //sb.AppendFormat("{0},", responseStatus.Message);
        //    //sb.AppendFormat("{0}", responseStatus.StackTrace);
        //    sb.Append(CsvSerializer.SerializeToString<ResponseStatus>(responseStatus));
        //    response.WriteErrorTextToResponse(sb, ContentType.Csv, responseStatus.StatusCode);
        //}
    }
}
