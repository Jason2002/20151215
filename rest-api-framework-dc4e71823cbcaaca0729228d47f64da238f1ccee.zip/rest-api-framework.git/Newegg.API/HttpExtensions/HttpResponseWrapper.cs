﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using Newegg.API.Common;
using System.Collections.Specialized;

namespace Newegg.API.HttpExtensions
{
    public class HttpResponseWrapper
    {
        //private static readonly ILog Log = LogManager.GetLogger(typeof(HttpResponseWrapper));

        private readonly HttpResponse response;

        public HttpResponseWrapper(HttpResponse response)
        {
            this.response = response;
            this.response.TrySkipIisCustomErrors = true;
            //this.Cookies = new Cookies(this);
        }

        public HttpResponse Response
        {
            get { return response; }
        }

        public object OriginalResponse
        {
            get { return response; }
        }

        public int StatusCode
        {
            set { this.response.StatusCode = value; }
        }

        public string StatusDescription
        {
            set { this.response.StatusDescription = value; }
        }

        public string ContentType
        {
            get { return response.ContentType; }
            set { response.ContentType = value; }
        }

        public string Language
        {
            set { this.AddHeader(HttpHeaders.ContentLanguage, value); }
        }

        //public ICookies Cookies { get; set; }

        public void AddHeader(string name, string value)
        {
            response.AddHeader(name, value);
        }

        public NameValueCollection Headers
        {
            get { return response.Headers; }
        }

        public void Redirect(string url)
        {
            response.Redirect(url);
        }

        public Stream OutputStream
        {
            get { return response.OutputStream; }
        }

        public void Write(string text)
        {
            response.Write(text);
        }

        public void Close()
        {
            this.IsClosed = true;
            response.OutputStream.Close();
        }

        public void End()
        {
            this.IsClosed = true;
            try
            {
                response.ClearContent();
                response.End();
            }
            catch { }
        }

        public void Flush()
        {
            response.Flush();
        }

        public bool IsClosed
        {
            get;
            private set;
        }
    }
}
