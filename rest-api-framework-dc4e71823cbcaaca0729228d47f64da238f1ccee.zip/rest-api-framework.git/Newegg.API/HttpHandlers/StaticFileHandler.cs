﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using Newegg.API.Common;

namespace Newegg.API.HttpHandlers
{
    public class StaticFileHandler : IHttpHandler
    {
        public bool IsReusable
        {
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            ProcessRequest(
            new HttpExtensions.HttpRequestWrapper(null, context.Request),
            new HttpExtensions.HttpResponseWrapper(context.Response),
            null);
        }

        public void ProcessRequest(HttpExtensions.HttpRequestWrapper request, HttpExtensions.HttpResponseWrapper response, string operationName)
        {
            var fileName = request.Request.PhysicalPath;

            var fi = new FileInfo(fileName);
            if (!fi.Exists)
            {
                throw new HttpException(404, "File '" + request.PathInfo + "' not found.");
            }

            try
            {
                response.ContentType = MimeTypes.GetMimeType(fileName);
                response.Response.TransmitFile(fileName);

            }
            catch (Exception)
            {
                throw new HttpException(403, "Forbidden.");
            }
        }
    }
}
