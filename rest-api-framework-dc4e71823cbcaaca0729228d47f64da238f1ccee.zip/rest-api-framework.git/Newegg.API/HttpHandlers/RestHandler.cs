﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Newegg.API.HttpExtensions;
using Newegg.API.ServiceHost;
using System.Runtime.Serialization;
using ServiceStack.Text;
using Newegg.API.Serialization;
using Newegg.API.Common;
using System.Net;
using Newegg.API.Exceptions;
using Newegg.API.Logging;
using Newegg.API.Profile;
using Newegg.API.Models;

namespace Newegg.API.HttpHandlers
{
    public class RestHandler : IHttpHandler
    {
        private ILog log = LogFactory.Log;

        public string RequestName { get; set; }

        internal RestPath RestPath { get; set; }
        public static RestPath FindMatchingRestPath(string httpMethod, string pathInfo)
        {
            var controller = AppConfig.Instance.ServiceManager;

            return controller.GetRestPathForRequest(httpMethod, pathInfo);
        }

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            var operationName = this.RequestName ?? context.Request.GetOperationName();

            ProcessRequest(
                new HttpExtensions.HttpRequestWrapper(operationName, context.Request),
                new HttpExtensions.HttpResponseWrapper(context.Response),
                operationName);
        }

        public RestPath GetRestPath(string httpMethod, string pathInfo)
        {
            if (this.RestPath == null)
            {
                this.RestPath = FindMatchingRestPath(httpMethod, pathInfo);
            }
            return this.RestPath;
        }

        public void ProcessRequest(HttpExtensions.HttpRequestWrapper httpReq, HttpExtensions.HttpResponseWrapper httpRes, string operationName)
        {
            var responseContentType = httpReq.ResponseContentType;
            object response = null;
            try
            {
                var restPath = GetRestPath(httpReq.HttpMethod, httpReq.PathInfo);
                if (restPath == null)
                    throw new NotSupportedException("No RestPath found for: " + httpReq.HttpMethod + " " + httpReq.PathInfo);

                operationName = restPath.RequestType.Name;

                var jsonp = httpReq.GetJsonpCallback();
                var doJsonp = responseContentType == ContentType.Json && !string.IsNullOrEmpty(jsonp);

                var request = GetRequest(httpReq, restPath);

                if (AppConfig.Instance.FilterManager.ApplyRequestFilters(httpReq, httpRes, request)) return;

                response = GetResponse(httpReq, httpRes, request);

                if (AppConfig.Instance.FilterManager.ApplyResponseFilters(httpReq, httpRes, response)) return;

                if (doJsonp)
                {
                    httpRes.WriteToResponse(httpReq, response, (jsonp + "(").ToUtf8Bytes(), ")".ToUtf8Bytes());
                }
                else
                {
                    httpRes.WriteToResponse(httpReq, response);
                }
            }
            catch (Exception ex)
            {
                if (AppConfig.Instance.IsLoggingException(ex))
                {
                    var message = string.Format("Error occured while Processing Request: {0}", httpReq.RawUrl);
                    log.Error(message, ex);
                }
                HandleException(responseContentType, httpReq, httpRes, ex);

            }
        }

        private void HandleException(string responseContentType, HttpExtensions.HttpRequestWrapper httpReq, HttpExtensions.HttpResponseWrapper httpRes, Exception ex)
        {
            try
            {
                var responseStatus = ErrorUtils.CreateErrorResponse(ex, AppConfig.Instance.DebugMode);

                if (!httpRes.IsClosed)
                {
                    httpRes.WriteErrorToResponse(responseContentType, responseStatus);
                }
            }
            catch (Exception writeErrorEx)
            {
                log.Error("Error occured while Processing Error", writeErrorEx);
                throw ex;
            }
        }

        private object GetRequest(HttpExtensions.HttpRequestWrapper httpReq, RestPath restPath)
        {
            var requestType = restPath.RequestType;
            var requestParams = httpReq.GetRequestParams();

            object requestDto = null;
            if (!requestType.IsSubclassOf(typeof(RawRequestDto)))
            {
                var contentType = httpReq.ContentType;
                if (string.IsNullOrEmpty(contentType))
                {
                    contentType = httpReq.ResponseContentType;
                }
                requestDto = CreateContentTypeRequest(httpReq, requestType, contentType);
            }

            return restPath.CreateRequest(httpReq.PathInfo, requestParams, requestDto);

        }

        protected object CreateContentTypeRequest(HttpExtensions.HttpRequestWrapper httpReq, Type requestType, string contentType)
        {
            try
            {
                if (!string.IsNullOrEmpty(contentType) && (httpReq.ContentLength > 0 || httpReq.IsChunked))
                {
                    var deserializer = HttpResponseSerialize.GetStreamDeserializer(contentType);
                    if (deserializer != null)
                    {
                        //保证原始input流不被关闭
                        MemoryStream copy = new MemoryStream();
                        httpReq.InputStream.CopyTo(copy);
                        copy.Position = 0;
                        httpReq.InputStream.Position = 0;
                        return deserializer(requestType, copy);
                    }
                }
            }
            catch (Exception ex)
            {
                var msg = "Could not deserialize '{0}' request using {1}'\nError: {2}"
                    .Fmt(contentType, requestType, ex);
                throw new SerializationException(msg);
            }
            return null;
        }

        public object GetResponse(HttpExtensions.HttpRequestWrapper httpReq, HttpExtensions.HttpResponseWrapper httpRes, object request)
        {
            var requestContentType = ContentType.GetContentType(httpReq.ResponseContentType);
            var httpMethod = HttpMethods.GetEndpointAttribute(httpReq.HttpMethod);
            ExecuteContext exeContext = httpReq.GetExecuteContext();
            exeContext.ContentType = requestContentType;
            exeContext.HttpMethod = httpMethod;
            return ExecuteService(request, exeContext, httpReq, httpRes);
        }

        private object ExecuteService(object request, ExecuteContext exeContext,
            HttpExtensions.HttpRequestWrapper httpReq, HttpExtensions.HttpResponseWrapper httpRes)
        {
            HttpRequestContext context = new HttpRequestContext(request, httpReq, httpRes);
            context.ExecuteContext = exeContext;
            return AppConfig.Instance.ServiceManager.Execute(request, context);
        }
    }
}
