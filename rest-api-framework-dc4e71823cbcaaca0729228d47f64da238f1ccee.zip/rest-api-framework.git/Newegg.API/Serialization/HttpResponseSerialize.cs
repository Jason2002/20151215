﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;
using System.IO;
using Newegg.API.Common;
using ServiceStack.Text;

namespace Newegg.API.Serialization
{
    public delegate string TextSerializerDelegate(object dto);

    public delegate void StreamSerializerDelegate(HttpRequestContext requestContext, object dto, Stream outputStream);

    public delegate void ResponseSerializerDelegate(HttpRequestContext requestContext, object dto, HttpResponseWrapper httpRes);

    public delegate object TextDeserializerDelegate(Type type, string dto);

    public delegate object StreamDeserializerDelegate(Type type, Stream fromStream);

    public class HttpResponseSerialize
    {
        public static StreamSerializerDelegate GetStreamSerializer(string contentType)
        {
            var contentTypeAttr = ContentType.GetContentType(contentType);
            switch (contentTypeAttr)
            {
                case ContentType.Xml:
                case ContentType.XmlText:
                    return (r, o, s) => XmlSimpleSerializer.SerializeToStream(o, s);

                case ContentType.Json:
                case ContentType.JsonText:
                    return (r, o, s) => JsonSerializer.SerializeToStream(o, s);

                case ContentType.Jsv:
                    return (r, o, s) => TypeSerializer.SerializeToStream(o, s);

                //case ContentType.Csv:
                //    return (r, o, s) => CsvSerializer.SerializeToStream(o, s);
            }

            return null;
        }

        public static TextSerializerDelegate GetStringSerializer(string contentType)
        {
            var contentTypeAttr = ContentType.GetContentType(contentType);
            switch (contentTypeAttr)
            {
                case ContentType.Xml:
                case ContentType.XmlText:
                    return (o) => XmlSimpleSerializer.SerializeToString(o);

                case ContentType.Json:
                case ContentType.JsonText:
                    return (o) => JsonSerializer.SerializeToString(o);

                case ContentType.Jsv:
                    return (o) => TypeSerializer.SerializeToString(o);

                    //case ContentType.Csv:
                    //    return (r, o, s) => CsvSerializer.SerializeToStream(o, s);
            }

            return null;
        }

        public static StreamDeserializerDelegate GetStreamDeserializer(string contentType)
        {
            var contentTypeAttr = ContentType.GetContentType(contentType);
            switch (contentTypeAttr)
            {
                case ContentType.Xml:
                case ContentType.XmlText:
                    return XmlSimpleSerializer.DeserializeFromStream;

                case ContentType.Json:
                case ContentType.JsonText:
                    return JsonSerializer.DeserializeFromStream;

                case ContentType.Jsv:
                    return TypeSerializer.DeserializeFromStream;

                //case ContentType.Csv:
                //    return CsvSerializer.DeserializeFromStream;
            }

            return null;
        }

        public static ResponseSerializerDelegate GetResponseSerializer(string contentType)
        {
            var serializer = GetStreamSerializer(contentType);
            if (serializer == null) return null;

            return (httpReq, dto, httpRes) => serializer(httpReq, dto, httpRes.OutputStream);
        }
    }
}
