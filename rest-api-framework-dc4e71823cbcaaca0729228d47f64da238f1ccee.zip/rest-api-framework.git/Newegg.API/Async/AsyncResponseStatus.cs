﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Newegg.API.Async
{
    public class AsyncResponseStatus
    {
        
        public DateTime Received { get; set; }

        
        public string RequestUri { get; set; }

        
        public string ResourceUri { get; set; }
    }
}
