﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;
using Newegg.API.Cache;
using Newegg.API.ServiceHost;
using System.Threading.Tasks;
using Newegg.API.Exceptions;
using Newegg.API.Common;

namespace Newegg.API.Async
{
    public class AsyncHandler
    {
        public static object HandlerAsync(HttpRequestContext context, string resourceUri)
        {
            return ResponseFactory.CreateAsyncResponse(context, resourceUri);
        }
    }
}
