﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Newegg.API.Monitors
//{
//    public class MonitorFactory
//    {
//        private static IMonitor monitor;

//        /// <summary>
//        /// Gets or sets the log factory.
//        /// Use this to override the factory that is used to create loggers
//        /// </summary>
//        /// <value>The log factory.</value>
//        public static IMonitor MonitorProvider
//        {
//            get
//            {
//                if (monitor == null)
//                {
//                    monitor = new DebugMonitor();
//                }
//                return monitor;
//            }
//            set { monitor = value; }
//        }
//    }
//}
