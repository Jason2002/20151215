﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Collections.Specialized;

//namespace Newegg.API.Monitors
//{
//    public static class MonitorHelper
//    {
//        public static List<HeaderInfo> GetHeaderInfo(HttpExtensions.HttpRequestWrapper req)
//        {
//            return GetHeaderCore(req.Headers);
//        }

//        public static List<HeaderInfo> GetHeaderInfo(HttpExtensions.HttpResponseWrapper res)
//        {
//            return GetHeaderCore(res.Headers);
//        }

//        private static List<HeaderInfo> GetHeaderCore(NameValueCollection headerCollection)
//        {
//            List<HeaderInfo> headers = new List<HeaderInfo>();
//            foreach (var key in headerCollection.AllKeys)
//            {
//                headers.Add(new HeaderInfo
//                {
//                    HeaderName = key,
//                    HeaderValue = headerCollection[key],
//                });
//            }

//            return headers;
//        }
//    }
//}
