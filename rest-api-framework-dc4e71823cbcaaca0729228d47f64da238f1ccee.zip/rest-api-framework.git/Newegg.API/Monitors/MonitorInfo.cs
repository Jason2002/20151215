﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Newegg.API.Models;

//namespace Newegg.API.Monitors
//{
//    public class MonitorInfo
//    {
//        public string PathInfo { get; set; }

//        public string IPAddress { get; set; }

//        public string HttpMethod { get; set; }

//        public DateTime RequestTime { get; set; }

//        public DateTime ResponseTime { get; set; }

//        public string RawUrl { get; set; }

//        public object RequestDto { get; set; }

//        public RequestAuthInfo AuthInfo { get; set; }

//        public List<HeaderInfo> RequestHeader { get; set; }

//        public object ResponseDto { get; set; }
//    }

//    public class HeaderInfo
//    {
//        public string HeaderName { get; set; }

//        public string HeaderValue { get; set; }
//    }
//}
