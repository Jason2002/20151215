﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using ServiceStack.Text;

//namespace Newegg.API.Monitors
//{
//    public class DebugMonitor : IMonitor
//    {
//        public void Record(HttpExtensions.HttpRequestWrapper req, HttpExtensions.HttpResponseWrapper res, object response)
//        {
//            try
//            {
//                if (req.MonitorInfo != null)
//                {
//                    if (response != null)
//                    {
//                        req.MonitorInfo.ResponseDto = XmlSerializer.SerializeToString(response);
//                    }
//                    req.MonitorInfo.ResponseTime = DateTime.Now;
//                    System.Diagnostics.Debug.WriteLine(XmlSerializer.SerializeToString<MonitorInfo>(req.MonitorInfo));
//                }
//                else
//                {
//                    return;
//                }
//            }
//            catch { }
            
//        }
//    }
//}
