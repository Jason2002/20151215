﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Common
{
    public static class AssemblyHelper
    {
        public static bool TryParseTypeFromString(string typeAssem, out string typeName, out string assemName)
        {
            int length = typeAssem.IndexOf(",");
            if ((length >= 0) && (length < (typeAssem.Length - 1)))
            {
                typeName = typeAssem.Substring(0, length).Trim();
                assemName = typeAssem.Substring(length + 1).Trim();
                return true;
            }
            else
            {
                typeName = string.Empty;
                assemName = string.Empty;
                return false;
            }
        }
    }
}
