﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using ServiceStack.Text;

namespace Newegg.API.Common
{
    public class NetDeflateProvider
    {
        public byte[] Deflate(string text)
        {
            var buffer = Encoding.UTF8.GetBytes(text);
            using (var ms = new MemoryStream())
            using (var zipStream = new DeflateStream(ms, CompressionMode.Compress))
            {
                zipStream.Write(buffer, 0, buffer.Length);
                zipStream.Close();

                return ms.ToArray();
            }
        }

        public string Inflate(byte[] gzBuffer)
        {
            using (var compressedStream = new MemoryStream(gzBuffer))
            using (var zipStream = new DeflateStream(compressedStream, CompressionMode.Decompress))
            {
                var utf8Bytes = zipStream.ReadFully();
                return Encoding.UTF8.GetString(utf8Bytes);
            }
        }

    }

    public class NetGZipProvider
    {
        public byte[] GZip(string text)
        {
            var buffer = Encoding.UTF8.GetBytes(text);
            using (var ms = new MemoryStream())
            using (var zipStream = new GZipStream(ms, CompressionMode.Compress))
            {
                zipStream.Write(buffer, 0, buffer.Length);
                zipStream.Close();

                return ms.ToArray();
            }
        }

        public string GUnzip(byte[] gzBuffer)
        {
            using (var compressedStream = new MemoryStream(gzBuffer))
            using (var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress))
            {
                var utf8Bytes = zipStream.ReadFully();
                return Encoding.UTF8.GetString(utf8Bytes);
            }
        }
    }

    public static class StreamExtensions
    {
        
        public static byte[] CompressDeflate(this string text)
        {
            return Deflate(text);
        }

        public static byte[] CompressGZip(this string text)
        {
            return GZip(text);
        }

        public static NetDeflateProvider DeflateProvider = new NetDeflateProvider();

        public static NetGZipProvider GZipProvider = new NetGZipProvider();

        public static string DecompressFlate(this byte[] gzBuffer)
        {
            return Inflate(gzBuffer);
        }

        public static string DecompressGzip(this byte[] gzBuffer)
        {
            return GUnzip(gzBuffer);
        }

        public static byte[] Deflate(this string text)
        {
            return DeflateProvider.Deflate(text);
        }

        public static string Inflate(this byte[] gzBuffer)
        {
            return DeflateProvider.Inflate(gzBuffer);
        }

        public static byte[] GZip(this string text)
        {
            return GZipProvider.GZip(text);
        }

        public static string GUnzip(this byte[] gzBuffer)
        {
            return GZipProvider.GUnzip(gzBuffer);
        }

        public static string ToUtf8String(this Stream stream)
        {
            if (stream == null) throw new ArgumentNullException("stream");

            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }

        public static byte[] ToBytes(this Stream stream)
        {
            if (stream == null) throw new ArgumentNullException("stream");

            return stream.ReadFully();
        }

        public static void Write(this Stream stream, string text)
        {
            var bytes = Encoding.UTF8.GetBytes(text);
            stream.Write(bytes, 0, bytes.Length);
        }

    }
}
