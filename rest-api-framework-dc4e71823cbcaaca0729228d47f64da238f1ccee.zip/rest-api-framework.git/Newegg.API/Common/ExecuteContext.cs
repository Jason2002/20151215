﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Common
{
    public class ExecuteContext
    {
        public string ContentType { get; set; }

        public string HttpMethod { get; set; }

        public InvokeType InvokeType { get; set; }

        public string CallbackUri { get; set; }

        public string MessageName { get; set; }

        public string View { get; set; }

        public string Expand { get; set; }

        public string SearchText { get; set; }
    }

    public enum InvokeType
    {
        Normal,
        Async,
        Message,
    }
}
