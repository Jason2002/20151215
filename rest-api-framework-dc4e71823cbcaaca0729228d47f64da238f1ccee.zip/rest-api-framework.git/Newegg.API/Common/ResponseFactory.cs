﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Async;
using Newegg.API.HttpExtensions;
using Newegg.API.Models;
using Newegg.API.Exceptions;

namespace Newegg.API.Common
{
    internal class ResponseFactory
    {
        internal static AsyncResponseStatus CreateAsyncResponse(HttpRequestContext context, string resourceUri)
        {
            AsyncResponseStatus response = new AsyncResponseStatus();
            response.Received = DateTime.UtcNow;
            response.RequestUri = context.RawUrl;
            response.ResourceUri = resourceUri;

            context.ResponseCode = System.Net.HttpStatusCode.Accepted;

            return response;
        }

        internal static ResponseStatus CreateCreatedResponse(HttpRequestContext context, string createdResourceUri)
        {
            ResponseStatus response = new ResponseStatus();
            response.Message = "Resource has been created.";
            response.ResponseCode = ErrorCode.EntityCreated;
            response.StatusCode = System.Net.HttpStatusCode.Created;
            context.AddLocationHeader(createdResourceUri);

            return response;
        }

        internal static ResponseStatus CreateNoResponse(HttpRequestContext context)
        {
            ResponseStatus response = new ResponseStatus();
            response.Message = "Request received but no response back.";
            response.ResponseCode = ErrorCode.NoResponse;
            response.StatusCode = System.Net.HttpStatusCode.NoContent;

            return response;
        }

        internal static ResponseStatus CreateRedirectResponse(HttpRequestContext context, string redirectUri)
        {
            ResponseStatus response = new ResponseStatus();
            response.Message = "Resource has been moved to new address.";
            response.ResponseCode = ErrorCode.ResourceMoved;
            response.StatusCode = System.Net.HttpStatusCode.Moved;
            context.AddLocationHeader(redirectUri);

            return response;
        }
    }
}
