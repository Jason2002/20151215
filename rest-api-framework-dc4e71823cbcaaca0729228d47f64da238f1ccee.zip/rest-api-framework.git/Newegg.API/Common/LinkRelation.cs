﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Common
{
    public static class LinkRelation
    {
        public const string Alernate = "alernate";

        public const string Stylesheet = "stylesheet";

        public const string Start = "start";

        public const string Last = "last";

        public const string Next = "next";

        public const string Prev = "prev";

        public const string Contents = "contents";

        public const string Index = "index";

        public const string Glossary = "glossary";

        public const string Copyright = "copyright";

        public const string Chapter = "chapter";

        public const string Section = "section";

        public const string Subsection = "subsection";

        public const string Appendix = "appendix";

        public const string Help = "help";

        public const string Self = "self";

        public const string Edit = "edit";

        public const string Related = "related";
    }
}
