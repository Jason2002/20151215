﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;
using Newegg.API.Attributes;
using System.Threading;
using Newegg.API.Logging;
using Newegg.API.Profile;

namespace Newegg.API.ServiceHost
{
    public class FilterManager
    {
        public List<Action<HttpRequestWrapper, HttpResponseWrapper, object>> RequestFilters { get; private set; }

        public List<Action<HttpRequestWrapper, HttpResponseWrapper, object>> ResponseFilters { get; private set; }

        private Dictionary<Type, IHasRequestFilter[]> requestFilterAttributes
            = new Dictionary<Type, IHasRequestFilter[]>();

        private Dictionary<Type, IHasResponseFilter[]> responseFilterAttributes
            = new Dictionary<Type, IHasResponseFilter[]>();

        public FilterManager()
        {
            RequestFilters = new List<Action<HttpRequestWrapper, HttpResponseWrapper, object>>();
            ResponseFilters = new List<Action<HttpRequestWrapper, HttpResponseWrapper, object>>();
        }

        public bool ApplyRequestFilters(HttpRequestWrapper httpReq, HttpResponseWrapper httpRes, object requestDto)
        {
            var attributes = GetRequestFilterAttributes(requestDto.GetType());
            var i = 0;
            for (; i < attributes.Length && attributes[i].Priority < 0; i++)
            {
                var attribute = attributes[i];
                AppConfig.Instance.ServiceManager.Container.AutoWire(attribute);
                attribute.RequestFilter(httpReq, httpRes, requestDto);
                if (httpRes.IsClosed) return httpRes.IsClosed;
            }

            foreach (var requestFilter in RequestFilters)
            {
                requestFilter(httpReq, httpRes, requestDto);
                if (httpRes.IsClosed)
                {
                    return httpRes.IsClosed;
                }
            }

            for (; i < attributes.Length; i++)
            {
                var attribute = attributes[i];
                AppConfig.Instance.ServiceManager.Container.AutoWire(attribute);
                attribute.RequestFilter(httpReq, httpRes, requestDto);
                if (httpRes.IsClosed) return httpRes.IsClosed;
            }
            return httpRes.IsClosed;
        }

        
        public bool ApplyResponseFilters(HttpRequestWrapper httpReq, HttpResponseWrapper httpRes, object response)
        {
            var attributes = response != null
                ? GetResponseFilterAttributes(response.GetType())
                : null;

            var i = 0;
            if (attributes != null)
            {
                for (; i < attributes.Length && attributes[i].Priority < 0; i++)
                {
                    var attribute = attributes[i];
                    AppConfig.Instance.ServiceManager.Container.AutoWire(attribute);
                    attribute.ResponseFilter(httpReq, httpRes, response);
                    
                    if (httpRes.IsClosed) return httpRes.IsClosed;
                }
            }

            foreach (var responseFilter in ResponseFilters)
            {
                responseFilter(httpReq, httpRes, response);
                if (httpRes.IsClosed)
                {
                    return httpRes.IsClosed;
                }
            }

            if (attributes != null)
            {
                for (; i < attributes.Length; i++)
                {
                    var attribute = attributes[i];
                    AppConfig.Instance.ServiceManager.Container.AutoWire(attribute);
                    attribute.ResponseFilter(httpReq, httpRes, response);
                    
                    if (httpRes.IsClosed) return httpRes.IsClosed;
                }
            }
            return httpRes.IsClosed;
        }

        private IHasRequestFilter[] GetRequestFilterAttributes(Type requestDtoType)
        {
            IHasRequestFilter[] attrs;
            if (requestFilterAttributes.TryGetValue(requestDtoType, out attrs)) return attrs;

            var attributes = new List<IHasRequestFilter>(
                (IHasRequestFilter[])requestDtoType.GetCustomAttributes(typeof(IHasRequestFilter), true));

            attributes.Sort((x, y) => x.Priority - y.Priority);
            attrs = attributes.ToArray();

            Dictionary<Type, IHasRequestFilter[]> snapshot, newCache;
            do
            {
                snapshot = requestFilterAttributes;
                newCache = new Dictionary<Type, IHasRequestFilter[]>(requestFilterAttributes);
                newCache[requestDtoType] = attrs;

            } while (!ReferenceEquals(
            Interlocked.CompareExchange(ref requestFilterAttributes, newCache, snapshot), snapshot));

            return attrs;
        }

        private IHasResponseFilter[] GetResponseFilterAttributes(Type responseDtoType)
        {
            IHasResponseFilter[] attrs;
            if (responseFilterAttributes.TryGetValue(responseDtoType, out attrs)) return attrs;

            var attributes = new List<IHasResponseFilter>(
                (IHasResponseFilter[])responseDtoType.GetCustomAttributes(typeof(IHasResponseFilter), true));

            attributes.Sort((x, y) => x.Priority - y.Priority);
            attrs = attributes.ToArray();

            Dictionary<Type, IHasResponseFilter[]> snapshot, newCache;
            do
            {
                snapshot = responseFilterAttributes;
                newCache = new Dictionary<Type, IHasResponseFilter[]>(responseFilterAttributes);
                newCache[responseDtoType] = attrs;

            } while (!ReferenceEquals(
            Interlocked.CompareExchange(ref responseFilterAttributes, newCache, snapshot), snapshot));

            return attrs;
        }
    }
}
