﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Funq;
using Newegg.API.Logging;
using System.Linq.Expressions;
using Newegg.API.Interfaces;
using Newegg.API.Attributes;
using Newegg.API.HttpExtensions;
using ServiceStack.Text;
using Newegg.API.Common;
using Newegg.API.Profile;

namespace Newegg.API.ServiceHost
{
    public class ServiceManager
    {
        private static readonly ILog Log = LogFactory.Log;
        public Container Container { get; private set; }
        private ContainerResolveCache typeFactory;
        private Assembly[] m_assembliesWithServices;
        readonly Dictionary<Type, Func<HttpRequestContext, object, object>> requestExecMap
            = new Dictionary<Type, Func<HttpRequestContext, object, object>>();

        private List<Type> SubServiceInit { get; set; }

        public HashSet<Type> ServiceTypes { get; protected set; }

        public Dictionary<Type, List<Type>> RequestResponseMap;

        public Dictionary<Type, Type> RequestServiceMap;

        public ServiceManager(Assembly[] assembliesWithServices)
        {
            if (assembliesWithServices != null && assembliesWithServices.Length > 0)
            {
                m_assembliesWithServices = assembliesWithServices;
            }

            this.Container = new Container();
            SubServiceInit = new List<Type>();
            ServiceTypes = new HashSet<Type>();
            RequestResponseMap = new Dictionary<Type, List<Type>>();
            RequestServiceMap = new Dictionary<Type, Type>();
        }

        private List<Type> GetAssemblyTypes(Assembly[] assembliesWithServices)
        {
            var results = new List<Type>();
            string assemblyName = null;
            string typeName = null;

            try
            {
                foreach (var assembly in assembliesWithServices)
                {
                    assemblyName = assembly.FullName;
                    foreach (var type in assembly.GetTypes())
                    {
                        typeName = type.Name;
                        results.Add(type);
                    }
                }
                return results;
            }
            catch (Exception ex)
            {
                var msg = string.Format("Failed loading types, last assembly '{0}', type: '{1}'", assemblyName, typeName);
                Log.Error(msg, ex);
                throw new Exception(msg, ex);
            }
        }

        public void Init()
        {
            typeFactory = new ContainerResolveCache(this.Container);
            Register();
        }

        
        public void Register()
        {
            if (m_assembliesWithServices != null && m_assembliesWithServices.Length > 0)
            {
                RegisterServiceCore(m_assembliesWithServices);
            }
        }

        internal void Register(Type serviceType)
        {
            RegisterService(serviceType);
            this.Container.RegisterAutoWiredTypes(this.ServiceTypes);
        }

        internal void Register(params Assembly[] assemblies)
        {
            RegisterServiceCore(assemblies);
        }

        #region Register Service
        private void RegisterServiceCore(params Assembly[] assemblies)
        {
            foreach (var serviceType in GetAssemblyTypes(assemblies))
            {
                RegisterServiceEntrance(serviceType);
                RegisterService(serviceType);
            }
            this.Container.RegisterAutoWiredTypes(this.ServiceTypes);
        }

        private void RegisterServiceEntrance(Type serviceType)
        {
            if (serviceType.IsSubclassOf(typeof(AppHostBase)))
            {
                SubServiceInit.Add(serviceType);
            }
        }

        private void RegisterService(Type serviceType)
        {
            if (serviceType.IsAbstract || serviceType.ContainsGenericParameters) return;

            RegisterMap(serviceType);

            foreach (var service in serviceType.GetInterfaces())
            {
                if (!service.IsGenericType
                    || service.GetGenericTypeDefinition() != typeof(IService<>)
                )
                {
                    continue;
                }

                var requestType = service.GetGenericArguments()[0];

                Register(requestType, serviceType);

                RegisterRestPaths(requestType);                

                this.ServiceTypes.Add(serviceType);
            }
        }

        private void Register(Type requestType, Type serviceType)
        {
            if (!RequestServiceMap.ContainsKey(requestType))
            {
                RequestServiceMap.Add(requestType, serviceType);
            }

            var typeFactoryFn = CallServiceExecuteGeneric(requestType, serviceType);

            Func<HttpRequestContext, object, object> handlerFn = (requestContext, dto) =>
            {
                var service = typeFactory.CreateInstance(serviceType);
                using (service as IDisposable) // using is happy if this expression evals to null
                {
                    InjectRequestContext(service, requestContext);

                    var executeContext = requestContext != null ? requestContext.ExecuteContext : new ExecuteContext();

                    try
                    {
                        //Executes the service and returns the result
                        var response = typeFactoryFn(dto, service, executeContext);
                        return response;
                    }
                    catch (TargetInvocationException tex)
                    {
                        throw tex.InnerException ?? tex;
                    }
                }
            };

            try
            {
                requestExecMap.Add(requestType, handlerFn);
            }
            catch (ArgumentException)
            {
                throw new AmbiguousMatchException(
                    string.Format("Could not register the service '{0}' as another service with the definition of type 'IService<{1}>' already exists.",
                    serviceType.FullName, requestType.Name));
            }
        }

        private static void InjectRequestContext(object service, HttpRequestContext requestContext)
        {
            if (requestContext == null) return;

            var servicesRequiresHttpRequest = service as IRequireContext;
            if (servicesRequiresHttpRequest != null)
            {
                servicesRequiresHttpRequest.RequestContext = requestContext;
            }
        }

        private static Func<object, object, ExecuteContext, object> CallServiceExecuteGeneric(Type requestType, Type serviceType)
        {
            var requestDtoParam = Expression.Parameter(typeof(object), "requestDto");
            var requestDtoStrong = Expression.Convert(requestDtoParam, requestType);

            var serviceParam = Expression.Parameter(typeof(object), "serviceObj");
            var serviceStrong = Expression.Convert(serviceParam, serviceType);

            var attrsParam = Expression.Parameter(typeof(ExecuteContext), "attrs");

            var mi = ServiceExec.GetExecMethodInfo(serviceType, requestType);

            Expression callExecute = Expression.Call(mi, new Expression[] { serviceStrong, requestDtoStrong, attrsParam });

            var executeFunc = Expression.Lambda<Func<object, object, ExecuteContext, object>>
                (callExecute, requestDtoParam, serviceParam, attrsParam).Compile();

            return executeFunc;


        }

        #endregion

        #region Execute Service

        public void ExecuteSubInit()
        {
            foreach (var initType in SubServiceInit)
            {
                var initObject = Activator.CreateInstance(initType) as AppHostBase;
                if (initObject != null)
                {
                    initObject.Init();
                }
            }
        }

        public object Execute(object dto)
        {
            return Execute(dto, null);
        }

        public object Execute(object request, HttpRequestContext requestContext)
        {
            var requestType = request.GetType();

            var handlerFn = GetService(requestType);
            return handlerFn(requestContext, request);
        }

        public Func<HttpRequestContext, object, object> GetService(Type requestType)
        {
            Func<HttpRequestContext, object, object> handlerFn;
            if (!requestExecMap.TryGetValue(requestType, out handlerFn))
            {
                throw new NotImplementedException(
                        string.Format("Unable to resolve service '{0}'", requestType.Name));
            }

            return handlerFn;
        }

        #endregion

        #region Register Rest Path
        public readonly Dictionary<string, List<RestPath>> RestPathMap = new Dictionary<string, List<RestPath>>();

        
        private void RegisterRestPaths(Type requestType)
        {
            var attrs = requestType.GetCustomAttributes(typeof(RestServiceAttribute), true);
            foreach (RestServiceAttribute attr in attrs)
            {
                var restPath = new RestPath(requestType, attr.Path, attr.Verbs);
                if (!restPath.IsValid)
                    throw new NotSupportedException(string.Format(
                        "RestPath '{0}' on Type '{1}' is not Valid", attr.Path, requestType.Name));

                RegisterRestPath(restPath);
            }
        }

        private void RegisterRestPath(RestPath restPath)
        {
            List<RestPath> pathsAtFirstMatch;
            if (!RestPathMap.TryGetValue(restPath.FirstMatchHashKey, out pathsAtFirstMatch))
            {
                pathsAtFirstMatch = new List<RestPath>();
                RestPathMap[restPath.FirstMatchHashKey] = pathsAtFirstMatch;
            }
            pathsAtFirstMatch.Add(restPath);
        }

        public RestPath GetRestPathForRequest(string httpMethod, string pathInfo)
        {
            var matchUsingPathParts = RestPath.GetPathPartsForMatching(pathInfo);

            List<RestPath> firstMatches;

            var yieldedHashMatches = RestPath.GetFirstMatchHashKeys(matchUsingPathParts);
            foreach (var potentialHashMatch in yieldedHashMatches)
            {
                if (!this.RestPathMap.TryGetValue(potentialHashMatch, out firstMatches)) continue;

                var bestScore = -1;
                foreach (var restPath in firstMatches)
                {
                    var score = restPath.MatchScore(httpMethod, matchUsingPathParts);
                    if (score > bestScore) bestScore = score;
                }

                if (bestScore > 0)
                {
                    foreach (var restPath in firstMatches)
                    {
                        if (bestScore == restPath.MatchScore(httpMethod, matchUsingPathParts))
                            return restPath;
                    }
                }
            }

            var yieldedWildcardMatches = RestPath.GetFirstMatchWildCardHashKeys(matchUsingPathParts);
            foreach (var potentialHashMatch in yieldedWildcardMatches)
            {
                if (!this.RestPathMap.TryGetValue(potentialHashMatch, out firstMatches)) continue;

                var bestScore = -1;
                foreach (var restPath in firstMatches)
                {
                    var score = restPath.MatchScore(httpMethod, matchUsingPathParts);
                    if (score > bestScore) bestScore = score;
                }
                if (bestScore > 0)
                {
                    foreach (var restPath in firstMatches)
                    {
                        if (bestScore == restPath.MatchScore(httpMethod, matchUsingPathParts))
                            return restPath;
                    }
                }
            }

            return null;
        }

        #endregion

        #region Register Request Response Map

        private void RegisterMap(Type responseType)
        {
            var attrs = responseType.GetCustomAttributes(typeof(ResponseTypeAttribute), true);
            if (attrs == null) return;

            foreach (ResponseTypeAttribute attr in attrs)
            {
                if (!RequestResponseMap.ContainsKey(attr.RequestType))
                {
                    RequestResponseMap.Add(attr.RequestType, new List<Type>());
                }

                RequestResponseMap[attr.RequestType].Add(responseType);
            }
        }

        #endregion
    }
}
