﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Newegg.API.Interfaces;
using Newegg.API.Common;

namespace Newegg.API.ServiceHost
{
    public class ServiceExec
    {
        private static readonly Dictionary<Type, MethodInfo> ServiceExecCache = new Dictionary<Type, MethodInfo>();

        public static MethodInfo GetExecMethodInfo(Type serviceType, Type requestType)
        {
            MethodInfo mi;
            lock (ServiceExecCache)
            {
                if (!ServiceExecCache.TryGetValue(requestType /*serviceType */, out mi))
                {
                    var genericType = typeof(ServiceExec<>).MakeGenericType(requestType);

                    mi = genericType.GetMethod("Execute", BindingFlags.Public | BindingFlags.Static);

                    ServiceExecCache.Add(requestType /* serviceType */, mi);
                }
            }

            return mi;
        }
    }

    public class ServiceExec<TReq>
    {

        public static object Execute(IService<TReq> service, TReq request, ExecuteContext attrs)
        {
            //if (attrs.IsAsyncCall)
            //{
            //    var asyncService = service as IAsyncService<TReq>;
            //    if (asyncService != null) return asyncService.ExecuteAsync(request);
            //}
            if (attrs.HttpMethod == HttpMethods.Get)
            {
                var restService = service as IRestGetService<TReq>;
                if (restService != null) return restService.Get(request);
            }
            else if (attrs.HttpMethod == HttpMethods.Post)
            {
                var restService = service as IRestPostService<TReq>;
                if (restService != null) return restService.Post(request);
            }
            else if (attrs.HttpMethod == HttpMethods.Put)
            {
                var restService = service as IRestPutService<TReq>;
                if (restService != null) return restService.Put(request);
            }
            else if (attrs.HttpMethod == HttpMethods.Delete)
            {
                var restService = service as IRestDeleteService<TReq>;
                if (restService != null) return restService.Delete(request);
            }
            else if (attrs.HttpMethod == HttpMethods.Patch)
            {
                var restService = service as IRestPatchService<TReq>;
                if (restService != null) return restService.Patch(request);
            }
            return service.Execute(request);
        }
    }
}
