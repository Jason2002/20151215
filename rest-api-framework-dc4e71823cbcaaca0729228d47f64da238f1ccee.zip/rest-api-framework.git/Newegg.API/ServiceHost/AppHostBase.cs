﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Newegg.API.Configuration;
using Newegg.API.HttpExtensions;
using Newegg.API.Common;
using System.Reflection;
using Newegg.API.Logging;
using Newegg.API.Cache;
using Newegg.API.Interfaces;
using Newegg.API.Profile;
using Newegg.API.Auth;
using Newegg.API.Exceptions;
using ServiceStack.Text;

namespace Newegg.API.ServiceHost
{
    public class AppHostBase
    {
        public static void Start()
        {
            new AppHostBase().InitAppInternal();
        }

        public List<Action<HttpRequestWrapper, HttpResponseWrapper, object>> RequestFilters
        {
            get
            {
                return AppConfig.Instance.FilterManager.RequestFilters;
            }
        }

        public List<Action<HttpRequestWrapper, HttpResponseWrapper, object>> ResponseFilters
        {
            get
            {
                return AppConfig.Instance.FilterManager.ResponseFilters;
            }
        }

        public List<IPlugin> Plugins
        {
            get { return AppConfig.Instance.PluginManager.Plugins; }
        }

        internal void InitAppInternal()
        {
            ApplyConfig();
            ServiceManager manager = new ServiceManager(ResourceConfiguration.Assemblies);
            manager.Init();
            AppConfig.Instance.ServiceManager = manager;
            AppConfig.Instance.FilterManager = new FilterManager();
            AppConfig.Instance.PluginManager = new PluginManager();
            AddGlobalRequestFilters();
            this.Plugins.Add(new Validation.ValidationPlugin());
            manager.ExecuteSubInit();
            AppConfig.Instance.PluginManager.LoadPlugin();
        }

        [Obsolete("该方法已经过期，请不要再继续使用，目前不需要在Global.asax.cs中调用任何代码")]
        public void InitApp()
        {
        }

        public virtual void Init()
        {

        }

        #region Apply Config

        private void ApplyConfig()
        {
            AppConfig.Instance.APIName = ResourceConfiguration.APIName;
            //SetLogger(ResourceConfiguration.Logger);
            SetCache(ResourceConfiguration.Cache);
            SetAuth(ResourceConfiguration.Auth);
            SetEnableAuth(ResourceConfiguration.EnableAuth);
            //SetEnableMonitor(ResourceConfiguration.EnableMonitor);
            //SetMonitor(ResourceConfiguration.Monitor);
            SetDebug(ResourceConfiguration.DebugMode);
            SetExpireTime(ResourceConfiguration.DefaultExpireTime);
        }

        private void SetEnableAuth(string enableAuth)
        {
            bool enable = false;
            if (!string.IsNullOrEmpty(enableAuth) && bool.TryParse(enableAuth, out enable))
            {
                AppConfig.Instance.EnableAuth = enable;
            }
        }

        private void SetAuth(string authType)
        {
            string typeName;
            string assemName;
            if (AssemblyHelper.TryParseTypeFromString(authType, out typeName, out assemName))
            {
                var auth = CreateInstance(typeName, assemName);
                if (auth != null && auth is IAuth)
                {
                    AuthFactory.AuthProvider = (IAuth)auth;
                }
            }
        }

        //private void SetEnableMonitor(string enableMonitor)
        //{
        //    bool enable = false;
        //    if (!string.IsNullOrEmpty(enableMonitor) && bool.TryParse(enableMonitor, out enable))
        //    {
        //        AppConfig.Instance.EnableMonitor = enable;
        //    }
        //}

        //private void SetMonitor(string monitorType)
        //{
        //    string typeName;
        //    string assemName;
        //    if (AssemblyHelper.TryParseTypeFromString(monitorType, out typeName, out assemName))
        //    {
        //        var monitor = CreateInstance(typeName, assemName);
        //        if (monitor != null && monitor is IMonitor)
        //        {
        //            MonitorFactory.MonitorProvider = (IMonitor)monitor;
        //        }
        //    }
        //}

        private void SetExpireTime(string expireTime)
        {
            int time = 60;
            if (!string.IsNullOrEmpty(expireTime) && Int32.TryParse(expireTime, out time))
            {
                AppConfig.Instance.DefaultExpireTime = TimeSpan.FromMinutes(time);
            }
        }

        private void SetDebug(string debugMode)
        {
            bool debug = false;
            if (!string.IsNullOrEmpty(debugMode) && bool.TryParse(debugMode, out debug))
            {
                AppConfig.Instance.DebugMode = debug;
                if (!debug)
                {
                    AppConfig.Instance.DefaultContentType = ContentType.Json;
                    AppConfig.Instance.PreferredContentTypes.Remove(ContentType.Html);
                }
            }
        }

        //private void SetLogger(string logType)
        //{
        //    string typeName;
        //    string assemName;
        //    if (AssemblyHelper.TryParseTypeFromString(logType, out typeName, out assemName))
        //    {
        //        var log = CreateInstance(typeName, assemName);
        //        if (log != null && log is ILog)
        //        {
        //            LogFactory.Log = (ILog)log;
        //        }
        //    }
        //}

        private void SetCache(string cacheType)
        {
            string typeName;
            string assemName;
            if (AssemblyHelper.TryParseTypeFromString(cacheType, out typeName, out assemName))
            {
                var cache = CreateInstance(typeName, assemName);
                if (cache != null && cache is ICacheClient)
                {
                    CacheFactory.CacheClient = (ICacheClient)cache;
                }
            }
        }

        private object CreateInstance(string typeName, string assemblyName)
        {
            Assembly assembly;
            try
            {
                assembly = Assembly.Load(assemblyName);
                Type type = assembly.GetType(typeName, false, false);
                if (type == null)
                {
                    return null;
                }
                object obj;
                obj = Activator.CreateInstance(type);
                return obj;
            }
            catch
            {
                return null;
            }
        }

        #endregion

        private void AddGlobalRequestFilters()
        {
            this.RequestFilters.Add((req, res, requestDto) =>
                {
                    if (req.HttpMethod == HttpMethods.Options)
                    {
                        Type serviceType;
                        AppConfig.Instance.ServiceManager.RequestServiceMap.TryGetValue(requestDto.GetType(),
                            out serviceType);
                        string allowHeader = "OPTIONS";
                        if (serviceType != null)
                        {
                            allowHeader += (serviceType.GetMethodInfo("OnGet").DeclaringType == serviceType) ? ", GET" : "";
                            allowHeader += (serviceType.GetMethodInfo("OnPost").DeclaringType == serviceType) ? ", POST" : "";
                            allowHeader += (serviceType.GetMethodInfo("OnPut").DeclaringType == serviceType) ? ", PUT" : "";
                            allowHeader += (serviceType.GetMethodInfo("OnDelete").DeclaringType == serviceType) ? ", DELETE" : "";
                            allowHeader += (serviceType.GetMethodInfo("OnPatch").DeclaringType == serviceType) ? ", PATCH" : "";
                        }
                        res.AddHeader(HttpHeaders.AllowMethods, allowHeader);
                        res.Close();
                    }
                });

            //Handler LanguageCode
            this.RequestFilters.Add((req, res, requestDto) =>
                {
                    if (AppConfig.Instance.SupportLanguageCode.FirstOrDefault(l => l.Equals(req.LanguageCode, StringComparison.InvariantCultureIgnoreCase)) != null)
                    {
                        res.Language = req.LanguageCode;
                    }
                    else
                    {
                        res.Language = AppConfig.Instance.DefaultContentLanguage;
                    }
                });

            //Handler Auth
            this.RequestFilters.Add((req, res, requestDto) =>
                {
                    if (!AuthHelper.TryParseAuthForGateway(req))
                    {
                        if (AppConfig.Instance.EnableAuth)
                        {
                            if (!AuthFactory.AuthProvider.Authenticate(req))
                            {
                                throw new HttpError(System.Net.HttpStatusCode.Unauthorized, ErrorCode.AuthFailed, "Authentication Failed.");
                            }
                        }
                    }
                });


            //Generate Debug Snapshot 
            this.ResponseFilters.Add((req, res, requestDto) =>
                {
                    HtmlReport report = new HtmlReport();
                    report.GenerateReport(req, res, requestDto);
                });
        }

        public void RegisterValidators(params Assembly[] assemblies)
        {
            AppConfig.Instance.RegisterValidators(assemblies);
        }

        public void RegisterValidator(Type validator)
        {
            AppConfig.Instance.RegisterValidator(validator);
        }

        public void RegisterService(Type service)
        {
            AppConfig.Instance.ServiceManager.Register(service);
        }

        public void RegisterServices(params Assembly[] assemblies)
        {
            AppConfig.Instance.ServiceManager.Register(assemblies);
        }

        public void RegisterIgnoreLoggingException(Type exceptionType)
        {
            if (!typeof(Exception).IsAssignableFrom(exceptionType)) return;
            if (AppConfig.Instance.IgnoreLoggingExceptions.Contains(exceptionType)) return;

            AppConfig.Instance.IgnoreLoggingExceptions.Add(exceptionType);
        }

        public void RegisterIgnoreLoggingStatusCode(HttpStatusCode code)
        {
            if (AppConfig.Instance.IgnoreLoggingStatusCodes.Contains(code)) return;

            AppConfig.Instance.IgnoreLoggingStatusCodes.Add(code);
        }

        protected void SetDefaultPageInfo(int pageSize, int pageIndex, int maxSize)
        {
            AppConfig.Instance.DefaultPageIndex = pageIndex;
            AppConfig.Instance.DefaultPageSize = pageSize;
            AppConfig.Instance.MaxPageSize = maxSize;
        }
    }
}
