﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Newegg.API.Common;
using System.Reflection;
using FluentValidation;
using Newegg.API.Exceptions;
using ServiceStack.Text;

namespace Newegg.API.ServiceHost
{
    public class AppConfig
    {
        public ServiceManager ServiceManager
        {
            get;
            set;
        }

        public FilterManager FilterManager
        {
            get;
            set;
        }

        public PluginManager PluginManager
        {
            get;
            set;
        }

        public HashSet<string> AllowFileExtensions { get; set; }
        public bool DebugMode { get; set; }
        //public bool EnableMonitor { get; set; }
        public bool EnableAuth { get; set; }
        public string DefaultContentType { get; set; }
        public List<string> SupportLanguageCode { get; set; }
        public string DefaultContentLanguage { get; set; }
        public string APIName { get; set; }
        public TimeSpan DefaultExpireTime { get; set; }
        public List<string> PreferredContentTypes { get; set; }
        public int DefaultPageSize { get; set; }
        public int DefaultPageIndex { get; set; }
        public int MaxPageSize { get; set; }
        internal List<Type> IgnoreLoggingExceptions { get; set; }
        internal List<HttpStatusCode> IgnoreLoggingStatusCodes { get; set; }

        private static AppConfig instance;
        public static AppConfig Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new AppConfig
                    {
                        DebugMode = false,
                        EnableAuth = false,
                        DefaultContentType = ContentType.Html,
                        DefaultContentLanguage = "en-us",
                        DefaultPageIndex = 0,
                        DefaultPageSize = 10,
                        MaxPageSize = 10000,
                        SupportLanguageCode = new List<string> { "en-us", "zh-cn", "zh-tw" },
                        AllowFileExtensions = new HashSet<string>(StringComparer.InvariantCultureIgnoreCase)
						{
							"js", "css", "htm", "html", "shtm", "txt", "xml", "rss", "csv", 
							"jpg", "jpeg", "gif", "png", "bmp", "ico", "tif", "tiff", 
							"avi", "divx", "m3u", "mov", "mp3", "mpeg", "mpg", "qt", "vob", "wav", "wma", "wmv", 
							"flv", "xap", "xaml", 
						},
                        DefaultExpireTime = TimeSpan.FromHours(1),
                        PreferredContentTypes = new List<string> { ContentType.Html, ContentType.Json, ContentType.JsonText, ContentType.Xml, ContentType.XmlText, ContentType.Jsv },
                        IgnoreLoggingExceptions = new List<Type>() { typeof(NotImplementedException) },
                        IgnoreLoggingStatusCodes = new List<HttpStatusCode>()
                    };
                }
                return instance;
            }
        }

        public AppConfig()
        {

        }

        public void Register<T>(T instance)
        {
            this.ServiceManager.Container.Register(instance);
        }

        public T TryResolve<T>()
        {
            return this.ServiceManager.Container.TryResolve<T>();
        }

        public void RegisterValidators(params Assembly[] assemblies)
        {
            foreach (var assembly in assemblies)
            {
                foreach (var validator in assembly.GetTypes()
                .Where(t => t.IsOrHasGenericInterfaceTypeOf(typeof(IValidator<>))))
                {
                    RegisterValidator(validator);
                }
            }
        }

        public void RegisterValidator(Type validator)
        {
            var baseType = validator.BaseType;
            while (!baseType.IsGenericType)
            {
                baseType = baseType.BaseType;
            }

            var dtoType = baseType.GetGenericArguments()[0];
            var validatorType = typeof(IValidator<>).MakeGenericType(dtoType);

            this.ServiceManager.Container.RegisterAutoWiredType(validator, validatorType);
        }

        internal bool IsLoggingException(Exception exception)
        {
            if (IgnoreLoggingExceptions.Contains(exception.GetType())) return false;
            var httpError = exception as HttpError;
            if (httpError != null)
            {
                if (IgnoreLoggingStatusCodes.Contains(httpError.StatusCode))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
