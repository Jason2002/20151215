﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Newegg.API.HttpExtensions;
using System.IO;
using Newegg.API.HttpHandlers;
using Newegg.API.Logging;

namespace Newegg.API.ServiceHost
{
    public class APIHttpHandlerFactory : IHttpHandlerFactory
    {
        static readonly List<string> WebHostRootFileNames = new List<string>();

        private ILog log = LogFactory.Log;

        static APIHttpHandlerFactory()
        {
            foreach (var dirName in Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory))
            {
                var dirNameLower = Path.GetFileName(dirName).ToLower(); 
                WebHostRootFileNames.Add(Path.GetFileName(dirNameLower));
            }
        }

        public IHttpHandler GetHandler(HttpContext context, string requestType, string url, string pathTranslated)
        {
            var pathInfo = context.Request.GetPathInfo();
            if (url == "/default.aspx" || url == "/Default.aspx")
            {
                pathInfo = "/";
            }

            return GetHandlerForPathInfo(
                context.Request.HttpMethod, pathInfo, context.Request.FilePath, pathTranslated)
                   ?? new NotFoundHandler();
        }

        public static IHttpHandler GetHandlerForPathInfo(string httpMethod, string pathInfo, string requestPath, string filePath)
        {
            var pathParts = pathInfo.TrimStart('/').Split('/');
            if (pathParts.Length == 0) return new NotFoundHandler();

            //to do: metadata handler
            //var handler = GetHandlerForPathParts(pathParts);
            //if (handler != null) return handler;

            var existingFile = pathParts[0].ToLower();
            if (WebHostRootFileNames.Contains(existingFile))
            {
                if (ShouldAllow(requestPath))
                {
                    return new StaticFileHandler();
                }
                else
                {
                    return new NotFoundHandler();
                }
            }

            //bool isMetadata = false;
            //if (pathParts[pathParts.Length - 1].ToLower() == "metadata")
            //{
            //    isMetadata = true;
            //    pathParts = pathInfo.TrimStart('/').ToLower().Replace("metadata", "").Split('/');
            //}

            var restPath = RestHandler.FindMatchingRestPath(httpMethod, pathInfo);
            if (restPath != null)
            {
                return new RestHandler { RestPath = restPath, RequestName = restPath.RequestType.Name };
            }
            //else if(restPath != null && isMetadata)
            //{
            //    return new WsdlMetadataHandler { RequestType = restPath.RequestType };
            //}

            return new NotFoundHandler();
        }

        private static bool ShouldAllow(string filePath)
        {
            var fileExt = Path.GetExtension(filePath);
            if (string.IsNullOrEmpty(fileExt)) return false;
            return AppConfig.Instance.AllowFileExtensions.Contains(fileExt.Substring(1));
        }

        public void ReleaseHandler(IHttpHandler handler)
        {

        }
    }
}
