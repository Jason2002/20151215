﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.API.Logging;

namespace Newegg.API.ServiceHost
{
    public class PluginManager
    {
        private ILog log = LogFactory.Log;

        public List<IPlugin> Plugins { get; set; }

        public PluginManager()
        {
            Plugins = new List<IPlugin>();
        }

        public void LoadPlugin()
        {
            foreach (var plugin in Plugins)
            {
                plugin.Register(AppConfig.Instance);

            }
        }
    }
}
