﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Cache
{
    public interface ICacheClient
        : IDisposable
    {
        /// <summary>
        /// Removes the specified item from the cache.
        /// </summary>
        /// <param name="key">The identifier for the item to delete.</param>
        /// <returns>
        /// true if the item was successfully removed from the cache; false otherwise.
        /// </returns>
        bool Remove(string key);

        /// <summary>
        /// Retrieves the specified item from the cache.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">The identifier for the item to retrieve.</param>
        /// <returns>
        /// The retrieved item, or <value>null</value> if the key was not found.
        /// </returns>
        T Get<T>(string key);

        CacheEntry Get(string key);

        List<string> SearchKeys(string keyPattern);

        /// <summary>
        /// Adds a new item into the cache at the specified cache key only if the cache is empty.
        /// </summary>
        /// <param name="key">The key used to reference the item.</param>
        /// <param name="value">The object to be inserted into the cache.</param>
        /// <returns>
        /// true if the item was successfully stored in the cache; false otherwise.
        /// </returns>
        /// <remarks>The item does not expire unless it is removed due memory pressure.</remarks>
        bool Add<T>(string key, T value);

        /// <summary>
        /// Sets an item into the cache at the cache key specified regardless if it already exists or not.
        /// </summary>
        bool Set<T>(string key, T value);

        /// <summary>
        /// Replaces the item at the cachekey specified only if an items exists at the location already. 
        /// </summary>
        bool Replace<T>(string key, T value);

        bool Add<T>(string key, T value, DateTime expiresAt);
        bool Set<T>(string key, T value, DateTime expiresAt);
        bool Replace<T>(string key, T value, DateTime expiresAt);

        bool Add<T>(string key, T value, TimeSpan expiresIn);
        bool Set<T>(string key, T value, TimeSpan expiresIn);
        bool Replace<T>(string key, T value, TimeSpan expiresIn);

        /// <summary>
        /// Invalidates all data on the cache.
        /// </summary>
        void FlushAll();
    }
}
