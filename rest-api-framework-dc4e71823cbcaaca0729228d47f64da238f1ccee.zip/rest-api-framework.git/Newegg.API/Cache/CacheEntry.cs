﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Cache
{
    public class CacheEntry
    {
        private object cacheValue;

        public DateTime ExpiresAt { get; set; }

        public DateTime LastModified { get; private set; }

        public string ETag { get; private set; }

        public CacheEntry(object value, DateTime expiresAt)
        {
            cacheValue = value;
            ExpiresAt = expiresAt;
            LastModified = DateTime.UtcNow;
            ETag = ETagHelper.NewETag();
        }

        public void SetValue(object value)
        {
            cacheValue = value;
            LastModified = DateTime.UtcNow;
            ETag = ETagHelper.NewETag();
        }

        public object Value
        {
            get { return cacheValue; }
            set
            {
                cacheValue = value;
            }
        }
    }
}
