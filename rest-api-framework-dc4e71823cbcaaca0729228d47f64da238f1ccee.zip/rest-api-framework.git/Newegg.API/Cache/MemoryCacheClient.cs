﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Cache.Transactions;
using Newegg.API.ServiceHost;

namespace Newegg.API.Cache
{
    public class MemoryCacheClient : ICacheClient
    {
        private TransactionalDictionary<string, CacheEntry> memory;

        public MemoryCacheClient()
        {
            memory = new TransactionalDictionary<string, CacheEntry>();
        }

        public bool Remove(string key)
        {
            return this.memory.Remove(key);
        }

        public T Get<T>(string key)
        {
            var value = Get(key);
            if (value != null && value.Value != null) return (T)value.Value;
            return default(T);
        }

        public CacheEntry Get(string key)
        {
            CacheEntry cacheEntry;
            if (this.memory.TryGetValue(key, out cacheEntry))
            {
                if (cacheEntry.ExpiresAt < DateTime.UtcNow)
                {
                    this.memory.Remove(key);
                    return null;
                }
                return cacheEntry;
            }
            return null;
        }

        

        private bool CacheAdd(string key, object value, DateTime expiresAt)
        {
            CacheEntry entry;
            if (this.memory.TryGetValue(key, out entry)) return false;

            entry = new CacheEntry(value, expiresAt);
            this.Set(key, entry);

            return true;
        }

        public bool Add<T>(string key, T value)
        {
            return CacheAdd(key, value, DateTime.UtcNow.Add(AppConfig.Instance.DefaultExpireTime));
        }

        private void Set(string key, CacheEntry entry)
        {
            this.memory[key] = entry;
        }

        public bool Set<T>(string key, T value)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(AppConfig.Instance.DefaultExpireTime));
        }

        private bool CacheSet(string key, object value, DateTime expiresAt)
        {
            CacheEntry entry;
            if (!this.memory.TryGetValue(key, out entry))
            {
                entry = new CacheEntry(value, expiresAt);
                this.Set(key, entry);
                return true;
            }

            entry.SetValue(value);
            entry.ExpiresAt = expiresAt;

            return true;
        }

        public bool Replace<T>(string key, T value)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(AppConfig.Instance.DefaultExpireTime));
        }

        public bool Add<T>(string key, T value, DateTime expiresAt)
        {
            return CacheAdd(key, value, expiresAt);
        }

        public bool Set<T>(string key, T value, DateTime expiresAt)
        {
            return CacheSet(key, value, expiresAt);
        }

        public bool Replace<T>(string key, T value, DateTime expiresAt)
        {
            return CacheSet(key, value, expiresAt);
        }

        public bool Add<T>(string key, T value, TimeSpan expiresIn)
        {
            return CacheAdd(key, value, DateTime.UtcNow.Add(expiresIn));
        }

        public bool Set<T>(string key, T value, TimeSpan expiresIn)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(expiresIn));
        }

        public bool Replace<T>(string key, T value, TimeSpan expiresIn)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(expiresIn));
        }

        public void FlushAll()
        {
            this.memory = new TransactionalDictionary<string, CacheEntry>();
        }

        public void Dispose()
        {
            this.memory = new TransactionalDictionary<string, CacheEntry>();
        }


        public List<string> SearchKeys(string keyPattern)
        {
            keyPattern = keyPattern.Replace("*", string.Empty);
            var find = this.memory.Keys.Where(k => k.Contains(keyPattern));
            if (find.Count() > 0)
            {
                return find.ToList();
            }
            else
            {
                return new List<string>();
            }
        }
    }
}
