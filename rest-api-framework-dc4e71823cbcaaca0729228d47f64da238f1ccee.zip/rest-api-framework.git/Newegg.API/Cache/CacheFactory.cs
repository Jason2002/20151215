﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Cache
{
    public class CacheFactory
    {
        private static ICacheClient cacheClient;

        /// <summary>
        /// Gets or sets the log factory.
        /// Use this to override the factory that is used to create loggers
        /// </summary>
        /// <value>The log factory.</value>
        public static ICacheClient CacheClient
        {
            get
            {
                if (cacheClient == null)
                {
                    cacheClient = new MemoryCacheClient();
                }
                return cacheClient;
            }
            set { cacheClient = value; }
        }
    }
}
