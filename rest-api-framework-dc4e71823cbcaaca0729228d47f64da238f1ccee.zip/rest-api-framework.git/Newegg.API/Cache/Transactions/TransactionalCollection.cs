﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Newegg.API.Cache.Transactions
{
    public abstract class TransactionalCollection<C, T> : Transactional<C>, IEnumerable<T> where C : IEnumerable<T>
    {
        public TransactionalCollection(C collection)
        {
            Value = collection;
        }
        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            return Value.GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            IEnumerable<T> enumerable = this;
            return enumerable.GetEnumerator();
        }
    }
}
