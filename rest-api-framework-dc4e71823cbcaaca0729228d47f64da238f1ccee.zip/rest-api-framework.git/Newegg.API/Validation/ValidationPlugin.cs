﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;

namespace Newegg.API.Validation
{
    public class ValidationPlugin : IPlugin
    {
        public void Register(ServiceHost.AppConfig appHost)
        {
            ValidationFilters filter = new ValidationFilters();
            appHost.FilterManager.RequestFilters.Add(filter.RequestFilter);
        }
    }
}
