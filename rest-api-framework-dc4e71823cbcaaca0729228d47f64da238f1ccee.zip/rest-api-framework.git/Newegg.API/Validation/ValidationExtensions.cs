﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Validation
{
    public static class ValidationExtensions
    {
        public static IRuleBuilderOptions<T, TProperty> NotNullorEmpty<T, TProperty>(this IRuleBuilder<T, TProperty> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new NotNullorEmptyValidator());
        }
    }
}
