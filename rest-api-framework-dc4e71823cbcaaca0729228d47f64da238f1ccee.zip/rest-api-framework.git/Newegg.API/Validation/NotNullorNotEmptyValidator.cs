﻿using FluentValidation.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Validation
{
    public class NotNullorEmptyValidator : PropertyValidator
    {
        public NotNullorEmptyValidator() : base("Property {PropertyName} must not be null or empty!")
        {

        }
        protected override bool IsValid(PropertyValidatorContext context)
        {
            var obj = context.PropertyValue;
            if (obj == null)
            {
                return false;
            }
            string val = obj as string;
            if (string.IsNullOrEmpty(val))
            {
                return false;
            }

            return true;
        }
    }
}
