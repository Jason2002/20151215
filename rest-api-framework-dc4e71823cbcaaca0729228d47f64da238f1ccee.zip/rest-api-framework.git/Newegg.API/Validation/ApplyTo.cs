﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Validation
{
    [Flags]
    public enum ApplyTo
    {
        All = Get | Post | Put | Delete | Patch,
        Get = 1 << 0,
        Post = 1 << 1,
        Put = 1 << 2,
        Delete = 1 << 3,
        Patch = 1 << 4,
        //Async = 1 << 5
    }
}
