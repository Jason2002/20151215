﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;
using FluentValidation;
using Newegg.API.ServiceHost;
using System.Threading;
using System.Reflection;

namespace Newegg.API.Validation
{
    public static class ValidatorCache
    {
        private static Dictionary<Type, ResolveValidatorDelegate> delegateCache
        = new Dictionary<Type, ResolveValidatorDelegate>();

        private delegate IValidator ResolveValidatorDelegate();

        public static IValidator GetValidator(Type type)
        {
            ResolveValidatorDelegate parseFn;
            if (delegateCache.TryGetValue(type, out parseFn)) return parseFn.Invoke();

            var genericType = typeof(ValidatorCache<>).MakeGenericType(type);
            var mi = genericType.GetMethod("GetValidator", BindingFlags.Public | BindingFlags.Static);
            parseFn = (ResolveValidatorDelegate)Delegate.CreateDelegate(typeof(ResolveValidatorDelegate), mi);

            Dictionary<Type, ResolveValidatorDelegate> snapshot, newCache;
            do
            {
                snapshot = delegateCache;
                newCache = new Dictionary<Type, ResolveValidatorDelegate>(delegateCache);
                newCache[type] = parseFn;

            } while (!ReferenceEquals(
            Interlocked.CompareExchange(ref delegateCache, newCache, snapshot), snapshot));

            return parseFn.Invoke();
        }
    }

    public class ValidatorCache<T>
    {
        public static IValidator GetValidator()
        {
            return AppConfig.Instance.TryResolve<IValidator<T>>();
        }
    }
}
