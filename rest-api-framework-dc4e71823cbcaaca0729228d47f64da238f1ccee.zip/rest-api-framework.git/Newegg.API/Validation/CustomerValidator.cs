﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentValidation;
using FluentValidation.Internal;
using System.Linq.Expressions;
using Newegg.API.Interfaces;
using FluentValidation.Resources;

namespace Newegg.API.Validation
{
    public abstract class CustomerValidator<T> : AbstractValidator<T>
    {
        public void RuleSet(ApplyTo appliesTo, Action action)
        {
            var httpMethods = appliesTo.ToString().Split(',').Select(x => x.Trim().ToUpper());

            foreach (var httpMethod in httpMethods)
            {
                RuleSet(httpMethod, action);
            }
        }

        public IRuleBuilderInitial<T, TProperty> RuleFor<TProperty>(Expression<Func<T, TProperty>> expression)
        {
            return RuleFor(expression, false);
        }

        public IRuleBuilderInitial<T, TProperty> RuleFor<TProperty>(Expression<Func<T, TProperty>> expression, bool isStopWhenFirstFailed)
        {
            var rule = PropertyRule.Create(expression,
                () =>
                {
                    if (isStopWhenFirstFailed)
                    {
                        return CascadeMode.StopOnFirstFailure;
                    }
                    else
                    {
                        return CascadeMode.Continue;
                    }
                });
            AddRule(rule);
            var ruleBuilder = new RuleBuilder<T, TProperty>(rule);
            return ruleBuilder;
        }

    }

    public static class CustomerErrorMessageExtension
    {
        public static IRuleBuilderOptions<T, TProperty> WithResourceCode<T, TProperty>(
            this IRuleBuilderOptions<T, TProperty> rule, string resourceCode)
        {
            return rule.Configure(config =>
            {
                config.CurrentValidator.ErrorMessageSource = new StaticStringSource(resourceCode);
            });
        }
    }
}
