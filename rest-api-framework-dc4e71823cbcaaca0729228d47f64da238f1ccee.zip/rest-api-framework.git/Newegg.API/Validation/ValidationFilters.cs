﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;
using FluentValidation;
using Newegg.API.Exceptions;
using FluentValidation.Results;
using Newegg.API.Interfaces;

namespace Newegg.API.Validation
{
    public class ValidationFilters
    {
        public void RequestFilter(HttpRequestWrapper req, HttpResponseWrapper res, object requestDto)
        {
            var validator = ValidatorCache.GetValidator(requestDto.GetType());
            if (validator is IMultipleLanguageValidation)
            {
                ((IMultipleLanguageValidation)validator).LanguageCode = req.LanguageCode;
            }
            if (validator != null)
            {
                string ruleSet = req.HttpMethod;
                var validationResult = validator.Validate(
                    new ValidationContext(requestDto, null, new MultiRuleSetValidatorSelector(ruleSet)));

                if (validationResult.IsValid) return;

                if (validator is IMultipleLanguageValidation)
                {
                    throw new ValidationError(
                        GetMultipleLanguageResults((IMultipleLanguageValidation)validator, validationResult, requestDto));
                }
                else
                {
                    throw new ValidationError(validationResult);
                }
                
            }
        }

        private ValidationResult GetMultipleLanguageResults
            (IMultipleLanguageValidation validator, ValidationResult validationResult, object requestDto)
        {
            List<ValidationFailure> failures = new List<ValidationFailure>();
            foreach (var result in validationResult.Errors)
            {
                var msg = validator.GetErrorMessage(requestDto, result.ErrorMessage);
                if(string.IsNullOrEmpty(msg))
                {
                    msg = result.ErrorMessage;
                }
                ValidationFailure failure = new ValidationFailure(result.PropertyName, msg);
                failures.Add(failure);
            }
            return new ValidationResult(failures);
        }
    }
}
