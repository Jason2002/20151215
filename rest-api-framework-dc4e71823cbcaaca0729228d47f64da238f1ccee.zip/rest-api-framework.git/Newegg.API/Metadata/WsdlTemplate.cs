﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Schema;
using System.Runtime.Serialization;
using System.IO;

namespace Newegg.API.Metadata
{
    public class WsdlTemplate
    {

        private const string Template =
@"<?xml version=""1.0"" encoding=""utf-8""?>
<wsdl:definitions name=""Soap11"" 
    targetNamespace=""http://www.newegg.com/api/types"" 
    xmlns:svc=""http://www.newegg.com/api/types"" 
    xmlns:tns=""http://www.newegg.com/api/types"" 
    
    xmlns:wsdl=""http://schemas.xmlsoap.org/wsdl/"" 
    xmlns:soap=""http://schemas.xmlsoap.org/wsdl/soap/"" 
    xmlns:soap12=""http://schemas.xmlsoap.org/wsdl/soap12/"" 
    xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"" 
    xmlns:soapenc=""http://schemas.xmlsoap.org/soap/encoding/"" 
    xmlns:wsam=""http://www.w3.org/2007/05/addressing/metadata"" 
    xmlns:wsa=""http://schemas.xmlsoap.org/ws/2004/08/addressing"" 
    xmlns:wsp=""http://schemas.xmlsoap.org/ws/2004/09/policy"" 
    xmlns:wsap=""http://schemas.xmlsoap.org/ws/2004/08/addressing/policy"" 
    xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" 
    xmlns:msc=""http://schemas.microsoft.com/ws/2005/12/wsdl/contract"" 
    xmlns:wsaw=""http://www.w3.org/2006/05/addressing/wsdl"" 
    xmlns:wsa10=""http://www.w3.org/2005/08/addressing"" 
    xmlns:wsx=""http://schemas.xmlsoap.org/ws/2004/09/mex"">

	<wsdl:types>
		{0}
	</wsdl:types>
	
</wsdl:definitions>";

        private Type m_operationType;

        public WsdlTemplate(Type operationType)
        {
            m_operationType = operationType;
        }

        public override string ToString()
        {
            var schemaSet = GetXmlSchemaSet(m_operationType);
            var xsd = GetXsd(schemaSet);

            var wsdl = string.Format(Template, xsd);

            return wsdl;
        }

        private XmlSchemaSet GetXmlSchemaSet(Type operationType)
        {
            var exporter = new XsdDataContractExporter();
            exporter.Export(operationType);
            exporter.Schemas.Compile();
            return exporter.Schemas;
        }

        private string GetXsd(XmlSchemaSet schemaSet)
        {
            var sb = new StringBuilder();
            using (var sw = new StringWriter(sb))
            {
                foreach (XmlSchema schema in schemaSet.Schemas())
                {
                    if (schema.SchemaTypes.Count == 0) continue; //remove blank schemas
                    schema.Write(sw);
                }
            }
            sb = sb.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", ""); //remove xml declaration
            return sb.ToString().Trim();
        }
    }
}
