﻿using Newegg.API.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Metadata
{
    [RestService("/api-doc")]
    public class ApiDocModule
    {
        public string Path { get; set; }

        public string Method { get; set; }

        public List<Model> Models { get; set; }
    }

    public class Model
    {
        public string TypeName { get; set; }

        public string ModelType { get; set; }

        public List<ModelProperty> Properties { get; set; }
    }

    public class ModelProperty
    {
        public string Name { get; set; }

        public string Type { get; set; }

        public string RefType { get; set; }
    }
}
