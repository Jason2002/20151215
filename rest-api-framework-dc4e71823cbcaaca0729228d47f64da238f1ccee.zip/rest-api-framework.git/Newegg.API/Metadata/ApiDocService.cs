﻿using Newegg.API.Interfaces;
using Newegg.API.ServiceHost;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceStack.Text;
using System.Reflection;

namespace Newegg.API.Metadata
{
    public class ApiDocService : RestServiceBase<ApiDocModule>
    {
        public override object OnGet(ApiDocModule request)
        {
            if (string.IsNullOrEmpty(request.Path) || string.IsNullOrEmpty(request.Method))
            {
                return request;
            }

            var restPath = AppConfig.Instance.ServiceManager.GetRestPathForRequest(request.Method, request.Path);

            if (restPath == null)
            {
                return request;
            }

            var requestType = restPath.RequestType;
            request.Models = new List<Model>();
            Model requestModel = new Model
            {
                ModelType = "Request",
                TypeName = requestType.Name
            };
            requestModel.Properties = requestType.GetSerializableProperties().Select(p => GetPerpertyInfo(p)).ToList();
            request.Models.Add(requestModel);

            List<Type> responseType;
            if (AppConfig.Instance.ServiceManager.RequestResponseMap.TryGetValue(requestType, out responseType))
            {
                responseType.ForEach(res =>
                    {
                        Model model = new Model
                        {
                            ModelType = "Response",
                            TypeName = res.Name
                        };
                        model.Properties = res.GetSerializableProperties().Select(p => GetPerpertyInfo(p)).ToList();
                        request.Models.Add(model);
                    });
            }

            return request;
        }

        private ModelProperty GetPerpertyInfo(PropertyInfo p)
        {
            var pType = p.PropertyType;

            if (pType.IsGenericType)
            {
                if (pType.IsOrHasGenericInterfaceTypeOf(typeof(Nullable<>)))
                {
                    return new ModelProperty
                    {
                        Name = p.Name,
                        Type = pType.GetGenericArguments()[0].Name,
                    };
                }
                if (pType.IsOrHasGenericInterfaceTypeOf(typeof(IEnumerable<>)))
                {
                    return new ModelProperty
                    {
                        Name = p.Name,
                        Type = "List",
                        RefType = pType.GetGenericArguments()[0].Name
                    };
                }
            }

            if (pType.IsArray)
            {
                return new ModelProperty
                {
                    Name = p.Name,
                    Type = "Array",
                    RefType = pType.GetElementType().Name,
                };
            }

            return new ModelProperty
            {
                Name = p.Name,
                Type = pType.Name,
            };
        }

    }
}
