﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Reflection;

namespace Newegg.API.Configuration
{
    public static class ResourceConfiguration
    {
        private static RestResourceSection m_section = (RestResourceSection)ConfigurationManager.GetSection("RestResourceSection");


        public static string APIName
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.APIName;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string Cache
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.Cache;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string DebugMode
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.DebugMode;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string DefaultExpireTime
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.DefaultExpireTime;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string Auth
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.Auth;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string EnableAuth
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.EnableAuth;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static Assembly[] Assemblies
        {
            get
            {
                if (m_section != null)
                {
                    return m_section.Resources.GetAllTypes();
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
