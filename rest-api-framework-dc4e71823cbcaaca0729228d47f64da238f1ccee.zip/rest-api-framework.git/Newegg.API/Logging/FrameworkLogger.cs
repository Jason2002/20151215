﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.API.Exceptions;
using Newegg.API.Models;
using Newegg.Framework.Tools.Log;
using ServiceStack.Text;

namespace Newegg.API.Logging
{
    public class FrameworkLogger : ILog
    {
        const string DEBUG = "DEBUG";
        const string ERROR = "ERROR";
        const string INFO = "INFO";
        const string WARN = "WARN";

        private static void Log(object message, Exception exception, string category)
        {
            try
            {
                string msg = message == null ? string.Empty : message.ToString();
                if (exception != null)
                {
                    msg += "\r\n Exception: \r\n" + GetExceptionDetail(exception);
                }
                LogEntry log = new LogEntry();
                log.CategoryName = category;
                log.Content = msg;
                Logger.WriteLog(log);

            }
            catch { }
        }

        public void Debug(object message)
        {
            Log(message, null, DEBUG);
        }

        public void Debug(object message, Exception exception)
        {
            Log(message, null, DEBUG);
        }

        public void Error(object message)
        {
            Log(message, null, ERROR);
        }

        public void Error(object message, Exception exception)
        {
            Log(message, exception, ERROR);
        }

        public void Info(object message)
        {
            Log(message, null, INFO);
        }

        public void Info(object message, Exception exception)
        {
            Log(message, exception, INFO);
        }

        public void Warn(object message)
        {
            Log(message, null, WARN);
        }

        public void Warn(object message, Exception exception)
        {
            Log(message, exception, WARN);
        }

        private static string GetExceptionDetail(Exception ex)
        {
            if (ex == null)
                return "";
            StringBuilder sb = new StringBuilder(1000);

            if (ex is HandleException)
            {
                var handleException = ex as HandleException;
                sb.AppendFormat("Date: {0}\r\n", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff"));
                sb.AppendFormat("Message: {0}.\r\n", handleException.InnerException.Message);
                sb.AppendFormat("Uri: {0}.\r\n", handleException.RawUrl);
                if (handleException.RequestAuth != null)
                {
                    sb.AppendFormat("Auth: {0}.\r\n", handleException.RequestAuth.ToJson());
                }
                ex = handleException.InnerException;
            }
            else
            {
                sb.AppendFormat("Message: {0}.\r\n", ex.Message);
            }

            sb.AppendFormat("Exception Type: {0}.\r\n", ex.GetType().FullName);

            if (ex.Source != null)
            {
                sb.AppendFormat("Source: {0}.\r\n", ex.Source);
            }
            if (ex.TargetSite != null)
            {
                sb.AppendFormat("Module Name: {0}.\r\n", ex.TargetSite.Module.FullyQualifiedName);
            }
            if (ex.StackTrace != null)
            {
                sb.AppendFormat("Stack Trace: {0}.\r\n", ex.StackTrace);
            }
            if (ex.InnerException != null)
            {
                AppendInnerException(ex.InnerException, sb);
            }
            if (ex is ValidationError)
            {
                AppendValidationException((ValidationError)ex, sb);
            }

            return sb.ToString();
        }

        private static void AppendInnerException(Exception ex, StringBuilder sb)
        {
            sb.Append("\r\n");
            sb.AppendFormat("Inner Exception:\r\n");
            sb.AppendFormat("\tMessage: {0}. \r\n", ex.Message);
            sb.AppendFormat("\tException Type: {0}.\r\n", ex.GetType().FullName);
            if (ex.Source != null)
            {
                sb.AppendFormat("\tSource: {0}.\r\n", ex.Source);
            }
            if (ex.StackTrace != null)
            {
                sb.AppendFormat("\tStack Trace: {0}.\r\n", ex.StackTrace);
            }
            if (ex.InnerException != null)
            {
                AppendInnerException(ex.InnerException, sb);
            }
        }

        private static void AppendValidationException(ValidationError ex, StringBuilder sb)
        {
            sb.Append("\r\n");
            sb.AppendFormat("Validation Exception:\r\n");
            var errors = ex.GetResponseDTO();
            errors.ForEach(e =>
            {
                sb.AppendFormat("\tProperty Name: {0}. \r\n", e.PropertyName);
                sb.AppendFormat("\tError Messages: {0}.\r\n", e.ErrorMessage);
            });
            
        }
    }
}
