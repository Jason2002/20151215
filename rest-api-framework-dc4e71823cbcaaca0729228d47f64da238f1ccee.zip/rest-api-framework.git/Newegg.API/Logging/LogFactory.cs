﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Logging
{
    public class LogFactory
    {
        private static ILog logger;

        /// <summary>
        /// Gets or sets the log factory.
        /// Use this to override the factory that is used to create loggers
        /// </summary>
        /// <value>The log factory.</value>
        public static ILog Log
        {
            get
            {
                if (logger == null)
                {
                    logger = new FrameworkLogger();
                }
                return logger;
            }
            set { logger = value; }
        }
    }
}
