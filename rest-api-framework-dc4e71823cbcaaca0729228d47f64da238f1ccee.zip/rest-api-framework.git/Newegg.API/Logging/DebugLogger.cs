﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Logging
{
    public class DebugLogger : ILog
    {
        const string DEBUG = "DEBUG: ";
        const string ERROR = "ERROR: ";
        const string INFO = "INFO: ";
        const string WARN = "WARN: ";

        private static void Log(object message, Exception exception)
        {
            string msg = message == null ? string.Empty : message.ToString();
            if (exception != null)
            {
                msg += ", Exception: " + exception.Message;
            }
            System.Diagnostics.Debug.WriteLine(msg);
        }

        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        private static void Log(object message)
        {
            string msg = message == null ? string.Empty : message.ToString();
            System.Diagnostics.Debug.WriteLine(msg);
        }

        public void Debug(object message)
        {
            Log(DEBUG + message);
        }

        public void Debug(object message, Exception exception)
        {
            Log(DEBUG + message, exception);
        }

        public void Error(object message)
        {
            Log(ERROR + message);
        }

        public void Error(object message, Exception exception)
        {
            Log(ERROR + message, exception);
        }

        public void Info(object message)
        {
            Log(INFO + message);
        }

        public void Info(object message, Exception exception)
        {
            Log(WARN + message, exception);
        }

        public void Warn(object message)
        {
            Log(WARN + message);
        }

        public void Warn(object message, Exception exception)
        {
            Log(WARN + message, exception);
        }
    }
}
