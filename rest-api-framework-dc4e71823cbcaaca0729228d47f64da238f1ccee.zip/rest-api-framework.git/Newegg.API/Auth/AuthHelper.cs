﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.ServiceHost;
using Newegg.API.HttpExtensions;
using Newegg.API.Common;
using Newegg.API.Models;

namespace Newegg.API.Auth
{
    public static class AuthHelper
    {
        public static AuthData GetAuthData(HttpExtensions.HttpRequestWrapper req)
        {
            string authString = req.Headers[HttpHeaders.Authorization];
            if (string.IsNullOrEmpty(authString))
            {
                authString = req.GetAccessKey() + "&" + req.GetAccessToken();
            }

            string[] authPart = authString.Split(new char[]{'&'}, StringSplitOptions.RemoveEmptyEntries);
            if (authPart == null || authPart.Length != 2)
            {
                return null;
            }
            else
            {
                return new AuthData
                {
                    AppKey = authPart[0],
                    AccessToken = authPart[1]
                };
            }
        }

        public static string GetUriTemplate(HttpExtensions.HttpRequestWrapper req)
        {
            return AppConfig.Instance.ServiceManager.GetRestPathForRequest(req.HttpMethod, req.PathInfo).Path;
        }

        public static bool TryParseAuthForGateway(HttpExtensions.HttpRequestWrapper req)
        {
            string authString = req.Headers[HttpHeaders.Authorization];
            if (string.IsNullOrEmpty(authString))
            {
                return false;
            }

            string[] authPart = authString.Split(new char[] { '&' }, StringSplitOptions.RemoveEmptyEntries);
            if (authPart == null || authPart.Length != 2)
            {
                return false;
            }

            if (!authPart[0].Equals("gateway", StringComparison.InvariantCultureIgnoreCase))
            {
                return false;
            }

            try
            {
                byte[] encodedDataAsBytes = System.Convert.FromBase64String(authPart[1]);
                string authValue = System.Text.Encoding.UTF8.GetString(encodedDataAsBytes);

                string[] authInfo = authValue.Split(new string[] { "^&^" }, StringSplitOptions.RemoveEmptyEntries);
                if (authInfo == null || authInfo.Length != 4)
                {
                    return false;
                }

                req.RequestAuth = new RequestAuthInfo
                {
                    ApiId = authInfo[0],
                    RequestSystem = authInfo[1],
                    UserId = authInfo[2],
                    UserName = authInfo[3],
                };
                req.IsFromGateway = true;
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    public class AuthData
    {
        public string AppKey { get; set; }

        public string AccessToken { get; set; }
    }
}
