﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.ServiceHost;
using Newegg.API.HttpExtensions;
using System.IO;
using System.Xml;
using Newegg.API.Common;

namespace Newegg.API.Auth
{
    public class MockAuth : IAuth
    {
        public bool Authenticate(HttpExtensions.HttpRequestWrapper req)
        {
            
            AuthData auth = AuthHelper.GetAuthData(req);
            if (auth == null)
            {
                return false;
            }

            req.RequestAuth = new Models.RequestAuthInfo
            {
                RequestSystem = auth.AppKey,
                UserId = auth.AccessToken,
                UserName = auth.AccessToken,
            };

            return true;
        }
    }
}
