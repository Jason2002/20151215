﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Auth
{
    public class AuthFactory
    {
        private static IAuth auth;

        /// <summary>
        /// Gets or sets the log factory.
        /// Use this to override the factory that is used to create loggers
        /// </summary>
        /// <value>The log factory.</value>
        public static IAuth AuthProvider
        {
            get
            {
                if (auth == null)
                {
                    auth = new MockAuth();
                }
                return auth;
            }
            set { auth = value; }
        }
    }
}
