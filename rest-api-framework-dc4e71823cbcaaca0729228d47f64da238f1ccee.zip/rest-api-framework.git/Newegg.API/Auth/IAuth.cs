﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Auth
{
    public interface IAuth
    {
        bool Authenticate(HttpExtensions.HttpRequestWrapper req);
    }
}
