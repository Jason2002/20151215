﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Models
{
    public class RequestAuthInfo
    {
        public string ApiId { get; set; }

        public string UserId { get; set; }

        public string UserName { get; set; }

        public string RequestSystem { get; set; }
    }
}
