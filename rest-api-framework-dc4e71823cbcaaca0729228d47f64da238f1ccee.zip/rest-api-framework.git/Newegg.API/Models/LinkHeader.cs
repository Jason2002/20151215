﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Models
{
    public class LinkHeader
    {
        public string Uri { get; set; }

        public string Relation { get; set; }

        public string ContentType { get; set; }

        public string Title { get; set; }

        public LinkHeader(string uri, string relation)
        {
            Uri = uri;
            Relation = relation;
        }

        public override string ToString()
        {
            string content = string.Format("<{0}>; rel=\"{1}\"", Uri, Relation);
            if (!string.IsNullOrWhiteSpace(ContentType))
            {
                content += string.Format("; type=\"{0}\"", ContentType);
            }
            if (!string.IsNullOrWhiteSpace(Title))
            {
                content += string.Format("; title=\"{0}\"", Title);
            }
            return content;
        }
    }
}
