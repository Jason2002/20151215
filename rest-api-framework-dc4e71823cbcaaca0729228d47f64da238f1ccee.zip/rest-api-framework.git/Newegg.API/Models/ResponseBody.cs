﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Models
{
    //public class ResponseBody
    //{
    //    public ResponseStatus ResponseStatus { get; set; }

        
    //}

    //public static class ResponseBodyHelper
    //{
    //    public static ResponseBody GetFinalResponse(object response)
    //    {
    //        ResponseBody finalRes = new ResponseBody();
    //        if (response is ResponseStatus)
    //        {
    //            finalRes.ResponseStatus = response as ResponseStatus;
    //        }
    //        else
    //        {
    //            finalRes.ResponseContent = response;
    //        }
    //        return finalRes;
    //    }
    //}
}
