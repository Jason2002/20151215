﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Models
{
    public class RawRequestDto
    {
        public string DtoType
        {
            get
            {
                return "Raw Request";
            }
        }
    }
}
