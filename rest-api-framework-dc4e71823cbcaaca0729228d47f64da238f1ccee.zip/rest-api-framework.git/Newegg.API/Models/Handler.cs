﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Models
{
    public class Handler
    {
        public string SystemSource { get; set; }

        public string ActionType { get; set; }

        public string ActionMemo { get; set; }

        public string ActionUserID { get; set; }

        public DateTime ActionTime { get; set; }

        public string ClientTag { get; set; }
    }
}
