﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Runtime.Serialization;
using Newegg.API.Exceptions;
using System.Xml.Serialization;

namespace Newegg.API.Models
{
    public class ResponseStatus
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseStatus"/> class.
        /// 
        /// A response status without an errorcode == success
        /// </summary>
        public ResponseStatus()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseStatus"/> class.
        /// 
        /// A response status with an errorcode == failure
        /// </summary>
        public ResponseStatus(string errorCode)
        {
            this.ResponseCode = errorCode;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseStatus"/> class.
        /// 
        /// A response status with an errorcode == failure
        /// </summary>
        public ResponseStatus(string errorCode, string message)
            : this(errorCode)
        {
            this.Message = message;
        }

        /// <summary>
        /// Holds the custom ErrorCode enum if provided in ValidationException
        /// otherwise will hold the name of the Exception type, e.g. typeof(Exception).Name
        /// 
        /// A value of non-null means the service encountered an error while processing the request.
        /// </summary>
        public string ResponseCode { get; set; }

        /// <summary>
        /// A human friendly error message
        /// </summary>
        public string Message { get; set; }

        
        public List<ValidationErrorResponse> ValidationErrors { get; set; }

        /// <summary>
        /// 
        /// </summary>
        
        public string StackTrace { get; set; }

        public HttpStatusCode StatusCode { get; set; }
    }
}
