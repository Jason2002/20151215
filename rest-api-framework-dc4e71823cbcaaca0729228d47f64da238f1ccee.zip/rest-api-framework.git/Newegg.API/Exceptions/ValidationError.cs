﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentValidation.Results;
using System.Runtime.Serialization;

namespace Newegg.API.Exceptions
{
    public class ValidationError : Exception
    {
        public ValidationResult ValidationResults { get; set; }

        public ValidationError(ValidationResult results)
        {
            ValidationResults = results;
        }

        public List<ValidationErrorResponse> GetResponseDTO()
        {
            List<ValidationErrorResponse> response = new List<ValidationErrorResponse>();
            foreach (var error in ValidationResults.Errors)
            {
                ValidationErrorResponse item = new ValidationErrorResponse();
                item.ErrorMessage = error.ErrorMessage;
                item.PropertyName = error.PropertyName;
                response.Add(item);
            }
            return response;
        }
    }

    [DataContract(Namespace = "http://www.newegg.com/api", Name = "ValidationErrorResponse")]
    public class ValidationErrorResponse
    {
        [DataMember]
        public string PropertyName { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }
    }
}
