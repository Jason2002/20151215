﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Models;

namespace Newegg.API.Exceptions
{
    internal class HandleException : Exception
    {
        public HandleException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public RequestAuthInfo RequestAuth { get; set; }

        public string RawUrl { get; set; }
    }
}
