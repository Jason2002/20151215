﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Exceptions
{
    internal static class ErrorCode
    {
        internal static string EntityVersionNotCorrect = "0130001";
        internal static string EntityValidationError = "0130002";
        internal static string EntityCreated = "0110003";
        internal static string NoResponse = "0110004";
        internal static string ResourceMoved = "0110005";
        internal static string AuthFailed = "0110006";
    }
}
