﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace Newegg.API.Exceptions
{
    public class HttpError : Exception
    {
        public HttpError(string errorCode, string message)
            : this(HttpStatusCode.InternalServerError, errorCode, message) { }

        public HttpError(HttpStatusCode statusCode, string errorCode)
            : this(statusCode, errorCode, null) { }

        public HttpError(HttpStatusCode statusCode, string errorCode, string errorMessage)
            : base(errorMessage ?? errorCode)
        {
            this.ErrorCode = errorCode;
            this.StatusCode = statusCode;
        }

        public string ErrorCode { get; set; }

        public HttpStatusCode StatusCode { get; set; }
    }
}
