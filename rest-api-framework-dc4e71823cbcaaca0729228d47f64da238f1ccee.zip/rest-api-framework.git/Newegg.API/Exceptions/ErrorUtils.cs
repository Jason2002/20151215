﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using Newegg.API.Models;
using System.Runtime.Serialization;

namespace Newegg.API.Exceptions
{
    public static class ErrorUtils
    {
        public static ResponseStatus CreateErrorResponse(Exception ex, bool isDebug)
        {
            var httpError = ex as HttpError;
            if (httpError != null)
            {
                ResponseStatus responseDto = new ResponseStatus();
                responseDto.ResponseCode = httpError.ErrorCode;
                responseDto.Message = httpError.Message;
                responseDto.StatusCode = httpError.StatusCode;
                if (isDebug)
                {
                    responseDto.StackTrace = httpError.StackTrace;
                }
                return responseDto;
            }
            else if (ex is ValidationError)
            {
                ResponseStatus responseDto = new ResponseStatus();
                responseDto.ResponseCode = ErrorCode.EntityValidationError;
                responseDto.Message = "Validation Errors";
                responseDto.StatusCode = HttpStatusCode.InternalServerError;
                if (isDebug)
                {
                    responseDto.StackTrace = ex.StackTrace;
                }
                responseDto.ValidationErrors = ((ValidationError)ex).GetResponseDTO();
                return responseDto;
            }
            else
            {
                ResponseStatus responseDto = new ResponseStatus();
                HttpStatusCode statusCode = HttpStatusCode.InternalServerError;
                if (ex is SerializationException || ex is ArgumentException)
                {
                    statusCode = HttpStatusCode.BadRequest;
                }
                else if (ex is NotImplementedException)
                {
                    statusCode = HttpStatusCode.MethodNotAllowed;
                }
                responseDto.StatusCode = statusCode;
                responseDto.ResponseCode = ((int)statusCode).ToString();
                if (isDebug)
                {
                    responseDto.StackTrace = ex.StackTrace;
                    responseDto.Message = ex.Message;
                }
                else
                {
                    responseDto.Message = statusCode.ToString();
                }
                return responseDto;
            }
        }
    }
}
