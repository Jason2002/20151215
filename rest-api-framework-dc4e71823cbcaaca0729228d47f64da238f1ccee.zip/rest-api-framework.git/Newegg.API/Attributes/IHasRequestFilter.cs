﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.HttpExtensions;

namespace Newegg.API.Attributes
{
    /// <summary>
    /// This interface can be implemented by an attribute
    /// which adds an request filter for the specific request DTO the attribute marked.
    /// </summary>
    public interface IHasRequestFilter
    {
        /// <summary>
        /// Order in which Request Filters are executed. 
        /// &lt;0 Executed before global request filters
        /// &gt;0 Executed after global request filters
        /// </summary>
        int Priority { get; }

        /// <summary>
        /// The request filter is executed before the service.
        /// </summary>
        /// <param name="req">The http request wrapper</param>
        /// <param name="res">The http response wrapper</param>
        /// <param name="requestDto">The request DTO</param>
        void RequestFilter(HttpRequestWrapper req, HttpResponseWrapper res, object requestDto);
    }
}
