﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class ResponseTypeAttribute : Attribute
    {
        private Type m_requestType;
        public ResponseTypeAttribute(Type requestDTOType)
        {
            m_requestType = requestDTOType;
        }

        public Type RequestType { get { return m_requestType; } }
    }
}
