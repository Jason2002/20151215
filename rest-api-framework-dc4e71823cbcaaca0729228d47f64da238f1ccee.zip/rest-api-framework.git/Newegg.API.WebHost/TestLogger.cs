﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newegg.API.Logging;

namespace Newegg.API.Test
{
    public class TestLogger : ILog
    {
        const string DEBUG = "TestDEBUG: ";
        const string ERROR = "TestERROR: ";
        const string INFO = "TestINFO: ";
        const string WARN = "TestWARN: ";

        private static void Log(object message, Exception exception)
        {
            string msg = message == null ? string.Empty : message.ToString();
            if (exception != null)
            {
                msg += ", Exception: " + exception.Message;
            }
            System.Diagnostics.Debug.WriteLine(msg);
        }

        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        private static void Log(object message)
        {
            string msg = message == null ? string.Empty : message.ToString();
            System.Diagnostics.Debug.WriteLine(msg);
        }

        public void Debug(object message)
        {
            Log(DEBUG + message);
        }

        public void Debug(object message, Exception exception)
        {
            Log(DEBUG + message, exception);
        }

        public void Error(object message)
        {
            Log(ERROR + message);
        }

        public void Error(object message, Exception exception)
        {
            Log(ERROR + message, exception);
        }

        public void Info(object message)
        {
            Log(INFO + message);
        }

        public void Info(object message, Exception exception)
        {
            Log(WARN + message, exception);
        }

        public void Warn(object message)
        {
            Log(WARN + message);
        }

        public void Warn(object message, Exception exception)
        {
            Log(WARN + message, exception);
        }
    }
}