﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;
using Newegg.API.HttpExtensions;
using Newegg.API.Serialization;
using ServiceStack.Text;

namespace Newegg.API.Metadata
{
    public class MetadataResponseFilterAttribute : Attribute, IHasResponseFilter
    {
        public int Priority
        {
            get { return -1; }
        }

        public void ResponseFilter(HttpExtensions.HttpRequestWrapper req, HttpExtensions.HttpResponseWrapper res, object response)
        {
            if (response is Resources)
            {
                HandlerResourceList(req, res, (Resources)response);
            }
            else if (response is ResourceTypeInfo)
            {
                HandlerResourceType(req, res, (ResourceTypeInfo)response);
            }
        }

        private void HandlerResourceType(HttpRequestWrapper req, HttpResponseWrapper res, ResourceTypeInfo resourceTypeInfo)
        {
            if (!resourceTypeInfo.ShowRaw)
            {
                ResourcesTypeTemplate template = new ResourcesTypeTemplate();
                template.ResoureListPath = GetBaseURL(req) + "/resources-list";
                template.APIName = resourceTypeInfo.APIName;
                template.ResoureName = resourceTypeInfo.ResourceName;
                template.ContentType = resourceTypeInfo.DemoType;
                template.PathInfo = resourceTypeInfo.PathInfo;
                template.RequestTypeString = resourceTypeInfo.RequestType;
                template.ResponseTypeString = resourceTypeInfo.ResponseTypes;
                res.WriteTextToResponse(template.GetContent(), "text/html");
                res.Close();
               
            }
            else
            {
                res.WriteTextToResponse(XmlSimpleSerializer.SerializeToString<ResourceTypeInfo>(resourceTypeInfo), "application/xml");
                res.Close();
            }
        }

        private void HandlerResourceList(HttpExtensions.HttpRequestWrapper req,
            HttpExtensions.HttpResponseWrapper res, Resources response)
        {
            if (!response.ShowRaw)
            {
                ResourceListTemplate template = new ResourceListTemplate();
                template.APIName = response.APIName;
                foreach (var item in response.ResourceInfoList)
                {
                    item.XMLMeta = GetBaseURL(req) + item.XMLMeta;
                    item.JsonMeta = GetBaseURL(req) + item.JsonMeta;
                }
                template.InfoList = response.ResourceInfoList;
                res.WriteTextToResponse(template.GetContent(), "text/html");
                res.Close();
            }
            else
            {
                res.WriteTextToResponse(XmlSimpleSerializer.SerializeToString<Resources>(response), "application/xml");
                res.Close();
            }
        }

        private string GetBaseURL(HttpExtensions.HttpRequestWrapper req)
        {
            if (string.IsNullOrEmpty(req.Request.ApplicationPath) || req.Request.ApplicationPath == "/")
            {
                return req.Request.Url.GetLeftPart(UriPartial.Authority);
            }
            else
            {
                return req.Request.ApplicationPath;
            }
        }
    }
}
