﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Metadata
{
    public class ResourceListTemplate
    {
        private static string m_HTMLTemplate = MetadataRes.ResourceList;
        private static string m_resourceTemplate =
@"<ul>
    <li>
        <span>{0}</span>
        <a href=""{1}"">XML</a>
        <a href=""{2}"">JSON</a>
    </li>
</ul>";

        public string APIName { get; set; }

        public List<ResourceInfo> InfoList { get; set; }
        

        public string GetContent()
        {
            StringBuilder resBuilder = new StringBuilder();
            foreach (var res in InfoList)
            {
                resBuilder.AppendFormat(m_resourceTemplate, res.ResourceName, res.XMLMeta, res.JsonMeta);
            }
            var content = m_HTMLTemplate.Replace("{APIName}", APIName);
            content = content.Replace("{ResourceList}", resBuilder.ToString());
            return content;
        }

    }
}
