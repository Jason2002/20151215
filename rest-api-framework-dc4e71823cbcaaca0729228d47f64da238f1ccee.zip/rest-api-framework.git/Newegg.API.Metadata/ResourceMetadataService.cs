﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.API.ServiceHost;
using Newegg.API.Exceptions;
using System.Net;
using Newegg.API.Attributes;
using System.Web;
using System.IO;
using System.Xml;

namespace Newegg.API.Metadata
{
    public class ResourceMetadataService : RestServiceBase<ResourceMetadata>
    {
        public override object OnGet(ResourceMetadata request)
        {
            if (string.IsNullOrEmpty(request.Name))
            {
                return GetAllResource(request);
            }
            else
            {
                var find = AppConfig.Instance.ServiceManager.RequestResponseMap.Keys.FirstOrDefault
                    (r => r.Name.ToLower() == request.Name.ToLower());
                if (find == null)
                {
                    throw new HttpError(HttpStatusCode.NotFound, "950", "Resource not found");
                }
                else
                {
                    return GetResourceInfoList(request, find);
                }
            }
        }

        private object GetResourceInfoList(ResourceMetadata request, Type requestType)
        {
            ResourceTypeInfo typeInfo = new ResourceTypeInfo();
            typeInfo.APIName = AppConfig.Instance.APIName;
            typeInfo.ShowRaw = request.ShowRaw;
            typeInfo.DemoType = string.IsNullOrEmpty(request.DemoType) ? "json" : request.DemoType;
            typeInfo.ResourceName = requestType.Name;
            typeInfo.RequestType = GetSerializeString(requestType, request.DemoType);
            typeInfo.PathInfo = new List<string>();
            foreach (var attr in requestType.GetCustomAttributes(typeof(RestServiceAttribute), true))
            {
                typeInfo.PathInfo.Add(((RestServiceAttribute)attr).Path);
            }
            typeInfo.ResponseTypes = new List<string>();
            foreach (var res in AppConfig.Instance.ServiceManager.RequestResponseMap[requestType])
            {
                typeInfo.ResponseTypes.Add(GetSerializeString(res, request.DemoType));
            }
            return typeInfo;
        }

        private string GetSerializeString(Type typeInfo, string contentType)
        {
            if (string.IsNullOrEmpty(contentType) || contentType.Trim().ToLower() != "xml")
            {
                return ServiceStack.Text.JsonSerializer.SerializeToString(Activator.CreateInstance(typeInfo));
            }
            else
            {
                var from = Activator.CreateInstance(typeInfo);
                using (var ms = new MemoryStream())
                {
                    var serializer = new System.Runtime.Serialization.DataContractSerializer(from.GetType());

                    using (var xw = new XmlTextWriter(ms, Encoding.UTF8))
                    {
                        xw.Formatting = Formatting.Indented;

                        serializer.WriteObject(xw, from);
                        xw.Flush();

                        ms.Seek(0, SeekOrigin.Begin);
                        using (var reader = new StreamReader(ms))
                        {
                            return HttpUtility.HtmlEncode(reader.ReadToEnd());
                        }

                    }
                }
            }
        }

        private object GetAllResource(ResourceMetadata request)
        {
            Resources resources = new Resources();
            resources.APIName = AppConfig.Instance.APIName;
            resources.ShowRaw = request.ShowRaw;
            resources.ResourceInfoList = GetResourceInfoList(request.ShowRaw);
            return resources;
        }

        private List<ResourceInfo> GetResourceInfoList(bool showRaw)
        {
            List<ResourceInfo> list = new List<ResourceInfo>();
            foreach (Type key in AppConfig.Instance.ServiceManager.RequestResponseMap.Keys)
            {
                ResourceInfo info = new ResourceInfo();
                info.ResourceName = key.Name;
                info.XMLMeta = string.Format(@"/resource/{0}?demotype=xml&showraw={1}", key.Name, showRaw ? "true" : "false");
                info.JsonMeta = string.Format(@"/resource/{0}?demotype=json&showraw={1}", key.Name, showRaw ? "true" : "false");
                list.Add(info);
            }
            return list;
        }
    }
}
