﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Metadata
{
    public class ResourcesTypeTemplate
    {
        private static string m_HTMLTemplate = MetadataRes.RequestTypeTemp;

        public string PathTemplate = @"All Verbs {0}";

        public string responseTemplate = 
@"<h4>Response</h4>
        <div class=""response"">
            <pre>
HTTP/1.1 200 OK
Content-Type: application/{1}
Content-Length: length
 
{0}
            </pre>
        </div>
";

        public string JsonType = "json";

        public string XMLType = "xml";

        public string APIName { get; set; }

        public string ResoureName { get; set; }

        public string ResoureListPath { get; set; }

        public string ContentType { get; set; }

        public string RequestTypeString { get; set; }

        public List<string> ResponseTypeString { get; set; }

        public List<string> PathInfo { get; set; }

        public string GetContent()
        {
            string restPath = string.Empty;
            string postPath = string.Empty;
            if (PathInfo.Count > 0)
            {
                foreach (var path in PathInfo.OrderBy(p => p.Length).ToList())
                {
                    restPath += string.Format(PathTemplate, path) + System.Environment.NewLine;
                    if (string.IsNullOrEmpty(postPath))
                    {
                        postPath = path;
                    }
                }
            }
            string responseType = string.Empty;

            foreach (var res in ResponseTypeString)
            {
                responseType += string.Format(responseTemplate, res, GetContentType()) + System.Environment.NewLine;
            }

            string content = m_HTMLTemplate;
            content = content.Replace("{ResourceListPath}", ResoureListPath);
            content = content.Replace("{APIName}", APIName);
            content = content.Replace("{ResourceName}", ResoureName);
            content = content.Replace("{RestPath}", restPath);
            content = content.Replace("{RestPath1}", postPath);
            content = content.Replace("{ContentType}", GetContentType());
            content = content.Replace("{RequestType}", RequestTypeString);
            content = content.Replace("{ResponseType}", responseType);

            return content;
        }

        private string GetContentType()
        {
            switch (ContentType.ToLower())
            {
                case "json":
                    return JsonType;
                case "xml":
                    return XMLType;
                default:
                    return JsonType;
            }
        }
    }
}
