﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace Newegg.API.Metadata
{
    [RestService("/resources-list")]
    [RestService("/resource/{Name}")]
    public class ResourceMetadata
    {
        
        public string Name { get; set; }

        
        public string DemoType { get; set; }

        
        public bool ShowRaw { get; set; }
    }

    [MetadataResponseFilter]
    public class Resources
    {
        
        public string APIName { get; set; }

        [XmlIgnore]
        public bool ShowRaw { get; set; }

        
        public List<ResourceInfo> ResourceInfoList { get; set; }
    }

    
    public class ResourceInfo
    {
    
        public string ResourceName { get; set; }

    
        public string XMLMeta { get; set; }

    
        public string JsonMeta { get; set; }
    }

    [MetadataResponseFilter]
    public class ResourceTypeInfo
    {
        public string APIName { get; set; }

        public string ResourceName { get; set; }

        [XmlIgnore]
        public bool ShowRaw { get; set; }

        [XmlIgnore]
        public string DemoType { get; set; }

        public List<string> PathInfo { get; set; }

        public string RequestType { get; set; }

        public List<string> ResponseTypes { get; set; }
    }
}
