﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Newegg.API.Silverlight
{
    
    public class ResponseStatus
    {
    
        public string ResponseCode { get; set; }

    
        public string Message { get; set; }

    
        public string StackTrace { get; set; }

    
        public List<ValidationErrorResponse> ValidationErrors { get; set; }
    }

    
    public class ValidationErrorResponse
    {
    
        public string PropertyName { get; set; }

    
        public string ErrorMessage { get; set; }
    }

    
    public class AsyncResponseStatus
    {
    
        public DateTime Received { get; set; }

    
        public string RequestUri { get; set; }

    
        public string ResourceUri { get; set; }
    }
}
