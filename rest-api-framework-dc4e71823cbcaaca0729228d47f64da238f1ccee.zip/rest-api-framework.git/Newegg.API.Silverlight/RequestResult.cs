﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Silverlight
{
    public class RequestResult<TResponse>
    {
        public TResponse Result { get; set; }

        public Exception Error { get; set; }

        public System.Net.WebHeaderCollection Headers { get; set; }

        public bool HasError
        {
            get
            {
                return Error != null;
            }
        }

        public WebServiceException GetStandardResponseError()
        {
            if (Error != null && Error is WebServiceException && ((WebServiceException)Error).ResponseDto != null)
            {
                return (WebServiceException)Error;
            }
            else
            {
                return null;
            }
        }
    }
}
