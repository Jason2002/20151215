﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows;

namespace Newegg.API.Silverlight
{
    public class RequestState<TResponse> : IDisposable
    {
        const int BufferSize = 4096;

        public RequestState()
        {
            BufferRead = new byte[BufferSize];
            TextData = new StringBuilder();
            BytesData = new MemoryStream(BufferSize);
            WebRequest = null;
            ResponseStream = null;
        }

        public bool HandleCallbackOnUIThread { get; set; }

        public string HttpMethod;

        public string Url;

        public StringBuilder TextData;

        public MemoryStream BytesData;

        public byte[] BufferRead;

        public object Request;

        public HttpWebRequest WebRequest;

        public HttpWebResponse WebResponse;

        public Stream ResponseStream;

        public int Completed;

        public Timer Timer;

        public Action<RequestResult<TResponse>> OnFinish;

        public void HandleFinish(RequestResult<TResponse> response)
        {
            if (this.OnFinish == null)
                return;

            if (WebResponse != null)
            {
                response.Headers = WebResponse.Headers;
            }

            if (HandleCallbackOnUIThread)
            {
                System.Windows.Deployment.Current.Dispatcher.BeginInvoke(() => this.OnFinish(response));
            }
            else
            {
                this.OnFinish(response);
            }

        }

        public void StartTimer(TimeSpan timeOut)
        {
            this.Timer = new Timer(this.TimedOut, this, (int)timeOut.TotalMilliseconds, System.Threading.Timeout.Infinite);
        }

        public void TimedOut(object state)
        {
            if (Interlocked.Increment(ref Completed) == 1)
            {
                if (this.WebRequest != null)
                {
                    this.WebRequest.Abort();
                }
            }
            this.Timer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
            this.Timer.Dispose();
            this.Dispose();
        }

        public void Dispose()
        {
            if (this.BytesData == null) return;
            this.BytesData.Dispose();
            this.BytesData = null;
        }
    }
}
