﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.API.Silverlight
{
    public static class ContentTypes
    {
        public const string Xml = "application/xml";

        public const string Json = "application/json";

        public const string Jsv = "application/jsv";

        public static string GetContentType(string contentType)
        {
            if (contentType == null)
                return Json;

            var realContentType = contentType.Split(';')[0].Trim();
            switch (realContentType)
            {
                case Json:
                    return Json;

                case Xml:
                    return Xml;

                case Jsv:
                    return Jsv;
            }

            return Json;
        }
    }
}
