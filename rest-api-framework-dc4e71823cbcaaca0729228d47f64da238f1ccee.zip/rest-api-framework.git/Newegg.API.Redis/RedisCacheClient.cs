﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Cache;
using ServiceStack.Redis;
using System.Configuration;
using Newegg.API.ServiceHost;

namespace Newegg.API.Redis
{
    public class RedisCacheClient : ICacheClient
    {
        private PooledRedisClientManager m_client;

        public RedisCacheClient()
        {
            Init();
        }

        private void Init()
        {
            string address = ConfigurationManager.AppSettings["Framework.RedisAddress"];
            if (!string.IsNullOrEmpty(address))
            {
                m_client = new PooledRedisClientManager(address);
            }
            else
            {
                m_client = new PooledRedisClientManager();
            }
        }

        public bool Remove(string key)
        {
            return this.m_client.Remove(key);
        }

        public T Get<T>(string key)
        {
            var value = m_client.Get<T>(key);
            if (value != null) return value;
            return default(T);
        }

        private bool TryGet<T>(string key, out T obj)
        {
            var value = this.m_client.Get<T>(key);
            if (value != null)
            {
                obj = value;
                return true;
            }
            else
            {
                obj = default(T);
                return false;
            }
        }

        public CacheEntry Get(string key)
        {
            CacheEntry cacheEntry;
            if (TryGet<CacheEntry>(key, out cacheEntry))
            {
                if (cacheEntry.ExpiresAt < DateTime.UtcNow)
                {
                    this.m_client.Remove(key);
                    return null;
                }
                return cacheEntry;
            }
            return null;
        }

        private bool CacheAdd(string key, object value, DateTime expiresAt)
        {
            CacheEntry entry;
            if (TryGet(key, out entry)) return false;

            entry = new CacheEntry(value, expiresAt);
            this.Set(key, entry);

            return true;
        }

        public List<string> SearchKeys(string keyPattern)
        {
            return m_client.GetClient().SearchKeys(keyPattern);
        }

        public bool Add<T>(string key, T value)
        {
            return CacheAdd(key, value, DateTime.UtcNow.Add(AppConfig.Instance.DefaultExpireTime));
        }

        private void Set(string key, CacheEntry entry)
        {
            this.m_client.Set<CacheEntry>(key, entry);
        }

        public bool Set<T>(string key, T value)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(AppConfig.Instance.DefaultExpireTime));
        }

        private bool CacheSet(string key, object value, DateTime expiresAt)
        {
            CacheEntry entry;
            if (!TryGet(key, out entry))
            {
                entry = new CacheEntry(value, expiresAt);
                this.Set(key, entry);
                return true;
            }

            entry.SetValue(value);
            entry.ExpiresAt = expiresAt;
            this.Set(key, entry);
            return true;
        }

        public bool Replace<T>(string key, T value)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(AppConfig.Instance.DefaultExpireTime));
        }

        public bool Add<T>(string key, T value, DateTime expiresAt)
        {
            return CacheAdd(key, value, expiresAt);
        }

        public bool Set<T>(string key, T value, DateTime expiresAt)
        {
            return CacheSet(key, value, expiresAt);
        }

        public bool Replace<T>(string key, T value, DateTime expiresAt)
        {
            return CacheSet(key, value, expiresAt);
        }

        public bool Add<T>(string key, T value, TimeSpan expiresIn)
        {
            return CacheAdd(key, value, DateTime.UtcNow.Add(expiresIn));
        }

        public bool Set<T>(string key, T value, TimeSpan expiresIn)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(expiresIn));
        }

        public bool Replace<T>(string key, T value, TimeSpan expiresIn)
        {
            return CacheSet(key, value, DateTime.UtcNow.Add(expiresIn));
        }

        public void FlushAll()
        {
            this.m_client.FlushAll();
        }

        public void Dispose()
        {
            this.m_client.FlushAll();
        }
    }
}
