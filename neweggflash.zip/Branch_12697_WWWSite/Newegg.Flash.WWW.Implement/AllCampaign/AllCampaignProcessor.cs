﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IAllCampaign))]
    public class AllCampaignProcessor : IAllCampaign
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());
        protected IStore StoreProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IStore>();
            }
        }
        /// <summary>
        /// Get all campaign deals by storeid
        /// </summary>
        /// <param name="storeId"></param>
        /// <returns></returns>
        public GeneralDeals Get(int storeId, int pageIndex = 1, int pageSize = 20, int sort = 1)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("All_Campaign");
            request.IsAwaitContext = false;
            request.SetUrlParameter("storeId", storeId.ToString());
            request.SetUrlParameter("pageIndex", pageIndex.ToString());
            request.SetUrlParameter("pageSize", pageSize.ToString());
            request.SetUrlParameter("sort", sort.ToString());
            var result=this.restClient.Value.SendAsync<GeneralDeals>(request).Result.ResponseBody;


            result.StoreName = StoreProcessor.GetStoreProperty(result.StoreId, "Crumb");
            result.PageAliase = StoreProcessor.GetStoreProperty(result.StoreId, "Aliase");

            return result;
        }
    }
}
