﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IStore))]
    public class StoreProcessor : IStore
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public HeaderContent GetHeaderContent(int categoryCount = 7, int featuredSalesCount = 5)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Home_GetHeaderContent");
            request.IsAwaitContext = false;
             var result = this.restClient.Value.SendAsync<HeaderContent>(request).Result.ResponseBody;

            var headerContent = new HeaderContent();

            result.HeaderStores.ForEach(store =>
            {
                store.PageAliase = GetStoreProperty(store.StoreId, "Aliase");
                store.StoreName = GetStoreProperty(store.StoreId);
                headerContent.HeaderStores.Add(store);
            });
            headerContent.HeaderStores = result.HeaderStores.OrderBy(x => x.StoreId).ToList();
            return headerContent;
        }

        /// <summary>
        /// Get Deals By NeweggFlash Store.
        /// </summary>
        /// <param name="storeId"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="category"></param>
        /// <param name="sortby"></param>
        /// <returns></returns>
        public GeneralDeals GetStoreDeals(int storeId = 1, int pageIndex = 1, int pageSize = 20, int category = 0,
            int sortby = 0)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("NFStore_Get");
            request.IsAwaitContext = false;
            request.SetUrlParameter("storeId", storeId.ToString());
            request.SetUrlParameter("pageIndex", pageIndex.ToString());
            request.SetUrlParameter("pageSize", pageSize.ToString());
            request.SetUrlParameter("category", category.ToString());
            request.SetUrlParameter("sortby", sortby.ToString());
            var result = this.restClient.Value.SendAsync<GeneralDeals>(request).Result.ResponseBody;
            result.SubCategoryId = category;
            result.StoreId = storeId;
            result.StoreName = GetStoreProperty(storeId, "Crumb");
            result.PageAliase = GetStoreProperty(storeId, "Aliase");

            return result;
        }

        public string GetStoreProperty(int id, string suffix="")
        {
            const string prefix = "Store";
            var pp = string.Format("{0}{1}{2}", prefix, id, suffix);
            var ppinfo = typeof(WWW.Globalization.Store).GetProperty(pp);
            var ppvalue = ppinfo.GetValue(null) ?? "";
            return ppvalue.ToString();
        }


    }
}
