﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Interface.Customer;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Implement.Account
{
    /// <summary>
    /// Customer Account Implementation.
    /// </summary>
    [AutoSetupService(typeof(ICustomerAccount))]
    public class CustomerAccount : ICustomerAccount
    {
        /// <summary>
        /// Rest client.
        /// </summary>
        private Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        /// <summary>
        /// Customer login.
        /// </summary>
        /// <param name="userName">The user login name,always email address.</param>
        /// <param name="password">The user's password.</param>
        /// <param name="pageName"> Page name.</param>
        /// <param name="checkCapcha">Whether check capcha.</param>
        /// <param name="transactionNumber">Validation code transaction number.</param>
        /// <param name="validateCode">Validate code.</param>
        /// <returns> The login result.</returns>
        public Task<IRestfulResponse<MessageExtension<UILoginResultInfo, MPEOutputMessageInfo>>> Login(string userName, string password, string pageName, bool checkCapcha, int transactionNumber, string validateCode)
        {
            IRestfulRequest request = this.restClient.Value.GetRequestFromConfigurationWithRequestHeader("Customer_Login");
            request.SetUrlParameter("UserName", userName);
            request.SetUrlParameter("Password", password);
            request.SetUrlParameter("referenceURL", pageName);
            request.SetUrlParameter("needCheckCapture", checkCapcha.ToString());
            request.SetUrlParameter("tranNum", transactionNumber.ToString());
            request.SetUrlParameter("validateCode", validateCode);
            var response = this.restClient.Value.SendAsync<MessageExtension<UILoginResultInfo, MPEOutputMessageInfo>>(request);
            return response;
        }

        /// <summary>
        /// Quick register a new customer.
        /// </summary>
        /// <param name="registerInfo">The register info entity.</param>
        /// <returns>UI Login Result Info.</returns>
        public Task<IRestfulResponse<MessageExtension<UILoginResultInfo, MPEOutputMessageInfo>>> QuickRegister(UICustomerRegisterInfo registerInfo)
        {
            IRestfulRequest request = this.restClient.Value.GetRequestFromConfigurationWithRequestHeader<UICustomerRegisterInfo>("Customer_QuickRegister");
            request.ReqeustBodyObject = registerInfo;
            var response = this.restClient.Value.SendAsync<MessageExtension<UILoginResultInfo, MPEOutputMessageInfo>>(request);
            return response;
        }

        /// <summary>
        /// Shopping login.
        /// </summary>
        /// <param name="userName">The user login name,always email address.</param>
        /// <param name="password">The user's password.</param>
        /// <param name="pageName"> Page name.</param>
        /// <param name="checkCapcha">Whether check capcha.</param>
        /// <param name="transactionNumber">Validation code transaction number.</param>
        /// <param name="validateCode">Validate code.</param>
        /// <returns>UI Shopping Login Result Info.</returns>
        public Task<IRestfulResponse<MessageExtension<UIShoppingLoginResultInfo, MPEOutputMessageInfo>>> ShoppingLogin(string userName, string password, string pageName, bool checkCapcha, int transactionNumber, string validateCode)
        {
            IRestfulRequest request = this.restClient.Value.GetRequestFromConfigurationWithRequestHeader("Customer_ShoppingLogin");
            UILoginInputInfo loginInputInfo = new UILoginInputInfo()
            {
                LoginName = userName,
                Password = password,
                ReferenceURL = pageName,
                NeedCheckCapcha = checkCapcha,
                TransactionNumber = transactionNumber,
                ValidateCode = validateCode
            };
            request.ReqeustBodyObject = loginInputInfo;
            var response = this.restClient.Value.SendAsync<MessageExtension<UIShoppingLoginResultInfo, MPEOutputMessageInfo>>(request);

            return response;
        }
    }
}
