﻿using System;
using System.Linq;
using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IToday))]
    public class TodayProcessor:IToday
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public TodayDeals Get()
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("EndingSoon_Get");
            request.IsAwaitContext = false;
            var result = this.restClient.Value.SendAsync<TodayDeals>(request).Result.ResponseBody;
            if (result != null)
            {
                result.Deals.ForEach(d =>
                {
                    if (d.ItemType == 0)
                    {
                        d.Campaign.ImageSize = d.ImageSize;
                    }
                    else
                    {
                        d.Item.ImageSize = d.ImageSize;
                    }
                });

                //result.Deals = (from d in result.Deals
                //                orderby d.ImageSize descending, d.StartTime descending, d.Priority
                //                select d).ToList();
            }

            return result;
        }
    }
}
