﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IFeaturedStore))]
    public class FeaturedStoreProcessor : IFeaturedStore
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());
        /// <summary>
        /// 获取Featured Store数据，含分页
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public GeneralDeals Get(int pageIndex = 1, int pageSize = 20)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("FeaturedStore_Get");
            request.SetUrlParameter("PageIndex", pageIndex.ToString());
            request.SetUrlParameter("PageSize", pageSize.ToString());
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<GeneralDeals>(request).Result.ResponseBody;
        }
    }
}
