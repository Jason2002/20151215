﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.EC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface.Search;
using Newegg.EC.IOC;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(ISearch))]
    public class SearchProcessor :ISearch
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public SearchPage Get(string keyword, int sortby=0, int category=0,string within="")
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Search_Get");
            request.SetUrlParameter("Keyword", keyword);
            request.SetUrlParameter("Within", within);
            request.SetUrlParameter("Sortby", sortby.ToString());
            request.SetUrlParameter("Category", category.ToString());
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<SearchPage>(request).Result.ResponseBody;
        }

        public KeyValuePair<int, List<ItemBase>> Paging(string keyword,int sortby,string within,int pageIndex, int pageSize, int category)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Search_Paging");
            request.SetUrlParameter("Keyword", keyword);
            request.SetUrlParameter("Within", within);
            request.SetUrlParameter("PageIndex", pageIndex.ToString());
            request.SetUrlParameter("PageSize", pageSize.ToString());
            request.SetUrlParameter("Category", category.ToString());
            request.SetUrlParameter("Sortby", sortby.ToString());
            
            request.IsAwaitContext = false;
            var result = this.restClient.Value.SendAsync<SearchPage>(request).Result.ResponseBody;
            return new KeyValuePair<int, List<ItemBase>>(result.TotalCount, result.Items);
        }

        public List<string> GetSuggestKeywords(string userInput, int sugguestCount)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Search_SuggestKey");
            request.SetUrlParameter("userInput", userInput);
            request.SetUrlParameter("sugguestCount", sugguestCount.ToString());
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<List<string>>(request).Result.ResponseBody;
        }
    }
}
