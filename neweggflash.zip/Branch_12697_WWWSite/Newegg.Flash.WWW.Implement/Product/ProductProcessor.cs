﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IProduct))]
    public class ProductProcessor:IProduct
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public List<Item> Get(string itemNumber, bool isUpcoming, bool isRequestFromNeweggCentral, bool isGift)
        {
            IRestfulRequest request = null;
            if (!isRequestFromNeweggCentral)
            {
                request = restClient.Value.GetRequestFromConfigurationWithRegion("Product_Get");
            }
            else
            {
                request = restClient.Value.GetRequestFromConfigurationWithRequestHeaderForNeweggCentral("Product_Get");
            }
            
            request.SetUrlParameter("itemNumber", itemNumber);
            request.SetUrlParameter("isUpcoming", isUpcoming.ToString());
            request.SetUrlParameter("isGift", isGift.ToString());
            request.IsAwaitContext = false;
            return restClient.Value.SendAsync<List<Item>>(request).Result.ResponseBody;
        }

        /// <summary>
        /// Get item's return policy
        /// </summary>
        /// <param name="itemNumber">itemNumber</param>
        /// <returns></returns>
        public ReturnPolicyPage GetReturnPolicy(string itemNumber, bool isGift)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("ReturnPolicy_Get");
            request.SetUrlParameter("itemNumber", itemNumber);
            request.SetUrlParameter("isGift", isGift.ToString());
            request.IsAwaitContext = false;
            return restClient.Value.SendAsync<ReturnPolicyPage>(request).Result.ResponseBody;
        }

        public List<AdditionalProductInfo> GetAdditionalProductInfo(string lstitemNumbers, string itype)
        {
            IRestfulRequest request = null;
            if (lstitemNumbers.IsNullOrEmpty())
            {
                return null;
            }

            request = restClient.Value.GetRequestFromConfigurationWithRegion("ProductAdditional");
            request.SetUrlParameter("itemNumbers", lstitemNumbers);
            request.SetUrlParameter("type", itype);
            request.IsAwaitContext = false;

            return restClient.Value.SendAsync<List<AdditionalProductInfo>>(request).Result.ResponseBody; 
        }


        public IEnumerable<RealTimeExchangeRateModel> GetRealtimeExchangeRate(string itemNumbers, 
            string countryCode, int companyCode, string currencyCode )
        {
            IRestfulRequest request = null;
            if (itemNumbers.IsNullOrEmpty())
            {
                return null;
            }

            request = restClient.Value.GetRequestFromConfiguration("ProductRealtimeExchangeRate");
            request.SetUrlParameter("itemNumbers", itemNumbers);
            request.SetUrlParameter("countryCode", countryCode);
            request.SetUrlParameter("companyCode", companyCode.ToString());
            request.SetUrlParameter("currencyCode", currencyCode);
            request.IsAwaitContext = false;

            return restClient.Value.SendAsync<List<RealTimeExchangeRateModel>>(request).Result.ResponseBody; 
        }
    }
}
