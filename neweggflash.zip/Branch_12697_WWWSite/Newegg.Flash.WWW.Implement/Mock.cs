﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash
{
    public static class Mock
    {
        public static List<Store> MockStore()
        {
            var result = new List<Store>()
			{
				new Store()
				{
					StoreId		= 1,
					SubCategories	= new DealsContainer<Subcategory>()
					{
						Items = new List<Subcategory>()
						{
							new Subcategory()
							{
								ID	= 1,
								Name	= "Computer"
							},
							new Subcategory()
							{
								ID	= 2,
								Name	= "Digital"
							},
							new Subcategory()
							{
								ID	= 3,
								Name	= "Office"
							},
							new Subcategory()
							{
								ID	= 4,
								Name	= "Peripherals"
							},
							new Subcategory()
							{
								ID	= 5,
								Name	= "Game"
							},
							new Subcategory()
							{
								ID	= 6,
								Name	= "Software"
							}
						}
					},
					FeaturedSales = new DealsContainer<Deal>()
					{
						Items = new List<Deal>()
						{
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 50,
									UnitPrice	= 969.99m,
									FinalPrice	= 779.99m,
									Qty		= 99,
									Description	= "Eyama Super Power Banks—save now on extra fast mobile battery recharges",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_07.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 50,
									UnitPrice	= 969.99m,
									FinalPrice	= 779.99m,
									Qty		= 99,
									Description	= "Avatar Gaming I5-4576 Desktop PC Intel Core i5 4570 (3.20GHz) 8GB DDR3 1TB HDD Capacity Windows 8.1 64-Bit",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_01.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 59,
									UnitPrice	= 31.99m,
									FinalPrice	= 12.99m,
									Qty		= 4,
									Description	= "Doctor Who Trivia Pursuit Game!",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_02.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 48,
									UnitPrice	= 24.99m,
									FinalPrice	= 12.99m,
									Qty		= 0,
									Description	= "Rosewill RHB-320W 7 Ports USB 2.0 Hub with Power Adapter",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_04.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountInstant = 25,
									UnitPrice	= 19.99m,
									FinalPrice	= 14.99m,
									Qty		= 20,
									Description	= "Archstone AH-497 Battery operated wine opener",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_10.jpg"
										}
									}
								},
							}
						}
					}
				},
				new Store()
				{
					StoreId		= 2,
					SubCategories	= new DealsContainer<Subcategory>()
					{
						Items = new List<Subcategory>()
						{
							new Subcategory()
							{
								ID	= 11,
								Name	= "Game"
							},
							new Subcategory()
							{
								ID	= 22,
								Name	= "SoftWare"
							},
							new Subcategory()
							{
								ID	= 33,
								Name	= "Office"
							},
							new Subcategory()
							{
								ID	= 44,
								Name	= "Peripherals"
							}
						}
					},
					FeaturedSales = new DealsContainer<Deal>()
					{
						Items = new List<Deal>()
						{
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 50,
									UnitPrice	= 969.99m,
									FinalPrice	= 779.99m,
									Qty		= 99,
									Description	= "Eyama Super Power Banks—save now on extra fast mobile battery recharges",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_07.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 50,
									UnitPrice	= 969.99m,
									FinalPrice	= 779.99m,
									Qty		= 99,
									Description	= "Avatar Gaming I5-4576 Desktop PC Intel Core i5 4570 (3.20GHz) 8GB DDR3 1TB HDD Capacity Windows 8.1 64-Bit",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_01.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 59,
									UnitPrice	= 31.99m,
									FinalPrice	= 12.99m,
									Qty		= 4,
									Description	= "Doctor Who Trivia Pursuit Game!",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_02.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 48,
									UnitPrice	= 24.99m,
									FinalPrice	= 12.99m,
									Qty		= 0,
									Description	= "Rosewill RHB-320W 7 Ports USB 2.0 Hub with Power Adapter",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_04.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountInstant = 25,
									UnitPrice	= 19.99m,
									FinalPrice	= 14.99m,
									Qty		= 20,
									Description	= "Archstone AH-497 Battery operated wine opener",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_10.jpg"
										}
									}
								},
							}
						}
					}
				},
				new Store()
				{
					StoreId		= 3,
					SubCategories	= new DealsContainer<Subcategory>()
					{
						Items = new List<Subcategory>()
						{
							new Subcategory()
							{
								ID	= 111,
								Name	= "Computer"
							},
							new Subcategory()
							{
								ID	= 222,
								Name	= "Digital"
							},
							new Subcategory()
							{
								ID	= 333,
								Name	= "Office"
							},
							new Subcategory()
							{
								ID	= 444,
								Name	= "Peripherals"
							},
							new Subcategory()
							{
								ID	= 555,
								Name	= "Game"
							},
							new Subcategory()
							{
								ID	= 666,
								Name	= "SoftWare"
							}
						}
					},
					FeaturedSales = new DealsContainer<Deal>()
					{
						Items = new List<Deal>()
						{
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 50,
									UnitPrice	= 969.99m,
									FinalPrice	= 779.99m,
									Qty		= 99,
									Description	= "Eyama Super Power Banks—save now on extra fast mobile battery recharges",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_07.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 50,
									UnitPrice	= 969.99m,
									FinalPrice	= 779.99m,
									Qty		= 99,
									Description	= "Avatar Gaming I5-4576 Desktop PC Intel Core i5 4570 (3.20GHz) 8GB DDR3 1TB HDD Capacity Windows 8.1 64-Bit",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_01.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 59,
									UnitPrice	= 31.99m,
									FinalPrice	= 12.99m,
									Qty		= 4,
									Description	= "Doctor Who Trivia Pursuit Game!",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_02.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountMark	= true,
									DiscountInstant = 48,
									UnitPrice	= 24.99m,
									FinalPrice	= 12.99m,
									Qty		= 0,
									Description	= "Rosewill RHB-320W 7 Ports USB 2.0 Hub with Power Adapter",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_04.jpg"
										}
									}
								},
							},
							new Deal()
							{
								ItemType	= 1,
								Item		= new ItemBase()
								{
									Active		= true,
									DiscountInstant = 25,
									UnitPrice	= 19.99m,
									FinalPrice	= 14.99m,
									Qty		= 20,
									Description	= "Archstone AH-497 Battery operated wine opener",
									StartTime	= DateTime.Now.AddDays( -2 ),
									ExpireTime	= DateTime.Now.AddDays( 2 ),
									ImageSize	= 0,
									Images		= new List<ItemImage>()
									{
										new ItemImage()
										{
											ImageSize300 = "http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_10.jpg"
										}
									}
								},
							}
						}
					}
				}
			};

//            var storeMenus = ConfigurationWWWManager<StoreMenuConfig>.ItemCfg();
//            foreach (var item in result)
//            {
//                var store = storeMenus.Stores.FirstOrDefault(i => i.StoreId == item.StoreId);
//                if (store != null)
//                {
//                    item.StoreName = store.StoreName;
//                    item.PageAliase = store.Aliase;
//                }
//            }
            return (result);
        }


        public static AllCampaign MockAllCampaign(int id)
        {
//            var storeMenus = ConfigurationWWWManager<StoreMenuConfig>.ItemCfg();
//            var store = storeMenus.Stores.FirstOrDefault(i => i.StoreId == id);
            AllCampaign all = new AllCampaign()
            {
                Id = id,
//                Aliase = store != null ? store.Aliase : string.Empty,
//                Name = store != null ? store.StoreName : string.Empty,
                Items = new DealsContainer<Campaign>()
                {
                    Items = new List<Campaign>()
					{
						new Campaign()
						{
                            CampaignId=1,
                            CampaignName="Campaign1",
							CampaignDescription	= "Archstone AH-497 Battery operated wine opener",
							StartTime	= DateTime.Now.AddDays( -2 ),
							ExpireTime	= DateTime.Now.AddDays( 2 ),
                            ImageSize=0,
                            ImageName="1",
							ImageUrl300="http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_10.jpg"
						},
                        new Campaign()
						{
                            CampaignId=2,
                            CampaignName="Campaign2",
							CampaignDescription	= "Rosewill RHB-320W 7 Ports USB 2.0 Hub with Power Adapter",
							StartTime	= DateTime.Now.AddDays( -2 ),
							ExpireTime	= DateTime.Now.AddDays( 3 ),
                            ImageSize=0,
                            ImageName="1",
							ImageUrl300="http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_04.jpg"
						},
                        new Campaign()
						{
                            CampaignId=3,
                            CampaignName="Campaign3",
							CampaignDescription	= "Doctor Who Trivia Pursuit Game!",
							StartTime	= DateTime.Now.AddDays( -2 ),
							ExpireTime	= DateTime.Now.AddDays( 3 ),
                            ImageSize=0,
                            ImageName="1",
							ImageUrl300="http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_02.jpg"
						},
                        new Campaign()
						{
                            CampaignId=4,
                            CampaignName="Campaign4",
							CampaignDescription	= "Eyama Super Power Banks—save now on extra fast mobile battery recharges",
							StartTime	= DateTime.Now.AddDays( -2 ),
							ExpireTime	= DateTime.Now.AddDays( 3 ),
                            ImageSize=0,
                            ImageName="1",
							ImageUrl300="http://10.16.76.229/neweggflash/20140401/images/products/640x480/p_01.jpg"
						},
					}
                }
            };
            all.Items.TotalCount = 100;
            return (all);
        }
    }
}
