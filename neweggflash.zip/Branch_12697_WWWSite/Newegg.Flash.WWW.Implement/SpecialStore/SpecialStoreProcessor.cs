﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.EC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface.Search;
using Newegg.EC.IOC;
using Newegg.Flash.WWW.Interface.SpecialStore;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(ISpecialStore))]
    public class SpecialStoreProcessor : ISpecialStore
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public GeneralDeals Get(int pageIndex, int pageSize)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("SpecialStore_Get");
            request.SetUrlParameter("PageIndex", Convert.ToString(pageIndex));
            request.SetUrlParameter("PageSize", Convert.ToString(pageSize));
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<GeneralDeals>(request).Result.ResponseBody;
        }
        
    }



}
