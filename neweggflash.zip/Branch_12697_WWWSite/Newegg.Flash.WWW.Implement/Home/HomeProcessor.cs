﻿using System;
using System.Linq;
using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Log;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IHome))]
    public class HomeProcessor : IHome
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public BizContext BizContextData()
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("BizContext");
            request.IsAwaitContext = false;
            var result = restClient.Value.SendAsync<BizContext>(request).Result.ResponseBody;
            return result;
        }

        public HomePage Get()
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Home_Get");
            request.IsAwaitContext = false;
            var result = this.restClient.Value.SendAsync<HomePage>(request).Result.ResponseBody;

            return result;
        }

        /// <summary>
        /// Subscribe
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="subscriptStatus"></param>
        /// <returns></returns>
        public bool Subscribe(string loginName, bool subscriptStatus = true)
        {
            var result = false;
            var request = restClient.Value.GetRequestFromConfigurationWithRequestHeader("Subscribe");
            request.SetUrlParameter("loginName", loginName);
            request.SetUrlParameter("subscriptStatus", subscriptStatus.ToString());
            try
            {
                var response = this.restClient.Value.SendAsync<Message<bool>>(request).Result;
                if (response != null && response.IsSuccessStatusCode && response.ResponseBody != null)
                {
                    if (response.ResponseBody.Body && response.ResponseBody.HasSuccess)
                    {
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                var log = ECLibraryContainer.Current.GetInstance<ILogger>();
                if (log != null)
                {
                    log.Exception = ex;
                    log.AddCategory("Newegg.Flash");
                    log.AddMessage("Homepage Subscribe Error.");
                    log.Write();
                }
            }
            return result;
        }

        /// <summary>
        /// 获取首页数据
        /// </summary>
        /// <param name="upcomingDays"></param>
        /// <param name="bannerCount"></param>
        /// <returns></returns>
        public HomePage Get(int upcomingDays = 3,int bannerCount = 5, int featuredDealsCount = 5, int featuredStoreCount =  5,int upcomingCount = 5)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("HomeV2_Get");
            request.IsAwaitContext = false;
            request.Verb = VerbType.Get;
            request.SetUrlParameter("upcomingDays", upcomingDays.ToString());
            request.SetUrlParameter("bannerCount", bannerCount.ToString());
            request.SetUrlParameter("featuredDealsCount", featuredDealsCount.ToString());
            request.SetUrlParameter("featuredStoreCount", featuredStoreCount.ToString());
            request.SetUrlParameter("upcomingCount", upcomingCount.ToString());
            var result = this.restClient.Value.SendAsync<HomePage>(request).Result.ResponseBody;

            return result;
        }
    }
}
