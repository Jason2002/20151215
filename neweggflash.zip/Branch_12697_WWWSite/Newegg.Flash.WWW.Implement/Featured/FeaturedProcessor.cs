﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.EC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface.Search;
using Newegg.EC.IOC;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IFeatured))]
    public class FeaturedProcessor :IFeatured
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public FeaturedPage Get(int category,int sortby)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Featured_Get");
            request.SetUrlParameter("PageIndex",Convert.ToString(1));
            request.SetUrlParameter("PageSize", Convert.ToString(20));
            request.SetUrlParameter("Category", category.ToString());
            request.SetUrlParameter("Sortby", sortby.ToString());
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<FeaturedPage>(request).Result.ResponseBody;
        }

        

        public KeyValuePair<int, List<ItemBase>> Paging(int pageIndex,int pageSize,int category,int sortby)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Featured_Paging");
            request.SetUrlParameter("PageIndex", pageIndex.ToString());
            request.SetUrlParameter("PageSize", pageSize.ToString());
            request.SetUrlParameter("Category", category.ToString());
            request.SetUrlParameter("Sortby", sortby.ToString());
            
            request.IsAwaitContext = false;
            var result = this.restClient.Value.SendAsync<FeaturedPage>(request).Result.ResponseBody;
            return new KeyValuePair<int, List<ItemBase>>(result.TotalCount, result.Items);
        }
    }



}
