﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IEggPoint))]
    public class EggPointProcessor : IEggPoint
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public List<EggPointServiceModel> GetEggPoint(List<PointRateItemInfo> items)
        {
            IRestfulRequest request = null;
            if (items==null)
            {
                return null;
            }

            request = restClient.Value.GetRequestFromConfigurationWithRegion("EggPoint_Get");
            request.ReqeustBodyObject = items;
            request.IsAwaitContext = false;

            return restClient.Value.SendAsync<List<EggPointServiceModel>>(request).Result.ResponseBody; 
        }
    }
}
