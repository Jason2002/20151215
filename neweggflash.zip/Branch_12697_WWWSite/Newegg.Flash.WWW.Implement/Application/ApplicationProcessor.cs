﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  5/21/2013 3:54:24 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;

using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement.Application
{
    [AutoSetupService(typeof(IApplication))]
    public class ApplicationProcessor : IApplication
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        #region IApplication Members

        public Model.Application Get()
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Application_Get");
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<Model.Application>(request).Result.ResponseBody;
        }

        #endregion
    }
}
