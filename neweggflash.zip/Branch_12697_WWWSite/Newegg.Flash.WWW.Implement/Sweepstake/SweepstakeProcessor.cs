﻿using System;
using System.Linq;
using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Log;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(ISweepstake))]
    public class SweepstakeProcessor : ISweepstake
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public Sweepstake Get(string countryCode)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Sweepstake_Get");
            request.IsAwaitContext = false;
            request.SetUrlParameter("countryCode", countryCode);
            var result = this.restClient.Value.SendAsync<Sweepstake>(request).Result.ResponseBody;

            return result;
        }
    }
}
