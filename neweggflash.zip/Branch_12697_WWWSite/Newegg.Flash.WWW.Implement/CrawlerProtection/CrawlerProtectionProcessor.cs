﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement.CrawlerProtection
{
    [AutoSetupService(typeof(ICrawlerProtection))]
    public class CrawlerProtectionProcessor : ICrawlerProtection
    {
        /// <summary>
        /// Rest client.
        /// </summary>
        private Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public CrawlerProtectionInfo LoadProtectionInfo(string ip, string utma)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Crawler_LoadProtectionInfo");
            request.Verb = VerbType.Get;
            request.IsAwaitContext = false;
            request.SetUrlParameter("ip", ip);
            request.SetUrlParameter("utma", utma);
            var result = this.restClient.Value.SendAsync<CrawlerProtectionInfo>(request).Result.ResponseBody;
            return result;
        }
    }
}
