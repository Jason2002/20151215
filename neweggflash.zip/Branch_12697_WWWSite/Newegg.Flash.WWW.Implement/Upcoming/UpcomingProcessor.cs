﻿using System;
using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(IUpcoming))]
    public class UpcomingProcessor : IUpcoming
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public UpcomingSales Get(int dayCount = 3, int dealCount = 4)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Upcoming_Get");
            request.SetUrlParameter("dayCount", dayCount.ToString());
            request.SetUrlParameter("dealCount", dealCount.ToString());
            request.IsAwaitContext = false;
            UpcomingSales result = this.restClient.Value.SendAsync<UpcomingSales>(request).Result.ResponseBody;
            if (result != null)
            {
                result.Deals.Values.ForEach(listDeal =>
                {
                    listDeal.ForEach(d => d.ImageSize = 0);
                });
            }
            return result;
        }
    }
}
