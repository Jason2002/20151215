﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface.MiniCart;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement.MiniCart
{
    [AutoSetupService(typeof(IMiniCart))]
    public class MiniCartProcessor : IMiniCart
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        /// <summary>
        /// minicart更新时，获取数据
        /// </summary>
        /// <param name="itemNumbers">需要更新的itemnumber列表</param>
        /// <returns></returns>
        public List<MiniCartItem> GetMiniCartItemInfo(string itemNumbers)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("MiniCartItemInfo_Get");
            request.IsAwaitContext = false;
            request.SetUrlParameter("itemNumbers", itemNumbers);
            var result = this.restClient.Value.SendAsync<List<MiniCartItem>>(request).Result.ResponseBody;

            return result;
        }
    }
}
