﻿using Newegg.EC;
using Newegg.EC.IOC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Implement
{
    [AutoSetupService(typeof(ICampaign))]
    public class CampaignProcessor : ICampaign
    {
        protected Lazy<IRestfulClient> restClient = new Lazy<IRestfulClient>(() => ECLibraryContainer.Current.GetInstance<IRestfulClient>());

        public CampaignPage Get(int campaignID)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Campaign_Get");
            request.SetUrlParameter("CampaignID",campaignID.ToString());
            request.IsAwaitContext = false;
            return this.restClient.Value.SendAsync<CampaignPage>(request).Result.ResponseBody;
        }

        public KeyValuePair<int, List<ItemBase>> Paging(int campaignID, int pageIndex, int pageSize, int sort, int categoryID)
        {
            var request = restClient.Value.GetRequestFromConfigurationWithRegion("Campaign_Paging");
            request.SetUrlParameter("CampaignID", campaignID.ToString());
            request.SetUrlParameter("PageIndex", pageIndex.ToString());
            request.SetUrlParameter("PageSize", pageSize.ToString());
            request.SetUrlParameter("Sort", sort.ToString());
            request.SetUrlParameter("subCategoryID",categoryID.ToString());
            request.IsAwaitContext = false;
            var result = this.restClient.Value.SendAsync<CampaignPage>(request).Result.ResponseBody;
            return new KeyValuePair<int, List<ItemBase>>(result.TotalCount, result.Items);
        }
    }
}
