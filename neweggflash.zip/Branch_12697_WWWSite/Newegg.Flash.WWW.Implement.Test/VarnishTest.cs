﻿using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Newegg.Flash.WWW.Implement.Test
{
    [TestFixture]
    public class VarnishTest
    {
        #region <-Instance Fields->
        public const string APPLE_DEVICE = "Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1C28 Safari/419.3";
        public const string ANDROID_DEVICE = "Mozilla/5.0 (Linux; U; Android 3.0.1; ja-jp; MZ604 Build/H.6.2-20) AppleWebKit/534.13 (KHTML, like Gecko) Version/4.0 Safari/534.13";
        public const string BLACK_BERRY_DEVICE = "BlackBerry9000/4.6.0.294 Profile/MIDP-2.0 Configuration/CLDC-1.1 VendorID/220";
        public const string WINDOWS_PHONE_DEVICE = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; KDDI-TS01; Windows Phone 6.5.3.5)";

        public const string OTHER_DEVICE_BROWSER = "Fiddler";

        public const string IE_BROWSER = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)";
        public const string FIREFOX_BROWSER = "Mozilla/5.0 (Windows NT 5.1; rv:5.0) Gecko/20100101 Firefox/5.0";
        public const string OPERA_BROWSER = "Opera/9.80 (Windows NT 5.1; U; zh-cn) Presto/2.9.168 Version/11.50";
        public const string SAFARI_BROWSER = "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1";
        public const string CHROME_BROWSER = "Mozilla/5.0 (Windows NT 5.2) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.122 Safari/534.30";

        public string HomePage;
        private Dictionary<string, string> testmap = new Dictionary<string, string>();
        #endregion

        #region <-Methodes->

        [TestFixtureSetUp]
        public void Initlized()
        {
            HomePage = "http://localhost:62010/";

            testmap.Add(HomePage, "Level1");
            testmap.Add("http://localhost:62010/Campaign/4", "Level1");

            testmap.Add("http://localhost:62010/Product/N82E16897044070R", "Level2");
            testmap.Add("http://localhost:62010/Product/N82E16897044070R/ReturnPolicy", "Level2");

            testmap.Add("http://localhost:62010/Upcoming", "Level3");
            testmap.Add("http://localhost:62010/Today", "Level3");

            testmap.Add("http://localhost:62010/about-us", "Level4");
            testmap.Add("http://localhost:62010/office-hours-and-locations", "Level4");
            testmap.Add("http://localhost:62010/contact-us", "Level4");
            testmap.Add("http://localhost:62010/faq", "Level4");
            testmap.Add("http://localhost:62010/california-transparency-in-supply-chains-act", "Level4");
            testmap.Add("http://localhost:62010/terms-and-conditions", "Level4");
            testmap.Add("http://localhost:62010/privacy-policy", "Level4");
            testmap.Add("http://localhost:62010/return-policy", "Level4");
            testmap.Add("http://localhost:62010/affiliates", "Level4");
            testmap.Add("http://localhost:62010/sell-to-us", "Level4");

            testmap.Add("http://localhost:62010/App/faq.aspx", "Bypass");
            testmap.Add("http://localhost:62010/ServerTest", "Bypass");
        }

        [Test]
        public void PageTest()
        {
            foreach (var entity in testmap)
            {
                Assert.AreEqual(CreateRequest(entity.Key, IE_BROWSER), entity.Value,string.Format("{0} should return {1}",entity.Key,entity.Value));
            }
        }

        [Test]
        public void DeviceTest()
        {
            Assert.AreEqual(CreateRequest(HomePage, APPLE_DEVICE), "Bypass");
            Assert.AreEqual(CreateRequest(HomePage, ANDROID_DEVICE), "Bypass");
            Assert.AreEqual(CreateRequest(HomePage, BLACK_BERRY_DEVICE), "Bypass");
            Assert.AreEqual(CreateRequest(HomePage, WINDOWS_PHONE_DEVICE), "Level1");
        }

        [Test]
        public void BrowserTest()
        {
            Assert.AreEqual(CreateRequest(HomePage, IE_BROWSER), "Level1");
            Assert.AreEqual(CreateRequest(HomePage, FIREFOX_BROWSER), "Level1");
            Assert.AreEqual(CreateRequest(HomePage, OPERA_BROWSER), "Level1");
            Assert.AreEqual(CreateRequest(HomePage, SAFARI_BROWSER), "Level1");
            Assert.AreEqual(CreateRequest(HomePage, CHROME_BROWSER), "Level1");
        }

        private string CreateRequest(string url, string userAgent)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.UserAgent = userAgent;
            request.Headers.Add("X-From-Cache", "yes");
            var response = request.GetResponse();
            return response.Headers["x-cache-behavior"];
        }
        #endregion
    }
}
