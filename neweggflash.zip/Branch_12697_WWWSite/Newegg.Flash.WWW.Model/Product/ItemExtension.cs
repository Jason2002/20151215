﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/28/2013 10:57:56 AM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;
using System.Linq;
using System.Collections.Generic;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common;
using System.Text;
using System.Xml;
using Resource = Newegg.Flash.WWW.Globalization;
using Newegg.EC;
using Newegg.EC.BizUnit;
using Newegg.Flash.WWW.Globalization;

namespace Newegg.Flash.WWW.Model
{

    /// <summary>
    /// Newegg image type
    /// </summary>
    public enum NeweggImageType
    {
        Normal,
        Sene7,
        Specialsene7,
    }

    public partial class Item
    {

        private List<string> additionalImages;
        private string m_specification;
        private string m_warrantyContent;
        private string m_sellerWarrantyContent;

        /// <summary>
        ///Additionl images(storage at DFIS) 
        /// </summary>
        public List<string> AdditionalImages
        {
            get
            {
                if (additionalImages == null)
                {
                    additionalImages = SpecialImage.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                }
                return additionalImages;
            }
        }

        /// <summary>
        /// get newegg image type
        /// </summary>
        public NeweggImageType NeweggImageType
        {
            get
            {
                Scene7 scen7Config = ConfigurationWWWManager<Scene7>.ItemCfg();
                if (this.HasScene7Image == "1" && scen7Config != null && scen7Config.EnableScene7)
                {
                    return NeweggImageType.Sene7;
                }
                else if (!string.IsNullOrEmpty(this.SpecialImageList) && scen7Config != null && scen7Config.EnableSpecialScene7)
                {
                    return NeweggImageType.Specialsene7;
                }
                else
                {
                    return NeweggImageType.Normal;
                }
            }
        }

        private List<string> neweggImages;
        /// <summary>
        /// Normal or Sence7 images
        /// </summary>
        public List<string> NeweggImages
        {
            get
            {
                if (neweggImages == null)
                {
                    var type = NeweggImageType;
                    switch (type)
                    {
                        case NeweggImageType.Sene7:
                            neweggImages = this.ImageSetImageList.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                            break;
                        case NeweggImageType.Specialsene7:
                            neweggImages = this.SpecialImageList.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                            break;
                        case NeweggImageType.Normal:
                            neweggImages = this.ImageName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                            break;
                    }
                }

                //if (this.ItemNumber.StartsWith("9SI")) //fixed seller item image issue.
                //{
                //    neweggImages = new List<string>();
                //}
                ////如果ItemNumber是3-4-5格式，则remove掉该Item的newegg images. added by ky54
                //else if (ItemNumberConvert.IsParentItem(this.ItemNumber))
                //{
                //    neweggImages = new List<string>();
                //}

                return neweggImages;
            }
        }

        private ImageSiteInfo additionalSite;
        /// <summary>
        /// AdditionalSite from DFIS.
        /// </summary>
        public ImageSiteInfo AdditionalSite
        {
            get
            {
                if (additionalSite == null)
                {
                    additionalSite = new ImageSiteInfo();
                    additionalSite.SiteUrl = DFISUtility.DFISHost + DFISUtility.DFISFileGroup;
                    additionalSite.LargeImagePath = DFISUtility.FullSizeImagePath + "{0}";
                    additionalSite.MiddleImagePath = DFISUtility.FullSizeImagePath + "{0}";
                    additionalSite.SmallImagePath = DFISUtility.SmallSizeImagePath + "{0}";
                }
                return additionalSite;
            }
        }

        private ImageSiteInfo neweggSite;
        /// <summary>
        /// NeweggSite from normal or sence7.
        /// </summary>
        public ImageSiteInfo NeweggSite
        {
            get
            {
                if (neweggSite == null)
                {
                    neweggSite = new ImageSiteInfo();
                    Scene7 scen7Config = ConfigurationWWWManager<Scene7>.ItemCfg();
                    //determine image type
                    if (this.HasScene7Image == "1" && scen7Config != null && scen7Config.EnableScene7)
                    {
                        neweggSite.ImageType = 1;
                    }
                    else if (!string.IsNullOrWhiteSpace(this.SpecialImageList) && scen7Config != null &&
                             scen7Config.EnableSpecialScene7)
                    {
                        neweggSite.ImageType = 2;
                    }
                    else
                    {
                        neweggSite.ImageType = 0;
                    }

                    neweggSite.SiteUrl = ProductImageBuilder.GetProductImageServerPath(neweggSite.ImageType);
                    if (neweggSite.ImageType != 0)
                    {
                        //scene7 image use "$S60$" to get size image, like:19-198-198-TS.jpg?$S60$
                        neweggSite.LargeImagePath = "{0}?$" + ProductImageBuilder.GetScene7ImageSize(ImageSizeEnum.FullSize, WaterMarkFlag) + "$";
                        neweggSite.MiddleImagePath = "{0}?$" + ProductImageBuilder.GetScene7ImageSize(ImageSizeEnum.FullSize, WaterMarkFlag) + "$";
                        neweggSite.SmallImagePath = "{0}?$" + ProductImageBuilder.GetScene7ImageSize(ImageSizeEnum.Size125, WaterMarkFlag) + "$";
                    }
                    else
                    {
                        //normal image
                        neweggSite.LargeImagePath = ProductImageBuilder.GetImageSite(ImageSizeEnum.FullSize, WaterMarkFlag) + "{0}";
                        neweggSite.MiddleImagePath = ProductImageBuilder.GetImageSite(ImageSizeEnum.Size640, WaterMarkFlag) + "{0}";
                        neweggSite.SmallImagePath = ProductImageBuilder.GetImageSite(ImageSizeEnum.Size125, WaterMarkFlag) + "{0}";
                    }
                }
                return neweggSite;
            }
        }

        /// <summary>
        /// Model.
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// Manufactory.
        /// </summary>
        public string Manufactory { get; set; }

        public string Specification
        {
            get
            {
                if (string.IsNullOrEmpty(m_specification) &&
                        !string.IsNullOrEmpty(this.XmlSpec))
                {
                    int limitRowCount = 10;
                    int rowIndex = 0;
                    StringBuilder builder = new StringBuilder();
                    XmlDocument doc = new XmlDocument();
                    XmlAttribute attr = null;
                    var hasShowMore = false;

                    doc.LoadXml(this.XmlSpec);

                    if (doc.FirstChild.ChildNodes != null)
                    {
                        var model = doc.SelectSingleNode("/LongDescription/Group[*][@GroupName='Model']");
                        var hasModel = doc.SelectSingleNode("/LongDescription/Group[*]/Property[@Key='Model']");
                        var hasBrand = doc.SelectSingleNode("/LongDescription/Group[*]/Property[@Key='Brand']");
                        if (model == null)
                        {
                            var eleModel = doc.CreateElement("Group");
                            eleModel.SetAttribute("GroupName", "Model");
                           
                            XmlElement ele = null;
                            if (!string.IsNullOrEmpty(Manufactory)&&hasBrand==null)
                            {
                                ele = doc.CreateElement("Property");
                                ele.SetAttribute("Key", "Brand");
                                ele.SetAttribute("Value", Manufactory.Trim());
                                eleModel.AppendChild(ele);
                            }
                            if (!string.IsNullOrEmpty(Model)&&hasModel==null)
                            {
                                ele = doc.CreateElement("Property");
                                ele.SetAttribute("Key", "Model");
                                ele.SetAttribute("Value", Model.Trim());
                                eleModel.AppendChild(ele);
                            }
                            if (ele != null)
                            {
                                doc.FirstChild.InsertAfter(eleModel, null);
                            }
                        }
                        else
                        {
                            if (hasModel == null&&!string.IsNullOrEmpty(Model))
                            {
                                var ele = doc.CreateElement("Property");
                                ele.SetAttribute("Key", "Model");
                                ele.SetAttribute("Value", Model.Trim());
                                model.InsertBefore(ele, model.FirstChild);
                            }
                            if (hasBrand == null&&!string.IsNullOrEmpty(Manufactory))
                            {
                                var ele = doc.CreateElement("Property");
                                ele.SetAttribute("Key", "Brand");
                                ele.SetAttribute("Value", Manufactory.Trim());
                                model.InsertBefore(ele, model.FirstChild);
                            }
                        }
                        builder.Append("<ul class=\"specification\">\r\n");
                        foreach (XmlNode group in doc.FirstChild.ChildNodes)
                        {
                            if ((attr = group.Attributes["GroupName"]) != null && !string.IsNullOrEmpty(attr.Value))
                            {
                                if (rowIndex == limitRowCount && !hasShowMore)
                                {
                                    this.SetShowMore(builder);
                                    hasShowMore = true;
                                }
                                builder.AppendFormat("<li class=\"group\" style=\"{1}\">{0}</li>\r\n", attr.Value, rowIndex >= limitRowCount ? "display:none;" : string.Empty);
                            }

                            if (group.ChildNodes != null)
                            {
                                int index = 0;
                                foreach (XmlNode child in group.ChildNodes)
                                {
                                    if (rowIndex == limitRowCount && !hasShowMore)
                                    {
                                        this.SetShowMore(builder);
                                        hasShowMore = true;
                                    }
                                    builder.AppendFormat(
                                        "<li class=\"item\" style=\"{2}\"><table><tr><td class=\"name\">{0}</td><td class=\"value\">{1}</td></tr></table></li>\r\n",
                                        child.Attributes["Key"].Value,
                                        child.Attributes["Value"].Value,
                                        rowIndex >= limitRowCount ? "display:none;" : string.Empty);
                                    index++;
                                    rowIndex++;
                                }
                            }
                        }

                        if (rowIndex >= limitRowCount)
                        {
                            this.SetShowMore(builder, true);
                        }
                        builder.Append("</ul>");
                        m_specification = builder.ToString();
                    }

                    return m_specification;
                }

                return m_specification;
            }
        }

        public string WarrantyContent
        {
            get
            {
                if (string.IsNullOrEmpty(m_warrantyContent))
                {
                    m_warrantyContent = string.Format(Resource.Product.ReturnPoliciesDescription, this.ReturnPolicyUrl, this.WarrantyName);
                }
                return m_warrantyContent;
            }
        }

        public string SellerWarrantyContent
        {
            get
            {
                if (string.IsNullOrEmpty(m_sellerWarrantyContent))
                {
                    m_sellerWarrantyContent = string.Format(Resource.Product.SellerReturnPoliciesDescription,
                                                            this.ReturnPolicyUrl,
                                                            string.Format(Resource.Product.SellerReturnPolicy, this.SellerName));
                }
                return m_sellerWarrantyContent;
            }
        }

        public string ReturnPolicyUrl { get; set; }


        private void SetShowMore(StringBuilder builder, bool isEnd = false)
        {
            if (!isEnd)
            {
                builder.Append("<li id=\"expansion\" name=\"expansion\" class=\"item seemore\"><a href=\"javascript:void(0);\" class=\"more\"><span>See More</span><b class=\"iconArrowDown\"></b></a></li>");
            }
            else
            {
                builder.Append("<li id=\"collapse\" style=\"display:none;\"><a href=\"#specificationContainer\" class=\"more\"><span>See Less</span><b class=\"iconArrowUp\"></b></a></li>");
            }
        }

        /// <summary>
        /// Unit price display on the page, it's formated.
        /// </summary>
        public string DisplayUnitPrice { get; set; }

        /// <summary>
        /// Final price display on the page, it's formated
        /// </summary>
        public string DisplayFinalPrice { get; set; }

        /// <summary>
        /// Get the button text by Flag_Select type;
        /// </summary>
        public string AddToCartButtonText
        {
            get {
                var text = Product.Info_AddToCart;
                if (string.IsNullOrEmpty(this.FlagSelect))
                {
                    return text;
                }

                switch (this.FlagSelect.Trim().ToLower())
                { 
                    case "1":
                    case "3":
                        text = Product.Info_AddToCart_Download;
                        break;
                    case "2":
                        text = Product.Info_AddToCart_GetTheCode;
                        break;
                }

                return text;
            }
        }

        public bool IsDownloadItem
        {
            get
            {
                var result = false;
                if (string.IsNullOrEmpty(this.FlagSelect))
                {
                    return result;
                }

                switch (this.FlagSelect.Trim().ToLower())
                {
                    case "1":
                    case "2":
                    case "3":
                    case "4":
                        result = true;
                        break;
                }

                return result;
            }
        }
    }

    /// <summary>
    /// Image site info.
    /// </summary>
    public class ImageSiteInfo
    {
        /// <summary>
        /// Image Type. 0: normal, 1: scene7, 2: specialScene7
        /// </summary>
        public int ImageType { get; set; }

        /// <summary>
        /// Site Url.
        /// </summary>
        public string SiteUrl { get; set; }

        /// <summary>
        /// Large Image Path.
        /// </summary>
        public string LargeImagePath { get; set; }

        /// <summary>
        /// Middle Image Path.
        /// </summary>
        public string MiddleImagePath { get; set; }

        /// <summary>
        /// Small Image Path.
        /// </summary>
        public string SmallImagePath { get; set; }

        /// <summary>
        /// Get Image Path.
        /// </summary>
        /// <param name="size">0-Large,1-middle,2-Small</param>
        public string ToString(int size)
        {
            Uri uri = new Uri(SiteUrl);
            Uri result = null;

            if (size == 0)
            {
                result = new Uri(uri, LargeImagePath);
            }
            else if (size == 1)
            {
                result = new Uri(uri, MiddleImagePath);
            }
            else
            {
                result = new Uri(uri, SmallImagePath);
            }
            return result.ToString();
        }
    }

}
