﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newegg.EC;

namespace Newegg.Flash.WWW.Model
{
    public class ItemGroup:FlashBaseModel
    {
        private const int CONST_DEFAULT_QUANTITY_TOTAL = 30;
        private List<Item> m_items;
        public List<Item> Items 
        {
            get
            {
                return m_items;
            }
            set
            {
                m_items = value;
                if (m_items.Count == 1)
                {
                    if (m_items[0].Properties != null && m_items[0].Properties.Count > 0)
                    {
                        m_items[0].Properties.Clear();
                    }
                }
                CreateProperties(m_items);
            }
        }

        public List<PropertyGroup> Properties { get; set; }

        public int CurrentItemIndex { get; set; }

        public ItemGroup(List<Item> items)
        {
            Items = items;
            CurrentItemIndex = 0;
        }

        private void CreateProperties(List<Item> items)
        {
            this.Properties = new List<PropertyGroup>();

            foreach (Item item in items)
            {
                if (item.Properties == null)
                {
                    item.Properties = new List<ItemProperty>();
                }

                for (int index = 0; index < CONST_DEFAULT_QUANTITY_TOTAL; index++)
                {
                    item.Properties.Add(new ItemProperty()
                    {
                        PropertyCode = "ItemQuantity",
                        PropertyDescription = "Quantity",
                        ValueCode = (index + 1).ToString(),
                        ValueDescription = (index + 1).ToString(),
                        ValuePriority = 0,
                    });
                }//for index

                foreach (ItemProperty property in item.Properties)
                {
                    PropertyGroup group = GetPropertyGroupByKey(property.PropertyCode);

                    if (group != null)
                    {
                        List<ItemPropertyWithItemNumbers> list = group.Value;
                        bool hasExist = false;
                        foreach (ItemPropertyWithItemNumbers itemProperty in list)
                        {
                            if (itemProperty.ValueCode == property.ValueCode)
                            {
                                hasExist = true;
                                itemProperty.ItemNumbers.Add(item.ItemNumber);
                                break;
                            }
                        }

                        if (!hasExist)
                        {
                            list.Add(new ItemPropertyWithItemNumbers(property)
                            {
                                ItemNumbers = new List<string>() { item.ItemNumber }
                            });
                        }
                    }
                    else
                    {
                        this.Properties.Add(new PropertyGroup()
                        {
                            Key = property.PropertyCode,
                            Value = new List<ItemPropertyWithItemNumbers>() { 
                                    new ItemPropertyWithItemNumbers(property){
                                         ItemNumbers = new List<string>(){item.ItemNumber}
                                    } 
                                }
                        });
                    }
                }//foreach proterty
            }//outer foreach item

            this.Properties.ForEach(p =>
                { p.Value = this.SortValueInfo(p.Value); });


        }

        public PropertyGroup GetPropertyGroupByKey(string key)
        {
            PropertyGroup group = null;
            foreach (PropertyGroup item in this.Properties)
            {
                if (item.Key == key)
                {
                    group = item;
                    break;
                }
            }

            return group;
        }

        protected List<ItemPropertyWithItemNumbers> SortValueInfo(List<ItemPropertyWithItemNumbers> propertyValues)
        {
            int temp;
            if (propertyValues.Count == propertyValues.Count(v => int.TryParse(v.ValueDescription, out temp)))
            {
                return propertyValues.OrderBy(v => v.ValueDescription.Trim().ToFloat()).ToList();
            }
            else
            {
                return propertyValues.OrderBy(v => v.ValuePriority).ThenBy(v => v.ValueDescription).ToList();
            }
        }
    }

    public class ItemPropertyWithItemNumbers : ItemProperty
    {
        public List<string> ItemNumbers { get; set; }

        public ItemPropertyWithItemNumbers():base()
        {
            this.ItemNumbers = new List<string>();
        }

        public ItemPropertyWithItemNumbers(ItemProperty property)
            : this()
        {
            this.PropertyCode = property.PropertyCode;
            this.PropertyDescription = property.PropertyDescription;
            this.ValueCode = property.ValueCode;
            this.ValueDescription = property.ValueDescription;
            this.Priority = property.Priority;
            this.ValuePriority = property.ValuePriority;
        }
    }

    public class PropertyGroup
    {
        public string Key { get; set; }
        public List<ItemPropertyWithItemNumbers> Value { get; set; }

        public PropertyGroup()
        {
            Value = new List<ItemPropertyWithItemNumbers>();
        }
    }
}
