﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  5/2/2013 6:19:04 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/

using System.Collections.Generic;
namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// ReturnPolicyPage model
    /// </summary>
    public class ReturnPolicyPage
    {
        /// <summary>
        /// Item info.
        /// </summary>
        public ItemBase Item { get; set; }

        /// <summary>
        /// Return policy info.
        /// </summary>
        public List<Warranty> Warranties { get; set; }

        /// <summary>
        /// OwnerType - 0 Newegg, 1 Seller
        /// </summary>
        public int OwnerType { get; set; }
    }
}
