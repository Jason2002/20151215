﻿

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Warranty Info model, for return plolicy page.
    /// </summary>
    public class Warranty
    {
        /// <summary>
        /// Gets or sets WarrantyID.
        /// </summary>
        public int WarrantyID { get; set; }

        /// <summary>
        /// Gets or sets WarrantyName.
        /// </summary>
        public string WarrantyName { get; set; }

        /// <summary>
        /// Gets or sets Status.
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets WarrantyTitle.
        /// </summary>
        public string WarrantyTitle { get; set; }

        /// <summary>
        /// Gets or sets WarrantySummary (RMAInstruction).
        /// </summary>
        public string WarrantySummary { get; set; }

        /// <summary>
        /// Gets or sets WarrantyDetail (RMAPolicy).
        /// </summary>
        public string WarrantyDetail { get; set; }

        /// <summary>
        /// Gets or sets RMAProcessedBy.
        /// </summary>
        public string RMAProcessedBy { get; set; }

        /// <summary>
        /// Gets or sets RMARefundDay.
        /// </summary>
        public int RMARefundDay { get; set; }

        /// <summary>
        /// Gets or sets RMAReplacementDay.
        /// </summary>
        public int RMAReplacementDay { get; set; }

        /// <summary>
        /// Gets or sets SubCategoryCode.
        /// </summary>
        public int SubCategoryCode { get; set; }

        /// <summary>
        /// Gets or sets SubCategoryDescription.
        /// </summary>
        public string SubCategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets RestockingFeeRate.
        /// </summary>
        public decimal RestockingFeeRate { get; set; }

        /// <summary>
        /// Gets or sets SellerType 1= intelnational seller.
        /// </summary>
        public int SellerType { get; set; }
    }
}
