﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public partial class Item : ItemBase
    {
        /// <summary>
        /// Gets or sets ShippingCharge.
        /// </summary>
        public decimal ShippingCharge { get; set; }

        /// <summary>
        /// Gets or sets Specification XML.
        /// </summary>
        public string XmlSpec { get; set; }

        /// <summary>
        /// Gets or sets GroupItemCount.
        /// </summary>
        public int GroupItemCount { get; set; }

        /// <summary>
        /// Gets or sets GroupLowestPrice.
        /// </summary>
        public int GroupLowestPrice { get; set; }

        /// <summary>
        /// Gets or sets IsFeaturedMerchants.
        /// </summary>
        public bool IsFeaturedMerchants { get; set; }

        /// <summary>
        /// Gets or sets IntroductionText.
        /// </summary>
        public string OverView { get; set; }

        /// <summary>
        /// Gets or sets ManufactoryWeb.
        /// </summary>
        public string ManufactoryWeb { get; set; }

        /// <summary>
        /// Gets or sets SupportEMail.
        /// </summary>
        public string SupportEMail { get; set; }

        /// <summary>
        /// Gets or sets SupportURL.
        /// </summary>
        public string SupportURL { get; set; }

        /// <summary>
        /// Gets or sets CustomerServicePhone.
        /// </summary>
        public string CustomerServicePhone { get; set; }

        /// <summary>
        /// Gets or sets Is3Party.
        /// </summary>
        public bool Is3Party { get; set; }

        /// <summary>
        /// Gets or sets ServiceProvider.
        /// </summary>
        public string ServiceProvider { get; set; }

        /// <summary>
        /// Gets or sets ProviderSupportEmail.
        /// </summary>
        public string ProviderSupportEmail { get; set; }

        /// <summary>
        /// Gets or sets ProviderSupportURL.
        /// </summary>
        public string ProviderSupportURL { get; set; }

        /// <summary>
        /// Gets or sets ProviderCustomerServicePhone.
        /// </summary>
        public string ProviderCustomerServicePhone { get; set; }

        /// <summary>
        /// Gets or sets WarrantyDayParts.
        /// </summary>
        public int WarrantyDayParts { get; set; }

        /// <summary>
        /// Gets or sets WarrantyDayLabor.
        /// </summary>
        public int WarrantyDayLabor { get; set; }

        /// <summary>
        /// Gets or sets HasManufacturerWarranty.
        /// </summary>
        public bool HasManufacturerWarranty { get; set; }

        /// <summary>
        /// Gets or sets Return policy name.
        /// </summary>
        public string WarrantyName { get; set; }

        /// <summary>
        /// Gets or sets WarrantySummary.
        /// </summary>
        public string WarrantySummary { get; set; }

        /// <summary>
        /// Gets or sets Properties.
        /// </summary>
        public List<ItemProperty> Properties { get; set; }

        /// <summary>
        /// Gets or sets Warnings.
        /// </summary>
        public List<Warning> Warnings { get; set; }

        /// <summary>
        /// Gets or sets Buyer content.
        /// </summary>
        public string BuyerContent { get; set; }

        /// <summary>
        /// Gets or sets HyperLink for Manufacturer's Product Page.
        /// </summary>
        public string ManufacturerHyperlink { get; set; }

        /// <summary>
        /// Gets or sets SellerName
        /// </summary>
        public string SellerName { get; set; }

        /// <summary>
        /// Gets or sets Bullets.
        /// </summary>
        public List<string> Bullets { get; set; }

        /// <summary>
        /// Gets or sets the flagselect.
        /// </summary>
        public string FlagSelect { get; set; }

        /// <summary>
        /// Gets or sets PayPalMessage
        /// </summary>
        public bool EnablePayPalMessage { get; set; }

        /// <summary>
        /// Gets or sets BMLMessage
        /// </summary>
        public bool EnableBMLMessage { get; set; }

        /// <summary>
        /// Gets or sets NPAMessage
        /// </summary>
        public bool EnableNPAMessage { get; set; }

        /// <summary>
        /// Gets or sets is NewEgg Store CreditCard Message
        /// </summary>
        public bool EnableNewEggStoreCreditCardMessage { get; set; }

        /// <summary>
        /// Gets or sets Promotion Text
        /// </summary>
        public string PromotionText { get; set; }

        /// <summary>
        /// Gets or sets Promotion Url
        /// </summary>
        public string PromotionUrl { get; set; }

        /// <summary>
        /// Gets or sets NeweggPromotionInfo
        /// </summary>
        public string NeweggPromotionInfo { get; set; }

        /// <summary>
        /// Gets or sets NeweggPromotionLink
        /// </summary>
        public string NeweggPromotionLink { get; set; }

        /// <summary>
        /// Gets or sets NeweggPromotionLinkOpenType
        /// </summary>
        public string NeweggPromotionLinkOpenType { get; set; } 
    }
}
