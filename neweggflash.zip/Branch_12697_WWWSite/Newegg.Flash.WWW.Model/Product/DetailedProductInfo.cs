using Newegg.EC;
using Newegg.EC.BizUnit;
using System.Collections.Generic;


namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Class DetailedProductInfo
    /// </summary>
	public class DetailedProductInfo
	{
        public string ItemNumber { get; set; }
        public string NeweggItemNumber { get; set; }
        public int SubCategoryId { get; set; }
        public string FlagSelect { get; set; }
        public bool StockForCombo { get; set; }
        public string Active { get; set; }
        public int Checked { get; set; }
        public decimal UnitCost { get; set; }
        public string Model { get; set; }
        public string SubCategoryDescription { get; set; }
        public string WebDescription { get; set; }
        public string CountryCode { get; set; }
        public int CompanyCode { get; set; }
        public decimal GiftCardAmount { get; set; }
        public string ViewState { get; set; }
        public int CaseID { get; set; }
        public string DiscountFromType { get; set; }
        public string ImageName { get; set; }

        public string DisplayUnitPrice { get; set; }

        public string GiftItemImagePath { get; set; }

        public string GiftDetailPageUrl { get; set; }
	}
}
