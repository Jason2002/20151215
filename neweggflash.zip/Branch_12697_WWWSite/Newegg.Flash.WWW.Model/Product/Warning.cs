﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class Warning
    {
        /// <summary>
        /// Gets or sets WaringID.
        /// </summary>
        public int WaringID { get; set; }

        /// <summary>
        /// Gets or sets WaringID.
        /// </summary>
        public string WebTitle { get; set; }

        /// <summary>
        /// Gets or sets WaringID.
        /// </summary>
        public int WarningTypeID { get; set; }

        /// <summary>
        /// Gets or sets WaringID.
        /// </summary>
        public string WebDescription { get; set; }

        /// <summary>
        /// Gets or sets WaringID.
        /// </summary>
        public string SellerPortalDescription { get; set; }

        /// <summary>
        /// Gets or sets WaringID.
        /// </summary>
        public int GroupID { get; set; }
    }
}
