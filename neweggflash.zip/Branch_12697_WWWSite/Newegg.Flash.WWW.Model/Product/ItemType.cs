using System;

namespace Newegg.Flash.WWW.Model
{
    public enum ItemType
    {
        Normal = 0,
        AutoAddMaster = 1,
        AutoAddTransaction = 2
    }
}
