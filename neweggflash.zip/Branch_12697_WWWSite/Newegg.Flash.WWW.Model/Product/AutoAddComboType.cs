
namespace Newegg.Flash.WWW.Model
{
	/// <summary>
	/// AutoAddComboType
	/// </summary>
	public enum AutoAddComboType
	{
		/// <summary>
		/// None
		/// </summary>
		None = -1,

		/// <summary>
		/// NoDiscount
		/// </summary>
		NoDiscount = 0,

		/// <summary>
		/// AllDiscountFromAutoAddItem
		/// </summary>
		AllDiscountFromAutoAddItem = 1,

		/// <summary>
		/// AllDiscountFromPrimaryItem
		/// </summary>
		AllDiscountFromPrimaryItem = 2,

		/// <summary>
		/// FixedDiscountFromAutoAddItem
		/// </summary>
		FixedDiscountFromAutoAddItem = 3,
	}
}
