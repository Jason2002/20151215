using System.Collections.Generic;

namespace Newegg.Flash.WWW.Model
{
	public class AutoAddComboInfo
	{
        public int CaseID { get; set; }

        public string PrimaryItem { get; set; }

        public string StartTime { get; set; }

        public string DiscountFromType { get; set; }

        public string FreeShippingMark { get; set; }

        public decimal FixDiscount { get; set; }

        public string ForceCloseMark { get; set; }

        public AutoAddComboType AutoAddComboType
        {
            get
            {
                switch (DiscountFromType)
                {
                    case "0":
                        return AutoAddComboType.NoDiscount;
                    case "1":
                        return AutoAddComboType.AllDiscountFromAutoAddItem;
                    case "2":
                        return AutoAddComboType.AllDiscountFromPrimaryItem;
                    case "3":
                        return AutoAddComboType.FixedDiscountFromAutoAddItem;
                    default:
                        return AutoAddComboType.None;
                }
            }
        }

        public string GiftCardMark { get; set; }

        public decimal GiftCardAmount { get; set; }

        public List<DetailedProductInfo> AutoAddItemList { get; set; }

        //public string IncludeString
        //{
        //    get
        //    {
        //        if (this.AutoAddComboType == AutoAddComboType.NoDiscount)
        //        {
        //            return Globalization.Product.PurchaseIncludes1;
        //        }
        //        else
        //        {
        //            //foreach (DetailedProductInfo info in this.AutoAddItemList)
        //            //{
        //            //    if (info.Item == itemNumber && (info.ItemType.IsCiscoServiceItem || info.ItemType.IsMicrosoftDownloadItem || info.ItemType.IsStandaloneSNETItem))
        //            //    {
        //            //        return Globalization.Product.Include;
        //            //    }
        //            //}
        //            return Globalization.Product.FreeGift4;
        //        }
        //    }
        //}
	}
}
