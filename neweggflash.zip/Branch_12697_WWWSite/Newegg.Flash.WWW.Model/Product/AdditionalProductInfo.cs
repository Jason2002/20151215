﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class AdditionalProductInfo
    {
        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets MapPrice
        /// </summary>
        public string MapPrice { get; set; }

        /// <summary>
        /// Gets or sets GiftWrapItem
        /// </summary>
        public string GiftWrapItem { get; set; }

        /// <summary>
        /// Gets or sets Active
        /// </summary>
        public string Active { get; set; }

        /// <summary>
        /// Gets or sets HasOpcInventory
        /// </summary>
        public string HasOpcInventory { get; set; }

        /// <summary>
        /// Gets or sets IsHot
        /// </summary>
        public string IsHot { get; set; }

        /// <summary>
        /// Gets or sets Mailrebatedescrip
        /// </summary>
        public string Mailrebatedescrip { get; set; }

        /// <summary>
        /// Gets or sets Mailrebateamount
        /// </summary>
        public string Mailrebateamount { get; set; }

        /// <summary>
        /// Gets or sets InstantRebateAmount
        /// </summary>
        public string InstantRebateAmount { get; set; }

        /// <summary>
        /// Gets or sets item final price.
        /// </summary>
        public decimal FinalPrice { get; set; }

        /// <summary>
        /// Gets or sets SpecialLinkInfoList
        /// </summary>
        public List<SpecialLinkInfo> SpecialLinkInfoList { get; set; }

        /// <summary>
        /// sub category id.
        /// </summary>
        public int SubCategoryId { get; set; }

        /// <summary>
        /// brand id.
        /// </summary>
        public int BrandId { get; set; }

        /// <summary>
        /// seller id.
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// is recertified.
        /// </summary>
        public bool IsRecertified { get; set; }

        /// <summary>
        /// Gets IsPremierItem
        /// </summary>
        public bool IsPremierItem { get; set; }
    }
}
