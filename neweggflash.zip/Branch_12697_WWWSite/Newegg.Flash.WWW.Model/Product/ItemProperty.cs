﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public partial class ItemProperty
    {
        /// <summary>
        /// Gets or sets PropertyCode.
        /// </summary>
        public string PropertyCode { get; set; }

        /// <summary>
        /// Gets or sets PropertyDescription.
        /// </summary>
        public string PropertyDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueCode.
        /// </summary>
        public string ValueCode { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription.
        /// </summary>
        public string ValueDescription { get; set; }

        /// <summary>
        /// Gets or sets Priority.
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// Gets or sets ValuePriority.
        /// </summary>
        public int ValuePriority { get; set; }
    }
}
