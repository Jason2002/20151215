﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    //[Serializable]
    public class SpecialLinkInfo
    {
        #region properties
        /// <summary>
        /// Gets or sets  Name
        /// </summary>
        //[DataMapping("Name", DbType.String)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets  Link
        /// </summary>
        //[DataMapping("Link", DbType.String)]
        public string Link { get; set; }

        /// <summary>
        /// Gets HasSpecialLink
        /// </summary>
        public bool HasSpecialLink { get; set; }

        #endregion
    }
}
