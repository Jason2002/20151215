﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class SearchPage :FlashBaseModel
    {
        public string Keyword { get; set; }
        
        public int Sortby { get; set; }

        public int Category { get; set; }

        public string Within { get; set; }

        public List<ItemBase> Items { get; set; }

        public List<ItemBase> Featured { get; set; }

        public int FeaturedCount { get; set; }

        public int TotalCount { get; set; }

        public List<Subcategory> SubCategoryList { get; set; }

        public List<KeyValuePair<int, string>> SortbyList { get; set; }


    }
}
