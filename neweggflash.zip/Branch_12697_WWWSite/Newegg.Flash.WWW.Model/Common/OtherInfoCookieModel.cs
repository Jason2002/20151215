﻿using Newegg.EC.Cookie;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// NV_OtherInfo cookie Model.Body.
    /// </summary>
    public class OtherInfoCookieModel : FlashCookieBase
    {
        public const string Key = "OtherInfo";
        /// <summary>
        /// Login Name.
        /// </summary>
        private string loginName = string.Empty;

        /// <summary>
        /// Gets or Sets Sortby Field of Search Result Page
        /// </summary>]
        [JsonProperty(CookieConst.SORTBY)]
        public int Sortby { get; set; }

        /// <summary>
        /// Gets or sets login name.
        /// </summary>
        [ECEncryption]
        [JsonProperty(CookieConst.LOGINID6)]
        public string LoginName
        {
            get
            {
                return loginName;
            }

            set
            {
                loginName = value;
                this.LoginID5 = value;
            }
        }

        [JsonProperty(CookieConst.LOGINID5)]
        public string LoginID5 { get; set; }

        /// <summary>
        /// Gets or sets customer number.
        /// </summary>
        [ECEncryption]
        [JsonProperty(CookieConst.LOGINID4)]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets contact with.
        /// </summary>
        [JsonProperty(CookieConst.CONTACTWITH)]
        public string ContactWith { get; set; }

        /// <summary>
        /// Gets or sets customer county.
        /// </summary>
        [JsonProperty(CookieConst.NVS_CUSTOMER_COUNTY)]
        public string CustomerCounty { get; set; }

        /// <summary>
        /// Gets or sets customer shipping state.
        /// </summary>
        [JsonProperty(CookieConst.NVS_CUSTOMER_SHIPPINGSTATE)]
        public string CustomerShippingState { get; set; }

        /// <summary>
        /// Gets or sets customer zip code.
        /// </summary>
        [JsonProperty(CookieConst.NVS_CUSTOMER_ZIP_CODE)]
        public string CustomerZipCode { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether has shipping address.
        /// </summary>
        [JsonProperty(CookieConst.HASSHIPPINGADDRESS)]
        public bool HasShippingAddress { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether has billing address.
        /// </summary>
        [JsonProperty(CookieConst.HASBILLINGADDRESS)]
        public bool HasBillingAddress { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether has credit card.
        /// </summary>
        [JsonProperty(CookieConst.HASCREDITCARD)]
        public bool HasCreditCard { get; set; }

        /// <summary>
        /// Gets a value indicating whether customer login.
        /// </summary>
        [JsonIgnore]
        public bool IsLogin
        {
            get
            {
                bool isLogin = false;
                if (!string.IsNullOrEmpty(this.LoginName) && !string.IsNullOrEmpty(CustomerNumber))
                {
                    string decryptionCustomerNumber = this.LoginID5;
                    if (this.LoginName == decryptionCustomerNumber)
                    {
                        isLogin = true;
                    }
                }

                return isLogin;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether remember this customer.
        /// </summary>
        [JsonProperty(CookieConst.ISREMEMBER)]
        public bool IsRemember { get; set; }

        /// <summary>
        /// Clear has shipping address cookie.
        /// </summary>
        public void ClearAllCookie()
        {
            this.LoginName = null;
            this.LoginID5 = null;
            this.CustomerNumber = null;
            this.ContactWith = null;
            this.CustomerZipCode = null;
            this.CustomerCounty = null;
            this.CustomerShippingState = null;
            this.HasShippingAddress = default(bool);
            this.HasBillingAddress = default(bool);
            this.HasCreditCard = default(bool);
            this.Sortby = 2;
        }

        /// <summary>
        /// Gets or sets validation transaction number.
        /// </summary>
        [ECEncryption]
        [JsonProperty(CookieConst.VALIDTRANNO)]
        public string ValidationTranNum { get; set; }

        /// <summary>
        /// Gets or sets Pronunciation Number.
        /// </summary>
        [ECEncryption]
        [JsonProperty(CookieConst.PRONUNCIATIONNUMBER)]
        public string PronunciationNo { get; set; }

        [JsonProperty(CookieConst.SEARCH_HIS)]
        public List<string> SearchHistory { get; set; }

        [JsonProperty(CookieConst.GatedLaunch)]
        public string GatedLaunch { get; set; }


        [JsonProperty(CookieConst.UserEmail)]
        public string UserEmail { get; set; }

    }
}
