﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class NavgationItem
    {
        private string m_name;
        private string m_url;

        public string Name
        {
            get 
            {
                if (NameArgs != null)
                {
                    return string.Format(this.m_name, NameArgs);
                }

                return m_name;
            }

            set
            {
                m_name = value;
            }
        }

        public string Url 
        {
            get
            {
                if (UrlArgs != null)
                {
                    return string.Format(this.m_url, UrlArgs);
                }

                return m_url;
            }
            set
            {
                m_url = value;
            }
        }
        public object[] UrlArgs { get; set; }
        public object[] NameArgs { get; set; }
    }
}
