﻿using Newtonsoft.Json;

namespace Newegg.Flash.WWW.Model
{
    public class SweepstakesIndicatorCookie : FlashCookieBase
    {
        /// <summary>
        /// Define a cookie name indicate the redirect is for sweepstakes.
        /// </summary>
        public static string Key = "SweepstaksInidicator";

        [JsonProperty(CookieConst.SweepstakesIndicator)]
        public string NFSIC { get; set; }
    }
}
