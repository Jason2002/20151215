﻿using Newegg.EC.Cookie;
using Newtonsoft.Json;
using System.Collections.Generic;


namespace Newegg.Flash.WWW.Model
{
    public class ComInfoCookieModel : FlashCookieBase
    {
        public const string Key = "NFComInfo";

        /// <summary>
        /// Gets or Sets Sortby Field of Search Result Page
        /// </summary>]
        [JsonProperty(CookieConst.SORTBY)]
        public int Sortby { get; set; }

        [JsonProperty(CookieConst.SEARCH_HIS)]
        public List<string> SearchHistory { get; set; }

        [JsonProperty(CookieConst.GatedLaunch)]
        public string GatedLaunch { get; set; }
         
        [JsonProperty(CookieConst.UserEmail)]
        public string UserEmail { get; set; }

        [JsonProperty(CookieConst.SyncCookie)]
        public string SyncCookie { get; set; }

        [JsonProperty(CookieConst.LastRegion)]
        public string LastRegion { get; set; }

        [JsonProperty(CookieConst.LastCurrency)]
        public string LastCurrency { get; set; }
    }
}
