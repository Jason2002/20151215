﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Define cookie const info.
    /// </summary>
    public static class CookieConstDefination
    {
        /// <summary>
        /// Random id.
        /// </summary>
        public const string CUSTOMERINFORANDOMID = "ID";

        /// <summary>
        /// Encrypt customer number.
        /// </summary>
        public const string CUSTOMERINFOENCRYPTCUSTOMERNUMBER = "LOGINID5";

        /// <summary>
        /// Customer number.
        /// </summary>
        public const string CUSTOMERINFOCUSTOMERNUMBER = "LOGINID4";

        /// <summary>
        /// Login name.
        /// </summary>
        public const string CUSTOMERINFOLOGINNAME = "LOGINID6";

        /// <summary>
        /// Contact with.
        /// </summary>
        public const string CUSTOMERINFOCONTACTWITH = "CONTACTWITH";

        /// <summary>
        /// Zip code.
        /// </summary>
        public const string CUSTOMERINFOZIPCODE = "NVS_CUSTOMER_ZIP_CODE";

        /// <summary>
        /// Customer county.
        /// </summary>
        public const string CUSTOMERINFOCOUNTY = "NVS_CUSTOMER_COUNTY";

        /// <summary>
        /// Shipping state.
        /// </summary>
        public const string CUSTOMERINFOSHIPPINGSTATE = "NVS_CUSTOMER_SHIPPINGSTATE";

        /// <summary>
        /// Subscribe newsletter flag.
        /// </summary>
        public const string CUSTOMERINFOSUBSCRIBENEWSLETTERFLAG = "SubscribeNewsletterFlag";

        /// <summary>
        /// Is remember customer.
        /// </summary>
        public const string CUSTOMERINFOISREMEBER = "ISREMEMBER";

        /// <summary>
        /// ORDERCOOKIE for order items.
        /// </summary>
        public const string ORDERITEMS = "ORDERITEMS";

        /// <summary>
        /// NEWEGGCOOKIE for ShippingID.
        /// </summary>
        public const string SHIPPINGID = "SHIPPINGID";

        /// <summary>
        /// NEWEGGCOOKIE for ShippingID.
        /// </summary>
        public const string BILLINGID = "BILLINGID";

        /// <summary>
        /// NEWEGGCOOKIE for ShippingID.
        /// </summary>
        public const string PAYMENTID = "PAYMENTID";

        /// <summary>
        /// NEWEGGCOOKIE for cart shippingMethod.
        /// </summary>
        public const string SHIPPINGMETHOD = "SHIPPINGMETHOD";

        /// <summary>
        /// NEWEGGCOOKIE for cart shippingMethod.
        /// </summary>
        public const string SESSIONID = "SESSIONID";

        /// <summary>
        /// NEWEGGCOOKIE for cart ShippingZipCode.
        /// </summary>
        public const string SHIPPINGZIPCODE = "SHIPPINGZIPCODE";

        /// <summary>
        /// NEWEGGCOOKIE for HasShippingAddress.
        /// </summary>
        public const string HASSHIPPINGADDRESS = "HASSHIPPINGADDRESS";

        /// <summary>
        /// NEWEGGCOOKIE for HasBillingAddress.
        /// </summary>
        public const string HASBILLINGADDRESS = "HASBILLINGADDRESS";

        /// <summary>
        /// NEWEGGCOOKIE for HasBillingAddress.
        /// </summary>
        public const string HASCREDITCARD = "HASCREDITCARD";

        /// <summary>
        /// NEWEGGCOOKIE for mini Item.
        /// </summary>
        public const string MINIITEMS = "MINIITEMS";

        /// <summary>
        /// NEWEGGCOOKIE for mini Summary.
        /// </summary>
        public const string MINISUMMARY = "MINISUMMARY";

        /// <summary>
        /// VALIDTRANNO for validation transaction number.
        /// </summary>
        public const string VALIDATETRANSACTIONNUMBER = "VALIDTRANNO";

        /// <summary>
        /// VALIDTRANNO for validation transaction number.
        /// </summary>
        public const string VALIDATEPRONUNCIATIONNUMBER = "PRONUNCIATIONNUMBER";
    }
}
