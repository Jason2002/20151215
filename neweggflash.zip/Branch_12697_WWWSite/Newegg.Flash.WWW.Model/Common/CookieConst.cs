﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class CookieConst
    {
        public const string CONTACTWITH = "si";
        public const string LOGINID4 = "sc";
        public const string LOGINID5 = "sb";
        public const string LOGINID6 = "sd";
        public const string ISREMEMBER = "sj";
        public const string NVS_CUSTOMER_ZIP_CODE = "se";
        public const string NVS_CUSTOMER_COUNTY = "sf";
        public const string NVS_CUSTOMER_SHIPPINGSTATE = "sg";
        public const string ORDERITEMS = "oi";
        public const string NEWEGGCOOKIE = "sg";
        public const string HASSHIPPINGADDRESS = "hs";
        public const string HASBILLINGADDRESS = "hb";
        public const string HASCREDITCARD = "hc";
        public const string SHIPPINGMETHOD = "sm";
        public const string SESSIONID = "id";
        public const string SHIPPINGZIPCODE = "sz";
        public const string PAYMENTID = "pi";
        public const string MINIITEMS = "mi";
        public const string MINISUMMARY = "ms";
        public const string PRONUNCIATIONNUMBER = "pn";
        public const string VALIDTRANNO = "vt";
        public const string PAYPALEMAIL = "pe";
        public const string PROMOTIONCODE = "pc";
        public const string SORTBY = "st";
        public const string SEARCH_HIS = "sh";
        public const string NFGIFTCARD = "nfgc";

        public const string Quantity = "qty";
        public const string CookieOptions = "opt";
        public const string ItemNumber = "no";
        public const string ImageUrl = "img";
        public const string Title = "title";
        public const string Property = "prt";
        public const string Price = "pri";
        public const string Time = "tim";
        public const string Link = "lk";
        public const string GiftItemQty = "gqty";
        public const string GiftExtendPrice = "gpri";
        public const string PromoGiftItemQty = "pgqty";
        public const string GatedLaunch = "gl";
        public const string UserEmail = "ue";
        public const string SyncCookie = "syn";
        public const string SweepstakesIndicator = "nfsic";
        public const string NeweggCustomerNumber = "s81";
        public const string GlobalRegionCode = "w57";
        public const string GlobalCurrencyCode = "w58";
        public const string LastRegion = "lrn";
        public const string LastCurrency = "lcy";
    }
}
