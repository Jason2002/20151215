﻿using Newegg.Flash.WWW.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class GatedLaunchCookieModel : FlashCookieBase
    { 
        public static string Key
        {
            get
            {
                if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().SwithToNewegg)
                {
                    return "GatedLaunchCOOKIENF";
                }
                return "GatedLaunchCOOKIE";
            }
        }

        public string Content { get; set; }
    }
}
