﻿using System.ComponentModel.DataAnnotations;
using Newegg.Flash.WWW.Globalization;

namespace Newegg.Flash.WWW.Model
{
    public class EmailToFriend:FlashBaseModel
    {
        public string ItemNumber { get; set; }
        public int CustomerNumber { get; set; }
        [Required(ErrorMessageResourceType = typeof(Global), 
                  ErrorMessageResourceName = "Validation_Required")]
        [EmailAddress(ErrorMessageResourceType = typeof(Global), 
                      ErrorMessageResourceName = "Validation_EmailFormat", 
                      ErrorMessage = null)]
        public string CustomerEmailAddress {get;set;}
        [Required(ErrorMessageResourceType = typeof(Global), 
                  ErrorMessageResourceName = "Validation_Required")]
        [RegularExpression(@"^((\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*);?)+$",
                           ErrorMessageResourceName = "Validation_EmailFormat", 
                           ErrorMessage = null,
                           ErrorMessageResourceType = typeof(Global))]
        public string ReceiveEmailAddress { get; set; }
        public string CustomerComment { get; set; }
        public UIEmailItemInfo ItemInfo { get; set; }
        public bool AllowEmailDisplay { get; set; }
        public string ReleateUrl { get; set; }

        public EmailToFriend()
        {
            AllowEmailDisplay = false;
        }
    }

    public class UIEmailItemInfo
    {
        public string ItemLineDescription { get; set; }
        public float UnitPrice { get; set;}
        public float FinalPrice { get; set; }
        public string ImageUrl { get; set; }
    }
}
