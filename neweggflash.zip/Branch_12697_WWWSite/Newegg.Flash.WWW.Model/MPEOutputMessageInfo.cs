﻿namespace Newegg.Flash.WWW.Model
{
    public class MPEOutputMessageInfo
    {
        private int m_MessageCode = 100000;
        private string m_Message = string.Empty;
        private MessageEntityInfo[] m_DetailMessages;

        public int MessageCode
        {
            get
            {
                return m_MessageCode;
            }
            set
            {
                m_MessageCode = value;
            }
        }

        public string Message
        {
            get
            {
                return m_Message;
            }
            set
            {
                m_Message = value;
            }
        }

        public MessageEntityInfo[] DetailMessages
        {
            get
            {
                return this.m_DetailMessages;
            }
            set
            {
                this.m_DetailMessages = value;
            }
        }
    }

    public class MessageEntityInfo
    {
        private int m_MessageCode;
        private MessageDataInfo[] m_MessageDatas;

        internal MessageEntityInfo()
        {
        }

        public MessageEntityInfo(int messageCode)
        {
            this.m_MessageCode = messageCode;
        }

        public int MessageCode
        {
            get
            {
                return this.m_MessageCode;
            }
            set
            {
                this.m_MessageCode = value;
            }
        }

        public MessageDataInfo[] MessageDatas
        {
            get
            {
                return this.m_MessageDatas;
            }
            set
            {
                this.m_MessageDatas = value;
            }
        }
    }

    public class MessageDataInfo
    {
        private string m_Key;
        private object m_Value;

        internal MessageDataInfo()
        {
        }

        public MessageDataInfo(string key, object value)
        {
            this.m_Key = key;
            this.m_Value = value;
        }

        public string Key
        {
            get
            {
                return this.m_Key;
            }
            set
            {
                this.m_Key = value;
            }
        }

        public object Value
        {
            get
            {
                return this.m_Value;
            }
            set
            {
                this.m_Value = value;
            }
        }
    }
}
