﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class AllCampaign : FlashBaseModel
    {
        /// <summary>
        /// Store name or campaign name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Store aliase
        /// </summary>
        public string Aliase { get; set; }

        /// <summary>
        /// Store id or campaign id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Current page item List.
        /// </summary>
        public DealsContainer<Campaign> Items { get; set; }
    }
}
