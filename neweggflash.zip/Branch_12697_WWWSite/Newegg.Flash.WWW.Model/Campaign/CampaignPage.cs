﻿using System;
/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/20/2013 4:40:21 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Campaign page Model.
    /// </summary>
    public class CampaignPage:FlashBaseModel
    {
        /// <summary>
        /// Current Campaign Info.
        /// </summary>
        public Campaign Campaign { get; set; }

        /// <summary>
        /// Current page item List.
        /// </summary>
        public List<ItemBase> Items { get; set; }

        /// <summary>
        /// Subcategory list
        /// </summary>
        public List<Subcategory> SubCategoryList{ get; set; }

        public int TotalCount { get; set; }

        public DateTime CurrentDateTime 
        {
            get
            {
                return Common.CommonUtility.DateTimeNow;  
            }
        }
    }
}
