﻿using System;

namespace Newegg.Flash.WWW.Model
{
    public class Subcategory
    {
        public int ID { get; set; }

        public string Name { get; set; }
    }
}
