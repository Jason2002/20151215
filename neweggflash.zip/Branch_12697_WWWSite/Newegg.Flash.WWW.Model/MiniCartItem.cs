﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Item Entity for Minicart request.
    /// </summary>
    public class MiniCartItem : ItemBase
    {
        /// <summary>
        /// Url Link.
        /// </summary>
        public string DealUrlPath { get; set; }
    }
}
