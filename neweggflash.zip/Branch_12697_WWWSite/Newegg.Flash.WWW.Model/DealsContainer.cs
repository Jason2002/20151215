﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class DealsContainer<T> where T:new()
    {
        public List<T> Items { get; set; }
        public int TotalCount { get; set; }
    }
}
