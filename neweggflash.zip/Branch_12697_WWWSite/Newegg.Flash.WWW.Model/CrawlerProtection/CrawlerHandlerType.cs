
namespace Newegg.Flash.WWW.Model
{
	public enum CrawlerHandlerType
	{
        Forbidden = 0,
        Captcha = 1,
        DummyPrice = 2,
        EncryptedPrice = 3,
        Pass = 99
	}
}
