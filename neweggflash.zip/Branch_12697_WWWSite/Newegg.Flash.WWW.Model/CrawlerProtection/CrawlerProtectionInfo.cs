
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Model
{
    public class CrawlerProtectionInfo
	{
        public bool IsProtectedResponse { get; set; }

        public bool IsBypassVarnish { get; set; }

        public CrawlerHandlerType HandlerType { get; set; }
    }
}
