﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class Sweepstake
    {
        public string SweepstakeName { set; get; }

        /// <summary>
        /// A stands for [Active]; D stands for [Deactive]; 
        /// </summary>
        public string Status { set; get; }

        public string Description { set; get; }

        public string LinkedURL { set; get; }

        public string ImageURL { set; get; }
        /// <summary>
        /// sweepstake 生效日期
        /// </summary>
        public DateTime StartDate { set; get; }
        /// <summary>
        /// sweepstake 失效日期
        /// </summary>
        public DateTime ExpiredDate { set; get; }
    }
}
