﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class FeaturedPage : FlashBaseModel
    {
        public int TotalCount { get; set; }

        public List<ItemBase> Items { get; set; }


        public List<Subcategory> SubCategoryList { get; set; }

        public List<KeyValuePair<int, string>> SortbyList { get; set; }

        public int Sortby { get; set; }

        public int Category { get; set; }
    }
}
