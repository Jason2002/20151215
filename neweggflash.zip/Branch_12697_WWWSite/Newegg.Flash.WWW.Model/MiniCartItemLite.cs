﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class MiniCartItemLite
    {
        /// <summary>
        /// Gets or sets ItemNumber.
        /// </summary>
        public string ItemNumber { get; set; }

        /// <summary>
        /// Product Title.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Final Price.
        /// </summary>
        public decimal FinalPrice { get; set; }

        /// <summary>
        /// Url Link.
        /// </summary>
        public string DealUrlPath { get; set; }

        /// <summary>
        /// Get expire time total milliseconds.
        /// </summary>
        public long ExpireTotalMilliseconds { get; set; }

        /// <summary>
        /// Get Image path.
        /// </summary>
        public string ImageSrc { get; set; }
    }
}
