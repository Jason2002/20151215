﻿using System.Collections.Generic;
using Newegg.EC.Cookie;
using Newtonsoft.Json;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Model
{
    // Summary:
    //     ItemAttribute
    public enum UIItemAttribute
    {
        // Summary:
        //     None
        None = 0,
        //
        // Summary:
        //     SingleItem
        SingleItem = 1,
        //
        // Summary:
        //     NormalComboPrimaryItem
        NormalComboPrimaryItem = 2,
        //
        // Summary:
        //     NormalComboPriceGift
        NormalComboPriceGift = 3,
        //
        // Summary:
        //     NormalComboZeroPriceGift
        NormalComboZeroPriceGift = 4,
        //
        // Summary:
        //     AutoAddComboPrimaryItem
        AutoAddComboPrimaryItem = 5,
        //
        // Summary:
        //     AutoAddComboItem
        AutoAddComboItem = 6,
        //
        // Summary:
        //     PromotionCodeGift
        PromotionCodeGift = 7,
        //
        // Summary:
        //     CellPhonePlanItem
        CellPhonePlanItem = 8,
        //
        // Summary:
        //     CellPhonePhoneItem
        CellPhonePhoneItem = 9,
        //
        // Summary:
        //     CellPhoneSIMCard
        CellPhoneSIMCard = 10,
        //
        // Summary:
        //     CellPhoneAccessoryItem
        CellPhoneAccessoryItem = 11,
    }

    /// <summary>
    /// Mini Car View Model.
    /// </summary>
    public class MiniCarViewModel : FlashCookieBase
    {
        public class MiniCarItemModel
        {
            [JsonProperty(CookieConst.ItemNumber)]
            public string PrimaryItemNumber { get; set; }

            [JsonProperty(CookieConst.Quantity)]
            public int ItemQty { get; set; }

            [JsonProperty(CookieConst.ImageUrl)]
            public string ImageUrl { get; set; }

            [JsonProperty(CookieConst.Title)]
            public string Title { get; set; }

            /// <summary>
            /// 总的销售价
            /// </summary>
            [JsonProperty(CookieConst.Price)]
            public string ExtendPrice { get; set; }

            [JsonProperty(CookieConst.Time)]
            public string EndTime { get; set; }

            [JsonProperty(CookieConst.Link)]
            public string ItemLink { get; set; }

            public UIItemAttribute ItemAttribute { get; set; }

            [JsonProperty(CookieConst.GiftItemQty)]
            public int GiftItemQty { get; set; }

            [JsonProperty(CookieConst.GiftExtendPrice)]
            public string GiftExtendPrice { get; set; }

            [JsonProperty(CookieConst.PromoGiftItemQty)]
            public int PromoGiftItemQty { get; set; }
        }

        /// <summary>
        /// For mini cart.
        /// </summary>
        //public static readonly string Key = "NeweggMiniCart"; 
        public static string Key
        {
            get
            {
                if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().SwithToNewegg)
                { 
                    return "FlashMiniCart";
                } 
                return "NeweggMiniCart";
            }
        }

        public MiniCarViewModel()
        {
            ItemList = new List<MiniCarItemModel>(); 
        }

        /// <summary>
        /// Shopping Car List.
        /// </summary>
        public List<MiniCarItemModel> ItemList { get; set; }

        /// <summary>
        /// Total Item Qty.
        /// </summary>
        [JsonProperty(CookieConst.Quantity)]
        public int TotalItemQty { get; set; }

        /// <summary>
        /// Sub Total Price.
        /// </summary>
        public string SubTotal { get; set; }
    }

    public class ShoppingInfoCookieModel : FlashCookieBase
    {
        public static string Key = "NeweggCOOKIE";

        public class ItemInfoCookieModel
        {
            public string ItemNumber { get; set; }

            public int Qty { get; set; }
        }

        public class ShippingMethodCookieModel
        {
            [ECEncryption]
            public string SellerID { get; set; }

            public int OrderItemType { get; set; }

            public bool IsMaunalMethod { get; set; }

            public bool IsEggSaverOrder { get; set; }

            [ECEncryption]
            public string DefaultShippingMethod { get; set; }
        }

        public List<ItemInfoCookieModel> ItemInfos { get; set; }

        public List<ShippingMethodCookieModel> ShippingMethodInfos { get; set; }

        public string ZipCode { get; set; }

        [ECEncryption]
        [JsonProperty(CookieConst.SESSIONID)]
        public string SessionID { get; set; }

        [ECEncryption]
        [JsonProperty(CookieConst.PAYMENTID)]
        public string PaymentID { get; set; }

        [ECEncryption]
        [JsonProperty(CookieConst.PAYPALEMAIL)]
        public string PaypalEmail { get; set; }

        [JsonProperty(CookieConst.PROMOTIONCODE)]
        public List<string> PromotionCodeList { get; set; }

        [JsonProperty(CookieConst.NFGIFTCARD)]
        public List<string> GiftCardList { get; set; }
    }
}

