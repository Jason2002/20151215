﻿namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// New Message for flash detail Msg.
    /// </summary>
    /// <typeparam name="T1">Body for Value.</typeparam>
    /// <typeparam name="T2">Biz Message.</typeparam>
    public class MessageExtension<T1, T2> : Message<T1>
    {
        public MessageExtension() { }
        public MessageExtension(string code, string description, T1 body, T2 msg)
        {
            this.Code = code;
            this.Description = description;
            this.Body = body;
            this.MessageInfo = msg;
        }

        public T2 MessageInfo { get; set; }
    }
}
