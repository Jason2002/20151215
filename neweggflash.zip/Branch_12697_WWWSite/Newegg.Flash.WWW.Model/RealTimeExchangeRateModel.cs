﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Newegg.Flash.WWW.Model
{
    public class RealTimeExchangeRateModel{

        
        public String itemNumber { get; set; }
        public String countryCode { get; set; }
        public int companyCode { get; set; }
        public double? exchangeRate { get; set; }
    }
}
