﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class ItemImage
    {
        public string ImageSize125 { get; set; }

        public string ImageSize300 { get; set; }

        public string ImageSize640 { get; set; }

        public string ImageSize1280 { get; set; }
    }
}
