﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public enum SourceType
    {
        Image = 0,
        Flash = 1,
        IFrame = 2,
        HtmlCode = 3
    }

    /// <summary>
    /// description a href link,example:
    ///   <a href="{Href}" 
    ///      title="{Title}" 
    ///      target="{Target}" 
    ///      alt="{Alt}" 
    ///      style="{Style};width:{Width}px;height:{Height};" 
    ///      class="{CssClass}" 
    ///      onclick="{ClickEventScript}" >
    ///     {Source}
    ///    </a>
    /// </summary>
    public partial class Banner 
    {
        /// <summary>Gets or sets Banner id.</summary>
        public int BannerId { get; set; }

        /// <summary>Gets or sets Title.</summary>
        public string Title { get; set; }

        /// <summary>Gets or sets Title link.</summary>
        public string Href { get; set; }

        /// <summary>Gets or sets Type of the banner.</summary>
        public SourceType SourceType { get; set; }

        /// <summary>Gets or sets Banner on click. </summary>
        public string ClickEventScript { get; set; }

        /// <summary>Gets or sets Banner width. </summary>
        public int Width { get; set; }

        /// <summary>Gets or sets Banner height. </summary>
        public int Height { get; set; }

        /// <summary>Gets or sets Banner target. </summary>
        public string Target { get; set; }

        /// <summary>Gets or sets Banner code. </summary>
        public string Source { get; set; }

        /// <summary>Gets or sets Banner priority. </summary>
        public int Priority { get; set; }

        /// <summary>Gets or sets Banner alt text. </summary>
        public string Alt { get; set; }

        /// <summary>
        /// background img
        /// </summary>
        public string Background
        {
            get
            {
                if (string.IsNullOrEmpty(Source))
                    return string.Empty;
                var index = Source.LastIndexOf("/");
                var left = Source.Substring(0, index + 1);
                var right = Source.Substring(index + 1, Source.Length - index - 1);
                return string.Format("{0}bg_{1}", left, right);
            }
        }
    }
}
