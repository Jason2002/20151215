﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/17/2013 1:09:08 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Homepage Model.
    /// </summary>
    public partial class HomePage : FlashBaseModel
    {
        /// <summary>
        /// Banners for homepage.
        /// </summary>
        public DealsContainer<Banner> Banners { get; set; }

        /// <summary>
        /// All deals include item & Camgaign.
        /// </summary>
        public DealsContainer<Deal> TodayBestDeals { get; set; }

        /// <summary>
        /// Upcomming deals.
        /// </summary>
        public DealsContainer<Deal> UpcomingDeals { get; set; }

        /// <summary>
        /// Top banner.
        /// </summary>
        public Banner TopBanner { get; set; }

        /// <summary>
        /// Promotion banner
        /// </summary>
        public Banner PromoBanner { get; set; }

        /// <summary>
        /// In the spotlight.
        /// </summary>
        public DealsContainer<Deal> InTheSpotlight { get; set; }

        /// <summary>
        /// Feature store.
        /// </summary>
        public DealsContainer<Deal> FeaturedStore { get; set; }

        /// <summary>
        /// The newegg flash store.
        /// </summary>
        public DealsContainer<Store> Store { get; set; }

        /// <summary>
        /// Special Store
        /// </summary>
        public DealsContainer<Deal> SpecialStore { get; set; }

        public List<Deal> Deals { get; set; }
    }
}
