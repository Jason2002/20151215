﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/11/2013 4:57:24 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Campaign Model Class.
    /// </summary>
    public partial class Campaign : FlashBaseModel
    {
        /// <summary>
        /// Gets or sets Campaign Id.
        /// </summary>
        public int CampaignId { get; set; }

        /// <summary>
        /// Gets or sets Campaign Name.
        /// </summary>
        public string CampaignName { get; set; }

        /// <summary>
        /// Gets or sets Campaign Description.
        /// </summary>
        public string CampaignDescription { get; set; }

        /// <summary>
        /// Gets or sets Campaign Image Name.
        /// </summary>
        public string ImageName { get; set; }

        /// <summary>
        /// Gets or sets Campaign Start Time.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Gets or sets Campaign Expire Time.
        /// </summary>
        public DateTime ExpireTime { get; set; }

        /// <summary>
        /// Gets or sets IsNeedLogin.
        /// </summary>
        public bool IsNeedLogin { get; set; }

        /// <summary>
        /// Gets or sets Campaign Image Name.
        /// </summary>
        public string ImageUrl300 { get; set; }

        /// <summary>
        /// Gets or sets Campaign Image Name.
        /// </summary>
        public string ImageUrl640 { get; set; }

        /// <summary>
        /// Gets or sets Campaign Image Name.
        /// </summary>
        public string ImageUrl240 { get; set; }

        /// <summary>
        /// Gets or sets Navigation
        /// </summary>
        public BreadCrumbsNavigation Navigation { get; set; }
    }
}
