﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public class Store:FlashBaseModel
    {
        /// <summary>
        /// Store id.
        /// </summary>
        public int StoreId { get; set; }

        /// <summary>
        /// Selected sub category
        /// </summary>
        public int SubCategoryId { get; set; }

        /// <summary>
        /// Page aliase.
        /// </summary>
        public string PageAliase { get; set; }

        /// <summary>
        /// Store name.
        /// </summary>
        public string StoreName { get; set; }

        /// <summary>
        /// Hot sales.
        /// </summary>
        public DealsContainer<Deal> FeaturedSales { get; set; }

        /// <summary>
        /// Sub category.
        /// </summary>
        public DealsContainer<Subcategory> SubCategories { get; set; }
    }
}
