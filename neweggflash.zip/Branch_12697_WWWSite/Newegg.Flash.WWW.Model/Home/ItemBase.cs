﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/17/2013 5:44:47 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Model
{
    public partial class ItemBase : FlashBaseModel
    {
        private string description;
        private string webDescription;

        /// <summary>
        /// Gets or sets TranNumber.
        /// </summary>
        public int TranNumber { get; set; }

        /// <summary>
        /// Gets or sets CampaignId.
        /// </summary>
        public int CampaignId { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber.
        /// </summary>
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets ItemNumber of Newegg format.
        /// </summary>
        public string NeweggItemNumber
        {
            get { return ItemNumberConvert.ItemNumber2NeweggItemNumber(this.ItemNumber); }
        }

        /// <summary>
        /// Gets or sets Parent ItemNumber.
        /// </summary>
        public string ParentItem { get; set; }

        /// <summary>
        /// Gets or sets ItemGroupID.
        /// </summary>
        public int ItemGroupID { get; set; }

        /// <summary>
        /// Gets or sets SellerID.
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// Product Title.
        /// </summary>
        public string Description 
        {
            get { return GetProductTitleBase(description, OEMMark); }
            set { description = value; }
        }
        
        /// <summary>
        /// Web description.
        /// </summary>
        public string WebDescription 
        {
            get { return GetProductTitleBase(webDescription, OEMMark); }
            set { webDescription = value; }
        }

        /// <summary>
        /// Unit Price.
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Final Price.
        /// </summary>
        public decimal FinalPrice { get; set; }

        /// <summary>
        /// Discount Instant.
        /// </summary>
        public decimal DiscountInstant { get; set; }

        /// <summary>
        /// Unit Price.
        /// </summary>
        public decimal SourceUnitPrice { get; set; }

        /// <summary>
        /// Final Price.
        /// </summary>
        public decimal SourceFinalPrice { get; set; }

        /// <summary>
        /// Discount Instant.
        /// </summary>
        public decimal SourceDiscountInstant { get; set; }

        /// <summary>
        /// Start Time.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Expire Time.
        /// </summary>
        public DateTime ExpireTime { get; set; }

        /// <summary>
        /// Discount Mark for discount icon display.
        /// </summary>
        public bool DiscountMark { get; set; }

        /// <summary>
        /// Gets or sets SpecialImage from EC_NFItemAdditionalInfo.
        /// </summary>
        public string SpecialImage { get; set; }

        /// <summary>
        /// Gets or sets WaterMarkFlag.
        /// </summary>
        public string WaterMarkFlag { get; set; }

        /// <summary>
        /// Gets or sets ShowOEMRetail.
        /// </summary>
        public string ShowOEMRetail { get; set; }

        /// <summary>
        /// Gets or sets HasScene7Image. 0- no, 1 has
        /// </summary>
        public string HasScene7Image { get; set; }

        /// <summary>
        /// Gets or sets ImageName.
        /// </summary>
        public string ImageName { get; set; }

        /// <summary>
        /// Gets or sets SpecialImageList.
        /// </summary>
        public string SpecialImageList { get; set; }

        /// <summary>
        /// Gets or sets ThumbnailSetName.
        /// </summary>
        public string ThumbnailSetName { get; set; }

        /// <summary>
        /// Gets or sets DiscountInstant.
        /// </summary>
        public string ImageSetName { get; set; }

        /// <summary>
        /// Gets or sets SpinSetName.
        /// </summary>
        public string SpinSetName { get; set; }

        /// <summary>
        /// Gets or sets ThumbnailSetImageList.
        /// </summary>
        public string ThumbnailSetImageList { get; set; }

        /// <summary>
        /// Gets or sets ImageSetImageList.
        /// </summary>
        public string ImageSetImageList { get; set; }

        /// <summary>
        /// Gets or sets SpinSetImageList.
        /// </summary>
        public string SpinSetImageList { get; set; }

        /// <summary>
        /// Gets or sets VendorSetImageList.
        /// </summary>
        public string VendorSetImageList { get; set; }

        /// <summary>
        /// Inventory Qty.
        /// </summary>
        public int Qty { get; set; }

        /// <summary>
        /// Gets or sets priority. 
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// Gets or sets Active. 
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// Gets or sets WebsiteBlockMark. 
        /// </summary>
        public int WebsiteBlockMark { get; set; }

        /// <summary>
        /// Gets or sets CampaignName.
        /// </summary>
        public string CampaignName { get; set; }

        /// <summary>
        /// Gets or sets OEMMark
        /// </summary>
        public bool OEMMark { get; set; }

        /// <summary>
        /// Gets or sets SubcategoryName
        /// </summary>
        public string SubcategoryName { get; set; }

        /// <summary>
        /// Gets or sets IsNeedLogin.
        /// </summary>
        public bool IsNeedLogin { get; set; }

        /// <summary>
        /// Gets or sets Image Path for normal.
        /// </summary>
        public List<ItemImage> Images { get; set; }

        /// <summary>
        /// Gets or sets the AutoAddInfo
        /// </summary>
        public AutoAddComboInfo AutoAddInfo { get; set; }

        /// <summary>
        /// Gets or sets AutoAddItemType.
        /// </summary>
        public ItemType AutoAddItemType { get; set; }

        /// <summary>
        /// Gets or sets Navigation
        /// </summary>
        public BreadCrumbsNavigation Navigation { get; set; }
    }
}
