﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// 数据实体，用于Header上的Store信息
    /// </summary>
    public class HeaderContent
    {
        public List<HeaderStore> HeaderStores { get; set; }

        public HeaderContent()
        {
            this.HeaderStores = new List<HeaderStore>();
        }
    }

    public class HeaderStore
    {
        public string PageAliase { get; set; }

        public string StoreName { get; set; }

        /// <summary>
        /// StoreId 1.ELECTRONICS 2.FOR HOME 3.FOR YOU
        /// </summary>
        public int StoreId { get; set; }

        /// <summary>
        /// Hot sales.
        /// </summary>
        public DealsContainer<HeaderSale> HotSales { get; set; }

        /// <summary>
        /// Sub category.
        /// </summary>
        public DealsContainer<Subcategory> SubCategories { get; set; }
    }

    public class HeaderSale
    {
        public string ItemNumber { get; set; }

        public string Description { get; set; }

        public string Title { get; set; }

        public string ImageSrc { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal FinalPrice { get; set; }
    }
}
