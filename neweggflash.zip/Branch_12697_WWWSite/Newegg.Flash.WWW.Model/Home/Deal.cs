﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/17/2013 1:20:10 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{

    /// <summary>
    /// 
    /// </summary>
    public partial class Deal : FlashBaseModel
    {
        /// <summary>
        /// Priority for display sort.
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// Image size: 0- small, 1-big.
        /// </summary>
        public int ImageSize { get; set; }

        /// <summary>
        /// Item Type: 0- Campaign, 1- item.
        /// </summary>
        public int ItemType { get; set; }

        /// <summary>
        /// Item info.
        /// </summary>
        public ItemBase Item { get; set; }

        /// <summary>
        /// Campaign info.
        /// </summary>
        public Campaign Campaign { get; set; }

        /// <summary>
        /// Gets or sets Deal Start Time.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Gets or sets Deal Expire Time.
        /// </summary>
        public DateTime ExpireTime { get; set; }

        /// <summary>
        /// Gets or sets the deal url path.
        /// </summary>
        public string DealUrlPath { get; set; }

        /// <summary>
        /// Gets or sets IsNeedLogin.
        /// </summary>
        public bool IsNeedLogin { get; set; }

        /// <summary>
        /// Gets or sets Last Item.
        /// </summary>
        public bool LastItem { get; set; }
    }
}
