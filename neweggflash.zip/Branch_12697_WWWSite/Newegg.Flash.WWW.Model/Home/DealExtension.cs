﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public partial class Deal
    {
        public string ItemPartialType { get; set; }

        public Deal()
        {
            ItemPartialType = "default";
        }

        public DateTime CurrentDateTime
        {
            get
            {
                return Common.CommonUtility.DateTimeNow;
            }
        }

        public int TotalCount { get; set; }
    }
}
