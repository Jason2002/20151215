﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public partial class Banner
    {
        public string Content
        {
            get
            {
                StringBuilder content = new StringBuilder();

                if (this.SourceType == Model.SourceType.Image)
                {
                    content.AppendFormat(@"<img src=""{0}"" title=""{1}"" alt=""{2}"" />", this.Source, System.Web.HttpUtility.HtmlEncode(Title), System.Web.HttpUtility.HtmlEncode(Alt));
                }
                else if (this.SourceType == Model.SourceType.IFrame)
                {
                    content.AppendFormat(@"<iframe src=""{0}"" ></iframe>", this.Source);
                }
                else if (this.SourceType == Model.SourceType.Flash)
                {
                    content.AppendFormat(@"<embed src=""{0}"" wmode=""transparent"" type=""application/x-shockwave-flash"">", this.Source);
                }
                else if (this.SourceType == Model.SourceType.HtmlCode)
                {
                    content.Append(this.Source);
                }

                return content.ToString();
            }
        }
    }
}
