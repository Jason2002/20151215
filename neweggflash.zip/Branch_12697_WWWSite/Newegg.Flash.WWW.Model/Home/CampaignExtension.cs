﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.Model
{
    public partial class Campaign
    {
        public long ExpireTicks
        {
            get
            {
                return (this.ExpireTime - Common.CommonUtility.DateTimeNow).Ticks;
            }
        }

        public string ImageSrc
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(this.ImageName))
                {
                    //if (this.ImageSize == 0)
                    //{
                    //    return this.ImageUrl300;
                    //}
                    //else
                    //{
                    //    return this.ImageUrl640;
                    //}
                    return this.ImageUrl640;
                }
                return string.Empty;

                //if (!string.IsNullOrWhiteSpace(this.ImageName))
                //{
                //    var imageUrl = DFISUtility.GetCampaignImageUrl(ImageSize == 0 ? ImageSizeEnum.Size300 : ImageSizeEnum.Size640);
                //    return imageUrl + this.ImageName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0];
                //}
                //return string.Empty;
            }
        }

        public string BigImageSrc
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(this.ImageName))
                {
                    return this.ImageUrl640;
                }
                return string.Empty;

                //if (!string.IsNullOrWhiteSpace(this.ImageName))
                //{
                //    var imageUrl = DFISUtility.GetCampaignImageUrl(ImageSizeEnum.Size640);
                //    return imageUrl + this.ImageName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0];
                //}
                //return string.Empty;
            }
        }


        /// <summary>
        /// Image size: 0-small, 1- big.
        /// </summary>
        public int ImageSize { get; set; }
    }
}
