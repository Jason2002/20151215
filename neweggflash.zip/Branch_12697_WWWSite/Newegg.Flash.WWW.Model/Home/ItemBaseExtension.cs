﻿using System;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Globalization;

namespace Newegg.Flash.WWW.Model
{
    public partial class ItemBase
    {
        public long ExpireTicks
        {
            get
            {
                return (this.ExpireTime - Common.CommonUtility.DateTimeNow).Ticks;
            }
        }

        //public string ImageSrc
        //{
        //    get
        //    {
        //        Scene7 scen7Config = ConfigurationWWWManager<Scene7>.ItemCfg();
        //        if (!string.IsNullOrWhiteSpace(this.SpecialImage))
        //        {
        //            var imageUrl = DFISUtility.GetItemImageUrl(ImageSize == 0 ? ImageSizeEnum.Size300 : ImageSizeEnum.Size640) + "{0}";
        //            return string.Format(imageUrl, this.SpecialImage.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0]);
        //        }
        //        else if (this.HasScene7Image == "1" && scen7Config != null && scen7Config.EnableScene7)
        //        {
        //            if (string.IsNullOrWhiteSpace(this.ThumbnailSetName))
        //            {
        //                return ProductImageBuilder.GetScene7DefaultImage();
        //            }
        //            string imageUrl = ProductImageBuilder.GetProductImageServerPath(1) + "{0}?$" +
        //                              ProductImageBuilder.GetScene7ImageSize(ImageSize == 0 ? ImageSizeEnum.Size300 : ImageSizeEnum.Size640, WaterMarkFlag) + "$";
        //            return string.Format(imageUrl, this.ThumbnailSetName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0]);
        //        }
        //        else if (!string.IsNullOrWhiteSpace(this.SpecialImageList) && scen7Config != null &&
        //                 scen7Config.EnableSpecialScene7)
        //        {
        //            string imageUrl = ProductImageBuilder.GetProductImageServerPath(2) + "{0}?$" +
        //                              ProductImageBuilder.GetScene7ImageSize(ImageSize == 0 ? ImageSizeEnum.Size300 : ImageSizeEnum.Size640, WaterMarkFlag) + "$";
        //            return string.Format(imageUrl, this.SpecialImageList.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0]);
        //        }
        //        else
        //        {
        //            string imageUrl = ProductImageBuilder.GetProductImageServerPath(0) +
        //                              ProductImageBuilder.GetImageSite(ImageSize == 0 ? ImageSizeEnum.Size300 : ImageSizeEnum.Size640, WaterMarkFlag) + "{0}";
        //            if (string.IsNullOrWhiteSpace(this.ImageName))
        //            {
        //                return string.Format(imageUrl, ProductImageBuilder.GetDefaultImage(ImageSize));
        //            }
        //            return string.Format(imageUrl, this.ImageName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0]);
        //        }
        //    }
        //}

        public string ImageSrc
        {
            get
            {
                if (this.Images != null
                    && this.Images.Count > 0)
                {
                    //if (this.ImageSize == 0)
                    //{
                    //    return this.Images[0].ImageSize300;
                    //}
                    //else
                    //{
                    //    return this.Images[0].ImageSize640;
                    //}
                    return this.Images[0].ImageSize640;
                }
                return string.Empty;
            }
        }

        public int AlmostQuanty
        {
            get
            {
                return ConfigurationWWWManager<BizUI>.ItemCfg() == null ? 0 : ConfigurationWWWManager<BizUI>.ItemCfg().AlmostGoneQty;
            }
        }

        public decimal DiscountPercent
        {
            get
            {
                return decimal.Round(this.UnitPrice > 0 ? this.DiscountInstant / this.UnitPrice * 100 : 0,0);
            }
        }

        public string MarkTitle
        {
            get
            {
                string content = string.Empty;
                if (this.Qty <= 0)
                {
                    content = Layout.Item_Soldout;
                }
                else if (this.Qty <= this.AlmostQuanty)
                {
                    content = Layout.Item_Almost;
                }
                else if (this.DiscountMark && this.DiscountPercent > 0)
                {
                    content = string.Format("{0:0}", this.DiscountPercent);
                }

                return content;
            }
        }

        public string OffPercentage
        {
            get
            {
                string content = string.Empty;
                string value = string.Format("{0:0}%", this.DiscountPercent);
                if (value != "0%")
                {
                    content = value;
                }

                return content;
            }
        }

        public DateTime CurrentDateTime
        {
            get
            {
                return  Common.CommonUtility.DateTimeNow;
            }
        }

        /// <summary>
        /// Image size: 0-small, 1- big.
        /// </summary>
        public int ImageSize { get; set; }


        public const string SUFFIX_OEM_RETAIL_TEXT = " - ";
        /// <summary>
        /// get product title base function
        /// </summary>
        /// <param name="description">product description</param>
        /// <param name="showOEMMark"></param>
        /// <returns></returns>
        private static string GetProductTitleBase(string description, bool showOEMMark)
        {
            string tempProductTitle = string.Empty;
            if (!string.IsNullOrWhiteSpace(description))
            {
                string suffixOemText = SUFFIX_OEM_RETAIL_TEXT + Product.OEM;
                tempProductTitle = description;

                if (showOEMMark)
                {
                    if (!description.ToUpper().EndsWith(suffixOemText.ToUpper()))
                    {

                        tempProductTitle = description + suffixOemText;
                    }
                }
                else
                {
                    tempProductTitle = RemoveRetailDescription(description);
                }
            }
            return tempProductTitle;
        }

        private static string RemoveRetailDescription(string description)
        {
            if (string.IsNullOrEmpty(description))
            {
                return string.Empty;
            }
            string suffixRetailText = Product.Retail.ToUpper();
            if (description.Trim().ToUpper().EndsWith(suffixRetailText))
            {
                description = description.Substring(0, description.Trim().Length - suffixRetailText.Length);

                if (!string.IsNullOrEmpty(description) && description.Trim().EndsWith("-"))
                {
                    description = description.Substring(0, description.Trim().Length - 1);
                }
            }
            return description;
        }
    }
}
