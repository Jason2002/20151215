﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// EggPoint ServiceModel from service.
    /// </summary>
    public class EggPointServiceModel
    {
        /// <summary>
        /// Gets or sets ItemNumber.
        /// </summary>
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ComboId.
        /// </summary>
        public int ComboId { get; set; }

        /// <summary>
        /// Gets or sets Rate.
        /// </summary>
        public decimal GetPointRate { get; set; }

        /// <summary>
        /// Gets or sets FixedReviewPoints.
        /// </summary>
        public decimal FixedPoints { get; set; }
    }
}
