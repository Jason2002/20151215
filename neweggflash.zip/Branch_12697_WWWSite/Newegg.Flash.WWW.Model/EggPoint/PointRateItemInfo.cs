﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// ItemRate Request.
    /// </summary>
    public class PointRateItemInfo
    {
        /// <summary>
        /// Gets or sets ItemNumber.
        /// </summary>
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets SubCategoryId .
        /// </summary>
        public int SubCategoryId { get; set; }

        /// <summary>
        /// Gets or sets BrandId.
        /// </summary>
        public int BrandId { get; set; }

        /// <summary>
        /// Gets or sets SellerId.
        /// </summary>
        public string SellerId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsRecertified .
        /// </summary>
        public bool IsRecertified { get; set; }
    }
}
