﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  4/17/2013 9:05:16 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Upcoming Sales Model.
    /// </summary>
    public partial class UpcomingSales : FlashBaseModel
    {
        /// <summary>
        /// Deals info List, group by date.
        /// </summary>
        public Dictionary<DateTime, List<Deal>> Deals { get; set; }
    }
}
