﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Error Code Mapping.
    /// </summary>
    public class ErrorCode : FlashBaseModel
    {
        /// <summary>
        /// No Error.
        /// </summary>
        public const string NoError = "000";

        /// <summary>
        /// Service invoke Error.
        /// </summary>
        public const string Error = "222";

        /// <summary>
        /// Server Logic Error.
        /// </summary>
        public const string LogicError = "111";

        /// <summary>
        /// Has prompt.
        /// </summary>
        public const string HasPrompt = "999";
    }

    /// <summary>
    /// Message T class.
    /// </summary>
    /// <typeparam name="T">Container type.</typeparam>
    public class Message<T> : FlashBaseModel
    {
        /// <summary>
        /// Initializes a new instance of the Message class.
        /// </summary>
        public Message()
            : this(string.Empty, string.Empty, default(T))
        {
        }

        /// <summary>
        /// Initializes a new instance of the Message class.
        /// </summary>
        /// <param name="body">Body object.</param>
        public Message(T body)
            : this(string.Empty, string.Empty, body)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Message class.
        /// </summary>
        /// <param name="code">Code number.</param>
        /// <param name="description">Description message.</param>
        public Message(string code, string description)
            : this(code, description, default(T))
        {
        }

        /// <summary>
        /// Initializes a new instance of the Message class.
        /// </summary>
        /// <param name="code">Code number.</param>
        /// <param name="description">Description message.</param>
        /// <param name="body">Body object.</param>
        public Message(string code, string description, T body)
        {
            this.Code = code;
            this.Description = description;
            this.Body = body;
        }

        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Body.
        /// </summary>
        public T Body { get; set; }

        /// <summary>
        /// Gets a value indicating whether HasError.
        /// </summary>
        public bool HasError
        {
            get
            {
                return ErrorCode.Error.Equals(this.Code, StringComparison.InvariantCultureIgnoreCase)
                    || ErrorCode.LogicError.Equals(this.Code, StringComparison.InvariantCultureIgnoreCase)
                    || this.Body == null;
            }
        }

        /// <summary>
        /// Gets a value indicating whether HasPrompt.
        /// </summary>
        public bool HasPrompt
        {
            get
            {
                return ErrorCode.HasPrompt.Equals(this.Code, StringComparison.InvariantCultureIgnoreCase);
            }
        }

        /// <summary>
        /// Gets a value indicating whether HasSuccess.
        /// </summary>
        public bool HasSuccess
        {
            get
            {
                return ErrorCode.NoError.Equals(this.Code, StringComparison.InvariantCultureIgnoreCase);
            }
        }
    }

    public class Message : Message<object>
    {
        public Message()
            : base()
        {
        }

        public Message(object body)
            : base(body)
        {
        }

        public Message(string code, string description)
            : base(code, description)
        {
        }

        public Message(string code, string description, object body)
            : base(code, description, body)
        {
        }
    }
}
