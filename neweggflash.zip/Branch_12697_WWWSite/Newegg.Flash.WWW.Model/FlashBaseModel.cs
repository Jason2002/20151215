﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.EC.Web.Mvc;

namespace Newegg.Flash.WWW.Model
{
    public class FlashBaseModel : ECBaseViewModel
    {
        private List<string> m_headerBars;
        public FlashBaseModel()
        {
            m_headerBars = new List<string>();
        }

        /// <summary>
        /// Display Header bars list
        /// </summary>
        public List<string> HeaderBars
        {
            get
            {
                return m_headerBars;
            }
            set
            {
                m_headerBars = value;
            }
        }

        public List<NavgationItem> Navgations { get; set; }

        public Footer Footer { get; set; }
    }

    public class Footer
    {
        public string Name { get; set; }

        public object Model { get; set; }
    }
}
