﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// 通用性Deals集合，用于Featured Store,NeweggFlash Store,改版完成后，Featured Deals也会使用该实体
    /// </summary>
    public class GeneralDeals:FlashBaseModel
    {
        public int Sortby { get; set; }

        /// <summary>
        /// Selected sub category
        /// </summary>
        public int SubCategoryId { get; set; }

        public bool SelectCategoryIsHiden { get; set; }

        /// <summary>
        /// Page aliase.
        /// </summary>
        public string PageAliase { get; set; }

        /// <summary>
        /// Store id.
        /// </summary>
        public int StoreId { get; set; }

        /// <summary>
        /// Store name.
        /// </summary>
        public string StoreName { get; set; }

        /// <summary>
        /// 每个Deals
        /// </summary>
        public List<Deal> Deals { get; set; }

        /// <summary>
        /// 整个Deals数量，含分页外的内容。
        /// </summary>
        public int TotalCount { get; set; }

        /// <summary>
        /// 扩展性统计字段，具体使用场景根据具体的页面来确定。
        /// </summary>
        public int Extend1TotalCount { get; set; }

        /// <summary>
        /// 当前Deals中包含哪些category
        /// </summary>
        public List<Subcategory> SubCategoryList { get; set; }

        /// <summary>
        /// 排序规则
        /// </summary>
        public List<KeyValuePair<int, string>> SortbyList { get; set; }
    }
}
