﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.Model
{
    /// <summary>
    /// Ajax result wrapper.
    /// </summary>
    /// <typeparam name="T">Biz object.</typeparam>
    public class UIAjaxResultModel<T>
    {
        /// <summary>
        /// Initializes a new instance of the UIAjaxResultModel class.
        /// </summary>
        public UIAjaxResultModel()
        {
            this.ErrorMessageForHtml = "Unknow Error.";
            this.Model = default(T);
            this.UserState = null;
            this.HasSuccess = false;
        }

        /// <summary>
        /// Gets or sets a value indicating error message.
        /// </summary>
        public string ErrorMessageForHtml { get; set; }

        /// <summary>
        /// Gets or sets a value indicating entity.
        /// </summary>
        public T Model { get; set; }

        /// <summary>
        /// Gets or sets a value indicating custom state.
        /// </summary>
        public object UserState { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether hasSuccess.
        /// </summary>
        public bool HasSuccess { get; set; }
    }
}