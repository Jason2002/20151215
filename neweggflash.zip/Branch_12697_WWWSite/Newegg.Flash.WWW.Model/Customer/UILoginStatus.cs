﻿using System;

namespace Newegg.Flash.WWW.Model
{
	/// <summary>
	/// 
	/// </summary>
	public enum UILoginStatus
	{
		Failure = 0,
		Success = 1
	}
}