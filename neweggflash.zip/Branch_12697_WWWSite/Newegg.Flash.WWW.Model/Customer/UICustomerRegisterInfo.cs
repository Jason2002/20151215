﻿using System;
using System.ComponentModel.DataAnnotations;

using Newegg.Flash.WWW.Globalization;

namespace Newegg.Flash.WWW.Model
{
    public partial class UICustomerRegisterInfo : FlashBaseModel
    {
        [Required(ErrorMessageResourceType = typeof(Global), ErrorMessageResourceName = "Warning_Required")]
        [EmailAddress(ErrorMessageResourceType = typeof(Login), ErrorMessageResourceName = "Warning_Email", ErrorMessage = null)]
        public string LoginName { get; set; }
		[Required(ErrorMessageResourceType = typeof(Global), ErrorMessageResourceName = "Warning_Required")]
        [StringLength(30, MinimumLength = 6, ErrorMessageResourceType = typeof(Login), ErrorMessageResourceName = "Warning_PasswordMinLength", ErrorMessage = null)]
        public string Password { get; set; }

        /// <summary>
        /// B2CCustomer = 0,
		/// B2BPrimary = 1,
		/// B2BUser = 2,
		/// B2BRestrictedUser = 3
        /// </summary>
        public int AccountType { get; set; }

        public bool AllowNewsLetter { get; set; }
    }
}
