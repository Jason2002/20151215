﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newegg.Flash.WWW.Globalization;

namespace Newegg.Flash.WWW.Model
{
    public partial class UILoginInfoViewModel : FlashBaseModel
    {
        [Required(ErrorMessageResourceType = typeof(Global), ErrorMessageResourceName = "Warning_Required")]
        [EmailAddress(ErrorMessageResourceType = typeof(Login), ErrorMessageResourceName = "Warning_Email", ErrorMessage = null)]
        public string LoginUser  { get; set; }
		[Required(ErrorMessageResourceType = typeof(Global), ErrorMessageResourceName = "Warning_Required")]
        public string LoginPwd   { get; set; }
        public bool RememberMe { get; set; }

        public UILoginInfoViewModel()
        {
            RememberMe = true;
        }
    }
}
