﻿using System;

namespace Newegg.Flash.WWW.Model
{
    public partial class UICustomerInfo : FlashBaseModel
    {
        public int CustomerNumber { get; set; }
        public string Name { get; set; }
        public string LoginName { get; set; }
        public string ZipCode { get; set; }
        public string AuthToken { get; set; }
        public bool IsNewOrRepeat { get; set; }
    }
}