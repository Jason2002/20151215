﻿using System;

namespace Newegg.Flash.WWW.Model
{
    public partial class UILoginInputInfo : FlashBaseModel
    {
        public string LoginName { get; set; }

        public string Password { get; set; }

		public string ReferenceURL { get; set; }

		public bool NeedCheckCapcha { get; set; }

		public int TransactionNumber { get; set; }

		public string ValidateCode { get; set; }

    }
}
