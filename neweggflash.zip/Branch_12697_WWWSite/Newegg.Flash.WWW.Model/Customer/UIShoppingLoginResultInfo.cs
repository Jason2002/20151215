﻿using System;

namespace Newegg.Flash.WWW.Model
{
    public class UIShoppingLoginResultInfo : UILoginResultInfo
    {
        public bool HasShippingAddress { get; set; }

        public bool HasBillingAddress { get; set; }

        public bool HasCreditCard { get; set; }

        public bool IsNPAAvailable { get; set; }
    }
}
