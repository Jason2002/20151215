﻿using System;

namespace Newegg.Flash.WWW.Model
{
    public partial class UILoginResultInfo : FlashBaseModel
    {
        public UICustomerInfo Customer { get; set; }
        public UILoginStatus LoginStatus { get; set; }
		public string ErrorMessage { get; set; }
    }
}