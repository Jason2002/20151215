﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Model
{
    public partial class UILoginViewModel : FlashBaseModel
    {
        public UILoginInfoViewModel LoginInfo { get; set; }
        public UICustomerRegisterInfo RegisterInfo { get; set; }

        public UILoginViewModel()
        {
            LoginInfo    = new UILoginInfoViewModel();
            RegisterInfo = new UICustomerRegisterInfo();
        }

        public bool IsPaypalCheckout { get; set; }

        public string RedirectUrl { get; set; }

        public bool IsShoppingLogin { get; set; }

		public string ValidationMark { get; set; }
    }

	public enum ValidateCodeType
	{
		ExpireAndCheck = 0,
		ExpireAndNoCheck = 1,
		NeedCheck = 2,
		NoNeedCheck = 3,
		UserChange = 4
	}
}
