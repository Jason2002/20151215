﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.Model
{
    public class CountryCurrencyDetail
    {
        public string CountryCode { get; set; }
        public int CompanyCode { get; set; }
        public string CurrencyCode { get; set; }
        public string IsDefault { get; set; }

        public bool IsLocalCurrency
        {
            get { return !string.IsNullOrWhiteSpace(IsDefault) && IsDefault.Equals("Y"); }
            set { IsDefault = value ? "Y" : "N"; }
        }
        public bool SupportDecimal { get; set; }
        public string CurrencyName { get; set; }
        public string ExtraUnit { get; set; }
        public string Symbol { get; set; }
        public int DecimalDigits { get; set; }
        public string DecimalSeparator { get; set; }
        public int GroupSizes { get; set; }
        public string GroupSeparator { get; set; }
        public int PositivePattern { get; set; }
        public int ListPriority { get; set; }
        public string Status { get; set; }
    }
}