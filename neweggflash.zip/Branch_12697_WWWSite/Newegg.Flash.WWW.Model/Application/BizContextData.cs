﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.Model
{
    public class BizContext
    {
        public List<CurrencyExchangeRate> CurrencyExchangeRates { get; set; }

        public List<CountryCurrencyDetail> CountryCurrencyDetails { get; set; }
    }
}