﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.Model
{
    public class CurrencyExchangeRate
    {
        public string FromCurrencyCode { get; set; }

        public string ToCurrencyCode { get; set; }

        public decimal ExchangeRate { get; set; }
    }
}