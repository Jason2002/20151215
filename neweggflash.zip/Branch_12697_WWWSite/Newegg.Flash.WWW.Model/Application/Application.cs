﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  5/21/2013 3:51:19 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
namespace Newegg.Flash.WWW.Model
{
    public class Application
    {
        /// <summary>
        /// Serve Name.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Database is Ok.
        /// </summary>
        public bool DatabaseIsOk { get; set; }
    }
}
