﻿using System.Collections.Generic;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface
{
    public interface IProduct
    {
        List<Item> Get(string itemNumber, bool isUpcoming, bool isRequestFromNeweggCentral, bool isGift);

        ReturnPolicyPage GetReturnPolicy(string itemNumber, bool isGift);

        List<AdditionalProductInfo> GetAdditionalProductInfo(string itemNumbers, string type);

        /// <summary>
        /// 获取实时对美元汇率
        /// </summary>
        /// <returns></returns>
        IEnumerable<RealTimeExchangeRateModel> GetRealtimeExchangeRate(string itemNumbers, string countryCode,
            int companyCode, string currencyCode);

    }
}
