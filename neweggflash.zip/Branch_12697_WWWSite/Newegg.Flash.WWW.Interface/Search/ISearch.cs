﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface.Search
{
    public interface ISearch
    {
        SearchPage Get(string keyword, int sortby,int category,string within);

        KeyValuePair<int, List<ItemBase>> Paging(string keyword, int sortby, string within, int pageIndex, int pageSize, int category);

        List<string> GetSuggestKeywords(string userInput, int sugguestCount);
    }
}
