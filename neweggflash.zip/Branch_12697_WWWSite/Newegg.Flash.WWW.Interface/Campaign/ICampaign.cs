﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Interface
{
    public interface ICampaign
    {
        CampaignPage Get(int campaignID);
        KeyValuePair<int, List<ItemBase>> Paging(int campaignID, int pageIndex, int pageSize, int sort, int categoryID);
    }
}
