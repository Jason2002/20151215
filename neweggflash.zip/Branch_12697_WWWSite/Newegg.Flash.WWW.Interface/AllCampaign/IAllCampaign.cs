﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Interface
{
    public interface IAllCampaign
    {
        /// <summary>
        /// Get all campaign deals by storeid
        /// </summary>
        /// <param name="storeId"></param>
        /// <returns></returns>
        GeneralDeals Get(int storeId, int pageIndex = 1, int pageSize = 20, int sort = 1);
    }
}
