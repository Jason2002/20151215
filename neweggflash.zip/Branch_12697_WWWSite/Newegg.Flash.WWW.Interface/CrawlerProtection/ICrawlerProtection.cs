﻿using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Interface
{
    public interface ICrawlerProtection
    {
        CrawlerProtectionInfo LoadProtectionInfo(string ip, string utma);
    }
}
