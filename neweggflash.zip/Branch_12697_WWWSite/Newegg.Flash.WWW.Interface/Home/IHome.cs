﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface
{
    public interface IHome
    {
        /// <summary>
        /// Home page
        /// </summary>
        /// <returns></returns>
        HomePage Get();

        /// <summary>
        /// Subscribe
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="subscriptStatus"></param>
        /// <returns></returns>
        bool Subscribe(string loginName, bool subscriptStatus=true);

        /// <summary>
        /// Get Today's homepage
        /// </summary>
        /// <param name="upcomingDays">Max days for upcoming deals, default value is 3.</param>
        /// <returns></returns>
        HomePage Get(int upcomingDays = 3, int bannerCount = 5, int featuredDealsCount = 5, int featuredStoreCount = 5, int upcomingCount = 5);

        BizContext BizContextData();
    }
}
