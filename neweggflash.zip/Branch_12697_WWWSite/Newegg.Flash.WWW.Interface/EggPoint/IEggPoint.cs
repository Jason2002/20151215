﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface
{
    public interface IEggPoint
    {
        List<EggPointServiceModel> GetEggPoint(List<PointRateItemInfo> items);
    }
}
