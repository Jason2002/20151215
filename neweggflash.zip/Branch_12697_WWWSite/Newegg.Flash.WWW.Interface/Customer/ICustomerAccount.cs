﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface.Customer
{
    /// <summary>
    /// Customer Account Interface Defination.
    /// </summary>
    public interface ICustomerAccount
    {
        /// <summary>
        /// Customer login.
        /// </summary>
        /// <param name="userName">The user login name,always email address.</param>
        /// <param name="password">The user's password.</param>
        /// <param name="pageName"> Page name.</param>
        /// <param name="checkCapcha">Whether check capcha.</param>
        /// <param name="transactionNumber">Validation code transaction number.</param>
        /// <param name="validateCode">Validate code.</param>
        /// <returns> The login result.</returns>
        Task<IRestfulResponse<MessageExtension<UILoginResultInfo, MPEOutputMessageInfo>>> Login(string userName, string password, string pageName, bool checkCapcha, int transactionNumber, string validateCode);

        /// <summary>
        /// Quick register a new customer.
        /// </summary>
        /// <param name="registerInfo">The register info entity.</param>
        /// <returns>UI Login Result Info.</returns>
        Task<IRestfulResponse<MessageExtension<UILoginResultInfo, MPEOutputMessageInfo>>> QuickRegister(UICustomerRegisterInfo registerInfo);

        /// <summary>
        /// Shopping login.
        /// </summary>
        /// <param name="userName">The user login name,always email address.</param>
        /// <param name="password">The user's password.</param>
        /// <param name="pageName"> Page name.</param>
        /// <param name="checkCapcha">Whether check Captcha.</param>
        /// <param name="transactionNumber">Validation code transaction number.</param>
        /// <param name="validateCode">Validate code.</param>
        /// <returns>UI Shopping Login Result Info.</returns>
        Task<IRestfulResponse<MessageExtension<UIShoppingLoginResultInfo, MPEOutputMessageInfo>>> ShoppingLogin(string userName, string password, string pageName, bool checkCapcha, int transactionNumber, string validateCode);
    }
}
