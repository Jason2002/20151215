﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface.Search
{
    public interface IFeatured
    {
        FeaturedPage Get(int category,int sortby);

        KeyValuePair<int, List<ItemBase>> Paging(int pageIndex, int pageSize, int category,int sortby);
    }
}
