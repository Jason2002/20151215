﻿using System.Collections.Generic;
using Newegg.Flash.WWW.Model;


namespace Newegg.Flash.WWW.Interface
{
    public interface ISweepstake
    {
        /// <summary>
        /// get active sweepstake for today by country
        /// </summary>
        /// <param name="countryCode"></param>
        /// <returns></returns>
        Sweepstake Get(string countryCode);
    }
}
