﻿using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface
{
    public interface IUpcoming
    {
        UpcomingSales Get(int dayCount = 3, int dealCount = 4);
    }
}
