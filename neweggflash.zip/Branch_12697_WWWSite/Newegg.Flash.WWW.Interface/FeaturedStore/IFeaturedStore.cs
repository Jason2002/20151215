﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Interface
{
    public interface IFeaturedStore
    {
        /// <summary>
        /// 获取Featured Store数据，含分页
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        GeneralDeals Get(int pageIndex = 1, int pageSize = 20);
    }
}
