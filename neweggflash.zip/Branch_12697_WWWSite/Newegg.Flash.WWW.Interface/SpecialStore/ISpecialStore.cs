﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.Interface.SpecialStore
{
    public interface ISpecialStore
    {
        /// <summary>
        /// Get Special Store Data.
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        GeneralDeals Get(int pageIndex = 1, int pageSize = 20);
    }
}
