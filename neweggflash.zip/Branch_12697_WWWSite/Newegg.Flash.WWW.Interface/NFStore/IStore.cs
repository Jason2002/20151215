﻿using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Interface
{
    public interface IStore
    {
        /// <summary>
        /// 获取Header上面的数据，包括n个Store，每个Store中包括7个category和5个featured sales.
        /// </summary>
        /// <remarks>每一个Header上有Sore信息的页面，都需要调用这个服务。</remarks>
        /// <returns></returns>
        HeaderContent GetHeaderContent(int categoryCount = 7, int featuredSalesCount = 5);

        /// <summary>
        /// Get Deals By NeweggFlash Store.
        /// </summary>
        /// <param name="storeId"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="category"></param>
        /// <param name="sortby"></param>
        /// <returns></returns>
        GeneralDeals GetStoreDeals(int storeId = 1, int pageIndex = 1, int pageSize = 20, int category = 0, int sortby = 0);


        string GetStoreProperty(int id, string suffix = "");
    }
}
