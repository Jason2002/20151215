﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Interface.MiniCart
{
    public interface IMiniCart
    {
        /// <summary>
        /// minicart更新时，获取数据
        /// </summary>
        /// <param name="itemNumbers">需要更新的itemnumber列表</param>
        /// <returns></returns>
        List<MiniCartItem> GetMiniCartItemInfo(string itemNumbers);
    }
}
