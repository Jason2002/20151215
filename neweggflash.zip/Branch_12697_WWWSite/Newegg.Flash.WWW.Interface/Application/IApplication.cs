﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  5/21/2013 3:50:07 PM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
namespace Newegg.Flash.WWW.Interface
{
    public interface IApplication
    {
        Model.Application Get();
    }
}
