﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using Newegg.EC;
using Newegg.EC.BizUnit;
using Newegg.EC.Log;
using Newegg.EC.Web;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.Filters;
using WebUtility = Newegg.Framework.Web.WebUtility;
using System.Text.RegularExpressions;
using Newegg.Flash.WWW.UI.UICommon;

namespace Newegg.Flash.WWW.UI
{
    /// <summary>
    /// Global class.
    /// </summary>
    public class MvcApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// Web application manager.
        /// </summary>
        private Lazy<IWebAppManager> webAppManager = new Lazy<IWebAppManager>(() => ECLibraryContainer.Current.GetInstance<IWebAppManager>());

        /// <summary>
        /// varnish http request header
        /// </summary>
        private const string X_FROM_VARNISH_KEY = "X-From-Cache";

        /// <summary>
        /// Application start event.
        /// </summary>
        protected void Application_Start()
        {
            if (this.webAppManager.Value != null)
            {
                this.webAppManager.Value.Start();
            }
            
            GlobalFilters.Filters.Add(new FlashCookieFilterAttribute() { NoCookie = false });

            /*********
             * Remove X-AspNetMvc-Version http header for security issue.
             *********/
            MvcHandler.DisableMvcResponseHeader = true;
        }

        /// <summary>
        /// End request event.
        /// </summary>
        /// <param name="sender">Object sender.</param>
        /// <param name="e">EventArgs e.</param>
        protected void Application_EndRequest(object sender, EventArgs e)
        {
            //varnish logic
            ExecuteVarnishBypassLogic();
        }

        /// <summary>
        /// Application error event.
        /// </summary>
        /// <param name="sender">Object sender.</param>
        /// <param name="e">EventsArgs e.</param>
        protected void Application_Error(object sender, EventArgs e)
        {
            /*Do not hanlder exception in local development.
            if (Request.IsLocal)
            {
                return;
            }*/
     
            var error = Server.GetLastError();
            var httpException = error as HttpException;
            var statusCode = 0;
            if (httpException != null)
            {
                statusCode = httpException.GetHttpCode();
            }
            else
            {
                statusCode = HttpStatusCode.InternalServerError.ToInt();
            }
            var host ="~/oops?code={0}";

            Regex globalRegex = new Regex(@"/global/(\w{1,3})", RegexOptions.IgnoreCase);
            MatchCollection globalMatches = globalRegex.Matches(Request.RawUrl);
            if (globalMatches != null
                    && globalMatches.Count > 0
                    && globalMatches[0].Groups.Count > 1
                    )
            {
                // request url contains global site key words 
                string displayShortCode = globalMatches[0].Groups[1].Value;
                host = "~/global/" + displayShortCode + "/oops?code={0}";
            } 

            var redirectURL = string.Format(host, statusCode);
            if (statusCode != 404)
            {
                var log = ECLibraryContainer.Current.GetInstance<ILogger>();
                if (log != null)
                {
                    try
                    {
                        log.Exception = error;
                        log.AddCategory("Newegg.Flash");
                        log.AddMessage("HttpServer Error.");
                        log.Write();
                    }
                    catch
                    {
                        //if request validate is enabled,it will throw exception in the log component.
                    }
                } 
            }

            if (Request.QueryString["cc"] != null && "t".Equals(Request.QueryString["cc"].ToLower()))
            {
                //region code change and destination url 404
                var path = Request.Url.PathAndQuery.ToLower();
                if (Request.Url.PathAndQuery.ToLower().Contains("/global/"))
                {
                    var index = path.IndexOf("/global/");
                    redirectURL = Utility.WebHostWithScheme() + "/global/" + path.Substring(index + 8, 2);
                }
                else
                {
                    redirectURL = Utility.WebHostWithScheme();
                }
            }

            Response.Clear();
            Server.ClearError();

            /*Render the error handling controller without a redirect.*/
            Response.Redirect(redirectURL);
        }

        private void ExecuteVarnishBypassLogic()
        {
            Varnish entity = ConfigurationWWWManager<Varnish>.ItemCfg();
            BrowserInfo browserInfo = BrowserInfoParser.Parse(HttpContext.Current.Request.UserAgent);
            if (entity != null && entity.EnableVarnish
                && HttpContext.Current.Request.Headers[X_FROM_VARNISH_KEY] != null
                && HttpContext.Current.Request.Headers[X_FROM_VARNISH_KEY].Equals(entity.FromVarnishValue, StringComparison.OrdinalIgnoreCase))
            {
                //First Step:Check Url Bypass Logic
                //if url has these string,it will send 'Bypass'
                if (entity.ByPass.ByPassPages != null && entity.ByPass.ByPassPages.Pages != null)
                {
                    if (entity.ByPass.ByPassPages.Pages.Exists(v =>
                    {
                        return HttpContext.Current.Request.Url.AbsoluteUri.IndexOf(v, StringComparison.OrdinalIgnoreCase) != -1;
                    }))
                    {
                        Response.AddHeader(entity.ToVarnishKey, entity.ByPass.ByPassValue);
                        return;
                    }
                }

                //Second Step:Check Device Bypass Logic
                if (entity.ByPass != null && entity.ByPass.ByPassDevices != null
                    && entity.ByPass.ByPassDevices.Devices != null)
                {
                    if (entity.ByPass.ByPassDevices.Devices.Exists(v =>
                    {
                        return HttpContext.Current.Request.UserAgent.IndexOf(v, StringComparison.OrdinalIgnoreCase) != -1;
                    }))
                    {
                        Response.AddHeader(entity.ToVarnishKey, entity.ByPass.ByPassValue);
                        return;
                    }
                }

                //Third Step:Check Browser Logic
                if (entity.ByPass != null && entity.ByPass.CheckAgents != null && entity.ByPass.CheckAgents.Agents != null)
                {
                    if (!entity.ByPass.CheckAgents.Agents.Exists(v =>
                    {
                        return string.Equals(browserInfo.BrowserApplication.ToString(), v, StringComparison.OrdinalIgnoreCase);
                    }))
                    {
                        Response.AddHeader(entity.ToVarnishKey, entity.ByPass.ByPassValue);
                        return;
                    }
                }
                //Fourth Step:Check Level Logic
                if (entity.Levelpages != null && entity.Levelpages != null)
                {
                    var levelPage = entity.Levelpages.Find(v =>
                    {
                        return (HttpContext.Current.Request.Url.AbsolutePath == "/" && v.Url.Equals("HomePage", StringComparison.OrdinalIgnoreCase)) ||
                            HttpContext.Current.Request.Url.AbsoluteUri.IndexOf(v.Url, StringComparison.OrdinalIgnoreCase) != -1;
                    });
                    if (levelPage != null)
                    {
                        Response.AddHeader(entity.ToVarnishKey, levelPage.Value);
                        return;
                    }
                }

                Response.AddHeader(entity.ToVarnishKey, entity.ByPass.ByPassValue);
            }
        }
    }
}
