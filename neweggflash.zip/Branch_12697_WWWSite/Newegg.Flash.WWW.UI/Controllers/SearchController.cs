﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.EC;
using Newegg.EC.Cookie;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Implement;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Interface.Search;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using Newegg.EC.NeweggComCookie;
using Newegg.Flash.WWW.UI.Filters;

namespace Newegg.Flash.WWW.UI.Controllers
{

    [RegionChangeFilterAttribute(RedirectKey = "cc", RedirectValue = "t")]
    public class SearchController : FlashController
    {
        private const int MAX_LENGTH = 250;

        private BizUI BizUIConfig
        {
            get
            {
                return ConfigurationWWWManager<BizUI>.ItemCfg();
            }
        }

        protected ISearch SearchProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<ISearch>();
            }
        }

        [HttpGet]
        [SiteCatalyst(typeof(SearchPageProcessor))]
        [Tealium(typeof(TealiumSearchProcessor))]
        [CrawlerDetection]
        public ActionResult Index(string keyword, string within="",int category=0, int sortby=-1)
        {
            if (string.IsNullOrEmpty(keyword))
            {
                return this.RedirectToAction("Index", "Home");
            }
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();

            ViewBag.FeaturedDeals = Globalization.Layout.Headline_FeaturedDeals;
            //if (bizUI != null && bizUI.HeadlineConfig != null && !string.IsNullOrEmpty(bizUI.HeadlineConfig.FeaturedDeals))
            //{
            //    ViewBag.FeaturedDeals = bizUI.HeadlineConfig.FeaturedDeals;
            //}

            var decodeKeyword = string.Join("",HttpUtility.UrlDecode(keyword).Take(MAX_LENGTH));
            var decodeWithin = string.Join("", HttpUtility.UrlDecode(within).Take(MAX_LENGTH));

            if (bizUI.TranslatorSetting != null
                && (BizThreadContext.RegionCode.Code.Equals("CHN") || BizThreadContext.RegionCode.Code.Equals("TWN")))
            {
                decodeKeyword = GetTranslatedKeyWord(decodeKeyword, bizUI.TranslatorSetting);
                decodeWithin = GetTranslatedKeyWord(decodeWithin, bizUI.TranslatorSetting);
            }

            #region -- 保存搜索历史到Cookie中 --
            if (this.CurrentLoginUser.SearchHistory == null)
            {
                this.CurrentLoginUser.SearchHistory = new List<string>() { keyword };
            }
            else
            {
                var list = new List<string>();
                this.CurrentLoginUser.SearchHistory.ForEach(p =>
                {
                    if (p.Equals(keyword, StringComparison.OrdinalIgnoreCase))
                    {
                        list.Add(p);
                    }
                });
                list.ForEach(p => this.CurrentLoginUser.SearchHistory.Remove(p));
                this.CurrentLoginUser.SearchHistory.Insert(0, keyword);
                if (this.CurrentLoginUser.SearchHistory.Count > this.BizUIConfig.MaxSearchHistoryCount)
                {
                    this.CurrentLoginUser.SearchHistory.RemoveRange(
                        this.BizUIConfig.MaxSearchHistoryCount,
                        this.CurrentLoginUser.SearchHistory.Count - this.BizUIConfig.MaxSearchHistoryCount);
                }
            }
            CurrentLoginUser.Sortby = sortby >= 0 ? sortby : CurrentLoginUser.Sortby;
            if (CurrentLoginUser.Sortby < 0) CurrentLoginUser.Sortby = 0;

            if (bizUI != null && !bizUI.SwithToNewegg)
            {
                CookieHelper.OtherInfoCookie.SetCookieModel(this.CurrentLoginUser);
            }
            else
            {
                CookieHelper.ComInfoCookie.SetSortBy(CurrentLoginUser.Sortby);
                CookieHelper.ComInfoCookie.SetSearchHistory(CurrentLoginUser.SearchHistory); 
            }
            #endregion


            var model = SearchProcessor.Get(decodeKeyword, CurrentLoginUser.Sortby, category, decodeWithin);
            model.Navgations = new List<NavgationItem>()
            {
                new NavgationItem()
                {
                    Name = "Home",
                    Url = Url.BuildUrl(PageAliase.Homepage)
                },
                new NavgationItem()
                {
                    Name = "Search"
                }
            };
            model.Keyword = decodeKeyword;
            model.Within = decodeWithin;
            model.Sortby = CurrentLoginUser.Sortby;
            model.Category = model.SubCategoryList.Exists(t => t.ID == category) ? category : 0;
            return View(model);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Paging(string keyword, int sortby, int category, string within, int pageIndex, int pageSize)
        {
            var decodeKeyword = string.Join("", HttpUtility.UrlDecode(keyword).Take(MAX_LENGTH));
            var decodeWithin = string.Join("", HttpUtility.UrlDecode(within).Take(MAX_LENGTH));
            var model = SearchProcessor.Paging(keyword, sortby, decodeWithin, pageIndex, pageSize, category);
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && !bizUI.SwithToNewegg)
            {
                CookieHelper.OtherInfoCookie.SetSortBy(sortby);
            }
            else
            {
                CookieHelper.ComInfoCookie.SetSortBy(sortby);
            }
            return View("_SearchDealsDetail", model);
        }

        public JsonResult Keywords(string input, int sugguestCount = 5)
        {
            var keyword = HttpUtility.UrlDecode(input);
            var data = this.SearchProcessor.GetSuggestKeywords(keyword, sugguestCount);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// translate keyword
        /// </summary>
        /// <param name="keyword"></param>
        /// <param name="translateSetting"></param>
        /// <returns></returns>
        private string GetTranslatedKeyWord(string keyword, TranslatorSetting translateSetting)
        {
            var decodeKeyword = keyword;
            try
            {
                // keyword is  chinese character ，translate
                if (System.Text.RegularExpressions.Regex.IsMatch(keyword, @"[\u4e00-\u9fa5]+$"))
                {
                    var translatedKeyword = Utility.GetTranslateResult(keyword, translateSetting);
                    decodeKeyword = string.Join("", HttpUtility.UrlDecode(translatedKeyword).Take(MAX_LENGTH));
                }
            }
            catch (Exception ex)
            {
                 
            }
            return decodeKeyword;
        }
    }
}
