﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.EC;
using Newegg.EC.Cookie;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Implement;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Interface.Search;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class FeaturedController : FlashController
    {
        //
        // GET: /Search/

        protected IFeatured FeaturedProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IFeatured>();
            }
        }

        [HttpGet]
        [Tealium(typeof(TealiumConfigurableHeadlineProcessor))]
        [SiteCatalyst(typeof(ConfigurableHeadlineProcessor))]
        [CrawlerDetection]
        public ActionResult Index(int category=0,int sortby=0)
        {
            var model = FeaturedProcessor.Get(category, sortby);
            //var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            var headline = Globalization.Layout.Headline_InTheSpotlight;
            //2015 06 02 by jason，本地化之之后，将移到资源文件
            //if (bizUI != null && bizUI.HeadlineConfig != null && !string.IsNullOrEmpty(bizUI.HeadlineConfig.InTheSpotlight))
            //{
            //    headline = bizUI.HeadlineConfig.InTheSpotlight;
            //}
            ViewBag.Headline = headline;
            model.Navgations = new List<NavgationItem>()
            {
                new NavgationItem()
                {
                    Name = "Home",
                    Url = Url.BuildUrl(PageAliase.Homepage)
                },
                new NavgationItem()
                {
                    Name = headline
                }
            };
            model.Category = model.SubCategoryList.Exists(t => t.ID == category) ? category : 0;
            model.Sortby = model.SortbyList.Exists(t => t.Key == sortby) ? sortby : 0;

            return View(model);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Paging(int pageIndex, int pageSize,int category,int sortby)
        {
            var model = FeaturedProcessor.Paging(pageIndex, pageSize, category, sortby);
            return View("_FeaturedDealsDetail", model);
        }

    }
}
