﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.EC;
using Newegg.Flash.WWW.BizPolicy.Core;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class UpcomingController : FlashController
    {
        protected IUpcoming UpcomingProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IUpcoming>();
            }
        }
        //
        // GET: /Upcoming/
        [HttpGet]
        public ActionResult Index()
        {
            var upcomingEvents = ConfigurationWWWManager<BizUI>.ItemCfg().UpcomingEvents;

            UpcomingSales model = UpcomingProcessor.Get(upcomingEvents.DayCount, upcomingEvents.DealCount);
            if (model.Deals != null)
            {
                foreach (KeyValuePair<DateTime,List<Deal>> item in model.Deals)
                {
                    if (item.Value != null)
                    {
                        foreach (Deal deal in item.Value)
                        {
                            deal.ItemPartialType = "upcoming";
                            deal.StartTime = Utility.GetTimeByTimeZoneID(deal.StartTime, null, BizThreadContext.RegionCode.TimeZone);
                        }
                    }
                }
            }

            var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
            if (seoInfo != null && seoInfo.Upcoming != null)
            {
                RenderSEOInfo(seoInfo.Upcoming);
            }

            return View(model);
        }

    }
}
