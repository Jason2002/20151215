﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Newegg.EC;
using Newegg.EC.Configuration;
using Newegg.EC.Net.Implement;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.EC.Web.Mvc;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class ServerTestController : Controller
    {
        [HttpGet()]
        public ActionResult Index()
        {
            CheckPage cfg = ConfigurationWWWManager<CheckPage>.ItemCfg();
            JavaScriptSerializer js = new JavaScriptSerializer();
            ViewBag.ClientServerInfo = js.Serialize(cfg).Replace("\"", "'");
            return View();
        }

        public string Check(string pageUrl)
        {
            if (string.IsNullOrEmpty(pageUrl)) return string.Empty;
            var homeUrl = Url.BuildUrl(PageAliase.Homepage).Trim('/').ToLower();
            var decodeUrl = HttpUtility.UrlDecode(pageUrl).ToLower();

            if (!decodeUrl.StartsWith(homeUrl))
                return string.Format("The request url is not inside \"{0}\"", homeUrl);

            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            string rt = string.Empty;
            try
            {
                rt = client.DownloadString(pageUrl);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                client.Dispose();
            }
            return rt;
        }
    }
}
