﻿using Newegg.EC.Cookie;
using Newegg.EC.NeweggComCookie;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.Filters;
using Newegg.Flash.WWW.UI.UICommon;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class CookieSyncController : FlashController
    {
        [NoCookie]
        public string Index()
        {
            var callbackName = this.HttpContext.Request["callback"]; 
            var shoppingInfo = CookieManager.GetValue<ShoppingInfoCookieModel>(ShoppingInfoCookieModel.Key);
            var miniCartInfo = CookieManager.GetValue<MiniCarViewModel>(MiniCarViewModel.Key);
            var otherInfo = CookieManager.GetValue<OtherInfoCookieModel>(OtherInfoCookieModel.Key);
            var gatedLaunch = CookieManager.GetValue<GatedLaunchCookieModel>(GatedLaunchCookieModel.Key);

            //clear old cookie
            CookieManager.ClearValue(ShoppingInfoCookieModel.Key);
            CookieManager.ClearValue(MiniCarViewModel.Key);
            CookieManager.ClearValue(OtherInfoCookieModel.Key);
            var result = new
            {
                shopincart = shoppingInfo,
                minicart = miniCartInfo,
                gatedLaunch = gatedLaunch,
                comminfo = new
                {
                    sh = otherInfo.SearchHistory,
                    st =otherInfo.Sortby.ToString(),
                    gl = otherInfo.GatedLaunch,
                    ue = otherInfo.UserEmail,
                    syn = "1",
                    opt = otherInfo.CookieOptions
                }
            };

            return string.Format("{0}({1})", callbackName, JsonConvert.SerializeObject(result));
        }

    }
}
