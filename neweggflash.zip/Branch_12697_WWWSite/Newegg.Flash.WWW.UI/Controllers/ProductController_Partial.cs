﻿using Newegg.EC;
using Newegg.EC.Configuration;
using Newegg.EC.Net.Implement;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.Filters;
using Newegg.Flash.WWW.UI.UICommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class AdditionalInfo
    {
        public string Mir { get; set; }
        public string EggPoint { get; set; }
        public string Premier { get; set; }
    }

    public partial class ProductController
    {
        protected IEggPoint EggPointProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IEggPoint>();
            }
        }

        [FlashCookieFilter(NoCookie = true)]
        public JsonResult GetAdditionalInfo(string items,string pageAliase)
        {
            List<AdditionalInfo> result = new List<AdditionalInfo>();
            if (string.IsNullOrEmpty(items))
                return Json(result, JsonRequestBehavior.AllowGet);
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            string[] itemList = items.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Where(i => !string.IsNullOrEmpty(i)).ToArray();
            var additional = ProdcutProcessor.GetAdditionalProductInfo(items, "");
            List<EggPointServiceModel> eggpoints = null;
            EggPointRule rule = GetEggPointRule(pageAliase);
            if (rule != null && rule.Enable && additional != null && additional.Any())
            {
                var request = additional.Select(x => new PointRateItemInfo()
                {
                    BrandId = x.BrandId,
                    IsRecertified = x.IsRecertified,
                    ItemNumber = x.ItemNumber,
                    SellerId =(x.SellerID??string.Empty).Trim(),
                    SubCategoryId = x.SubCategoryId
                }).ToList();
                eggpoints = EggPointProcessor.GetEggPoint(request);
            }

            itemList.ForEach(i =>
            {
                AdditionalInfo item = new AdditionalInfo();
                result.Add(item);
                if (additional != null && additional.Any())
                {
                    var data = additional.Where(a => a.ItemNumber == i).FirstOrDefault();
                    if (data != null && bizUI != null && bizUI.MIRConfig != null && bizUI.MIRConfig.Enable)
                    {
                        item.Mir = RebateHelper.BuildMaininRebate(data, false);
                    }

                    if (data != null && bizUI != null && bizUI.NeweggPremier != null && bizUI.NeweggPremier.Enable)
                    {
                        item.Premier = GetPremierItemHtml(data , true);
                    } 
                    if (eggpoints != null && eggpoints.Any())
                    {
                        var point = eggpoints.Where(a => a.ItemNumber == i).FirstOrDefault();
                        if (point != null)
                        {
                            item.EggPoint = BuildEggPointHtml(point, rule, data.FinalPrice);
                        }
                    }
                }
            });

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// get eggpoint rule
        /// </summary>
        /// <param name="position">show position, BizUI.config -> eggPoints -> rule -> position</param>
        /// <returns></returns>
        private EggPointRule GetEggPointRule(string position)
        {
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && bizUI.EggPointConfig != null && bizUI.EggPointConfig.Enable)
            {
                 return bizUI.EggPointConfig.GetRule(position);
            }
            return null;
        }

        /// <summary>
        /// get eggpoint html
        /// </summary>
        /// <param name="model">egg point data</param>
        /// <param name="rule">egg point rule</param>
        /// <param name="finalPrice">UnitCost - ISNULL(a.instantRebateAmount, 0) as FinalPrice</param>
        /// <returns></returns>
        [FlashCookieFilter(NoCookie = true)]
        private string BuildEggPointHtml(EggPointServiceModel model, EggPointRule rule, decimal finalPrice)
        {
            StringBuilder sb = new StringBuilder();
            if (rule != null && rule.Enable)
            {
                var pointRate = model.GetPointRate < 0 ? 0 : model.GetPointRate;
                var points = Math.Ceiling(Math.Abs(finalPrice)) * pointRate;
                var pointsText = points.ToString("C", EggPointFormat);
                if (points > 0)
                {
                    // 需要显示倍率
                    sb.AppendLine(" <span class=\"iconPoint\"></span>");
                    sb.AppendLine(" <span class=\"eggpointsEarn\">+</span>");
                    sb.AppendLine(" <span class=\"eggpointsPoints\">" + pointsText + "</span>");
                }
            }
            return sb.ToString();
        }


        /// <summary>
        /// get eggpoint html
        /// </summary>
        /// <param name="model">egg point data</param>
        /// <param name="finalPrice">UnitCost - ISNULL(a.instantRebateAmount, 0) as FinalPrice</param>
        /// <param name="position">show position, BizUI.config -> eggPoints -> rule -> position</param>
        /// <returns></returns>
        [FlashCookieFilter(NoCookie = true)]
        private string BuildEggPointHtml(EggPointServiceModel model, decimal finalPrice, string position)
        {
            StringBuilder sb = new StringBuilder();
             var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
             if (bizUI != null && bizUI.EggPointConfig != null && bizUI.EggPointConfig.Enable)
             {
                 var pointRate = model.GetPointRate < 0 ? 0 : model.GetPointRate;
                 var points = Math.Ceiling(Math.Abs(finalPrice)) * pointRate;
                 var pointsText = points.ToString("C", EggPointFormat);

                 // 当前页面允许显示
                 var rule = bizUI.EggPointConfig.GetRule(position);
                 if (rule != null && rule.Enable && points > 0)
                 {
                     // 需要显示倍率
                     if (rule.HasMultiple && pointRate > 1)
                     {
                         sb.AppendLine("  <span class=\"iconPointsMultiple\">");
                         sb.AppendLine("     " + pointRate + "x<span class=\"arrow\"></span>");
                         sb.AppendLine(" </span>");
                     }
                     sb.AppendLine(" <span class=\"iconPoint\">EggPoints</span>");
                     sb.AppendLine(" <span class=\"eggpointsUpto\">up to</span>");
                     sb.AppendLine(" <span class=\"eggpointsEarn\">+</span>");
                     sb.AppendLine(" <span class=\"eggpointsPoints\">" + pointsText + "</span>");
                     if (rule.HasPopup)
                     {
                         var manager = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
                         var hosts = manager.GetConfiguration<HostsConfig>();

                         //需要强制转跳到的URL
                         var host = hosts.Hosts.Collection.FirstOrDefault(t => System.String.Compare(t.Name, "WWWNeweggCom", System.StringComparison.OrdinalIgnoreCase) == 0);
               
                         sb.AppendLine(" <span class=\"iconRightHelp\">help</span>");
                         sb.AppendLine(" <div class=\"popContainer rightPopContainer\" style=\"z-index: 1000; display: none;\">");
                         sb.AppendLine("     <span class=\"arrow\"></span>");
                         sb.AppendLine("     <div class=\"longarrow\"></div>");
                         sb.AppendLine("     <p class=\"color1\"><span class=\"iconPoint\"></span>Valid for 90 Days</p>");
                         sb.AppendLine("     <p class=\"color subTitle\">Earn EggPoints and save money on future orders!</p>");
                         sb.AppendLine("     <ul>");
                         sb.AppendLine("         <li>Earn EggPoints when you shop at <a class=\"link\" href=\"" + host.Address 
                                        + "\">Newegg.com</a> or <a class=\"link\" href=\"/\">Neweggflash.com</a></li>");
                         sb.AppendLine("         <li>Use your EggPoints like cash when you make a purchase</li>");
                         sb.AppendLine("         <li>EggPoints determined by final selling price after all</li>");
                         sb.AppendLine("     </ul>");
                         if (!string.IsNullOrEmpty(bizUI.EggPointConfig.ProductPagePromotionLink))
                         {
                             sb.AppendFormat("     <p><a target=\"_blank\" class=\"link color1\" href=\"{0}\" title=\"Learn More\">Learn More</a></p>\r\n", bizUI.EggPointConfig.ProductPagePromotionLink);
                         }
                         sb.AppendLine(" </div>  ");
                     }
                 }
             }
            return sb.ToString();
        }
    }
}