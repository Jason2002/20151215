﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.EC;
using Newegg.Flash.WWW.UI.UICommon.Sweepstakes;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class StoreController : FlashController
    {

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Index(int id = 0, int sortby = 0)
        {
            return FlashStore(1, id,sortby);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult AllStore(int id = 0, int sortby = 0)
        {
            var homepage = ECLibraryContainer.Current.GetInstance<IHome>().Get();
            homepage.Title = StoreProcessor.GetStoreProperty(id, "Crumb");
            homepage.Navgations = new List<NavgationItem>()
            {
                new NavgationItem()
				{
					Name	= "Home",
					Url	= Url.BuildUrl( PageAliase.Homepage )
				},
				new NavgationItem()
				{
					Name = StoreProcessor.GetStoreProperty(id, "Crumb"),
                    Url=Url.BuildUrl(PageAliase.AllStore)
				},
            };
            return (View("AllStore", homepage));
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult ForHome(int id = 0,int sortby = 0)
        {
            return FlashStore(2, id, sortby);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult ForYou(int id = 0, int sortby = 0)
        {
            return FlashStore(3, id, sortby);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Paging(int id, int pageIndex, int pageSize, int sort, int subCategoryID)
        {
            var stores=StoreProcessor.GetStoreDeals(id, pageIndex, pageSize,subCategoryID,sort);
            return (View("_FlashStoreList", stores));
        }

        private ActionResult FlashStore(int storeId, int category,int sortby)
        {
            var store = StoreProcessor.GetStoreDeals(storeId, 1, 20, category, sortby);
            store.Sortby = sortby;
            store.Navgations = new List<NavgationItem>()
			{
				new NavgationItem()
				{
					Name	= "Home",
					Url	= Url.BuildUrl( PageAliase.Homepage )
				},
				new NavgationItem()
				{
					Name =store.StoreName,
                    Url=Url.BuildUrl(store.PageAliase,new {id=0})
				},
			};

            var cate=store.SubCategoryList.FirstOrDefault(i => i.ID == category);
            if (cate != null)
            {
                store.Navgations.Add(new NavgationItem()
                {
                     Name=cate.Name
                });
            }

            int index=store.SubCategoryList.FindIndex(i => i.ID == store.SubCategoryId);
            if (index >= 10)
            {
                store.SelectCategoryIsHiden = true;
            }
            return (View("FlashStore", store));
        }

    }
}
