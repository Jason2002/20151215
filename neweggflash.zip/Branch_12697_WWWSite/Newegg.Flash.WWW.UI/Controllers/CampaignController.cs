﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.EC;
using Newegg.Flash.WWW.Common;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using Newegg.Flash.WWW.UI.Filters;

namespace Newegg.Flash.WWW.UI.Controllers
{
    [RegionChangeFilterAttribute(RedirectKey = "cc", RedirectValue = "t")]
    public class CampaignController : FlashController
    {
        protected ICampaign CampaignProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<ICampaign>();
            }
        }

        protected IAllCampaign AllCampaignProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IAllCampaign>();
            }
        }

        //
        // GET: /Default1/
        [HttpGet]
        [Tealium(typeof(TealiumCampainProcessor))]
        [SiteCatalyst(typeof(CampaignPageProcessor))]
        [CrawlerDetection]
        public ActionResult Index(int id)
        {
            CampaignPage model = CampaignProcessor.Get(id);

            if (model != null && model.Campaign != null)
            {
                if (model.Campaign.StartTime > Common.CommonUtility.DateTimeNow)
                {
                    return this.Redirect(Url.BuildUrl(PageAliase.ComingSoon));
                }

                if (Utility.IsGomez(Request.UserAgent))
                {
                    model.Campaign.IsNeedLogin = false;
                }

                var needLogin = Utility.AllowAccessItem(this, model.Campaign.IsNeedLogin);
                if (needLogin != null)
                {
                    return needLogin;
                }

                model.Navgations = new List<NavgationItem>()
                                       {
                                           new NavgationItem()
                                               {
                                                   Name = "Home",
                                                   Url = Url.BuildUrl(PageAliase.Homepage)
                                               },
                                           new NavgationItem()
                                               {
                                                   Name = model.Campaign.CampaignName
                                               }
                                       };

                var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
                if (seoInfo != null && seoInfo.Campaign != null)
                {
                    string campaignName = string.IsNullOrWhiteSpace(model.Campaign.CampaignName)
                                             ? string.Empty
                                             : model.Campaign.CampaignName.Trim();
                    SEOPageInfo productSEOInfo = new SEOPageInfo()
                    {
                        PageTitle = string.Format(seoInfo.Campaign.PageTitle, campaignName),
                        PageDescription = string.Format(seoInfo.Campaign.PageDescription, campaignName),
                        PageKeywords = seoInfo.Campaign.PageKeywords,
                    };
                    RenderSEOInfo(productSEOInfo);
                }

            }
            return View(model);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Paging(int id, int pageIndex, int pageSize, int sort, int subCategoryID)
        {
            var model = CampaignProcessor.Paging(id, pageIndex, pageSize, sort, subCategoryID);
            return View("_Campaign", model);
        }

        [HttpGet]
        [SiteCatalyst(typeof(AllCampaignProcessor))]
        [CrawlerDetection]
        public ActionResult All(int id)
        {
            GeneralDeals all = AllCampaignProcessor.Get(id);
            all.StoreId = id;
            all.Navgations = new List<NavgationItem>()
            {
                new NavgationItem(){
                   Name="Home",
                   Url=Url.BuildUrl(PageAliase.Homepage)
                },
                new NavgationItem(){
                   Name=all.StoreName,
                   Url=Url.BuildUrl(all.PageAliase,new {id=0})
                },
                new NavgationItem(){
                   Name="All Campaigns"
                }
            };
            return View("All", all);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult AllPaging(int id, int pageIndex, int pageSize)
        {
            GeneralDeals all = AllCampaignProcessor.Get(id, pageIndex, pageSize, 1);
            return View("_AllCampaignList", all);
        }
    }
}
