﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.EC;
using Newegg.Flash.WWW.Common;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
namespace Newegg.Flash.WWW.UI.Controllers
{
    public class FeaturedStoreController : FlashController
    {
        public IFeaturedStore FeaturedStoreProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IFeaturedStore>();
            }
        }

        [HttpGet]
        [Tealium(typeof(TealiumConfigurableHeadlineProcessor))]
        [SiteCatalyst(typeof(ConfigurableHeadlineProcessor))]
        [CrawlerDetection]
        public ActionResult Index()
        {
            GeneralDeals all = FeaturedStoreProcessor.Get();
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            var headline = Globalization.Layout.Headline_FeaturedStore;
            //if (bizUI != null && bizUI.HeadlineConfig != null && !string.IsNullOrEmpty(bizUI.HeadlineConfig.FeaturedStore))
            //{
            //    headline = bizUI.HeadlineConfig.FeaturedStore;
            //}
            ViewBag.Headline = headline;
            all.Navgations = new List<NavgationItem>()
            {
                new NavgationItem(){
                   Name="Home",
                   Url=Url.BuildUrl(PageAliase.Homepage)
                },
                new NavgationItem(){
                   Name=headline
                }
            };
            return View(all);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Paging(int pageIndex, int pageSize)
        {
            GeneralDeals all = FeaturedStoreProcessor.Get(pageIndex,pageSize);
            return View("_FeaturedStoreList",all);
        }
    }
}
