﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Interface;
using Newegg.EC;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using System.Globalization;
using Newegg.EC.BizUnit;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using System.Text;
using Newegg.Flash.WWW.UI.Filters;

namespace Newegg.Flash.WWW.UI.Controllers
{
    [RegionChangeFilterAttribute(RedirectKey = "cc", RedirectValue = "t",IsProduct=true)]
    public partial class ProductController : FlashController
    {
        protected IProduct ProdcutProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IProduct>();
            }
        }

        private static readonly NumberFormatInfo EggPointFormat = new NumberFormatInfo()
        {
            CurrencyDecimalDigits = 0,
            CurrencyDecimalSeparator = ".",
            CurrencyGroupSeparator = ",",
            CurrencyGroupSizes = new int[] { 3, 3, 3, 3, 3 },
            CurrencyNegativePattern = 1,
            CurrencyPositivePattern = 0,
            CurrencySymbol = "",
            NegativeSign = "-",
        };

        //
        // GET: /Product/
        [HttpGet]
        [Tealium(typeof(TealiumProductProcessor))]
        [SiteCatalyst(typeof(ProductPageProcessor))]
        [CrawlerDetection]
        public ActionResult Index(string id, string upcoming = "", string gift = "")
        {
            var isUpcoming = !upcoming.IsNullOrEmpty();
            var isGift = !gift.IsNullOrEmpty();

            this.ViewBag.Gift = isGift;

            id = ItemNumberConvert.NeweggItemNumber2ItemNumber(id);
            bool isRequestFromNeweggCentral = false;
            if (this.Request.Headers["X-NeweggCentral-Source"] != null)
            {
                isRequestFromNeweggCentral = string.Compare("Yes",
                    this.Request.Headers["X-NeweggCentral-Source"],
                    true) == 0;
            }
            List<Item> list = ProdcutProcessor.Get(id, isUpcoming, isRequestFromNeweggCentral, isGift);
            if (!isRequestFromNeweggCentral &&
                (isUpcoming && list.Count > 0 && list[0].StartTime > Common.CommonUtility.DateTimeNow))
            {
                return this.Redirect(Url.BuildUrl(PageAliase.ComingSoon));
            }

            if (list != null && (isRequestFromNeweggCentral || Utility.IsGomez(Request.UserAgent)))
            {
                list.ForEach(i => { i.IsNeedLogin = false; });
            }

            ItemGroup model = new ItemGroup(list);
            if (model.Items != null && model.Items.Count > 0)
            {
                ActionResult needLogin = null;
                foreach (Item item in model.Items)
                {
                    if (!isRequestFromNeweggCentral &&
                        ((needLogin = Utility.AllowAccessItem(this, item.IsNeedLogin)) != null))
                    {
                        return needLogin;
                    }

                    item.ReturnPolicyUrl = Url.BuildUrl(PageAliase.ReturnPolicy, new { itemNumber = item.NeweggItemNumber });

                    item.ReturnPolicyUrl = Utility.AddGiftTagForUrl(item.ReturnPolicyUrl, isGift);

                    if (item.AutoAddInfo != null && item.AutoAddInfo.AutoAddItemList != null)
                    {
                        var bizUnit = BizThreadContext.BizUnitInfo;
                        foreach (var autoItem in item.AutoAddInfo.AutoAddItemList)
                        {
                            autoItem.GiftItemImagePath = autoItem.ImageName;
                            autoItem.GiftDetailPageUrl = Url.BuildUrl(PageAliase.Product, new { id = autoItem.NeweggItemNumber, gift = 1 });
                            autoItem.DisplayUnitPrice = string.Format(CultureInfo.CreateSpecificCulture(bizUnit.DefaultLanguageCode), "{0:C2}", autoItem.UnitCost);
                        }
                    }
                }

                model.Navgations = new List<NavgationItem>() { 
                    new NavgationItem()
                    { 
                        Name = "Home",
                        Url = Url.BuildUrl(PageAliase.Homepage)
                    }
                };
                if (model.Items[model.CurrentItemIndex].ExpireTicks > 0)
                {
                    if (model.Items[model.CurrentItemIndex].CampaignId > 0 && !string.IsNullOrEmpty(model.Items[model.CurrentItemIndex].CampaignName))
                    {
                        model.Navgations.Add(new NavgationItem()
                        {
                            Name = model.Items[model.CurrentItemIndex].CampaignName,
                            Url = Url.BuildUrl(PageAliase.Campaign, new { id = model.Items[model.CurrentItemIndex].CampaignId })
                        });
                    }
                    else if (model.Items[model.CurrentItemIndex].Navigation != null && !string.IsNullOrEmpty(model.Items[model.CurrentItemIndex].Navigation.CategoryName))
                    {
                        model.Items[model.CurrentItemIndex].Navigation.StoreName = StoreProcessor.GetStoreProperty(model.Items[model.CurrentItemIndex].Navigation.StoreId);
                        model.Items[model.CurrentItemIndex].Navigation.PageAliase = StoreProcessor.GetStoreProperty(model.Items[model.CurrentItemIndex].Navigation.StoreId, "Aliase");

                        model.Navgations.Add(new NavgationItem()
                        {
                            Name = model.Items[model.CurrentItemIndex].Navigation.StoreName,
                            Url = Url.BuildUrl(model.Items[model.CurrentItemIndex].Navigation.PageAliase, new { id = 0 })
                        });

                        model.Navgations.Add(new NavgationItem()
                        {
                            Name = model.Items[model.CurrentItemIndex].Navigation.CategoryName,
                            Url = Url.BuildUrl(model.Items[model.CurrentItemIndex].Navigation.PageAliase, new { id = model.Items[model.CurrentItemIndex].Navigation.CategoryId })
                        });
                    }
                }

                model.Navgations.Add(new NavgationItem()
                {
                    Name = "Item#: {0}",
                    NameArgs = new object[] { model.Items[model.CurrentItemIndex].NeweggItemNumber }
                });

                var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
                if (seoInfo != null && seoInfo.Product != null)
                {
                    string webDescription = string.IsNullOrWhiteSpace(model.Items[model.CurrentItemIndex].WebDescription)
                                             ? string.Empty
                                             : model.Items[model.CurrentItemIndex].WebDescription.Trim();
                    string description = string.IsNullOrWhiteSpace(model.Items[model.CurrentItemIndex].Description)
                                             ? string.Empty
                                             : model.Items[model.CurrentItemIndex].Description.Trim();
                    SEOPageInfo productSEOInfo = new SEOPageInfo()
                    {
                        PageTitle = string.Format(seoInfo.Product.PageTitle, webDescription),
                        PageDescription = string.Format(seoInfo.Product.PageDescription, description),
                        PageKeywords = string.Format(seoInfo.Product.PageKeywords, description),
                    };
                    RenderSEOInfo(productSEOInfo);
                }
            }
            ViewBag.MobileDevice = Utility.IsMobileDevice();
            if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().SwithToNewegg)
            {
                ViewBag.AddToCartUrl = Url.BuildUrl(PageAliase.OutSite.AddToNeweggShoppingCart);
                ViewBag.ShareToFriendUrl = string.Format(Url.BuildUrl(PageAliase.OutSite.NeweggCommonShare), (int)(CrossDomainActionEnum.ShareToFriend));
            }
            else
            {
                ViewBag.AddToCartUrl = Url.BuildUrl(PageAliase.OutSite.AddToShoppingCart);
                ViewBag.ShareToFriendUrl = Url.BuildUrl(PageAliase.OutSite.ShareToFriend);
            }

            // not default currency
            if (!"Y".Equals(BizThreadContext.CurrentCurrencyInfo.IsDefault))
            {
                ProcessFromLocalPrice(model); 
            }
            return View(model);
        }

        private void ProcessFromLocalPrice(ItemGroup model)
        {
            var defaultCurrencyCode = BizThreadContext.CurrentCurrencyCode;
            var defaultCurrency = BizThreadContext.Currencys.Where(x=>x.CountryCode.Trim() == BizThreadContext.RegionCode.Code && "Y".Equals(x.IsDefault)).FirstOrDefault();

            if(defaultCurrency != null )
            {
               defaultCurrencyCode = defaultCurrency.CurrencyCode.Trim();
            }
            // step1 : get exchange rate from big data service
            var realTimeExchangeRate = ProdcutProcessor.GetRealtimeExchangeRate(string.Join(",", model.Items.Select(x => x.ItemNumber)),
                BizThreadContext.RegionCode.Code, 1003, defaultCurrencyCode);
            if (realTimeExchangeRate != null)
            {
                // step2 : set price in current currency 
                Utility.ProcessLocalPrice(model, realTimeExchangeRate);
            }
        } 

        [HttpGet]
        [Tealium(typeof(TealiumProductReturnPolicyProcessor))]
        [SiteCatalyst(typeof(ProductReturnPolicyPageProcessor))]
        [CrawlerDetection]
        public ActionResult ReturnPolicy(string itemNumber, string gift = "")
        {
            var isGift = !gift.IsNullOrEmpty();

            this.ViewBag.Gift = isGift;

            itemNumber = ItemNumberConvert.NeweggItemNumber2ItemNumber(itemNumber);
            ReturnPolicyPage model = new ReturnPolicyPage();
            model = ProdcutProcessor.GetReturnPolicy(itemNumber, isGift);

            if (model != null && model.Item != null)
            {
                model.Item.Navgations = new List<NavgationItem>()
                    {
                        new NavgationItem()
                            {
                                Name = "Home",
                                Url = Url.BuildUrl(PageAliase.Homepage)
                            }
                    };
                if (model.Item.CampaignId > 0 && !string.IsNullOrWhiteSpace(model.Item.CampaignName))
                {
                    model.Item.Navgations.Add(new NavgationItem()
                        {
                            Name = model.Item.CampaignName,
                            Url = Url.BuildUrl(PageAliase.Campaign, new { id = model.Item.CampaignId }),
                            NameArgs = new object[] { model.Item.CampaignId }
                        });
                }

                model.Item.Navgations.AddRange(new List<NavgationItem>()
                {
                    new NavgationItem()
                    {
                        Name = "Item#: {0}",
                        NameArgs = new object[] {model.Item.NeweggItemNumber},
                        Url = Utility.AddGiftTagForUrl(Url.BuildUrl(PageAliase.Product, new {id = model.Item.NeweggItemNumber}), isGift)
                    },
                    new NavgationItem()
                    {
                        Name = "Standard Return Policy"
                    }
                });

                var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
                if (seoInfo != null && seoInfo.ProductReturnPolicy != null)
                {
                    string subCategoryName = string.IsNullOrWhiteSpace(model.Item.SubcategoryName)
                                                ? string.Empty
                                                : model.Item.SubcategoryName.Trim();
                    string description = string.IsNullOrWhiteSpace(model.Item.Description)
                                             ? string.Empty
                                             : model.Item.Description.Trim();
                    SEOPageInfo productSEOInfo = new SEOPageInfo()
                        {
                            PageTitle = seoInfo.ProductReturnPolicy.PageTitle,
                            PageDescription = string.Format(seoInfo.ProductReturnPolicy.PageDescription, subCategoryName),
                            PageKeywords = string.Format(seoInfo.ProductReturnPolicy.PageKeywords, description),
                        };
                    RenderSEOInfo(productSEOInfo);
                }
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult ImageViewer(string info)
        {
            var serializer = EC.ECLibraryContainer.Current.GetInstance<Newegg.EC.Serialization.IJsonSerializer>();
            List<string> imageList = serializer.DeserializeFromText<List<string>>(info.Replace("'", "\""));
            return View("Viewer", imageList);
        }

        [HttpPost]
        [FlashCookieFilter(NoCookie = true)]
        public ActionResult GetAdditionalProductInfo(string itemNumbers, string type)
        {
            var additionalInfo = this.ProdcutProcessor.GetAdditionalProductInfo(itemNumbers, type);
            return Json(additionalInfo);
        }


        /// <summary>
        /// Get additional product info html by item number
        /// </summary>
        /// <param name="itemNumbers"></param>
        /// <param name="infotype">0: all ; 1:mir info ; 2:iron egg; 3:make gift </param>
        /// <returns></returns>
        [HttpPost]
        [FlashCookieFilter(NoCookie = true)]
        public string AdditionalProductInfoHtml(string itemNumber, string infotype = "0")
        {
            var resultHTML = string.Empty;
            var infos = new string[4] {"","","",""};
            if (string.IsNullOrEmpty(itemNumber))
            {
                return null;
            }
            var data = this.ProdcutProcessor.GetAdditionalProductInfo(itemNumber, "0");
            if (!data.IsNullOrEmpty())
            {
                // mir 1
                infos[0] = GetMIRHtml(data[0]);

                // iron egg  2
                if ("1".Equals(data[0].IsHot))
                {
                    infos[1] = GetIronEggHtml(data[0]);
                }

                // Make a gift 3
                infos[2] = GetMakeGiftHtml(data[0]);

                // Premier item
                infos[3] = GetPremierItemHtml(data[0]); 
            }
            return string.Join("||+||+||", infos);
        }

        [HttpPost]
        [FlashCookieFilter(NoCookie = true)]
        public string EggPointsInfoHtml(string itemNumber, string position)
        {
            var result = string.Empty;
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && bizUI.EggPointConfig != null && bizUI.EggPointConfig.Enable)
            {
                var data = this.ProdcutProcessor.GetAdditionalProductInfo(itemNumber, "0");
                if (!data.IsNullOrEmpty()&& data.FirstOrDefault() != null)
                {
                    var request = new PointRateItemInfo()
                    {
                        BrandId = data.FirstOrDefault().BrandId,
                        IsRecertified = data.FirstOrDefault().IsRecertified,
                        ItemNumber = data.FirstOrDefault().ItemNumber,
                        SellerId = (data.FirstOrDefault().SellerID ?? string.Empty).Trim(),
                        SubCategoryId = data.FirstOrDefault().SubCategoryId
                    };
                    var eggpoints = EggPointProcessor.GetEggPoint(new List<PointRateItemInfo> { request });
                    if (eggpoints != null && eggpoints.FirstOrDefault() != null)
                    {
                        result = BuildEggPointHtml(eggpoints.FirstOrDefault(), data.FirstOrDefault().FinalPrice, position);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Get MIR Html
        /// </summary>
        /// <param name="additionalProductInfo"></param>
        /// <returns></returns>
        private string GetMIRHtml(AdditionalProductInfo additionalProductInfo)
        {
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && bizUI.MIRConfig != null && bizUI.MIRConfig.Enable)
            {
                if (!string.IsNullOrEmpty(additionalProductInfo.Mailrebateamount)
                    && !string.IsNullOrEmpty(additionalProductInfo.Mailrebatedescrip))
                {
                    return RebateHelper.BuildMaininRebate(additionalProductInfo, true);
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Get Make Gift Html
        /// </summary>
        /// <param name="additionalData"></param>
        /// <returns></returns>
        private string GetMakeGiftHtml(AdditionalProductInfo additionalData)
        {
            if (additionalData == null)
            {
                return string.Empty;
            }
            StringBuilder makeGiftHtml = new StringBuilder();
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && bizUI.MakeGiftConfig != null && bizUI.MakeGiftConfig.Enable)
            {
                if (!string.IsNullOrEmpty(additionalData.GiftWrapItem)
                    && (additionalData.GiftWrapItem.IndexOf("BOX-002") > -1 || additionalData.GiftWrapItem.IndexOf("BOX-003") > -1 || additionalData.GiftWrapItem.IndexOf("BOX-004") > -1)
                    && "1".Equals(additionalData.Active.Trim())
                    && "1".Equals(additionalData.HasOpcInventory.Trim()))
                {
                    makeGiftHtml.AppendLine("<input class=\"popCheck\" id=\"make-gift\" type=\"checkbox\" value=\"" + string.Join("_",additionalData.GiftWrapItem, additionalData.ItemNumber) + "\">");
                    makeGiftHtml.AppendLine("<label for=\"make-gift\">Make this item a gift</label>");
                    makeGiftHtml.AppendLine("<span class=\"iconRightHelp popLinkTarget\">Learn More</span>");
                    makeGiftHtml.AppendLine("<div class=\"popContainer rightPopContainer\" style=\"display: none; z-index: 0;\">");
                    makeGiftHtml.AppendLine("<span class=\"arrow\"></span>");
                    makeGiftHtml.AppendLine("<h3 class=\"rightHead\">Send it as a gift!</h3>");
                    makeGiftHtml.AppendLine("<p>Newegg’s gift-wrap service is the ideal solution for making your gift special! Select your item as a gift, then add your message. Your gift will also be discreet with no prices being included on the packing slip.</p>");
                    makeGiftHtml.AppendLine("</div>");
                }
            }
            return makeGiftHtml.ToString();
        }

        /// <summary>
        /// GetIronEggHtml
        /// </summary>
        /// <param name="additionalData"></param>
        /// <returns></returns>
        private string GetIronEggHtml(AdditionalProductInfo additionalData)
        {
            if (additionalData == null)
            {
                return string.Empty;
            }
            StringBuilder ironEggHtml = new StringBuilder();
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && bizUI.IronEggConfig != null && bizUI.IronEggConfig.Enable)
            {
                var startTime = bizUI.IronEggConfig.StartDateTime;
                 var endTime = bizUI.IronEggConfig.EndDateTime;
                DateTime begin;
                DateTime end;
                bool timeCheck = false;
                if (DateTime.TryParse(startTime, out begin) && DateTime.TryParse(endTime, out end))
                {
                    timeCheck = (Common.CommonUtility.DateTimeNow >= begin) && (Common.CommonUtility.DateTimeNow <= end);
                }
                else
                {
                    if (DateTime.TryParse(startTime, out begin))
                    {
                        timeCheck = (Common.CommonUtility.DateTimeNow >= begin);
                    }

                    if (DateTime.TryParse(endTime, out end))
                    {
                        timeCheck = (Common.CommonUtility.DateTimeNow <= end);
                    }
                }

                if ("1".Equals(additionalData.IsHot) && timeCheck)
                {
                    var link = bizUI.IronEggConfig.ProductPagePromotionLink;
                    
                    //ironEggHtml.AppendLine("<span class=\"ironEgg block\" >");
                    if (string.IsNullOrEmpty(link.Trim()))
                    {
                        ironEggHtml.AppendLine("<span class=\"iconIronEggImg\">IRON EGG</span>");
                    }
                    else
                    {
                        ironEggHtml.AppendLine("<a href=\"" + link + "\" title=\"Iron Egg\"><span class=\"iconIronEggImg\">IRON EGG</span></a>");
                    }
                    //ironEggHtml.AppendLine("</span>");
                }
            }
            return ironEggHtml.ToString();
        }

        /// <summary>
        /// GetIronEggHtml
        /// </summary>
        /// <param name="additionalData"></param>
        /// <returns></returns>
        private string GetPremierItemHtml(AdditionalProductInfo additionalData, bool forList = false)
        {
            if (additionalData == null)
            {
                return string.Empty;
            }
            StringBuilder premierItemHtml = new StringBuilder();
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && bizUI.NeweggPremier != null && bizUI.NeweggPremier.Enable)
            { 
                if (additionalData.IsPremierItem)
                {
                    if (forList)
                    {
                        premierItemHtml.AppendLine("<span class=\"iconPremier\"></span>");
                    }
                    else
                    {
                        var link = bizUI.NeweggPremier.LearnMoreLink;

                        var linkHtml = String.Empty;
                        if (!string.IsNullOrEmpty(link.Trim()))
                        {
                            linkHtml = String.Format(Newegg.Flash.WWW.Globalization.Product.PremierLink, link.Trim());
                        }
                        premierItemHtml.AppendFormat(Newegg.Flash.WWW.Globalization.Product.PremierNote, linkHtml);
                    }
                }
            }
            return premierItemHtml.ToString();
        }
    }
}
