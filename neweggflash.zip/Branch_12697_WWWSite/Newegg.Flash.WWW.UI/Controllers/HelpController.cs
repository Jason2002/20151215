﻿using System.Web.Mvc;
using Newegg.EC.Net.Implement;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.Controllers
{
    /// <summary>
    /// Help controller.
    /// </summary>
    public class HelpController : FlashController
    {

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string actionName = this.ValueProvider.GetValue("action").RawValue as string;
            //render seo info
            var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
            if (seoInfo != null && seoInfo.Help != null)
            {
                var title = string.Empty;
                switch (actionName.ToLower())
                {
                    case "contact-us":
                        title = "Contact Us";
                        break;
                    case "about-us":
                        title = "About Us";
                        break;
                    case "office-hours-and-locations":
                        title = "Office Hours & Locations";
                        break;
                    case "faq":
                        title = "FAQ";
                        break;
                    case "policy-agreement":
                        title = "Terms & Conditions";
                        break;
                    case "privacy-policy":
                        title = "Privacy Policy";
                        break;
                    case "return-policy":
                        title = "Return Policy";
                        break;
                    case "affiliates":
                        title = "Become an Affiliate";
                        break;
                    case "sell-to-us":
                        title = "Sell to Us";
                        break;
                    case "policy-bml":
                        title = "Bill Me Later";
                        break;
                    case "policy-npa":
                        title = "Neweggflash Preferred Account";
                        break;
                    case "policy-ironegg":
                        title = "The Neweggflash Iron Egg Guarantee";
                        break;
                    default:
                        title = "Help";
                        break;
                }
                SEOPageInfo productSEOInfo = new SEOPageInfo
                {
                    PageTitle = string.Format(seoInfo.Help.PageTitle, title),
                    PageKeywords = seoInfo.Help.PageKeywords,
                    PageDescription = seoInfo.Help.PageDescription,
                };

                RenderSEOInfo(productSEOInfo);
            }
            base.OnActionExecuting(filterContext);
        }

        private BizUI BizUIConfig
        {
            get
            {
                return ConfigurationWWWManager<BizUI>.ItemCfg();
            }
        }

        /// <summary>
        /// Index action.
        /// </summary>
        /// <returns>Action result.</returns>
        public ActionResult Index()
        {
            return AboutUs();
        }

        /// <summary>
        /// FAQ controller.
        /// </summary>
        /// <returns>Action result.</returns>
        public ActionResult FAQ(bool initMenuShown = false)
        {
                var url = string.Format("{0}{1}", BizUIConfig.ExternalPageLinksConfig.Host, BizUIConfig.ExternalPageLinksConfig.Faq);
            url = ProcessKBUrl(url);
                return Redirect(url);
            }

        private string ProcessKBUrl(string url)
            {
            if (BizThreadContext.IsUSARequest && BizThreadContext.IsDefaultRegion)
            {
                url = url + "?channel=fl";
            }
            return url;
        }

        /// <summary>
        /// Privacy Policy action.
        /// </summary>
        /// <returns>Action result.</returns>
        [ActionName("privacy-policy")]
        public ActionResult PrivacyPolicy()
        {
                var url = string.Format("{0}{1}", BizUIConfig.ExternalPageLinksConfig.Host, BizUIConfig.ExternalPageLinksConfig.PrivacyPolicy);
            url = ProcessKBUrl(url);
                return Redirect(url);
            }

        /// <summary>
        /// Sell to us action.
        /// </summary>
        /// <returns>Action result.</returns>
        [ActionName("sell-to-us")]
        public ActionResult SellToUS()
        {
            return View("SellToUS");
        }

        /// <summary>
        /// policy agreement action.
        /// </summary>
        /// <returns>Action result.</returns>
        [ActionName("policy-agreement")]
        public ActionResult PolicyAgreement()
        {
                var url = string.Format("{0}{1}", BizUIConfig.ExternalPageLinksConfig.Host, BizUIConfig.ExternalPageLinksConfig.TermsConditions);
            url = ProcessKBUrl(url);
                return Redirect(url);
            }

        /// <summary>
        /// Return policy.
        /// </summary>
        /// <returns>Action result.</returns>
        [ActionName("return-policy")]
        public ActionResult ReturnPolicy()
        {
                var url = string.Format("{0}{1}", BizUIConfig.ExternalPageLinksConfig.Host, BizUIConfig.ExternalPageLinksConfig.ReturnPolicy);
            url = ProcessKBUrl(url);
                return Redirect(url);
            }

        /// <summary>
        /// Return policy.
        /// </summary>
        /// <returns>Action result.</returns>
        [ActionName("california-transparency-in-supply-chains-act")]
        public ActionResult CaliforniaTransparencyInSupplyChainsAct()
        {
            return View("CaliforniaTransparencyInSupplyChainsAct");
        }

        [ActionName("office-hours-and-locations")]
        public ActionResult OfficeHoursAndLocation()
        {
            return View("OfficeHoursAndLocation");
        }

        [ActionName("about-us")]
        public ActionResult AboutUs()
        {
            return View("AboutUs");
        }

        [ActionName("contact-us")]
        public ActionResult ContactUs(string tagName)
        {
                var url = string.Format("{0}{1}", BizUIConfig.ExternalPageLinksConfig.Host, BizUIConfig.ExternalPageLinksConfig.ContactUs);
            url = ProcessKBUrl(url);
                return Redirect(url);
            }

        [ActionName("affiliates")]
        public ActionResult Affiliates()
        {
            return View("Affiliates");
        }

        [ActionName("mobile-app")]
        public ActionResult MobileApp()
        {
            return View("MobileApp");
        }

        [ActionName("policy-npa")]
        public ActionResult PolicyPrefferAccount()
        {
            return new RedirectResult("http://promotions.newegg.com/Newegg/PA110708/index.html", false);
        }

        [ActionName("policy-bml")]
        public ActionResult PolicyBllingMeLater()
        {
            return new RedirectResult("http://promotions.newegg.com/Newegg/BML110708/index.html", false);
        }

        [ActionName("policy-nscc")]
        public ActionResult PolicyNewEggStoreCreditCard()
        {
            return new RedirectResult("http://www.newegg.com/newegg-store-credit-card", false);
        }

        [ActionName("giftcard-policy")]
        public ActionResult GiftCardPolicy()
        {
            if (!string.IsNullOrEmpty(BizUIConfig.ExternalPageLinksConfig.GiftCardTermCondition))
            {

                var url = string.Format("{0}{1}", BizUIConfig.ExternalPageLinksConfig.Host, BizUIConfig.ExternalPageLinksConfig.GiftCardTermCondition);
                url = ProcessKBUrl(url);
                return Redirect(url);
            }
            return RedirectToAction("policy-agreement");
        }
    }
}
