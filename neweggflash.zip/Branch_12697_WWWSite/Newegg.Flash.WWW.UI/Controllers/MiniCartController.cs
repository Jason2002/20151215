﻿using Newegg.EC;
using Newegg.Flash.WWW.Interface.MiniCart;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.Filters;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public partial class MiniCartController : FlashController
    {
        protected IMiniCart MiniCartProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IMiniCart>();
            }
        }

        [CrawlerDetection]
        [FlashCookieFilter(NoCookie=true)]
        public ActionResult GetMiniCartItemInfoByAjax(string itemNumbers)
        {
            var result = MiniCartProcessor.GetMiniCartItemInfo(itemNumbers);
            var resultLite = new List<MiniCartItemLite>(16);
            if (result != null
                && result.Count != 0)
            {
                foreach (var item in result)
                {
                    item.Description = HttpUtility.UrlEncode(item.Description.Replace("\r\n", ""));

                    var itemLite = new MiniCartItemLite
                    {
                        ItemNumber = item.ItemNumber,
                        Description = item.Description,
                        DealUrlPath = item.DealUrlPath,
                        ExpireTotalMilliseconds = item.ExpireTime.TotalMilliseconds(),
                        FinalPrice = item.FinalPrice,
                        ImageSrc = item.ImageSrc,
                    };
                    resultLite.Add(itemLite);
                }
            }

            return Json(resultLite, JsonRequestBehavior.AllowGet);
        }
    }
}