﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.EC;
using Newegg.Flash.WWW.UI.UICommon.Sweepstakes;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class HomeController : FlashController
    {
        protected IHome HomeProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IHome>();
            }
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Index()
        {
            var result = HomeProcessor.Get(3, 5, 10, 5, 5);
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            //set default value
            ViewBag.SpecialStore = Globalization.Layout.Headline_SpecialStore;
            ViewBag.InTheSpotlight = Globalization.Layout.Headline_InTheSpotlight;
            ViewBag.FeaturedStore = Globalization.Layout.Headline_FeaturedStore;

            // 2015 06 02 by jason 本地化之后将移动到资源文件 
            //if (bizUI != null && bizUI.HeadlineConfig != null)
            //{

            //    if (!string.IsNullOrEmpty(bizUI.HeadlineConfig.SpecialStore)) ViewBag.SpecialStore = Globalization.Layout.Headline_SpecialStore;
            //    if (!string.IsNullOrEmpty(bizUI.HeadlineConfig.InTheSpotlight)) ViewBag.InTheSpotlight = Globalization.Layout.Headline_InTheSpotlight;
            //    if (!string.IsNullOrEmpty(bizUI.HeadlineConfig.FeaturedStore)) ViewBag.FeaturedStore = Globalization.Layout.Headline_FeaturedStore;
            //}

            if (!string.IsNullOrEmpty(this.Request.QueryString["url"]))
            {
                this.ViewBag.NeedLogin = this.Request.QueryString["url"];
            }

            this.ViewBag.SweepstakesInfo = SweepstakesHelper.Process();

            if (result != null)
            {
                if (result.UpcomingDeals != null)
                {
                    foreach (Deal item in result.UpcomingDeals.Items)
                    {
                        item.ItemPartialType = "upcoming";
                    }
                }
            }

            this.ViewBag.ShowItunesAPP = true;

            if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().SwithToNewegg)
            {
                ViewBag.InvitedToFriendUrl = string.Format(Url.BuildUrl(PageAliase.OutSite.NeweggCommonShare), (int)(CrossDomainActionEnum.InviteToFriend));
                ViewBag.ShareSweepstakesUrl = string.Format(Url.BuildUrl(PageAliase.OutSite.NeweggCommonShare), (int)(CrossDomainActionEnum.ShareSweepstakes));
                ViewBag.LogShareUrl = string.Format(Url.BuildUrl(PageAliase.OutSite.NeweggCommonShare), (int)(CrossDomainActionEnum.LogShare));
                ViewBag.SubscriptionUrl = string.Format(Url.BuildUrl(PageAliase.OutSite.NeweggCommonShare), (int)(CrossDomainActionEnum.EBlast));
            }
            else
            {
                ViewBag.InvitedToFriendUrl = Url.BuildUrl(PageAliase.OutSite.InviteFriend);
                ViewBag.ShareSweepstakesUrl = Url.BuildUrl(PageAliase.OutSite.ShareSweepstakes);
                ViewBag.LogShareUrl = Url.BuildUrl(PageAliase.OutSite.LogShareInfo);
                ViewBag.SubscriptionUrl = Url.BuildUrl(PageAliase.OutSite.SaveSubscription);
            }

            return View("Index", result);
        }

        [HttpGet]
        public ActionResult ComingSoon()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Subscribe(string email)
        {
            return Json(HomeProcessor.Subscribe(email));
        }


        public ActionResult AdvancedLinkLanding()
        {
            /*
             * Url:     http://www.newegg.com/Common/AdvancedLinkLanding.aspx?nm_mc=AFC-C8Junction&cm_mmc=AFC-C8Junction-_-na-_-na-_-na&AID=10446076&PID=1&URL=http%3A%2F%2Fwww.newegg.com%2FProduct%2FProduct.aspx%3FItem%3D9SIA3JC1CK3548
             * Params:  nm_mc=AFC-C8Junction
             *          cm_mmc=AFC-C8Junction-_-na-_-na-_-na
             *          AID=10446076
             *          PID=1
             *          URL=http%3A%2F%2Fwww.newegg.com%2FProduct%2FProduct.aspx%3FItem%3D9SIA3JC1CK3548             * 
             */

            var redirectUrl = Url.BuildUrl(PageAliase.Homepage);

            if (Request.QueryString["url"] != null)
            {
                redirectUrl = IsUnderNeweggAffiliateSites(Request.QueryString["url"])
                    ? Request.QueryString["url"]
                    : redirectUrl;
            }
            redirectUrl =
                Request.QueryString.AllKeys.Where(
                    key => String.Compare(key, "url", StringComparison.OrdinalIgnoreCase) != 0)
                    .Aggregate(redirectUrl,
                        (current, key) => Utility.AddQueryStringParam(current, key, Request.QueryString[key]));
            return Redirect(redirectUrl);
        }
    }
}
