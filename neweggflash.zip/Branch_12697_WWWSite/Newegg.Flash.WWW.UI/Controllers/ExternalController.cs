﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using Newegg.EC;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Common;
using System.Security.Cryptography;
using System.Text;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.Controllers
{
    /// <summary>
    /// External Controller
    /// <remarks>用于对外系统提供链接</remarks>
    /// </summary>
    public class ExternalController : FlashController
    {
        /// <summary>
        /// Landing 页面
        /// <remarks>对 kb.newegglfash.com 提供外链，View 里拼凑成javascript以js形式调用</remarks>
        /// </summary>
        /// <returns></returns>
        public ActionResult Landing()
        {
            ActionResult result = null;
            string actionString = this.Request.QueryString["action"];
            int action = 0;
            if (!int.TryParse(actionString, out action))
            {
                action = 99;
            }

            CrossDomainActionEnum actionType = CrossDomainActionEnum.ContactUs;

            if (Enum.IsDefined(typeof(CrossDomainActionEnum), action))
            {
                actionType = (CrossDomainActionEnum)(action);
            }

            switch (actionType)
            {
                case CrossDomainActionEnum.SubmitSweepstakes:
                    result = LandingNeweggSweepstakes();
                    break;
                case CrossDomainActionEnum.ContactUs:
                    result = View("Landing");
                    break;
                case CrossDomainActionEnum.Logout:
                    result = Redirect(Url.BuildUrl(PageAliase.Homepage));
                    break;
                default:
                    result = Redirect(Url.BuildUrl(PageAliase.Homepage));
                    break;
            }
            return result;
        }

        #region core landing

        private ActionResult LandingNeweggSweepstakes()
        {
            var queryString = this.Request.QueryString;
            var redirectUrl = string.Empty;
            var BackURL = queryString["backURL"];
            var source = Common.CommonUtility.DateTimeNow.ToString("yyyyMMddHHmmss");
            var paramByte = new MD5CryptoServiceProvider().ComputeHash(ASCIIEncoding.ASCII.GetBytes(source));
            var param = this.ByteArrayToHexString(paramByte);

            ////设置一个cookie，在WWW 首页的js中判定是否来自于sweepstakes，用以决定是否显示social share popup.
            var cookie = new SweepstakesIndicatorCookie { NFSIC = param };
            CookieHelper.SweepstakesCookie.SetCookieModel(cookie);

            if (BackURL.Contains("?"))
            {
                ////nfsst =  NeweggFlash SweepStakes Ticket.
                redirectUrl = BackURL + "&nfsst=" + param;
            }
            else
            {
                redirectUrl = BackURL + "?nfsst=" + param;
            }

            return Redirect(redirectUrl);
        }

        #endregion

        #region private method

        /// <summary>
        /// Compute byte array to hex string.
        /// </summary>
        /// <param name="arrInput">Input byte array.</param>
        /// <returns>Hex string.</returns>
        private string ByteArrayToHexString(byte[] arrInput)
        {
            int i;
            StringBuilder sb = new StringBuilder(arrInput.Length);
            for (i = 0; i < arrInput.Length - 1; i++)
            {
                sb.Append(arrInput[i].ToString("X2"));
            }

            return sb.ToString();
        }

        #endregion
    }
}
