﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.EC;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;

namespace Newegg.Flash.WWW.UI.Controllers
{
    public class TodayController : FlashController
    {
        protected IToday TodayProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IToday>();
            }
        }

        //
        // GET: /Today/
        [HttpGet]
        [CrawlerDetection]
        public ActionResult Index()
        {
            var model = TodayProcessor.Get();
            var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
            if (seoInfo != null && seoInfo.Today != null)
            {
                RenderSEOInfo(seoInfo.Today);
            }

            return View(model);
        }

    }
}
