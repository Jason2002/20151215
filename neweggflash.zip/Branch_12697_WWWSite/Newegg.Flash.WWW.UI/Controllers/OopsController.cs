﻿using System;
using System.Web.Mvc;
using Newegg.EC;
using Newegg.EC.Log;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Globalization;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.UI.Filters;

namespace Newegg.Flash.WWW.UI.Controllers
{
    [RegionChangeFilterAttribute(RedirectKey = "cc", RedirectValue = "t")]
    public class OopsController : FlashController
    {
        //
        // GET: /OOPS/
        [HttpGet]
        public ActionResult Index()
        {
            var statusCode = Request.QueryString["code"] ?? string.Empty;
            ViewData["StatusCode"] = statusCode;
            ViewData["HiddenMenuAndBar"] = true;
            return View();
        }

        public ActionResult Message()
        {
            var statusCode = Request.QueryString["code"] ?? "403";

            this.ViewBag.ErrorMessage = Oops.OopsInfo_NoteCrawler403.Replace("#IP#", Newegg.Framework.Web.WebUtility.ReferenceIP());

            if (false)
            {
                this.ViewBag.ReturnUrl = Url.BuildUrl(PageAliase.Homepage);
            }

            return View();
        }

        /// <summary>
        /// Render tealium script in the page.
        /// </summary>
        /// <param name="filterContext">Action executed context.</param>
        protected override void OnActionExecuted(System.Web.Mvc.ActionExecutedContext filterContext)
        {
            var trackingContext = new TrackingContext
            {
                ExecutedContext = filterContext,
                ViewData = this.ViewData,
                UserInfo = this.ViewBag.UserInfo,
                TempData = this.TempData,
                ViewBag = this.ViewBag
            };

            try
            {
                var trackingScrpit = TrackingInfoBuilder.Build(trackingContext);

                this.ViewData[TrackingInfoBuilder.TrakingKey] = trackingScrpit;
            }
            catch (Exception ex)
            {
                var log = ECLibraryContainer.Current.GetInstance<ILogger>();
                if (log != null)
                {
                    try
                    {
                        log.Exception = ex;
                        log.AddCategory("Newegg.Flash");
                        log.AddMessage("Third party integration");
                        log.Write();
                    }
                    catch
                    {
                    }
                }
            }

            base.OnActionExecuted(filterContext);
        }

    }
}
