﻿using System.Web.Mvc;

using Newegg.EC.Web.Mvc;
using Newegg.EC.Cookie;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;

namespace Newegg.Flash.WWW.UI.Controllers
{
    /// <summary>
    /// Login controller.
    /// </summary>
    public class CustomerController : FlashController
    {
        /// <summary>
        /// Sign out current user.
        /// </summary>
        /// <returns>Action result.</returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult CustomerSignOut()
        {
            ////Cookie改造 by az08
            this.CurrentLoginUser.ClearAllCookie();
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (bizUI != null && !bizUI.SwithToNewegg)
            {
                CookieHelper.OtherInfoCookie.SetCookieModel(this.CurrentLoginUser);
                ////如果用户sign out，那么将所有的promotionCode cookie清空。 added by ky54
                CookieHelper.ShoppingCookie.SetPromotionCodeList(null);
                CookieHelper.ShoppingCookie.SetGiftCardList(null);

                return this.RedirectToAction("Index", "home");
            }
            else
            {
                return new RedirectResult(string.Format(Url.BuildUrl(Newegg.Flash.WWW.Common.PageAliase.OutSite.NeweggCommonShare),(int)(CrossDomainActionEnum.Logout)));
            }
        }
    }
}