﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.EC;
using Newegg.EC.Cookie;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Implement;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Interface.Search;
using Newegg.Flash.WWW.Interface.SpecialStore;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.UI.UICommon;
using Newegg.Flash.WWW.UI.UICommon.CrawlerDetection;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;


namespace Newegg.Flash.WWW.UI.Controllers
{
    public class SpecialStoreController : FlashController
    {
        protected ISpecialStore SpecialStoreProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<ISpecialStore>();
            }
        }

        [HttpGet]
        [SiteCatalyst(typeof(ConfigurableHeadlineProcessor))]
        [Tealium(typeof(TealiumConfigurableHeadlineProcessor))]
        [CrawlerDetection]
        public ActionResult Index()
        {
            var model = SpecialStoreProcessor.Get(1, 20);
            var bizUI =  ConfigurationWWWManager<BizUI>.ItemCfg();
            var headline = Globalization.Layout.Headline_SpecialStore;
            //if (bizUI != null && bizUI.HeadlineConfig != null && !string.IsNullOrEmpty(bizUI.HeadlineConfig.SpecialStore))
            //{
            //    headline = bizUI.HeadlineConfig.SpecialStore;
            //}
            ViewBag.Headline = headline;
            model.Navgations = new List<NavgationItem>()
            {
                new NavgationItem()
                {
                    Name = "Home",
                    Url = Url.BuildUrl(PageAliase.Homepage)
                },
                new NavgationItem()
                {
                    Name = headline
                }
            };
            return View(model);
        }

        [HttpGet]
        [CrawlerDetection]
        public ActionResult Paging(int pageIndex, int pageSize)
        {
            var model = SpecialStoreProcessor.Get(pageIndex, pageSize);
            if (model == null)
                model = new GeneralDeals();
            if (model.Deals == null)
                model.Deals = new List<Deal>();
            return View("_SpecialStoreList", model);
        }

    }
}
