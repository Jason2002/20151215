﻿using Newegg.Flash.WWW.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newegg.EC.Web.Mvc;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon;

namespace Newegg.Flash.WWW.UI.Filters
{
    public class RegionChangeFilterAttribute : ActionFilterAttribute
    {
        public string RedirectKey { get; set; }

        public string RedirectValue { get; set; }

        public bool IsProduct{ get; set; }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var request = filterContext.RequestContext.HttpContext.Request;
            var key = RedirectKey.Trim().ToLower();
            var value = RedirectValue.Trim().ToLower();
            if (request.QueryString[key] != null && value.Equals(request.QueryString[key].ToLower()))
            {
                if (IsProduct && "index".Equals(request.RequestContext.RouteData.Values["action"].ToString().ToLower()))
                {
                    // url comes from Region change
                    var items =((Newegg.Flash.WWW.Model.ItemGroup)(filterContext.Controller.ViewData.Model)).Items;
                    if (items == null || items.Count == 0)
                    {
                        var redirectURL = request.Url.AbsoluteUri;

                        var id = string.Empty;
                        if (request.RequestContext.RouteData.Values.Keys.Contains("id"))
                        {
                            id = request.RequestContext.RouteData.Values["id"].ToString();

                            id = ItemNumberConvert.NeweggItemNumber2ItemNumber(id);
                            var searchUrl = Utility.WebHostWithScheme() + new ClientEvirment().GlobalPath.TrimEnd('/')
                                            + "/" + PageAliase.Search + "?keyword=" + id;
                            filterContext.Result = new RedirectResult(searchUrl);
                        }
                    }
                }
            }
            base.OnActionExecuted(filterContext);
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var request = filterContext.RequestContext.HttpContext.Request;
            var key = RedirectKey.Trim().ToLower();
            var value = RedirectValue.Trim().ToLower();
         
            // url comes from Region change
            if (request.QueryString[key] != null && value.Equals(request.QueryString[key].ToLower()))
            {
                if (!IsProduct) 
                {
                    filterContext.RequestContext.HttpContext.Response.Clear();
                    filterContext.RequestContext.HttpContext.Server.ClearError();
                    filterContext.Result = new RedirectResult(Utility.WebHostWithScheme());
                }
            }
        }
    }
}