﻿using System;
using System.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon;

namespace Newegg.Flash.WWW.UI.Filters
{
    public class FlashCookieFilterAttribute : ActionFilterAttribute
    {
        #region IActionFilter Members

        public bool NoCookie { get; set; }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            if (!NoCookie)
            {
                CookieHelper.FlushToResponse();
            }
            else
            {
                filterContext.HttpContext.Response.Cookies.Clear();    
            }
            base.OnResultExecuted(filterContext);
        }        


        #endregion
    }
}
