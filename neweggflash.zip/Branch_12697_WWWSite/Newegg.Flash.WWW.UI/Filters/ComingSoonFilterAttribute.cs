﻿using System;
using System.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.UICommon;

namespace Newegg.Flash.WWW.UI.Filters
{
    public class ComingSoonFilterAttribute : ActionFilterAttribute
    {
        #region IActionFilter Members
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            var comingSoon = bizUI.ComingSoon;
            if (comingSoon != null && comingSoon.Enable && comingSoon.LaunchTime>Common.CommonUtility.DateTimeNow)
            {
                var customeIP = Utility.ReferenceIP();
                if (!(comingSoon.InternalIP != null && comingSoon.InternalIP.IP != null && comingSoon.InternalIP.IP.Contains(customeIP)) && !string.IsNullOrWhiteSpace(comingSoon.PageUrl))
                {
                    filterContext.Result = new RedirectResult(comingSoon.PageUrl);
                }
            }
        }

        #endregion
    }
}
