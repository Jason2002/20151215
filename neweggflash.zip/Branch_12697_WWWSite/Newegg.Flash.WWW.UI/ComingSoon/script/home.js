jQuery(document).ready(function(){
	//banner
	$('#Banner').Slider({
		AutoSlide: true,
		Duration: 4000,
		ShowThumbnail: true,
		AllwaysShow: true
	});
	//box slider
	$('.boxA_wrap').Slider();
	$('.boxA .info p').ellipsis();
	
	$('#SubscribeBtn').click(function(){
		var txtObj = $("#SubscribeBox");
		if(emptyChk(".subscribeBox", ".form_Email")){
			if (!checkEmail(txtObj.val())) {
				errSet(txtObj.parent(), "Please check your email.");
				boolSubmit = false;
			} else {
				$('.subscribeBox .iePlaceholder').hide();
				$('.subscribeBox .successMsg').show();
			}
		}
	});
	$(window).resize(function(){
		var  popLoginTop = $('#PopLogin').outerHeight(true) > $(window).height() ? 50 : ($(window).height() - $('#PopLogin').outerHeight(true)) / 2,
			 popRegTop = $('#PopRegister').outerHeight(true) > $(window).height() ? 50 : ($(window).height() - $('#PopLogin').outerHeight(true)) / 2;
		$('#PopLogin').css({
			left: ($(window).width() - 490) / 2,
			top: popLoginTop
		});
		$('#PopRegister').css({
			left: ($(window).width() - 490) / 2,
			top: popRegTop
		});
	});
});