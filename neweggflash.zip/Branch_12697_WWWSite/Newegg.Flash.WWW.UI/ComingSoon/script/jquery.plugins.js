/*
 * Swipe 1.0
 *
 * Brad Birdsall, Prime
 * Copyright 2011, Licensed GPL & MIT
 *
*/
window.Swipe = function(element, options) {

  // return immediately if element doesn't exist
  if (!element) return null;

  var _this = this;

  // retreive options
  this.options = options || {};
  this.index = this.options.startSlide || 0;
  this.speed = this.options.speed || 300;
  this.callback = this.options.callback || function() {};
  this.delay = this.options.auto || 0;

  // reference dom elements
  this.container = element;
  this.element = this.container.children[0]; // the slide pane

  // static css
  this.container.style.overflow = 'hidden';
  this.element.style.listStyle = 'none';
  this.element.style.margin = 0;

  // trigger slider initialization
  this.setup();

  // begin auto slideshow
  this.begin();

  // add event listeners
  if (this.element.addEventListener) {
    this.element.addEventListener('touchstart', this, false);
    this.element.addEventListener('touchmove', this, false);
    this.element.addEventListener('touchend', this, false);
    this.element.addEventListener('touchcancel', this, false);
    this.element.addEventListener('webkitTransitionEnd', this, false);
    this.element.addEventListener('msTransitionEnd', this, false);
    this.element.addEventListener('oTransitionEnd', this, false);
    this.element.addEventListener('transitionend', this, false);
    window.addEventListener('resize', this, false);
  }
};

Swipe.prototype = {
  setup: function() {

    // get and measure amt of slides
    this.slides = this.element.children;
    this.length = this.slides.length;

    // return immediately if their are less than two slides
    if (this.length < 2) return null;

    // determine width of each slide
    this.width = Math.ceil(("getBoundingClientRect" in this.container) ? this.container.getBoundingClientRect().width : this.container.offsetWidth);

    // Fix width for Android WebView (i.e. PhoneGap) 
    if (this.width === 0 && typeof window.getComputedStyle === 'function') {
      this.width = window.getComputedStyle(this.container, null).width.replace('px','');
    }

    // return immediately if measurement fails
    if (!this.width) return null;

    // hide slider element but keep positioning during setup
    var origVisibility = this.container.style.visibility;
    this.container.style.visibility = 'hidden';

    // dynamic css
    this.element.style.width = Math.ceil(this.slides.length * this.width) + 'px';
    var index = this.slides.length;
    while (index--) {
      var el = this.slides[index];
      el.style.width = this.width + 'px';
      el.style.display = 'table-cell';
      el.style.verticalAlign = 'top';
    }

    // set start position and force translate to remove initial flickering
    this.slide(this.index, 0); 

    // restore the visibility of the slider element
    this.container.style.visibility = origVisibility;

  },

  slide: function(index, duration) {

    var style = this.element.style;

    // fallback to default speed
    if (duration == undefined) {
        duration = this.speed;
    }

    // set duration speed (0 represents 1-to-1 scrolling)
    style.webkitTransitionDuration = style.MozTransitionDuration = style.msTransitionDuration = style.OTransitionDuration = style.transitionDuration = duration + 'ms';

    // translate to given index position
    style.MozTransform = style.webkitTransform = 'translate3d(' + -(index * this.width) + 'px,0,0)';
    style.msTransform = style.OTransform = 'translateX(' + -(index * this.width) + 'px)';

    // set new index to allow for expression arguments
    this.index = index;

  },

  getPos: function() {
    
    // return current index position
    return this.index;

  },

  prev: function(delay) {

    // cancel next scheduled automatic transition, if any
    this.delay = delay || 0;
    clearTimeout(this.interval);

    if (this.index) this.slide(this.index-1, this.speed); // if not at first slide
    else this.slide(this.length - 1, this.speed); //if first slide return to end

  },

  next: function(delay) {

    // cancel next scheduled automatic transition, if any
    this.delay = delay || 0;
    clearTimeout(this.interval);

    if (this.index < this.length - 1) this.slide(this.index+1, this.speed); // if not last slide
    else this.slide(0, this.speed); //if last slide return to start

  },

  begin: function() {

    var _this = this;

    this.interval = (this.delay)
      ? setTimeout(function() { 
        _this.next(_this.delay);
      }, this.delay)
      : 0;
  
  },
  
  stop: function() {
    this.delay = 0;
    clearTimeout(this.interval);
  },
  
  resume: function() {
    this.delay = this.options.auto || 0;
    this.begin();
  },

  handleEvent: function(e) {
    switch (e.type) {
      case 'touchstart': this.onTouchStart(e); break;
      case 'touchmove': this.onTouchMove(e); break;
      case 'touchcancel' :
      case 'touchend': this.onTouchEnd(e); break;
      case 'webkitTransitionEnd':
      case 'msTransitionEnd':
      case 'oTransitionEnd':
      case 'transitionend': this.transitionEnd(e); break;
      case 'resize': this.setup(); break;
    }
  },

  transitionEnd: function(e) {
    
    if (this.delay) this.begin();

    this.callback(e, this.index, this.slides[this.index]);

  },

  onTouchStart: function(e) {
    
    this.start = {

      // get touch coordinates for delta calculations in onTouchMove
      pageX: e.touches[0].pageX,
      pageY: e.touches[0].pageY,

      // set initial timestamp of touch sequence
      time: Number( new Date() )

    };

    // used for testing first onTouchMove event
    this.isScrolling = undefined;
    
    // reset deltaX
    this.deltaX = 0;

    // set transition time to 0 for 1-to-1 touch movement
    this.element.style.MozTransitionDuration = this.element.style.webkitTransitionDuration = 0;
    
    e.stopPropagation();
  },

  onTouchMove: function(e) {

    // ensure swiping with one touch and not pinching
    if(e.touches.length > 1 || e.scale && e.scale !== 1) return;

    this.deltaX = e.touches[0].pageX - this.start.pageX;

    // determine if scrolling test has run - one time test
    if ( typeof this.isScrolling == 'undefined') {
      this.isScrolling = !!( this.isScrolling || Math.abs(this.deltaX) < Math.abs(e.touches[0].pageY - this.start.pageY) );
    }

    // if user is not trying to scroll vertically
    if (!this.isScrolling) {

      // prevent native scrolling 
      e.preventDefault();

      // cancel slideshow
      clearTimeout(this.interval);

      // increase resistance if first or last slide
      this.deltaX = 
        this.deltaX / 
          ( (!this.index && this.deltaX > 0               // if first slide and sliding left
            || this.index == this.length - 1              // or if last slide and sliding right
            && this.deltaX < 0                            // and if sliding at all
          ) ?                      
          ( Math.abs(this.deltaX) / this.width + 1 )      // determine resistance level
          : 1 );                                          // no resistance if false
      
      // translate immediately 1-to-1
      this.element.style.MozTransform = this.element.style.webkitTransform = 'translate3d(' + (this.deltaX - this.index * this.width) + 'px,0,0)';
      
      e.stopPropagation();
    }

  },

  onTouchEnd: function(e) {

    // determine if slide attempt triggers next/prev slide
    var isValidSlide = 
          Number(new Date()) - this.start.time < 250      // if slide duration is less than 250ms
          && Math.abs(this.deltaX) > 20                   // and if slide amt is greater than 20px
          || Math.abs(this.deltaX) > this.width/2,        // or if slide amt is greater than half the width

    // determine if slide attempt is past start and end
        isPastBounds = 
          !this.index && this.deltaX > 0                          // if first slide and slide amt is greater than 0
          || this.index == this.length - 1 && this.deltaX < 0;    // or if last slide and slide amt is less than 0

    // if not scrolling vertically
    if (!this.isScrolling) {

      // call slide function with slide end value based on isValidSlide and isPastBounds tests
      this.slide( this.index + ( isValidSlide && !isPastBounds ? (this.deltaX < 0 ? 1 : -1) : 0 ), this.speed );

    }
    
    e.stopPropagation();
  }
};
/*
 * Platform
 * Trey.Y.Liu@Newegg.com
 */
;(function($){ 
	jQuery.extend({
		//Browser Version
		IsIE: function(version){
			var agent = navigator.userAgent.toLowerCase();
			if(version) {
				switch (version) {
					case 6 :
						return agent.indexOf('msie 6.0') > 0;
					case 7 :
						return agent.indexOf('msie 7.0') > 0;
					case 8 :
						return agent.indexOf('msie 8.0') > 0;
					case 9 :
						return agent.indexOf('msie 9.0') > 0;
					case 10:
						return agent.indexOf('msie 10.0') > 0;
				}
			} else {
				return agent.indexOf('msie') > 0;
			}
		},
		//Is tablet
		IsTouchMedia: function(){
			var userAgentInfo = navigator.userAgent; 
			var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"); 
			var flag = false; 
			for (var i = 0; i < Agents.length; i++) { 
				if (userAgentInfo.indexOf(Agents[i]) > 0) { flag = true; break; } 
			} 
			return flag; 
		},
		MaskBox: function(opacity){
			var height,
				maskBox = $('<div class="maskBox popupMaskBox"></div>');
			/*if($.IsTouchMedia()){
				height = document.body.getBoundingClientRect().height + document.body.getBoundingClientRect().top;
				maskBox.css({
					position: 'absolute',
					height: height
				})
			}*/
			maskBox.css({
				opacity: !isNaN(parseFloat(opacity))? opacity : 0.4
			})
			$('body').append(maskBox);
		}
	});
})(jQuery); 
/*
 * Slider and banner
 * Trey.Y.Liu@Newegg.com
 */
;(function($){ 
	$.fn.extend({
		/*
		 * Slider
		 */
		Slider: function(options) {
			if($.IsTouchMedia()) {
				var defaults = { }
				var options =  $.extend(defaults, options);
				return this.each(function() {
					this.o = options;
					this.imgs = $(this).find('img');
					var _this = this;
					if(this.imgs.length < 2) return;
					this.thumbnail = $('<div class="thumbnail"></div>');
					for(var i = 0; i < this.imgs.length; i++) {
						$('<span index=' + i + '></span>').appendTo(this.thumbnail)
					}
					this.thumbnail.appendTo($(this)).find('span:eq(0)').addClass('current');
					slider = new Swipe(this ,{
						startSlide: 0,
						speed: 400,
						auto: this.o.Duration,
						callback: function(event, index, element) {
							_this.thumbnail.appendTo($(_this)).find('span:eq(' + index + ')').addClass('current').siblings().removeClass('current');
						}
					});
				});
			} else {
				var defaults = {  
					AutoSlide: false,
					Duration: 3000,
					Speed: 180,
					ShowThumbnail: false,
					AllwaysShow: false,
					Style: null
				}
				var options =  $.extend(defaults, options);
				
				return this.each(function() {
					if(typeof this != 'object') return false;
					
					this.o = options;
					this.a = $(this).find('>a');
					this.wrap = this.a.find('>.wrap');
					this.ul = $(this).find('ul.sliders');
					this.imgs = $(this).find('img');
					this.price = $(this).find('.price');
					this.saleTime = $(this).find('.sale_time');
					this.fullTitle = $(this).find('h3').text();
					this.info = $(this).find('.info');
					this.description = $(this).find('.info p').text();
					this.infoHeight = this.info.outerHeight(true);
					this.isInserted = false;
					
					//on pc browser
					if($.IsIE(7) || $.IsIE(8)) this.ul.css('height', this.imgs.height())
					
					this.Pause =  function(){
						this.timer = false;
					}
					this.Begin = function(){
						this.timer = true;
					}
					
					if(options.AutoSlide) {
						CreatCanvas(this);
						this.Begin();
						AutoSlide(this);
					}
					
					$(this).hover(function(){
						mouseover(this);
						this.Pause();
					},function(){
						mouseout(this);
						this.Begin();
					});
					var _this = this;
					$(window).resize(function(){
						var width, height;
						if(!_this.ul) {
							height = _this.imgs.height();
						} else {
							height = _this.ul.height();
						}
						if($.IsIE(7) || $.IsIE(8)) _this.ul.css('height', _this.imgs.height());
					});
				});
			}
			function AutoSlide(_this) {
				setTimeout(function(){
					if(_this.timer) {
						_this.next[0].click();
					}
					AutoSlide(_this);
				}, _this.o.Duration);
			}
			
			function mouseover(_this){
				var speed = _this.o.Speed;
				if(_this.o.Style == 'small') {
					_this.isSlide = false;
					if(!_this.isInserted) {
						CreatCanvas(_this);
					}
					if(!_this.box.is(':animated') &&
						!_this.wrap.is(':animated')) {
						_this.box.animate({
							bottom: 0
						}, speed);
						_this.wrap.animate({
							top: -_this.a.outerHeight(true)
						}, speed);
					}
				} else { // base style
					if(_this.imgs.length < 2) {
						_this.isSlide = false;
						if(!_this.saleTime.is(':animated')) {
							_this.saleTime.animate({
								bottom: _this.info.outerHeight(true)
							}, speed);
						}
					} else {
						_this.isSlide = true;
						if(!_this.isInserted) {
							CreatCanvas(_this);
						}
						if(!_this.prev.is(':animated') && 
							!_this.next.is(':animated') && 
							!_this.saleTime.is(':animated')) {
							_this.prev.css('top', top).clearQueue().stop()
							.animate({
								left: 0
							}, speed);
							_this.next.css('top', top).clearQueue().stop()
							.animate({
								right: 0
							}, speed);
							_this.saleTime.clearQueue().stop()
							.animate({
								bottom: _this.info.outerHeight(true)
							}, speed);
						}
					}
				}
			}
			
			function mouseout(_this){
				var speed = _this.o.Speed;
				if(_this.o.Style == 'small') {
					_this.box.clearQueue().stop()
					.animate({
							bottom: -_this.box.outerHeight(true)
						}, speed);
					_this.wrap.clearQueue().stop()
					.animate({
							top: 0
						}, speed);
				} else {
					if(_this.isSlide) {
						_this.prev.clearQueue().stop()
						.animate({
								left: -40
							}, speed);
						_this.next.clearQueue().stop()
						.animate({
								right: -40
							}, speed, function(){
								if(!_this.o.AllwaysShow) {
									_this.next.remove();
									_this.prev.remove();
									_this.slider.remove();
									_this.isInserted = false;
								} else {
									_this.isInserted = true;
								}
							});
					}
					_this.saleTime.clearQueue().stop()
					.animate({
							bottom: -_this.infoHeight
						}, speed);
				}
			}
			
			function CreatCanvas(_this) {
				var	width = _this.ul.width(),
					height = _this.imgs.outerHeight(true),
					top = ((height < 280 ? 280 : height) - 80) * 0.5, imgs1;
				if(_this.imgs.length > 1) {//banner and activity box
					_this.next = $('<div class="slide_next"></div>');
					_this.prev = $('<div class="slide_prev"></div>');
					_this.slider = $('<div class="slide_box"></div>');
					_this.thumbnail = $('<div class="thumbnail"></div>');
					
					_this.card = $('<div class="slide_wrap">\
								<a class="imgs fix" href="#" style="width:' + width * _this.imgs.length * 2 + 'px;height:' + height + 'px">\
								</a></div>');
					var imgs1 = [];
					for(var i = 0; i < _this.imgs.length; i++) {
						imgs1.push('<img style="width:' + width + 'px;" src="' + _this.imgs[i].src + '" />');
						$('<span index=' + i + '></span>').appendTo(_this.thumbnail)
						.click(function(){ 
							var from = $(_this).find('span.current').index(),
								to = $(this).index();
								step = to - from;
							if(step != 0) {
								Slider(_this, _this.card.find('a'), step);
							}
						});
					}
					var imgs2 = imgs1.slice(0);
					var imgs = imgs2.concat(imgs1);
					var left = -width * (imgs2.length);
					$(imgs).appendTo(_this.card.find('a').css('left', left + "px"));
					
					_this.slideIndex = 0;
					_this.setpWidth = width;
				
					_this.card.appendTo(_this.slider);
					_this.next.css('top', top).appendTo($(_this));
					_this.prev.css('top', top).appendTo($(_this));
					if(_this.o.ShowThumbnail) {
						_this.thumbnail.appendTo($(_this));
						_this.thumbnail.find('span:eq(0)').addClass('current');
					}
					_this.slider.appendTo($(_this)).show();
					
					if(_this.a.attr('href')) {
						_this.card.find('a').attr('href', _this.a.attr('href'));
					} else {
						var index = $(_this).find('span.current').index();
						_this.card.find('a').attr('href', $(_this.imgs[index]).parent().attr('href'));
					}
					
					if(!_this.prev.is(':animated') && 
						!_this.next.is(':animated')) {
						_this.prev.click(function(){
							Slider(_this, _this.card.find('a'), -1);
						});
						_this.next.click(function(){
							Slider(_this, _this.card.find('a'), 1);
						});
					}
				}
				if(_this.o.Style == 'small') {
					var isActivity = $(_this).find('.price').clone()[0] ? false : true;
					var title = $('<div class="fullTitle">' + _this.fullTitle + '</div>');
					var wrap = $('<div class="wrap"></div>');
					var smallImg = $('<img src="' + _this.imgs[0].src + '">');
					_this.box = $('<div class="boxA_info"></div>');
					wrap.append(smallImg);
					wrap.append(_this.price.clone());
					wrap.append(title);
					if(isActivity) {
						var description = $('<p>' + _this.description + '</p>');
						description.css('margin-bottom', '8px');
						wrap.append(description);
						title.css('max-height', '63px');
					}
					_this.box.append(wrap);
					wrap.append(_this.saleTime.clone().removeClass().addClass('endTime'));
					_this.box.css({
						border: '1px solid #e8e8e8',
						width: _this.a.width()  - 40,
						height: _this.a.height() - 42
					}).appendTo(_this.a)
				}
				_this.isInserted = true;
				
				$(window).resize(function(){
					width = _this.ul.width(),
					height = _this.ul.height();
					top = (height - 80) * 0.5, imgs1;
					if(_this.card) {
						_this.card.find('a').css({
							left: -width * ( _this.imgs.length  + _this.slideIndex ),
							width: width * _this.imgs.length * 2,
							height: '100%'
						}).find('img').css({
							width: width
						});
					}
					if(_this.box) {
						_this.box.css({
							bottom: -_this.box.outerHeight(true),
							width: _this.a.width()  - 40,
							height: _this.a.height() - 40
						});
					}
					_this.setpWidth = width;
					if(_this.next) {
						_this.next.css('top', top);
					}
					if(_this.prev) {
						_this.prev.css('top', top);
					}
				});
			}
			
			function Slider(_this, ele, step) {
				if(!ele.is(':animated')) {
					_this.slideIndex = _this.slideIndex + step;
					var slideIndex = _this.slideIndex,
						count = _this.imgs.length,
						width = _this.setpWidth,
						step;
					ele.animate({
						left: ( step < 0 ? '+=' : '-=' ) + width * Math.abs(step)
					}, 200, function(){
						if(slideIndex == -count + 1) {
							ele.css('left', -width * (count + 1) + 'px')
							_this.slideIndex = 1;
						}
						if(slideIndex == count - 1) {
							ele.css('left', -width * (count - 1) + 'px')
							_this.slideIndex = -1;
						}
						var index = slideIndex < 0 ? slideIndex + count : slideIndex;
						_this.thumbnail.find('span:eq(' + index + ')').addClass('current')
						.siblings().removeClass();
						_this.card.find('a').attr('href', $(_this.imgs[index]).parents('a').attr('href'));
					});
				}
			}
		}
    });
})(jQuery); 

/**
 * Copyright (c) 2007-2012 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
 * Dual licensed under MIT and GPL.
 * @author Ariel Flesler
 * @version 1.4.3.1
 */
;(function($){var h=$.scrollTo=function(a,b,c){$(window).scrollTo(a,b,c)};h.defaults={axis:'xy',duration:parseFloat($.fn.jquery)>=1.3?0:1,limit:true};h.window=function(a){return $(window)._scrollable()};$.fn._scrollable=function(){return this.map(function(){var a=this,isWin=!a.nodeName||$.inArray(a.nodeName.toLowerCase(),['iframe','#document','html','body'])!=-1;if(!isWin)return a;var b=(a.contentWindow||a).document||a.ownerDocument||a;return/webkit/i.test(navigator.userAgent)||b.compatMode=='BackCompat'?b.body:b.documentElement})};$.fn.scrollTo=function(e,f,g){if(typeof f=='object'){g=f;f=0}if(typeof g=='function')g={onAfter:g};if(e=='max')e=9e9;g=$.extend({},h.defaults,g);f=f||g.duration;g.queue=g.queue&&g.axis.length>1;if(g.queue)f/=2;g.offset=both(g.offset);g.over=both(g.over);return this._scrollable().each(function(){if(e==null)return;var d=this,$elem=$(d),targ=e,toff,attr={},win=$elem.is('html,body');switch(typeof targ){case'number':case'string':if(/^([+-]=)?\d+(\.\d+)?(px|%)?$/.test(targ)){targ=both(targ);break}targ=$(targ,this);if(!targ.length)return;case'object':if(targ.is||targ.style)toff=(targ=$(targ)).offset()}$.each(g.axis.split(''),function(i,a){var b=a=='x'?'Left':'Top',pos=b.toLowerCase(),key='scroll'+b,old=d[key],max=h.max(d,a);if(toff){attr[key]=toff[pos]+(win?0:old-$elem.offset()[pos]);if(g.margin){attr[key]-=parseInt(targ.css('margin'+b))||0;attr[key]-=parseInt(targ.css('border'+b+'Width'))||0}attr[key]+=g.offset[pos]||0;if(g.over[pos])attr[key]+=targ[a=='x'?'width':'height']()*g.over[pos]}else{var c=targ[pos];attr[key]=c.slice&&c.slice(-1)=='%'?parseFloat(c)/100*max:c}if(g.limit&&/^\d+$/.test(attr[key]))attr[key]=attr[key]<=0?0:Math.min(attr[key],max);if(!i&&g.queue){if(old!=attr[key])animate(g.onAfterFirst);delete attr[key]}});animate(g.onAfter);function animate(a){$elem.animate(attr,f,g.easing,a&&function(){a.call(this,e,g)})}}).end()};h.max=function(a,b){var c=b=='x'?'Width':'Height',scroll='scroll'+c;if(!$(a).is('html,body'))return a[scroll]-$(a)[c.toLowerCase()]();var d='client'+c,html=a.ownerDocument.documentElement,body=a.ownerDocument.body;return Math.max(html[scroll],body[scroll])-Math.min(html[d],body[d])};function both(a){return typeof a=='object'?a:{top:a,left:a}}})(jQuery);

/*
	Masked Input plugin for jQuery
	Copyright (c) 2007-2011 Josh Bush (digitalbush.com)
	Licensed under the MIT license (http://digitalbush.com/projects/masked-input-plugin/#license) 
	Version: 1.3
*/
;(function(a){var b=(a.browser.msie?"paste":"input")+".mask",c=window.orientation!=undefined;a.mask={definitions:{9:"[0-9]",a:"[A-Za-z]","*":"[A-Za-z0-9]"},dataName:"rawMaskFn"},a.fn.extend({caret:function(a,b){if(this.length!=0){if(typeof a=="number"){b=typeof b=="number"?b:a;return this.each(function(){if(this.setSelectionRange)this.setSelectionRange(a,b);else if(this.createTextRange){var c=this.createTextRange();c.collapse(!0),c.moveEnd("character",b),c.moveStart("character",a),c.select()}})}if(this[0].setSelectionRange)a=this[0].selectionStart,b=this[0].selectionEnd;else if(document.selection&&document.selection.createRange){var c=document.selection.createRange();a=0-c.duplicate().moveStart("character",-1e5),b=a+c.text.length}return{begin:a,end:b}}},unmask:function(){return this.trigger("unmask")},mask:function(d,e){if(!d&&this.length>0){var f=a(this[0]);return f.data(a.mask.dataName)()}e=a.extend({placeholder:"_",completed:null},e);var g=a.mask.definitions,h=[],i=d.length,j=null,k=d.length;a.each(d.split(""),function(a,b){b=="?"?(k--,i=a):g[b]?(h.push(new RegExp(g[b])),j==null&&(j=h.length-1)):h.push(null)});return this.trigger("unmask").each(function(){function v(a){var b=f.val(),c=-1;for(var d=0,g=0;d<k;d++)if(h[d]){l[d]=e.placeholder;while(g++<b.length){var m=b.charAt(g-1);if(h[d].test(m)){l[d]=m,c=d;break}}if(g>b.length)break}else l[d]==b.charAt(g)&&d!=i&&(g++,c=d);if(!a&&c+1<i)f.val(""),t(0,k);else if(a||c+1>=i)u(),a||f.val(f.val().substring(0,c+1));return i?d:j}function u(){return f.val(l.join("")).val()}function t(a,b){for(var c=a;c<b&&c<k;c++)h[c]&&(l[c]=e.placeholder)}function s(a){var b=a.which,c=f.caret();if(a.ctrlKey||a.altKey||a.metaKey||b<32)return!0;if(b){c.end-c.begin!=0&&(t(c.begin,c.end),p(c.begin,c.end-1));var d=n(c.begin-1);if(d<k){var g=String.fromCharCode(b);if(h[d].test(g)){q(d),l[d]=g,u();var i=n(d);f.caret(i),e.completed&&i>=k&&e.completed.call(f)}}return!1}}function r(a){var b=a.which;if(b==8||b==46||c&&b==127){var d=f.caret(),e=d.begin,g=d.end;g-e==0&&(e=b!=46?o(e):g=n(e-1),g=b==46?n(g):g),t(e,g),p(e,g-1);return!1}if(b==27){f.val(m),f.caret(0,v());return!1}}function q(a){for(var b=a,c=e.placeholder;b<k;b++)if(h[b]){var d=n(b),f=l[b];l[b]=c;if(d<k&&h[d].test(f))c=f;else break}}function p(a,b){if(!(a<0)){for(var c=a,d=n(b);c<k;c++)if(h[c]){if(d<k&&h[c].test(l[d]))l[c]=l[d],l[d]=e.placeholder;else break;d=n(d)}u(),f.caret(Math.max(j,a))}}function o(a){while(--a>=0&&!h[a]);return a}function n(a){while(++a<=k&&!h[a]);return a}var f=a(this),l=a.map(d.split(""),function(a,b){if(a!="?")return g[a]?e.placeholder:a}),m=f.val();f.data(a.mask.dataName,function(){return a.map(l,function(a,b){return h[b]&&a!=e.placeholder?a:null}).join("")}),f.attr("readonly")||f.one("unmask",function(){f.unbind(".mask").removeData(a.mask.dataName)}).bind("focus.mask",function(){m=f.val();var b=v();u();var c=function(){b==d.length?f.caret(0,b):f.caret(b)};(a.browser.msie?c:function(){setTimeout(c,0)})()}).bind("blur.mask",function(){v(),f.val()!=m&&f.change()}).bind("keydown.mask",r).bind("keypress.mask",s).bind(b,function(){setTimeout(function(){f.caret(v(!0))},0)}),v()})}})})(jQuery);

/*!

    Copyright (c) 2011 Peter van der Spek

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
    
 */
;(function(a){function m(){if(!d){d=!0;for(var c in b)a(c).each(function(){var d,e;d=a(this),e=d.data("jqae"),(e.containerWidth!=d.width()||e.containerHeight!=d.height())&&f(d,b[c])});d=!1}}function l(a){b[a]&&(delete b[a],b.length||c&&(window.clearInterval(c),c=undefined))}function k(a,d){b[a]=d,c||(c=window.setInterval(function(){m()},200))}function j(){return this.nodeType===3}function i(b){if(b.contents().length){var c=b.contents(),d=c.eq(c.length-1);if(d.filter(j).length){var e=d.get(0).nodeValue;e=a.trim(e);if(e==""){d.remove();return!0}return!1}while(i(d));if(d.contents().length)return!1;d.remove();return!0}return!1}function h(a){if(a.contents().length){var b=a.contents(),c=b.eq(b.length-1);return c.filter(j).length?c:h(c)}a.append("");var b=a.contents();return b.eq(b.length-1)}function g(b){var c=h(b);if(c.length){var d=c.get(0).nodeValue,e=d.lastIndexOf(" ");e>-1?(d=a.trim(d.substring(0,e)),c.get(0).nodeValue=d):c.get(0).nodeValue="";return!0}return!1}function f(b,c){var d=b.data("jqae");d||(d={});var e=d.wrapperElement;e||(e=b.wrapInner("<div/>").find(">div"),e.css({margin:0,padding:0,border:0}));var f=e.data("jqae");f||(f={});var j=f.originalContent;j?e=f.originalContent.clone(!0).data("jqae",{originalContent:j}).replaceAll(e):e.data("jqae",{originalContent:e.clone(!0)}),b.data("jqae",{wrapperElement:e,containerWidth:b.width(),containerHeight:b.height()});var k=b.height(),l=(parseInt(b.css("padding-top"),10)||0)+(parseInt(b.css("border-top-width"),10)||0)-(e.offset().top-b.offset().top),m=!1,n=e;c.selector&&(n=a(e.find(c.selector).get().reverse())),n.each(function(){var b=a(this),d=b.text(),f=!1;if(e.innerHeight()-b.innerHeight()>k+l)b.remove();else{i(b);if(b.contents().length){m&&(h(b).get(0).nodeValue+=c.ellipsis,m=!1);while(e.innerHeight()>k+l){f=g(b);if(!f){m=!0,b.remove();break}i(b);if(b.contents().length)h(b).get(0).nodeValue+=c.ellipsis;else{m=!0,b.remove();break}}c.setTitle=="onEllipsis"&&f||c.setTitle=="always"?b.attr("title",d):c.setTitle!="never"&&b.removeAttr("title")}}})}var b={},c,d=!1,e={ellipsis:"...",setTitle:"never",live:!1};a.fn.ellipsis=function(b,c){var d,g;d=a(this),typeof b!="string"&&(c=b,b=undefined),g=a.extend({},e,c),g.selector=b,d.each(function(){var b=a(this);f(b,g)}),g.live?k(d.selector,g):l(d.selector);return this}})(jQuery);