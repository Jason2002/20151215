jQuery(document).ready(function(){
	//format price
	$('*[format="price"]').html(function(){
		if($(this).text().indexOf('.') > 0) {
			var arr = $(this).text().split('.');
			return arr[0]  + '.<sup>' + arr[1] + '</sup>';
		} else { return this.innerText; }
	});
	//format select 
	$('#Size').Selector({
		label: {
			text: 'Size',
			width: 91,
			className: 'labelSpan'
		},
		height: 40
	});
	$('#Color').Selector({
		label: {
			text: 'Color',
			width: 91,
			className: 'labelSpan'
		},
		height: 40
	});
	$('#Qty').Selector({
		label: {
			text: 'Quantity',
			width: 91,
			className: 'labelSpan'
		},
		height: 40,
		defaultRows: 5	//show droplist rows
	});
	//EmailShare
	$('#EmailShare').click(function(){
		popShow($('#PopEmailShare'));
	});
	//see more
	$('#More').click(function(){
		var box = $('#MoreInfo'),
			arrow = $(this).find('b'),
			text = $(this).find('span');
		box.wrapInner('<div></div>');
		var	height, top;
		if(arrow.hasClass('iconArrowDown')) {
			text.text('See Less');
			arrow.removeClass().addClass('iconArrowUp');
			height = box.find('>div').height() +20;
			top = box;
		} else {
			text.text('See More');
			arrow.removeClass().addClass('iconArrowDown');
			height = 0;
			top = $('.otherinfo');
		}
		if(!$.IsTouchMedia()){
			$(window).scrollTo( top, 160 );
			box.animate({
				height: height
			}, 150);
		} else {
			box.css('height', height);
		}
	});
	$('#Canvas').Zoom([{
			bigUrl: '',
			normalUrl: '',
			thumbnailUrl: '',
			current: true
		}, {
			bigUrl: 'images/products/1280x960/02.jpg',
			normalUrl: 'images/products/640x480/02.jpg',
			thumbnailUrl: 'images/products/160x120/02.jpg',
			current: false
		}, {
			bigUrl: 'images/products/1280x960/03.jpg',
			normalUrl: 'images/products/640x480/03.jpg',
			thumbnailUrl: 'images/products/160x120/03.jpg',
			current: false
		}, {
			bigUrl: 'images/products/1280x960/04.jpg',
			normalUrl: 'images/products/640x480/04.jpg',
			thumbnailUrl: 'images/products/160x120/04.jpg',
			current: true
		}, {
			bigUrl: 'images/products/1280x960/05.jpg',
			normalUrl: 'images/products/640x480/05.jpg',
			thumbnailUrl: 'images/products/160x120/05.jpg',
			current: false
		}, {
			bigUrl: 'images/products/1280x960/06.jpg',
			normalUrl: 'images/products/640x480/06.jpg',
			thumbnailUrl: 'images/products/160x120/06.jpg',
			current: false
	}]);
});
