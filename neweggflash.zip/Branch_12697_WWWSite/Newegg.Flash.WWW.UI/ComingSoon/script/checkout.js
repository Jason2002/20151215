$(window).load(function(){
	footerFix();
	
	$(".mask_ZipCode").mask("99999?-9999");
	$(".mask_Phone").mask("(999) 999-9999? x9999");
	$(".mask_SecurityCode").mask("?9999");
	$(".mask_GiftCardNumber").mask("9999 9999 9999 9999");
	$(".mask_GiftCardCode").mask("9999");
	
	//payment method tab
	tab(".paymentTab");
	
	//switch box
	$(".switchBox").find("dt").click(function(){
		$(this).next("dd").toggle(0, function(){
			if ($(this).is(":hidden")){
				$(this).prev("dt").find(".OnOff").removeClass("OnOff_ON");
			}else {
				$(this).prev("dt").find(".OnOff").addClass("OnOff_ON");
			}
		});
	});
	
	//use the same billing address as the shipping address
	if ($(".sameOnOff").is(":checked")) {
		$(".sameOnOff").parents(".sameAddress").next(".addressList").hide();
	}else {
		$(".sameOnOff").parents(".sameAddress").next(".addressList").show();
	}
	$(".sameOnOff").click(function(){
		if ($(this).is(":checked")) {
			$(this).parents(".sameAddress").next(".addressList").slideUp("fast");
		}else {
			$(this).parents(".sameAddress").next(".addressList").slideDown("fast");
		}
	});
	
	//choose address
	var oCurrentAddress = $("#AddressList dt .formRadiobox:checked").parent("dt");
	$("#AddressList dt .edit").click(function(){
		closeList(oCurrentAddress, oCurrentAddress.next("dd"));
		oCurrentAddress.find(".addressInfo").slideDown("fast");
		oCurrentAddress = $(this).parent("dt");
		openList(oCurrentAddress, oCurrentAddress.next("dd"));
		oCurrentAddress.find(".addressInfo").slideUp("fast");
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#AddressList dt .formRadiobox").click(function(){
		if ($(this).parent("dt").next("dd").is(":hidden")) {
			oCurrentAddress.find(".addressInfo").slideDown("fast");
			closeList(oCurrentAddress, oCurrentAddress.next("dd"));
			oCurrentAddress = $(this).parent("dt");
		}
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#AddressList dd .cancelBtn").click(function(){
		var o = $(this).parents("dd");
		closeList(o.prev(), o);
		oCurrentAddress.find(".addressInfo").slideDown("fast");
		var t = setTimeout(function(){
					footerFix();
					menuFun();
				}, 300);
	});
	$("#AddressList .new .formRadiobox").click(function(){
		if ($(this).parent("dt").next("dd").is(":hidden")) {
			openList(oCurrentAddress, oCurrentAddress.next("dd"));
		}
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#AddressList .new a.add").click(function(){
		oCurrentAddress.next("dd").find(".cancelBtn").click();
		oCurrentAddress = $(this).parent("dt");
		if (oCurrentAddress.next("dd").is(":hidden")) {
			openList(oCurrentAddress, oCurrentAddress.next("dd"));
		}
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#AddressList .new .cancelBtn").click(function(){
		$("#AddressList .formRadiobox").eq(0).click();
	});
	
	//choose credit card
	var oCurrentCard = $("#CardList dt .formRadiobox:checked").parent("dt");
	oCurrentCard.find(".form_SecurityCode").show();
	$("#CardList dt .edit").click(function(){
		closeList(oCurrentCard, oCurrentCard.next("dd"));
		$("#CardList dt .form_SecurityCode").hide();
		oCurrentCard = $(this).parent("dt");
		openList(oCurrentCard, oCurrentCard.next("dd"));
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#CardList dt .formRadiobox").click(function(){
		if ($(this).parent("dt").next("dd").is(":hidden")) {
			closeList(oCurrentCard, oCurrentCard.next("dd"));
			oCurrentCard.find(".form_SecurityCode").hide();
			oCurrentCard = $(this).parent("dt");
			oCurrentCard.find(".form_SecurityCode").show();
		}
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#CardList dt .addressInfo").click(function(){
		$(this).parent().find(".formRadiobox").click();
	});
	$("#CardList dd .cancelBtn").click(function(){
		var o = $(this).parents("dd");
		closeList(o.prev(), o);
		oCurrentCard.find(".form_SecurityCode").show();
		var t = setTimeout(function(){
					footerFix();
					menuFun();
				}, 300);
	});
	$("#CardList .new .formRadiobox").click(function(){
		if ($(this).parent("dt").next("dd").is(":hidden")) {
			openList(oCurrentCard, oCurrentCard.next("dd"));
		}
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#CardList .new a.add").click(function(){
		oCurrentCard.next("dd").find(".cancelBtn").click();
		oCurrentCard = $(this).parent("dt");
		if (oCurrentCard.next("dd").is(":hidden")) {
			openList(oCurrentCard, oCurrentCard.next("dd"));
		}
		var t = setTimeout(function(){
					footerFix();
				}, 300);
	});
	$("#CardList .new .cancelBtn").click(function(){
		$("#CardList .formRadiobox").eq(0).click();
	});
	
	//card type
	$(".addressList .chkNum").each(function(index, element) {
		var num = $(this).html();
		var img = chkCardNum(num);
		var txt = "";
		if (img[0]) {
			$(this).parent().css("background-image", "url(images/icon/" + img[0] + ")");
			if (img[2] == "3") {
				num = num.substring(0,1) + "*********" + num.substring(num.length - 5, num.length);
				for (var i=num.length; i>0; i--) {
					if (i == num.length - 5 || i == num.length - 11) {
						txt = num.substring(i-1, i) + "&nbsp;&nbsp;&nbsp;" + txt;
					}else {
						txt = num.substring(i-1, i) + "&nbsp;" + txt;
					}
				}
			}else {
				num = num.substring(0,1) + "***********" + num.substring(num.length - 4, num.length);
				for (var i=num.length; i>0; i--) {
					if (i == num.length - 4 || i == num.length - 8 || i == num.length - 12) {
						txt = num.substring(i-1, i) + "&nbsp;&nbsp;&nbsp;" + txt;
					}else {
						txt = num.substring(i-1, i) + "&nbsp;" + txt;
					}
				}
			}
			$(this).html(txt);
		}
	});
	$(".mask_CardNumber").each(function(index, element) {
		var img = chkCardNum($(this).val());
		$(this).data("firstNum", img[2]);
		if (img[0]) {
			$(this).css("background-image", "url(images/icon/" + img[0] + ")").mask(img[1]);
		}else {
			$(this).css("background-image", "").mask("?9 9 9 9   9 9 9 9   9 9 9 9   9 9 9 9");
		}
	}).keyup(function(){
		var img = chkCardNum($(this).val());
		if ($(this).data("firstNum") != img[2]) {
			$(this).data("firstNum", img[2]);
			if (img[0]) {
				$(this).css("background-image", "url(images/icon/" + img[0] + ")").mask(img[1]);
			}else {
				$(this).css("background-image", "");
			}
		}
	});
		
}).resize(function() {
	footerFix();
}).scroll(function(){
	footerFix();
});