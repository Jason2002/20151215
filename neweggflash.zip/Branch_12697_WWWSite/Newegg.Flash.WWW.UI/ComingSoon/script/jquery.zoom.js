/*
	jQuery Zoom v1.7.0 - 2013-01-31
	(c) 2013 Jack Moore - jacklmoore.com/zoom
	license: http://www.opensource.org/licenses/mit-license.php
*/
(function ($) {
	var defaults = {
		url: false,
		callback: false,
		target: false,
		duration: 120,
		on: 'mouseover' // other options: 'grab', 'click', 'toggle'
	};

	// Core Zoom Logic, independent of event listeners.
	$.zoom = function(target, source, img) {
		var outerWidth,
			outerHeight,
			xRatio,
			yRatio,
			offset,
			position = $(target).css('position');

		// The parent element needs positioning so that the zoomed element can be correctly positioned within.
		$(target).css({
			position: /(absolute|fixed)/.test() ? position : 'relative',
			overflow: 'hidden'
		});

		$(img)
			.addClass('zoomImg')
			.css({
				position: 'absolute',
				top: 0,
				left: 0,
				opacity: 0,
				width: img.width,
				height: img.height,
				border: 'none',
				maxWidth: 'none'
			})
			.appendTo(target);

		return {
			init: function() {
				outerWidth = $(target).outerWidth();
				outerHeight = $(target).outerHeight();
				xRatio = (img.width - outerWidth) / $(source).outerWidth();
				yRatio = (img.height - outerHeight) / $(source).outerHeight();
				offset = $(source).offset();
			},
			move: function (e) {
				try {
				var left = (e.pageX - offset.left),
					top = (e.pageY - offset.top);

				top = Math.max(Math.min(top, outerHeight), 0);
				left = Math.max(Math.min(left, outerWidth), 0);

				img.style.left = (left * -xRatio) + 'px';
				img.style.top = (top * -yRatio) + 'px';
				}catch(ex){}
			}
		};
	};

	$.fn.zoom = function (options) {
		return this.each(function () {
			var
			settings = $.extend({}, defaults, options || {}),
			//target will display the zoomed iamge
			target = settings.target || this,
			//source will provide zoom location info (thumbnail)
			source = this,
			img = new Image(),
			$img = $(img),
			mousemove = 'mousemove',
			clicked = false;

			// If a url wasn't specified, look for an image element.
			if (!settings.url) {
				settings.url = $(source).find('img').attr('src');
				if (!settings.url) {
					return;
				}
			}

			img.onload = function () {
				var zoom = $.zoom(target, source, img);

				function start(e) {
					zoom.init();
					zoom.move(e);

					// Skip the fade-in for IE8 and lower since it chokes on fading-in
					// and changing position based on mousemovement at the same time.
					$img.stop()
					.fadeTo($.support.opacity ? settings.duration : 0, 1);
				}

				function stop() {
					$img.stop()
					.fadeTo(settings.duration, 0);
				}

				if (settings.on === 'grab') {
					$(source).mousedown(
						function (e) {
							$(document).one('mouseup',
								function () {
									stop();

									$(document).unbind(mousemove, zoom.move);
								}
							);

							start(e);

							$(document)[mousemove](zoom.move);

							e.preventDefault();
						}
					);
				} else if (settings.on === 'click') {
					$(source).click(
						function (e) {
							if (clicked) {
								// bubble the event up to the document to trigger the unbind.
								return;
							} else {
								clicked = true;
								start(e);
								$(document)[mousemove](zoom.move);
								$(document).one('click',
									function () {
										stop();
										clicked = false;
										$(document).unbind(mousemove, zoom.move);
									}
								);
								return false;
							}
						}
					);
				} else if (settings.on === 'toggle') {
					$(source).click(
						function (e) {
							if (clicked) {
								stop();
							} else {
								start(e);
							}
							clicked = !clicked;
						}
					);
				} else {
					zoom.init(); // Pre-emptively call init because IE7 will fire the mousemove handler before the hover handler.

					$(source).hover(
						start,
						stop
					)[mousemove](zoom.move);
				}

				if ($.isFunction(settings.callback)) {
					settings.callback.call(img);
				}
			};

			img.src = settings.url;
		});
	};

	$.fn.zoom.defaults = defaults;
}(window.jQuery));

/*
 * use age:
 * ------------[Selector]------------
   $('.className, #elementID').Selector({
		label: {
			text: 'Quantity',
			width: 91,
			className: 'labelSpan'
		},
		height: 40,
		defaultRows: 5	//show droplist rows, default is 8
	});
	$('.className, #elementID').Selector({
		label: {
			text: 'Color',
			width: 91,
			className: 'labelSpan'
		},
		height: 40
	});
 */
(function($){ 
	$.fn.extend({
		/*
		 * Selector
		 */
		Selector: function(options) {
			var defaults = {  
				isOpen: false,
				posClass: 'selectWrap',
				firstChildClass: 'selectValue',
				scrollClass: 'selectOptionsWrap',
				childClass: 'selectItems',
				width: '100%',
				height: 24,
				defaultRows: 8,
				label: {}
			}
			var options =  $.extend(defaults, options);
			
			return this.each(function() {
				if(this.nodeName.toLowerCase() != 'select') return;
				var o = options; 
				if($.IsTouchMedia()) {
					var posSpan = $('<span class="' + o.posClass + '"></span>');
					posSpan.css({
						width: o.width,
						height: o.height,
						overflow: 'hidden',
						lineHeight: o.height
					});
					if(o.label) {
						o.labelSpan = $('<span class="selectLabel ' + o.label.className + '" style="width:' + 
										o.label.width + 'px;height:' + o.height + 'px;line-height:' + 
										o.height + 'px;z-index:1;">' + 
										o.label.text + 
										'</span>').appendTo(posSpan);
					}
					
					posSpan.insertAfter($(this));
					$(this).appendTo(posSpan)
					$(this).css({
						display: 'block',
						margin: '5px 0 0 0',
						width: (posSpan.width() - o.label.width), 
						height: '30px', 
						visibility: 'visible'
					});
					return;
				}
				o.mask = $('<div class="maskBox" style="height:' + window.screen.availHeight + 'px;"></div>');
				this.style.display = 'none';
				CreatElement(this, o);
			})
			function CreatElement(element, o) {
				var posSpan = $('<span class="' + o.posClass + '"></span>');
				posSpan.css({
					width: o.width,
					height: o.height,
					overflow: 'hidden',
					lineHeight: o.height
				});
				
				if(o.label) {
					o.labelSpan = $('<span class="selectLabel ' + o.label.className + '" style="width:' + 
									o.label.width + 'px;height:' + o.height + 'px;line-height:' + 
									o.height + 'px;z-index:1;">' + 
									o.label.text + 
									'</span>').appendTo(posSpan)
					.click(function(){
						firstChildSpan.trigger('click');
					});
				}
				
				var selectValueSpan = $('<span  class="' + o.firstChildClass + '"></span>'),
					html = element.options[element.options.selectedIndex].text,
					left = (o.label ? o.label.width + 'px' : '');
				
				selectValueSpan.html(html)
				.css({
					height: o.height,
					lineHeight: o.height + 'px'
				})
				.click(function(){
					if(element.disabled) return;
					OpenOrCloseList(posSpan, element, o);
				})
				
				var scrollSpan = $('<span class="' + o.scrollClass + '"></span>');
				scrollSpan.css({
					width: o.width,
					height: ((element.options.length  + 1) > o.defaultRows ? o.defaultRows : (element.options.length  + 1)) * o.height + 'px',
					lineHeight: o.height + 'px',
					textIndent: left
				});
				
				selectValueSpan.appendTo(posSpan);
				
				posSpan.insertAfter(element);
				o.arrow = $('<b class="iconArrowDown" style="right:20px;top:' + 
							(o.height - 4)*0.5 + 'px"></b>')
							.appendTo(selectValueSpan);
				if(element.disabled) {
					posSpan.addClass('disabled');
					return;
				}
				scrollSpan.appendTo(posSpan);
				InsertOptions(element, posSpan, selectValueSpan, scrollSpan, o);
			}
			function InsertOptions(element, posSpan, selectValueSpan, scrollSpan, o) {
				var optionsNum = element.options.length;
				for(var i = 0; i < optionsNum; i++) {
					var childSpan = $('<span name="' + i + '" class="' + o.childClass + ' ' + element.options[i].className + '"></span>'),
						html = element.options[i].text,
						left = (o.label ? o.label.width + 'px' : '');
					childSpan.css({
						height: o.height + 'px',
						lineHeight: o.height + 'px',
						textIndent: left
					})
					.attr('title', html)
					.html(html)
					.click(function(){
						ChangeValue($(this), posSpan, selectValueSpan, element, o);
					})
					.mouseover(function(){
						$(this).addClass('hover');
					})
					.mouseout(function(){
						$(this).removeClass('hover');
					})
					.appendTo(scrollSpan);
				}
			}
			function OpenOrCloseList(posSpan, element, o) {
				if(o.isOpen) { // to close
					o.mask.remove().css('z-index', '');
					posSpan.css({
						overflow: 'hidden',
						zIndex: ''
					});
					o.isOpen = false;
				} else {//to open
					posSpan.css({
						overflow: '',
						zIndex: 9999
					});
					o.mask.css('z-index', 9998).click(function(){
						SelectisOpen = true;
						OpenOrCloseList(posSpan, element, o);
					}).appendTo($('body'));
					o.isOpen = true;
				}
			}
			function ChangeValue(childSpan, posSpan, selectValueSpan, element, o) {
				element.options[element.selectedIndex].selected = false;
				element.options[childSpan.attr('name')].selected = true;
				selectValueSpan.html(childSpan.html()).append(o.arrow);
				o.isOpen = true;
				OpenOrCloseList(posSpan, element, o);
				$(element).trigger('change');
			}
		},
		/*
		 * pic zoom
		 */
		Zoom: function(options){
			return this.each(function() {
				var o  = options
				if(!o) return;
				var isTouchMedia = $.IsTouchMedia();
				if(isTouchMedia) {//on touch screen
					var canvas = this,
						ul = $('<ul></ul>'),
						thumbnails = $('<div id="Thumbnails" class="smallpic fix"></div'),
						slider, index;
						
					for(var i = 0; i < o.length; i++) {
						var img = $('<img src="' + o[i].normalUrl + '">'),
							thumbnail = $('<img index="'+i+'" class="' + (o[i].current ? 'current' : '') + '" src="' + o[i].thumbnailUrl + '">'),
							li = $('<li></li>');
							
						if(o[i].current) index = i;
						img.appendTo(li);
						li.appendTo(ul);
						thumbnail.appendTo(thumbnails);
						thumbnail.click(function(){
							var step = this.getAttribute('index') - slider.getPos();
							while(step<0){
								slider.prev();
								step++;
							}
							while(step>0){
								slider.next();
								step--;
							}	
							if(step==0) {
								slider.resume()
							}
						});
					}
					ul.appendTo($(this));
					thumbnails.insertAfter($(canvas));
					slider = new Swipe(this,{
						startSlide: index,
						speed: 400,
						callback: function(event, index, element) {
							$('#Thumbnails img').eq(index).addClass('current').siblings().removeClass();
						}
					});
				} else {//desktop browser
					var canvas = this,
						thumbnails = $('<div id="Thumbnails" class="smallpic fix"></div'),
						outer = $('<div class="thumbnailOuter"></div>'),
						inner = $('<div class="thumbnailInner"></div>');
					thumbnails.index = 0;
					inner.css('width', o.length * 89 + 10);
					for(var i = 0; i < o.length; i++) {
						var id = 'tmp-' + parseInt(Math.random(100000)*100000), timer,
							box = $('<div id="' + id + '" class="item ' + (o[i].current ? 'current' : '') + '"></div>'),
							img = $('<img src="' + o[i].bigUrl + '">')
							thumbnail = $('<img for="' + id + '" class="' + (o[i].current ? 'current' : '') + '" src="' + o[i].thumbnailUrl + '">');
						if(o[i].current) thumbnails.index = i;
						img.appendTo(box);
						box.zoom().hover(function(){
							$(this).css('z-index', '9999');
							$(canvas).css('z-index', '9999');
						}, function(){
							$(this).css('z-index', '');
							$(canvas).css('z-index', '');
						});
						box.appendTo($(canvas));
						thumbnail.appendTo(inner);
						thumbnail.mouseover(function(){
							thumbnails.index = inner.find('img').index(this);
							Show();
						});
					}
					
					inner.appendTo(outer);
					outer.appendTo(thumbnails);
					thumbnails.insertAfter($(canvas));
					
					if(o.length > 5) {
						var prev = $('<div class="prev disabled"></div>'),
							next = $('<div class="next"></div>');
						prev.click(function(){
							if(!$(this).hasClass('disabled')) {
								thumbnails.index = inner.find('img').index(inner.find('img.current'));
								if(thumbnails.index % 5 == 0) {
									inner.animate({
										left: '+=' + outer.width()
									}, 250);
								}
								thumbnails.index--;
								Show();
							}
						})
						.insertBefore(outer);
						next.click(function(){
							if(!$(this).hasClass('disabled')) {
								thumbnails.index = inner.find('img').index(inner.find('img.current'));
								thumbnails.index++;
								Show();
								if(thumbnails.index % 5 == 0) {
									inner.animate({
										left: '-=' + outer.width()
									}, 250);
								}
							}
						})
						.appendTo(thumbnails);
					}
					function Show() {
						if(o.length > 5) {
							if(thumbnails.index == 0 ){
								next.removeClass('disabled');
								prev.addClass('disabled');
							} 
							if(thumbnails.index == o.length - 1 ){
								prev.removeClass('disabled');
								next.addClass('disabled');
							} 
							if(thumbnails.index > 0 && thumbnails.index < o.length - 1) { 
								next.removeClass('disabled')
								prev.removeClass('disabled');
							}
						}
						
						thumbnails.find('img:eq(' + thumbnails.index + ')').addClass('current').siblings().removeClass('current');
						var id = thumbnails.find('img:eq(' + thumbnails.index + ')').addClass('current').attr('for');
						$('#' + id).addClass('current').siblings().removeClass('current');
					}
				}
			});
		}
    });
})(jQuery); 