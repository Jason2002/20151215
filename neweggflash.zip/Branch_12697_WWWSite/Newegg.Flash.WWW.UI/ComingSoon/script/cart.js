$(window).load(function(){
	footerFix();
	$(".mask_ZipCode").mask("99999?-9999");
	$(".mask_Phone").mask("(999) 999-9999? x9999");
	$(".mask_SecurityCode").mask("?9999");
	$(".mask_GiftCardNumber").mask("9999 9999 9999 9999");
	$(".mask_GiftCardCode").mask("9999");
	
	$(".switchBox").find("dt").click(function(){
		$(this).next("dd").toggle(0, function(){
			if ($(this).is(":hidden")){
				$(this).prev("dt").find(".OnOff").removeClass("OnOff_ON");
			}else {
				$(this).prev("dt").find(".OnOff").addClass("OnOff_ON");
			}
		});
	});
	
	$(".zipCode_readonly").val($(".mask_ZipCode").val());
	$(".mask_ZipCode").change(function(){
		$(".zipCode_readonly").val($(".mask_ZipCode").val());
	});
			
	$(".cartItem .qty .num")
		.change(function(){
			if (this.value < 1) this.value = 1;
		})
		.mask("9?9");
	
	$(".cartItem .qty .btn_minus").click(function(){
		var o = $(this).next(".num");
		var n = o.val();
		n--;
		if (n < 1) n = 1;
		o.val(n);
	});
	
	$(".cartItem .qty .btn_plus").click(function(){
		var o = $(this).prev(".num");
		var n = o.val();
		n++;
		if (n > 99) n = 99;
		o.val(n);
	});
});