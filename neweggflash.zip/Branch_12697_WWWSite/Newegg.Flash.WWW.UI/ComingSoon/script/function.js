$(window).scroll(function(){
	//header scroll shadow
	var y = getPageScroll()[1];
	if(y > 0) {
		$('#Header').addClass('headerShadow');
	} else {
		$('#Header').removeClass('headerShadow');
	}
	
	//aside
	asideFun()
	
	//account menu and about menu
	menuFun();
	
	//go top
	//topFun();
	//feedbackFun();
}).load(function(){
	setCssWidth();
	feedbackFun();
	
	//ie placeholder
	if($.IsIE(6) || $.IsIE(7) || $.IsIE(8) || $.IsIE(9)) {
		$(".iePlaceholder .formText").each(function(index, element) {
			if ($(this).val().length > 0) {
				$(this).siblings(".formTitle").hide();
			}
		}).keypress(function(){
			$(this).siblings(".formTitle").hide();
		}).blur(function() {
			if ($(this).val().length == 0) {
				$(this).siblings(".formTitle").show();
			} 
		});
	}
	
	$('#MiniAccount, #MiniCart').hover(function(){
		var _this = this;
		clearTimeout(_this.t2);
		_this.t1 = setTimeout(function(){
			if(_this.t1) {
				$(_this).addClass('hover').find('.popContainer').show();
			}
		}, 200);
	}, function(){
		var _this = this;
		clearTimeout(_this.t1);
		_this.t2 = setTimeout(function(){
			if(_this.t2) {
				$(_this).removeClass('hover').find('.popContainer').hide();
			}
		}, 200);
	});
	//Logo effect
	$('#Logo, #FooterLogo').mouseover(function(){
		if($.IsIE(6) || $.IsIE(7) || $.IsIE(8) || $.IsTouchMedia()) return;
		var _this = this;
		if(!_this.isAnimated) {
			var shadow_e = $('<a class="logo_shadow_e" href="' + this.href + '"></a>'),
				shadow_w = $('<a class="logo_shadow_w" href="' + this.href + '"></a>');
			
			shadow_e.appendTo($(_this));
			shadow_w.appendTo($(_this));
			_this.isAnimated = true;
			shadow_e.animate({
				right: $(_this).width()
			}, 600, function(){
				shadow_e.remove();
			});
			shadow_w.animate({
				left: $(_this).width()
			}, 600, function(){
				shadow_w.remove();
				setTimeout(function(){_this.isAnimated = false;}, 500)
			});
		}
	});
	
}).resize(function(){
	setCssWidth();
});

function setCssWidth() {
	if ((document.documentElement.clientWidth || document.body.clientWidth) <= 980) {
		$("body").addClass("w960");
		if($.IsTouchMedia()) {
			$('body').addClass('w960Media');
		}
	}else {
		$("body").removeClass("w960");
		if($.IsTouchMedia()) {
			$('body').removeClass('w960Media');
		}
	}
}

function openList(oDT, oDD) {
	oDT.css("border-bottom-width", "0px");
	oDT.children(".formRadiobox").prop("checked", "checked");
	oDT.find(".edit, .delete").hide();
	oDT.find(".markDft").hide();
	oDD.slideDown("fast");
}
function closeList(oDT, oDD) {
	oDT.css("border-bottom-width", "1px");
	oDT.find(".edit, .delete").show();
	oDT.find(".markDft").show();
	oDD.slideUp("fast");
}

function footerFix() {
	var docH, htmlH;
	htmlH = $("#Header").height() + $("#Footer").height() + $(".section").height();
	docH = $(document).innerHeight();
	if (docH >= htmlH + 90) {
		$("#Footer").addClass("footerFix");
		var o = $("#Footer .feedback");
		o.css({
			position: 'absolute',
			top: '-135px'
		})
		if($.IsIE(7)) {
			o.css({
				top: '-95px'
			})
		}
	}else {
		$("#Footer").removeClass("footerFix");
	}
}

function asideFun() {
	var o = $("#ScrollFix");
	if (o[0]) {
		if (getPageScroll()[1] > 155) {
			o.removeAttr("style").addClass("fixed");
			if (getPageScroll()[1] - $("#Header").height() >= $(".section").height() - o.height()) {
				var top = $(".section").height() - o.height() - 70;	
				o.css({
					"position": "absolute", 
					"top": top
				});
			}
		}else {
			o.removeAttr("style").removeClass("fixed");
		}
	}
}
function menuFun() {
	var o = $("#Menu");
	if (o[0]) {
	    if (getPageScroll()[1] > 75 && document.documentElement.clientWidth > 768) {
			o.removeAttr("style").addClass("fixed");
			if (getPageScroll()[1] - $("#Header").height() >= $(".section").height() - o.height() - 46) {
				var top = $(".section").height() - o.height() - 46;	
				o.css({
					"position": "absolute", 
					"top": top
				});
			}
		}else {
			o.removeAttr("style").removeClass("fixed");
		}
	}
}
function topFun() {
	var o = $("#Footer .goTopFix");
	if (o[0]) {
		if (getPageScroll()[1] > 200) {
			o.removeAttr("style").addClass("fixed").css("display", "block");
			if ($(document).height() - $(window).height() - getPageScroll()[1] <= $("#Footer").height() + 30) {
				o.removeClass("fixed");
			}
		}else {
			o.removeClass("fixed").css("display", "none");
		}
	}
}
function feedbackFun() {
	var o = $("#Footer .feedback");
	if(!$.IsTouchMedia() && o[0]) {
		if ($(document).height() - $(window).height() - getPageScroll()[1] <= $("#Footer").height() + 30) {
			o.css({
				position: 'absolute',
					top: '-135px'
			})
			if($.IsIE(7)) {
				o.css({
					top: '-90px'
				})
			}
		} else {
			o.css({
				position: '',
				top: ''
			})
		}
	}
}

function getPageScroll() {
    var xScroll, yScroll;
    if (self.pageYOffset) {
      yScroll = self.pageYOffset;
      xScroll = self.pageXOffset;
    } else if (document.documentElement && document.documentElement.scrollTop) {	 // Explorer 6 Strict
      yScroll = document.documentElement.scrollTop;
      xScroll = document.documentElement.scrollLeft;
    } else if (document.body) {// all other Explorers
      yScroll = document.body.scrollTop;
      xScroll = document.body.scrollLeft;	
    }
    return new Array(xScroll,yScroll) 
}

function tab(obj) {
	$(".tab_options li", obj).click(function(){
		var o = $(this);
		if (this.className != "tab_current") {
			o.siblings().removeClass("tab_current");
			o.addClass("tab_current");
			$(".tab_body", obj).hide().eq(o.index()).show();
			$("#BillingAddress").toggle();
			footerFix();
		}
	});
}
/*
Fill finished return true.
example:
	if (emptyChk()) {
		//submit....
	}
*/
function emptyChk(obj, nameStr, errStr){
	if (obj == null) obj = "body";
	if (errStr == null) errStr = "This field is required.";
	if (nameStr == null) nameStr = ".form_FirstName:visible, .form_LastName:visible, .form_Address:visible, .form_City:visible, .form_ZipCode:visible, .form_Phone:visible, .form_CardholderName:visible, .form_CardNumber:visible, .form_SecurityCode:visible";

	var returnValue = true;
	var chkObj = $(nameStr, obj);
	
	$(".formError", obj).removeClass("formError");
	$("p.errorInfo", obj).remove();
	
	chkObj.each(function(index, element) {
		var o = $(this);
		if (o.find(".formText").val() == "") {
			returnValue = false;
			errSet(o, "This field is required.");
		}
	});
	
	return returnValue;
}
function errSet(obj, errStr){
	var w = $(obj).width();
	errStr = '<p class="errorInfo" style="width: ' + w + 'px;">' + errStr + '</p>';
	$("p.errorInfo", obj).remove();
	$(obj).addClass("formError")
		.append(errStr)
		.find(".formText").keypress(function(){
			$(this).parent()
				.removeClass("formError")
				.find("p.errorInfo").remove();
		});
}
function checkEmail(str){
	var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	return reg.test(str);
}
function openWin(url, w, h){
	var myWin = window.open(url, '', 'width=' + w +', height=' + h + '');
	myWin.focus();
}
function chkCardNum(num){
	num = num.substring(0,1);
	switch(num) {
	case "3":
		return new Array("img_ccAmex.png", "?9 9 9 9   9 9 9 9 9 9   9 9 9 9 9", num);
		break;
	case "4":
		return new Array("img_ccVisa.png", "?9 9 9 9   9 9 9 9   9 9 9 9   9 9 9 9", num);
		break;
	case "5":
		return new Array("img_ccMastercard.png", "?9 9 9 9   9 9 9 9   9 9 9 9   9 9 9 9", num);
		break;
	case "6":
		return new Array("img_ccDnetwork_v1.png", "?9 9 9 9   9 9 9 9   9 9 9 9   9 9 9 9", num);
		break;
	default:
		return false;
		break;
	}
}
function popShow(ele) {
	if(!ele[0]) return;
	$.MaskBox();
	ele.removeClass('hidden').css('left', ($(window).width() - 490) / 2).animate({
		top: ($(window).height() - ele.outerHeight(true) < 0 ? 120 : $(window).height() - ele.outerHeight(true)) / 2
	}, 300).find('.pop_close').click(function(){
		ele.addClass('hidden');
		$('.maskBox').remove();
	});
}
