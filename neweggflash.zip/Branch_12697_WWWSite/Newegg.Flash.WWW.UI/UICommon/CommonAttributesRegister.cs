﻿using System.Web.Mvc;

using Newegg.EC.Web;
using Newegg.EC.Web.Mvc;
using Newegg.Flash.WWW.UI.Filters;

namespace Newegg.Flash.WWW.UI.UICommon
{
    internal class CommonAttributesRegister : BaseWebAppStartProcessor
    {
        /// <summary>
        /// Gets web application priority.
        /// </summary>
        public override int Priority
        {
            get { return 9000; }
        }

        /// <summary>
        /// Process the work when application start. 
        /// </summary>
        public override void Process()
        {
            GlobalFilters.Filters.Add(new ComingSoonFilterAttribute());
        }
    }
}