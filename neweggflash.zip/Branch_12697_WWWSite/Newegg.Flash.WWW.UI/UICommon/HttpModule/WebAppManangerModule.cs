﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newegg.EC;
using Newegg.EC.BizUnit;
using Newegg.EC.Web;

namespace Newegg.Flash.WWW.UI.UICommon
{
    public class WebAppManangerModule : IHttpModule
    {
        /// <summary>
        /// Web application manager.
        /// </summary>
        private Lazy<IWebAppManager> webAppManager = new Lazy<IWebAppManager>(() => ECLibraryContainer.Current.GetInstance<IWebAppManager>());

        public void Dispose()
        {

        }

        public void Init(HttpApplication context)
        {
            context.BeginRequest -= context_BeginRequest;
            context.EndRequest -= context_EndRequest;

            context.BeginRequest += context_BeginRequest;
            context.EndRequest += context_EndRequest;
        }

        void context_EndRequest(object sender, EventArgs e)
        {
            if (this.webAppManager.Value != null)
            {
                this.webAppManager.Value.EndRequest();
            }
        }

        void context_BeginRequest(object sender, EventArgs e)
        {
            BizThreadContext.BizUnitInfo = ECLibraryContainer.Current.GetInstance<IBizUnitFactory>().Create();
            if (this.webAppManager.Value != null)
            {
                this.webAppManager.Value.BeginRequest();
            }
        }
    }
}