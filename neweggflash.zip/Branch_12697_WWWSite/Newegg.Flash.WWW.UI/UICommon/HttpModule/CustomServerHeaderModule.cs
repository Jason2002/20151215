﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Http module for custommize server header.
    /// </summary>
    public class CustomServerHeaderModule : IHttpModule
    {
        /// <summary>
        /// Dispose the http module.
        /// </summary>
        public void Dispose()
        {
        }

        /// <summary>
        /// Init Method.
        /// </summary>
        /// <param name="context">Http context.</param>
        public void Init(HttpApplication context)
        {
            context.PreSendRequestHeaders += this.OnPreSendRequestHeaders;
        }

        /// <summary>
        /// On presend request headers event.
        /// </summary>
        /// <param name="sender">Object sender.</param>
        /// <param name="e">Event args.</param>
        private void OnPreSendRequestHeaders(object sender, EventArgs e)
        {
            if (HttpContext.Current == null)
                return;
            HttpContext.Current.Response.Headers.Set("Server", "NEWEGG");
        }
    }
}