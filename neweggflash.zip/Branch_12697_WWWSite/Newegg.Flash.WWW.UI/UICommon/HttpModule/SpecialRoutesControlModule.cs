﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newegg.Framework.Web;
namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Http module for custommize server header.
    /// </summary>
    public class SpecialRoutesControlModule : IHttpModule
    {
        /// <summary>
        /// Dispose the http module.
        /// </summary>
        public void Dispose()
        {
        }

        /// <summary>
        /// Init Method.
        /// </summary>
        /// <param name="context">Http context.</param>
        public void Init(HttpApplication context)
        {
            context.BeginRequest += OnBeginRequest;
        }

        private void OnBeginRequest(object sender, EventArgs e)
        {
            if (HttpContext.Current == null) return;
            var routes = Common.ConfigurationWWWManager<Common.Configuration.SpecialRoutesControl>.ItemCfg();
            if (routes == null || routes.SpecialRoutes == null) return;
            var path = HttpContext.Current.Request.Path.ToLower();
            //            var clientIp = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            //            if (string.IsNullOrEmpty(clientIp)) clientIp = HttpContext.Current.Request.UserHostAddress;
            var clientIp = WebUtility.ReferenceIP();
            var isSpecialRoute = routes.SpecialRoutes.Exists(route => path.IndexOf(route.Path.ToLower()) >= 0);
            var iplist = string.Empty;
            routes.Allows.ForEach(route => iplist += route.Value + ",");
            var isAllowed = iplist.IndexOf(clientIp) >= 0;
            if (isSpecialRoute && !isAllowed)
            {
                HttpContext.Current.Response.Redirect("~/oops?code=404");
            }

        }
    }
}