﻿using Newegg.Flash.WWW.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.EC.Web.Mvc;

namespace Newegg.Flash.WWW.UI.UICommon
{
   [Obsolete("Due to force login requirement changed, this attribute has been obsoleted, please reference CRL#:24272 SRS document.")] 
    public class AuthenticationRequiredAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().EnableForceLogin &&
                  (filterContext.Controller.ViewBag.UserInfo == null ||
                    string.IsNullOrEmpty(filterContext.Controller.ViewBag.UserInfo.CustomerNumber) ||
                    !filterContext.Controller.ViewBag.UserInfo.IsLogin))
            {
                filterContext.Result = new RedirectResult(string.Format("~/?url={0}", Uri.EscapeDataString(filterContext.HttpContext.Request.RawUrl)));
                return;
            }
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            filterContext.Controller.ViewBag.PopLoginRedirectUrl = (new UrlHelper(filterContext.RequestContext)).BuildUrl(PageAliase.Homepage).TrimEnd('/') + "/?url=" + Uri.EscapeDataString(HttpContext.Current.Request.RawUrl);
        }
    }
}
