﻿namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// The third party process interface.
    /// </summary>
    public interface ITrackingBuilder
    {
        /// <summary>
        /// Gets the Builder name.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Process the third party process.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        /// <returns>The result.</returns>
        string Build(TrackingContext context);
    }
}
