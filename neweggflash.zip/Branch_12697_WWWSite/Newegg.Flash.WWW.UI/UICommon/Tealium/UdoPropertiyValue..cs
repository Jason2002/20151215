﻿using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium
{
    /// <summary>
    /// Udo property value.
    /// </summary>
    public class UdoPropertiyValue
    {
        /// <summary>
        /// Gets or sets the configed property.
        /// </summary>
        public UdoProperty ConfigProperty { get; set; }

        /// <summary>
        /// Gets or sets the property value.
        /// </summary>
        public string Content { get; set; }
    }
}