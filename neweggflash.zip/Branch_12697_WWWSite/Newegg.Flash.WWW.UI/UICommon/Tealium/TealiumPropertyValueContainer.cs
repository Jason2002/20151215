﻿using Newegg.Flash.WWW.Common.Configuration.Tealium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium
{
    /// <summary>
    /// Tealium propery value container.
    /// </summary>
    public static class TealiumPropertyValueContainer
    {
        /// <summary>
        /// Current private udo properties with values.
        /// </summary>
        private static ThreadLocal<Dictionary<TealiumPropertyName, UdoPropertiyValue>> globalValues = new ThreadLocal<Dictionary<TealiumPropertyName, UdoPropertiyValue>>();

        /// <summary>
        /// Current private udo properties with values.
        /// </summary>
        private static ThreadLocal<Dictionary<TealiumPropertyName, UdoPropertiyValue>> privateValues = new ThreadLocal<Dictionary<TealiumPropertyName, UdoPropertiyValue>>();

        /// <summary>
        /// Gets or sets the global property values.
        /// </summary>
        public static Dictionary<TealiumPropertyName, UdoPropertiyValue> GlobalPropertyValues
        {
            get { return globalValues.Value; }

            set { globalValues.Value = value; }
        }

        /// <summary>
        /// Gets or sets the private property values.
        /// </summary>
        public static Dictionary<TealiumPropertyName, UdoPropertiyValue> PrivatePropertyValues
        {
            get { return privateValues.Value; }

            set { privateValues.Value = value; }
        }

        /// <summary>
        /// Clear the data.
        /// </summary>
        public static void Reset()
        {
            privateValues.Value = null;
            globalValues.Value = null;
        }
    }
}