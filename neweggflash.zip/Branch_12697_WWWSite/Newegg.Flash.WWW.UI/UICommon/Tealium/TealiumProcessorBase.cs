﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Web;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium
{
    /// <summary>
    /// Tealium processor base.
    /// </summary>
    public abstract class TealiumProcessorBase
    {        
        /// <summary>
        /// Gets the tealium config.
        /// </summary>
        protected static TealiumIQ TealiumConfig
        {
            get
            {
                return ConfigurationWWWManager<ThirdParty>.ItemCfg().TealiumIQ;
            }
        }

        /// <summary>
        /// Gets or sets the currenty propery dictionary.
        /// </summary>
        protected virtual Dictionary<TealiumPropertyName, UdoPropertiyValue> CurrentPropertyValues
        {
            get { return TealiumPropertyValueContainer.PrivatePropertyValues; }

            set { TealiumPropertyValueContainer.PrivatePropertyValues = value; }
        }

        /// <summary>
        /// Procss tealium values.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        /// <returns>Tealium value list.</returns>
        public Dictionary<TealiumPropertyName, UdoPropertiyValue> Process(TrackingContext context)
        {
            this.CurrentPropertyValues = this.LoadConfigProperties(context);
            if (this.CurrentPropertyValues.Count != 0)
            {
                this.FillDynamicProperty(context);
            }

            return this.CurrentPropertyValues;
        }

        /// <summary>
        /// Load configed properties.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        /// <returns>Tealium udo property values.</returns>
        protected virtual Dictionary<TealiumPropertyName, UdoPropertiyValue> LoadConfigProperties(TrackingContext context)
        {
            var data = new Dictionary<TealiumPropertyName, UdoPropertiyValue>();

            if (TealiumConfig.IsConfigForAction(context.ActionKey))
            {
                var pageConfig = TealiumConfig[context.ActionKey];
                if (pageConfig != null && pageConfig.PropertyList != null)
                {
                    foreach (var item in pageConfig.PropertyList)
                    {
                        if (item.Enable == true)
                        {
                            var value = new UdoPropertiyValue
                            {
                                ConfigProperty = item,
                                Content = item.Value ?? string.Empty
                            };

                            data.Add(item.Name, value);
                        }
                    }
                }
            }

            return data;
        }

        /// <summary>
        /// Sets value for special key.
        /// </summary>
        /// <param name="key">The udo key.</param>
        /// <param name="value">The udo value.</param>
        /// <param name="isEncode">Indicating whether encode the value using javascript encoding.</param>
        protected virtual void SetValue(TealiumPropertyName key, string value, bool isEncode = true)
        {
            ////如果页面私有字段和共有字段有相同的key，以私有字段配置为准，覆盖共有字段。
            if (TealiumPropertyValueContainer.PrivatePropertyValues.ContainsKey(key))
            {
                if (TealiumPropertyValueContainer.PrivatePropertyValues[key].ConfigProperty.Override == true)
                {
                    var data = isEncode ? HttpUtility.JavaScriptStringEncode(value) : value;
                    TealiumPropertyValueContainer.PrivatePropertyValues[key].Content = data;
                }

                ////移除公共字段中的对应值，以便后续输出不至于有多个相同json字段，导致错误。
                if (TealiumPropertyValueContainer.GlobalPropertyValues.ContainsKey(key))
                {
                    TealiumPropertyValueContainer.GlobalPropertyValues.Remove(key);
                }
            }
            else if (TealiumPropertyValueContainer.GlobalPropertyValues.ContainsKey(key))
            {
                if (TealiumPropertyValueContainer.GlobalPropertyValues[key].ConfigProperty.Override == true)
                {
                    var data = isEncode ? HttpUtility.JavaScriptStringEncode(value) : value;
                    TealiumPropertyValueContainer.GlobalPropertyValues[key].Content = data;
                }
            }
        }

        /// <summary>
        /// Build breadcrumb.
        /// </summary>
        /// <param name="navagatons">Navagation items</param>
        /// <returns>Breadcrumb items.</returns>
        protected string BuildBreadcrumb(List<NavgationItem> navagatons)
        {
            if (navagatons == null)
            {
                return string.Empty;
            }

            var sb = new StringBuilder();
            foreach (var item in navagatons)
            {
                sb.Append(item.Name).Append(" > ");
            }

            return sb.Remove(sb.Length - 2, 2).ToString();
        }

        /// <summary>
        /// Fill the propery with dynamic data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected abstract void FillDynamicProperty(TrackingContext context);

        #region Product Info Builder
        /// <summary>
        /// The combination data Builder.
        /// </summary>
        protected class Builder
        {
            /// <summary>
            /// The data builders.
            /// </summary>
            private List<StringBuilder> builders = new List<StringBuilder>();

            /// <summary>
            /// The tealium propertiy list to be build.
            /// </summary>
            private List<TealiumPropertyName> properties;

            /// <summary>
            /// The "SetValue" function.
            /// </summary>
            private Action<TealiumPropertyName, string, bool> action;

            /// <summary>
            /// Initializes a new instance of the Builder class.
            /// </summary>
            /// <param name="props">Tealium propery name list.</param>
            /// <param name="act">Build result function.</param>
            public Builder(List<TealiumPropertyName> props, Action<TealiumPropertyName, string, bool> act)
            {
                if (props == null || props.Count == 0)
                {
                    throw new ArgumentException("props cannot be empty.");
                }

                this.properties = props;

                if (act == null)
                {
                    throw new ArgumentException("action cannot be null.");
                }

                this.action = act;

                for (int i = 0; i < props.Count; i++)
                {
                    this.builders.Add(new StringBuilder());
                }
            }

            /// <summary>
            /// Add [.
            /// </summary>
            public void AppendPre()
            {
                this.AppendInfo("[");
            }

            /// <summary>
            /// Add ].
            /// </summary>
            public void AppendSuffix()
            {
                this.AppendInfo("]");
            }

            /// <summary>
            /// Add ",".
            /// </summary>
            public void AppendComma()
            {
                this.AppendInfo(",");
            }

            /// <summary>
            /// Add double quotes.
            /// </summary>
            public void AppendQuote()
            {
                this.AppendInfo("\"");
            }

            /// <summary>
            /// Append data.
            /// </summary>
            /// <param name="datas">Data lists. the sequence of the lists must bring into correspondence with the TealiumPropertyName list.</param>
            public void AppendData(params string[] datas)
            {
                if (datas == null || datas.Length != this.builders.Count)
                {
                    throw new ArgumentException("datas must not null and datas length must match the length of builders");
                }

                for (int i = 0; i < datas.Length; i++)
                {
                    this.builders[i].Append(HttpUtility.JavaScriptStringEncode(datas[i] ?? string.Empty));
                }
            }

            /// <summary>
            /// Build result.
            /// </summary>
            public void BuildResult()
            {
                for (int i = 0; i < this.properties.Count; i++)
                {
                    this.action(this.properties[i], this.builders[i].ToString(), false);
                }
            }

            /// <summary>
            /// Append symbol.
            /// </summary>
            /// <param name="symbol">The symbol to append.</param>
            private void AppendInfo(string symbol)
            {
                this.builders.ForEach(o => o.Append(symbol));
            }
        }
        #endregion
    }
}