﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon.Tealium.Processors;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium
{
    /// <summary>
    /// Tealium processor manager.
    /// </summary>
    public partial class TealiumProcessorManager
    {
        /// <summary>
        /// Global processor.
        /// </summary>
        private static readonly TealiumProcessorBase globalProcessor = new TealiumGlobalProcessor();

        /// <summary>
        /// Tealium common private processor.
        /// </summary>
        private static readonly TealiumProcessorBase commonPrivateProssesor = new TealiumCommonProcessor();

        /// <summary>
        /// Tealium private processors mapping. The key is controller name plus action name, seperated by dot mark.
        /// </summary>
        private static Lazy<Dictionary<string, TealiumProcessorBase>> processors = new Lazy<Dictionary<string, TealiumProcessorBase>>(InitProcessorMapping);

        /// <summary>
        /// Init processor mapping.
        /// </summary>
        /// <returns>Init Processor mapping.</returns>
        private static Dictionary<string, TealiumProcessorBase> InitProcessorMapping()
        {
            return TrackingProcessorMappingHelper.InitProcessorMapping<TealiumProcessorManager, TealiumProcessorBase, TealiumAttribute>();
        }
    }
}