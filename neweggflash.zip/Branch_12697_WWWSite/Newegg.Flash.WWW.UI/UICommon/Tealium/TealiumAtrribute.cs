﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium
{
    /// <summary>
    /// Tealium customer attribute.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class TealiumAttribute : TrackingMappingAtrribute
    {
        /// <summary>
        /// Initializes a new instance of the TealiumAttribute class.
        /// </summary>
        /// <param name="processorType">Type of processor.</param>
        public TealiumAttribute(Type processorType)
            : base(processorType)
        {
        }
    }
}