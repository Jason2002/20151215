﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// For product policy.
    /// </summary>
    public class TealiumProductReturnPolicyProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            var model = context.ViewData.Model as ReturnPolicyPage;
            if (model != null)
            {
                SetValue(TealiumPropertyName.page_breadcrumb, this.BuildBreadcrumb(model.Item.Navgations));
                SetValue(TealiumPropertyName.page_campaign_name, model.Item.CampaignName);

                var properties = new List<TealiumPropertyName>
                {
                    TealiumPropertyName.product_id,
                    TealiumPropertyName.product_title,
                    TealiumPropertyName.product_subcategory_desc
                };

                var builder = new Builder(properties, this.SetValue);

                builder.AppendPre();
                builder.AppendQuote();

                builder.AppendData(
                    ItemNumberConvert.ItemNumber2NeweggItemNumber(model.Item.ItemNumber),
                    model.Item.Description,
                    string.IsNullOrEmpty(model.Item.SubcategoryName) ? string.Empty : model.Item.SubcategoryName.Trim()
                );

                builder.AppendQuote();
                builder.AppendSuffix();

                builder.BuildResult();
            }
        }
    }
}