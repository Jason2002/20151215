﻿using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// Campaign processor.
    /// </summary>
    public class TealiumCampainProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            var model = context.ViewData.Model as CampaignPage;
            if (model != null && model.Campaign != null)
            {
                SetValue(TealiumPropertyName.page_name, "Campaign-" + model.Campaign.CampaignId.ToString());
                SetValue(TealiumPropertyName.page_campaign_name, model.Campaign.CampaignName);
                SetValue(TealiumPropertyName.page_campaign_id, model.Campaign.CampaignId.ToString());

                SetValue(TealiumPropertyName.page_breadcrumb, this.BuildBreadcrumb(model.Navgations));
            }
        }
    }
}