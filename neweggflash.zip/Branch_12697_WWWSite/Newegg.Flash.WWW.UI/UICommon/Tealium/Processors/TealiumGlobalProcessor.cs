﻿using System.Collections.Generic;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// Process the global properties for the configured pages.
    /// </summary>
    public class TealiumGlobalProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Gets or sets the currenty propery dictionary.
        /// </summary>
        protected override Dictionary<TealiumPropertyName, UdoPropertiyValue> CurrentPropertyValues
        {
            get { return TealiumPropertyValueContainer.GlobalPropertyValues; }

            set { TealiumPropertyValueContainer.GlobalPropertyValues = value; }
        }

        /// <summary>
        /// Load global config properties.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        /// <returns>Property values.</returns>
        protected override Dictionary<TealiumPropertyName, UdoPropertiyValue> LoadConfigProperties(TrackingContext context)
        {
            var data = new Dictionary<TealiumPropertyName, UdoPropertiyValue>();

            foreach (var item in TealiumConfig.GlobalUdoProperties)
            {
                if (item.Enable == true)
                {
                    var value = new UdoPropertiyValue
                    {
                        ConfigProperty = item,
                        Content = item.Value ?? string.Empty
                    };

                    data.Add(item.Name, value);
                }
            }

            return data;
        }

        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            var pageConfig = TealiumConfig[context.ActionKey];
            if (pageConfig == null || pageConfig.Page == null)
            {
                return;
            }

            SetValue(TealiumPropertyName.page_name, pageConfig.Page.Name);
            SetValue(TealiumPropertyName.page_type, pageConfig.Page.Type);
            SetValue(TealiumPropertyName.page_breadcrumb, pageConfig.Page.Breadcrumb);
        }

        /// <summary>
        /// Sets value for special key.
        /// </summary>
        /// <param name="key">The udo key.</param>
        /// <param name="value">The udo value.</param>
        /// <param name="isEncode">Indicating whether encode the value using javascript encoding.</param>
        protected override void SetValue(TealiumPropertyName key, string value, bool isEncode = true)
        {
            if (TealiumPropertyValueContainer.GlobalPropertyValues.ContainsKey(key))
            {
                if (TealiumPropertyValueContainer.GlobalPropertyValues[key].ConfigProperty.Override == true)
                {
                    var data = isEncode ? HttpUtility.JavaScriptStringEncode(value) : value;
                    TealiumPropertyValueContainer.GlobalPropertyValues[key].Content = data;
                }
            }
        }
    }
}