﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// For ProductController.Index action.
    /// </summary>
    public class TealiumProductProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            var model = context.ViewData.Model as ItemGroup;
            if (model != null && model.Items != null && model.Items.Count > 0)
            {
                var currentItem = model.Items[model.CurrentItemIndex];
                if (currentItem.ExpireTicks <= 0)
                {
                    SetValue(TealiumPropertyName.page_campaign_name, string.Empty);
                }
                else
                {
                    SetValue(TealiumPropertyName.page_campaign_name, currentItem.CampaignName);
                }
                SetValue(TealiumPropertyName.page_breadcrumb, this.BuildBreadcrumb(model.Navgations));

                var properties = new List<TealiumPropertyName>
                {
                    TealiumPropertyName.product_id,
                    TealiumPropertyName.product_title,
                    TealiumPropertyName.product_unit_price,
                    TealiumPropertyName.product_sale_price,
                    TealiumPropertyName.product_subcategory_desc,
                    TealiumPropertyName.product_promo_text,
                    TealiumPropertyName.product_manufacture,
                    TealiumPropertyName.product_type,
                    TealiumPropertyName.product_model,
                };

                var builder = new Builder(properties, this.SetValue);

                builder.AppendPre();
                foreach (var item in model.Items)
                {
                    builder.AppendQuote();

                    var id = ItemNumberConvert.ItemNumber2NeweggItemNumber(item.ItemNumber);
                    var title = item.Description;
                    var unitPrice = item.UnitPrice.ToString("0.00");
                    var salsePrice = item.FinalPrice.ToString("0.00");
                    var subCategory = item.SubcategoryName ?? string.Empty;
                    var promoText = item.BuyerContent;
                    var manufacture = string.Empty;
                    var type = string.Empty;
                    var productModel = string.Empty;

                    builder.AppendData(id, title, unitPrice, salsePrice, subCategory, 
                        promoText, manufacture, type, productModel);

                    builder.AppendQuote();

                    if (model.Items.IndexOf(item) != model.Items.Count - 1)
                    {
                        builder.AppendComma();
                    }
                }
                builder.AppendSuffix();

                builder.BuildResult();
            }
        }
    }
}