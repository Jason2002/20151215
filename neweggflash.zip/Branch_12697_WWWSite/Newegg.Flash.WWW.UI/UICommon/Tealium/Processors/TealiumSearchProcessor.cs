﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// For search page.
    /// </summary>
    public class TealiumSearchProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            var model = context.ViewData.Model as SearchPage;
            if (model != null)
            {
                SetValue(TealiumPropertyName.page_breadcrumb, this.BuildBreadcrumb(model.Navgations));
                SetValue(TealiumPropertyName.search_keyword, model.Keyword);
                SetValue(TealiumPropertyName.search_results, model.Items.Count.ToString());
            }
        }
    }
}