﻿using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// Campaign processor.
    /// </summary>
    public class TealiumConfigurableHeadlineProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            var headline = context.ViewBag.Headline;
            dynamic model = context.ViewData.Model;
            if (!string.IsNullOrEmpty(headline)&& model !=null)
            {
                SetValue(TealiumPropertyName.page_name, headline);
                SetValue(TealiumPropertyName.page_type, headline);
                var nav = model.Navgations;
                if(nav !=null)
                    SetValue(TealiumPropertyName.page_breadcrumb, BuildBreadcrumb(nav));
            }
        }
    }
}