﻿namespace Newegg.Flash.WWW.UI.UICommon.Tealium.Processors
{
    /// <summary>
    /// For common pages.
    /// </summary>
    public class TealiumCommonProcessor : TealiumProcessorBase
    {
        /// <summary>
        /// Fill the page data.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        protected override void FillDynamicProperty(TrackingContext context)
        {
            ////Nothing need to do.
        }
    }
}