﻿using System;
using System.Collections.Generic;
using System.Text;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.Tealium;

namespace Newegg.Flash.WWW.UI.UICommon.Tealium
{
    /// <summary>
    /// Tealium processor manager.
    /// </summary>
    public partial class TealiumProcessorManager : ITrackingBuilder
    {
        public string Name { get { return "TealiumBuilder"; } }

        /// <summary>
        /// Gets tealium config.
        /// </summary>
        private static TealiumIQ TealiumConfig
        {
            get
            {
                return ConfigurationWWWManager<ThirdParty>.ItemCfg().TealiumIQ;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the tealium is enabled.
        /// </summary>
        private static bool IsTealiumEnabled
        {
            get
            {
                return ConfigurationWWWManager<ThirdParty>.ItemCfg().TealiumIQEnable;
            }
        }

        /// <summary>
        /// Process tealium.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        /// <returns>Tealium final script string.</returns>
        public string Build(TrackingContext context)
        {
            if (IsTealiumEnabled == false)
            {
                return string.Empty;
            }

            if (!TealiumConfig.IsConfigForAction(context.ActionKey))
            {
                return string.Empty;
            }

            TealiumPropertyValueContainer.Reset();

            ProcessGlobalProperties(context);
            ProcessPrivateProperties(context);
            var script = MergeScript();

            TealiumPropertyValueContainer.Reset();

            return script;
        }

        /// <summary>
        /// Process global property.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        private static void ProcessGlobalProperties(TrackingContext context)
        {
            globalProcessor.Process(context);
        }

        /// <summary>
        /// Process private property.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        private static void ProcessPrivateProperties(TrackingContext context)
        {
            var processor = GetProcessor(context);

            if (processor == null)
            {
                return;
            }

            processor.Process(context);
        }

        /// <summary>
        /// Merge script.
        /// </summary>
        /// <returns>Final scripts string.</returns>
        private static string MergeScript()
        {
            var udoInfo = new StringBuilder();

            foreach (var item in TealiumPropertyValueContainer.GlobalPropertyValues)
            {
                if (item.Value.Content.StartsWith("["))
                {
                    udoInfo.Append(item.Key.ToString()).Append(":").Append(item.Value.Content).Append(",");
                }
                else
                {
                    udoInfo.Append(item.Key.ToString()).Append(":\"").Append(item.Value.Content).Append("\",");
                }
            }

            foreach (var item in TealiumPropertyValueContainer.PrivatePropertyValues)
            {
                if (item.Value.Content.StartsWith("["))
                {
                    udoInfo.Append(item.Key.ToString()).Append(":").Append(item.Value.Content).Append(",");
                }
                else
                {
                    udoInfo.Append(item.Key.ToString()).Append(":\"").Append(item.Value.Content).Append("\",");
                }
            }

            if (udoInfo.Length > 0)
            {
                udoInfo.Remove(udoInfo.Length - 1, 1);
            }

            var script = TealiumConfig.Code.Replace("$account$", TealiumConfig.Account)
                .Replace("$profile$", TealiumConfig.Profile)
                .Replace("$udo$", udoInfo.ToString());
#if DEBUG
            if (TealiumConfig.EnableDebug == true)
            {
                script += "<script type='text/javascript'>if(window.console) console.log(utag_data);</script>";
            }
#endif
            return script;
        }

        /// <summary>
        /// Get private property processor.
        /// </summary>
        /// <param name="context">Tealium context.</param>
        /// <returns>Private processor.</returns>
        private static TealiumProcessorBase GetProcessor(TrackingContext context)
        {
            if (context == null)
            {
                throw new ArgumentException("invalid param: context cannot be null");
            }

            TealiumProcessorBase processor;
            processors.Value.TryGetValue(context.ActionKey, out processor);

            if (processor == null)
            {
                return commonPrivateProssesor;
            }

            return processor;
        }
    }
}