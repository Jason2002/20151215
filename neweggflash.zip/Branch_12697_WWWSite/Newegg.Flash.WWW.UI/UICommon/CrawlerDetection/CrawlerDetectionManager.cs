﻿using Newegg.EC;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;
using Newegg.Framework.Web;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.UICommon.CrawlerDetection
{
    public class CrawlerDetectionManager
    {
        private const string COOKIE_NAME_UTMA = "__utma";
        private const string REGEX_PATTERN_UTMA = @"^(\d+)\.(\d+)\.(\d+)";

        public static CrawlerProtectionInfo DetectCrawler(ActionExecutingContext context) 
        {
            var ip = WebUtility.ReferenceIP();
            var utma = GetUTMA();

            if(string.IsNullOrEmpty(ip) && string.IsNullOrEmpty(utma))
            {
                return null;
            }

            var service = ECLibraryContainer.Current.GetInstance<ICrawlerProtection>();
            return service.LoadProtectionInfo(ip, utma);
        }

        private static string GetUTMA()
        {
            if (HttpContext.Current != null)
            {
                HttpCookie httpCookie = HttpContext.Current.Request.Cookies[COOKIE_NAME_UTMA];
                if (httpCookie != null)
                {
                    Match match = Regex.Match(httpCookie.Value, REGEX_PATTERN_UTMA);
                    if (match.Success)
                    {
                        return match.Value;
                    }
                }
            }

            return string.Empty;
        }
    }
}