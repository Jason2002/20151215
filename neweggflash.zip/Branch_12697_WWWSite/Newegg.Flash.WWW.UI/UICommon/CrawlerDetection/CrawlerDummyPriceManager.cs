﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.CrawlerDetection
{
    public class CrawlerDummyPriceManager
    {
        /// <summary>
        /// 保存各个页面Model找到Item的映射器
        /// </summary>
        private static Dictionary<Type, Action<object>> ms_Processor = new Dictionary<Type, Action<object>>();

        /// <summary>
        /// 初始化映射器。
        /// 这里根据页面Model的类型，映射获取ItemBase对象的lambda表达式方法
        /// </summary>
        static CrawlerDummyPriceManager()
        {
            //HomePage
            InitCast<HomePage>(o => o.TodayBestDeals.Items.Where(p => p.ItemType == 1).Select(p => p.Item));
            //CampaingPage, featuredpage and SearchPage
            InitCast<KeyValuePair<int, List<ItemBase>>>(o => o.Value);
            //CampageInit
            InitCast<CampaignPage>(o => o.Items);
            //Featured
            InitCast<FeaturedPage>(o => o.Items);
            //Product detail
            InitCast<ItemGroup>(p => p.Items);
            //RetrunPolicy
            InitCast<ReturnPolicyPage>(p => p.Item);
            //Search Page
            InitCast<SearchPage>(p => p.Items);
            //TodayDeals
            InitCast<TodayDeals>(o => o.Deals.Where(p => p.ItemType == 1).Select(p => p.Item));
            //UpcommingDeals
            //InitCast<UpcomingSales>(o => o.Deals.Values.Select(p => p.Select(c => c.Item)));
        }

        /// <summary>
        /// 生成映射器模板方法。
        /// 用页面Model类型Type为键值，欺诈价格的处理逻辑为Value。
        /// </summary>
        /// <typeparam name="T">页面Model类型</typeparam>
        /// <param name="func">获取Model类型中IemBase对象集合的lambda表达式。</param>
        private static void InitCast<T>(Func<T, IEnumerable<ItemBase>> func)
        {
            ms_Processor.Add(typeof(T), model =>
            {
                Process(func((T)model));
            });
        }

        /// <summary>
        /// 生成映射器模板方法。
        /// 用页面Model类型Type为键值，欺诈价格的处理逻辑为Value。
        /// </summary>
        /// <typeparam name="T">页面Model类型</typeparam>
        /// <param name="func">获取Model类型中IemBase对象的lambda表达式。</param>
        private static void InitCast<T>(Func<T, ItemBase> func)
        {
            ms_Processor.Add(typeof(T), model =>
            {
                Process(func((T)model));
            });
        }

        /// <summary>
        /// 生成映射器模板方法。
        /// 用页面Model类型Type为键值，欺诈价格的处理逻辑为Value。
        /// </summary>
        /// <typeparam name="T">页面Model类型</typeparam>
        /// <param name="func">
        /// 获取Model类型中IemBase对象集合的lambda表达式。这里主要针对Upcoming页面
        /// </param>
        //private static void InitCast<T>(Func<T, IEnumerable<IEnumerable<ItemBase>>> func)
        //{
        //    ms_Processor.Add(typeof(T), model =>
        //    {
        //        var list = func((T)model);
        //        foreach (var item in list)
        //        {
        //            Process(item);
        //        }
        //    });
        //}

        /// <summary>
        /// Dummy Price处理入口
        /// </summary>
        /// <param name="model"></param>
        public static void ProcessDummyPrice(object model)
        {
            

            if (model != null && ms_Processor.ContainsKey(model.GetType()))
            {
                try
                {
                    ms_Processor[model.GetType()](model);
                }
                catch (Exception ex)
                {
                }
            }
        }

        /// <summary>
        /// 价格处理为原始价格，无折扣
        /// </summary>
        /// <param name="item"></param>
        private static void Process(ItemBase item)
        {
            if (item == null)
            {
                return;
            }

            item.DiscountInstant = 0;
            item.DiscountMark = false;
            item.FinalPrice = item.UnitPrice;
        }

        /// <summary>
        /// 批量价格处理
        /// </summary>
        /// <param name="itemList"></param>
        private static void Process(IEnumerable<ItemBase> itemList)
        {
            if (itemList == null)
            {
                return;
            }

            itemList.ToList().ForEach(p => Process(p));
        }
    }
}