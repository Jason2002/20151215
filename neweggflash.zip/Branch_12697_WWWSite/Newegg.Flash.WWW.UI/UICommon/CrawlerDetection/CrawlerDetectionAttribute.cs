﻿using Newegg.EC;
using Newegg.EC.Log;
using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.UICommon.CrawlerDetection
{
    /// <summary>
    /// 爬虫保护处理拦截器。
    /// 在需要进行爬虫价格保护的Action上应用该Attribute。
    /// </summary>
    public class CrawlerDetectionAttribute : ActionFilterAttribute
    {
        private const string HTTP_HEADER_VARNISH_NAME = "X-From-Cache";
        private const string THREADSTORAGE_KEY_ISBYPASSVARNISHCRAWLERSOURCE = "IsByPassVarnish4CrawlerSource";

        private ConcurrentDictionary<HttpRequest, CrawlerProtectionInfo> protectionInfo = new ConcurrentDictionary<HttpRequest,CrawlerProtectionInfo>();       
        /// <summary>
        /// 请求到达，执行Action之前进行爬虫预处理操作。
        /// 调用service利用ip和utma判定该请求是否由爬虫发起。
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            try
            {
                //根据请求判定是否是爬虫
                var info = CrawlerDetectionManager.DetectCrawler(actionContext);
                if (info != null)
                {
                    if (info.HandlerType == CrawlerHandlerType.Pass)
                    {
                        return;
                    }

                    //如果请求来自于varnish，并且需要跳过varnish缓存，则设置Http响应头，指示varnish不进行缓存
                    var currentContext = HttpContext.Current;
                    if (info.IsBypassVarnish == true
                        && currentContext.Request.Headers[HTTP_HEADER_VARNISH_NAME] != null)
                    {
                        currentContext.Response.Headers.Add(THREADSTORAGE_KEY_ISBYPASSVARNISHCRAWLERSOURCE, "true");
                    }

                    //如果是爬虫，处理类型时直接403或者页面保护为false，都直接到403页面
                    if (info.HandlerType == CrawlerHandlerType.Forbidden
                        || info.IsProtectedResponse == false)
                    {
                        actionContext.Result = new RedirectResult("~/oops/message?code=403");
                    }
                    else
                    {
                        //在非403保护模式下，将爬虫信息保存到线程中，供Action执行完成后，
                        //在Attribute的OnActionExecuted中使用
                        protectionInfo.TryAdd(currentContext.Request, info);
                    }
                }
            }
            catch (Exception ex)
            {
                this.Log(ex, "Process Crawler Detection.");
            }
        }

        /// <summary>
        /// Action执行完成，render view之前进行拦截处理。
        /// 目前主要判断保护类型是DummyPrice的请求，进行价格替换操作。
        /// </summary>
        /// <param name="actionExecutedContext"></param>
        public override void OnActionExecuted(ActionExecutedContext actionExecutedContext)
        {
            try
            {
                CrawlerProtectionInfo info;
                this.protectionInfo.TryRemove(HttpContext.Current.Request, out info);
                if (info != null && info.HandlerType == CrawlerHandlerType.DummyPrice)
                {
                    var viewResult = actionExecutedContext.Result as ViewResultBase;
                    if (viewResult != null && viewResult.Model != null)
                    {
                        CrawlerDummyPriceManager.ProcessDummyPrice(viewResult.Model);
                    }
                }
            }
            catch (Exception ex)
            {
                this.Log(ex, "Process Dummy Price.");
            }
        }

        /// <summary>
        /// 异常日志辅助
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="msg"></param>
        private void Log(Exception ex, string msg)
        {
            try
            {
                var log = ECLibraryContainer.Current.GetInstance<ILogger>();
                if (log != null)
                {
                    log.Exception = ex;
                    log.AddCategory("Newegg.Flash");
                    log.AddMessage(msg);
                    log.Write();
                }
            }
            catch { }
        }
    }
}