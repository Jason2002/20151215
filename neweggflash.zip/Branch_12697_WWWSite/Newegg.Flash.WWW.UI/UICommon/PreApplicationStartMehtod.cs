﻿
namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Dynamic register the module without modify your web.config.
    /// You can reference here: http://blog.davidebbo.com/2011/02/register-your-http-modules-at-runtime.html
    /// </summary>
    public class PreApplicationStartMethod
    {
        public static void Init()
        {
            Microsoft.Web.Infrastructure.DynamicModuleHelper.DynamicModuleUtility.RegisterModule(typeof(WebAppManangerModule));
            Microsoft.Web.Infrastructure.DynamicModuleHelper.DynamicModuleUtility.RegisterModule(typeof(SpecialRoutesControlModule));
            Microsoft.Web.Infrastructure.DynamicModuleHelper.DynamicModuleUtility.RegisterModule(typeof(CustomServerHeaderModule));
        }
    }
}