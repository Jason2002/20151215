﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;

namespace Newegg.Flash.WWW.UI
{
    public class ClientResources
    {
        public string Wating
        {
            get
            {
                return Globalization.Global.Waiting;
            }
        }

        public string Send
        {
            get
            {
                return Globalization.Global.Send;
            }
        }

        public string EmailAddress
        {
            get
            {
                return Globalization.Login.Login_Email;
            }
        }

        public string RequiredField
        {
            get
            {
                return Globalization.Global.Warning_Required;
            }
        }

        public string MailCheck
        {
            get
            {
                return Globalization.Global.Validation_EmailFormat;
            }
        }

        public string Select
        {
            get
            {
                return Globalization.Global.Select;
            }
        }
        public string ViewCart
        {
            get
            {
                return Globalization.Global.ViewCart;
            }
        }
        public string Item
        {
            get
            {
                return Globalization.Global.Common_Item;
            }
        }

        public string Items
        {
            get
            {
                return Globalization.Global.Items;
            }
        }
        public string SearchWithin
        {
            get
            {
                return Globalization.Global.SearchWithin;
            }
        }

        public string[] WeekDays
        {
            get
            {
                DateTime date = DateTime.Now;
                date=date.AddDays( DayOfWeek.Sunday-date.DayOfWeek );// set to sunday;
                string[] days = new string[7];
                CultureInfo culture = Thread.CurrentThread.CurrentUICulture;
                for (int i= 0; i<7;i++)
                {
                    days[i] =  string.Format(culture, "{0:ddd}", date.AddDays(i));
                }
                return days;
               
            }
        }

        public string Days
        {
            get { return Globalization.Layout.Item_Day; }
        }

        public string Hours
        {
            get { return Globalization.Layout.Item_Hour; }
        }
        public string Minutes
        {
            get { return Globalization.Layout.Item_Minutes; }
        }
    }
}