﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI
{
    public  class ClientEvirment
    {
        public  string ToLetterCode
        {
            get
            {
                return BizThreadContext.RegionCode.TwoLetterCode;
            }
        }

        public  string RegionCode
        {
            get
            {
                return BizThreadContext.RegionCode.Code;
            }
        }

        public  string CurrencySymbol
        {
            get
            {
                return BizThreadContext.CurrentCurrencyInfo.Symbol;
            }
        }

        public  string CurrencyCode
        {
            get
            {
                return BizThreadContext.CurrentCurrencyCode;
            }
        }

        public  string GlobalPath
        {
            get
            {
                if (BizThreadContext.IsGlobalRequest)
                { 
                    return "/global/" + BizThreadContext.RegionCode.DisplayShortCode.ToLower() +"/";
                }
                return string.Empty;
            }
        }
        /// <summary>
        ///  get current timezone offset from utc. unit=ms
        /// </summary>
        public int CurrentTimeZoneOffset
        {
            get
            {
                var offset=BizThreadContext.CurrentTimeZone.GetUtcOffset(DateTime.UtcNow);
                return (int)offset.TotalMilliseconds;
            }
        }
    }
}