﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newegg.EC;
using Newegg.EC.Configuration;
using Newegg.EC.Cookie;
using Newegg.EC.Net;
using Newegg.EC.Web.Mvc;
using Newegg.EC.Net.Implement;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.UI.Controllers;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using Newegg.EC.Log;
using Newegg.Flash.WWW.Interface;
using System.Web.Mvc;
using Newegg.Flash.WWW.UI.UICommon.ABTesting;
using Newegg.Flash.WWW.UI.Filters;
using System.Text;
using Newegg.EC.BizUnit;
using Newegg.EC.NeweggComCookie;
using Newegg.EC.Cryptograph;
using Newegg.Framework.Threading;
using System.Text.RegularExpressions;
using Newegg.Flash.WWW.BizPolicy.Core;
using Newtonsoft.Json;
using System.Threading;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Flash Controller.
    /// </summary>
    public class FlashController : WebsiteController
    {

        #region constructor
        private CookieRepository cookieOperator = new CookieRepository();
        private bool _IsSwitchingCountry = false;
        private bool _IsRedirecting = false;
        private BizUI bizUI = null;
        private string _globalPath = null;

        /// <summary>
        /// Initializes a new instance of the FlashController class.
        /// </summary>
        public FlashController()
        {
            
            if (bizUI == null)
            {
                bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            }
            if (bizUI != null && bizUI.SwithToNewegg)
            {
                /*
                 * 这里获取NV_OTHERINFO和NV_DVINFO,仅仅是读取其中的登陆信息并加判断， 
                 * 不会发生回写。所以FlushToResponse中不会包含对这两个cookie的回写操作
                 * NeweggComCookies.config中这两个cookie的配置节点，expiresAfter其实是没有用到的，
                 * 随便配成什么都可以。       
                 *     <cookie cookieId="DVINFO" cookieName="NV_DVINFO" specialDomain="true" path="/" expiresAfter="0000.00:00:00" secureOnly="false" />
                 *     <cookie cookieId="OtherInfo" cookieName="NV_OTHERINFO" specialDomain="true" path="/" expiresAfter="00.00:00:00" secureOnly="false" renderInClient="false" />
                 * comments by jovi
                 */
                var loginName = DecryptString(cookieOperator.GetValue("OtherInfo", CookieConst.LOGINID6));
                var loginid5 = DecryptString(cookieOperator.GetValue("OtherInfo", CookieConst.LOGINID5));
                var loginid4 = cookieOperator.GetValue("OtherInfo", CookieConst.LOGINID4);
                var contactwith = cookieOperator.GetValue("OtherInfo", CookieConst.CONTACTWITH);
                var customerNumber = cookieOperator.GetValue("DVINFO", CookieConst.NeweggCustomerNumber);
                OtherInfoCookieModel otherinfo = new OtherInfoCookieModel
                {
                    LoginName = loginName,
                    LoginID5 = loginid5,
                    CustomerNumber = customerNumber,
                    ContactWith = contactwith,
                    Sortby = CookieHelper.ComInfoCookie.Current.Sortby,
                    SearchHistory = CookieHelper.ComInfoCookie.Current.SearchHistory
                };
                this.ViewBag.UserInfo = otherinfo;
            }
            else
            {
                this.ViewBag.UserInfo = CookieHelper.OtherInfoCookie.Current;
            }
            // 修改 Header Menu 部分的Featured Deals

            ViewBag.FeaturedDeals = Globalization.Layout.Headline_FeaturedDeals;
            //if (bizUI != null && bizUI.HeadlineConfig != null &&
            //    !string.IsNullOrEmpty(bizUI.HeadlineConfig.FeaturedDeals))
            //{
            //    ViewBag.FeaturedDeals = bizUI.HeadlineConfig.FeaturedDeals;
            //}

           

            //if (bizUI != null && bizUI.SwithToNewegg)
            //{
            // render Newegg cookie  前台配置
            var cookieConfig = ConfigurationWWWManager<NeweggComCookies>.ItemCfg();
            if (cookieConfig != null)
            {
                var scriptString = ProcessClientCookieConfig();
                MvcHtmlString scriptConfig = new MvcHtmlString(scriptString);
                ViewBag.CookieConfig = scriptConfig;
            }
            //}
            // 计算当前的copyright
            this.CalculateCopyright();
        }
        public string GlobalPath {
            get { return _globalPath; }
        }
        private string CookieRegionCode
        {
            get
            {
                return cookieOperator.GetValue("Configuration", CookieConst.GlobalRegionCode);
            }
        }

        private string CookieCurrencyCode
        {
            get
            {
                return cookieOperator.GetValue("Configuration", CookieConst.GlobalCurrencyCode);
            }
        }
        /// <summary>
        /// global site logic
        /// </summary>
        private string ProcessGlobalSite()
        {
            var redirectUrl = SetRegionCode();
            if (!_IsRedirecting)
            {
                SetCurrencyCode();
            }
            var lastRegion = CookieHelper.ComInfoCookie.Current.LastRegion;
            var lastCurrency = CookieHelper.ComInfoCookie.Current.LastCurrency;
            var newregion =LogicalThreadContext.GetData(BizThreadContext.THREADSTORAGE_KEY_REGIONCODEVALUE);
            var newcurrency =LogicalThreadContext.GetData(BizThreadContext.THREADSTORAGE_KEY_CURRENCYCODEVALUE);
            var new_Region =  newregion == null ? string.Empty: newregion.ToString();
            var new_Currency = newcurrency == null ? string.Empty : newcurrency.ToString();
            if (lastRegion != new_Region || lastCurrency != new_Currency)
            {
                CookieHelper.MiniCarCookie.Clear();

                CookieHelper.ComInfoCookie.SetLastRegion(new_Region);
                CookieHelper.ComInfoCookie.SetLastCurrency(new_Currency);
            }
            return redirectUrl;
        }

        private void SetCurrencyCode()
        {
            string currencyCodeCookie = this.CookieCurrencyCode;
            CountryCurrencyDetail currentCurrency = null;

            //Get currency by cookie.
            //If cookie value is invalid or switching country by change url, like from "global/ie/" to "global/nl/, get default currency
            //If no default currency, set currency cookie to ThreadStorage_Value_CurrencyCode_Default
            // get regioncode from current context
            IRegionCode regionCode = BizThreadContext.RegionCode;
            var regionCurrencys = BizThreadContext.Currencys.Where(x => x.CountryCode.Trim().Equals(regionCode.Code));
            if (regionCode != null && regionCurrencys != null && regionCurrencys.Count() > 0)
            {
                if (!string.IsNullOrWhiteSpace(currencyCodeCookie) && !_IsSwitchingCountry)
                {
                    currentCurrency = regionCurrencys.FirstOrDefault(p => p.CurrencyCode.Trim().Equals(currencyCodeCookie));
                }
                if (currentCurrency == null)
                {
                    currentCurrency = regionCurrencys.FirstOrDefault(code => code.IsLocalCurrency) ?? BizThreadContext.Currencys.FirstOrDefault();
                }
            }

            currencyCodeCookie = currentCurrency != null ? currentCurrency.CurrencyCode.Trim() : StringResource.ThreadStorage_Value_CurrencyCode_Default;

            cookieOperator.SetValue("Configuration", CookieConst.GlobalCurrencyCode, currencyCodeCookie);

            LogicalThreadContext.SetData(BizThreadContext.THREADSTORAGE_KEY_CURRENCYCODEVALUE, currencyCodeCookie);

        }

        private string SetRegionCode()
        {
            var returnUrl = string.Empty;
            
            if (BizThreadContext.BizUnitInfo == null ||
                BizThreadContext.BizUnitInfo.Regions == null ||
                BizThreadContext.BizUnitInfo.Regions.Count == 0)
            {
                return returnUrl;
            }

            IRegionCode currentRegionCode = null;
            Regex globalRegex = new Regex(@"/global/(\w{1,3})", RegexOptions.IgnoreCase);
            MatchCollection globalMatches = globalRegex.Matches(Request.RawUrl);

            // external request from shec .  外部请求回来的时候不知道是哪个region，所以不能用url去解析得到regioncode，而是直接用cookie中的region
            if (Request.Url.AbsoluteUri.ToLower().Contains("external/landing"))
            {
                currentRegionCode = BizThreadContext.BizUnitInfo.Regions.Where(x => CookieRegionCode.Equals(x.Code)).FirstOrDefault();
            }
            else
            {
                if (globalMatches != null
                    && globalMatches.Count > 0
                    && globalMatches[0].Groups.Count > 1
                    )
                {
                    // request url contains global site key words 

                    string displayShortCode = globalMatches[0].Groups[1].Value;

                    // get regions by displayShortCode
                    currentRegionCode = BizThreadContext.BizUnitInfo.Regions.FirstOrDefault(p => !string.IsNullOrWhiteSpace(p.DisplayShortCode)
                                                                                                                && p.DisplayShortCode.ToLower().Equals(displayShortCode.ToLower()));

                    // global url but wrong regioncode ,or  global/ us , return 404
                    if (currentRegionCode == null || BizThreadContext.BizUnitInfo.CountryCode.Equals(currentRegionCode.Code.Trim()))
                    {
                        _IsRedirecting = true;
                        returnUrl = Utility.WebHostWithScheme() + "/oops?code=404";
                    }
                    // if region changes , mark to change currency
                    if (currentRegionCode != null
                        && !string.IsNullOrEmpty(currentRegionCode.Code)
                        && !string.IsNullOrEmpty(CookieRegionCode)
                        && currentRegionCode.Code != CookieRegionCode)
                    {
                        _IsSwitchingCountry = true;
                    }

                }
                else
                {
                    
                    // if url does not contains global site key words, get the defaul site
                    //   get regioncode from regionlist (default) 
                    if (Request.Url.AbsolutePath.Length <= 1 && !string.IsNullOrEmpty(CookieRegionCode))
                    {
                        // visite home page with out global path  ,redirect to the region that saved in cookie 
                        currentRegionCode = BizThreadContext.BizUnitInfo.Regions.Where(x => CookieRegionCode.Equals(x.Code)).FirstOrDefault();

                        if (currentRegionCode == null)
                        {
                            currentRegionCode = BizThreadContext.BizUnitInfo.Regions.Where(x => x.IsDefault == true).FirstOrDefault();
                            if (currentRegionCode == null)
                            {
                                currentRegionCode = BizThreadContext.BizUnitInfo.Regions.FirstOrDefault();
                            }
                        }

                        // if not usa site ,change to 
                        if (!currentRegionCode.IsDefault)
                        {
                            _IsRedirecting = true;
                            String lan = currentRegionCode.DisplayShortCode ?? currentRegionCode.TwoLetterCode;
                            returnUrl =  Utility.WebHostWithScheme() + "/global/" + lan.ToLower(); 
                            return returnUrl;
                        }
                    }
                    else
                    {
                        // visite ther pages with out global path ,such as "/allstore/0", redirect to usa  region with the same path
                        currentRegionCode = BizThreadContext.BizUnitInfo.Regions.FirstOrDefault(r => r.IsDefault);
                        if (bizUI.IPData.Enable)
                        {
                            // get region code form ip
                            var ipUrl = string.Format(bizUI.IPData.URL, Utility.ReferenceIP());

                            string s = Utility.GetRegionByIP(ipUrl).Trim();
                            var ipregion = BizThreadContext.BizUnitInfo.Regions.Where(x => x.DisplayShortCode.ToLower().Equals(s.Trim().ToLower())).FirstOrDefault();
                            if (ipregion != null)
                            {
                                currentRegionCode = ipregion;
                            }
                        }
                    } 
                }
            }
            currentRegionCode = currentRegionCode ?? BizThreadContext.BizUnitInfo.Regions[0];

            // save the region code to context
            if (!string.IsNullOrWhiteSpace(currentRegionCode.Code))
            {
                // save regioncode to cookie
                cookieOperator.SetValue("Configuration", CookieConst.GlobalRegionCode, currentRegionCode.Code);

                // save to context
                LogicalThreadContext.SetData(BizThreadContext.THREADSTORAGE_KEY_REGIONCODEVALUE, currentRegionCode.Code);

                // set current region culture.
                Thread.CurrentThread.CurrentUICulture = currentRegionCode.Culture;
            }

            return returnUrl;
        }
        #endregion

        #region  overrided method

        protected override IAsyncResult BeginExecute(System.Web.Routing.RequestContext requestContext, AsyncCallback callback, object state)
        {
            this.ProcessSEOInfo();
            return base.BeginExecute(requestContext, callback, state);
        }

        protected override void EndExecute(IAsyncResult asyncResult)
        {
            this.ProcessSelectedMenuInfo();

            base.EndExecute(asyncResult);
        }

        /// <summary>
        /// 处理mobile请求，在Newegg SSL兼容mobile设备之前，如果是mobile请求，则强制转跳到旧站点，使用Flash SSL
        /// </summary>
        private void ProcessMobileRequest(System.Web.Mvc.ActionExecutingContext filterContext)
        {

            try
            {
                var manager = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
                var hosts = manager.GetConfiguration<HostsConfig>();

                //需要强制转跳到的URL
                var host_old = hosts.Hosts.Collection.FirstOrDefault(t => System.String.Compare(t.Name, "WWWFlashSite_Old_TMP", System.StringComparison.OrdinalIgnoreCase) == 0);
                var host_new = hosts.Hosts.Collection.FirstOrDefault(t => System.String.Compare(t.Name, "WWWFlashSite_New_TMP", System.StringComparison.OrdinalIgnoreCase) == 0);

                if (host_old == null || host_new == null)
                {
                    // 配置拿掉后，不在做强制转跳的逻辑
                    return;
                }

                var uriCurrent = new Uri(Utility.WebHostWithScheme());
                var uri_old = new Uri(host_old.Address);
                var uri_new = new Uri(host_new.Address);

                var pathAndQuery = filterContext.RequestContext.HttpContext.Request.Url.PathAndQuery;

                // mobile  &  not global request need redirect to www.neweggflash.com
                if (Utility.IsMobileDevice())
                {
                    // 当前为新站点 ，则进行转跳mobile请求到老站点
                    if (Uri.Compare(uriCurrent, uri_new, UriComponents.Host, UriFormat.Unescaped, StringComparison.OrdinalIgnoreCase) == 0
                        && "USA".Equals(BizThreadContext.RegionCode.Code))
                    {
                        var Url = new Uri(uri_old, pathAndQuery);
                        filterContext.Result = new RedirectResult(Url.AbsoluteUri, false);
                    }
                }
                else
                {
                    // 非mobile访问老站点，切换到新站点
                    if (Uri.Compare(uriCurrent, uri_old, UriComponents.Host, UriFormat.Unescaped, StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        var Url = new Uri(uri_new, pathAndQuery);
                        filterContext.Result = new RedirectResult(Url.AbsoluteUri, true);
                    }
                }
            }
            catch
            {

            }
        }

        protected override void OnActionExecuting(System.Web.Mvc.ActionExecutingContext filterContext)
        {
            if (bizUI == null)
            {
                bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
            }
            //if (bizUI.SwithToNewegg)
            //{
            // Global site Logic 
            var retrunUrl = ProcessGlobalSite();
            _globalPath = new ClientEvirment().GlobalPath;
            if (_IsRedirecting && !string.IsNullOrEmpty(retrunUrl))
            {
                filterContext.Result = new RedirectResult(retrunUrl, false);
                base.OnActionExecuting(filterContext);
                return;
            }
            //}
            if (bizUI != null)
            {
                var blogrolls = bizUI.Blogrolls;
                if (blogrolls != null)
                    ViewBag.Blogrolls = bizUI.Blogrolls;
            }
            ProcessMobileRequest(filterContext);

            BuildStringResources(filterContext);
            var redirectUrl = this.ProcessABTesting(filterContext);
            if (!string.IsNullOrEmpty(redirectUrl))
            {
                filterContext.Result = new RedirectResult(redirectUrl);
                return;
            }

            base.OnActionExecuting(filterContext);
        }

        /// <summary>
        /// Render tealium script in the page.
        /// </summary>
        /// <param name="filterContext">Action executed context.</param>
        protected override void OnActionExecuted(System.Web.Mvc.ActionExecutedContext filterContext)
        {
            if (ViewData["HiddenMenuAndBar"] != null && (bool)ViewData["HiddenMenuAndBar"] == true)
            {
                return;
            }

            if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerType == typeof(ExternalController) &&
                filterContext.ActionDescriptor.ActionName.ToLower() == "footer")
            {
                return;
            }

            if (!(filterContext.Result is RedirectResult))
            {
                this.ProcessTracingContext(filterContext);
                this.ProcessHeaderContent();
            }
            base.OnActionExecuted(filterContext);
        }

        #endregion

        #region protected method

        /// <summary>
        /// Gets current login user object.
        /// </summary>
        protected OtherInfoCookieModel CurrentLoginUser
        {
            get
            {
                return this.ViewBag.UserInfo;
            }
        }

        /// <summary>
        /// Get current store processor.
        /// </summary>
        protected IStore StoreProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<IStore>();
            }
        }

        /// <summary>
        /// Is under newegg affiliate sites.
        /// </summary>
        /// <param name="redirectUrl">Redirect url.</param>
        /// <returns>Return value.</returns>
        protected bool IsUnderNeweggAffiliateSites(string redirectUrl)
        {
            bool isUnderNewegg = false;
            try
            {
                IConfigurationManager manager = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
                Uri uri = new Uri(redirectUrl);
                var hosts = manager.GetConfiguration<HostsConfig>();
                if (hosts != null
                    && hosts.Hosts != null
                    && hosts.Hosts.Collection != null
                    && hosts.Hosts.Collection.Count > 0)
                {
                    foreach (var item in hosts.Hosts.Collection)
                    {
                        if (item.Address.ToUpper().Contains(uri.Authority.ToUpper()))
                        {
                            isUnderNewegg = true;
                            break;
                        }
                    }
                }
            }
            catch
            {
                isUnderNewegg = false;
            }

            return isUnderNewegg;
        }

        /// <summary>
        /// Render seo info in the page. like title, keywords, description.
        /// </summary>
        /// <param name="seoInfo"></param>
        protected void RenderSEOInfo(SEOPageInfo seoInfo)
        {
            if (seoInfo != null)
            {
                ViewBag.Title = seoInfo.PageTitle;
                ViewBag.Keywords = seoInfo.PageKeywords;
                ViewBag.Description = seoInfo.PageDescription;
            }
        }

        #endregion

        #region private method

        /// <summary>
        /// process ab tesing.
        /// </summary>
        /// <param name="filterContext"></param>
        /// <returns>new redirect url</returns>
        private string DecryptString(string inputString)
        {
            try
            {
                if (string.IsNullOrEmpty(inputString))
                {
                    return string.Empty;
                }
                var crypto = new CryptoManagerForCom().GetCrypto(CryptoAlgorithm.TripleDES);

                return crypto.Decrypt(inputString);
            }
            catch
            {
                return string.Empty;
            }
        }
        private string ProcessABTesting(System.Web.Mvc.ActionExecutingContext filterContext)
        {
            return ABTestingProcessor.Process(filterContext);
        }

        private void ProcessSEOInfo()
        {
            var seoInfo = ConfigurationWWWManager<SEOInfo>.ItemCfg();
            if (seoInfo != null && seoInfo.Home != null)
            {
                RenderSEOInfo(seoInfo.Home);
            }
        }

        private void ProcessSelectedMenuInfo()
        {
            string controllerName = this.ValueProvider.GetValue("controller").RawValue as string;
            string actionName = this.ValueProvider.GetValue("action").RawValue as string;
            this.ViewBag.SelectedMenu = string.Empty;
            if (!controllerName.IsNullOrEmpty() && !actionName.IsNullOrEmpty())
            {
                if (controllerName.Equals("Home", StringComparison.OrdinalIgnoreCase))
                {
                    if (actionName.Equals("Index", StringComparison.OrdinalIgnoreCase))
                    {
                        this.ViewBag.SelectedMenu = PageAliase.Homepage;
                    }
                }
                else if (controllerName.Equals("Store", StringComparison.OrdinalIgnoreCase))
                {
                    if (actionName.Equals("Index", StringComparison.OrdinalIgnoreCase))
                    {
                        this.ViewBag.SelectedMenu = PageAliase.Electronics;
                    }
                    else if (actionName.Equals("ForHome", StringComparison.OrdinalIgnoreCase))
                    {
                        this.ViewBag.SelectedMenu = PageAliase.ForHome;
                    }
                    else if (actionName.Equals("ForYou", StringComparison.OrdinalIgnoreCase))
                    {
                        this.ViewBag.SelectedMenu = PageAliase.ForYou;
                    }
                    else if (actionName.Equals("AllStore", StringComparison.OrdinalIgnoreCase))
                    {
                        this.ViewBag.SelectedMenu = PageAliase.AllStore;
                    }
                }
                else if (controllerName.Equals("Upcoming", StringComparison.OrdinalIgnoreCase))
                {
                    this.ViewBag.SelectedMenu = PageAliase.Upcoming;
                }
                else if (controllerName.Equals("Today", StringComparison.OrdinalIgnoreCase))
                {
                    this.ViewBag.SelectedMenu = PageAliase.EndingSoon;
                }
            }
        }

        private void ProcessTracingContext(System.Web.Mvc.ActionExecutedContext filterContext)
        {
            var trackingContext = new TrackingContext
            {
                ExecutedContext = filterContext,
                ViewData = this.ViewData,
                UserInfo = this.CurrentLoginUser,
                TempData = this.TempData,
                ViewBag = this.ViewBag
            };

            try
            {
                var trackingScrpit = TrackingInfoBuilder.Build(trackingContext);

                this.ViewData[TrackingInfoBuilder.TrakingKey] = trackingScrpit;

                ProcessCJFunction();
            }
            catch (Exception ex)
            {
                var log = ECLibraryContainer.Current.GetInstance<ILogger>();
                if (log != null)
                {
                    try
                    {
                        log.Exception = ex;
                        log.AddCategory("Newegg.Flash");
                        log.AddMessage("Third party integration");
                        log.Write();
                    }
                    catch { }
                }
            }
        }

        private void ProcessCJFunction()
        {
            var uriCurrent = new Uri(Utility.WebHostWithScheme());
            var uriNewHost = new Uri(Utility.WebHostWithScheme());
            var manager = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
            var hosts = manager.GetConfiguration<HostsConfig>();

            // 新域名下的URL
            var host_new = hosts.Hosts.Collection.FirstOrDefault(t => System.String.Compare(t.Name, "WWWFlashSite_New_TMP", System.StringComparison.OrdinalIgnoreCase) == 0);

            if (host_new != null && !string.IsNullOrEmpty(host_new.Address))
            {
                uriNewHost = new Uri(host_new.Address);
            }

            if (Uri.Compare(uriCurrent, uriNewHost, UriComponents.Host, UriFormat.Unescaped, StringComparison.OrdinalIgnoreCase) != 0)
            {
                return;
            }
            bool isCJ = false;
            bool isTrackingPixel = false;
            var nmmcValue = string.Empty;
            #region CJunction
            //step1) check querystring
            ThirdParty thirdPartyConfig = ConfigurationWWWManager<ThirdParty>.ItemCfg();
            CJunction cjFunction = thirdPartyConfig.CJunction;
            if (cjFunction != null && !string.IsNullOrEmpty(cjFunction.Code)
                && cjFunction.ParamNameConfig != null
                && cjFunction.ParamNameConfig.NameList != null
                && cjFunction.ParamNameConfig.NameList.Count > 0
                && cjFunction.Enalbe)
            {
                foreach (string name in cjFunction.ParamNameConfig.NameList)
                {
                    if (!string.IsNullOrEmpty(name))
                    {
                        if (Request.QueryString.AllKeys.Contains(name))
                        {
                            nmmcValue = Request.QueryString[name.Trim()];

                            if (string.Compare(Request.QueryString[name.Trim()], cjFunction.Code.Trim(), true) == 0)
                            {
                                isCJ = true;
                                isTrackingPixel = true;
                                break;
                            }
                        }
                    }
                }
            }

            var cookieOperator = new CookieRepository();
            var cookieConfig = ConfigurationWWWManager<NeweggComCookies>.ItemCfg();
            var cookieInfo = cookieConfig.NeweggComCookieConfig.Where(x => x.CookieId.Equals("ChannelIntelligence")).FirstOrDefault();

            //step2) set CJ cookie
            if (isCJ)
            {
                cookieOperator.ClearDomainCookie(cookieInfo.CookieName, cookieInfo.DomainName, cookieInfo.ExpiresAfter);

                cookieOperator.SetValue("ChannelIntelligence", "w22", cjFunction.Code.Trim());

                #region add additional infomation
                string pid = this.HttpContext.Request.QueryString["PID"];
                string aid = this.HttpContext.Request.QueryString["AID"];
                string sid = this.HttpContext.Request.QueryString["SID"];
                if (!string.IsNullOrEmpty(pid))
                {
                    cookieOperator.SetValue("ChannelIntelligence", "wv", pid);
                }
                if (!string.IsNullOrEmpty(aid))
                {
                    cookieOperator.SetValue("ChannelIntelligence", "ww", aid);
                }
                if (!string.IsNullOrEmpty(sid))
                {
                    cookieOperator.SetValue("ChannelIntelligence", "wx", sid);
                }
                #endregion

                string localPath = Utility.GetReferenceUrlLocalPath();
                if (!string.IsNullOrEmpty(localPath))
                {
                    cookieOperator.SetValue("ChannelIntelligence", "wu", Utility.GetReferenceUrl());
                }
            }

            if (!isTrackingPixel && !string.IsNullOrEmpty(nmmcValue))
            {
                cookieOperator.ClearDomainCookie(cookieInfo.CookieName, cookieInfo.DomainName, cookieInfo.ExpiresAfter);
            }
            #endregion
        }

        private void ProcessHeaderContent()
        {
            var headerContent = StoreProcessor.GetHeaderContent();
            this.ViewBag.StoreData = headerContent;
        }

        private string BuildCookieMappingConfig(NeweggComCookies configs)
        {
            if (configs == null)
            {
                return "";
            }
            int pos = 0;
            StringBuilder sb = new StringBuilder();
            sb.Append("CookieMapping:{");
            foreach (NeweggComCookie co in configs.NeweggComCookieConfig)
            {
                if (pos != 0)
                {
                    sb.Append(",");
                }
                sb.Append("'" + co.CookieName + "':");
                sb.Append("['" + co.DomainName + "'," + co.ExpiresAfter.TotalSeconds + ",'" + co.Path + "'," + co.SecureOnly.ToString().ToLower() + "]");
                pos++;
            }
            sb.Append("}");
            return sb.ToString();
        }

        public static string BuildSiteCookieConfig(NeweggComCookies configs)
        {
            if (configs == null)
            {
                return "";
            }
            var bizUnit = BizThreadContext.BizUnitInfo;
            StringBuilder sb = new StringBuilder();
            sb.Append("SiteCookieInfo:{");
            sb.Append("bizUnit:\"" + bizUnit.CountryCode + "\"");
            sb.Append(",enableReformattedCookie:" + configs.EnableReformattedCookie.ToString().ToLower());
            sb.Append(",writeReformattedCookie:" + configs.WriteReformattedCookie.ToString().ToLower());
            sb.Append("}");
            return sb.ToString();
        }

        public static string BuildEnvironmentConfig(NeweggComCookies configs)
        {
            if (configs == null)
            {
                return "";
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("Environment:{");
            sb.Append("Cookies:{");
            sb.Append("EnableCookieNameMapping:" + (configs.EnableCookieNameMapping ? "1" : "0"));
            sb.Append("}");
            sb.Append("}");
            return sb.ToString();
        }

        private string ProcessClientCookieConfig()
        {

            var cookieConfig = ConfigurationWWWManager<NeweggComCookies>.ItemCfg();

            StringBuilder sb = new StringBuilder();
            sb.Append("<script type=\"text/javascript\">");
            sb.Append("if(!window[\"Web\"]){Web={};};Web[\"Config\"]={");
            sb.Append(BuildEnvironmentConfig(cookieConfig));
            sb.Append(",");
            sb.Append(BuildCookieMappingConfig(cookieConfig));
            sb.Append(",");
            sb.Append(BuildSiteCookieConfig(cookieConfig)); 
            sb.Append("};");
            sb.Append("</script>");
            return sb.ToString();
        }

        private void BuildStringResources(System.Web.Mvc.ActionExecutingContext filterContext)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<script type=\"text/javascript\">");
            sb.Append("if(!window[\"StringResources\"]){StringResources={};};StringResources[\"Config\"]={");
            sb.Append("ClientResources:" + JsonConvert.SerializeObject(new ClientResources()));
            sb.Append(",ClientEvirment:" + JsonConvert.SerializeObject(new ClientEvirment()));
            sb.Append("};");
            sb.Append("</script>");
            sb.ToString();
            var scriptString = sb.ToString();
            MvcHtmlString scriptConfig = new MvcHtmlString(scriptString);
            ((System.Web.Mvc.ControllerContext)(filterContext)).Controller.ViewBag.ClientResources = scriptConfig;
        }

        /// <summary>
        /// Calculate current copyright.
        /// </summary>
        private void CalculateCopyright()
        {
            var currentYear = Common.CommonUtility.DateTimeNow.Year;
            var copyright = @"© 2013-{0} NEWEGGFLASH";
            copyright = string.Format(copyright, currentYear);

            ViewBag.Copyright = copyright;
        }

        #endregion
    }
}
