using System;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst
{
    /// <summary>
    /// The SiteCatalystManager.
    /// </summary>
    public partial class SiteCatalystManager : ITrackingBuilder
    {
        /// <summary>
        /// The common processor.
        /// </summary>
        private ISiteCatalystComponentProcessor commonProcessor = new CommonPageInfoProcessor();

        /// <summary>
        /// Gets the site catalyst config.
        /// </summary>
        public static SiteCatalystConfiguration SiteCatalystConfig
        {
            get { return ConfigurationWWWManager<ThirdParty>.ItemCfg().SiteCatalyst; }
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        public string Name
        {
            get { return "SiteCatalystBuilder"; }
        }

        /// <summary>
        /// The catalyst integration entry.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        /// <returns>The result script.</returns>
        public string Build(TrackingContext context)
        {
            if (SiteCatalystConfig.Enable == false)
            {
                return string.Empty;
            }

            if (!SiteCatalystConfig.IsConfigForAction(context.ActionKey))
            {
                return string.Empty;
            }

            SiteCatalystValueContainer.Init();

            this.commonProcessor.Process(context);
            this.ProcessIndividual(context);

            var result = SiteCatalystValueContainer.GenerateJsonString();

            SiteCatalystValueContainer.Reset();

            return SiteCatalystConfig.TagManager.TagDataCode.Replace("$scp$", result);
        }

        /// <summary>
        /// Process individual properties.
        /// </summary>
        /// <param name="context">Tracking context.</param>
        private void ProcessIndividual(TrackingContext context)
        {
            var processor = this.GetProcessor(context);
            if (processor != null)
            {
                processor.Process(context);
            }
        }

        /// <summary>
        /// Get private property processor.
        /// </summary>
        /// <param name="context">Tracking context.</param>
        /// <returns>Individual processor.</returns>
        private SiteCatalystProcessorBase GetProcessor(TrackingContext context)
        {
            if (context == null)
            {
                throw new ArgumentException("invalid param: context cannot be null");
            }

            SiteCatalystProcessorBase processor;
            processors.Value.TryGetValue(context.ActionKey, out processor);

            return processor;
        }
    }
}