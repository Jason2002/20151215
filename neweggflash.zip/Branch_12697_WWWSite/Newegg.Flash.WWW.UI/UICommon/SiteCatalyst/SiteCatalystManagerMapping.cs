using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.SiteCatalyst;
using Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst
{
    /// <summary>
    /// The SiteCatalystManager.
    /// </summary>
    public partial class SiteCatalystManager : ITrackingBuilder
    {
        /// <summary>
        /// Tealium private processors mapping. The key is controller name plus action name, seperated by dot mark.
        /// </summary>
        private static Lazy<Dictionary<string, SiteCatalystProcessorBase>> processors = new Lazy<Dictionary<string, SiteCatalystProcessorBase>>(InitProcessorMapping);

        /// <summary>
        /// Init processor mapping.
        /// </summary>
        /// <returns>Init Processor mapping.</returns>
        private static Dictionary<string, SiteCatalystProcessorBase> InitProcessorMapping()
        {
            return TrackingProcessorMappingHelper.InitProcessorMapping<SiteCatalystManager, SiteCatalystProcessorBase, SiteCatalystAttribute>();
        }
    }
}