namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst
{
    /// <summary>
    /// The site catalyst component processor.
    /// </summary>
    public interface ISiteCatalystComponentProcessor
    {
        /// <summary>
        /// Process the site catalyst.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        void Process(TrackingContext context);
    }
}