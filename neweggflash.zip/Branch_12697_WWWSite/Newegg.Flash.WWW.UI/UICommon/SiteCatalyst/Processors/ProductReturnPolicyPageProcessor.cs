using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    /// <summary>
    /// The ProductReturnPolicyPageProcessor
    /// </summary>
    public class ProductReturnPolicyPageProcessor : SiteCatalystProcessorBase
    {
        /// <summary>
        /// Process the site catalyst.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        public override void Process(TrackingContext context)
        {
            var model = context.ViewData.Model as ReturnPolicyPage;

            if (model != null)
            {
                DealWithItemNumber(model);
                DealWithPageHierarchy(model);
            }
        }

        /// <summary>
        /// Deal with the page hierarchy.
        /// </summary>
        /// <param name="model">The model.</param>
        private void DealWithPageHierarchy(ReturnPolicyPage model)
        {
            var itemName = model.Item.Description;

            JsonObj.pageName = JsonObj.pageName.Replace("{#ItemName}", itemName);
            JsonObj.prop2 = JsonObj.prop2.Replace("{#ItemName}", itemName);
            JsonObj.prop3 = JsonObj.pageName;
        }

        /// <summary>
        /// Deal with the item number.
        /// </summary>
        /// <param name="model">The model.</param>
        private void DealWithItemNumber(ReturnPolicyPage model)
        {
            JsonObj.products = model.Item.ItemNumber;
        }
    }
}