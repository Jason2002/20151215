﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    public class SearchPageProcessor : SiteCatalystProcessorBase
    {
        public override void Process(TrackingContext context)
        {
            var model = context.ViewData.Model as SearchPage;
            
            if (model != null &&!string.IsNullOrEmpty( model.Keyword))
            {
                this.JsonObj.eVar2 = model.Keyword;
                this.JsonObj.prop4 = model.Keyword;
                this.JsonObj.prop5 = "zero";
                if (model.TotalCount > 0)
                    this.JsonObj.prop5 = model.TotalCount;
                if (!string.IsNullOrEmpty(model.Within))
                {
                    this.JsonObj.eVar2 += " " + model.Within;
                    this.JsonObj.prop4 += " " + model.Within;
                }
            }
        }
    }
}