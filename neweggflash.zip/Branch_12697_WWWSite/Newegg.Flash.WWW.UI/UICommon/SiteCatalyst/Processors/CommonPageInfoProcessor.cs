using Newegg.Flash.WWW.Common.Configuration.SiteCatalyst;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    /// <summary>
    /// Common page info processor.
    /// </summary>
    public class CommonPageInfoProcessor : SiteCatalystProcessorBase
    {
        /// <summary>
        /// Process page properties.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        public override void Process(TrackingContext context)
        {
            var config = this.SiteCatalystConfig[context.ActionKey];
            if (config == null)
            {
                return;
            }
             
            this.DealWithPageHierachy(config);
            this.DealWithPageCategory(config);
            this.DeailWithServerName();
            this.DealWithPageType(config);
            if (!string.IsNullOrEmpty(JsonObj.pageName))
            {
                JsonObj.pageName = "nf " + JsonObj.pageName;
            }
            JsonObj.prop28 = "flash";
        }

        /// <summary>
        /// Deal with the page type, just for prop11 data.
        /// </summary>
        /// <param name="config">The mapping config.</param>
        private void DealWithPageType(Mapping config)
        {
            if (!string.IsNullOrEmpty(config.PageType))
            {
                JsonObj.prop11 = config.PageType;
            }
        }

        /// <summary>
        /// Deal with the page hierarchy.
        /// </summary>
        /// <param name="config">The mapping config.</param>
        private void DealWithPageHierachy(Mapping config)
        {
            if (string.IsNullOrEmpty(config.Hierarchy))
            {
                JsonObj.pageName = string.Empty;
                JsonObj.channel = string.Empty;
                JsonObj.prop2 = string.Empty;
                JsonObj.prop3 = string.Empty;
                return;
            }

            var hierachies = config.Hierarchy.Split(new[] { ':' });

            JsonObj.pageName = config.Hierarchy;
            JsonObj.channel = hierachies[0];
            
            if (hierachies.Length == 2)
            {
                JsonObj.prop2 = hierachies[0] + ":" + hierachies[1];
                JsonObj.prop3 = hierachies[0] + ":" + hierachies[1];
            }
            else if (hierachies.Length == 3)
            {
                JsonObj.prop2 = hierachies[0] + ":" + hierachies[1];
                JsonObj.prop3 = hierachies[0] + ":" + hierachies[1] + ":" + hierachies[2];
            }
            else
            {
                JsonObj.prop2 = hierachies[0];
                JsonObj.prop3 = hierachies[0];
            }
        }

        /// <summary>
        /// Deal with the page category info.
        /// </summary>
        /// <param name="config">Mapping config.</param>
        private void DealWithPageCategory(Mapping config)
        {
            if (string.IsNullOrEmpty(config.Category))
            {
                JsonObj.prop1 = string.Empty;
                JsonObj.prop23 = string.Empty;
                return;
            }

            var category = config.Category.Split(new[] { ':' });
            JsonObj.prop1 = category[0];
            if (category.Length == 2)
            {
                JsonObj.prop23 = category[1];
            }
            else {
                JsonObj.prop23 = string.Empty;
            }
        }

        /// <summary>
        /// Get the Servername.
        /// </summary>
        private void DeailWithServerName()
        {
            JsonObj.server = System.Environment.MachineName.Trim();
        }
    }
}