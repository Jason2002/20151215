using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    /// <summary>
    /// The CampaignPageProcessor.
    /// </summary>
    public class CampaignPageProcessor : SiteCatalystProcessorBase
    {
        /// <summary>
        /// The event.
        /// </summary>
        private static readonly string sc_event = "prodView";

        /// <summary>
        /// Process the site catalyst.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        public override void Process(TrackingContext context)
        {
            var model = context.ViewData.Model as CampaignPage;
            if (model != null && model.Campaign != null)
            {
                JsonObj.events = sc_event;

                DealWithItemNumber(model);
                DealWithPageHierarchy(model);
            }
        }

        /// <summary>
        /// Deal with the page hierarchy.
        /// </summary>
        /// <param name="model">The model.</param>
        private void DealWithPageHierarchy(CampaignPage model)
        {
            var campaignName = model.Campaign.CampaignName;

            var pageName = JsonObj.pageName as string;

            if (pageName == null)
            {
                return;
            }

            JsonObj.pageName = pageName.Replace("{#CampaignName}", campaignName);
            JsonObj.prop2 = JsonObj.pageName;
            JsonObj.prop3 = JsonObj.pageName;
        }

        /// <summary>
        /// Deal with the item number.
        /// </summary>
        /// <param name="model">The model.</param>
        private void DealWithItemNumber(CampaignPage model)
        {
            JsonObj.products = model.Campaign.CampaignId.ToString();

            var dic = (IDictionary<string, object>)this.JsonObj;
            if (dic.ContainsKey("prop11") && dic["prop11"] != null)
            {
                JsonObj.prop11 = JsonObj.prop11.Replace("{#CampaignID}", model.Campaign.CampaignId.ToString());
            }
        }
    }
}