using System.Text;
using Newegg.Flash.WWW.Model;
using System.Collections;
using System.Collections.Generic;
using Newegg.Flash.WWW.Common;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    /// <summary>
    /// The ProductPageProcessor.
    /// </summary>
    public class ProductPageProcessor : SiteCatalystProcessorBase
    {
        /// <summary>
        /// The event.
        /// </summary>
        private static readonly string sc_event = "prodView";

        /// <summary>
        /// Process the site catalyst.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        public override void Process(TrackingContext context)
        {
            JsonObj.events = sc_event;
             
            var model = context.ViewData.Model as ItemGroup;

            if (model != null && model.Items != null && model.Items.Count > 0)
            {
                DealWithItemNumber(model);
                DealWithPageHierarchy(model);
            }
        }

        /// <summary>
        /// Deal with the page hierarchy.
        /// </summary>
        /// <param name="model">The model.</param>
        private void DealWithPageHierarchy(ItemGroup model)
        {
            var itemName = model.Items[model.CurrentItemIndex].WebDescription;
            var campaignName = model.Items[model.CurrentItemIndex].CampaignName;
            string categoryName = string.Empty;
            if (model.Items[model.CurrentItemIndex].ExpireTicks > 0
                && model.Items[model.CurrentItemIndex].Navigation != null
                && model.Items[model.CurrentItemIndex].Navigation.CategoryName != null)
            {
                categoryName = model.Items[model.CurrentItemIndex].Navigation.CategoryName;
            }

            var hierarchyTemplate = JsonObj.pageName as string;

            if (hierarchyTemplate == null)
            {
                return;
            }

            if (model.Items[model.CurrentItemIndex].ExpireTicks > 0)
            {
                if (!string.IsNullOrEmpty(campaignName))
                {
                    JsonObj.prop2 = hierarchyTemplate.Replace("{#CampaignName}", campaignName)
                                     .Replace(":{#ItemName}", string.Empty);
                }
                else if (!string.IsNullOrEmpty(categoryName))
                {
                    JsonObj.prop2 = hierarchyTemplate.Replace("{#CampaignName}", categoryName)
                     .Replace(":{#ItemName}", string.Empty);
                }
                else
                {
                    hierarchyTemplate = hierarchyTemplate.Replace(":{#CampaignName}", string.Empty);
                    JsonObj.prop2 = hierarchyTemplate.Replace("{#ItemName}", itemName);
                }
            }
            else
            {
                hierarchyTemplate = hierarchyTemplate.Replace(":{#CampaignName}", string.Empty);
                JsonObj.prop2 = hierarchyTemplate.Replace("{#ItemName}", itemName);
            }
            if (model.Items[model.CurrentItemIndex].ExpireTicks <= 0)
            {
                JsonObj.pageName = hierarchyTemplate.Replace("{#CampaignName}", string.Empty).Replace("{#ItemName}", itemName);
            }
            else
            {
                JsonObj.pageName = hierarchyTemplate.Replace("{#CampaignName}", string.IsNullOrEmpty(campaignName) ? categoryName : campaignName).Replace("{#ItemName}", itemName);
            }
            JsonObj.prop3 = JsonObj.pageName;
        }

        /// <summary>
        /// Deal with the item number.
        /// </summary>
        /// <param name="model">The model.</param>
        private void DealWithItemNumber(ItemGroup model)
        {
            var sb = new StringBuilder();
            model.Items.ForEach(p => sb.Append(";").Append(p.ItemNumber).Append(","));

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 1, 1);
            }

            JsonObj.products = sb.ToString();

            var dic = (IDictionary<string, object>)this.JsonObj;
            if (dic.ContainsKey("prop11") && dic["prop11"] != null)
            {
                JsonObj.prop11 = JsonObj.prop11.Replace("{#ItemNumber}", model.Items[model.CurrentItemIndex].ItemNumber.ToString());
            }
        }
    }
}