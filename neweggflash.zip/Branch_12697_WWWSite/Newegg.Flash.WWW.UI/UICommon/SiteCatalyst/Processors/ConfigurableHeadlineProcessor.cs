﻿using System;
using Newegg.Flash.WWW.Model;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    public class ConfigurableHeadlineProcessor : SiteCatalystProcessorBase
    {
        public override void Process(TrackingContext context)
        {
            var pageName = JsonObj.pageName as string;
            if (pageName == null) return;
            pageName = pageName.Replace("{#Headline}", context.ViewBag.Headline);
            JsonObj.pageName = pageName;
            JsonObj.prop2 = pageName;
            JsonObj.prop3 = pageName;
        }
    }
}