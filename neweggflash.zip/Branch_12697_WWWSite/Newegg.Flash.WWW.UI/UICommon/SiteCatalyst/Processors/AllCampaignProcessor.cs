﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst.Processor
{
    public class AllCampaignProcessor : SiteCatalystProcessorBase
    {
        public override void Process(TrackingContext context)
        {
            var model = context.ViewData.Model as GeneralDeals;
            if (model != null)
            {

                DealWithPageHierarchy(model);
            }
        }

        private void DealWithPageHierarchy(GeneralDeals model)
        {
            var storeName = model.StoreName;

            var pageName = JsonObj.pageName as string;

            if (pageName == null)
            {
                return;
            }
            JsonObj.pageName = pageName.Replace("{#Electronics}", storeName);
            var array = JsonObj.pageName.Split(':');

            JsonObj.prop2 = array[0] + ":" + array[1];
            JsonObj.prop3 = JsonObj.pageName;
        }
    }
}