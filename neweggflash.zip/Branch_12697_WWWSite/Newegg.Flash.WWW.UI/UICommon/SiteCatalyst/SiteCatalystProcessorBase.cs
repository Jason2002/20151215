﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common.Configuration.SiteCatalyst;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst
{
    /// <summary>
    /// Site catalyst processir base.
    /// </summary>
    public abstract class SiteCatalystProcessorBase : ISiteCatalystComponentProcessor
    {
        /// <summary>
        /// Gets the site catalyst config.
        /// </summary>
        protected SiteCatalystConfiguration SiteCatalystConfig
        {
            get
            {
                return ConfigurationWWWManager<ThirdParty>.ItemCfg().SiteCatalyst;
            }
        }

        /// <summary>
        /// Gets the dynamic json object.
        /// </summary>
        protected dynamic JsonObj
        {
            get { return SiteCatalystValueContainer.Content; }
        }

        /// <summary>
        /// Process the site catalyst.
        /// </summary>
        /// <param name="context">The tracking context.</param>
        public abstract void Process(TrackingContext context);
    }
}