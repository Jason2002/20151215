﻿using Newegg.Flash.WWW.Common;
using System.Dynamic;
using System.Threading;
using System.Web.Script.Serialization;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst
{
    /// <summary>
    /// SiteCatalyst propery value container.
    /// </summary>
    public static class SiteCatalystValueContainer
    {
        /// <summary>
        /// Current private udo properties with values.
        /// </summary>
        private static ThreadLocal<dynamic> content = new ThreadLocal<dynamic>();

        /// <summary>
        /// Gets or sets the json property values.
        /// </summary>
        public static dynamic Content
        {
            get { return content.Value; }

            set { content.Value = value; }
        }

        /// <summary>
        /// Init the dynamic object.
        /// </summary>
        public static void Init()
        {
            content.Value = new ExpandoObject();
        }

        /// <summary>
        /// Clear the data.
        /// </summary>
        public static void Reset()
        {
            content.Value = null;
        }

        /// <summary>
        /// Generate the json string.
        /// </summary>
        /// <returns>The result.</returns>
        public static string GenerateJsonString()
        {
            if (content == null || content.Value == null)
            {
                return string.Empty;
            }

            var serializer = new JavaScriptSerializer();
            serializer.RegisterConverters(new JavaScriptConverter[] { new ExpandoJSONConverter() });

            return serializer.Serialize(content.Value);
        }
    }
}