﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.SiteCatalyst
{
    /// <summary>
    /// Site cataliyst customer attribute.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class SiteCatalystAttribute : TrackingMappingAtrribute
    {
        /// <summary>
        /// Initializes a new instance of the SiteCatalystAttribute class.
        /// </summary>
        /// <param name="processorType">Type of processor.</param>
        public SiteCatalystAttribute(Type processorType)
            : base(processorType)
        {
        }
    }
}