﻿using System;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Tealium customer attribute.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public abstract class TrackingMappingAtrribute : Attribute
    {
        /// <summary>
        /// Is TrackingMapping enabled.
        /// </summary>
        private bool enabled = true;

        /// <summary>
        /// Initializes a new instance of the TrackingMappingAtrribute class.
        /// </summary>
        /// <param name="processorType">Processor type.</param>
        public TrackingMappingAtrribute(Type processorType)
        {
            this.ProcessorType = processorType;
        }

        /// <summary>
        /// Gets or sets the processor type.
        /// </summary>
        public Type ProcessorType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether TrackingMapping is enabled.
        /// </summary>
        public bool Enable
        {
            get { return this.enabled; }

            set { this.enabled = value; }
        }

        /// <summary>
        /// Gets or sets the TrackingMapping mapping key. Default is controller name plus action name if the key is not set.
        /// </summary>
        public string Key { get; set; }
    }
}