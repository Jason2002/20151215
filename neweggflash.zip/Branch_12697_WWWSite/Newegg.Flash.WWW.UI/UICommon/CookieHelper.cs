﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Web;
using Newegg.EC;
using Newegg.EC.Cookie;
using Newegg.EC.Web.Cookie;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Common;
using Newtonsoft.Json;
using Newegg.EC.NeweggComCookie;
using System.Collections.Specialized;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// A helper class to quick access cookie.
    /// </summary>
    public static class CookieHelper
    {
        /// <summary>
        /// Gets the current request shopping cookie object.
        /// </summary>
        public static ShoppingInfo ShoppingCookie
        {
            get
            {
                return ShoppingInfo.Instance;
            }
        }

        /// <summary>
        /// Gets the current request other info cookie object.
        /// </summary>
        public static OtherInfo OtherInfoCookie
        {
            get
            {
                return OtherInfo.Instance;
            }
        }

        /// <summary>
        /// Gets the current request other info cookie object.
        /// </summary>
        public static ComInfo ComInfoCookie
        {
            get
            {
                return ComInfo.Instance;
            }
        }


        /// <summary>
        /// Gets the current request gated launch cookie object.
        /// </summary>
        public static GatedLaunch GatedLaunchCookie
        {
            get
            {
                return GatedLaunch.Instance;
            }
        }

        /// <summary>
        /// Gets the current request mini cart cookie object.
        /// </summary>
        public static MiniCarInfo MiniCarCookie
        {
            get
            {
                return MiniCarInfo.Instance;
            }
        }
        
        /// <summary>
        /// Gets the current request sweepstakes cookie object.
        /// </summary>
        public static SweepstakesCookieInfo SweepstakesCookie
        {
            get
            {
                return SweepstakesCookieInfo.Instance;
            }
        }

        /// <summary>
        /// To flush all the cookie to response.
        /// All cookie model object must flush to reponse one time.
        /// The method must be called in the FlashController.OnActionExecuted.
        /// </summary>
        public static void FlushToResponse()
        {
           var bizUI =  ConfigurationWWWManager<BizUI>.ItemCfg();
           if (bizUI != null && bizUI.SwithToNewegg)
           {
               var cookieOperator = new CookieRepository();

               SweepstakesCookie.SetCookieOptions();
               CookieManager.SetValue(SweepstakesIndicatorCookie.Key, SweepstakesCookie.Current);

               MiniCarCookie.SetCookieOptions();
               CookieManager.SetValue(MiniCarViewModel.Key, MiniCarCookie.Current);

               ComInfoCookie.SetCookieOptions();
               CookieManager.SetValue(ComInfoCookie.Key, ComInfoCookie.Current);

               GatedLaunchCookie.SetCookieOptions();
               CookieManager.SetValue(GatedLaunchCookieModel.Key , GatedLaunchCookie.Current);

               //get shopping cart info in request cookies
               var shoppingInfo = cookieOperator.GetValues("NewEggShoppingCart");
               
               //// delete all values
               ////cookieOperator.SetValues("NewEggShoppingCart", new NameValueCollection());
               ////cookieOperator.SetValue("NewEggShoppingCart", JsonConvert.SerializeObject(new { Values = new  NameValueCollection()}));
                
               //// add shopping info to response
               if (shoppingInfo != null && shoppingInfo.HasKeys())
               {
                   foreach (var item in shoppingInfo.AllKeys)
                   {
                       cookieOperator.SetValue("NewEggShoppingCart", item, shoppingInfo[item]);
                   }
               } 
           }
           else
           {
               ShoppingCookie.SetCookieOptions();
               OtherInfoCookie.SetCookieOptions();
               GatedLaunchCookie.SetCookieOptions();
               MiniCarCookie.SetCookieOptions();

               CookieManager.SetValue(MiniCarViewModel.Key, MiniCarCookie.Current);
               CookieManager.SetValue(ShoppingInfoCookieModel.Key, ShoppingCookie.Current);
               CookieManager.SetValue(OtherInfoCookieModel.Key, OtherInfoCookie.Current);
               CookieManager.SetValue(GatedLaunchCookieModel.Key, GatedLaunchCookie.Current);
           }
        }

        /// <summary>
        /// The flash cookie info base.
        /// </summary>
        /// <typeparam name="C">Cookie object type param.</typeparam>
        /// <typeparam name="T">Cookie info type param.</typeparam>
        public abstract class FlashCookieInfoBase<C, T>
            where T : FlashCookieInfoBase<C, T>, new()
            where C : FlashCookieBase, new()
        {
            /// <summary>
            /// Real cookie object.
            /// </summary>
            protected C cookieModel = default(C);

            /// <summary>
            /// Cookie info instance container.For Each thread the instance is singleton.
            /// </summary>
            private static ConcurrentDictionary<HttpRequest, T> cookieInstanceContainer = new ConcurrentDictionary<HttpRequest, T>();

            /// <summary>
            /// Initializes a new instance of the FlashCookieInfoBase class.
            /// </summary>
            protected FlashCookieInfoBase()
            {
                this.cookieModel = CookieManager.GetValue<C>(this.Key);
            }

            /// <summary>
            /// Gets instance for current cookie info.
            /// </summary>
            public static T Instance
            {
                get
                {
                    if (!cookieInstanceContainer.ContainsKey(HttpContext.Current.Request))
                    {
                        cookieInstanceContainer[HttpContext.Current.Request] = new T();
                    }

                    return cookieInstanceContainer[HttpContext.Current.Request];
                }
            }

            /// <summary>
            /// Gets the cookie key.
            /// </summary>
            public abstract string Key { get; }

            /// <summary>
            /// Gets cookie model.
            /// </summary>
            /// <returns>Cookie model.</returns>
            public C Current
            {
                get { return this.cookieModel; }
            }

            /// <summary>
            /// Set a new instance.
            /// </summary>
            /// <param name="cookieModel">Cookie model.</param>
            public virtual void SetCookieModel(C cookieModel)
            {
                this.cookieModel = cookieModel;
            }

            /// <summary>
            /// Clear cookie info.
            /// </summary>
            /// <returns>ShoppingInfo instance.</returns>
            public T Clear()
            {
                this.cookieModel = new C();
                return (T)this;
            }

            /// <summary>
            /// Save cookie options.
            /// </summary>
            /// <param name="cookieOptions">Cookie options.</param>
            /// <returns>ShoppingInfo instance.</returns>
            public T SetCookieOptions(string cookieOptions)
            {
                this.cookieModel.CookieOptions = cookieOptions;
                return (T)this;
            }

            /// <summary>
            /// Sets Cookie Options.
            /// </summary>
            public void SetCookieOptions()
            {
                // 1 Get cookie options.
                string strVal = string.Empty;
                var config = ECLibraryContainer.Current.GetInstance<ICookiesConfigRepository>().GetCookie(this.Key);
                DateTime expTime = Common.CommonUtility.DateTimeNow.Add(config.ExpiresAfter);

                // strVal = string.Format("{{'exp':'{0}','domin':'{1}','path':'{2}','secure':'{3}'}}", expTime, config.Domain, config.Path, config.SecureOnly);.
                var obj = new { exp = expTime, domain = config.Domain, path = config.Path, secure = config.SecureOnly };
                strVal = CookieSerializer.Serialize(obj);

                this.cookieModel.CookieOptions = strVal;
            }
        }

        /// <summary>
        /// MiniCarInfo helper class.
        /// </summary>
        public class MiniCarInfo : FlashCookieInfoBase<MiniCarViewModel, MiniCarInfo>
        {
            /// <summary>
            /// Get cookie key.
            /// </summary>
            public override string Key
            {
                get { return MiniCarViewModel.Key; }
            }
        }


        /// <summary>
        /// ShoppingInfo helper class.
        /// </summary>
        public class ShoppingInfo : FlashCookieInfoBase<ShoppingInfoCookieModel, ShoppingInfo>
        {
            /// <summary>
            /// Get cookie key.
            /// </summary>
            public override string Key
            {
                get { return ShoppingInfoCookieModel.Key; }
            }

            /// <summary>
            /// Do not allow to Set a new instance directly for ShoppingInfoCookieModel.
            /// </summary>
            /// <param name="cookieModel">Cookie model.</param>
            public override void SetCookieModel(ShoppingInfoCookieModel cookieModel)
            {
                this.cookieModel = cookieModel;
            }

            /// <summary>
            /// Save promotion code list.
            /// </summary>
            /// <param name="promotionCodeList">Promotion code list.</param>
            /// <returns>ShoppingInfo instance.</returns>
            public ShoppingInfo SetPromotionCodeList(List<string> promotionCodeList)
            {
                this.cookieModel.PromotionCodeList = promotionCodeList;
                return this;
            }

            /// <summary>
            /// Save gift card code list.
            /// </summary>
            /// <param name="giftCardList">gift card code list.</param>
            /// <returns>ShoppingInfo instance.</returns>
            public ShoppingInfo SetGiftCardList(List<string> giftCardList)
            {
                this.cookieModel.GiftCardList = giftCardList;
                return this;
            }
        }

        /// <summary>
        /// MiniCarInfo helper class.
        /// </summary>
        public class OtherInfo : FlashCookieInfoBase<OtherInfoCookieModel, OtherInfo>
        {
            /// <summary>
            /// Get cookie key.
            /// </summary>
            public override string Key
            {
                get { return OtherInfoCookieModel.Key; }
            }

            /// <summary>
            /// Save search sort by param.
            /// </summary>
            /// <param name="promotionCodeList">Sort by param.</param>
            /// <returns>OtherInfo instance.</returns>
            public OtherInfo SetSortBy(int sortBy)
            {
                this.cookieModel.Sortby = sortBy;
                return this;
            }

            /// <summary>
            /// Save gated launch by param
            /// </summary>
            /// <param name="gatedLaunch">Gated launch. e.g. 1397544715.1</param>
            /// <returns>OtherInfo instance.</returns>
            public OtherInfo SetGatedLaunch(string gatedLaunch)
            {
                this.cookieModel.GatedLaunch = gatedLaunch;
                GatedLaunchCookie.SetContent(this.GatedLaunchVersion);
                return this;
            }

            private string GatedLaunchVersion
            {
                get
                {
                    try
                    {
                        var result = string.Empty;
                        if (!string.IsNullOrEmpty(this.cookieModel.GatedLaunch))
                        {
                            var array = this.cookieModel.GatedLaunch.Split('.');
                            if (array.Length >= 2)
                            {
                                result = array[1];
                            }
                        }
                        return result;
                    }
                    catch
                    {
                        return string.Empty;
                    }
                }
            }
        }

        /// <summary>
        /// MiniCarInfo helper class.
        /// </summary>
        public class ComInfo : FlashCookieInfoBase<ComInfoCookieModel, ComInfo>
        {
            /// <summary>
            /// Get cookie key.
            /// </summary>
            public override string Key
            {
                get { return ComInfoCookieModel.Key; }
            } 
            public ComInfo SetSortBy(int sortBy)
            {
                this.cookieModel.Sortby = sortBy;
                return this;
            }

            public ComInfo SetSearchHistory(List<string> searchHistory)
            {
                this.cookieModel.SearchHistory = searchHistory;
                return this;
            }
            public ComInfo SetGatedLaunch(string gatedLaunch)
            {
                this.cookieModel.GatedLaunch = gatedLaunch;
                GatedLaunchCookie.SetContent(this.GatedLaunchVersion);
                return this;
            }

            public ComInfo SetLastRegion(string lastRegion)
            {
                this.cookieModel.LastRegion = lastRegion;
                return this;
            }
            public ComInfo SetLastCurrency(string LastCurrency)
            {
                this.cookieModel.LastCurrency = LastCurrency;
                return this;
            }

            private string GatedLaunchVersion
            {
                get
                {
                    try
                    {
                        var result = string.Empty;
                        if (!string.IsNullOrEmpty(this.cookieModel.GatedLaunch))
                        {
                            var array = this.cookieModel.GatedLaunch.Split('.');
                            if (array.Length >= 2)
                            {
                                result = array[1];
                            }
                        }
                        return result;
                    }
                    catch
                    {
                        return string.Empty;
                    }
                }
            }
        }


        /// <summary>
        /// Gated Launch helper class.
        /// </summary>
        public class GatedLaunch : FlashCookieInfoBase<GatedLaunchCookieModel, GatedLaunch>
        {
            /// <summary>
            /// Get cookie key.
            /// </summary>
            public override string Key
            {
                get { return GatedLaunchCookieModel.Key; }
            }

            /// <summary>
            /// Save gated launch by param
            /// </summary>
            /// <param name="gatedLaunch">Gated launch. e.g. 1 old version; 2 new version</param>
            /// <returns>OtherInfo instance.</returns>
            public GatedLaunch SetContent(string content)
            {
                this.cookieModel.Content = content;
                return this;
            }
        }

        public class SweepstakesCookieInfo : FlashCookieInfoBase<SweepstakesIndicatorCookie, SweepstakesCookieInfo>
        {
            /// <summary>
            /// Get cookie key.
            /// </summary>
            public override string Key
            {
                get { return SweepstakesIndicatorCookie.Key; }
            }
        }
    }
}