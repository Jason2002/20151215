﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// The TrackingProcessorMappingHelper.
    /// </summary>
    public static class TrackingProcessorMappingHelper
    {
        /// <summary>
        /// Summary: 统一处理映射器的初始化工作.
        /// </summary>
        /// <typeparam name="M">Param: 第三方集成处理管理类类型.</typeparam>
        /// <typeparam name="B">Param: 处理器基类类型.</typeparam>
        /// <typeparam name="A">Param: 映射器Attribute类型，不能是基类.</typeparam>
        /// <returns>The result.</returns>
        public static Dictionary<string, B> InitProcessorMapping<M, B, A>()
            where A : TrackingMappingAtrribute
            where B : class
        {
            var processors = new Dictionary<string, B>();

            var controllerTypes = from type in typeof(M).Assembly.GetTypes()
                                  where type.Name.EndsWith("Controller")
                                  select type;

            foreach (var type in controllerTypes)
            {
                var methods = type.GetMethods();
                foreach (var method in methods)
                {
                    var siteCatalystAttr = method.GetCustomAttribute<A>();

                    if (siteCatalystAttr != null && siteCatalystAttr.ProcessorType != null
                        && siteCatalystAttr.ProcessorType.IsSubclassOf(typeof(B))
                        && siteCatalystAttr.Enable != false)
                    {
                        var key = !string.IsNullOrWhiteSpace(siteCatalystAttr.Key) ? siteCatalystAttr.Key
                            : GetControllerName(type) + "." + GetActionName(method);

                        if (processors.ContainsKey(key))
                        {
                            continue;
                        }

                        var instance = Activator.CreateInstance(siteCatalystAttr.ProcessorType) as B;

                        if (instance != null)
                        {
                            processors.Add(key, instance);
                        }
                    }
                }
            }

            return processors;
        }

        /// <summary>
        /// Gets controller name.
        /// </summary>
        /// <param name="type">Controller type info.</param>
        /// <returns>Controller name.</returns>
        private static string GetControllerName(Type type)
        {
            return type.Name.Replace("Controller", string.Empty).ToLower();
        }

        /// <summary>
        /// Gets action name.
        /// </summary>
        /// <param name="method">Method info.</param>
        /// <returns>Action name.</returns>
        private static string GetActionName(MethodInfo method)
        {
            var actionNameAttr = method.GetCustomAttribute<ActionNameAttribute>();

            return actionNameAttr == null ? method.Name.ToLower() : actionNameAttr.Name.ToLower();
        }
    }
}