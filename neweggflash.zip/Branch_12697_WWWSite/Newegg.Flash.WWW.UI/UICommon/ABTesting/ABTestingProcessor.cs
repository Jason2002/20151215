﻿using Newegg.EC;
using Newegg.EC.Log;
using Common = Newegg.Flash.WWW.Common;
using Configuration = Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;

namespace Newegg.Flash.WWW.UI.UICommon.ABTesting
{
    /// <summary>
    /// AB Testing processor.
    /// </summary>
    /// <summary>
    /// ABTesting Processor class.
    /// </summary>
    public static class ABTestingProcessor
    {
        /// <summary>
        /// Max value.
        /// </summary>
        private const int MaxValue = 100;

        /// <summary>
        /// ABTesting mark.
        /// </summary>
        private const string ABTestingMark = "markgl";

        /// <summary>
        /// Process ABtesting.
        /// </summary>
        /// <param name="filterContext">Filter context.</param>
        /// <returns>Redirect url.</returns>
        public static string Process(ActionExecutingContext filterContext)
        {
            try
            {
                var abtestingContext = ProcessABTestingLogic(filterContext);
                  var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
                  if (bizUI != null && bizUI.SwithToNewegg)
                  {
                      if (abtestingContext != null
                         && abtestingContext.UpdateCookie)
                      {
                          CookieHelper.ComInfoCookie.SetGatedLaunch(abtestingContext.ToString());
                      }
                      else
                      {
                          CookieHelper.ComInfoCookie.SetGatedLaunch(CookieHelper.ComInfoCookie.Current.GatedLaunch);
                      }
                  }
                  else
                  {
                      if (abtestingContext != null
                          && abtestingContext.UpdateCookie)
                      { 
                          CookieHelper.OtherInfoCookie.SetGatedLaunch(abtestingContext.ToString()); 
                      }
                      else
                      {
                          // if no need to redirect, refresh gatedlaunch data to make sure NV_GL is synchronized.
                          CookieHelper.OtherInfoCookie.SetGatedLaunch(CookieHelper.OtherInfoCookie.Current.GatedLaunch);
                      }
                  }

                if (abtestingContext != null
                    && abtestingContext.NeedRedirect)
                {
                    var url = AppendQueryStringToTheEnd(abtestingContext, filterContext);
                    return url;
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                var log = ECLibraryContainer.Current.GetInstance<ILogger>();
                if (log != null)
                {
                    try
                    {
                        log.Exception = ex;
                        log.AddCategory("Newegg.Flash");
                        log.AddMessage("Process AB Testing failed.");
                        log.Write();
                    }
                    catch
                    {
                    }
                }
                  var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
                  if (bizUI != null && bizUI.SwithToNewegg)
                  {
                      CookieHelper.ComInfoCookie.SetGatedLaunch(string.Empty);
                  }
                  else
                  {
                      CookieHelper.OtherInfoCookie.SetGatedLaunch(string.Empty);
                  }
                return string.Empty;
            }
        }

        /// <summary>
        /// Validated Disabled Cookie.
        /// </summary>
        /// <param name="filterContext">Filter Context.</param>
        /// <param name="gatedLaunch">Gated Launch.</param>
        /// <returns>Ture or False.</returns>
        private static bool ValidateDisabledCookie(System.Web.Mvc.ActionExecutingContext filterContext, string gatedLaunch)
        {
            if (string.IsNullOrWhiteSpace(gatedLaunch))
            {
                var queryString = filterContext.HttpContext.Request.QueryString;
                if (queryString.AllKeys.Contains(ABTestingMark))
                {
                    return false;
                }

                return true;
            }

            return true;
        }

        /// <summary>
        /// Load gated launch cookie.
        /// </summary>
        /// <param name="gatedLaunch">Gated launch.</param>
        /// <returns>ABTestingContext object.</returns>
        private static ABTestingContext LoadGatedLaunchCookie(string gatedLaunch)
        {
            ABTestingContext abtestingContext = null;
            try
            {
                if (string.IsNullOrWhiteSpace(gatedLaunch))
                {
                    return null;
                }

                abtestingContext = ABTestingContext.Bulid(gatedLaunch);
            }
            catch
            {
                abtestingContext = null;
            }

            return abtestingContext;
        }

        /// <summary>
        /// Process ABTesting Core.
        /// </summary>
        /// <param name="filterContext">Filter context.</param>
        /// <returns>ABTestingContext object.</returns>
        private static ABTestingContext ProcessABTestingLogic(ActionExecutingContext filterContext)
        {
            var currentGatedLaunch = string.Empty;
            var newGatedLaunch = string.Empty; 
                var bizUI = ConfigurationWWWManager<BizUI>.ItemCfg();
                if (bizUI != null && bizUI.SwithToNewegg)
                {
                    currentGatedLaunch = CookieHelper.ComInfoCookie.Current.GatedLaunch;
                }
                else
                {
                    currentGatedLaunch = CookieHelper.OtherInfoCookie.Current.GatedLaunch; 
                }
            //// 实例化cookie中GL数据对象。
            ABTestingContext abtestingContext = LoadGatedLaunchCookie(currentGatedLaunch);
            var abtestingConfig = Common.ConfigurationWWWManager<Configuration.ABTesting>.ItemCfg();
            if (abtestingConfig.Enable)
                {
                // 判断用户是否禁用了Cookie。
                    if (!ValidateDisabledCookie(filterContext, currentGatedLaunch))
                    {
                    // 如果禁用cookie，直接放过。
                    abtestingContext = ABTestingContext.Bulid(Common.CommonUtility.DateTimeNow, -1, false);
                    abtestingContext.NeedRedirect = false;
                    abtestingContext.IsShowMarkGL = false;
                    return abtestingContext;
                    }

                    var ip = Utility.ReferenceIP();
                //// 判断白名单。
                //// 如果在白名单中。
                if (abtestingConfig.WhiteList != null
                   && abtestingConfig.WhiteList.Content != null
                   && abtestingConfig.WhiteList.Content.Count > 0
                   && abtestingConfig.WhiteList.Content.Contains(ip))
                {
                    ProcessWhiteListLogic(ref abtestingContext, abtestingConfig);
                }
                else
                {
                    ProcessNormalLogic(ref abtestingContext, abtestingConfig);
                }

                ProcessForcedRefreshLogic(ref abtestingContext, abtestingConfig);
            }
            else
            {
                ProcessDisabledLogic(ref abtestingContext);
            }

            return abtestingContext;
        }

        /// <summary>
        /// Process whitelist logic.
        /// </summary>
        /// <param name="abtestingContext">ABTesting Context.</param>
        /// <param name="abtestingConfig">ABTesting config.</param>
        private static void ProcessWhiteListLogic(ref ABTestingContext abtestingContext, Configuration.ABTesting abtestingConfig)
                    {
            // 如果cookie中gl值有效
            if (abtestingContext != null)
                        {
                if (abtestingContext.Version == abtestingConfig.WhiteList.VersionNumber)
                            {
                    // pass.
                    abtestingContext.NeedRedirect = false;
                    abtestingContext.UpdateCookie = false;
                    abtestingContext.IsShowMarkGL = false;
                            }
                            else
                            {
                    abtestingContext.InDate = Common.CommonUtility.DateTimeNow;
                    abtestingContext.Version = abtestingConfig.WhiteList.VersionNumber;
                    abtestingContext.NeedRedirect = true;
                    abtestingContext.UpdateCookie = true;
                    abtestingContext.IsShowMarkGL = true;
                            }
                        }
                        else
                        {
                // 如果gl中无值，则新建对象，赋值
                abtestingContext = ABTestingContext.Bulid(Common.CommonUtility.DateTimeNow, abtestingConfig.WhiteList.VersionNumber, false);
                abtestingContext.NeedRedirect = true;
                abtestingContext.UpdateCookie = true;
                abtestingContext.IsShowMarkGL = true;
                        }

            // 在白名单中
            abtestingContext.ContainsWhiteList = true;
                    }

        /// <summary>
        /// Process whitelist logic.
        /// </summary>
        /// <param name="abtestingContext">ABTesting Context.</param>
        /// <param name="abtestingConfig">ABTesting config.</param>
        private static void ProcessNormalLogic(ref ABTestingContext abtestingContext, Configuration.ABTesting abtestingConfig)
                    {
            if (abtestingContext != null)
                        {
                if (abtestingConfig.Versions != null
                    && abtestingConfig.Versions != null
                    && abtestingConfig.Versions.Count > 0)
                            {
                    var currentVersion = abtestingContext.Version;
                    var versionObj = abtestingConfig.Versions.FirstOrDefault(i => i.VersionNumber == currentVersion);
                                if (versionObj != null)
                                {
                        if (versionObj.ExpireTime > abtestingContext.InDate)
                                    {
                            // pass.
                            abtestingContext.NeedRedirect = false;
                            abtestingContext.UpdateCookie = false;
                            abtestingContext.IsShowMarkGL = false;
                                    }
                                    else
                                    {
                            // 如果已经到期了，那么重新计算当前版本
                            abtestingContext.InDate = Common.CommonUtility.DateTimeNow;
                            abtestingContext.Version = CalculateVerion(abtestingConfig);
                            abtestingContext.AlreadyForceRefresh = true;
                            abtestingContext.NeedRedirect = true;
                            abtestingContext.UpdateCookie = true;
                            abtestingContext.IsShowMarkGL = true;
                        }
                    }
                    else
                    {
                        // cookie中解析出来的version，在配置文件中没有找到，此时默认写入version=1
                        abtestingContext.InDate = Common.CommonUtility.DateTimeNow;
                        abtestingContext.Version = 1;
                        abtestingContext.AlreadyForceRefresh = true;
                        abtestingContext.NeedRedirect = true;
                        abtestingContext.UpdateCookie = true;
                        abtestingContext.IsShowMarkGL = true;
                                    }
                                }
                                else
                                {
                    // 如果配置文件中没有值，此时默认写入version=1
                    abtestingContext.InDate = Common.CommonUtility.DateTimeNow;
                    abtestingContext.Version = 1;
                    abtestingContext.AlreadyForceRefresh = true;
                    abtestingContext.NeedRedirect = true;
                    abtestingContext.UpdateCookie = true;
                    abtestingContext.IsShowMarkGL = true;
                                }
                            }
                            else
                            {
                // 此前什么cookie都没有，需要重新计算
                // 计算新的版本
                var versionNumber = CalculateVerion(abtestingConfig);
                abtestingContext = ABTestingContext.Bulid(Common.CommonUtility.DateTimeNow, versionNumber, true);
                abtestingContext.NeedRedirect = true;
                abtestingContext.UpdateCookie = true;
                abtestingContext.IsShowMarkGL = true;
            }
        }

        /// <summary>
        /// Process forced refresh logic.
        /// </summary>
        /// <param name="abtestingContext">ABTesting Context.</param>
        /// <param name="abtestingConfig">ABTesting config.</param>
        private static void ProcessForcedRefreshLogic(ref ABTestingContext abtestingContext, Configuration.ABTesting abtestingConfig)
        {
            if (abtestingContext != null)
            {
                if (abtestingConfig.Versions != null
                   && abtestingConfig.Versions != null
                   && abtestingConfig.Versions.Count > 0)
                {
                    var currentVersion = abtestingContext.Version;
                    var versionObj = abtestingConfig.Versions.FirstOrDefault(i => i.VersionNumber == currentVersion);
                    if (versionObj != null)
                    {
                        if (!abtestingContext.AlreadyForceRefresh
                            && versionObj.ForcedRefresh)
                        {
                            var versionNumber = CalculateVerion(abtestingConfig);
                            abtestingContext.InDate = Common.CommonUtility.DateTimeNow;
                            abtestingContext.Version = versionNumber;
                            abtestingContext.AlreadyForceRefresh = true;
                            abtestingContext.NeedRedirect = true;
                            abtestingContext.UpdateCookie = true;
                            abtestingContext.IsShowMarkGL = true;
                        }
                        else if (abtestingContext.AlreadyForceRefresh
                                && !versionObj.ForcedRefresh)
                        {
                            abtestingContext.AlreadyForceRefresh = false;
                            abtestingContext.NeedRedirect = false || abtestingContext.NeedRedirect;
                            abtestingContext.UpdateCookie = true;
                            abtestingContext.IsShowMarkGL = false || abtestingContext.IsShowMarkGL;
                        }
                    }
                }
            }
                            }

        /// <summary>
        /// Process disabled refresh logic.
        /// </summary>
        /// <param name="abtestingContext">ABTesting Context.</param>
        private static void ProcessDisabledLogic(ref ABTestingContext abtestingContext)
        {
            if (abtestingContext != null)
            {
                // 未开启abtest，直接清空abtesting cookie,然后重定向
                abtestingContext.Version = -1;
                abtestingContext.NeedRedirect = true;
                abtestingContext.UpdateCookie = true;
                abtestingContext.IsShowMarkGL = false;
                        }
                        else
                        {
                abtestingContext = ABTestingContext.Bulid(Common.CommonUtility.DateTimeNow, -1, false);
                abtestingContext.NeedRedirect = false;
                abtestingContext.UpdateCookie = false;
                abtestingContext.IsShowMarkGL = false;
            }
        }

        /// <summary>
        /// Calculate version number.
        /// </summary>
        /// <param name="abtestingConfig">ABTesting config.</param>
        /// <returns>The new version number.</returns>
        private static int CalculateVerion(Configuration.ABTesting abtestingConfig)
        {
                            var newVersion = 1;
            if (abtestingConfig.Versions != null
                && abtestingConfig.Versions.Count > 0)
            {
                var retry = false;

                // 如果命中的版本是过期的话，重新计算，最多试10次，10次后仍然命中过期版本，那么直接将版本号设置为1
                var tryTimes = 0;
                var maxTryTimes = 10;
                do
                            {
                    // 为用户生成新的版本号和时间戳
                    // 选择范围是1~100，但是随机数生成范围是0~99,所以最后+1
                    var hashValue = Utility.RandomNumber(MaxValue) + 1;

                    // 按照版本号排序，越小的版本号，越先参与计算
                    var versionList = abtestingConfig.Versions.OrderBy(i => i.VersionNumber).ToList();
                                for (int i = 0; i < versionList.Count; i++)
                                {
                                    int rate = 0;
                                    for (int j = 0; j <= i; j++)
                                    {
                                        rate += +versionList[j].Rate;
                                        rate = rate > 100 ? 100 : rate;
                                    }

                                    if (i == 0)
                                    {
                                        if (hashValue > 0
                                            && hashValue <= rate)
                                        {
                                if (versionList[i].ExpireTime > Common.CommonUtility.DateTimeNow)
                                {
                                    // 命中
                                            newVersion = versionList[i].VersionNumber;
                                    retry = false;
                                }
                                else
                                {
                                    retry = true;
                                }

                                            break;
                                        }
                                    }
                                    else
                                    {
                                        if (hashValue > versionList[i - 1].Rate
                                           && hashValue <= rate)
                                        {
                                if (versionList[i].ExpireTime > Common.CommonUtility.DateTimeNow)
                                {
                                    // 命中
                                            newVersion = versionList[i].VersionNumber;
                                    retry = false;
                            }
                            else
                            {
                                    retry = true;
                            }

                                break;
                        }
                    }
                }

                    if (retry && ++tryTimes >= maxTryTimes)
                    {
                        newVersion = 1;
                        retry = false;
                    }
                }
                while (retry);
                    }
                    else
                    {
                // 配置文件中，没有配置版本号，此时默认写入version=1
                newVersion = 1;
                    }

            return newVersion;
                }

        /// <summary>
        /// Append 'markgl' to redirect url.
        /// </summary>
        /// <param name="abtestingContext">ABTesting Context.</param>
        /// <param name="filterContext">Filter Context.</param>
        /// <returns>Complate url address.</returns>
        private static string AppendQueryStringToTheEnd(ABTestingContext abtestingContext, ActionExecutingContext filterContext)
                {
            //var url = filterContext.HttpContext.Request.Url.AbsolutePath;
            var url = filterContext.HttpContext.Request.RawUrl;
                    var queryString = filterContext.HttpContext.Request.QueryString;
            if ((!queryString.AllKeys.Contains(ABTestingMark)
                        || queryString[ABTestingMark] != "1")
                && abtestingContext.IsShowMarkGL)
                    {
                        if (url.IndexOf("?") >= 0)
                        {
                            url = url + string.Format("&{0}=1", ABTestingMark);
                        }
                        else
                        {
                            url = url + string.Format("?{0}=1", ABTestingMark);
                        }
                }

            return url;
        }
    }
}