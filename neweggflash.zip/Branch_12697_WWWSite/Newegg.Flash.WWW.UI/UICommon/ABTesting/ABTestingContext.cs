﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.ABTesting
{
    /// <summary>
    /// ABTesting Context class.
    /// </summary>
    public class ABTestingContext
    {
        /// <summary>
        /// Prevents a default instance of the ABTestingContext class from being created.
        /// </summary>
        private ABTestingContext()
        {
        }

        #region entity

        /// <summary>
        /// Gets or sets InDate.
        /// </summary>
        public DateTime InDate { get; set; }

        /// <summary>
        /// Gets or sets Version.
        /// </summary>
        public int Version { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether AlreadyForceRefresh is true.
        /// </summary>
        public bool AlreadyForceRefresh { get; set; }

        #endregion

        /// <summary>
        /// Gets or sets a value indicating whether NeedRedirect is true.
        /// </summary>
        public bool NeedRedirect { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether UpdateCookie is true.
        /// </summary>
        public bool UpdateCookie { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsShowMarkGL is true.
        /// </summary>
        public bool IsShowMarkGL { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether ContainsWhiteList is true.
        /// </summary>
        public bool ContainsWhiteList { get; set; }

        /// <summary>
        /// Bulid ABTestingContext object.
        /// </summary>
        /// <param name="cookieValue">Cookie Value.</param>
        /// <returns>ABTestingContext object.</returns>
        public static ABTestingContext Bulid(string cookieValue)
        {
            ABTestingContext obj = null;
            var array = cookieValue.Split('.');
            switch (array.Length)
            {
                case 2:
                    obj = new ABTestingContext();
                    obj.InDate = Utility.ConvertTimestampToDateTime(array[0]);
                    obj.Version = Convert.ToInt32(array[1]);
                    obj.AlreadyForceRefresh = false;
                    break;
                case 3:
                    obj = new ABTestingContext();
                    obj.InDate = Utility.ConvertTimestampToDateTime(array[0]);
                    obj.Version = Convert.ToInt32(array[1]);
                    obj.AlreadyForceRefresh = array[2] == "1" ? true : false;
                    break;
                default:
                    obj = null;
                    break;
            }

            return obj;
        }

        /// <summary>
        /// Bulid ABTestingContext object.
        /// </summary>
        /// <param name="inDate">InDate param.</param>
        /// <param name="version">Version param.</param>
        /// <param name="alreadyForceRefresh">AlreadyForceRefresh param.</param>
        /// <returns>ABTestingContext object.</returns>
        public static ABTestingContext Bulid(DateTime inDate, int version, bool alreadyForceRefresh)
        {
            ABTestingContext obj = new ABTestingContext();
            obj.InDate = inDate;
            obj.Version = version;
            obj.AlreadyForceRefresh = alreadyForceRefresh;
            return obj;
        }

        /// <summary>
        /// Override ToString Method.
        /// </summary>
        /// <returns>Cookie value.</returns>
        public override string ToString()
        {
            if (this.Version == -1)
            {
                return string.Empty;
            }

            return string.Format("{0}.{1}.{2}", Utility.ConvertDateTimeToTimestamp(this.InDate), this.Version, this.AlreadyForceRefresh ? "1" : "0");
        }
    }
}