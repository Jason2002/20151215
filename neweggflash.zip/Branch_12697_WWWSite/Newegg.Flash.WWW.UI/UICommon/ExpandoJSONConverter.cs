﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web.Script.Serialization;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// The ExpandoJSONConverter.
    /// </summary>
    public class ExpandoJSONConverter : JavaScriptConverter
    {
        /// <summary>
        /// Get the supported types.
        /// </summary>
        public override IEnumerable<Type> SupportedTypes
        {
            get
            {
                return new ReadOnlyCollection<Type>(new Type[] { typeof(System.Dynamic.ExpandoObject) });
            }
        }

        /// <summary>
        /// The Deserialize.
        /// </summary>
        /// <param name="dictionary">The data.</param>
        /// <param name="type">The type.</param>
        /// <param name="serializer">The serializer.</param>
        /// <returns>The returns.</returns>
        public override object Deserialize(IDictionary<string, object> dictionary, Type type, JavaScriptSerializer serializer)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// The Serialize.
        /// </summary>
        /// <param name="obj">The obj.</param>
        /// <param name="serializer">The serializer.</param>
        /// <returns>The result.</returns>
        public override IDictionary<string, object> Serialize(object obj, JavaScriptSerializer serializer)
        {
            var result = new Dictionary<string, object>();
            var dictionary = obj as IDictionary<string, object>;
            foreach (var item in dictionary)
            {
                result.Add(item.Key, item.Value);
            }

            return result;
        }
    }
}
