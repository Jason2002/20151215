﻿using System.Text.RegularExpressions;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UISocialShareInfoBase
    {

        private static ThreadLocal<SweepstakesConfigItem> ms_CurrentConfig = new ThreadLocal<SweepstakesConfigItem>();
        private static ThreadLocal<SocialShareConfig> ms_SocialShareConfig = new ThreadLocal<SocialShareConfig>();

        protected SocialShareConfig SocialShareConfig
        {
            get
            {
                if (ms_SocialShareConfig.Value == null)
                {
                    ms_SocialShareConfig.Value = ConfigurationWWWManager<BizUI>.ItemCfg().SocialShareConfig;
                }

                return ms_SocialShareConfig.Value;
            }
        }

        public UISocialShareInfoBase()
        {
            var config = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (config != null && config.SwithToNewegg)
            {
                this.RedirectUri = "http://flash.newegg.com";
                this.Caption = "flash.newegg.com";
            }
            else
            {
                this.RedirectUri = "http://www.neweggflash.com";  // TODO
                this.Caption = "www.neweggflash.com"; // TODO
            }
        }

        public string Title { get; set; }

        public string PromotionUrl { get; set; }

        public string ImageUrl { get; set; }

        public string ShareDesciption { get; set; }

        public string Link { get; set; }

        public string RedirectUri { get; protected set; }

        public string Caption { get; protected set; }

        protected string UrlEncode(string source)
        {
            if (string.IsNullOrEmpty(source))
            {
                return string.Empty;
            }

            return HttpUtility.UrlEncode(source);
        }

        public String BuildUrl(String format)
        {
            //http://connect.qq.com/widget/shareqq/index.html?url={url}&desc={desc}&title={title}pics={pic}
            String input = Regex.Replace(format, "{url}", UrlEncode(Link));
            input = Regex.Replace(input, "{desc}", UrlEncode(ShareDesciption));
            input = Regex.Replace(input, "{title}", UrlEncode(Title));
            input = Regex.Replace(input, "{pic}", UrlEncode(ImageUrl));
            input = Regex.Replace(input, "{site}", UrlEncode(RedirectUri));
            input = Regex.Replace(input, "{cap}", UrlEncode(Caption));

            return input;
        }
    }
}