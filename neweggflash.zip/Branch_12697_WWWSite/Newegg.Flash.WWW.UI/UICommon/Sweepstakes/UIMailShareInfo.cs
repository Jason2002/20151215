﻿using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Globalization;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UIMailShareInfo : UISocialShareInfoBase
    {
        [Required(ErrorMessageResourceType = typeof(Global),
                 ErrorMessageResourceName = "Validation_Required")]
        [EmailAddress(ErrorMessageResourceType = typeof(Global),
                      ErrorMessageResourceName = "Validation_EmailFormat",
                      ErrorMessage = null)]
        public string CustomerEmailAddress { get; set; }

        [Required(ErrorMessageResourceType = typeof(Global), 
                  ErrorMessageResourceName = "Validation_Required")]
        [RegularExpression(@"^((\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*);?)+$",
                           ErrorMessageResourceName = "Validation_EmailFormat",
                           ErrorMessage = null,
                           ErrorMessageResourceType = typeof(Global))]
        public string ReceiveEmailAddress { get; set; }

        public string ContentDefault { get; private set; }
    }
}