﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using Newegg.Flash.WWW.Model;
using Newegg.Flash.WWW.Interface;
using Newegg.EC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UISweepstakesSocialShareInfo
    {
        private SweepstakesConfigItem Config { set; get; }

        protected ISweepstake SweepstakeProcessor
        {
            get
            {
                return ECLibraryContainer.Current.GetInstance<ISweepstake>();
            }
        }

        public UISweepstakesSocialShareInfo()
        {
            //passing value from new Model Model.Sweepstake to the old Model SweepstakeConfigItem
            Sweepstake curSweepstake = SweepstakeProcessor.Get(BizThreadContext.RegionCode.Code);
            if (null != curSweepstake && !string.IsNullOrEmpty(curSweepstake.Description))
            {
                this.Config = new SweepstakesConfigItem();
                this.Config.Description = curSweepstake.Description;
                this.Config.InnerDescription = curSweepstake.Description;
                this.Config.Title = curSweepstake.SweepstakeName;
                this.Config.Enabled = curSweepstake.Status == "A";
                this.Config.PromotionUrl = curSweepstake.LinkedURL;
                this.Config.ImagePath = curSweepstake.ImageURL;
                this.Config.StartTime = curSweepstake.StartDate;
                this.Config.EndTime = curSweepstake.ExpiredDate;
            }
        }

        public UIFacebookShareInfo Facebook { get; private set; }

        public UITwitterShareInfo Twitter { get; private set; }

        public UIPinterestShareInfo Pinterest { get; private set; }

        public UITumblrShareInfo Tumblr { get; private set; }

        public UIMailShareInfo Mail { get; private set; }

        public bool IsShowSweepstakesPopup
        {
            get
            {
                if (this.Config == null)
                {
                    return false;
                }

                //nfsst =  NeweggFlash SweepStakes Ticket, from SSL SITE feedbackhelper.
                //var urlIndicator = HttpContext.Current.Request.QueryString["nfsst"];
                // by jw3j, use cookie instead of url param from landing page,for querystring may be cutted when request is  from global site
                var urlIndicator = CookieHelper.SweepstakesCookie.Current.NFSIC;
                if (urlIndicator != null)
                    urlIndicator = urlIndicator.Trim();
                if (string.IsNullOrEmpty(urlIndicator))
                {
                    return false;
                }

                return true;
            }
        }

        public void BuildShareInfos()
        {
            this.BuildFacebook();
            this.BuildTwitter();
            this.BuildPinterest();
            this.BuildTumblr();
            this.BuildEmail();
        }

        private void BuildFacebook()
        {
            this.Facebook = new UIFacebookShareInfo
            {
                Link = this.Config.PromotionUrl,
                Picture = this.Config.ImagePath,
                Name = this.Config.Title,
                Description = this.Config.Description
            };

            this.BuildBaseShareItem(this.Facebook);
        }

        private void BuildTwitter()
        {
            this.Twitter = new UITwitterShareInfo
            {
                OriginalReferer = this.Config.PromotionUrl,
                Url = this.Config.PromotionUrl
            };

            this.BuildBaseShareItem(this.Twitter);
        }

        private void BuildPinterest()
        {
            this.Pinterest = new UIPinterestShareInfo
            {
                Url = this.Config.PromotionUrl,
                Media = this.Config.ImagePath,
                Description = this.Config.Description
            };

            this.BuildBaseShareItem(this.Pinterest);
        }

        private void BuildTumblr()
        {
            this.Tumblr = new UITumblrShareInfo
            {
                Url = this.Config.PromotionUrl,
                Name = this.Config.Title,
                Description = this.Config.Description
            };

            this.BuildBaseShareItem(this.Tumblr);
        }

        private void BuildEmail()
        {
            this.Mail = new UIMailShareInfo();
            this.BuildBaseShareItem(this.Mail);
        }

        private void BuildBaseShareItem<T>(T info) where T : UISocialShareInfoBase
        {
            info.Title = this.Config.Title;
            info.PromotionUrl = this.Config.PromotionUrl;
            info.ImageUrl = this.Config.ImagePath;
            info.ShareDesciption = this.Config.Description;
        }
    }
}