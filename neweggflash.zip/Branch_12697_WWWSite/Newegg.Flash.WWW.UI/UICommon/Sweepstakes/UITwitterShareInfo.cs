﻿using Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UITwitterShareInfo : UISocialShareInfoBase
    {
        private const string apiUrlTemplate = "https://twitter.com/intent/tweet?original_referer={0}&source=tweetbutton&url={1}&nm_mc=SNC-Twitter&icid=SNC-twitter-_-webshare-_-NA-_-NA&utm_source=SNC-twitter&utm_medium=Webshare&utm_campaign=webshare";

        public string OriginalReferer { get; set; }

        public string Url { get; set; }

        public string BuildShareAPIUrl()
        {
            return string.Format(apiUrlTemplate,
                this.UrlEncode(this.OriginalReferer),
                this.UrlEncode(this.Url));
        }
    }
}