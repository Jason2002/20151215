﻿using Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UITumblrShareInfo : UISocialShareInfoBase
    {
        private const string apiUrlTemplate = "http://www.tumblr.com/share/link?url={0}&name={1}&description={2}&nm_mc=SNC-tumblr&icid=SNC-tumblr-_-webshare-_-NA-_-NA&utm_source=SNC-tumblr&utm_medium=Webshare&utm_campaign=webshare";

        public string Url { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string BuildShareAPIUrl()
        {
            return string.Format(apiUrlTemplate,
                this.UrlEncode(this.Url),
                this.UrlEncode(this.Name),
                this.UrlEncode(this.Description));
        }
    }
}