﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Routing;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UIFacebookShareInfo : UISocialShareInfoBase
    {
        private const string apiUrlTemplate = "https://www.facebook.com/dialog/feed?app_id={0}&redirect_uri={1}&link={2}&picture={3}&name={4}&caption={5}&description={6}&nm_mc=SNC-Facebook&icid=SNC-Facebook-_-webshare-_-NA-_-NA&utm_source=SNC-Facebook&utm_medium=Webshare&utm_campaign=webshare";

        public string AppId { get; private set; }
        

        public string Picture { get; set; }

        public string Name { get; set; }

        

        public string Description { get; set; }

        public UIFacebookShareInfo()
        {
            if (this.SocialShareConfig != null && this.SocialShareConfig.Facebook != null)
            {
                this.AppId = this.SocialShareConfig.Facebook.AppId;
            }
        }

        public string BuildShareAPIUrl()
        {
            return string.Format(apiUrlTemplate,
                this.AppId,
                this.UrlEncode(this.RedirectUri),
                this.UrlEncode(this.Link),
                this.UrlEncode(this.Picture),
                this.UrlEncode(this.Name),
                this.UrlEncode(this.Caption),
                this.UrlEncode(this.Description));
        }
    }
}