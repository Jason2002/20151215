﻿using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class SweepstakesHelper
    {
        public static UISweepstakesSocialShareInfo Process()
        {
            UISweepstakesSocialShareInfo info = new UISweepstakesSocialShareInfo();

            if (info.IsShowSweepstakesPopup == false)
            {
                return info;
            }

            info.BuildShareInfos();

            return info;
        }
    }
}