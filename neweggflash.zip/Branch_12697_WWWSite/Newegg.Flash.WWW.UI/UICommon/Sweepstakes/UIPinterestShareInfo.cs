﻿using Newegg.Flash.WWW.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon.Sweepstakes
{
    public class UIPinterestShareInfo : UISocialShareInfoBase
    {
        private const string apiUrlTemplate = "http://pinterest.com/pin/create/button/?url={0}&media={1}&description={2}&nm_mc=SNC-Pinterest&icid=SNC-Pinterest-_-webshare-_-NA-_-NA&utm_source=SNC-Pinterest&utm_medium=Webshare&utm_campaign=webshare";

        public string Url { get; set; }

        public string Media { get; set; }

        public string Description { get; set; }

        public string BuildShareAPIUrl()
        {
            return string.Format(apiUrlTemplate,
                this.UrlEncode(this.Url),
                this.UrlEncode(this.Media),
                this.UrlEncode(this.Description));
        }
    }
}