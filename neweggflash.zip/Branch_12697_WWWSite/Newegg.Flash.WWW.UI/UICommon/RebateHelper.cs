﻿using Newegg.Flash.WWW.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon
{
    public class MailinRebateInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public decimal RebateAmount { get; set; }
        /// <summary>
        /// USD or other.
        /// </summary>
        public string CurrentCode { get; set; }
        /// <summary>
        /// Card,Check,default:Check
        /// </summary>
        public string RedemptionType { get; set; }
    }

    public class RebateHelper
    {
        private static readonly string CardType = "Card";
        private static readonly string CheckType = "Check";
        private static readonly string DefaultCurrentCode = "USD";

        private static MailinRebateInfo[] ParseMailinRebate(string rebateAmounts, string rebateDescription)
        {
            MailinRebateInfo[] rebates = new MailinRebateInfo[0];
            if (string.IsNullOrEmpty(rebateAmounts) || string.IsNullOrEmpty(rebateDescription))
                return rebates;
            var amounts = rebateAmounts.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
            var descriptions = rebateDescription.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
            if (amounts.Length == descriptions.Length)
            {
                rebates = new MailinRebateInfo[amounts.Length];
                for (int i = 0; i < amounts.Length; i++)
                {
                    string[] array = rebateAmounts.Split(",".ToArray(), StringSplitOptions.RemoveEmptyEntries);
                    rebates[i] = new MailinRebateInfo()
                    {
                        Description = descriptions[i].Trim(),
                        RebateAmount = Math.Abs(Converter.ToDecimal(array[0].Trim(), 0)),
                        CurrentCode = array.Length > 1 ? array[1].Trim() : DefaultCurrentCode,
                        RedemptionType = array.Length > 2 ? array[2] : CheckType
                    };
                    break;
                }
            }
            return rebates;
        }

        public static string BuildMaininRebate(AdditionalProductInfo info,bool showTips)
        {
            if (info == null)
                return null;
            MailinRebateInfo rebate = ParseMailinRebate(info.Mailrebateamount, info.Mailrebatedescrip).FirstOrDefault();
            if (rebate == null || rebate.CurrentCode != "USD")
                return null;
            StringBuilder builder = new StringBuilder();

            if (info.MapPrice == "0")
            {
                if (!CardType.Equals(rebate.RedemptionType))
                {
                    //$X.XX after $RebateAmount rebate
                    builder.AppendFormat("<span class=\"priceNoteDollar\">{0}</span>", (info.FinalPrice - rebate.RebateAmount).CurrencyFormat());
                    builder.Append("<span class=\"priceNoteLabel\"> after </span>");
                    builder.AppendFormat("<span class=\"priceNoteDollar\">{0}</span>",rebate.RebateAmount.CurrencyFormat());
                    builder.Append("<span class=\"priceNoteLabel\"> rebate</span>");
                }
                else
                {
                    //$X.XX after $RebateAmount rebate card
                    builder.AppendFormat("<span class=\"priceNoteDollar\">{0}</span>", (info.FinalPrice - rebate.RebateAmount).CurrencyFormat());
                    builder.Append("<span class=\"priceNoteLabel\"> after </span>");
                    builder.AppendFormat("<span class=\"priceNoteDollar\">{0}</span>", rebate.RebateAmount.CurrencyFormat());
                    builder.Append("<span class=\"priceNoteLabel\"> rebate card</span>");
                }
            }
            else if (info.MapPrice == "1" || info.MapPrice == "2")
            {
                if (!CardType.Equals(rebate.RedemptionType))
                {
                    //$RebateAmount Rebate available
                    builder.AppendFormat("<span class=\"priceNoteDollar\">{0}</span>", rebate.RebateAmount.CurrencyFormat());
                    builder.Append("<span class=\"priceNoteLabel\"> Rebate available</span>");
                }
                else
                {
                    //$RebateAmount Rebate Card available
                    builder.AppendFormat("<span class=\"priceNoteDollar\">{0}</span>", rebate.RebateAmount.CurrencyFormat());
                    builder.Append("<span class=\"priceNoteLabel\"> Rebate Card available</span>");
                }
            }

            if (showTips && info.SpecialLinkInfoList.Any()
                && !string.IsNullOrEmpty(info.SpecialLinkInfoList[0].Name))
            {
                builder.Append("<span class=\"iconRightHelp\">help</span>");
                builder.Append("<div class=\"popContainer rightPopContainer\">");
                builder.Append("<span class=\"arrow\"></span>");
                builder.Append("<div class=\"longarrow\"></div>");
                builder.Append("<h3 class=\"rightHead\">REBATE CARD</h3>");
                builder.AppendFormat("<p>{0}</p>", info.SpecialLinkInfoList[0].Name);
                if (info.SpecialLinkInfoList[0].HasSpecialLink && !string.IsNullOrEmpty(info.SpecialLinkInfoList[0].Link))
                {
                    builder.AppendFormat("<p class=\"links\"><a target=\"_blank\" class=\"link\" href=\"{0}\" title=\"Print Rebate Form\">Print Rebate Form</a></p>",
                        info.SpecialLinkInfoList[0].Link);
                }
            }

            return builder.ToString();
        }
    }
}