﻿using System;
using System.Text;
using System.Web;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Common.Configuration;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Build ThirdParty script
    /// </summary>
    public static class ThirdPartyBuilder
    {
        /// <summary>
        /// Build GoogleAnalytics Code.
        /// </summary>
        /// <returns></returns>
        public static string BuildGoogleAnalyticsCode()
        {
            string googleTrackingCode = string.Empty;

            ThirdParty thirdPartyConfig = ConfigurationWWWManager<ThirdParty>.ItemCfg();
            if (thirdPartyConfig != null && thirdPartyConfig.GoogleAnalyticsCodeEnable)
            {
                googleTrackingCode = thirdPartyConfig.GoogleAnalyticsCode.Content
                                                .Replace("#accountID#", thirdPartyConfig.GoogleAnalyticsCode.AccountID)
                                                .Replace("#trackDomain#", thirdPartyConfig.GoogleAnalyticsCode.TrackDomain);
            }

            return googleTrackingCode;
        }

        /// <summary>
        /// Build Nassau code.
        /// </summary>
        /// <returns></returns>
        public static string BuildNassau()
        {
            string nassauCode = string.Empty;

            ThirdParty thirdPartyConfig = ConfigurationWWWManager<ThirdParty>.ItemCfg();
            if (thirdPartyConfig != null && thirdPartyConfig.NassauEnable)
            {
                nassauCode = thirdPartyConfig.Nassau.Content;
            }

            return nassauCode;
        }

        /// <summary>
        /// Build NassauTracking code.
        /// </summary>
        /// <param name="CampaignName">Campaign Name.</param>
        /// <returns></returns>
        public static string BuildNassauTracking(string CampaignName)
        {
            string nassauTrackingCode = string.Empty;

            ThirdParty thirdPartyConfig = ConfigurationWWWManager<ThirdParty>.ItemCfg();
            if (thirdPartyConfig != null && thirdPartyConfig.NassauTrackingEnable)
            {
                nassauTrackingCode = thirdPartyConfig.NassauTracking.TrackingCode
                                         .Replace("#campaignName#", HttpUtility.JavaScriptStringEncode(CampaignName))
                                         .Replace("#serverID#", Environment.MachineName);
            }

            return nassauTrackingCode;
        }

        /// <summary>
        /// Build Newegg Visitor Tracking Cookie
        /// </summary>
        /// <returns></returns>
        public static string BuildNVTC() 
        {
            string nvtcCode = string.Empty;
            ThirdParty thirdPartyConfig = ConfigurationWWWManager<ThirdParty>.ItemCfg();
            if (thirdPartyConfig != null && thirdPartyConfig.NeweggVisitorTrackingCookieEnable)
            {
                nvtcCode = thirdPartyConfig.NeweggVisitorTrackingCookie.Code;
            }
            return nvtcCode;
        }
    }
}
