﻿using Newegg.EC.Cryptograph;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Encrypt string.
    /// </summary>
    public static class Encryption
    {
        /// <summary>
        /// Cryption Item.
        /// </summary>
        private static ICrypto crypto;

        /// <summary>
        /// Initializes static members of the Encryption class.
        /// </summary>
        static Encryption()
        {
            var tmpCom = new CryptoManagerForCom();
            crypto = tmpCom.GetCrypto(CryptoAlgorithm.TripleDES);
        }

        /// <summary>
        /// Encrypt String.
        /// </summary>
        /// <param name="val">Plain string.</param>
        /// <returns>Sting of Encrypted as base64.</returns>
        public static string Encrypt(string val)
        {
            if (string.IsNullOrEmpty(val) || val.Trim() == string.Empty)
            {
                return string.Empty;
            }

            return crypto.Encrypt(val);
        }

        /// <summary>
        /// Decrypt base64String.
        /// </summary>
        /// <param name="val">String of encrypted as base64.</param>
        /// <returns>Plain string.</returns>
        public static string Decrypt(string val)
        {
            if (string.IsNullOrEmpty(val) || val.Trim() == string.Empty)
            {
                return string.Empty;
            }

            return crypto.Decrypt(val);
        }
    }
}