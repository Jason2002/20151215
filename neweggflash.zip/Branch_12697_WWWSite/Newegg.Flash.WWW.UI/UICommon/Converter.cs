﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.UICommon
{
    public static class Converter
    {
        public static decimal ToDecimal(string value, decimal defaultValue)
        {
            decimal.TryParse(value, out defaultValue);
            return defaultValue;
        }
    }
}