﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using Newegg.EC;
using Newegg.EC.BizUnit;
using Newegg.EC.Configuration;
using Newegg.EC.Net.Implement;
using Newegg.EC.Web.Mvc;
using Newegg.EC.Web.Script.Implement;
using Newegg.Flash.WWW.Common;
using Newegg.Flash.WWW.Globalization;
using Newegg.Flash.WWW.Common.Configuration;
using System.Net;
using Newegg.Framework.Logging;
using System.Xml;
using System.Runtime.Serialization.Json;
using Newegg.Flash.WWW.Model;


namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Utility class.
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// The Current Web host.
        /// </summary>
        private static string flashHost = string.Empty;

        private static string flashHostWithoutPort = string.Empty;

        private static Random m_Random = new Random();

        private static string GomezAgent = "GomezAgent";

        /// <summary>
        /// Deep copy an object using binaray serialize.
        /// </summary>
        /// <typeparam name="T">Object type.</typeparam>
        /// <param name="originObject">Need to be cloned object.</param>
        /// <returns>A new object.</returns>
        public static T ExDeepClone<T>(this T originObject)
        {
            using (var objectStream = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(objectStream, originObject);
                objectStream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(objectStream);
            }
        }

        /// <summary>
        /// Check request device is mobile or pad
        /// </summary>
        /// <returns></returns>
        public static bool IsMobileDevice()
        {
            if (HttpContext.Current == null || HttpContext.Current.Request == null)
                return false;
            string userAgent = HttpContext.Current.Request.UserAgent;
            if (string.IsNullOrEmpty(userAgent))
                return false;
            string[] deviceArray = new string[] { "Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod" };
            foreach (var device in deviceArray)
            {
                if (userAgent.IndexOf(device, StringComparison.OrdinalIgnoreCase) != -1)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Get client ip with ["X-Source-IP"] and ["REMOTE_ADDR"].
        /// </summary>
        /// <returns>Client ip.</returns>
        public static string ReferenceIP()
        {
            if (!string.IsNullOrEmpty(HttpContext.Current.Request.Headers["X-Source-IP"]))
            {
                return HttpContext.Current.Request.Headers["X-Source-IP"];
            }

            return HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }

        /// <summary>
        /// Get Web Host.  flash.newegg.com
        /// </summary>
        /// <returns>Web Host.</returns>
        public static string WebHost()
        {
            if (string.IsNullOrEmpty(flashHost))
            {
                var url = HttpContext.Current.Request.Url;
                if (url.Authority.ToLower().Contains("localhost:"))
                {
                    flashHost = url.Authority;
                }
                else
                {
                    flashHost = url.DnsSafeHost;
                }
            }

            return flashHost;
        }

        /// <summary>
        ///  Get Host   http:// flash.newegg.com/
        /// </summary>
        /// <returns></returns>
        public static string WebHostWithScheme()
        {
            var host = WebHost();

            return HttpContext.Current.Request.Url.Scheme + "://" + host;
        }

        /// <summary>
        /// Get Web Host without Port.
        /// </summary>
        /// <returns></returns>
        public static string WebHostWithoutPort()
        {
            if (string.IsNullOrEmpty(flashHostWithoutPort))
            {
                flashHostWithoutPort = HttpContext.Current.Request.Url.Host;
            }

            return flashHostWithoutPort;
        }

        public static string CurrencyFormat(this decimal value)
        {
            var bizUnit = BizThreadContext.BizUnitInfo;
            return string.Format(System.Globalization.CultureInfo.CreateSpecificCulture(bizUnit.DefaultLanguageCode), "{0:C2}", value)
                .Replace("$", Newegg.Flash.WWW.BizThreadContext.CurrentCurrencyInfo.Symbol);
        }

        public static string DisplayFinalPrice(this decimal value)
        {
            value = Math.Round(value, 2, MidpointRounding.AwayFromZero);
            string price =
                string.Format("{0:f2}", value);
            return string.Format(Globalization.Product.FinalPriceFormat,
                price.Substring(0, price.LastIndexOf('.')),
                price.Substring(price.LastIndexOf('.') + 1));
        }

        public static string FromTicks(long timeTick, DateTime expireDate)
        {
            string result = string.Empty;

            double value = TimeSpan.FromTicks(timeTick).TotalDays;
            CultureInfo culture = Thread.CurrentThread.CurrentUICulture;
            
            
            if (value >= 1)
            {
                expireDate = Utility.GetTimeByTimeZoneID(expireDate, null,
                    Newegg.Flash.WWW.BizThreadContext.RegionCode.TimeZone);

                DateTime date = Common.CommonUtility.DateTimeNow;
                date = date.AddDays(Math.Ceiling(value));
                result = string.Format(culture, "<span>{0}</span> {1} ({2:ddd})", Math.Ceiling(value), Layout.Item_Day, expireDate);
            }

            if (string.IsNullOrEmpty(result) && value > 0)
            {
                value = TimeSpan.FromTicks(timeTick).TotalHours;
                result = string.Format("<span>{0}</span> {1}", Math.Ceiling(value), Layout.Item_Hour);
                if (value < 1)
                {
                    result = Layout.Item_Minutes;
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                result = Layout.ItemPartial_Expired;
            }

            return result;
        }

        public static string ToJSON(object data, bool allowBase64 = false)
        {
            string result = string.Empty;
            if (data != null)
            {
                //IJsonSerializer serializer = ECLibraryContainer.Current.GetInstance<IJsonSerializer>();
                //result = serializer.SerializeObjectToText(data);
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                result = serializer.Serialize(data);
                result = Escape(result);
                if (allowBase64)
                {
                    result = Convert.ToBase64String(UTF8Encoding.UTF8.GetBytes(result));
                }
            }
            return result;
        }

        public static string Escape(string source)
        {
            StringBuilder sb = new StringBuilder();
            byte[] ba = System.Text.Encoding.Unicode.GetBytes(source);
            for (int i = 0; i < ba.Length; i += 2)
            {
                sb.Append("%u");
                sb.Append(ba[i + 1].ToString("X2"));

                sb.Append(ba[i].ToString("X2"));
            }
            return sb.ToString();

        } 

        public static string WarrantyDaysFormat(int days)
        {
            string result = "0 day";
            if (days >= 99999)
            {
                result = "Lifetime";
            }
            else if (days > 0)
            {
                if (days % 365 >= 360 || days % 365 <= 5)
                {
                    double years = Math.Round((days / 365d));
                    result = (int)years + (years > 1 ? " years" : " year");
                }
                else
                {
                    result = days + " days";
                }
            }

            return result;
        }

        public static long TotalMilliseconds(this DateTime current)
        {
            var dateTimeForCurrentCountry = GetTimeByTimeZoneID(current, null, BizThreadContext.RegionCode.TimeZone);

            return (long)(dateTimeForCurrentCountry - new DateTime(1970, 1, 1)).TotalMilliseconds;
        }

        public static string ServerTime
        {
            get
            {
                var current = Common.CommonUtility.DateTimeNow;
                var dateTimeForCurrentCountry = GetTimeByTimeZoneID(current, null, BizThreadContext.RegionCode.TimeZone);
                TimeSpan ts = dateTimeForCurrentCountry - DateTime.Parse("1970-01-01 00:00:00");
                var m = ts.TotalMilliseconds;
                return m.ToString();
            }
        }

        /// <summary>
        /// Cut string
        /// </summary>
        /// <param name="description"></param>
        /// <param name="maxLength"></param>
        /// <param name="eclipsis"></param>
        /// <returns></returns>
        public static string CutString(this string description, int maxLength, string eclipsis = "")
        {
            if (string.IsNullOrWhiteSpace(description))
                return string.Empty;
            if (description.Length <= maxLength)
                return description;
            eclipsis = eclipsis ?? string.Empty;
            int pos = maxLength - eclipsis.Length;
            while (pos > 0 && char.IsLetter(description[pos]))
            {
                pos--;
            }
            if (pos < 0)
            {
                pos = 0;
            }
            return description.Substring(0, pos) + eclipsis;
        }

        public static ActionResult AllowAccessItem(FlashController current, bool needLogin)
        {
            if (needLogin)
            {
                if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().EnableForceLogin &&
                  (current.ViewBag.UserInfo == null ||
                    !current.ViewBag.UserInfo.IsLogin))
                {
                    if (ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().SwithToNewegg)
                    {
                        var url = new UrlHelper(current.ControllerContext.RequestContext);
                        var redirectUrl = Path.Combine(url.BuildUrl(PageAliase.Homepage) + current.HttpContext.Request.RawUrl.TrimStart('/'));
                         
                        if (!string.IsNullOrEmpty(current.GlobalPath))
                        {
                            redirectUrl = Path.Combine(url.BuildUrl(PageAliase.Homepage).ToLower().Replace(current.GlobalPath.TrimEnd('/'), "") + current.HttpContext.Request.RawUrl);
                        }
                        return new RedirectResult(string.Format(url.BuildUrl(PageAliase.OutSite.NeweggLogin), Uri.EscapeDataString(redirectUrl)));
                    }
                    else
                    {
                        return new RedirectResult(string.Format("~/?url={0}#", Uri.EscapeDataString(current.HttpContext.Request.RawUrl)));
                    }
                }
            }

            return null;
        }

        public static HtmlString ScriptRenderFromScriptConfig(string name)
        {
            var mgr = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
            var config = mgr.GetConfiguration<ScriptsConfig>(System.IO.Path.Combine(HttpContext.Current.Server.MapPath("~"),
                                                                                       "Configurations/Scripts.config"));
            name = name.ToLower();

            foreach (var item in config.Scripts.Collection)
            {
                if (item.Key.ToLower() == name)
                {
                    return new HtmlString(@"<script>NEG.run(function(require){require(""" +
                                            item.Src.Replace("/", ".").Replace("\\", ".").TrimEnd(".js".ToCharArray()) +
                                          @""");});</script>");
                }
            }
            return null;
        }

        public static string AddQueryStringParam(string url, string key, string value)
        {
            if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(url))
            {
                return null;
            }

            var seperator = url.IndexOf('?') > 0 ? "&" : "?";

            return string.Format("{0}{1}{2}={3}", url, seperator, key, HttpUtility.UrlEncode(value));
        }

        public static string AddGiftTagForUrl(string url, bool isGift)
        {
            if (isGift)
            {
                return AddQueryStringParam(url, "gift", "1");
            }

            return url;
        }

        /// <summary>
        /// 时间戳转为C#格式时间
        /// </summary>
        /// <param name="timeStamp">Unix时间戳格式</param>
        /// <returns>C#格式时间</returns>
        public static DateTime ConvertTimestampToDateTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        /// <summary>
        /// DateTime时间格式转换为Unix时间戳格式
        /// </summary>
        /// <param name="time"> DateTime时间格式</param>
        /// <returns>Unix时间戳格式</returns>
        public static string ConvertDateTimeToTimestamp(DateTime time)
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));
            return ((int)(time - startTime).TotalSeconds).ToString();
        }

        public static int RandomNumber(int maxValue)
        {
            lock (m_Random)
            {
                return m_Random.Next(maxValue);
            }
        }

        public static string EscapeExternal(string htmlContent, bool isFontStyle = false)
        {
            var escapedContent = htmlContent;
            var manager = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
            var hosts = manager.GetConfiguration<HostsConfig>();
            var host =
                hosts.Hosts.Collection.FirstOrDefault(
                    t => System.String.Compare(t.Name, "flashWWWSite", System.StringComparison.OrdinalIgnoreCase) == 0);
            var address = "http://www.neweggflash.com";
            var config = ConfigurationWWWManager<BizUI>.ItemCfg();
            if (config != null && config.SwithToNewegg)
            {
                address = "http://flash.newegg.com";
            }
            if (host != null && !string.IsNullOrEmpty(host.Address))
            {
                address = host.Address.TrimEnd('/');
            }

            if (BizThreadContext.IsGlobalRequest)
            {
                address += "/global/" + BizThreadContext.RegionCode.DisplayShortCode;
            }

            if (isFontStyle)
            {
                var pattern = "/Content/en/themes/fonts/";
                var replacement = "/content/en/themes/fl/fonts/";
                escapedContent = Regex.Replace(escapedContent, pattern, replacement, RegexOptions.IgnoreCase);
            }
            else
            {
                var searchUrlPattern = "data-search-url=\"(?<content>.*?)\"";
                var keywordUrlPattern = "data-keyword-url=\"(?<content>.*?)\"";
                var searchReplacement = string.Format("data-search-url=\"{0}${{content}}\"", address);
                var keywordReplacement = string.Format("data-keyword-url=\"{0}${{content}}\"", address);
                escapedContent = Regex.Replace(escapedContent, searchUrlPattern, searchReplacement,
                    RegexOptions.IgnoreCase);
                escapedContent = Regex.Replace(escapedContent, keywordUrlPattern, keywordReplacement,
                    RegexOptions.IgnoreCase);
            }
            escapedContent = escapedContent.Replace("\\", "\\\\")
                .Replace("\r", "")
                .Replace("\n", "\\n")
                .Replace("'", "\\'")
                .Replace("\"", "\\\"");
            return escapedContent;
        }

        public static bool IsGomez(string userAgent)
        {
            return userAgent.IndexOf(GomezAgent, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public static string GetReferenceUrl()
        {
            return GetReferenceUrl(false);
        }

        public static string GetReferenceUrl(bool isToLowerCase)
        {
            string url = HttpContext.Current.Request.ServerVariables["HTTP_REFERER"];

            if (string.IsNullOrEmpty(url))
            {
                return string.Empty;
            }
            if (isToLowerCase)
            {
                return url.ToLower();
            }

            return url;
        }

        public static string GetReferenceUrlLocalPath()
        {
            string reference = GetReferenceUrl();
            int maxSchemaLength = "https://".Length;
            if (!string.IsNullOrEmpty(reference) && reference.Length > maxSchemaLength)
            {
                reference = reference.Substring(maxSchemaLength);
                int beginIndex = reference.IndexOf('/');
                int endIndex = reference.IndexOf('?');
                if (beginIndex > 0)
                {
                    if (endIndex > 0)
                    {
                        return reference.Substring(beginIndex, endIndex - beginIndex);
                    }
                    return reference.Substring(beginIndex);
                }
            }

            return string.Empty;
        }

        public static string GetRegionByIP(string referenceIPData)
        {
            string regionCode = string.Empty;
            try
            {
                WebClient client = new WebClient();
                //data like [{"216.154.55.015":{"err":-1,"cyc":"CA"}}]
                string data = client.DownloadString(referenceIPData);
                client.Dispose();
                if (string.IsNullOrWhiteSpace(data))
                {
                    return regionCode;
                }

                //split data, get region code value, like CA or US ...
                string splitString = "\"region\":\"";
                int startIndex = data.IndexOf(splitString) + splitString.Length;
                regionCode = data.Substring(startIndex, data.IndexOf("\"", startIndex) - startIndex);
            }
            catch (Exception ex)
            {
                LoggerFactory.CreateLogger().LogEvent("Newegg.Website.Service", 3, ex.ToString());
            }
            return regionCode;
        }

        public static string GetTranslateResult(string sourceString, TranslatorSetting setting)
        {
            var result = string.Empty;
            try
            {
                var strRequestDetails = string.Format(setting.RequestDetails, HttpUtility.UrlEncode(setting.ClientID), HttpUtility.UrlEncode(setting.Password));
                System.Net.WebRequest webRequest = System.Net.WebRequest.Create(setting.TranslatorAccessURI);
                webRequest.Proxy = WebRequest.DefaultWebProxy;
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.Method = "POST";

                byte[] bytes = System.Text.Encoding.ASCII.GetBytes(strRequestDetails);
                webRequest.ContentLength = bytes.Length;
                using (System.IO.Stream outputStream = webRequest.GetRequestStream())
                {
                    outputStream.Write(bytes, 0, bytes.Length);
                }

                var webResponse = webRequest.GetResponse();

                var serializer = new DataContractJsonSerializer(typeof(TranslaotrAccessToken));

                //Get deserialized object from JSON stream 
                TranslaotrAccessToken token = (TranslaotrAccessToken)serializer.ReadObject(webResponse.GetResponseStream());

                string headerValue = "Bearer " + token.access_token;

                System.Net.WebRequest translationWebRequest = System.Net.WebRequest.Create(string.Format(setting.TranslateURI, sourceString));
                translationWebRequest.Proxy = WebRequest.DefaultWebProxy;
                translationWebRequest.Headers.Add("Authorization", headerValue);
                System.Net.WebResponse response = null;
                response = translationWebRequest.GetResponse(); 
                var translatedStream = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("utf-8"));
                var  xTranslation = new XmlDocument();
                xTranslation.LoadXml(translatedStream.ReadToEnd());

                result = xTranslation.InnerText;
            }
            catch (Exception ex)
            {
                result = sourceString;
            }

            return result;
        }
          
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceTime"></param>
        /// <param name="timeZoneID">destination timezoneID, if not a stadard tiem zone id ,use PST</param>
        /// <returns></returns>
        public static DateTime GetTimeByTimeZoneID(DateTime sourceTime, string fromTimeZoneID = "Pacific Standard Time", string toTimeZoneID = "Pacific Standard Time")
        {
            sourceTime = new DateTime(sourceTime.Year, sourceTime.Month, sourceTime.Day, sourceTime.Hour, sourceTime.Minute, sourceTime.Second, sourceTime.Millisecond, DateTimeKind.Unspecified);
            var systemTimeZone = TimeZoneInfo.GetSystemTimeZones().Select(x => x.Id);

            if (string.IsNullOrEmpty(fromTimeZoneID) || !systemTimeZone.Contains(fromTimeZoneID))
            {
                fromTimeZoneID = "Pacific Standard Time";
            }

            if (string.IsNullOrEmpty(toTimeZoneID) || !systemTimeZone.Contains(toTimeZoneID))
            {
                toTimeZoneID = "Pacific Standard Time";
            }

            TimeZoneInfo from = TimeZoneInfo.FindSystemTimeZoneById(fromTimeZoneID);
            TimeZoneInfo to = TimeZoneInfo.FindSystemTimeZoneById(toTimeZoneID);

            return TimeZoneInfo.ConvertTime(sourceTime, from, to);
        }
         
        /// <summary>
        /// change price from local price to usd price
        /// </summary>
        /// <param name="model"></param>
        /// <param name="result"></param>
        internal static void ProcessLocalPrice(ItemGroup model, System.Collections.Generic.IEnumerable<RealTimeExchangeRateModel> result)
        {
           
            if (BizThreadContext.CurrentCurrencyInfo.SupportDecimal)
            {
                var digtalCount = BizThreadContext.CurrentCurrencyInfo.DecimalDigits;
                model.Items.ForEach(
                                 (item) =>
                                 {
                                     var rate = result.Where(x => x.itemNumber == item.ItemNumber).FirstOrDefault();
                                     double exchageRate = 1;
                                     if (rate != null && rate.exchangeRate.HasValue)
                                         exchageRate = rate.exchangeRate.Value;
                                     item.UnitPrice = Math.Round((decimal)((double)item.SourceUnitPrice / exchageRate), digtalCount, MidpointRounding.AwayFromZero);
                                     item.DiscountInstant = Math.Round((decimal)((double)item.SourceDiscountInstant / exchageRate), digtalCount, MidpointRounding.AwayFromZero);
                                     item.FinalPrice = item.UnitPrice - item.DiscountInstant;
                                 });
            }
            else
            { 
                model.Items.ForEach(
                                (item) =>
                                {
                                    var rate = result.Where(x => x.itemNumber == item.ItemNumber).FirstOrDefault();
                                    double exchageRate = 1;
                                    if (rate != null && rate.exchangeRate.HasValue)
                                        exchageRate = rate.exchangeRate.Value;
                                    item.UnitPrice = Math.Floor((decimal)((double)item.SourceUnitPrice / exchageRate));
                                    item.DiscountInstant = Math.Floor((decimal)((double)item.SourceDiscountInstant / exchageRate));
                                    item.FinalPrice = item.UnitPrice - item.DiscountInstant;
                                });
            }
        }
    }
}
