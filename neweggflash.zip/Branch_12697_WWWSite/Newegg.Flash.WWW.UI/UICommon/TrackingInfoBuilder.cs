﻿using Newegg.EC;
using Newegg.EC.Log;
using Newegg.Flash.WWW.UI.UICommon.Tealium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Third party tracking builder entry class.
    /// </summary>
    public static class TrackingInfoBuilder
    {
        /// <summary>
        /// The third party tracking key.
        /// </summary>
        public static readonly string TrakingKey = "THIRD_PARTY_TRAKING_KEY";

        /// <summary>
        /// The logger.
        /// </summary>
        private static ILogger logger = ECLibraryContainer.Current.GetInstance<ILogger>();

        /// <summary>
        /// The builders.
        /// </summary>
        private static Lazy<List<ITrackingBuilder>> builders = new Lazy<List<ITrackingBuilder>>(InitThirdPartyBuilders);

        /// <summary>
        /// The script bulider.
        /// </summary>
        private static ThreadLocal<StringBuilder> scriptBuilder = new ThreadLocal<StringBuilder>();

        /// <summary>
        /// Gets or sets the scriot builder.
        /// </summary>
        private static StringBuilder ScriptBuilder
        {
            get { return scriptBuilder.Value; }
            set { scriptBuilder.Value = value; }
        }

        /// <summary>
        /// Process the third party integration.
        /// </summary>
        /// <param name="context">The tacking context.</param>
        /// <returns>Final script.</returns>
        public static string Build(TrackingContext context)
        {
            ScriptBuilder = new StringBuilder();

            // 执行所有的第三方集成管理器
            // BUILDERS在初始化时自动从程序集中寻找实现了ITrackingBuilder的类型并实例化后做缓存
            foreach (var buider in builders.Value)
            {
                ProcessIntergration(buider, context);
            }

            return ScriptBuilder.ToString();
        }

        /// <summary>
        /// Process the builder,unified exception handling.
        /// </summary>
        /// <param name="builder">The third party builder.</param>
        /// <param name="context">The tracking context.</param>
        private static void ProcessIntergration(ITrackingBuilder builder, TrackingContext context)
        {
            try
            {
                var script = builder.Build(context);

                ScriptBuilder.AppendLine(script);
            }
            catch (Exception ex)
            {
                try
                {
                    logger.Exception = ex;
                    logger.AddCategory("Newegg.Flash[" + builder.Name + "]");
                    logger.AddMessage("Third party integration");
                    logger.Write();
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Get all the builder which realized from ITrackingBuilder from the assemble.
        /// </summary>
        /// <returns>The result.</returns>
        private static List<ITrackingBuilder> InitThirdPartyBuilders()
        {
            var builders = new List<ITrackingBuilder>();

            var tackingBuilderType = typeof(ITrackingBuilder);

            var builderTypes = from type in typeof(TealiumProcessorManager).Assembly.GetTypes()
                               where tackingBuilderType.IsAssignableFrom(type)
                               && type.IsInterface == false
                               && type.IsAbstract == false
                               select type;

            foreach (var type in builderTypes)
            {
                var instance = Activator.CreateInstance(type) as ITrackingBuilder;
                if (instance != null)
                {
                    builders.Add(instance);
                }
            }

            return builders;
        }
    }
}