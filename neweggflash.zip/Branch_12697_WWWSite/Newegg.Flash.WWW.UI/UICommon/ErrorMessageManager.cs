﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Newegg.Flash.WWW.Globalization;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Error message manager.
    /// </summary>
    public static class ErrorMessageManager
    {

        /// <summary>
        /// Get login register message.
        /// </summary>
        /// <param name="errorCode">Error code.</param>
        /// <param name="accountName">Account name.</param>
        /// <param name="expireTime">Expire time.</param>
        /// <returns>Error description.</returns>
        public static string GetLoginRegisterMessage(string errorCode, string accountName, string expireTime) 
        {
            string errorText = string.Empty;
            switch (errorCode)
            {
                /*BIZ_TEMPORARILY_LOCKED*/
                case "107523":
                    errorText = string.Format(Login.Warning_AccountHasBeenTemporarilyLockedDescription_107523, expireTime);
                    break;
                /*BIZ_EMPTY_PARAMETER*/
                case "107517":
                    errorText = Login.Warning_CheckParametersMessage_107517;
                    break;
                /*BIZ_VALIDATECODE_ERROR*/
                case "107522":
                case "102411":
                    errorText = Login.Warning_ValidationTextInvalidDescription_107522_102411;
                    break;
                /*BIZ_LOGINNAME_ISNOTEXIST or BIZ_PASSWORD_ERROR*/
                case "107520":
                case "107521":
                    errorText = Login.Warning_LoginFailed_107520_107521;
                    break;
                /*BIZ_BLOCK_LOGIN*/
                case "107519":
                    errorText = Login.Warning_AccountHasBeenSuspendedDescription_107519;
                    break;
                /*BIZ_EMPTY_PARAMETERS*/
                case "102401":
                    errorText = Login.Warning_EmptyParametersMessage_102401;
                    break;
                /*BIZ_LOGINNAME_ISINVAILD*/
                case "102407":
                    errorText = Login.Warning_LoginNameIsInvalidate_102407;
                    break;
                /*BIZ_DUPLICATE_LOGINNAME*/
                case "102404":
                    errorText = string.Format(Login.Warning_AnAccountAlreadyExistsDescription_102404, accountName);
                    break;
                /*SYSTEM_EXEC_DATABASE_FAILED_CUSTOMERINFOPERSIST or MESSAGE_CODE_CALLSERVICEFAILED*/
                case "102103":
                case "100001":
                    errorText = string.Format(Login.Warning_RegsiterFailed_102103_100001, errorCode);
                    break;
                default:
                    errorText = errorCode;
                    break;
            }

            return errorText;
        }

    }
}