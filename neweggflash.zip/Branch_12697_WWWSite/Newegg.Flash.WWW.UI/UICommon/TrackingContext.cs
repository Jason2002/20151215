﻿using System.Web.Mvc;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW.UI.UICommon
{
    /// <summary>
    /// Tealium tracking context.
    /// </summary>
    public class TrackingContext
    {
        /// <summary>
        /// Cached action key.
        /// </summary>
        private string actionKey = string.Empty;

        /// <summary>
        /// Gets or sets the executed context.
        /// </summary>
        public ActionExecutedContext ExecutedContext { get; set; }

        /// <summary>
        /// Gets or sets the view data of each action.
        /// </summary>
        public ViewDataDictionary ViewData { get; set; }

        /// <summary>
        /// Gets or sets the temp data of each action.
        /// </summary>
        public TempDataDictionary TempData { get; set; }

        /// <summary>
        /// Gets or sets the view bag data of each action.
        /// </summary>
        public dynamic ViewBag { get; set; }

        /// <summary>
        /// Gets or sets the current user info.
        /// </summary>
        public OtherInfoCookieModel UserInfo { get; set; }

        /// <summary>
        /// Gets the action key of current request.
        /// </summary>
        public string ActionKey
        {
            get
            {
                if (string.IsNullOrWhiteSpace(this.actionKey))
                {
                    if (this.ExecutedContext == null 
                        || this.ExecutedContext.RouteData == null
                        || this.ExecutedContext.RouteData.Values == null)
                    {
                        return null;
                    }

                    var controller = this.ExecutedContext.RouteData.Values["controller"];
                    var action = this.ExecutedContext.RouteData.Values["action"];

                    if (controller == null || action == null)
                    {
                        return null;
                    }

                    this.actionKey = (controller + "." + action).ToLower();
                }

                return this.actionKey;
            }
        }
    }
}