namespace Newegg.Flash.WWW.BizPolicy.Core
{
	public static class MoneyCalculator
	{
		public static decimal CalculateWithRound(decimal money)
		{
			return new MoneyCalculateWithRound().Calculate(money);
		}

		public static decimal CaculatorWithoutRound(decimal money)
		{
			return new MoneyCalculateWithoutRound().Calculate(money);
		}
		public static decimal ConvertCA2US(decimal money)
		{
			return new MoneyConverter().Calculate(money);
		}
	}
}
