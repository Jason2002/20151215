﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;

namespace Newegg.Flash.WWW.BizPolicy.Core
{
    public enum BizUnitType
    {
        [XmlEnum("USA")]
        [Description("USA")]
        B2C_USA = 0,
        [XmlEnum("CAN")]
        [Description("CAN")]
        B2C_CAN = 1,
        [XmlEnum("B2B")]
        [Description("B2B")]
        B2B_USA = 2
    }
}