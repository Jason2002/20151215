/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Jason Huang (jason.j.huang@newegg.com)
 * Create Date:  07/15/2008 14:18:12
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using Newegg.Framework.Utility;

namespace Newegg.Flash.WWW.BizPolicy.Core
{
	public class MoneyCalculateWithoutRound : IMoneyCalculator
	{
		public decimal Calculate(decimal money)
		{
			if (BizThreadContext.IsCANRequest)
			{
				decimal res = money * BizThreadContext.CurrencyExchangeRate;
				decimal suffix = res - decimal.ToInt32(res);
				if (suffix < 0.5m)
				{
					return decimal.ToInt32(res) + 0.59m;
				}
				else if (suffix > 0.5m)
				{
					return decimal.ToInt32(res) + 0.99m;
				}
				return res;
			}
			return money;
		}
	}
}
