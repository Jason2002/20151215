using Newegg.Framework.Utility;

namespace Newegg.Flash.WWW.BizPolicy.Core
{
	public class MoneyConverter: IMoneyCalculator
	{
		public decimal Calculate(decimal money)
		{
			if (BizThreadContext.IsCANRequest)
			{
				return decimal.Round(money / BizThreadContext.CurrencyExchangeRate, 2);
			}
			return decimal.Round(money, 2);
		}
	}
}