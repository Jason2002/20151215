﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Neil Chen (neil.j.chen@newegg.com)
 * Create Date:  05/06/2009 17:34:40
 * Usage:
 *
 * RevisionHistory
 * Date         Author               Description
 * 
*****************************************************************/
using System.Linq;
using System.Data;
using System.Collections.Generic;
using System.Xml.Serialization;
using Newegg.Framework.Collection;
using Newegg.Framework.Utility; 
using Newegg.Framework.XmlAccess; 

using Newegg.Framework.Entity;

namespace Newegg.Flash.WWW.BizPolicy.Core
{
    public class BizUnitInfo
    {
        private const string DEFALUT_LANGUAGENAME = "en-US";

        #region fields
        private BizUnitType m_Name;
        private string m_CountryCode;
        private int m_CompanyCode;
        private string m_CurrencyCode;
        private string m_LanguageName;
        private string m_NameDescription;
        private LanguageCodes m_LanguageCodes;
        #endregion

        #region property
        [XmlAttribute("name")]
        public BizUnitType Name
        {
            get { return m_Name; }
            set
            {
                m_Name = value;
                m_NameDescription = EnumHelper.GetEnumValueDescription<BizUnitType>(m_Name);
            }
        }

        [XmlAttribute("countryCode")]
        public string CountryCode
        {
            get { return m_CountryCode; }
            set { m_CountryCode = value; }
        }

        [XmlAttribute("companyCode")]
        public int CompanyCode
        {
            get { return m_CompanyCode; }
            set { m_CompanyCode = value; }
        }

        [XmlAttribute("currencyCode")]
        public string CurrencyCode
        {
            get { return m_CurrencyCode; }
            set { m_CurrencyCode = value; }
        }

        /// <summary>
        /// the language name for this biz unit.
        /// like:en-US,es-ES
        /// this value come from config file:
        /// BizUnitPolicy.config
        /// </summary>
        public string LanguageName
        {
            get { return string.IsNullOrWhiteSpace(m_LanguageName) ? DEFALUT_LANGUAGENAME : m_LanguageName; }
            set { m_LanguageName = value; }
        }

        public string NameDescription
        {
            get
            {
                return m_NameDescription;
                //                return RuntimeConfig.BizUnitConfig.BizUnitTypeDictionary[Name];
            }
        }

        [XmlElement("languages")]
        public LanguageCodes LanguageCodes
        {
            get { return m_LanguageCodes; }
            set { m_LanguageCodes = value; }
        }

        /// <summary>
        /// Gets or sets RegionCollection.
        /// </summary>
        [XmlElement("regions")]
        public RegionCollection RegionCollection { get; set; }
        #endregion
    }

    public class LanguageCodes
    {
        private List<string> m_LanguageCodeList;

        [XmlElement("languageCode")]
        public List<string> LanuageCodeList
        {
            get { return m_LanguageCodeList; }
            set { m_LanguageCodeList = value; }
        }
    }

    /// <summary>
    /// RegionCollection class.
    /// </summary>
    public class RegionCollection
    {
        /// <summary>
        /// Gets or sets Regions.
        /// </summary>
        [XmlElement("regionCode")]
        public KeyedObjectCollection<string, RegionCode> Regions { get; set; }
    }

    /// <summary>
    /// RegionCode class.
    /// </summary>
    public class RegionCode : IKeyedObject<string>
    {
        private const string XML_COUNTRY_CURRENCY_DETAIL_INFO = "CountryCurrencyDetailInfo.xml";

        private string twoLetterCode;
        private string displayShortCode;
        /// <summary>
        /// Gets or sets Code.
        /// </summary>
        [XmlAttribute("code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [XmlAttribute("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets IsDefault.
        /// </summary>
        [XmlAttribute("isDefault")]
        public bool IsDefault { get; set; }

        /// <summary>
        /// Gets or sets timeZone.
        /// </summary>
        [XmlAttribute("timeZone")]
        public string TimeZone
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets two letter region code.
        /// </summary>
        [XmlAttribute("twoLetterCode")]
        public string TwoLetterCode
        {
            get { return twoLetterCode; }
            set { twoLetterCode = value; }
        }

        /// <summary>
        /// Gets or sets two letter region code.
        /// </summary>
        [XmlAttribute("displayShortCode")]
        public string DisplayShortCode
        {
            get
            {
                if (string.IsNullOrWhiteSpace(displayShortCode))
                {
                    return twoLetterCode;
                }
                else
                {
                    return displayShortCode;
                }
            }
            set
            {
                displayShortCode = value;
            }
        }

        private List<Currency> currencies;


        /// <summary>
        /// Gets or sets Currencys.
        /// </summary>
        [XmlIgnore]
        public List<Currency> Currencys
        {
            get
            {
                if (currencies != null)
                {
                    return currencies;
                }
                ILookup<string, Currency> allDetail = XmlDataManager.GetEntityLookup<string, Currency>(
                    XML_COUNTRY_CURRENCY_DETAIL_INFO,
                    KeySelectorName.COUNTRY_CODE.ToString(),
                    c => c.CountryCode);

                List<Currency> lstResult = allDetail != null
                                           && allDetail.Contains(this.Code)
                                           && allDetail[this.Code].ToList<Currency>().Exists(tt => tt.Status == "A")
                                               ? allDetail[this.Code].OrderBy(c => c.ListPriority).ToList()
                                               : new List<Currency>
                                                   {
                                                       new Currency
                                                           {
                                                               CountryCode = this.Code,
                                                               CompanyCode = 1003,
                                                               Code = ThreadContext.IsCANRequest ? "CAD" : "USD", //Follow Crazy Egg Phase I logic
                                                               InternalIsLocalCurrency = "Y",
                                                               CurrencyName = ThreadContext.IsCANRequest ? "Canadian Dollar" : "US Dollar",
                                                               ExtraUnit = string.Empty,
                                                               Unit = "$",
                                                               DecimalDigits = 2,
                                                               DecimalSeparator = ".",
                                                               GroupSizes = 3,
                                                               GroupSeparator = ",",
                                                               PositivePattern = 0,
                                                               Status = "A"
                                                           }
                                                   };
                currencies = lstResult.FindAll(t => t.Status == "A");
                return currencies;
            }
        }

        public string Key
        {
            get { return Code; }
        }
    }

    /// <summary>
    /// Currency class.
    /// This class combine currency info and country info
    /// Cause they are cached, so this cannot be split into 2 modals
    /// </summary>
    public class Currency
    {
        /// <summary>
        /// Gets or sets CountryCode.
        /// </summary>
        [DataMapping("CountryCode", DbType.String)]
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets CompanyCode.
        /// </summary>
        [DataMapping("CompanyCode", DbType.Int32)]
        public int CompanyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode.
        /// </summary>
        [DataMapping("CurrencyCode", DbType.String)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets IsDefault.
        /// Have to set the "get" function to be public, otherwise the XmlSerializer will throw an exception on reflecting. 
        /// </summary>
        [DataMapping("IsDefault", DbType.String)]
        public string InternalIsLocalCurrency
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets IsLocalCurrency.
        /// Have to add "set" to serialize to js config.
        /// </summary>
        public bool IsLocalCurrency
        {
            get { return !string.IsNullOrWhiteSpace(InternalIsLocalCurrency) && InternalIsLocalCurrency.Equals("Y"); }
            set { InternalIsLocalCurrency = value ? "Y" : "N"; }
        }

        /// <summary>
        /// Gets or sets CurrencyName.
        /// </summary>
        [DataMapping("CurrencyName", DbType.String)]
        public string CurrencyName { get; set; }

        /// <summary>
        /// Gets or sets ExtraUnit.
        /// </summary>
        [DataMapping("ExtraUnit", DbType.String)]
        public string ExtraUnit { get; set; }

        /// <summary>
        /// Gets or sets Unit.
        /// </summary>
        [DataMapping("Symbol", DbType.String)]
        public string Unit { get; set; }

        /// <summary>
        /// Gets or sets DecimalDigits.
        /// </summary>
        [DataMapping("DecimalDigits", DbType.Int32)]
        public int DecimalDigits { get; set; }

        /// <summary>
        /// Gets or sets DecimalSeparator.
        /// </summary>
        [DataMapping("DecimalSeparator", DbType.String)]
        public string DecimalSeparator { get; set; }

        /// <summary>
        /// Gets or sets GroupSizes.
        /// </summary>
        [DataMapping("GroupSizes", DbType.Int32)]
        public int GroupSizes { get; set; }

        /// <summary>
        /// Gets or sets GroupSeparator.
        /// </summary>
        [DataMapping("GroupSeparator", DbType.String)]
        public string GroupSeparator { get; set; }

        /// <summary>
        /// Gets or sets PositivePattern.
        /// </summary>
        [DataMapping("PositivePattern", DbType.Int32)]
        public int PositivePattern { get; set; }

        /// <summary>
        /// Gets or sets ListPriority.
        /// </summary>
        [DataMapping("ListPriority", DbType.Int32)]
        public int ListPriority { get; set; }

        /// <summary>
        /// Gets or sets GroupSeparator.
        /// </summary>
        [DataMapping("Status", DbType.String)]
        public string Status { get; set; }
    }
     public enum KeySelectorName
     {
         COUNTRY_CODE
     }

}
