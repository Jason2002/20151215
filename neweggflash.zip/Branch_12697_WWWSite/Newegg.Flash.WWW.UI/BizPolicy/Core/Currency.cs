﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Newegg.Flash.WWW.UI.BizPolicy.Core
{
    /// <summary>
    /// Currency class.
    /// This class combine currency info and country info
    /// Cause they are cached, so this cannot be split into 2 modals
    /// </summary>
    public class Currency
    {
        /// <summary>
        /// Gets or sets CountryCode.
        /// </summary>
        [DataMapping("CountryCode", DbType.String)]
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets CompanyCode.
        /// </summary>
        [DataMapping("CompanyCode", DbType.Int32)]
        public int CompanyCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode.
        /// </summary>
        [DataMapping("CurrencyCode", DbType.String)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets IsDefault.
        /// Have to set the "get" function to be public, otherwise the XmlSerializer will throw an exception on reflecting. 
        /// </summary>
        [DataMapping("IsDefault", DbType.String)]
        public string InternalIsLocalCurrency
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets IsLocalCurrency.
        /// Have to add "set" to serialize to js config.
        /// </summary>
        public bool IsLocalCurrency
        {
            get { return !string.IsNullOrWhiteSpace(InternalIsLocalCurrency) && InternalIsLocalCurrency.Equals("Y"); }
            set { InternalIsLocalCurrency = value ? "Y" : "N"; }
        }

        /// <summary>
        /// Gets or sets CurrencyName.
        /// </summary>
        [DataMapping("CurrencyName", DbType.String)]
        public string CurrencyName { get; set; }

        /// <summary>
        /// Gets or sets ExtraUnit.
        /// </summary>
        [DataMapping("ExtraUnit", DbType.String)]
        public string ExtraUnit { get; set; }

        /// <summary>
        /// Gets or sets Unit.
        /// </summary>
        [DataMapping("Symbol", DbType.String)]
        public string Unit { get; set; }

        /// <summary>
        /// Gets or sets DecimalDigits.
        /// </summary>
        [DataMapping("DecimalDigits", DbType.Int32)]
        public int DecimalDigits { get; set; }

        /// <summary>
        /// Gets or sets DecimalSeparator.
        /// </summary>
        [DataMapping("DecimalSeparator", DbType.String)]
        public string DecimalSeparator { get; set; }

        /// <summary>
        /// Gets or sets GroupSizes.
        /// </summary>
        [DataMapping("GroupSizes", DbType.Int32)]
        public int GroupSizes { get; set; }

        /// <summary>
        /// Gets or sets GroupSeparator.
        /// </summary>
        [DataMapping("GroupSeparator", DbType.String)]
        public string GroupSeparator { get; set; }

        /// <summary>
        /// Gets or sets PositivePattern.
        /// </summary>
        [DataMapping("PositivePattern", DbType.Int32)]
        public int PositivePattern { get; set; }

        /// <summary>
        /// Gets or sets ListPriority.
        /// </summary>
        [DataMapping("ListPriority", DbType.Int32)]
        public int ListPriority { get; set; }

        /// <summary>
        /// Gets or sets GroupSeparator.
        /// </summary>
        [DataMapping("Status", DbType.String)]
        public string Status { get; set; }
    }
}