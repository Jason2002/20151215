﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newegg.Flash.WWW.Common.Configuration;

namespace Newegg.Flash.WWW.BizPolicy.Core
{
    [EC.IOC.AutoSetupService(typeof(ICfgRoleFilter))]
    public class CfgRoleFilter : ICfgRoleFilter
    {
        public List<T> Filter<T>(IEnumerable<T> lst, Func<T, String> getRoles,bool nullIsAll) where T:class
        {
            if (lst == null) return null;

            List<T> result=new List<T>(lst.Count());
            foreach (T item in lst)
            {
                String roles = getRoles(item);
                if (nullIsAll && String.IsNullOrEmpty(roles))
                    result.Insert(0, item); //保持在first
                else
                {

                    String curRegionCode = BizThreadContext.RegionCode.Code;
                    bool isFind = Regex.IsMatch(roles, String.Format(@"\b{0}\b", curRegionCode),
                        RegexOptions.IgnoreCase);
                    if (isFind)
                        result.Add(item);

                }
            }
            return result;
        }


        public T FilterSingle<T>(IEnumerable<T> lst, Func<T, string> getRoles, bool nullIsAll, bool nullIsDefault = true) where T : class
        {
            var result = Filter(lst, getRoles, nullIsAll);
            if (result == null || result.Count == 0)
            {
                if (nullIsDefault)
                {
                    return default(T);
                }
                else
                {
                    return null;
                }
            }
            return result.Count > 1 ? result[1] : result[0];
            
        }
    }
}
