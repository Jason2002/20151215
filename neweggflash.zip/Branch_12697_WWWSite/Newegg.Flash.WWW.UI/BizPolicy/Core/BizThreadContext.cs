﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Jason Huang (jason.j.huang@newegg.com)
 * Create Date:  08/11/2008 09:17:03
 * Usage:
 *
 * RevisionHistory
 * Date         Author               Description
 * 
*****************************************************************/
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Globalization;
using System.Web;

using Newegg.Framework.Threading; 
using Newegg.Framework.Utility;
using Newegg.Framework.Globalization;
using Newegg.Flash.WWW.BizPolicy.Core;
using Newegg.EC.BizUnit;
using System.Collections; 
using Newegg.Framework.XmlAccess;
using System.Linq;
using Newegg.EC;
using Newegg.EC.Net.Http;
using Newegg.Flash.WWW.Interface;
using Newegg.Flash.WWW.Model;

namespace Newegg.Flash.WWW
{
    public class BizThreadContext
    { 
        public const string THREADSTORAGE_KEY_REGIONCODEVALUE = "ThreadStorage_Key_RegionCodeValue";
        public const string THREADSTORAGE_KEY_BIZCONTEXTVALUE = "ThreadStorage_Key_BizContextValue";
        public const string THREADSTORAGE_KEY_BIZUNITALUE = "ThreadStorage_Key_BizUnitValue";
        public const string THREADSTORAGE_KEY_CURRENCYCODEVALUE = "ThreadStorage_Key_CurrencyCodeValue";
        public const string THREADSTORAGE_KEY_BIZUNIT_INFO = "ThreadStorage_Key_BIZUNIT_INFO";
        private const string XML_COUNTRY_CURRENCY_DETAIL_INFO = "CountryCurrencyDetailInfo.xml";
        private static List<CountryCurrencyDetail> currencies; 

        public static bool IsCANRequest
        {
            get
            {
                return CurrentBizUnitType == "CAN";
            }
        }

        public static bool IsGlobalRequest
        {
            get
            {
                return IsUSARequest && RegionCode.Code != "USA";
            }
        }

        public static bool IsUSARequest
        {
            get
            {
                return CurrentBizUnitType == "USA";
            }
        }
          
        public static IBizUnit BizUnitInfo
        {
            get 
            {
                return LogicalThreadContext.GetData(THREADSTORAGE_KEY_BIZUNITALUE) as IBizUnit;
            }
            set
            {
                LogicalThreadContext.SetData(THREADSTORAGE_KEY_BIZUNITALUE, value);
            }
        }

        public static string CurrentBizUnitType
        {
            get
            {
                if (BizUnitInfo == null)
                {
                    return "USA";
                }
                return BizUnitInfo.Name;
            }
        }

        private static string CurrentLanguageName
        {
            get
            {
                CultureInfo culture =
                    LogicalThreadContext.GetData(StringResource.ThreadStorage_Key_Language) as CultureInfo ??
                    CultureInfo.InvariantCulture;
                return culture.Name;
            }
        }

        /// <summary>
        /// current language code.like:es,en
        /// </summary>
        public static string CurrentLanguageCode
        {
            get
            {
                return ResourceProfile.CurrentLanguageCode;
            }
        }

        /// <summary>
        /// indicate the current language is english?
        /// </summary>
        public static bool IsEnglishLanguage
        {
            get
            {
                return ResourceProfile.IsEnglishLanguage;
            }
        }
          
        /// <summary>
        /// The user selector region is Default Region.
        /// </summary>
        public static bool IsDefaultRegion
        {
            get
            {
                return RegionCode == null || RegionCode.IsDefault;
            }
        }
         
        /// <summary>
        /// Gets the CurrentRegion.
        /// </summary>
        public static IRegionCode RegionCode
        {
            get
            {
               var regionCode = "USA";
                var code =LogicalThreadContext.GetData(THREADSTORAGE_KEY_REGIONCODEVALUE);
                if (code != null)
                {
                    regionCode = code.ToString().Trim();
                }
                return BizUnitInfo.Regions.Where(x => regionCode.Equals(x.Code.Trim())).FirstOrDefault();
            }
        }

        /// <summary>
        /// Gets the CurrencyCode.
        /// </summary>
        public static string CurrentCurrencyCode
        {
            get
            {
                var currency = LogicalThreadContext.GetData(THREADSTORAGE_KEY_CURRENCYCODEVALUE);
                return currency != null ? currency.ToString() : StringResource.ThreadStorage_Value_CurrencyCode_Default;
            }
        }

        public static decimal CurrencyExchangeRate
        {
            get
            {
                var rate = LogicalThreadContext.GetData(StringResource.ThreadStorage_Key_CurrencyExchangeRate);
                if (rate == null)
                {
                   var changeRate = BizContextData.CurrencyExchangeRates.Where(x => x.FromCurrencyCode == CurrentCurrencyCode &&
                        x.ToCurrencyCode == StringResource.ThreadStorage_Value_CurrencyCode_Default).FirstOrDefault();
                   rate = 1;
                   if (changeRate != null)
                   {
                       rate = changeRate.ExchangeRate;
                   }
                   LogicalThreadContext.SetData(StringResource.ThreadStorage_Key_CurrencyExchangeRate, rate);
                } 
                return (decimal)rate;
            }
        }
         
        private static BizContext BizContextData
        {
            get
            {
                var _BizContext = (BizContext)LogicalThreadContext.GetData(THREADSTORAGE_KEY_BIZCONTEXTVALUE);
                if (_BizContext == null)
                {
                    var HomeProcesser = ECLibraryContainer.Current.GetInstance<IHome>();
                    _BizContext = HomeProcesser.BizContextData();
                    LogicalThreadContext.SetData(THREADSTORAGE_KEY_BIZCONTEXTVALUE, _BizContext);
                }

                return _BizContext;
            }
        } 

        public static List<CountryCurrencyDetail> Currencys
        {
            get
            {
                //if (currencies != null)
                //{
                //    return currencies;
                //}
                var lstResult = BizContextData.CountryCurrencyDetails
                                .Where(x => "A".Equals(x.Status))
                                .OrderBy(x => x.ListPriority).ToList();

                if (lstResult.Count() == 0)
                {
                    lstResult.Add(
                        new CountryCurrencyDetail
                        {
                            CountryCode = RegionCode.Code,
                            CompanyCode = 1003,
                            CurrencyCode = BizThreadContext.IsCANRequest ? "CAD" : "USD", //Follow Crazy Egg Phase I logic
                            //InternalIsLocalCurrency = "Y",
                            CurrencyName = BizThreadContext.IsCANRequest ? "Canadian Dollar" : "US Dollar",
                            ExtraUnit = string.Empty,
                            Symbol = "$",
                            DecimalDigits = 2,
                            DecimalSeparator = ".",
                            GroupSizes = 3,
                            GroupSeparator = ",",
                            PositivePattern = 0,
                            Status = "A"
                        });
                }
                currencies = lstResult;
                return currencies;
            }
        }

        /// <summary>
        /// Gets current Currency.
        /// </summary>
        public static CountryCurrencyDetail CurrentCurrencyInfo
        {
            get
            {
                var currency = Currencys.Where(x=>x.CurrencyCode.ToString().Trim().Equals(CurrentCurrencyCode.ToString())
                                                && x.CountryCode.Trim().ToString().Equals(RegionCode.Code)).FirstOrDefault();
                if (null == currency || string.IsNullOrEmpty(currency.CurrencyCode))
                {
                    currency = DefaultCurrency;
                }
                return currency;
            }
        }

        public static TimeZoneInfo CurrentTimeZone
        {
            get
            {
                var curTimeInfo = TimeZoneInfo.GetSystemTimeZones().First(x => x.Id == RegionCode.TimeZone);
                return curTimeInfo ?? TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time");
            }
        }
        private static readonly CountryCurrencyDetail DefaultCurrency = new CountryCurrencyDetail
        {
            CountryCode = "",
            CompanyCode = 1003,
            CurrencyCode = BizThreadContext.IsCANRequest ? "CAD" : "USD",
            IsDefault = "Y",
            CurrencyName = BizThreadContext.IsCANRequest ? "Canadian Dollar" : "US Dollar",
            ExtraUnit = string.Empty,
            Symbol = "$",
            DecimalDigits = 2,
            DecimalSeparator = ".",
            GroupSizes = 3,
            GroupSeparator = ",",
            PositivePattern = 0,
        };
    }
}
