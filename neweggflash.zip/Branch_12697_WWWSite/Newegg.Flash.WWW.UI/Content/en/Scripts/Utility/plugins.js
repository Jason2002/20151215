﻿NEG.Module("Utility.Plugins", function (require) {
    var jQuery = require("Utility.JQuery");
    window.jQuery = jQuery;

/*
    * Swiper 2.5.5
    * Mobile touch slider and framework with hardware accelerated transitions
    *
    * http://www.idangero.us/sliders/swiper/
    *
    * Copyright 2010-2014, Vladimir Kharlampidi
    * The iDangero.us
    * http://www.idangero.us/
    *
    * Licensed under GPL & MIT 
    *
    * Released on: March 23, 2014
*/
window.Swiper=function(f,b){function h(a,b){return document.querySelectorAll?(b||document).querySelectorAll(a):jQuery(a,b)}function g(){var c=B-l;b.freeMode&&(c=B-l);b.slidesPerView>a.slides.length&&!b.centeredSlides&&(c=0);0>c&&(c=0);return c}function k(){function c(c){var d=new Image;d.onload=function(){a&&void 0!==a.imagesLoaded&&a.imagesLoaded++;a.imagesLoaded===a.imagesToLoad.length&&(a.reInit(),b.onImagesReady&&a.fireCallback(b.onImagesReady,a))};d.src=c}var d=a.h.addEventListener,e="wrapper"===
b.eventTarget?a.wrapper:a.container;a.browser.ie10||a.browser.ie11?(d(e,a.touchEvents.touchStart,C),b.fixPerView||(d(document,a.touchEvents.touchMove,D),d(document,a.touchEvents.touchEnd,E))):(a.support.touch&&(d(e,"touchstart",C),d(e,"touchmove",D),d(e,"touchend",E)),b.simulateTouch&&(d(e,"mousedown",C),b.fixPerView||(d(document,"mousemove",D),d(document,"mouseup",E))));b.autoResize&&d(window,"resize",a.resizeFix);v();a._wheelEvent=!1;if(b.mousewheelControl){void 0!==document.onmousewheel&&(a._wheelEvent=
"mousewheel");if(!a._wheelEvent)try{new WheelEvent("wheel"),a._wheelEvent="wheel"}catch(n){}a._wheelEvent||(a._wheelEvent="DOMMouseScroll");a._wheelEvent&&d(a.container,a._wheelEvent,Q)}b.keyboardControl&&(b.fixPerView||d(document,"keydown",I));if(b.updateOnImagesReady)for(a.imagesToLoad=h("img",a.container),d=0;d<a.imagesToLoad.length;d++)c(a.imagesToLoad[d].getAttribute("src"))}function v(){var c=a.h.addEventListener,d;if(b.preventLinks){var e=h("a",a.container);for(d=0;d<e.length;d++)c(e[d],"click",
R)}if(b.releaseFormElements)for(e=h("input, textarea, select",a.container),d=0;d<e.length;d++)c(e[d],a.touchEvents.touchStart,S,!0);if(b.onSlideClick)for(d=0;d<a.slides.length;d++)c(a.slides[d],"click",T);if(b.onSlideTouch)for(d=0;d<a.slides.length;d++)c(a.slides[d],a.touchEvents.touchStart,U)}function r(){var c=a.h.removeEventListener,d;if(b.onSlideClick)for(d=0;d<a.slides.length;d++)c(a.slides[d],"click",T);if(b.onSlideTouch)for(d=0;d<a.slides.length;d++)c(a.slides[d],a.touchEvents.touchStart,U);
if(b.releaseFormElements){var e=h("input, textarea, select",a.container);for(d=0;d<e.length;d++)c(e[d],a.touchEvents.touchStart,S,!0)}if(b.preventLinks)for(e=h("a",a.container),d=0;d<e.length;d++)c(e[d],"click",R)}function I(c){var b=c.keyCode||c.charCode;if(!(c.shiftKey||c.altKey||c.ctrlKey||c.metaKey)){if(37===b||39===b||38===b||40===b){for(var e=!1,n=a.h.getOffset(a.container),f=a.h.windowScroll().left,g=a.h.windowScroll().top,x=a.h.windowWidth(),h=a.h.windowHeight(),n=[[n.left,n.top],[n.left+
a.width,n.top],[n.left,n.top+a.height],[n.left+a.width,n.top+a.height]],k=0;k<n.length;k++){var l=n[k];l[0]>=f&&l[0]<=f+x&&l[1]>=g&&l[1]<=g+h&&(e=!0)}if(!e)return}if(m){if(37===b||39===b)c.preventDefault?c.preventDefault():c.returnValue=!1;39===b&&a.swipeNext();37===b&&a.swipePrev()}else{if(38===b||40===b)c.preventDefault?c.preventDefault():c.returnValue=!1;40===b&&a.swipeNext();38===b&&a.swipePrev()}}}function Q(c){var d=a._wheelEvent,e=0;if(c.detail)e=-c.detail;else if("mousewheel"===d)if(b.mousewheelControlForceToAxis)if(m)if(Math.abs(c.wheelDeltaX)>
Math.abs(c.wheelDeltaY))e=c.wheelDeltaX;else return;else if(Math.abs(c.wheelDeltaY)>Math.abs(c.wheelDeltaX))e=c.wheelDeltaY;else return;else e=c.wheelDelta;else if("DOMMouseScroll"===d)e=-c.detail;else if("wheel"===d)if(b.mousewheelControlForceToAxis)if(m)if(Math.abs(c.deltaX)>Math.abs(c.deltaY))e=-c.deltaX;else return;else if(Math.abs(c.deltaY)>Math.abs(c.deltaX))e=-c.deltaY;else return;else e=Math.abs(c.deltaX)>Math.abs(c.deltaY)?-c.deltaX:-c.deltaY;if(b.freeMode){if(d=a.getWrapperTranslate()+e,
0<d&&(d=0),d<-g()&&(d=-g()),a.setWrapperTransition(0),a.setWrapperTranslate(d),a.updateActiveSlide(d),0===d||d===-g())return}else 60<(new Date).getTime()-V&&(0>e?a.swipeNext():a.swipePrev()),V=(new Date).getTime();b.autoplay&&a.stopAutoplay(!0);c.preventDefault?c.preventDefault():c.returnValue=!1;return!1}function T(c){a.allowSlideClick&&(W(c),a.fireCallback(b.onSlideClick,a,c))}function U(c){W(c);a.fireCallback(b.onSlideTouch,a,c)}function W(c){if(c.currentTarget)a.clickedSlide=c.currentTarget;else{c=
c.srcElement;do{if(-1<c.className.indexOf(b.slideClass))break;c=c.parentNode}while(c);a.clickedSlide=c}a.clickedSlideIndex=a.slides.indexOf(a.clickedSlide);a.clickedSlideLoopIndex=a.clickedSlideIndex-(a.loopedSlides||0)}function R(c){if(!a.allowLinks)return c.preventDefault?c.preventDefault():c.returnValue=!1,b.preventLinksPropagation&&"stopPropagation"in c&&c.stopPropagation(),!1}function S(a){a.stopPropagation?a.stopPropagation():a.returnValue=!1;return!1}function C(c){b.preventLinks&&(a.allowLinks=
!0);if(a.isTouched||b.onlyExternal)return!1;var d;if(d=b.noSwiping)if(d=c.target||c.srcElement){d=c.target||c.srcElement;var e=!1;do-1<d.className.indexOf(b.noSwipingClass)&&(e=!0),d=d.parentElement;while(!e&&d.parentElement&&-1===d.className.indexOf(b.wrapperClass));!e&&-1<d.className.indexOf(b.wrapperClass)&&-1<d.className.indexOf(b.noSwipingClass)&&(e=!0);d=e}if(d)return!1;J=!1;a.isTouched=!0;y="touchstart"===c.type;y&&1!==c.targetTouches.length||(a.callPlugins("onTouchStartBegin"),y||a.isAndroid||
(c.preventDefault?c.preventDefault():c.returnValue=!1),d=y?c.targetTouches[0].pageX:c.pageX||c.clientX,c=y?c.targetTouches[0].pageY:c.pageY||c.clientY,a.touches.startX=a.touches.currentX=d,a.touches.startY=a.touches.currentY=c,a.touches.start=a.touches.current=m?d:c,a.setWrapperTransition(0),a.positions.start=a.positions.current=a.getWrapperTranslate(),a.setWrapperTranslate(a.positions.start),a.times.start=(new Date).getTime(),z=void 0,0<b.moveStartThreshold&&(K=!1),b.onTouchStart&&a.fireCallback(b.onTouchStart,
a),a.callPlugins("onTouchStartEnd"))}function D(c){if(a.isTouched&&!b.onlyExternal&&(!y||"mousemove"!==c.type)){var d=y?c.targetTouches[0].pageX:c.pageX||c.clientX,e=y?c.targetTouches[0].pageY:c.pageY||c.clientY;"undefined"===typeof z&&m&&(z=!!(z||Math.abs(e-a.touches.startY)>Math.abs(d-a.touches.startX)));"undefined"!==typeof z||m||(z=!!(z||Math.abs(e-a.touches.startY)<Math.abs(d-a.touches.startX)));if(z)a.isTouched=!1;else if(c.assignedToSwiper)a.isTouched=!1;else if(c.assignedToSwiper=!0,b.preventLinks&&
(a.allowLinks=!1),b.onSlideClick&&(a.allowSlideClick=!1),b.autoplay&&a.stopAutoplay(!0),!y||1===c.touches.length)if(a.isMoved||(a.callPlugins("onTouchMoveStart"),b.loop&&(a.fixLoop(),a.positions.start=a.getWrapperTranslate()),b.onTouchMoveStart&&a.fireCallback(b.onTouchMoveStart,a)),a.isMoved=!0,c.preventDefault?c.preventDefault():c.returnValue=!1,a.touches.current=m?d:e,a.positions.current=(a.touches.current-a.touches.start)*b.touchRatio+a.positions.start,0<a.positions.current&&b.onResistanceBefore&&
a.fireCallback(b.onResistanceBefore,a,a.positions.current),a.positions.current<-g()&&b.onResistanceAfter&&a.fireCallback(b.onResistanceAfter,a,Math.abs(a.positions.current+g())),b.resistance&&"100%"!==b.resistance&&(0<a.positions.current&&(c=1-a.positions.current/l/2,a.positions.current=0.5>c?l/2:a.positions.current*c),a.positions.current<-g()&&(d=(a.touches.current-a.touches.start)*b.touchRatio+(g()+a.positions.start),c=(l+d)/l,d=a.positions.current-d*(1-c)/2,e=-g()-l/2,a.positions.current=d<e||
0>=c?e:d)),b.resistance&&"100%"===b.resistance&&(0<a.positions.current&&(!b.freeMode||b.freeModeFluid)&&(a.positions.current=0),a.positions.current<-g()&&(!b.freeMode||b.freeModeFluid)&&(a.positions.current=-g())),b.followFinger){if(b.moveStartThreshold)if(Math.abs(a.touches.current-a.touches.start)>b.moveStartThreshold||K){if(!K){K=!0;a.touches.start=a.touches.current;return}a.setWrapperTranslate(a.positions.current)}else a.positions.current=a.positions.start;else a.setWrapperTranslate(a.positions.current);
(b.freeMode||b.watchActiveIndex)&&a.updateActiveSlide(a.positions.current);b.grabCursor&&(a.container.style.cursor="move",a.container.style.cursor="grabbing",a.container.style.cursor="-moz-grabbin",a.container.style.cursor="-webkit-grabbing");G||(G=a.touches.current);L||(L=(new Date).getTime());a.velocity=(a.touches.current-G)/((new Date).getTime()-L)/2;2>Math.abs(a.touches.current-G)&&(a.velocity=0);G=a.touches.current;L=(new Date).getTime();a.callPlugins("onTouchMoveEnd");b.onTouchMove&&a.fireCallback(b.onTouchMove,
a);return!1}}}function E(c){z&&a.swipeReset();if(!b.onlyExternal&&a.isTouched){a.isTouched=!1;b.grabCursor&&(a.container.style.cursor="move",a.container.style.cursor="grab",a.container.style.cursor="-moz-grab",a.container.style.cursor="-webkit-grab");a.positions.current||0===a.positions.current||(a.positions.current=a.positions.start);b.followFinger&&a.setWrapperTranslate(a.positions.current);a.times.end=(new Date).getTime();a.touches.diff=a.touches.current-a.touches.start;a.touches.abs=Math.abs(a.touches.diff);
a.positions.diff=a.positions.current-a.positions.start;a.positions.abs=Math.abs(a.positions.diff);var d=a.positions.diff,e=a.positions.abs;c=a.times.end-a.times.start;5>e&&300>c&&!1===a.allowLinks&&(b.freeMode||0===e||a.swipeReset(),b.preventLinks&&(a.allowLinks=!0),b.onSlideClick&&(a.allowSlideClick=!0));setTimeout(function(){b.preventLinks&&(a.allowLinks=!0);b.onSlideClick&&(a.allowSlideClick=!0)},100);var n=g();if(!a.isMoved&&b.freeMode)a.isMoved=!1;else if(!a.isMoved||0<a.positions.current||a.positions.current<
-n)a.swipeReset();else if(a.isMoved=!1,b.freeMode){if(b.freeModeFluid){var e=1E3*b.momentumRatio,d=a.positions.current+a.velocity*e,f=!1,h,x=20*Math.abs(a.velocity)*b.momentumBounceRatio;d<-n&&(b.momentumBounce&&a.support.transitions?(d+n<-x&&(d=-n-x),h=-n,J=f=!0):d=-n);0<d&&(b.momentumBounce&&a.support.transitions?(d>x&&(d=x),h=0,J=f=!0):d=0);0!==a.velocity&&(e=Math.abs((d-a.positions.current)/a.velocity));a.setWrapperTranslate(d);a.setWrapperTransition(e);b.momentumBounce&&f&&a.wrapperTransitionEnd(function(){J&&
(b.onMomentumBounce&&a.fireCallback(b.onMomentumBounce,a),a.callPlugins("onMomentumBounce"),a.setWrapperTranslate(h),a.setWrapperTransition(300))});a.updateActiveSlide(d)}(!b.freeModeFluid||300<=c)&&a.updateActiveSlide(a.positions.current)}else{H=0>d?"toNext":"toPrev";"toNext"===H&&300>=c&&(30>e||!b.shortSwipes?a.swipeReset():a.swipeNext(!0));"toPrev"===H&&300>=c&&(30>e||!b.shortSwipes?a.swipeReset():a.swipePrev(!0));n=0;if("auto"===b.slidesPerView){for(var d=Math.abs(a.getWrapperTranslate()),k=f=
0;k<a.slides.length;k++)if(x=m?a.slides[k].getWidth(!0,b.roundLengths):a.slides[k].getHeight(!0,b.roundLengths),f+=x,f>d){n=x;break}n>l&&(n=l)}else n=s*b.slidesPerView;"toNext"===H&&300<c&&(e>=n*b.longSwipesRatio?a.swipeNext(!0):a.swipeReset());"toPrev"===H&&300<c&&(e>=n*b.longSwipesRatio?a.swipePrev(!0):a.swipeReset())}b.onTouchEnd&&a.fireCallback(b.onTouchEnd,a);a.callPlugins("onTouchEnd")}}function X(a,b){var e=document.createElement("div");e.innerHTML=b;e=e.firstChild;e.className+=" "+a;return e.outerHTML}
function M(c,d,e){function n(){g+=k*(+new Date-h)/(1E3/60);(m="toNext"===l?g>c:g<c)?(a.setWrapperTranslate(Math.round(g)),a._DOMAnimating=!0,window.setTimeout(function(){n()},1E3/60)):(b.onSlideChangeEnd&&("to"===d?!0===e.runCallbacks&&a.fireCallback(b.onSlideChangeEnd,a):a.fireCallback(b.onSlideChangeEnd,a)),a.setWrapperTranslate(c),a._DOMAnimating=!1)}var f="to"===d&&0<=e.speed?e.speed:b.speed,h=+new Date;if(a.support.transitions||!b.DOMAnimation)a.setWrapperTranslate(c),a.setWrapperTransition(f);
else{var g=a.getWrapperTranslate(),k=Math.ceil((c-g)/f*(1E3/60)),l=g>c?"toNext":"toPrev",m="toNext"===l?g>c:g<c;if(a._DOMAnimating)return;n()}a.updateActiveSlide(c);b.onSlideNext&&"next"===d&&a.fireCallback(b.onSlideNext,a,c);b.onSlidePrev&&"prev"===d&&a.fireCallback(b.onSlidePrev,a,c);b.onSlideReset&&"reset"===d&&a.fireCallback(b.onSlideReset,a,c);("next"===d||"prev"===d||"to"===d&&!0===e.runCallbacks)&&$(d)}function $(c){a.callPlugins("onSlideChangeStart");if(b.onSlideChangeStart)if(b.queueStartCallbacks&&
a.support.transitions){if(a._queueStartCallbacks)return;a._queueStartCallbacks=!0;a.fireCallback(b.onSlideChangeStart,a,c);a.wrapperTransitionEnd(function(){a._queueStartCallbacks=!1})}else a.fireCallback(b.onSlideChangeStart,a,c);b.onSlideChangeEnd&&(a.support.transitions?b.queueEndCallbacks?a._queueEndCallbacks||(a._queueEndCallbacks=!0,a.wrapperTransitionEnd(function(d){a.fireCallback(b.onSlideChangeEnd,d,c)})):a.wrapperTransitionEnd(function(d){a.fireCallback(b.onSlideChangeEnd,d,c)}):b.DOMAnimation||
setTimeout(function(){a.fireCallback(b.onSlideChangeEnd,a,c)},10))}function Y(){var b=a.paginationButtons;if(b)for(var d=0;d<b.length;d++)a.h.removeEventListener(b[d],"click",Z)}function Z(b){var d;b=b.target||b.srcElement;for(var e=a.paginationButtons,f=0;f<e.length;f++)b===e[f]&&(d=f);a.swipeTo(d)}function P(){u=setTimeout(function(){b.loop?(a.fixLoop(),a.swipeNext(!0)):a.swipeNext(!0)||(b.autoplayStopOnLast?(clearTimeout(u),u=void 0):a.swipeTo(0));a.wrapperTransitionEnd(function(){"undefined"!==
typeof u&&P()})},b.autoplay)}if(document.body.__defineGetter__&&HTMLElement){var t=HTMLElement.prototype;t.__defineGetter__&&t.__defineGetter__("outerHTML",function(){return(new XMLSerializer).serializeToString(this)})}window.getComputedStyle||(window.getComputedStyle=function(a,b){this.el=a;this.getPropertyValue=function(b){var d=/(\-([a-z]){1})/g;"float"===b&&(b="styleFloat");d.test(b)&&(b=b.replace(d,function(a,b,c){return c.toUpperCase()}));return a.currentStyle[b]?a.currentStyle[b]:null};return this});
Array.prototype.indexOf||(Array.prototype.indexOf=function(a,b){for(var e=b||0,f=this.length;e<f;e++)if(this[e]===a)return e;return-1});if((document.querySelectorAll||window.jQuery)&&"undefined"!==typeof f&&(f.nodeType||0!==h(f).length)){var a=this;a.touches={start:0,startX:0,startY:0,current:0,currentX:0,currentY:0,diff:0,abs:0};a.positions={start:0,abs:0,diff:0,current:0};a.times={start:0,end:0};a.id=(new Date).getTime();a.container=f.nodeType?f:h(f)[0];a.isTouched=!1;a.isMoved=!1;a.activeIndex=
0;a.centerIndex=0;a.activeLoaderIndex=0;a.activeLoopIndex=0;a.previousIndex=null;a.velocity=0;a.snapGrid=[];a.slidesGrid=[];a.imagesToLoad=[];a.imagesLoaded=0;a.wrapperLeft=0;a.wrapperRight=0;a.wrapperTop=0;a.wrapperBottom=0;a.isAndroid=0<=navigator.userAgent.toLowerCase().indexOf("android");var N,s,B,H,z,l,t={eventTarget:"wrapper",mode:"horizontal",touchRatio:1,speed:300,freeMode:!1,freeModeFluid:!1,momentumRatio:1,momentumBounce:!0,momentumBounceRatio:1,slidesPerView:1,slidesPerGroup:1,slidesPerViewFit:!0,
simulateTouch:!0,followFinger:!0,shortSwipes:!0,longSwipesRatio:0.5,moveStartThreshold:!1,onlyExternal:!1,createPagination:!0,pagination:!1,paginationElement:"span",paginationClickable:!1,paginationAsRange:!0,resistance:!0,scrollContainer:!1,preventLinks:!0,preventLinksPropagation:!1,noSwiping:!1,noSwipingClass:"swiper-no-swiping",initialSlide:0,keyboardControl:!1,mousewheelControl:!1,mousewheelControlForceToAxis:!1,useCSS3Transforms:!0,autoplay:!1,autoplayDisableOnInteraction:!0,autoplayStopOnLast:!1,
loop:!1,loopAdditionalSlides:0,roundLengths:!1,calculateHeight:!1,cssWidthAndHeight:!1,updateOnImagesReady:!0,releaseFormElements:!0,watchActiveIndex:!1,visibilityFullFit:!1,offsetPxBefore:0,offsetPxAfter:0,offsetSlidesBefore:0,offsetSlidesAfter:0,centeredSlides:!1,queueStartCallbacks:!1,queueEndCallbacks:!1,autoResize:!0,resizeReInit:!1,DOMAnimation:!0,loader:{slides:[],slidesHTMLType:"inner",surroundGroups:1,logic:"reload",loadAllSlides:!1},slideElement:"div",slideClass:"swiper-slide",slideActiveClass:"swiper-slide-active",
slideVisibleClass:"swiper-slide-visible",slideDuplicateClass:"swiper-slide-duplicate",wrapperClass:"swiper-wrapper",paginationElementClass:"swiper-pagination-switch",paginationActiveClass:"swiper-active-switch",paginationVisibleClass:"swiper-visible-switch"};b=b||{};for(var p in t)if(p in b&&"object"===typeof b[p])for(var F in t[p])F in b[p]||(b[p][F]=t[p][F]);else p in b||(b[p]=t[p]);a.params=b;b.scrollContainer&&(b.freeMode=!0,b.freeModeFluid=!0);b.loop&&(b.resistance="100%");var m="horizontal"===
b.mode;p=["mousedown","mousemove","mouseup"];a.browser.ie10&&(p=["MSPointerDown","MSPointerMove","MSPointerUp"]);a.browser.ie11&&(p=["pointerdown","pointermove","pointerup"]);a.touchEvents={touchStart:a.support.touch||!b.simulateTouch?"touchstart":p[0],touchMove:a.support.touch||!b.simulateTouch?"touchmove":p[1],touchEnd:a.support.touch||!b.simulateTouch?"touchend":p[2]};for(p=a.container.childNodes.length-1;0<=p;p--)if(a.container.childNodes[p].className)for(F=a.container.childNodes[p].className.split(/\s+/),
t=0;t<F.length;t++)F[t]===b.wrapperClass&&(N=a.container.childNodes[p]);a.wrapper=N;a._extendSwiperSlide=function(c){c.append=function(){b.loop?c.insertAfter(a.slides.length-a.loopedSlides):(a.wrapper.appendChild(c),a.reInit());return c};c.prepend=function(){b.loop?(a.wrapper.insertBefore(c,a.slides[a.loopedSlides]),a.removeLoopedSlides(),a.calcSlides(),a.createLoop()):a.wrapper.insertBefore(c,a.wrapper.firstChild);a.reInit();return c};c.insertAfter=function(d){if("undefined"===typeof d)return!1;
b.loop?((d=a.slides[d+1+a.loopedSlides])?a.wrapper.insertBefore(c,d):a.wrapper.appendChild(c),a.removeLoopedSlides(),a.calcSlides(),a.createLoop()):(d=a.slides[d+1],a.wrapper.insertBefore(c,d));a.reInit();return c};c.clone=function(){return a._extendSwiperSlide(c.cloneNode(!0))};c.remove=function(){a.wrapper.removeChild(c);a.reInit()};c.html=function(a){if("undefined"===typeof a)return c.innerHTML;c.innerHTML=a;return c};c.index=function(){for(var b,e=a.slides.length-1;0<=e;e--)c===a.slides[e]&&(b=
e);return b};c.isActive=function(){return c.index()===a.activeIndex?!0:!1};c.swiperSlideDataStorage||(c.swiperSlideDataStorage={});c.getData=function(a){return c.swiperSlideDataStorage[a]};c.setData=function(a,b){c.swiperSlideDataStorage[a]=b;return c};c.data=function(a,b){if("undefined"===typeof b)return c.getAttribute("data-"+a);c.setAttribute("data-"+a,b);return c};c.getWidth=function(b,e){return a.h.getWidth(c,b,e)};c.getHeight=function(b,e){return a.h.getHeight(c,b,e)};c.getOffset=function(){return a.h.getOffset(c)};
return c};a.calcSlides=function(c){var d=a.slides?a.slides.length:!1;a.slides=[];a.displaySlides=[];for(var e=0;e<a.wrapper.childNodes.length;e++)if(a.wrapper.childNodes[e].className)for(var f=a.wrapper.childNodes[e].className.split(/\s+/),g=0;g<f.length;g++)f[g]===b.slideClass&&a.slides.push(a.wrapper.childNodes[e]);for(e=a.slides.length-1;0<=e;e--)a._extendSwiperSlide(a.slides[e]);!1===d||d===a.slides.length&&!c||(r(),v(),a.updateActiveSlide(),a.params.pagination&&a.createPagination(),a.callPlugins("numberOfSlidesChanged"))};
a.createSlide=function(c,d,e){d=d||a.params.slideClass;e=e||b.slideElement;e=document.createElement(e);e.innerHTML=c||"";e.className=d;return a._extendSwiperSlide(e)};a.appendSlide=function(b,d,e){if(b)return b.nodeType?a._extendSwiperSlide(b).append():a.createSlide(b,d,e).append()};a.prependSlide=function(b,d,e){if(b)return b.nodeType?a._extendSwiperSlide(b).prepend():a.createSlide(b,d,e).prepend()};a.insertSlideAfter=function(b,d,e,f){return"undefined"===typeof b?!1:d.nodeType?a._extendSwiperSlide(d).insertAfter(b):
a.createSlide(d,e,f).insertAfter(b)};a.removeSlide=function(c){if(a.slides[c]){if(b.loop){if(!a.slides[c+a.loopedSlides])return!1;a.slides[c+a.loopedSlides].remove();a.removeLoopedSlides();a.calcSlides();a.createLoop()}else a.slides[c].remove();return!0}return!1};a.removeLastSlide=function(){return 0<a.slides.length?(b.loop?(a.slides[a.slides.length-1-a.loopedSlides].remove(),a.removeLoopedSlides(),a.calcSlides(),a.createLoop()):a.slides[a.slides.length-1].remove(),!0):!1};a.removeAllSlides=function(){for(var b=
a.slides.length-1;0<=b;b--)a.slides[b].remove()};a.getSlide=function(b){return a.slides[b]};a.getLastSlide=function(){return a.slides[a.slides.length-1]};a.getFirstSlide=function(){return a.slides[0]};a.activeSlide=function(){return a.slides[a.activeIndex]};a.fireCallback=function(c,d,e,f,g,h){if("[object Array]"===Object.prototype.toString.call(c))for(var k=0;k<c.length;k++){if("function"===typeof c[k])c[k](d,e,f,g,h)}else"[object String]"===Object.prototype.toString.call(c)?b["on"+c]&&a.fireCallback(b["on"+
c]):c(d,e,f,g,h)};a.addCallback=function(a,b){var e;if(this.params["on"+a]){e="[object Array]"===Object.prototype.toString.apply(this.params["on"+a])?!0:!1;if(e)return this.params["on"+a].push(b);if("function"===typeof this.params["on"+a])return e=this.params["on"+a],this.params["on"+a]=[],this.params["on"+a].push(e),this.params["on"+a].push(b)}else return this.params["on"+a]=[],this.params["on"+a].push(b)};a.removeCallbacks=function(b){a.params["on"+b]&&(a.params["on"+b]=null)};var O=[],A;for(A in a.plugins)b[A]&&
(p=a.plugins[A](a,b[A]))&&O.push(p);a.callPlugins=function(a,b){b||(b={});for(var e=0;e<O.length;e++)if(a in O[e])O[e][a](b)};!a.browser.ie10&&!a.browser.ie11||b.onlyExternal||a.wrapper.classList.add("swiper-wp8-"+(m?"horizontal":"vertical"));b.freeMode&&(a.container.className+=" swiper-free-mode");a.initialized=!1;a.init=function(c,d){var e=a.h.getWidth(a.container,!1,b.roundLengths),f=a.h.getHeight(a.container,!1,b.roundLengths);if(e!==a.width||f!==a.height||c){a.width=e;a.height=f;var g,h,k;l=
m?e:f;var q=a.wrapper;c&&a.calcSlides(d);if("auto"===b.slidesPerView){var p=0,u=0;0<b.slidesOffset&&(q.style.paddingLeft="",q.style.paddingRight="",q.style.paddingTop="",q.style.paddingBottom="");q.style.width="";q.style.height="";0<b.offsetPxBefore&&(m?a.wrapperLeft=b.offsetPxBefore:a.wrapperTop=b.offsetPxBefore);0<b.offsetPxAfter&&(m?a.wrapperRight=b.offsetPxAfter:a.wrapperBottom=b.offsetPxAfter);b.centeredSlides&&(m?(a.wrapperLeft=(l-this.slides[0].getWidth(!0,b.roundLengths))/2,a.wrapperRight=
(l-a.slides[a.slides.length-1].getWidth(!0,b.roundLengths))/2):(a.wrapperTop=(l-a.slides[0].getHeight(!0,b.roundLengths))/2,a.wrapperBottom=(l-a.slides[a.slides.length-1].getHeight(!0,b.roundLengths))/2));m?(0<=a.wrapperLeft&&(q.style.paddingLeft=a.wrapperLeft+"px"),0<=a.wrapperRight&&(q.style.paddingRight=a.wrapperRight+"px")):(0<=a.wrapperTop&&(q.style.paddingTop=a.wrapperTop+"px"),0<=a.wrapperBottom&&(q.style.paddingBottom=a.wrapperBottom+"px"));var v=h=0;a.snapGrid=[];a.slidesGrid=[];for(k=g=
0;k<a.slides.length;k++){e=a.slides[k].getWidth(!0,b.roundLengths);f=a.slides[k].getHeight(!0,b.roundLengths);b.calculateHeight&&(g=Math.max(g,f));var r=m?e:f;if(b.centeredSlides){var t=k===a.slides.length-1?0:a.slides[k+1].getWidth(!0,b.roundLengths),w=k===a.slides.length-1?0:a.slides[k+1].getHeight(!0,b.roundLengths),t=m?t:w;if(r>l){if(b.slidesPerViewFit)a.snapGrid.push(h+a.wrapperLeft),a.snapGrid.push(h+r-l+a.wrapperLeft);else for(w=0;w<=Math.floor(r/(l+a.wrapperLeft));w++)0===w?a.snapGrid.push(h+
a.wrapperLeft):a.snapGrid.push(h+a.wrapperLeft+l*w);a.slidesGrid.push(h+a.wrapperLeft)}else a.snapGrid.push(v),a.slidesGrid.push(v);v+=r/2+t/2}else{if(r>l)if(b.slidesPerViewFit)a.snapGrid.push(h),a.snapGrid.push(h+r-l);else if(0!==l)for(t=0;t<=Math.floor(r/l);t++)a.snapGrid.push(h+l*t);else a.snapGrid.push(h);else a.snapGrid.push(h);a.slidesGrid.push(h)}h+=r;p+=e;u+=f}b.calculateHeight&&(a.height=g);m?(B=p+a.wrapperRight+a.wrapperLeft,q.style.width=p+"px",q.style.height=a.height+"px"):(B=u+a.wrapperTop+
a.wrapperBottom,q.style.width=a.width+"px",q.style.height=u+"px")}else if(b.scrollContainer)q.style.width="",q.style.height="",g=a.slides[0].getWidth(!0,b.roundLengths),h=a.slides[0].getHeight(!0,b.roundLengths),B=m?g:h,q.style.width=g+"px",q.style.height=h+"px",s=m?g:h;else{if(b.calculateHeight){h=g=0;m||(a.container.style.height="");q.style.height="";for(k=0;k<a.slides.length;k++)a.slides[k].style.height="",g=Math.max(a.slides[k].getHeight(!0),g),m||(h+=a.slides[k].getHeight(!0));f=g;a.height=f;
m?h=f:(l=f,a.container.style.height=l+"px")}else f=m?a.height:a.height/b.slidesPerView,b.roundLengths&&(f=Math.round(f)),h=m?a.height:a.slides.length*f;e=m?a.width/b.slidesPerView:a.width;b.roundLengths&&(e=Math.round(e));g=m?a.slides.length*e:a.width;s=m?e:f;0<b.offsetSlidesBefore&&(m?a.wrapperLeft=s*b.offsetSlidesBefore:a.wrapperTop=s*b.offsetSlidesBefore);0<b.offsetSlidesAfter&&(m?a.wrapperRight=s*b.offsetSlidesAfter:a.wrapperBottom=s*b.offsetSlidesAfter);0<b.offsetPxBefore&&(m?a.wrapperLeft=b.offsetPxBefore:
a.wrapperTop=b.offsetPxBefore);0<b.offsetPxAfter&&(m?a.wrapperRight=b.offsetPxAfter:a.wrapperBottom=b.offsetPxAfter);b.centeredSlides&&(m?(a.wrapperLeft=(l-s)/2,a.wrapperRight=(l-s)/2):(a.wrapperTop=(l-s)/2,a.wrapperBottom=(l-s)/2));m?(0<a.wrapperLeft&&(q.style.paddingLeft=a.wrapperLeft+"px"),0<a.wrapperRight&&(q.style.paddingRight=a.wrapperRight+"px")):(0<a.wrapperTop&&(q.style.paddingTop=a.wrapperTop+"px"),0<a.wrapperBottom&&(q.style.paddingBottom=a.wrapperBottom+"px"));B=m?g+a.wrapperRight+a.wrapperLeft:
h+a.wrapperTop+a.wrapperBottom;b.cssWidthAndHeight||(0<parseFloat(g)&&(q.style.width=g+"px"),0<parseFloat(h)&&(q.style.height=h+"px"));h=0;a.snapGrid=[];a.slidesGrid=[];for(k=0;k<a.slides.length;k++)a.snapGrid.push(h),a.slidesGrid.push(h),h+=s,b.cssWidthAndHeight||(0<parseFloat(e)&&(a.slides[k].style.width=e+"px"),0<parseFloat(f)&&(a.slides[k].style.height=f+"px"))}a.initialized?(a.callPlugins("onInit"),b.onInit&&a.fireCallback(b.onInit,a)):(a.callPlugins("onFirstInit"),b.onFirstInit&&a.fireCallback(b.onFirstInit,
a));a.initialized=!0}};a.reInit=function(b){a.init(!0,b)};a.resizeFix=function(c){a.callPlugins("beforeResizeFix");a.init(b.resizeReInit||c);b.freeMode?a.getWrapperTranslate()<-g()&&(a.setWrapperTransition(0),a.setWrapperTranslate(-g())):(a.swipeTo(b.loop?a.activeLoopIndex:a.activeIndex,0,!1),b.autoplay&&(a.support.transitions&&"undefined"!==typeof u?"undefined"!==typeof u&&(clearTimeout(u),u=void 0,a.startAutoplay()):"undefined"!==typeof w&&(clearInterval(w),w=void 0,a.startAutoplay())));a.callPlugins("afterResizeFix")};
a.destroy=function(){var c=a.h.removeEventListener,d="wrapper"===b.eventTarget?a.wrapper:a.container;a.browser.ie10||a.browser.ie11?(c(d,a.touchEvents.touchStart,C),c(document,a.touchEvents.touchMove,D),c(document,a.touchEvents.touchEnd,E)):(a.support.touch&&(c(d,"touchstart",C),c(d,"touchmove",D),c(d,"touchend",E)),b.simulateTouch&&(c(d,"mousedown",C),c(document,"mousemove",D),c(document,"mouseup",E)));b.autoResize&&c(window,"resize",a.resizeFix);r();b.paginationClickable&&Y();b.mousewheelControl&&
a._wheelEvent&&c(a.container,a._wheelEvent,Q);b.keyboardControl&&c(document,"keydown",I);b.autoplay&&a.stopAutoplay();a.callPlugins("onDestroy");a=null};a.disableKeyboardControl=function(){b.keyboardControl=!1;a.h.removeEventListener(document,"keydown",I)};a.enableKeyboardControl=function(){b.keyboardControl=!0;a.h.addEventListener(document,"keydown",I)};var V=(new Date).getTime();b.grabCursor&&(A=a.container.style,A.cursor="move",A.cursor="grab",A.cursor="-moz-grab",A.cursor="-webkit-grab");a.allowSlideClick=
!0;a.allowLinks=!0;var y=!1,K,J=!0,G,L;a.swipeNext=function(c){!c&&b.loop&&a.fixLoop();!c&&b.autoplay&&a.stopAutoplay(!0);c=a.slidesGrid.length;if(b.fixPerView&&4==c&&a.activeIndex==c-2&&0==a.previousIndex)a.activeIndex=c-1,a.previousIndex=c-2,a.swipeNext();else if(b.fixPerView&&a.activeIndex==c-3&&a.previousIndex==c-1)a.activeIndex=c-2,a.previousIndex=c-3,a.swipeNext();else{a.callPlugins("onSwipeNext");var d=c=a.getWrapperTranslate();if("auto"===b.slidesPerView)for(var e=0;e<a.snapGrid.length;e++){if(-c>=
a.snapGrid[e]&&-c<a.snapGrid[e+1]){d=-a.snapGrid[e+1];break}}else d=s*b.slidesPerGroup,d=-(Math.floor(Math.abs(c)/Math.floor(d))*d+d);d<-g()&&(d=-g());if(d===c)return!1;M(d,"next");return!0}};a.swipePrev=function(c){!c&&b.loop&&a.fixLoop();!c&&b.autoplay&&a.stopAutoplay(!0);c=a.slidesGrid.length;if(b.fixPerView&&1==a.activeIndex&&a.previousIndex!=c-1&&a.previousIndex!=c-2)a.swipeTo(c-2,0),a.swipeTo(c-3,300),a.activeIndex=c-3;else if(b.fixPerView&&0==a.activeIndex)a.swipeTo(c-3,0),a.swipeTo(c-4,300),
a.activeIndex=c-4;else{a.callPlugins("onSwipePrev");c=Math.ceil(a.getWrapperTranslate());var d;if("auto"===b.slidesPerView){d=0;for(var e=1;e<a.snapGrid.length;e++){if(-c===a.snapGrid[e]){d=-a.snapGrid[e-1];break}if(-c>a.snapGrid[e]&&-c<a.snapGrid[e+1]){d=-a.snapGrid[e];break}}}else d=s*b.slidesPerGroup,d*=-(Math.ceil(-c/d)-1);0<d&&(d=0);if(d===c)return!1;M(d,"prev");return!0}};a.swipeReset=function(){a.callPlugins("onSwipeReset");var c=a.getWrapperTranslate(),d=s*b.slidesPerGroup;g();if("auto"===
b.slidesPerView){for(var e=d=0;e<a.snapGrid.length;e++){if(-c===a.snapGrid[e])return;if(-c>=a.snapGrid[e]&&-c<a.snapGrid[e+1]){d=0<a.positions.diff?-a.snapGrid[e+1]:-a.snapGrid[e];break}}-c>=a.snapGrid[a.snapGrid.length-1]&&(d=-a.snapGrid[a.snapGrid.length-1]);c<=-g()&&(d=-g())}else d=0>c?Math.round(c/d)*d:0;b.scrollContainer&&(d=0>c?c:0);d<-g()&&(d=-g());b.scrollContainer&&l>s&&(d=0);if(d===c)return!1;M(d,"reset");return!0};a.swipeTo=function(c,d,e){c=parseInt(c,10);a.callPlugins("onSwipeTo",{index:c,
speed:d});b.loop&&(c+=a.loopedSlides);var f=a.getWrapperTranslate();if(!(c>a.slides.length-1||0>c)){var h;h="auto"===b.slidesPerView?-a.slidesGrid[c]:-c*s;h<-g()&&(h=-g());if(h===f)return!1;M(h,"to",{index:c,speed:d,runCallbacks:!1===e?!1:!0});return!0}};a._queueStartCallbacks=!1;a._queueEndCallbacks=!1;a.updateActiveSlide=function(c){if(a.initialized&&0!==a.slides.length){a.previousIndex=a.activeIndex;"undefined"===typeof c&&(c=a.getWrapperTranslate());0<c&&(c=0);var d;if("auto"===b.slidesPerView){if(a.activeIndex=
a.slidesGrid.indexOf(-c),0>a.activeIndex){for(d=0;d<a.slidesGrid.length-1&&!(-c>a.slidesGrid[d]&&-c<a.slidesGrid[d+1]);d++);var e=Math.abs(a.slidesGrid[d]+c),f=Math.abs(a.slidesGrid[d+1]+c);a.activeIndex=e<=f?d:d+1}}else a.activeIndex=Math[b.visibilityFullFit?"ceil":"round"](-c/s);a.activeIndex===a.slides.length&&(a.activeIndex=a.slides.length-1);0>a.activeIndex&&(a.activeIndex=0);if(a.slides[a.activeIndex]){a.calcVisibleSlides(c);if(a.support.classList){for(d=0;d<a.slides.length;d++)e=a.slides[d],
e.classList.remove(b.slideActiveClass),0<=a.visibleSlides.indexOf(e)?e.classList.add(b.slideVisibleClass):e.classList.remove(b.slideVisibleClass);a.slides[a.activeIndex].classList.add(b.slideActiveClass)}else{e=RegExp("\\s*"+b.slideActiveClass);f=RegExp("\\s*"+b.slideVisibleClass);for(d=0;d<a.slides.length;d++)a.slides[d].className=a.slides[d].className.replace(e,"").replace(f,""),0<=a.visibleSlides.indexOf(a.slides[d])&&(a.slides[d].className+=" "+b.slideVisibleClass);a.slides[a.activeIndex].className+=
" "+b.slideActiveClass}b.loop?(d=a.loopedSlides,a.activeLoopIndex=a.activeIndex-d,a.activeLoopIndex>=a.slides.length-2*d&&(a.activeLoopIndex=a.slides.length-2*d-a.activeLoopIndex),0>a.activeLoopIndex&&(a.activeLoopIndex=a.slides.length-2*d+a.activeLoopIndex),0>a.activeLoopIndex&&(a.activeLoopIndex=0)):a.activeLoopIndex=a.activeIndex;b.pagination&&a.updatePagination(c)}}};a.createPagination=function(c){b.paginationClickable&&a.paginationButtons&&Y();a.paginationContainer=b.pagination.nodeType?b.pagination:
h(b.pagination)[0];if(b.createPagination){var d="",e=a.slides.length;b.loop&&(e-=2*a.loopedSlides);for(var f=0;f<e;f++)d+="<"+b.paginationElement+' class="'+b.paginationElementClass+'"></'+b.paginationElement+">";a.paginationContainer.innerHTML=d}a.paginationButtons=h("."+b.paginationElementClass,a.paginationContainer);c||a.updatePagination();a.callPlugins("onCreatePagination");if(b.paginationClickable&&(c=a.paginationButtons))for(d=0;d<c.length;d++)a.h.addEventListener(c[d],"click",Z)};a.updatePagination=
function(c){if(b.pagination&&!(1>a.slides.length)&&h("."+b.paginationActiveClass,a.paginationContainer)){var d=a.paginationButtons;if(0!==d.length){for(var e=0;e<d.length;e++)d[e].className=b.paginationElementClass;e=b.loop?a.loopedSlides:0;if(b.paginationAsRange){a.visibleSlides||a.calcVisibleSlides(c);c=[];var f;for(f=0;f<a.visibleSlides.length;f++){var g=a.slides.indexOf(a.visibleSlides[f])-e;b.loop&&0>g&&(g=a.slides.length-2*a.loopedSlides+g);b.loop&&g>=a.slides.length-2*a.loopedSlides&&(g=a.slides.length-
2*a.loopedSlides-g,g=Math.abs(g));c.push(g)}for(f=0;f<c.length;f++)d[c[f]]&&(d[c[f]].className+=" "+b.paginationVisibleClass);b.loop?void 0!==d[a.activeLoopIndex]&&(d[a.activeLoopIndex].className+=" "+b.paginationActiveClass):d[a.activeIndex].className+=" "+b.paginationActiveClass}else b.loop?d[a.activeLoopIndex]&&(d[a.activeLoopIndex].className+=" "+b.paginationActiveClass+" "+b.paginationVisibleClass):d[a.activeIndex].className+=" "+b.paginationActiveClass+" "+b.paginationVisibleClass}}};a.calcVisibleSlides=
function(c){var d=[],e=0,f=0,g=0;m&&0<a.wrapperLeft&&(c+=a.wrapperLeft);!m&&0<a.wrapperTop&&(c+=a.wrapperTop);for(var h=0;h<a.slides.length;h++){var e=e+f,f="auto"===b.slidesPerView?m?a.h.getWidth(a.slides[h],!0,b.roundLengths):a.h.getHeight(a.slides[h],!0,b.roundLengths):s,g=e+f,k=!1;b.visibilityFullFit?(e>=-c&&g<=-c+l&&(k=!0),e<=-c&&g>=-c+l&&(k=!0)):(g>-c&&g<=-c+l&&(k=!0),e>=-c&&e<-c+l&&(k=!0),e<-c&&g>-c+l&&(k=!0));k&&d.push(a.slides[h])}0===d.length&&(d=[a.slides[a.activeIndex]]);a.visibleSlides=
d};var u,w;a.startAutoplay=function(){if(a.support.transitions){if("undefined"!==typeof u)return!1;b.autoplay&&(a.callPlugins("onAutoplayStart"),b.onAutoplayStart&&a.fireCallback(b.onAutoplayStart,a),P())}else{if("undefined"!==typeof w)return!1;b.autoplay&&(a.callPlugins("onAutoplayStart"),b.onAutoplayStart&&a.fireCallback(b.onAutoplayStart,a),w=setInterval(function(){b.loop?(a.fixLoop(),a.swipeNext(!0)):a.swipeNext(!0)||(b.autoplayStopOnLast?(clearInterval(w),w=void 0):a.swipeTo(0))},b.autoplay))}};
a.stopAutoplay=function(c){a.support.transitions?u&&(u&&clearTimeout(u),u=void 0,c&&!b.autoplayDisableOnInteraction&&a.wrapperTransitionEnd(function(){P()}),a.callPlugins("onAutoplayStop"),b.onAutoplayStop&&a.fireCallback(b.onAutoplayStop,a)):(w&&clearInterval(w),w=void 0,a.callPlugins("onAutoplayStop"),b.onAutoplayStop&&a.fireCallback(b.onAutoplayStop,a))};a.loopCreated=!1;a.removeLoopedSlides=function(){if(a.loopCreated)for(var b=0;b<a.slides.length;b++)!0===a.slides[b].getData("looped")&&a.wrapper.removeChild(a.slides[b])};
a.createLoop=function(){if(0!==a.slides.length){a.loopedSlides="auto"===b.slidesPerView?b.loopedSlides||1:b.slidesPerView+b.loopAdditionalSlides;a.loopedSlides>a.slides.length&&(a.loopedSlides=a.slides.length);var c="",d="",e,f="",g=a.slides.length,h=Math.floor(a.loopedSlides/g),k=a.loopedSlides%g;for(e=0;e<h*g;e++){var l=e;e>=g&&(l=e-g*Math.floor(e/g));f+=a.slides[l].outerHTML}for(e=0;e<k;e++)d+=X(b.slideDuplicateClass,a.slides[e].outerHTML);for(e=g-k;e<g;e++)c+=X(b.slideDuplicateClass,a.slides[e].outerHTML);
N.innerHTML=c+f+N.innerHTML+f+d;a.loopCreated=!0;a.calcSlides();for(e=0;e<a.slides.length;e++)(e<a.loopedSlides||e>=a.slides.length-a.loopedSlides)&&a.slides[e].setData("looped",!0);a.callPlugins("onCreateLoop")}};a.fixLoop=function(){var c;if(a.activeIndex<a.loopedSlides)c=a.slides.length-3*a.loopedSlides+a.activeIndex,a.swipeTo(c,0,!1);else if("auto"===b.slidesPerView&&a.activeIndex>=2*a.loopedSlides||a.activeIndex>a.slides.length-2*b.slidesPerView)c=-a.slides.length+a.activeIndex+a.loopedSlides,
a.swipeTo(c,0,!1)};a.loadSlides=function(){var c="";a.activeLoaderIndex=0;for(var d=b.loader.slides,e=b.loader.loadAllSlides?d.length:b.slidesPerView*(1+b.loader.surroundGroups),f=0;f<e;f++)c="outer"===b.loader.slidesHTMLType?c+d[f]:c+("<"+b.slideElement+' class="'+b.slideClass+'" data-swiperindex="'+f+'">'+d[f]+"</"+b.slideElement+">");a.wrapper.innerHTML=c;a.calcSlides(!0);b.loader.loadAllSlides||a.wrapperTransitionEnd(a.reloadSlides,!0)};a.reloadSlides=function(){var c=b.loader.slides,d=parseInt(a.activeSlide().data("swiperindex"),
10);if(!(0>d||d>c.length-1)){a.activeLoaderIndex=d;var e=Math.max(0,d-b.slidesPerView*b.loader.surroundGroups),f=Math.min(d+b.slidesPerView*(1+b.loader.surroundGroups)-1,c.length-1);0<d&&(a.setWrapperTranslate(-s*(d-e)),a.setWrapperTransition(0));if("reload"===b.loader.logic){for(var g=a.wrapper.innerHTML="",d=e;d<=f;d++)g+="outer"===b.loader.slidesHTMLType?c[d]:"<"+b.slideElement+' class="'+b.slideClass+'" data-swiperindex="'+d+'">'+c[d]+"</"+b.slideElement+">";a.wrapper.innerHTML=g}else{for(var g=
1E3,h=0,d=0;d<a.slides.length;d++){var k=a.slides[d].data("swiperindex");k<e||k>f?a.wrapper.removeChild(a.slides[d]):(g=Math.min(k,g),h=Math.max(k,h))}for(d=e;d<=f;d++)d<g&&(e=document.createElement(b.slideElement),e.className=b.slideClass,e.setAttribute("data-swiperindex",d),e.innerHTML=c[d],a.wrapper.insertBefore(e,a.wrapper.firstChild)),d>h&&(e=document.createElement(b.slideElement),e.className=b.slideClass,e.setAttribute("data-swiperindex",d),e.innerHTML=c[d],a.wrapper.appendChild(e))}a.reInit(!0)}};
a.calcSlides();0<b.loader.slides.length&&0===a.slides.length&&a.loadSlides();b.loop&&a.createLoop();a.init();k();b.pagination&&a.createPagination(!0);b.loop||0<b.initialSlide?a.swipeTo(b.initialSlide,0,!1):a.updateActiveSlide(0);b.autoplay&&a.startAutoplay();a.centerIndex=a.activeIndex;b.onSwiperCreated&&a.fireCallback(b.onSwiperCreated,a);a.callPlugins("onSwiperCreated")}};
Swiper.prototype={plugins:{},wrapperTransitionEnd:function(f,b){function h(){f(g);g.params.queueEndCallbacks&&(g._queueEndCallbacks=!1);if(!b)for(r=0;r<v.length;r++)g.h.removeEventListener(k,v[r],h)}var g=this,k=g.wrapper,v=["webkitTransitionEnd","transitionend","oTransitionEnd","MSTransitionEnd","msTransitionEnd"],r;if(f)for(r=0;r<v.length;r++)g.h.addEventListener(k,v[r],h)},getWrapperTranslate:function(f){var b=this.wrapper,h,g;"undefined"===typeof f&&(f="horizontal"===this.params.mode?"x":"y");
this.support.transforms&&this.params.useCSS3Transforms?(b=window.getComputedStyle(b,null),window.WebKitCSSMatrix?b=new WebKitCSSMatrix(b.webkitTransform):(b=b.MozTransform||b.OTransform||b.MsTransform||b.msTransform||b.transform||b.getPropertyValue("transform").replace("translate(","matrix(1, 0, 0, 1,"),h=b.toString().split(",")),"x"===f&&(g=window.WebKitCSSMatrix?b.m41:16===h.length?parseFloat(h[12]):parseFloat(h[4])),"y"===f&&(g=window.WebKitCSSMatrix?b.m42:16===h.length?parseFloat(h[13]):parseFloat(h[5]))):
("x"===f&&(g=parseFloat(b.style.left,10)||0),"y"===f&&(g=parseFloat(b.style.top,10)||0));return g||0},setWrapperTranslate:function(f,b,h){var g=this.wrapper.style,k={x:0,y:0,z:0},v;3===arguments.length?(k.x=f,k.y=b,k.z=h):("undefined"===typeof b&&(b="horizontal"===this.params.mode?"x":"y"),k[b]=f);this.support.transforms&&this.params.useCSS3Transforms?(v=this.support.transforms3d?"translate3d("+k.x+"px, "+k.y+"px, "+k.z+"px)":"translate("+k.x+"px, "+k.y+"px)",g.webkitTransform=g.MsTransform=g.msTransform=
g.MozTransform=g.OTransform=g.transform=v):(g.left=k.x+"px",g.top=k.y+"px");this.callPlugins("onSetWrapperTransform",k);this.params.onSetWrapperTransform&&this.fireCallback(this.params.onSetWrapperTransform,this,k)},setWrapperTransition:function(f){var b=this.wrapper.style;b.webkitTransitionDuration=b.MsTransitionDuration=b.msTransitionDuration=b.MozTransitionDuration=b.OTransitionDuration=b.transitionDuration=f/1E3+"s";this.callPlugins("onSetWrapperTransition",{duration:f});this.params.onSetWrapperTransition&&
this.fireCallback(this.params.onSetWrapperTransition,this,f)},h:{getWidth:function(f,b,h){var g=window.getComputedStyle(f,null).getPropertyValue("width"),k=parseFloat(g);if(isNaN(k)||0<g.indexOf("%"))k=f.offsetWidth-parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-left"))-parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-right"));b&&(k+=parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-left"))+parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-right")));
return h?Math.round(k):k},getHeight:function(f,b,h){if(b)return f.offsetHeight;var g=window.getComputedStyle(f,null).getPropertyValue("height"),k=parseFloat(g);if(isNaN(k)||0<g.indexOf("%"))k=f.offsetHeight-parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-top"))-parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-bottom"));b&&(k+=parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-top"))+parseFloat(window.getComputedStyle(f,null).getPropertyValue("padding-bottom")));
return h?Math.round(k):k},getOffset:function(f){var b=f.getBoundingClientRect(),h=document.body,g=f.clientTop||h.clientTop||0,h=f.clientLeft||h.clientLeft||0,k=window.pageYOffset||f.scrollTop;f=window.pageXOffset||f.scrollLeft;document.documentElement&&!window.pageYOffset&&(k=document.documentElement.scrollTop,f=document.documentElement.scrollLeft);return{top:b.top+k-g,left:b.left+f-h}},windowWidth:function(){if(window.innerWidth)return window.innerWidth;if(document.documentElement&&document.documentElement.clientWidth)return document.documentElement.clientWidth},
windowHeight:function(){if(window.innerHeight)return window.innerHeight;if(document.documentElement&&document.documentElement.clientHeight)return document.documentElement.clientHeight},windowScroll:function(){if("undefined"!==typeof pageYOffset)return{left:window.pageXOffset,top:window.pageYOffset};if(document.documentElement)return{left:document.documentElement.scrollLeft,top:document.documentElement.scrollTop}},addEventListener:function(f,b,h,g){"undefined"===typeof g&&(g=!1);f.addEventListener?
f.addEventListener(b,h,g):f.attachEvent&&f.attachEvent("on"+b,h)},removeEventListener:function(f,b,h,g){"undefined"===typeof g&&(g=!1);f.removeEventListener?f.removeEventListener(b,h,g):f.detachEvent&&f.detachEvent("on"+b,h)}},setTransform:function(f,b){var h=f.style;h.webkitTransform=h.MsTransform=h.msTransform=h.MozTransform=h.OTransform=h.transform=b},setTranslate:function(f,b){var h=f.style,g=b.x||0,k=b.y||0,v=b.z||0;h.webkitTransform=h.MsTransform=h.msTransform=h.MozTransform=h.OTransform=h.transform=
this.support.transforms3d?"translate3d("+g+"px,"+k+"px,"+v+"px)":"translate("+g+"px,"+k+"px)";this.support.transforms||(h.left=g+"px",h.top=k+"px")},setTransition:function(f,b){var h=f.style;h.webkitTransitionDuration=h.MsTransitionDuration=h.msTransitionDuration=h.MozTransitionDuration=h.OTransitionDuration=h.transitionDuration=b+"ms"},support:{touch:window.Modernizr&&!0===Modernizr.touch||function(){return!!("ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch)}(),transforms3d:window.Modernizr&&
!0===Modernizr.csstransforms3d||function(){var f=document.createElement("div").style;return"webkitPerspective"in f||"MozPerspective"in f||"OPerspective"in f||"MsPerspective"in f||"perspective"in f}(),transforms:window.Modernizr&&!0===Modernizr.csstransforms||function(){var f=document.createElement("div").style;return"transform"in f||"WebkitTransform"in f||"MozTransform"in f||"msTransform"in f||"MsTransform"in f||"OTransform"in f}(),transitions:window.Modernizr&&!0===Modernizr.csstransitions||function(){var f=
document.createElement("div").style;return"transition"in f||"WebkitTransition"in f||"MozTransition"in f||"msTransition"in f||"MsTransition"in f||"OTransition"in f}(),classList:function(){return"classList"in document.createElement("div").style}()},browser:{ie8:function(){var f=-1;"Microsoft Internet Explorer"===navigator.appName&&null!==RegExp(/MSIE ([0-9]{1,}[\.0-9]{0,})/).exec(navigator.userAgent)&&(f=parseFloat(RegExp.$1));return-1!==f&&9>f}(),ie10:window.navigator.msPointerEnabled,ie11:window.navigator.pointerEnabled}};
(window.jQuery||window.Zepto)&&function(f){f.fn.swiper=function(b){b=new Swiper(f(this)[0],b);f(this).data("swiper",b);return b}}(window.jQuery||window.Zepto);"undefined"!==typeof module&&(module.exports=Swiper);"function"===typeof define&&define.amd&&define([],function(){return Swiper});

    ; !function (win, $, undefined) {
        var BannerSwiper = (function () {
            function BannerSwiper(dom, options) {
                this.dom = dom;
                this.setOptions(options);
                this.render();
                this.adjustHeight();
                this.bindEvent();
                this.resizeTimer = 0;
            }

            BannerSwiper.prototype.defaultOpts = {
                pagination: '.thumbnail',
                paginationActiveClass: 'current',
                paginationClickable: true,
                loop: true,
                grabCursor: false,
                autoplay: 5000,
                calculateHeight: true

            };

            BannerSwiper.prototype.setOptions = function (options) {
                this.opts = $.extend({}, this.defaultOpts, options);

                this.opts.swiperStatus = 0;

                if ($('.sectionBanner').width() > 960 && !$.IsIE(7) && !$.IsIE(8)) {
                    this.dom.find('.swiper-slide').addClass('sliderPadding');

                    this.opts = $.extend({}, this.opts, {
                        slidesPerView: 'auto',
                        keyboardControl: true,
                        centeredSlides: true,
                        watchActiveIndex: true,
                        fixPerView: true,
                        touchRatio: false
                    });
                    this.opts.swiperStatus = 1;
                }
            };

            BannerSwiper.prototype.adjustHeight = function (options) {
                if (!$.IsIE(7) && !$.IsIE(8)) {
                    var _selfHeight;
                    var _winWidth = $(window).width();

                    if (_winWidth > 960) {
                        _winWidth = $('.header_wrap').width();
                    }

                    var _padding = $.IsTouchMedia() ? 0 : 15;

                    if (_winWidth > 0 && _winWidth <= 320) {
                        _selfHeight = 140;
                    } else if (_winWidth > 320 && _winWidth <= 640 - _padding) {
                        _selfHeight = (_winWidth * 1.5) * 280 / 960;
                    } else if (_winWidth > 640 - _padding && _winWidth <= 960 - _padding) {
                        _selfHeight = _winWidth * 280 / 960;
                    } else {
                        _selfHeight = 280;
                    }
                    this.dom.height(_selfHeight);
                }
            };


            BannerSwiper.prototype.render = function () {
                var opt = this.options,
                    _self = this.dom;

                this.isSingle = _self.find('img').length < 2;

                var _winWidth = $(window).width();

                if (_winWidth > 960) {
                    _winWidth = $('.header_wrap').width();
                }

                if (_winWidth > 960 && this.isSingle) {
                    _self.find('.swiper-slide').addClass('swiper-slide-center');
                    return;
                }

                if (this.isSingle) {
                    this.opts = $.extend({}, this.opts, { 'onlyExternal': true, 'autoplay': false });
                }

                this.swiper = new Swiper('#' + _self.attr('id'), this.opts);

                // _self.find('.swiper-slide').show();

            };

            BannerSwiper.prototype.bindEvent = function () {
                var _self = this.dom,
                    _bannerSwiper = this.swiper;

                var _winWidth = $(window).width();

                if (_winWidth > 960) {
                    _winWidth = $('.header_wrap').width();
                }

                if (_winWidth > 960 && this.isSingle) {
                    return;
                }

                var _slidePrev = _self.find('.slide_prev'),
                    _slideNext = _self.find('.slide_next');

                if (!this.isSingle) {
                    $(_bannerSwiper.container).on('mouseenter.swiper', function () {
                        var _bannerHeight = _self.outerHeight() / 2 - 40;
                        _slidePrev.css('top', _bannerHeight).animate({ 'left': 0 }, 200);
                        _slideNext.css('top', _bannerHeight).animate({ 'right': 0 }, 200);
                        _bannerSwiper.stopAutoplay();
                    });
                    $(_bannerSwiper.container).on('mouseleave.swiper', function () {
                        _slidePrev.animate({ 'left': -40 }, 200);
                        _slideNext.animate({ 'right': -40 }, 200);
                        _bannerSwiper.startAutoplay();
                    })

                    $(_bannerSwiper.container).on('click.swiper', function (e) {
                        if ($(e.target).closest('.swiper-slide-visible').is('div')) {
                            if ($(e.target).closest('.swiper-slide-visible').hasClass('swiper-slide-active')) {
                                return;
                            }
                            var _index = $('.swiper-slide-visible').index($(e.target).closest('.swiper-slide-visible'));

                            if (_index == 0) {
                                _slidePrev.click();
                            } else if (_index == 2) {
                                _slideNext.click();
                            }
                        }
                    });

                    _slidePrev.on('click.swiper', function (e) {
                        _bannerSwiper.swipePrev();
                    });


                    _slideNext.on('click.swiper', function (e) {
                        _bannerSwiper.swipeNext();
                    });

                } else {
                    _self.find('.thumbnail').hide();
                }

                var _that = this;
                $(window).on('resize.swiper', function () {
                    clearTimeout(_that.resizeTimer);
                    _that.resizeTimer = setTimeout(function () {
                        _that.adjustHeight();

                        var _winWidth = $(window).width();

                        if (_winWidth > 960) {
                            _winWidth = $('.header_wrap').width();
                        }

                        if (_winWidth < 768) {
                            if (!_that.isSingle) {
                                _slidePrev.hide();
                                _slideNext.hide();
                            }
                        } else {
                            if (!_that.isSingle) {
                                _slidePrev.show();
                                _slideNext.show();
                            }
                        }
                    }, 10);
                });
            };

            BannerSwiper.prototype.destroys = function () {
                var opt = this.options,
                    _self = this.dom,
                    _bannerSwiper = this.swiper;

                _bannerSwiper.destroy();
                _self.find('.thumbnail').html('');
                _self.find('.swiper-slide').removeAttr('style').removeClass('swiper-slide-visible swiper-slide-active');
                _self.find('.swiper-wrapper').removeAttr('style');


                _self.find('.swiper-slide-duplicate').remove();

                clearTimeout(this.resizeTimer);
                $(window).off('.swiper');
                $(_bannerSwiper.container).off('.swiper');
                _self.find('.slide_prev').off('.swiper');
                _self.find('.slide_next').off('.swiper');
                _self.find('.swiper-slide-visible').off('.swiper');
            }
            return BannerSwiper;
        })();

        $.fn.BannerSwiper = function (opts) {
            var $this = $(this),
                data = $this.data();
            if (data == null) {
                return;
            }

            if (data.BannerSwiper) {
                delete data.BannerSwiper;
            }
            if (opts !== false) {
                data.BannerSwiper = new BannerSwiper($this, opts);
            }
            return data.BannerSwiper;
        };
    }(window, jQuery);

    /*
     * Platform
     */
    ; (function ($) {
        jQuery.easing['jswing'] = jQuery.easing['swing'];

        jQuery.extend(jQuery.easing, {
            def: 'easeOutQuad',
            swing: function (x, t, b, c, d) {
                //alert(jQuery.easing.default);
                return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
            },
            easeInQuad: function (x, t, b, c, d) {
                return c * (t /= d) * t + b;
            },
            easeOutQuad: function (x, t, b, c, d) {
                return -c * (t /= d) * (t - 2) + b;
            },
            easeInOutQuad: function (x, t, b, c, d) {
                if ((t /= d / 2) < 1) return c / 2 * t * t + b;
                return -c / 2 * ((--t) * (t - 2) - 1) + b;
            },
            easeInCubic: function (x, t, b, c, d) {
                return c * (t /= d) * t * t + b;
            },
            easeOutCubic: function (x, t, b, c, d) {
                return c * ((t = t / d - 1) * t * t + 1) + b;
            },
            easeInOutCubic: function (x, t, b, c, d) {
                if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
                return c / 2 * ((t -= 2) * t * t + 2) + b;
            },
            easeInQuart: function (x, t, b, c, d) {
                return c * (t /= d) * t * t * t + b;
            },
            easeOutQuart: function (x, t, b, c, d) {
                return -c * ((t = t / d - 1) * t * t * t - 1) + b;
            },
            easeInOutQuart: function (x, t, b, c, d) {
                if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
                return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
            },
            easeInQuint: function (x, t, b, c, d) {
                return c * (t /= d) * t * t * t * t + b;
            },
            easeOutQuint: function (x, t, b, c, d) {
                return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
            },
            easeInOutQuint: function (x, t, b, c, d) {
                if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
                return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
            },
            easeInSine: function (x, t, b, c, d) {
                return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
            },
            easeOutSine: function (x, t, b, c, d) {
                return c * Math.sin(t / d * (Math.PI / 2)) + b;
            },
            easeInOutSine: function (x, t, b, c, d) {
                return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
            },
            easeInExpo: function (x, t, b, c, d) {
                return (t == 0) ? b : c * Math.pow(2, 10 * (t / d - 1)) + b;
            },
            easeOutExpo: function (x, t, b, c, d) {
                return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
            },
            easeInOutExpo: function (x, t, b, c, d) {
                if (t == 0) return b;
                if (t == d) return b + c;
                if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
                return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
            },
            easeInCirc: function (x, t, b, c, d) {
                return -c * (Math.sqrt(1 - (t /= d) * t) - 1) + b;
            },
            easeOutCirc: function (x, t, b, c, d) {
                return c * Math.sqrt(1 - (t = t / d - 1) * t) + b;
            },
            easeInOutCirc: function (x, t, b, c, d) {
                if ((t /= d / 2) < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
                return c / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + b;
            },
            easeInElastic: function (x, t, b, c, d) {
                var s = 1.70158; var p = 0; var a = c;
                if (t == 0) return b; if ((t /= d) == 1) return b + c; if (!p) p = d * .3;
                if (a < Math.abs(c)) { a = c; var s = p / 4; }
                else var s = p / (2 * Math.PI) * Math.asin(c / a);
                return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
            },
            easeOutElastic: function (x, t, b, c, d) {
                var s = 1.70158; var p = 0; var a = c;
                if (t == 0) return b; if ((t /= d) == 1) return b + c; if (!p) p = d * .3;
                if (a < Math.abs(c)) { a = c; var s = p / 4; }
                else var s = p / (2 * Math.PI) * Math.asin(c / a);
                return a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
            },
            easeInOutElastic: function (x, t, b, c, d) {
                var s = 1.70158; var p = 0; var a = c;
                if (t == 0) return b; if ((t /= d / 2) == 2) return b + c; if (!p) p = d * (.3 * 1.5);
                if (a < Math.abs(c)) { a = c; var s = p / 4; }
                else var s = p / (2 * Math.PI) * Math.asin(c / a);
                if (t < 1) return -.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
                return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p) * .5 + c + b;
            },
            easeInBack: function (x, t, b, c, d, s) {
                if (s == undefined) s = 1.70158;
                return c * (t /= d) * t * ((s + 1) * t - s) + b;
            },
            easeOutBack: function (x, t, b, c, d, s) {
                if (s == undefined) s = 1.70158;
                return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
            },
            easeInOutBack: function (x, t, b, c, d, s) {
                if (s == undefined) s = 1.70158;
                if ((t /= d / 2) < 1) return c / 2 * (t * t * (((s *= (1.525)) + 1) * t - s)) + b;
                return c / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2) + b;
            },
            easeInBounce: function (x, t, b, c, d) {
                return c - jQuery.easing.easeOutBounce(x, d - t, 0, c, d) + b;
            },
            easeOutBounce: function (x, t, b, c, d) {
                if ((t /= d) < (1 / 2.75)) {
                    return c * (7.5625 * t * t) + b;
                } else if (t < (2 / 2.75)) {
                    return c * (7.5625 * (t -= (1.5 / 2.75)) * t + .75) + b;
                } else if (t < (2.5 / 2.75)) {
                    return c * (7.5625 * (t -= (2.25 / 2.75)) * t + .9375) + b;
                } else {
                    return c * (7.5625 * (t -= (2.625 / 2.75)) * t + .984375) + b;
                }
            },
            easeInOutBounce: function (x, t, b, c, d) {
                if (t < d / 2) return jQuery.easing.easeInBounce(x, t * 2, 0, c, d) * .5 + b;
                return jQuery.easing.easeOutBounce(x, t * 2 - d, 0, c, d) * .5 + c * .5 + b;
            }
        });

        /*
         * jQuery Easing Compatibility v1 - http://gsgd.co.uk/sandbox/jquery.easing.php
         *
         * Adds compatibility for applications that use the pre 1.2 easing names
         *
         * Copyright (c) 2007 George Smith
         * Licensed under the MIT License:
         *   http://www.opensource.org/licenses/mit-license.php
         */

        jQuery.extend(jQuery.easing,
        {
            easeIn: function (x, t, b, c, d) {
                return jQuery.easing.easeInQuad(x, t, b, c, d);
            },
            easeOut: function (x, t, b, c, d) {
                return jQuery.easing.easeOutQuad(x, t, b, c, d);
            },
            easeInOut: function (x, t, b, c, d) {
                return jQuery.easing.easeInOutQuad(x, t, b, c, d);
            },
            expoin: function (x, t, b, c, d) {
                return jQuery.easing.easeInExpo(x, t, b, c, d);
            },
            expoout: function (x, t, b, c, d) {
                return jQuery.easing.easeOutExpo(x, t, b, c, d);
            },
            expoinout: function (x, t, b, c, d) {
                return jQuery.easing.easeInOutExpo(x, t, b, c, d);
            },
            bouncein: function (x, t, b, c, d) {
                return jQuery.easing.easeInBounce(x, t, b, c, d);
            },
            bounceout: function (x, t, b, c, d) {
                return jQuery.easing.easeOutBounce(x, t, b, c, d);
            },
            bounceinout: function (x, t, b, c, d) {
                return jQuery.easing.easeInOutBounce(x, t, b, c, d);
            },
            elasin: function (x, t, b, c, d) {
                return jQuery.easing.easeInElastic(x, t, b, c, d);
            },
            elasout: function (x, t, b, c, d) {
                return jQuery.easing.easeOutElastic(x, t, b, c, d);
            },
            elasinout: function (x, t, b, c, d) {
                return jQuery.easing.easeInOutElastic(x, t, b, c, d);
            },
            backin: function (x, t, b, c, d) {
                return jQuery.easing.easeInBack(x, t, b, c, d);
            },
            backout: function (x, t, b, c, d) {
                return jQuery.easing.easeOutBack(x, t, b, c, d);
            },
            backinout: function (x, t, b, c, d) {
                return jQuery.easing.easeInOutBack(x, t, b, c, d);
            }
        });
        jQuery.extend({
            IsRetina: function () {
                var mediaQuery = "(-webkit-min-device-pixel-ratio: 1.5),\
			                  (min--moz-device-pixel-ratio: 1.5),\
			                  (-o-min-device-pixel-ratio: 3/2),\
			                  (min-resolution: 1.5dppx)";

                if (window.devicePixelRatio > 1)
                    return true;

                if (window.matchMedia && window.matchMedia(mediaQuery).matches)
                    return true;
                return false;
            },
            setGotopFeedback: function () {
                if ($(window).width() < 1280) {
                    $('#FBK').hide();
                    $('#GoTop').hide();
                    return;
                }
                $('#GoTop').show();
                $('#FBK').show();

                var dif = parseFloat($('#Footer').offset().top - $(window).height() - $(window).scrollTop());
                if (dif < 0) {
                    $("#FBK").css('bottom', 20 - dif);
                } else {
                    $("#FBK").css('bottom', 20);
                }
                if (window.isEmit) { return; }
                if (jQuery(window).scrollTop() > 200) {
                    if (!$("#GoTop").hasClass("dis")) {
                        $("#GoTop").removeClass('emit').attr('style', '').addClass('dis');
                    }
                } else {
                    $("#GoTop").hide().removeClass('dis');
                }
                if (dif < 0) {
                    $("#GoTop").css('bottom', 80 - dif);
                } else {
                    $("#GoTop").css('bottom', 80);
                }
            },
            //Browser Version
            IsIE: function (version) {
                var agent = navigator.userAgent.toLowerCase();
                if (version) {
                    switch (version) {
                        case 6:
                            return agent.indexOf('msie 6.0') > 0;
                        case 7:
                            return agent.indexOf('msie 7.0') > 0;
                        case 8:
                            return agent.indexOf('msie 8.0') > 0;
                        case 9:
                            return agent.indexOf('msie 9.0') > 0;
                        case 10:
                            return agent.indexOf('msie 10.0') > 0;
                    }
                } else {
                    return agent.indexOf('msie') > 0;
                }
            },
            IsSafari: function () {
                return /constructor/i.test(window.HTMLElement) &&
                    navigator.userAgent.indexOf('iPhone') < 0 &&
                    navigator.userAgent.indexOf('iPod') < 0;
            },
            IsAndroid: function () {
                return navigator.userAgent.indexOf('Android') > 0;
            },
            //Is tablet
            IsTouchMedia: function () {
                var userAgentInfo = navigator.userAgent;
                var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
                var flag = false;
                for (var i = 0; i < Agents.length; i++) {
                    if (userAgentInfo.indexOf(Agents[i]) > 0) { flag = true; break; }
                }
                return flag;
            },
            //Pop
            Popup: function (options) {
                var defaults = {
                    type: 'GET',
                    dataType: 'html',
                    url: '',
                    container: body
                }
                var o = $.extend(defaults, options);
                if (o.url) {
                    $.ajax({
                        type: o.type,
                        url: o.url,
                        dataType: o.dataType,
                        success: function (data) {

                        }
                    });
                } else {
                    $(o.container).append('<div class="maskBox"></div>');
                }
            },
            FormPost: function (data, action, autoDelete) {
                var id = (Date.now || function () { return +new Date; })();
                var frame = $("<iframe id=" + id + " style='display:none;'></iframe>");
                var inputStr = "";
                for (var name in data) {
                    if (typeof(data[name]) != "undefined" && data[name] != null) {
                        inputStr += "<input type='text' name='" + name + "' value='" + data[name] + "' ></input>";
                    }
                }
                var formStr = "<form action='" + action + "' method='POST'>"+inputStr+"</form>";
                frame.one("load", function () {
                    frame.contents().find("body").append(formStr);
                    var form = frame.contents().find("form");
                    form.submit();
                });
                $("body").append(frame);

                if (autoDelete) {
                    setTimeout(function () {
                        frame.remove();
                        frame = null;
                    }, 1000 * 2);
                }

                return id;
            },
            FormPostAsync: function (data, action, autoDelte) {
                var _self = this;
                setTimeout(function () {
                    _self.FormPost(data, action, autoDelte);
                }, 100);
            }

        });
    })(jQuery);
    /*
    **	Anderson Ferminiano
    **	contato@andersonferminiano.com -- feel free to contact me for bugs or new implementations.
    **	jQuery ScrollPagination
    **	28th/March/2011
    **	http://andersonferminiano.com/jqueryscrollpagination/
    **	You may use this script for free, but keep my credits.
    **	Thank you.
    */

    (function ($) {


        $.fn.scrollPagination = function (options) {

            var opts = $.extend($.fn.scrollPagination.defaults, options);
            var target = opts.scrollTarget;
            if (target == null) {
                target = obj;
            }
            opts.scrollTarget = target;

            return this.each(function () {
                $.fn.scrollPagination.init($(this), opts);
            });

        };

        $.fn.stopScrollPagination = function () {
            return this.each(function () {
                $(this).attr('scrollPagination', 'disabled');
            });

        };

        $.fn.scrollPagination.loadContent = function (obj, opts) {
            var target = opts.scrollTarget;
            var mayLoadContent = $(target).scrollTop() + opts.heightOffset >= $(document).height() - $(target).height();
            if (mayLoadContent) {
                if (opts.beforeLoad != null) {
                    opts.beforeLoad();
                }
                $(obj).children().attr('rel', 'loaded');
                if (opts.load != null) {
                    opts.load($(obj), {
                        completed: function () {
                            var objectsRendered = $(obj).children('[rel!=loaded]');

                            if (opts.afterLoad != null) {
                                opts.afterLoad(objectsRendered);
                            }
                        }
                    });
                }
            }

        };

        $.fn.scrollPagination.init = function (obj, opts) {
            var target = opts.scrollTarget;
            $(obj).attr('scrollPagination', 'enabled');
            $(target).scroll(function (event) {
                if ($(obj).attr('scrollPagination') == 'enabled') {
                    $.fn.scrollPagination.loadContent(obj, opts);
                }
                else {
                    event.stopPropagation();
                }
            });

            $.fn.scrollPagination.loadContent(obj, opts);

        };

        $.fn.scrollPagination.defaults = {
            'contentPage': null,
            'contentData': {},
            'beforeLoad': null,
            'afterLoad': null,
            'scrollTarget': null,
            'heightOffset': 0,
            'load': null
        };
    })(jQuery);

    /**
     * Copyright (c) 2007-2012 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
     * Dual licensed under MIT and GPL.
     * @author Ariel Flesler
     * @version 1.4.3.1
     */
    /*!
  * jQuery.ScrollTo
  * Copyright (c) 2007-2012 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
  * Dual licensed under MIT and GPL.
  * Date: 4/09/2012
  *
  * @projectDescription Easy element scrolling using jQuery.
  * http://flesler.blogspot.com/2007/10/jqueryscrollto.html
  * @author Ariel Flesler
  * @version 1.4.3.1
  *
  * @id jQuery.scrollTo
  * @id jQuery.fn.scrollTo
  * @param {String, Number, DOMElement, jQuery, Object} target Where to scroll the matched elements.
  *	  The different options for target are:
  *		- A number position (will be applied to all axes).
  *		- A string position ('44', '100px', '+=90', etc ) will be applied to all axes
  *		- A jQuery/DOM element ( logically, child of the element to scroll )
  *		- A string selector, that will be relative to the element to scroll ( 'li:eq(2)', etc )
  *		- A hash { top:x, left:y }, x and y can be any kind of number/string like above.
  *		- A percentage of the container's dimension/s, for example: 50% to go to the middle.
  *		- The string 'max' for go-to-end. 
  * @param {Number, Function} duration The OVERALL length of the animation, this argument can be the settings object instead.
  * @param {Object,Function} settings Optional set of settings or the onAfter callback.
  *	 @option {String} axis Which axis must be scrolled, use 'x', 'y', 'xy' or 'yx'.
  *	 @option {Number, Function} duration The OVERALL length of the animation.
  *	 @option {String} easing The easing method for the animation.
  *	 @option {Boolean} margin If true, the margin of the target element will be deducted from the final position.
  *	 @option {Object, Number} offset Add/deduct from the end position. One number for both axes or { top:x, left:y }.
  *	 @option {Object, Number} over Add/deduct the height/width multiplied by 'over', can be { top:x, left:y } when using both axes.
  *	 @option {Boolean} queue If true, and both axis are given, the 2nd axis will only be animated after the first one ends.
  *	 @option {Function} onAfter Function to be called after the scrolling ends. 
  *	 @option {Function} onAfterFirst If queuing is activated, this function will be called after the first scrolling ends.
  * @return {jQuery} Returns the same jQuery object, for chaining.
  *
  * @desc Scroll to a fixed position
  * @example $('div').scrollTo( 340 );
  *
  * @desc Scroll relatively to the actual position
  * @example $('div').scrollTo( '+=340px', { axis:'y' } );
  *
  * @desc Scroll using a selector (relative to the scrolled element)
  * @example $('div').scrollTo( 'p.paragraph:eq(2)', 500, { easing:'swing', queue:true, axis:'xy' } );
  *
  * @desc Scroll to a DOM element (same for jQuery object)
  * @example var second_child = document.getElementById('container').firstChild.nextSibling;
  *			$('#container').scrollTo( second_child, { duration:500, axis:'x', onAfter:function(){
  *				alert('scrolled!!');																   
  *			}});
  *
  * @desc Scroll on both axes, to different values
  * @example $('div').scrollTo( { top: 300, left:'+=200' }, { axis:'xy', offset:-20 } );
  */

    ; (function ($) {

        var $scrollTo = $.scrollTo = function (target, duration, settings) {
            $(window).scrollTo(target, duration, settings);
        };

        $scrollTo.defaults = {
            axis: 'xy',
            duration: parseFloat($.fn.jquery) >= 1.3 ? 0 : 1,
            limit: true
        };

        // Returns the element that needs to be animated to scroll the window.
        // Kept for backwards compatibility (specially for localScroll & serialScroll)
        $scrollTo.window = function (scope) {
            return $(window)._scrollable();
        };

        // Hack, hack, hack :)
        // Returns the real elements to scroll (supports window/iframes, documents and regular nodes)
        $.fn._scrollable = function () {
            return this.map(function () {
                var elem = this,
                    isWin = !elem.nodeName || $.inArray(elem.nodeName.toLowerCase(), ['iframe', '#document', 'html', 'body']) != -1;

                if (!isWin)
                    return elem;

                var doc = (elem.contentWindow || elem).document || elem.ownerDocument || elem;

                return /webkit/i.test(navigator.userAgent) || doc.compatMode == 'BackCompat' ?
                    doc.body :
                    doc.documentElement;
            });
        };

        $.fn.scrollTo = function (target, duration, settings) {
            if (typeof duration == 'object') {
                settings = duration;
                duration = 0;
            }
            if (typeof settings == 'function')
                settings = { onAfter: settings };

            if (target == 'max')
                target = 9e9;

            settings = $.extend({}, $scrollTo.defaults, settings);
            // Speed is still recognized for backwards compatibility
            duration = duration || settings.duration;
            // Make sure the settings are given right
            settings.queue = settings.queue && settings.axis.length > 1;

            if (settings.queue)
                // Let's keep the overall duration
                duration /= 2;
            settings.offset = both(settings.offset);
            settings.over = both(settings.over);

            return this._scrollable().each(function () {
                // Null target yields nothing, just like jQuery does
                if (target == null) return;

                var elem = this,
                    $elem = $(elem),
                    targ = target, toff, attr = {},
                    win = $elem.is('html,body');

                switch (typeof targ) {
                    // A number will pass the regex
                    case 'number':
                    case 'string':
                        if (/^([+-]=)?\d+(\.\d+)?(px|%)?$/.test(targ)) {
                            targ = both(targ);
                            // We are done
                            break;
                        }
                        // Relative selector, no break!
                        targ = $(targ, this);
                        if (!targ.length) return;
                    case 'object':
                        // DOMElement / jQuery
                        if (targ.is || targ.style)
                            // Get the real position of the target 
                            toff = (targ = $(targ)).offset();
                }
                $.each(settings.axis.split(''), function (i, axis) {
                    var Pos = axis == 'x' ? 'Left' : 'Top',
                        pos = Pos.toLowerCase(),
                        key = 'scroll' + Pos,
                        old = elem[key],
                        max = $scrollTo.max(elem, axis);

                    if (toff) {// jQuery / DOMElement
                        attr[key] = toff[pos] + (win ? 0 : old - $elem.offset()[pos]);

                        // If it's a dom element, reduce the margin
                        if (settings.margin) {
                            attr[key] -= parseInt(targ.css('margin' + Pos)) || 0;
                            attr[key] -= parseInt(targ.css('border' + Pos + 'Width')) || 0;
                        }

                        attr[key] += settings.offset[pos] || 0;

                        if (settings.over[pos])
                            // Scroll to a fraction of its width/height
                            attr[key] += targ[axis == 'x' ? 'width' : 'height']() * settings.over[pos];
                    } else {
                        var val = targ[pos];
                        // Handle percentage values
                        attr[key] = val.slice && val.slice(-1) == '%' ?
                            parseFloat(val) / 100 * max
                            : val;
                    }

                    // Number or 'number'
                    if (settings.limit && /^\d+$/.test(attr[key]))
                        // Check the limits
                        attr[key] = attr[key] <= 0 ? 0 : Math.min(attr[key], max);

                    // Queueing axes
                    if (!i && settings.queue) {
                        // Don't waste time animating, if there's no need.
                        if (old != attr[key])
                            // Intermediate animation
                            animate(settings.onAfterFirst);
                        // Don't animate this axis again in the next iteration.
                        delete attr[key];
                    }
                });

                animate(settings.onAfter);

                function animate(callback) {
                    $elem.animate(attr, duration, settings.easing, callback && function () {
                        callback.call(this, target, settings);
                    });
                };

            }).end();
        };

        // Max scrolling position, works on quirks mode
        // It only fails (not too badly) on IE, quirks mode.
        $scrollTo.max = function (elem, axis) {
            var Dim = axis == 'x' ? 'Width' : 'Height',
                scroll = 'scroll' + Dim;

            if (!$(elem).is('html,body'))
                return elem[scroll] - $(elem)[Dim.toLowerCase()]();

            var size = 'client' + Dim,
                html = elem.ownerDocument.documentElement,
                body = elem.ownerDocument.body;

            return Math.max(html[scroll], body[scroll])
                 - Math.min(html[size], body[size]);
        };

        function both(val) {
            return typeof val == 'object' ? val : { top: val, left: val };
        };

    })(jQuery);

    /*
	Masked Input plugin for jQuery
	Copyright (c) 2007-2011 Josh Bush (digitalbush.com)
	Licensed under the MIT license (http://digitalbush.com/projects/masked-input-plugin/#license) 
	Version: 1.3
*/
    (function ($) {
        var pasteEventName = ($.browser.msie ? 'paste' : 'input') + ".mask";
        var iPhone = (window.orientation != undefined);

        $.mask = {
            //Predefined character definitions
            definitions: {
                '9': "[0-9]",
                'a': "[A-Za-z]",
                '*': "[A-Za-z0-9]"
            },
            dataName: "rawMaskFn"
        };

        $.fn.extend({
            //Helper Function for Caret positioning
            caret: function (begin, end) {
                if (this.length == 0) return;
                if (typeof begin == 'number') {
                    end = (typeof end == 'number') ? end : begin;
                    return this.each(function () {
                        if (this.setSelectionRange) {
                            this.setSelectionRange(begin, end);
                        } else if (this.createTextRange) {
                            var range = this.createTextRange();
                            range.collapse(true);
                            range.moveEnd('character', end);
                            range.moveStart('character', begin);
                            range.select();
                        }
                    });
                } else {
                    if (this[0].setSelectionRange) {
                        begin = this[0].selectionStart;
                        end = this[0].selectionEnd;
                    } else if (document.selection && document.selection.createRange) {
                        var range = document.selection.createRange();
                        begin = 0 - range.duplicate().moveStart('character', -100000);
                        end = begin + range.text.length;
                    }
                    return { begin: begin, end: end };
                }
            },
            unmask: function () { return this.trigger("unmask"); },
            mask: function (mask, settings) {
                if (!mask && this.length > 0) {
                    var input = $(this[0]);
                    return input.data($.mask.dataName)();
                }
                settings = $.extend({
                    placeholder: "_",
                    completed: null
                }, settings);

                var defs = $.mask.definitions;
                var tests = [];
                var partialPosition = mask.length;
                var firstNonMaskPos = null;
                var len = mask.length;

                $.each(mask.split(""), function (i, c) {
                    if (c == '?') {
                        len--;
                        partialPosition = i;
                    } else if (defs[c]) {
                        tests.push(new RegExp(defs[c]));
                        if (firstNonMaskPos == null)
                            firstNonMaskPos = tests.length - 1;
                    } else {
                        tests.push(null);
                    }
                });

                return this.trigger("unmask").each(function () {
                    var input = $(this);
                    var buffer = $.map(mask.split(""), function (c, i) { if (c != '?') return defs[c] ? settings.placeholder : c });
                    var focusText = input.val();

                    function seekNext(pos) {
                        while (++pos <= len && !tests[pos]);
                        return pos;
                    };
                    function seekPrev(pos) {
                        while (--pos >= 0 && !tests[pos]);
                        return pos;
                    };

                    function shiftL(begin, end) {
                        if (begin < 0)
                            return;
                        for (var i = begin, j = seekNext(end) ; i < len; i++) {
                            if (tests[i]) {
                                if (j < len && tests[i].test(buffer[j])) {
                                    buffer[i] = buffer[j];
                                    buffer[j] = settings.placeholder;
                                } else
                                    break;
                                j = seekNext(j);
                            }
                        }
                        writeBuffer();
                        input.caret(Math.max(firstNonMaskPos, begin));
                    };

                    function shiftR(pos) {
                        for (var i = pos, c = settings.placeholder; i < len; i++) {
                            if (tests[i]) {
                                var j = seekNext(i);
                                var t = buffer[i];
                                buffer[i] = c;
                                if (j < len && tests[j].test(t))
                                    c = t;
                                else
                                    break;
                            }
                        }
                    };

                    function keydownEvent(e) {
                        var k = e.which;

                        //backspace, delete, and escape get special treatment
                        if (k == 8 || k == 46 || (iPhone && k == 127)) {
                            var pos = input.caret(),
                                begin = pos.begin,
                                end = pos.end;

                            if (end - begin == 0) {
                                begin = k != 46 ? seekPrev(begin) : (end = seekNext(begin - 1));
                                end = k == 46 ? seekNext(end) : end;
                            }
                            clearBuffer(begin, end);
                            shiftL(begin, end - 1);

                            return false;
                        } else if (k == 27) {//escape
                            input.val(focusText);
                            input.caret(0, checkVal());
                            return false;
                        }
                    };

                    function keypressEvent(e) {
                        var k = e.which,
                            pos = input.caret();
                        if (e.ctrlKey || e.altKey || e.metaKey || k < 32) {//Ignore
                            return true;
                        } else if (k) {
                            if (pos.end - pos.begin != 0) {
                                clearBuffer(pos.begin, pos.end);
                                shiftL(pos.begin, pos.end - 1);
                            }

                            var p = seekNext(pos.begin - 1);
                            if (p < len) {
                                var c = String.fromCharCode(k);
                                if (tests[p].test(c)) {
                                    shiftR(p);
                                    buffer[p] = c;
                                    writeBuffer();
                                    var next = seekNext(p);
                                    input.caret(next);
                                    if (settings.completed && next >= len)
                                        settings.completed.call(input);
                                }
                            }
                            return false;
                        }
                    };

                    function clearBuffer(start, end) {
                        for (var i = start; i < end && i < len; i++) {
                            if (tests[i])
                                buffer[i] = settings.placeholder;
                        }
                    };

                    function writeBuffer() { return input.val(buffer.join('')).val(); };

                    function checkVal(allow) {
                        //try to place characters where they belong
                        var test = input.val();
                        var lastMatch = -1;
                        for (var i = 0, pos = 0; i < len; i++) {
                            if (tests[i]) {
                                buffer[i] = settings.placeholder;
                                while (pos++ < test.length) {
                                    var c = test.charAt(pos - 1);
                                    if (tests[i].test(c)) {
                                        buffer[i] = c;
                                        lastMatch = i;
                                        break;
                                    }
                                }
                                if (pos > test.length)
                                    break;
                            } else if (buffer[i] == test.charAt(pos) && i != partialPosition) {
                                pos++;
                                lastMatch = i;
                            }
                        }
                        if (!allow && lastMatch + 1 < partialPosition) {
                            input.val("");
                            clearBuffer(0, len);
                        } else if (allow || lastMatch + 1 >= partialPosition) {
                            writeBuffer();
                            if (!allow) input.val(input.val().substring(0, lastMatch + 1));
                        }
                        return (partialPosition ? i : firstNonMaskPos);
                    };

                    input.data($.mask.dataName, function () {
                        return $.map(buffer, function (c, i) {
                            return tests[i] && c != settings.placeholder ? c : null;
                        }).join('');
                    })

                    if (!input.attr("readonly"))
                        input
                        .one("unmask", function () {
                            input
                                .unbind(".mask")
                                .removeData($.mask.dataName);
                        })
                        .bind("focus.mask", function () {
                            focusText = input.val();
                            var pos = checkVal();
                            writeBuffer();
                            var moveCaret = function () {
                                if (pos == mask.length)
                                    input.caret(0, pos);
                                else
                                    input.caret(pos);
                            };
                            ($.browser.msie ? moveCaret : function () { setTimeout(moveCaret, 0) })();
                        })
                        .bind("blur.mask", function () {
                            checkVal();
                            if (input.val() != focusText)
                                input.change();
                        })
                        .bind("keydown.mask", keydownEvent)
                        .bind("keypress.mask", keypressEvent)
                        .bind(pasteEventName, function () {
                            setTimeout(function () { input.caret(checkVal(true)); }, 0);
                        });

                    checkVal(); //Perform initial check for existing values
                });
            }
        });
    })(jQuery);

    /*!
    
        Copyright (c) 2011 Peter van der Spek
    
        Permission is hereby granted, free of charge, to any person obtaining a copy
        of this software and associated documentation files (the "Software"), to deal
        in the Software without restriction, including without limitation the rights
        to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
        copies of the Software, and to permit persons to whom the Software is
        furnished to do so, subject to the following conditions:
    
        The above copyright notice and this permission notice shall be included in
        all copies or substantial portions of the Software.
    
        THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
        IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
        FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
        AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
        LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
        OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
        THE SOFTWARE.
        
     */
    /*!

    Copyright (c) 2011 Peter van der Spek

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
    
 */


    (function ($) {

        /**
         * Hash containing mapping of selectors to settings hashes for target selectors that should be live updated.
         *
         * @type {Object.<string, Object>}
         * @private
         */
        var liveUpdatingTargetSelectors = {};

        /**
         * Interval ID for live updater. Contains interval ID when the live updater interval is active, or is undefined
         * otherwise.
         *
         * @type {number}
         * @private
         */
        var liveUpdaterIntervalId;

        /**
         * Boolean indicating whether the live updater is running.
         *
         * @type {boolean}
         * @private
         */
        var liveUpdaterRunning = false;

        /**
         * Set of default settings.
         *
         * @type {Object.<string, string>}
         * @private
         */
        var defaultSettings = {
            ellipsis: '...',
            setTitle: 'never',
            live: false
        };

        /**
         * Perform ellipsis on selected elements.
         *
         * @param {string} selector the inner selector of elements that ellipsis may work on. Inner elements not referred to by this
         *      selector are left untouched.
         * @param {Object.<string, string>=} options optional options to override default settings.
         * @return {jQuery} the current jQuery object for chaining purposes.
         * @this {jQuery} the current jQuery object.
         */
        $.fn.ellipsis = function (selector, options) {
            var subjectElements, settings;

            subjectElements = $(this);

            // Check for options argument only.
            if (typeof selector !== 'string') {
                options = selector;
                selector = undefined;
            }

            // Create the settings from the given options and the default settings.
            settings = $.extend({}, defaultSettings, options);

            // If selector is not set, work on immediate children (default behaviour).
            settings.selector = selector;

            // Do ellipsis on each subject element.
            subjectElements.each(function () {
                var elem = $(this);

                // Do ellipsis on subject element.
                ellipsisOnElement(elem, settings);
            });

            // If live option is enabled, add subject elements to live updater. Otherwise remove from live updater.
            if (settings.live) {
                addToLiveUpdater(subjectElements.selector, settings);

            } else {
                removeFromLiveUpdater(subjectElements.selector);
            }

            // Return jQuery object for chaining.
            return this;
        };


        /**
         * Perform ellipsis on the given container.
         *
         * @param {jQuery} containerElement jQuery object containing one DOM element to perform ellipsis on.
         * @param {Object.<string, string>} settings the settings for this ellipsis operation.
         * @private
         */
        function ellipsisOnElement(containerElement, settings) {
            var containerData = containerElement.data('jqae');
            if (!containerData) containerData = {};

            // Check if wrapper div was already created and bound to the container element.
            var wrapperElement = containerData.wrapperElement;

            // If not, create wrapper element.
            if (!wrapperElement) {
                wrapperElement = containerElement.wrapInner('<div/>').find('>div');

                // Wrapper div should not add extra size.
                wrapperElement.css({
                    margin: 0,
                    padding: 0,
                    border: 0
                });
            }

            // Check if the original wrapper element content was already bound to the wrapper element.
            var wrapperElementData = wrapperElement.data('jqae');
            if (!wrapperElementData) wrapperElementData = {};

            var wrapperOriginalContent = wrapperElementData.originalContent;

            // If so, clone the original content, re-bind the original wrapper content to the clone, and replace the
            // wrapper with the clone.
            if (wrapperOriginalContent) {
                wrapperElement = wrapperElementData.originalContent.clone(true)
                        .data('jqae', { originalContent: wrapperOriginalContent }).replaceAll(wrapperElement);

            } else {
                // Otherwise, clone the current wrapper element and bind it as original content to the wrapper element.

                wrapperElement.data('jqae', { originalContent: wrapperElement.clone(true) });
            }

            // Bind the wrapper element and current container width and height to the container element. Current container
            // width and height are stored to detect changes to the container size.
            containerElement.data('jqae', {
                wrapperElement: wrapperElement,
                containerWidth: containerElement.width(),
                containerHeight: containerElement.height()
            });

            // Calculate with current container element height.
            var containerElementHeight = containerElement.height();

            // Calculate wrapper offset.
            var wrapperOffset = (parseInt(containerElement.css('padding-top'), 10) || 0) + (parseInt(containerElement.css('border-top-width'), 10) || 0) - (wrapperElement.offset().top - containerElement.offset().top);

            // Normally the ellipsis characters are applied to the last non-empty text-node in the selected element. If the
            // selected element becomes empty during ellipsis iteration, the ellipsis characters cannot be applied to that
            // selected element, and must be deferred to the previous selected element. This parameter keeps track of that.
            var deferAppendEllipsis = false;

            // Loop through all selected elements in reverse order.
            var selectedElements = wrapperElement;
            if (settings.selector) selectedElements = $(wrapperElement.find(settings.selector).get().reverse());

            selectedElements.each(function () {
                var selectedElement = $(this),
                        originalText = selectedElement.text(),
                        ellipsisApplied = false;

                // Check if we can safely remove the selected element. This saves a lot of unnecessary iterations.
                if (wrapperElement.innerHeight() - selectedElement.innerHeight() > containerElementHeight + wrapperOffset) {
                    selectedElement.remove();

                } else {
                    // Reverse recursively remove empty elements, until the element that contains a non-empty text-node.
                    removeLastEmptyElements(selectedElement);

                    // If the selected element has not become empty, start ellipsis iterations on the selected element.
                    if (selectedElement.contents().length) {

                        // If a deffered ellipsis is still pending, apply it now to the last text-node.
                        if (deferAppendEllipsis) {
                            getLastTextNode(selectedElement).get(0).nodeValue += settings.ellipsis;
                            deferAppendEllipsis = false;
                        }

                        // Iterate until wrapper element height is less than or equal to the original container element
                        // height plus possible wrapperOffset.
                        while (wrapperElement.innerHeight() > containerElementHeight + wrapperOffset) {
                            // Apply ellipsis on last text node, by removing one word.
                            ellipsisApplied = ellipsisOnLastTextNode(selectedElement);

                            // If ellipsis was succesfully applied, remove any remaining empty last elements and append the
                            // ellipsis characters.
                            if (ellipsisApplied) {
                                removeLastEmptyElements(selectedElement);

                                // If the selected element is not empty, append the ellipsis characters.
                                if (selectedElement.contents().length) {
                                    getLastTextNode(selectedElement).get(0).nodeValue += settings.ellipsis;

                                } else {
                                    // If the selected element has become empty, defer the appending of the ellipsis characters
                                    // to the previous selected element.
                                    deferAppendEllipsis = true;
                                    selectedElement.remove();
                                    break;
                                }

                            } else {
                                // If ellipsis could not be applied, defer the appending of the ellipsis characters to the
                                // previous selected element.
                                deferAppendEllipsis = true;
                                selectedElement.remove();
                                break;
                            }
                        }

                        // If the "setTitle" property is set to "onEllipsis" and the ellipsis has been applied, or if the
                        // property is set to "always", the add the "title" attribute with the original text. Else remove the
                        // "title" attribute. When the "setTitle" property is set to "never" we do not touch the "title"
                        // attribute.
                        if (((settings.setTitle == 'onEllipsis') && ellipsisApplied) || (settings.setTitle == 'always')) {
                            selectedElement.attr('title', originalText);

                        } else if (settings.setTitle != 'never') {
                            selectedElement.removeAttr('title');
                        }
                    }
                }
            });
        }

        /**
         * Performs ellipsis on the last text node of the given element. Ellipsis is done by removing a full word.
         *
         * @param {jQuery} element jQuery object containing a single DOM element.
         * @return {boolean} true when ellipsis has been done, false otherwise.
         * @private
         */
        function ellipsisOnLastTextNode(element) {
            var lastTextNode = getLastTextNode(element);

            // If the last text node is found, do ellipsis on that node.
            if (lastTextNode.length) {
                var text = lastTextNode.get(0).nodeValue;

                // Find last space character, and remove text from there. If no space is found the full remaining text is
                // removed.
                var pos = text.lastIndexOf(' ');
                if (pos > -1) {
                    text = $.trim(text.substring(0, pos));
                    lastTextNode.get(0).nodeValue = text;

                } else {
                    lastTextNode.get(0).nodeValue = '';
                }

                return true;
            }

            return false;
        }

        /**
         * Get last text node of the given element.
         *
         * @param {jQuery} element jQuery object containing a single element.
         * @return {jQuery} jQuery object containing a single text node.
         * @private
         */
        function getLastTextNode(element) {
            if (element.contents().length) {

                // Get last child node.
                var contents = element.contents();
                var lastNode = contents.eq(contents.length - 1);

                // If last node is a text node, return it.
                if (lastNode.filter(textNodeFilter).length) {
                    return lastNode;

                } else {
                    // Else it is an element node, and we recurse into it.

                    return getLastTextNode(lastNode);
                }

            } else {
                // If there is no last child node, we append an empty text node and return that. Normally this should not
                // happen, as we test for emptiness before calling getLastTextNode.

                element.append('');
                var contents = element.contents();
                return contents.eq(contents.length - 1);
            }
        }

        /**
         * Remove last empty elements. This is done recursively until the last element contains a non-empty text node.
         *
         * @param {jQuery} element jQuery object containing a single element.
         * @return {boolean} true when elements have been removed, false otherwise.
         * @private
         */
        function removeLastEmptyElements(element) {
            if (element.contents().length) {

                // Get last child node.
                var contents = element.contents();
                var lastNode = contents.eq(contents.length - 1);

                // If last child node is a text node, check for emptiness.
                if (lastNode.filter(textNodeFilter).length) {
                    var text = lastNode.get(0).nodeValue;
                    text = $.trim(text);

                    if (text == '') {
                        // If empty, remove the text node.
                        lastNode.remove();

                        return true;

                    } else {
                        return false;
                    }

                } else {
                    // If the last child node is an element node, remove the last empty child nodes on that node.
                    while (removeLastEmptyElements(lastNode)) {
                    }

                    // If the last child node contains no more child nodes, remove the last child node.
                    if (lastNode.contents().length) {
                        return false;

                    } else {
                        lastNode.remove();

                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Filter for testing on text nodes.
         *
         * @return {boolean} true when this node is a text node, false otherwise.
         * @this {Node}
         * @private
         */
        function textNodeFilter() {
            return this.nodeType === 3;
        }

        /**
         * Add target selector to hash of target selectors. If this is the first target selector added, start the live
         * updater.
         *
         * @param {string} targetSelector the target selector to run the live updater for.
         * @param {Object.<string, string>} settings the settings to apply on this target selector.
         * @private
         */
        function addToLiveUpdater(targetSelector, settings) {
            // Store target selector with its settings.
            liveUpdatingTargetSelectors[targetSelector] = settings;

            // If the live updater has not yet been started, start it now.
            if (!liveUpdaterIntervalId) {
                liveUpdaterIntervalId = window.setInterval(function () {
                    doLiveUpdater();
                }, 200);
            }
        }

        /**
         * Remove the target selector from the hash of target selectors. It this is the last remaining target selector
         * being removed, stop the live updater.
         *
         * @param {string} targetSelector the target selector to stop running the live updater for.
         * @private
         */
        function removeFromLiveUpdater(targetSelector) {
            // If the hash contains the target selector, remove it.
            if (liveUpdatingTargetSelectors[targetSelector]) {
                delete liveUpdatingTargetSelectors[targetSelector];

                // If no more target selectors are in the hash, stop the live updater.
                if (!liveUpdatingTargetSelectors.length) {
                    if (liveUpdaterIntervalId) {
                        window.clearInterval(liveUpdaterIntervalId);
                        liveUpdaterIntervalId = undefined;
                    }
                }
            }
        };

        /**
         * Run the live updater. The live updater is periodically run to check if its monitored target selectors require
         * re-applying of the ellipsis.
         *
         * @private
         */
        function doLiveUpdater() {
            // If the live updater is already running, skip this time. We only want one instance running at a time.
            if (!liveUpdaterRunning) {
                liveUpdaterRunning = true;

                // Loop through target selectors.
                for (var targetSelector in liveUpdatingTargetSelectors) {
                    $(targetSelector).each(function () {
                        var containerElement, containerData;

                        containerElement = $(this);
                        containerData = containerElement.data('jqae');

                        // If container element dimensions have changed, or the container element is new, run ellipsis on
                        // that container element.
                        if ((containerData.containerWidth != containerElement.width()) ||
                                (containerData.containerHeight != containerElement.height())) {
                            ellipsisOnElement(containerElement, liveUpdatingTargetSelectors[targetSelector]);
                        }
                    });
                }

                liveUpdaterRunning = false;
            }
        };

    })(jQuery);

    /**
 * jQuery Validation Plugin 1.9.0
 *
 * http://bassistance.de/jquery-plugins/jquery-plugin-validation/
 * http://docs.jquery.com/Plugins/Validation
 *
 * Copyright (c) 2006 - 2011 Jörn Zaefferer
 *
 * Licensed under MIT: http://www.opensource.org/licenses/mit-license.php
 */

    (function ($) {

        $.extend($.fn, {
            // http://docs.jquery.com/Plugins/Validation/validate
            validate: function (options) {

                // if nothing is selected, return nothing; can't chain anyway
                if (!this.length) {
                    options && options.debug && window.console && console.warn("nothing selected, can't validate, returning nothing");
                    return;
                }

                // check if a validator for this form was already created
                var validator = $.data(this[0], 'validator');
                if (validator) {
                    return validator;
                }

                // Add novalidate tag if HTML5.
                if (!$.browser.msie || $.browser.version > 7) {
                    this.attr('novalidate', 'novalidate');
                }

                validator = new $.validator(options, this[0]);
                $.data(this[0], 'validator', validator);

                if (validator.settings.onsubmit) {

                    var inputsAndButtons = this.find("input, button");

                    // allow suppresing validation by adding a cancel class to the submit button
                    inputsAndButtons.filter(".cancel").click(function () {
                        validator.cancelSubmit = true;
                    });

                    // when a submitHandler is used, capture the submitting button
                    if (validator.settings.submitHandler) {
                        inputsAndButtons.filter(":submit").click(function () {
                            validator.submitButton = this;
                        });
                    }

                    // validate the form on submit
                    this.submit(function (event) {
                        if (validator.settings.debug)
                            // prevent form submit to be able to see console output
                            event.preventDefault();

                        function handle() {
                            if (validator.settings.submitHandler) {
                                if (validator.submitButton) {
                                    // insert a hidden input as a replacement for the missing submit button
                                    var hidden = $("<input type='hidden'/>").attr("name", validator.submitButton.name).val(validator.submitButton.value).appendTo(validator.currentForm);
                                }
                                validator.settings.submitHandler.call(validator, validator.currentForm);
                                if (validator.submitButton) {
                                    // and clean up afterwards; thanks to no-block-scope, hidden can be referenced
                                    hidden.remove();
                                }
                                return false;
                            }
                            return true;
                        }

                        // prevent submit for invalid forms or custom submit handlers
                        if (validator.cancelSubmit) {
                            validator.cancelSubmit = false;
                            return handle();
                        }
                        if (validator.form()) {
                            if (validator.pendingRequest) {
                                validator.formSubmitted = true;
                                return false;
                            }
                            return handle();
                        } else {
                            validator.focusInvalid();
                            return false;
                        }
                    });
                }

                return validator;
            },
            // http://docs.jquery.com/Plugins/Validation/valid
            valid: function () {
                if ($(this[0]).is('form')) {
                    return this.validate().form();
                } else {
                    var valid = true;
                    var validator = $(this[0].form).validate();
                    this.each(function () {
                        valid &= validator.element(this);
                    });
                    return valid;
                }
            },
            // attributes: space seperated list of attributes to retrieve and remove
            removeAttrs: function (attributes) {
                var result = {},
                    $element = this;
                $.each(attributes.split(/\s/), function (index, value) {
                    result[value] = $element.attr(value);
                    $element.removeAttr(value);
                });
                return result;
            },
            // http://docs.jquery.com/Plugins/Validation/rules
            rules: function (command, argument) {
                var element = this[0];

                if (command) {
                    var settings = $.data(element.form, 'validator').settings;
                    var staticRules = settings.rules;
                    var existingRules = $.validator.staticRules(element);
                    switch (command) {
                        case "add":
                            $.extend(existingRules, $.validator.normalizeRule(argument));
                            staticRules[element.name] = existingRules;
                            if (argument.messages)
                                settings.messages[element.name] = $.extend(settings.messages[element.name], argument.messages);
                            break;
                        case "remove":
                            if (!argument) {
                                delete staticRules[element.name];
                                return existingRules;
                            }
                            var filtered = {};
                            $.each(argument.split(/\s/), function (index, method) {
                                filtered[method] = existingRules[method];
                                delete existingRules[method];
                            });
                            return filtered;
                    }
                }

                var data = $.validator.normalizeRules(
                $.extend(
                    {},
                    $.validator.metadataRules(element),
                    $.validator.classRules(element),
                    $.validator.attributeRules(element),
                    $.validator.staticRules(element)
                ), element);

                // make sure required is at front
                if (data.required) {
                    var param = data.required;
                    delete data.required;
                    data = $.extend({ required: param }, data);
                }

                return data;
            }
        });

        // Custom selectors
        $.extend($.expr[":"], {
            // http://docs.jquery.com/Plugins/Validation/blank
            blank: function (a) { return !$.trim("" + a.value); },
            // http://docs.jquery.com/Plugins/Validation/filled
            filled: function (a) { return !!$.trim("" + a.value); },
            // http://docs.jquery.com/Plugins/Validation/unchecked
            unchecked: function (a) { return !a.checked; }
        });

        // constructor for validator
        $.validator = function (options, form) {
            this.settings = $.extend(true, {}, $.validator.defaults, options);
            this.currentForm = form;
            this.init();
        };

        $.validator.format = function (source, params) {
            if (arguments.length == 1)
                return function () {
                    var args = $.makeArray(arguments);
                    args.unshift(source);
                    return $.validator.format.apply(this, args);
                };
            if (arguments.length > 2 && params.constructor != Array) {
                params = $.makeArray(arguments).slice(1);
            }
            if (params.constructor != Array) {
                params = [params];
            }
            $.each(params, function (i, n) {
                source = source.replace(new RegExp("\\{" + i + "\\}", "g"), n);
            });
            return source;
        };

        $.extend($.validator, {

            defaults: {
                messages: {},
                groups: {},
                rules: {},
                errorClass: "error",
                validClass: "valid",
                errorElement: "label",
                focusInvalid: true,
                errorContainer: $([]),
                errorLabelContainer: $([]),
                onsubmit: true,
                ignore: ":hidden",
                ignoreTitle: false,
                onfocusin: function (element, event) {
                    this.lastActive = element;

                    // hide error label and remove error class on focus if enabled
                    if (this.settings.focusCleanup && !this.blockFocusCleanup) {
                        this.settings.unhighlight && this.settings.unhighlight.call(this, element, this.settings.errorClass, this.settings.validClass);
                        this.addWrapper(this.errorsFor(element)).hide();
                    }
                },
                onfocusout: function (element, event) {
                    if (!this.checkable(element) && (element.name in this.submitted || !this.optional(element))) {
                        this.element(element);
                    }
                },
                onkeyup: function (element, event) {
                    if (element.name in this.submitted || element == this.lastElement) {
                        this.element(element);
                    }
                },
                onclick: function (element, event) {
                    // click on selects, radiobuttons and checkboxes
                    if (element.name in this.submitted)
                        this.element(element);
                        // or option elements, check parent select in that case
                    else if (element.parentNode.name in this.submitted)
                        this.element(element.parentNode);
                },
                highlight: function (element, errorClass, validClass) {
                    if (element.type === 'radio') {
                        this.findByName(element.name).addClass(errorClass).removeClass(validClass);
                    } else {
                        $(element).addClass(errorClass).removeClass(validClass);
                    }
                },
                unhighlight: function (element, errorClass, validClass) {
                    if (element.type === 'radio') {
                        this.findByName(element.name).removeClass(errorClass).addClass(validClass);
                    } else {
                        $(element).removeClass(errorClass).addClass(validClass);
                    }
                }
            },

            // http://docs.jquery.com/Plugins/Validation/Validator/setDefaults
            setDefaults: function (settings) {
                $.extend($.validator.defaults, settings);
            },

            messages: {
                required: "This field is required.",
                remote: "Please fix this field.",
                email: "Please enter a valid email address.",
                url: "Please enter a valid URL.",
                date: "Please enter a valid date.",
                dateISO: "Please enter a valid date (ISO).",
                number: "Please enter a valid number.",
                digits: "Please enter only digits.",
                creditcard: "Please enter a valid credit card number.",
                equalTo: "Please enter the same value again.",
                accept: "Please enter a value with a valid extension.",
                maxlength: $.validator.format("Please enter no more than {0} characters."),
                minlength: $.validator.format("Please enter at least {0} characters."),
                rangelength: $.validator.format("Please enter a value between {0} and {1} characters long."),
                range: $.validator.format("Please enter a value between {0} and {1}."),
                max: $.validator.format("Please enter a value less than or equal to {0}."),
                min: $.validator.format("Please enter a value greater than or equal to {0}.")
            },

            autoCreateRanges: false,

            prototype: {

                init: function () {
                    this.labelContainer = $(this.settings.errorLabelContainer);
                    this.errorContext = this.labelContainer.length && this.labelContainer || $(this.currentForm);
                    this.containers = $(this.settings.errorContainer).add(this.settings.errorLabelContainer);
                    this.submitted = {};
                    this.valueCache = {};
                    this.pendingRequest = 0;
                    this.pending = {};
                    this.invalid = {};
                    this.reset();

                    var groups = (this.groups = {});
                    $.each(this.settings.groups, function (key, value) {
                        $.each(value.split(/\s/), function (index, name) {
                            groups[name] = key;
                        });
                    });
                    var rules = this.settings.rules;
                    $.each(rules, function (key, value) {
                        rules[key] = $.validator.normalizeRule(value);
                    });

                    function delegate(event) {
                        var validator = $.data(this[0].form, "validator"),
                            eventType = "on" + event.type.replace(/^validate/, "");
                        validator.settings[eventType] && validator.settings[eventType].call(validator, this[0], event);
                    }
                    $(this.currentForm)
                           .validateDelegate("[type='text'], [type='password'], [type='file'], select, textarea, " +
                                "[type='number'], [type='search'] ,[type='tel'], [type='url'], " +
                                "[type='email'], [type='datetime'], [type='date'], [type='month'], " +
                                "[type='week'], [type='time'], [type='datetime-local'], " +
                                "[type='range'], [type='color'] ",
                                "focusin focusout keyup", delegate)
                        .validateDelegate("[type='radio'], [type='checkbox'], select, option", "click", delegate);

                    if (this.settings.invalidHandler)
                        $(this.currentForm).bind("invalid-form.validate", this.settings.invalidHandler);
                },

                // http://docs.jquery.com/Plugins/Validation/Validator/form
                form: function () {
                    this.checkForm();
                    $.extend(this.submitted, this.errorMap);
                    this.invalid = $.extend({}, this.errorMap);
                    if (!this.valid())
                        $(this.currentForm).triggerHandler("invalid-form", [this]);
                    this.showErrors();
                    return this.valid();
                },

                checkForm: function () {
                    this.prepareForm();
                    for (var i = 0, elements = (this.currentElements = this.elements()) ; elements[i]; i++) {
                        this.check(elements[i]);
                    }
                    return this.valid();
                },

                // http://docs.jquery.com/Plugins/Validation/Validator/element
                element: function (element) {
                    element = this.validationTargetFor(this.clean(element));
                    this.lastElement = element;
                    this.prepareElement(element);
                    this.currentElements = $(element);
                    var result = this.check(element);
                    if (result) {
                        delete this.invalid[element.name];
                    } else {
                        this.invalid[element.name] = true;
                    }
                    if (!this.numberOfInvalids()) {
                        // Hide error containers on last error
                        this.toHide = this.toHide.add(this.containers);
                    }
                    this.showErrors();
                    return result;
                },

                // http://docs.jquery.com/Plugins/Validation/Validator/showErrors
                showErrors: function (errors) {
                    if (errors) {
                        // add items to error list and map
                        $.extend(this.errorMap, errors);
                        this.errorList = [];
                        for (var name in errors) {
                            this.errorList.push({
                                message: errors[name],
                                element: this.findByName(name)[0]
                            });
                        }
                        // remove items from success list
                        this.successList = $.grep(this.successList, function (element) {
                            return !(element.name in errors);
                        });
                    }
                    this.settings.showErrors
                        ? this.settings.showErrors.call(this, this.errorMap, this.errorList)
                        : this.defaultShowErrors();
                },

                // http://docs.jquery.com/Plugins/Validation/Validator/resetForm
                resetForm: function () {
                    if ($.fn.resetForm)
                        $(this.currentForm).resetForm();
                    this.submitted = {};
                    this.lastElement = null;
                    this.prepareForm();
                    this.hideErrors();
                    this.elements().removeClass(this.settings.errorClass);
                },

                numberOfInvalids: function () {
                    return this.objectLength(this.invalid);
                },

                objectLength: function (obj) {
                    var count = 0;
                    for (var i in obj)
                        count++;
                    return count;
                },

                hideErrors: function () {
                    this.addWrapper(this.toHide).hide();
                },

                valid: function () {
                    return this.size() == 0;
                },

                size: function () {
                    return this.errorList.length;
                },

                focusInvalid: function () {
                    if (this.settings.focusInvalid) {
                        try {
                            $(this.findLastActive() || this.errorList.length && this.errorList[0].element || [])
                            .filter(":visible")
                            .focus()
                            // manually trigger focusin event; without it, focusin handler isn't called, findLastActive won't have anything to find
                            .trigger("focusin");
                        } catch (e) {
                            // ignore IE throwing errors when focusing hidden elements
                        }
                    }
                },

                findLastActive: function () {
                    var lastActive = this.lastActive;
                    return lastActive && $.grep(this.errorList, function (n) {
                        return n.element.name == lastActive.name;
                    }).length == 1 && lastActive;
                },

                elements: function () {
                    var validator = this,
                        rulesCache = {};

                    // select all valid inputs inside the form (no submit or reset buttons)
                    return $(this.currentForm)
                    .find("input, select, textarea")
                    .not(":submit, :reset, :image, [disabled]")
                    .not(this.settings.ignore)
                    .filter(function () {
                        !this.name && validator.settings.debug && window.console && console.error("%o has no name assigned", this);

                        // select only the first element for each name, and only those with rules specified
                        if (this.name in rulesCache || !validator.objectLength($(this).rules()))
                            return false;

                        rulesCache[this.name] = true;
                        return true;
                    });
                },

                clean: function (selector) {
                    return $(selector)[0];
                },

                errors: function () {
                    return $(this.settings.errorElement + "." + this.settings.errorClass, this.errorContext);
                },

                reset: function () {
                    this.successList = [];
                    this.errorList = [];
                    this.errorMap = {};
                    this.toShow = $([]);
                    this.toHide = $([]);
                    this.currentElements = $([]);
                },

                prepareForm: function () {
                    this.reset();
                    this.toHide = this.errors().add(this.containers);
                },

                prepareElement: function (element) {
                    this.reset();
                    this.toHide = this.errorsFor(element);
                },

                check: function (element) {
                    element = this.validationTargetFor(this.clean(element));

                    var rules = $(element).rules();
                    var dependencyMismatch = false;
                    for (var method in rules) {
                        var rule = { method: method, parameters: rules[method] };
                        try {
                            var result = $.validator.methods[method].call(this, element.value.replace(/\r/g, ""), element, rule.parameters);

                            // if a method indicates that the field is optional and therefore valid,
                            // don't mark it as valid when there are no other rules
                            if (result == "dependency-mismatch") {
                                dependencyMismatch = true;
                                continue;
                            }
                            dependencyMismatch = false;

                            if (result == "pending") {
                                this.toHide = this.toHide.not(this.errorsFor(element));
                                return;
                            }

                            if (!result) {
                                this.formatAndAdd(element, rule);
                                return false;
                            }
                        } catch (e) {
                            this.settings.debug && window.console && console.log("exception occured when checking element " + element.id
                                 + ", check the '" + rule.method + "' method", e);
                            throw e;
                        }
                    }
                    if (dependencyMismatch)
                        return;
                    if (this.objectLength(rules))
                        this.successList.push(element);
                    return true;
                },

                // return the custom message for the given element and validation method
                // specified in the element's "messages" metadata
                customMetaMessage: function (element, method) {
                    if (!$.metadata)
                        return;

                    var meta = this.settings.meta
                        ? $(element).metadata()[this.settings.meta]
                        : $(element).metadata();

                    return meta && meta.messages && meta.messages[method];
                },

                // return the custom message for the given element name and validation method
                customMessage: function (name, method) {
                    var m = this.settings.messages[name];
                    return m && (m.constructor == String
                        ? m
                        : m[method]);
                },

                // return the first defined argument, allowing empty strings
                findDefined: function () {
                    for (var i = 0; i < arguments.length; i++) {
                        if (arguments[i] !== undefined)
                            return arguments[i];
                    }
                    return undefined;
                },

                defaultMessage: function (element, method) {
                    return this.findDefined(
                        this.customMessage(element.name, method),
                        this.customMetaMessage(element, method),
                        // title is never undefined, so handle empty string as undefined
                        !this.settings.ignoreTitle && element.title || undefined,
                        $.validator.messages[method],
                        "<strong>Warning: No message defined for " + element.name + "</strong>"
                    );
                },

                formatAndAdd: function (element, rule) {
                    var message = this.defaultMessage(element, rule.method),
                        theregex = /\$?\{(\d+)\}/g;
                    if (typeof message == "function") {
                        message = message.call(this, rule.parameters, element);
                    } else if (theregex.test(message)) {
                        message = jQuery.format(message.replace(theregex, '{$1}'), rule.parameters);
                    }
                    this.errorList.push({
                        message: message,
                        element: element
                    });

                    this.errorMap[element.name] = message;
                    this.submitted[element.name] = message;
                },

                addWrapper: function (toToggle) {
                    if (this.settings.wrapper)
                        toToggle = toToggle.add(toToggle.parent(this.settings.wrapper));
                    return toToggle;
                },

                defaultShowErrors: function () {
                    for (var i = 0; this.errorList[i]; i++) {
                        var error = this.errorList[i];
                        this.settings.highlight && this.settings.highlight.call(this, error.element, this.settings.errorClass, this.settings.validClass);
                        this.showLabel(error.element, error.message);
                    }
                    if (this.errorList.length) {
                        this.toShow = this.toShow.add(this.containers);
                    }
                    if (this.settings.success) {
                        for (var i = 0; this.successList[i]; i++) {
                            this.showLabel(this.successList[i]);
                        }
                    }
                    if (this.settings.unhighlight) {
                        for (var i = 0, elements = this.validElements() ; elements[i]; i++) {
                            this.settings.unhighlight.call(this, elements[i], this.settings.errorClass, this.settings.validClass);
                        }
                    }
                    this.toHide = this.toHide.not(this.toShow);
                    this.hideErrors();
                    this.addWrapper(this.toShow).show();
                },

                validElements: function () {
                    return this.currentElements.not(this.invalidElements());
                },

                invalidElements: function () {
                    return $(this.errorList).map(function () {
                        return this.element;
                    });
                },

                showLabel: function (element, message) {
                    var label = this.errorsFor(element);
                    if (label.length) {
                        // refresh error/success class
                        label.removeClass(this.settings.validClass).addClass(this.settings.errorClass);

                        // check if we have a generated label, replace the message then
                        label.attr("generated") && label.html(message);
                    } else {
                        // create label
                        label = $("<" + this.settings.errorElement + "/>")
                            .attr({ "for": this.idOrName(element), generated: true })
                            .addClass(this.settings.errorClass)
                            .html(message || "");
                        if (this.settings.wrapper) {
                            // make sure the element is visible, even in IE
                            // actually showing the wrapped element is handled elsewhere
                            label = label.hide().show().wrap("<" + this.settings.wrapper + "/>").parent();
                        }
                        if (!this.labelContainer.append(label).length)
                            this.settings.errorPlacement
                                ? this.settings.errorPlacement(label, $(element))
                                : label.insertAfter(element);
                    }
                    if (!message && this.settings.success) {
                        label.text("");
                        typeof this.settings.success == "string"
                            ? label.addClass(this.settings.success)
                            : this.settings.success(label);
                    }
                    this.toShow = this.toShow.add(label);
                },

                errorsFor: function (element) {
                    var name = this.idOrName(element);
                    return this.errors().filter(function () {
                        return $(this).attr('for') == name;
                    });
                },

                idOrName: function (element) {
                    return this.groups[element.name] || (this.checkable(element) ? element.name : element.id || element.name);
                },

                validationTargetFor: function (element) {
                    // if radio/checkbox, validate first element in group instead
                    if (this.checkable(element)) {
                        element = this.findByName(element.name).not(this.settings.ignore)[0];
                    }
                    return element;
                },

                checkable: function (element) {
                    return /radio|checkbox/i.test(element.type);
                },

                findByName: function (name) {
                    // select by name and filter by form for performance over form.find("[name=...]")
                    var form = this.currentForm;
                    return $(document.getElementsByName(name)).map(function (index, element) {
                        return element.form == form && element.name == name && element || null;
                    });
                },

                getLength: function (value, element) {
                    switch (element.nodeName.toLowerCase()) {
                        case 'select':
                            return $("option:selected", element).length;
                        case 'input':
                            if (this.checkable(element))
                                return this.findByName(element.name).filter(':checked').length;
                    }
                    return value.length;
                },

                depend: function (param, element) {
                    return this.dependTypes[typeof param]
                        ? this.dependTypes[typeof param](param, element)
                        : true;
                },

                dependTypes: {
                    "boolean": function (param, element) {
                        return param;
                    },
                    "string": function (param, element) {
                        return !!$(param, element.form).length;
                    },
                    "function": function (param, element) {
                        return param(element);
                    }
                },

                optional: function (element) {
                    return !$.validator.methods.required.call(this, $.trim(element.value), element) && "dependency-mismatch";
                },

                startRequest: function (element) {
                    if (!this.pending[element.name]) {
                        this.pendingRequest++;
                        this.pending[element.name] = true;
                    }
                },

                stopRequest: function (element, valid) {
                    this.pendingRequest--;
                    // sometimes synchronization fails, make sure pendingRequest is never < 0
                    if (this.pendingRequest < 0)
                        this.pendingRequest = 0;
                    delete this.pending[element.name];
                    if (valid && this.pendingRequest == 0 && this.formSubmitted && this.form()) {
                        $(this.currentForm).submit();
                        this.formSubmitted = false;
                    } else if (!valid && this.pendingRequest == 0 && this.formSubmitted) {
                        $(this.currentForm).triggerHandler("invalid-form", [this]);
                        this.formSubmitted = false;
                    }
                },

                previousValue: function (element) {
                    return $.data(element, "previousValue") || $.data(element, "previousValue", {
                        old: null,
                        valid: true,
                        message: this.defaultMessage(element, "remote")
                    });
                }

            },

            classRuleSettings: {
                required: { required: true },
                email: { email: true },
                url: { url: true },
                date: { date: true },
                dateISO: { dateISO: true },
                dateDE: { dateDE: true },
                number: { number: true },
                numberDE: { numberDE: true },
                digits: { digits: true },
                creditcard: { creditcard: true }
            },

            addClassRules: function (className, rules) {
                className.constructor == String ?
                    this.classRuleSettings[className] = rules :
                    $.extend(this.classRuleSettings, className);
            },

            classRules: function (element) {
                var rules = {};
                var classes = $(element).attr('class');
                classes && $.each(classes.split(' '), function () {
                    if (this in $.validator.classRuleSettings) {
                        $.extend(rules, $.validator.classRuleSettings[this]);
                    }
                });
                return rules;
            },

            attributeRules: function (element) {
                var rules = {};
                var $element = $(element);

                for (var method in $.validator.methods) {
                    var value;
                    // If .prop exists (jQuery >= 1.6), use it to get true/false for required
                    if (method === 'required' && typeof $.fn.prop === 'function') {
                        value = $element.prop(method);
                    } else {
                        value = $element.attr(method);
                    }
                    if (value) {
                        rules[method] = value;
                    } else if ($element[0].getAttribute("type") === method) {
                        rules[method] = true;
                    }
                }

                // maxlength may be returned as -1, 2147483647 (IE) and 524288 (safari) for text inputs
                if (rules.maxlength && /-1|2147483647|524288/.test(rules.maxlength)) {
                    delete rules.maxlength;
                }

                return rules;
            },

            metadataRules: function (element) {
                if (!$.metadata) return {};

                var meta = $.data(element.form, 'validator').settings.meta;
                return meta ?
                    $(element).metadata()[meta] :
                    $(element).metadata();
            },

            staticRules: function (element) {
                var rules = {};
                var validator = $.data(element.form, 'validator');
                if (validator.settings.rules) {
                    rules = $.validator.normalizeRule(validator.settings.rules[element.name]) || {};
                }
                return rules;
            },

            normalizeRules: function (rules, element) {
                // handle dependency check
                $.each(rules, function (prop, val) {
                    // ignore rule when param is explicitly false, eg. required:false
                    if (val === false) {
                        delete rules[prop];
                        return;
                    }
                    if (val.param || val.depends) {
                        var keepRule = true;
                        switch (typeof val.depends) {
                            case "string":
                                keepRule = !!$(val.depends, element.form).length;
                                break;
                            case "function":
                                keepRule = val.depends.call(element, element);
                                break;
                        }
                        if (keepRule) {
                            rules[prop] = val.param !== undefined ? val.param : true;
                        } else {
                            delete rules[prop];
                        }
                    }
                });

                // evaluate parameters
                $.each(rules, function (rule, parameter) {
                    rules[rule] = $.isFunction(parameter) ? parameter(element) : parameter;
                });

                // clean number parameters
                $.each(['minlength', 'maxlength', 'min', 'max'], function () {
                    if (rules[this]) {
                        rules[this] = Number(rules[this]);
                    }
                });
                $.each(['rangelength', 'range'], function () {
                    if (rules[this]) {
                        rules[this] = [Number(rules[this][0]), Number(rules[this][1])];
                    }
                });

                if ($.validator.autoCreateRanges) {
                    // auto-create ranges
                    if (rules.min && rules.max) {
                        rules.range = [rules.min, rules.max];
                        delete rules.min;
                        delete rules.max;
                    }
                    if (rules.minlength && rules.maxlength) {
                        rules.rangelength = [rules.minlength, rules.maxlength];
                        delete rules.minlength;
                        delete rules.maxlength;
                    }
                }

                // To support custom messages in metadata ignore rule methods titled "messages"
                if (rules.messages) {
                    delete rules.messages;
                }

                return rules;
            },

            // Converts a simple string to a {string: true} rule, e.g., "required" to {required:true}
            normalizeRule: function (data) {
                if (typeof data == "string") {
                    var transformed = {};
                    $.each(data.split(/\s/), function () {
                        transformed[this] = true;
                    });
                    data = transformed;
                }
                return data;
            },

            // http://docs.jquery.com/Plugins/Validation/Validator/addMethod
            addMethod: function (name, method, message) {
                $.validator.methods[name] = method;
                $.validator.messages[name] = message != undefined ? message : $.validator.messages[name];
                if (method.length < 3) {
                    $.validator.addClassRules(name, $.validator.normalizeRule(name));
                }
            },

            methods: {

                // http://docs.jquery.com/Plugins/Validation/Methods/required
                required: function (value, element, param) {
                    // check if dependency is met
                    if (!this.depend(param, element))
                        return "dependency-mismatch";
                    switch (element.nodeName.toLowerCase()) {
                        case 'select':
                            // could be an array for select-multiple or a string, both are fine this way
                            var val = $(element).val();
                            return val && val.length > 0;
                        case 'input':
                            if (this.checkable(element))
                                return this.getLength(value, element) > 0;
                        default:
                            return $.trim(value).length > 0;
                    }
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/remote
                remote: function (value, element, param) {
                    if (this.optional(element))
                        return "dependency-mismatch";

                    var previous = this.previousValue(element);
                    if (!this.settings.messages[element.name])
                        this.settings.messages[element.name] = {};
                    previous.originalMessage = this.settings.messages[element.name].remote;
                    this.settings.messages[element.name].remote = previous.message;

                    param = typeof param == "string" && { url: param } || param;

                    if (this.pending[element.name]) {
                        return "pending";
                    }
                    if (previous.old === value) {
                        return previous.valid;
                    }

                    previous.old = value;
                    var validator = this;
                    this.startRequest(element);
                    var data = {};
                    data[element.name] = value;
                    $.ajax($.extend(true, {
                        url: param,
                        mode: "abort",
                        port: "validate" + element.name,
                        dataType: "json",
                        data: data,
                        success: function (response) {
                            validator.settings.messages[element.name].remote = previous.originalMessage;
                            var valid = response === true;
                            if (valid) {
                                var submitted = validator.formSubmitted;
                                validator.prepareElement(element);
                                validator.formSubmitted = submitted;
                                validator.successList.push(element);
                                validator.showErrors();
                            } else {
                                var errors = {};
                                var message = response || validator.defaultMessage(element, "remote");
                                errors[element.name] = previous.message = $.isFunction(message) ? message(value) : message;
                                validator.showErrors(errors);
                            }
                            previous.valid = valid;
                            validator.stopRequest(element, valid);
                        }
                    }, param));
                    return "pending";
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/minlength
                minlength: function (value, element, param) {
                    return this.optional(element) || this.getLength($.trim(value), element) >= param;
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/maxlength
                maxlength: function (value, element, param) {
                    return this.optional(element) || this.getLength($.trim(value), element) <= param;
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/rangelength
                rangelength: function (value, element, param) {
                    var length = this.getLength($.trim(value), element);
                    return this.optional(element) || (length >= param[0] && length <= param[1]);
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/min
                min: function (value, element, param) {
                    return this.optional(element) || value >= param;
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/max
                max: function (value, element, param) {
                    return this.optional(element) || value <= param;
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/range
                range: function (value, element, param) {
                    return this.optional(element) || (value >= param[0] && value <= param[1]);
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/email
                email: function (value, element) {
                    // contributed by Scott Gonzalez: http://projects.scottsplayground.com/email_address_validation/
                    return this.optional(element) || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test($.trim(value));
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/url
                url: function (value, element) {
                    // contributed by Scott Gonzalez: http://projects.scottsplayground.com/iri/
                    return this.optional(element) || /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/date
                date: function (value, element) {
                    return this.optional(element) || !/Invalid|NaN/.test(new Date(value));
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/dateISO
                dateISO: function (value, element) {
                    return this.optional(element) || /^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/.test(value);
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/number
                number: function (value, element) {
                    return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(value);
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/digits
                digits: function (value, element) {
                    return this.optional(element) || /^\d+$/.test(value);
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/creditcard
                // based on http://en.wikipedia.org/wiki/Luhn
                creditcard: function (value, element) {
                    if (this.optional(element))
                        return "dependency-mismatch";
                    // accept only spaces, digits and dashes
                    if (/[^0-9 -]+/.test(value))
                        return false;
                    var nCheck = 0,
                        nDigit = 0,
                        bEven = false;

                    value = value.replace(/\D/g, "");

                    for (var n = value.length - 1; n >= 0; n--) {
                        var cDigit = value.charAt(n);
                        var nDigit = parseInt(cDigit, 10);
                        if (bEven) {
                            if ((nDigit *= 2) > 9)
                                nDigit -= 9;
                        }
                        nCheck += nDigit;
                        bEven = !bEven;
                    }

                    return (nCheck % 10) == 0;
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/accept
                accept: function (value, element, param) {
                    param = typeof param == "string" ? param.replace(/,/g, '|') : "png|jpe?g|gif";
                    return this.optional(element) || value.match(new RegExp(".(" + param + ")$", "i"));
                },

                // http://docs.jquery.com/Plugins/Validation/Methods/equalTo
                equalTo: function (value, element, param) {
                    // bind to the blur event of the target in order to revalidate whenever the target field is updated
                    // TODO find a way to bind the event just once, avoiding the unbind-rebind overhead
                    var target = $(param).unbind(".validate-equalTo").bind("blur.validate-equalTo", function () {
                        $(element).valid();
                    });
                    return value == target.val();
                }

            }

        });

        // deprecated, use $.validator.format instead
        $.format = $.validator.format;

    })(jQuery);

    /*
        jQuery Zoom v1.7.0 - 2013-01-31
        (c) 2013 Jack Moore - jacklmoore.com/zoom
        license: http://www.opensource.org/licenses/mit-license.php
    */
    (function ($) {
        var defaults = {
            url: false,
            callback: false,
            target: false,
            duration: 120,
            on: 'mouseover' // other options: 'grab', 'click', 'toggle'
        };

        // Core Zoom Logic, independent of event listeners.
        $.zoom = function (target, source, img) {
            var outerWidth,
                outerHeight,
                xRatio,
                yRatio,
                offset,
                position = $(target).css('position');

            // The parent element needs positioning so that the zoomed element can be correctly positioned within.
            //$(target).css({
            //    position: /(absolute|fixed)/.test() ? position : 'relative',
            //    overflow: 'hidden'
            //});

            $(img)
                .addClass('zoomImg')
                .css({
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    opacity: 0,
                    width: img.width <= 640 ? 1280 : img.width,
                    height: this.width * 0.75,//img.height <= 960 ? 960 : img.height,
                    border: 'none',
                    maxWidth: 'none'
                })
                .appendTo(target);

            return {
                init: function () {
                    outerWidth = $(target).outerWidth();
                    outerHeight = $(target).outerHeight();
                    xRatio = (img.width - outerWidth) / $(source).outerWidth();
                    yRatio = (img.height - outerHeight) / $(source).outerHeight();
                    offset = $(source).offset();
                },
                move: function (e) {
                    try {
                        var left = (e.pageX - offset.left),
                            top = (e.pageY - offset.top);

                        top = Math.max(Math.min(top, outerHeight), 0);
                        left = Math.max(Math.min(left, outerWidth), 0);

                        img.style.left = (left * -xRatio) + 'px';
                        img.style.top = (top * -yRatio) + 'px';
                    } catch (ex) { }
                }
            };
        };

        $.fn.zoom = function (options) {
            return this.each(function () {
                var
                settings = $.extend({}, defaults, options || {}),
                //target will display the zoomed iamge
                target = settings.target || this,
                //source will provide zoom location info (thumbnail)
                source = this,
                img = new Image(),
                $img = $(img),
                mousemove = 'mousemove',
                clicked = false;

                // If a url wasn't specified, look for an image element.
                if (!settings.url) {
                    settings.url = $(source).find('img').attr('src');
                    if (!settings.url) {
                        return;
                    }
                }

                img.onload = function () {
                    var zoom = $.zoom(target, source, img);

                    function start(e) {
                        zoom.init();
                        zoom.move(e);

                        // Skip the fade-in for IE8 and lower since it chokes on fading-in
                        // and changing position based on mousemovement at the same time.
                        $img.stop()
                        .fadeTo($.support.opacity ? settings.duration : 0, 1);
                    }

                    function stop() {
                        $img.stop()
                        .fadeTo(settings.duration, 0);
                    }

                    if (settings.on === 'grab') {
                        $(source).mousedown(
                            function (e) {
                                $(document).one('mouseup',
                                    function () {
                                        stop();

                                        $(document).unbind(mousemove, zoom.move);
                                    }
                                );

                                start(e);

                                $(document)[mousemove](zoom.move);

                                e.preventDefault();
                            }
                        );
                    } else if (settings.on === 'click') {
                        $(source).click(
                            function (e) {
                                if (clicked) {
                                    // bubble the event up to the document to trigger the unbind.
                                    return;
                                } else {
                                    clicked = true;
                                    start(e);
                                    $(document)[mousemove](zoom.move);
                                    $(document).one('click',
                                        function () {
                                            stop();
                                            clicked = false;
                                            $(document).unbind(mousemove, zoom.move);
                                        }
                                    );
                                    return false;
                                }
                            }
                        );
                    } else if (settings.on === 'toggle') {
                        $(source).click(
                            function (e) {
                                if (clicked) {
                                    stop();
                                } else {
                                    start(e);
                                }
                                clicked = !clicked;
                            }
                        );
                    } else {
                        zoom.init(); // Pre-emptively call init because IE7 will fire the mousemove handler before the hover handler.

                        $(source).hover(
                            start,
                            stop
                        )[mousemove](zoom.move);
                    }

                    if ($.isFunction(settings.callback)) {
                        settings.callback.call(img);
                    }
                };

                img.src = settings.url;
                img.alt = $(source).find('img').attr('alt');
            });
        };

        $.fn.zoom.defaults = defaults;
    }(jQuery));


    /*
     * use age:
     * ------------[Selector]------------
       $('.className, #elementID').Selector({
            height: 40,
            defaultRows: 5	//show droplist rows, default is 8
        });
        $('.className, #elementID').Selector({
            height: 40
        });
     */
    (function ($) {
        $.fn.extend({
            /*
             * Selector
             */
            Selector: function (options) {
                var defaults = {
                    isOpen: false,
                    posClass: 'selectWrap',
                    firstChildClass: 'selectValue',
                    scrollClass: 'selectOptionsWrap',
                    childClass: 'selectItems',
                    width: '100%',
                    height: 40,
                    defaultRows: 8
                }
                var options = $.extend(defaults, options);

                return this.each(function () {
                    if (this.nodeName.toLowerCase() != 'select') return;
                    var o = options;
                    var _this = this;
                    o.label = (_this.getAttribute('label') ? _this.getAttribute('label') : null);
                    if ($.IsTouchMedia()) {
                        var posSpan = $('<span class="' + o.posClass + '"></span>');
                        posSpan.css({
                            width: o.width,
                            height: o.height,
                            overflow: 'hidden',
                            lineHeight: o.height
                        });
                        if (o.label) {
                            o.labelWidth = o.label.length * 8.2 < 91 ? '91px' : 'auto;padding-right: 8px;';
                            o.labelSpan = $('<span class="selectLabel" style="width:' +
                                            o.labelWidth + ';height:' + o.height + 'px;line-height:' +
                                            o.height + 'px;z-index:1;">' +
                                            _this.getAttribute('label') +
                                            '</span>').appendTo(posSpan);
                        }

                        posSpan.insertAfter($(this));
                        $(this).appendTo(posSpan)
                        .css({
                            float: 'right',
                            margin: '5px 0 0 0',
                            width: posSpan.width() - (o.labelSpan.width() > 91 ? o.labelSpan.width() + 10 : o.labelSpan.width() + 2),
                            height: '30px',
                            visibility: 'visible'
                        });
                        $(window).resize(function () {
                            $(_this).css({
                                width: posSpan.width() - o.labelSpan.width() - 10
                            });
                        });
                        return;
                    }
                    o.mask = $('<div class="maskBox" style="height:' + window.screen.availHeight + 'px;"></div>');
                    this.style.display = 'none';
                    CreatElement(this, o);
                })
                function CreatElement(element, o) {
                    var posSpan = $('<span class="' + o.posClass + '"></span>');
                    posSpan.css({
                        width: o.width,
                        height: o.height,
                        overflow: 'hidden',
                        lineHeight: o.height
                    });

                    if (o.label) {
                        o.labelWidth = o.label.length * 8.2 < 91 ? '91px' : 'auto;padding-right: 8px;';
                        o.labelSpan = $('<span class="selectLabel" style="width:' +
                                        o.labelWidth + ';height:' + o.height + 'px;line-height:' +
                                        o.height + 'px;z-index:1;">' +
                                        element.getAttribute('label') +
                                        '</span>').appendTo(posSpan)
                        .click(function () {
                            selectValueSpan.trigger('click');
                        });
                    }

                    var selectValueSpan = $('<span  class="' + o.firstChildClass + '"></span>'),
                        html = element.options[element.options.selectedIndex].text,
                        left = (o.label ? o.label.width + 'px' : '');

                    selectValueSpan.html(html)
                    .css({
                        height: o.height,
                        lineHeight: o.height + 'px'
                    })
                    .click(function () {
                        if (element.disabled) return;
                        OpenOrCloseList(posSpan, element, o);
                    })

                    var scrollSpan = $('<span class="' + o.scrollClass + '"></span>');
                    scrollSpan.css({
                        width: o.width,
                        height: ((element.options.length + 1) > o.defaultRows ? o.defaultRows : (element.options.length + 1)) * o.height + 'px',
                        lineHeight: o.height + 'px',
                        textIndent: left
                    });

                    selectValueSpan.appendTo(posSpan);

                    posSpan.insertAfter(element);
                    o.arrow = $('<b class="iconArrowDown" style="right:20px;top:' +
                                (o.height - 4) * 0.5 + 'px"></b>')
                                .appendTo(selectValueSpan);
                    if (element.disabled) {
                        posSpan.addClass('disabled');
                        return;
                    }
                    scrollSpan.appendTo(posSpan);
                    InsertOptions(element, posSpan, selectValueSpan, scrollSpan, o);
                }
                function InsertOptions(element, posSpan, selectValueSpan, scrollSpan, o) {
                    var optionsNum = element.options.length;
                    for (var i = 0; i < optionsNum; i++) {
                        var childSpan = $('<span name="' + i + '" class="' + o.childClass + ' ' + element.options[i].className + '"></span>'),
                            html = element.options[i].text,
                            left = (o.label ? o.label.width + 'px' : '');
                        childSpan.css({
                            height: o.height + 'px',
                            lineHeight: o.height + 'px',
                            textIndent: left
                        })
                        .attr('title', html)
                        .html(html)
                        .click(function () {
                            ChangeValue($(this), posSpan, selectValueSpan, element, o);
                        })
                        .mouseover(function () {
                            $(this).addClass('hover');
                        })
                        .mouseout(function () {
                            $(this).removeClass('hover');
                        })
                        .appendTo(scrollSpan);
                    }
                }
                function OpenOrCloseList(posSpan, element, o) {
                    if (o.isOpen) { // to close
                        o.mask.remove().css('z-index', '');
                        posSpan.css({
                            overflow: 'hidden',
                            zIndex: ''
                        });
                        o.isOpen = false;
                    } else {//to open
                        posSpan.css({
                            overflow: '',
                            zIndex: 9999
                        });
                        o.mask.click(function () {
                            SelectisOpen = true;
                            OpenOrCloseList(posSpan, element, o);
                        }).appendTo($(element).parent());
                        o.isOpen = true;
                    }
                }
                function ChangeValue(childSpan, posSpan, selectValueSpan, element, o) {
                    element.options[element.selectedIndex].selected = false;
                    element.options[childSpan.attr('name')].selected = true;
                    selectValueSpan.html(childSpan.html()).append(o.arrow);
                    o.isOpen = true;
                    OpenOrCloseList(posSpan, element, o);
                    $(element).trigger('change');
                }
            },
            /*
             * pic zoom
             */
            Zoom: function (options) {
                return this.each(function () {
                    var o = options;
                    if (!o) return;
                    var _this = this;
                    if (($(window).width() <= 768 || $.IsTouchMedia()) && !($.IsIE(6) || $.IsIE(7) || $.IsIE(8))) {
                        this.layout = 'mobile';
                        this.currentlayout = 'mobile';
                    } else {
                        this.layout = 'pc';
                        this.currentlayout = 'pc';
                    }
                    $(window).resize(function () {
                        if ($.IsIE(6) || $.IsIE(7) || $.IsIE(8)) return;
                        if ($(window).width() <= 768 || $.IsTouchMedia()) {
                            _this.currentlayout = 'mobile';
                        } else {
                            _this.currentlayout = 'pc';
                        }
                        if (_this.layout != _this.currentlayout) {
                            if (_this.currentlayout == 'mobile') {
                                InitMobile(_this, o);
                                _this.layout = 'mobile';
                            }
                            if (_this.currentlayout == 'pc') {
                                InitWebsite(_this, o);
                                _this.layout = 'pc';
                            }
                        }
                    });
                    if (this.layout == 'mobile') {
                        InitMobile(this, o);
                    }
                    if (this.layout == 'pc') {
                        InitWebsite(this, o);
                    }
                    function InitMobile(_this, o) {
                        var opt = o[0];
                        $(_this).empty();
                        $('#Thumbnails').remove();
                        var canvas = _this,
                            ul = $('<ul class="swiper-wrapper"></ul>'),
                            //indexBox = $('<div class="indexBox"><span>1</span> of ' + opt.length + '</div>'),
                            //current = indexBox.find('span'),
                            thumbnail = $('<div class="thumbnail"></div>'),
                            slider, index;

                        for (var i = 0; i < opt.length; i++) {
                            var img = $('<img index="' + i + '" src="' + (opt[i].normalUrl == '' ? o[1].defaultImage : opt[i].normalUrl) + '">');
                            var _display = i == 0 ? 'block' : 'none';
                            var a = $('<a href="' + canvas.getAttribute("zoom") + '"></a>'),
                                li = $('<li style="display:' + _display + '"></li>');

                            //if (opt[i].current) index = i;
                            //current.text(index + 1);
                            img.appendTo(a).error(function () {
                                this.src = o[1].defaultImage;

                                // var _parent = this.parentNode;
                                // _parent.removeChild(this);
                                // var _img = $('<img src="' + o[1].defaultImage + '">');
                                // _img.appendTo(_parent);
                            });
                            a.appendTo(li);
                            li.appendTo(ul);
                        }
                        ul.appendTo($(_this));
                        // indexBox.appendTo($(_this));
                        thumbnail.appendTo($(_this));


                        $(_this).height($(_this).width() * 0.75);

                        setTimeout(function () {
                            $(_this).find('li').addClass('swiper-slide').show();

                            if (opt.length > 1) {
                                slider = new Swiper('#' + _this.id, {
                                    pagination: '.thumbnail',
                                    paginationActiveClass: 'current',
                                    paginationClickable: true,
                                    loop: true,
                                    grabCursor: false,
                                    onSlideChangeEnd: function () {
                                        var _index = slider.activeLoopIndex;
                                        $('#Thumbnails img').eq(_index).addClass('current').siblings().removeClass();
                                        // current.text(_index + 1);
                                    }
                                });
                            } else {
                                slider = new Swiper('#' + _this.id, {
                                    createPagination: false,
                                    followFinger: false,
                                    loop: false,
                                    grabCursor: false
                                });
                            }

                            $(window).resize(function () {
                                $(_this).height($(_this).width() * 0.75);
                            });
                        }, 100)
                    }

                    function InitWebsite(_this, o) {
                        var _maxW = $.IsTouchMedia() ? 1024 : 1024;
                        var opt = o[0];
                        $(_this).empty();
                        var canvas = _this,
                            thumbnails = $('<div id="Thumbnails" class="smallpic fix"></div'),
                            outer = $('<div class="thumbnailOuter"></div>'),
                            inner = $('<div class="thumbnailInner"></div>');
                        thumbnails.index = 0;
                        if ($(window).width() >= _maxW || $.IsIE(7) || $.IsIE(8)) {
                            inner.css({ 'height': opt.length * 77 + 17, 'width': 'auto' });
                            if (opt.length <= 1) {
                                $('.mainpic').addClass('single');
                            }
                        } else {
                            $('.mainpic').removeClass('single');
                            inner.css({ 'width': opt.length * 90 + 10, 'height': 'auto' });
                        }

                        $(window).resize(function () {
                            if ($.IsIE(7) || $.IsIE(8)) { return; }
                            if ($(window).width() >= _maxW) {
                                inner.css('height', opt.length * 77 + 17);
                                if (parseInt(inner.css('left')) < 0) {
                                    inner.css({ 'top': (parseInt(inner.css('left')) / 90) * 77, 'left': 0 });
                                }
                                if (opt.length <= 1) {
                                    $('.mainpic').addClass('single');
                                }
                            } else {
                                $('.mainpic').removeClass('single');
                                inner.css('width', opt.length * 90 + 10);
                                if (parseInt(inner.css('top')) < 0) {
                                    inner.css({ 'left': (parseInt(inner.css('top')) / 77) * 90, 'top': 0 });
                                }
                            }
                        })
                        for (var i = 0; i < opt.length; i++) {
                            opt[i].normalUrl = opt[i].normalUrl == '' ? o[1].defaultImage : opt[i].normalUrl;
                            opt[i].thumbnailUrl = opt[i].thumbnailUrl == '' ? o[1].defaultImage : opt[i].thumbnailUrl;
                            var id = 'tmp-' + parseInt(Math.random(100000) * 100000), timer,
                                box = $('<div id="' + id + '" class="item ' + (opt[i].current ? 'current' : '') + '"></div>'),
                                img = $('<img src="' + (opt[i].bigUrl == 'null' ? opt[i].normalUrl : opt[i].bigUrl) + '" alt="' + opt[i].description + '">'),
                                thumbnail = $('<img for="' + id + '" class="' + (opt[i].current ? 'current' : '') + '" src="' + opt[i].thumbnailUrl + '" alt="' + opt[i].description + '">');
                            if (opt[i].current) thumbnails.index = i;
                            img.appendTo(box).error(function () {
                                this.src = o[1].defaultImage;
                            });

                            if (opt[i].bigUrl !== 'null') {
                                box.zoom().hover(function () {
                                    $(this).css('z-index', '9999');
                                    $(canvas).css('z-index', '9999');
                                }, function () {
                                    $(this).css('z-index', '');
                                    $(canvas).css('z-index', '');
                                });
                            }
                            box.appendTo($(canvas));
                            thumbnail.appendTo(inner)
                            .mouseover(function () {
                                thumbnails.index = inner.find('img').index(this);
                                Show(opt, thumbnails, next, prev);
                            }).error(function () {
                                this.src = o[1].defaultImage;
                            });
                        }

                        inner.appendTo(outer);
                        outer.appendTo(thumbnails);
                        thumbnails.insertAfter($(canvas));
                        if (opt.length <= 1) {
                            thumbnails.hide();
                        }

                        if (opt.length > 5) {
                            var prev = $('<div class="prev disabled"></div>'),
                                next = $('<div class="next"></div>');
                            prev.click(function () {
                                if (!$(this).hasClass('disabled')) {
                                    thumbnails.index = inner.find('img').index(inner.find('img.current'));
                                    if (thumbnails.index % 5 == 0) {
                                        if ($(window).width() >= _maxW || $.IsIE(7) || $.IsIE(8)) {
                                            inner.animate({
                                                top: '+=' + outer.height()
                                            }, 250);
                                        } else {
                                            inner.animate({
                                                left: '+=' + outer.width()
                                            }, 250);
                                        }
                                    }
                                    thumbnails.index--;
                                    Show(opt, thumbnails, next, prev);
                                }
                            })
                            .insertBefore(outer);
                            next.click(function () {
                                if (!$(this).hasClass('disabled')) {
                                    thumbnails.index = inner.find('img').index(inner.find('img.current'));
                                    thumbnails.index++;
                                    Show(opt, thumbnails, next, prev);
                                    if (thumbnails.index % 5 == 0) {
                                        if ($(window).width() >= _maxW || $.IsIE(7) || $.IsIE(8)) {
                                            inner.animate({
                                                top: '-=' + outer.height()
                                            }, 250);
                                        } else {
                                            inner.animate({
                                                left: '-=' + outer.width()
                                            }, 250);
                                        }
                                    }
                                }
                            })
                            .appendTo(thumbnails);
                        }
                    }
                    function Show(o, thumbnails, next, prev) {
                        if (o.length > 5) {
                            if (thumbnails.index == 0) {
                                next.removeClass('disabled');
                                prev.addClass('disabled');
                            }
                            if (thumbnails.index == o.length - 1) {
                                prev.removeClass('disabled');
                                next.addClass('disabled');
                            }
                            if (thumbnails.index > 0 && thumbnails.index < o.length - 1) {
                                next.removeClass('disabled')
                                prev.removeClass('disabled');
                            }
                        }

                        thumbnails.find('img:eq(' + thumbnails.index + ')').addClass('current').siblings().removeClass('current');
                        var id = thumbnails.find('img:eq(' + thumbnails.index + ')').addClass('current').attr('for');
                        $('#' + id).addClass('current').siblings().removeClass('current');
                    }
                });
            }
        });
    })(jQuery);

    /*
 * Slider and banner
 * Trey.Y.Liu@Newegg.com
 */
    ; (function ($) {
        $.fn.extend({
            BannerSlider: function (options) {
                var defaults = {
                    pagination: '.thumbnail',
                    paginationActiveClass: 'current',
                    loop: true,
                    grabCursor: false,
                    paginationClickable: true,
                    autoplay: 4000
                };

                var _opt = $.extend({}, defaults, options);

                var _self = $(this);
                var _isSingle = _self.find('img').length < 2;

                if (_isSingle) {
                    _opt = $.extend({}, _opt, { 'onlyExternal': true, 'autoplay': false });
                }

                var _bannerSwiper = new Swiper('#' + _self.attr('id'), _opt);

                _self.find('.swiper-slide').show();

                var _slidePrev = _self.find('.slide_prev'),
                    _slideNext = _self.find('.slide_next');

                function adjustHeight() {
                    var _selfHeight;

                    if (!$.IsIE(7) && !$.IsIE(8)) {
                        var _chrome = (navigator.userAgent.indexOf('Safari') >= 0 && $(window).width() > 751 && $(window).width() <= 768 && $('#Logo').width() == 116)
                        var _widthLimit_1 = 623,
                            _widthLimit_2 = $.IsTouchMedia() || _chrome ? 768 : 751;

                        var _winWidth = $(window).width();
                        if (_winWidth > 0 && _winWidth <= 320) {
                            _selfHeight = 140;
                        } else if (_winWidth > 320 && _winWidth <= _widthLimit_1) {
                            _selfHeight = (_winWidth * 1.5) * 280 / 960;
                        } else if (_winWidth > _widthLimit_1 && _winWidth <= _widthLimit_2) {
                            _selfHeight = _winWidth * 280 / 960;
                        } else {
                            _selfHeight = 280;
                        }
                    }
                    _self.height(_selfHeight);
                }

                adjustHeight();

                if (!_isSingle) {
                    $(_bannerSwiper.container).hover(function () {
                        var _bannerHeight = _self.outerHeight() / 2 - 40;
                        _slidePrev.css('top', _bannerHeight).animate({ 'left': 0 }, 200);
                        _slideNext.css('top', _bannerHeight).animate({ 'right': 0 }, 200);
                        _bannerSwiper.stopAutoplay();
                    }, function () {
                        _slidePrev.animate({ 'left': -40 }, 200);
                        _slideNext.animate({ 'right': -40 }, 200);
                        _bannerSwiper.startAutoplay();
                    })

                    _slidePrev.on('click', function (e) {
                        e.preventDefault();
                        _bannerSwiper.swipePrev();
                    })
                    _slideNext.on('click', function (e) {
                        e.preventDefault();
                        _bannerSwiper.swipeNext();
                    });
                } else {
                    _self.find('.thumbnail').hide();
                }

                var _resizeTimer;
                $(window).resize(function () {
                    clearTimeout(_resizeTimer);
                    _resizeTimer = setTimeout(function () {
                        adjustHeight();

                        if ($(window).width() < 768) {
                            if (!_isSingle) {
                                _slidePrev.hide();
                                _slideNext.hide();
                            }
                        } else {
                            if (!_isSingle) {
                                _slidePrev.show();
                                _slideNext.show();
                            }
                        }
                    }, 10);
                });

                return _bannerSwiper;
            },
            ClickSlider: function (options) {
                var defaults = {
                    Speed: 180
                };
                var opts = $.extend(defaults, options);
                $(window).resize(function () {
                    $('.sale_time_cover').hide().stop();
                })

                $(this).find('.sale_time').addClass('sale_time_cover').hide();
                $(this).click(function () {
                    $(this).find('.sale_time').stop();
                    if ($(this).find('.sale_time').is(':visible')) {
                        return;
                    }
                    var _height = "100%";
                    $(this).find('.sale_time').css({ 'height': _height, 'line-height': _height + 'px', 'top': _height })
                                               .show()
                                               .animate({ 'top': 0 }, opts.Speed)
                                               .delay(2000)
                                               .animate({ 'top': $(this).find('img').height() }, opts.Speed, function () {
                                                   $(this).hide();
                                               });
                });
            },
            HoverSlider: function (options) {
                if ($.IsTouchMedia()) {
                    return;
                }
                var _isInit = false;
                var _self = this;
                if ($(window).width() <= 768) {
                    $(window).resize(function () {
                        if ($(window).width() >= 768 && !_isInit) {
                            hover(_self, options);
                        }
                    });
                } else {
                    hover(_self, options)
                }

                function hover(self, options) {
                    _isInit = true;

                    var defaults = {
                        Speed: 180,
                        AllwaysShow: false,
                        Style: null
                    }
                    var options = $.extend(defaults, options);

                    return self.each(function () {
                        if (typeof this != 'object') return false;

                        this.o = options;
                        this.a = $(this).find('>a');
                        this.wrap = this.a.find('>.wrap');
                        this.imgs = $(this).find('img');
                        this.price = $(this).find('.price');
                        this.saleTime = $(this).find('.sale_time');
                        this.fullTitle = $(this).find('h3').text();
                        this.info = $(this).find('.info');
                        this.description = $(this).find('.info p').text();
                        this.infoHeight = this.info.outerHeight(true);
                        this.isInserted = false;

                        ResizeHover(this);

                        var _this = this;
                        $(window).resize(function () {
                            if ($(window).width() <= 768) {
                                $(_this).unbind('hover');
                                _this._isHovered = false;
                            } else {
                                ResizeHover(_this);
                            }
                        });
                    });
                }

                function mouseover(_this) {
                    var speed = _this.o.Speed;
                    if (_this.o.Style == 'small') {
                        if (!_this.isInserted) {
                            CreatCanvas(_this);
                        }
                        if (!_this.box.is(':animated') &&
                            !_this.wrap.is(':animated')) {
                            _this.box.animate({
                                bottom: 0
                            }, speed);
                            _this.wrap.animate({
                                top: -_this.a.outerHeight(true)
                            }, speed);
                        }
                    } else { // base style
                        if (!_this.saleTime.is(':animated')) {
                            _this.saleTime.animate({
                                bottom: _this.info.outerHeight(true)
                            }, speed);
                        }
                    }
                }

                function mouseout(_this) {
                    var speed = _this.o.Speed;
                    if (_this.o.Style == 'small') {
                        _this.box.clearQueue().stop()
                        .animate({
                            bottom: -_this.box.outerHeight(true)
                        }, speed);
                        _this.wrap.clearQueue().stop()
                        .animate({
                            top: 0
                        }, speed);
                    } else {
                        _this.saleTime.clearQueue().stop()
                        .animate({
                            bottom: -_this.infoHeight
                        }, speed);
                    }
                }

                function CreatCanvas(_this) {
                    var height = _this.imgs.outerHeight(true),
                        top = ((height < 280 ? 280 : height) - 80) * 0.5, imgs1;
                    if (_this.o.Style == 'small') { // for up slider
                        var isActivity = $(_this).find('.price').clone()[0] ? false : true;
                        var title = $('<div class="fullTitle">' + _this.fullTitle + '</div>');
                        var wrap = $('<div class="wrap"></div>');
                        var smallImg = $('<img src="' + _this.imgs[0].src + '">');
                        _this.box = $('<div class="boxA_info"></div>');
                        wrap.append(smallImg);
                        wrap.append(_this.price.clone());
                        wrap.append(title);
                        if (isActivity) {
                            var description = $('<p>' + _this.description + '</p>');
                            description.css('margin-bottom', '8px');
                            wrap.append(description);
                            title.css('max-height', '63px');
                        }
                        _this.box.append(wrap);
                        wrap.append(_this.saleTime.clone().removeClass().addClass('endTime'));
                        _this.box.css({
                            border: '1px solid #e8e8e8',
                            width: _this.a.width() - 40,
                            height: _this.a.height() - 42
                        }).appendTo(_this.a)
                    }
                    _this.isInserted = true;

                    $(window).resize(function () {
                        if (_this.box && $(window).width() > 768) {
                            _this.box.css({
                                bottom: -_this.box.outerHeight(true),
                                width: _this.a.width() - 40,
                                height: _this.a.height() - 42
                            });
                        }
                    });
                }

                function ResizeHover(_this) {
                    if (!_this._isHovered) {
                        $(_this).hover(function () {
                            mouseover(_this);
                        }, function () {
                            mouseout(_this);
                        });
                        _this._isHovered = true;
                    }
                }

            }
        });
    })(jQuery);

    /*
 * textarea auto height
 * textarea word count
 * Dell.J.Du@newegg.com
 */
    !function (window, $, undefined) {
        var TextareaFix = (function () {
            var KEYCODE = [8, 35, 36, 37, 38, 39, 40];
            function TextareaFix(bindDom, options) {
                this.$this = bindDom;
                this.setOptions(options);
                this.render();
            }

            TextareaFix.prototype.defaultOpts = {
                limitLen: false,
                limitNum: 500,
                counterElement: '.counter',
                beforeCallback: function (self) { }
            };

            TextareaFix.prototype.setOptions = function (options) {
                this.opts = $.extend({}, this.defaultOpts, options);
            };

            TextareaFix.prototype.calculate = function (obj) {
                var self = this.$this;
                var opts = this.opts;
                if (opts.limitLen) {
                    var _count = self.val().length;

                    if (_count > opts.limitNum) {
                        self.val(self.val().substring(0, opts.limitNum));
                        _count = opts.limitNum;
                    }

                    if (_count == opts.limitNum) {
                        $(opts.counterElement).css('color', 'red');
                    }
                    else {
                        $(opts.counterElement).css('color', '#7f7f7f');
                    }
                    $(opts.counterElement).html(_count);
                }

                var content = self.val();
                content = content.replace(/\n/g, '<br>');

                $('.hiddendiv').css('width', self.width()).html(content + '<br class="lbr">');

                self.css('height', $('.hiddendiv').height());

                if ($('.hiddendiv').height() > 300) {
                    self.addClass('textareaMax');
                }
                else {
                    self.removeClass('textareaMax');
                }
            };

            TextareaFix.prototype.bindEvent = function () {
                var _self = this;
                $(window).bind('resize.' + _self.$this.constructor.expando, function () {
                    _self.opts.resizeBeforeCallback(_self.$this);
                    _self.calculate(_self.$this);
                });
            };

            TextareaFix.prototype.unBindEvent = function () {
                $(window).unbind('.' + this.$this.constructor.expando);
            };

            TextareaFix.prototype.render = function () {
                var opts = this.opts;
                var _self = this;

                if ($('.hiddendiv').length == 0) {
                    var hiddenDiv = $(document.createElement('div'));
                    hiddenDiv.addClass('hiddendiv textarea');
                    $('body').append(hiddenDiv);
                }
                opts.beforeCallback(this.$this);

                this.$this.addClass('txtstuff');

                _self.calculate();

                this.$this.keydown(function (e) {
                    if ($(opts.counterElement).html() == opts.limitNum && ((KEYCODE.indexOf(e.keyCode) < 0 && e.ctrlKey != true)
                         || (e.ctrlKey == true && e.keyCode == 86))) {
                        return false;
                    }
                });

                this.$this.keyup(function (e) {
                    _self.calculate();
                });
                this.$this.change(function () {
                    _self.calculate();
                });
                this.bindEvent();

                return this;
            };
            return TextareaFix;
        })();
        $.fn.TextareaFix = function (opts) {
            var $this = $(this),
                data = $this.data();

            if (data.TextareaFix) {
                delete data.TextareaFix;
            }
            if (opts !== false) {
                data.TextareaFix = new TextareaFix($this, opts);
            }

            return data.TextareaFix;
        };
    }
 (window, jQuery);

    // ajax mode: abort
    // usage: $.ajax({ mode: "abort"[, port: "uniqueport"]});
    // if mode:"abort" is used, the previous request on that port (port can be undefined) is aborted via XMLHttpRequest.abort()
    ; (function ($) {
        var pendingRequests = {};
        // Use a prefilter if available (1.5+)
        if ($.ajaxPrefilter) {
            $.ajaxPrefilter(function (settings, _, xhr) {
                var port = settings.port;
                if (settings.mode == "abort") {
                    if (pendingRequests[port]) {
                        pendingRequests[port].abort();
                    }
                    pendingRequests[port] = xhr;
                }
            });
        } else {
            // Proxy ajax
            var ajax = $.ajax;
            $.ajax = function (settings) {
                var mode = ("mode" in settings ? settings : $.ajaxSettings).mode,
                    port = ("port" in settings ? settings : $.ajaxSettings).port;
                if (mode == "abort") {
                    if (pendingRequests[port]) {
                        pendingRequests[port].abort();
                    }
                    return (pendingRequests[port] = ajax.apply(this, arguments));
                }
                return ajax.apply(this, arguments);
            };
        }
    })(jQuery);

    // provides cross-browser focusin and focusout events
    // IE has native support, in other browsers, use event caputuring (neither bubbles)

    // provides delegate(type: String, delegate: Selector, handler: Callback) plugin for easier event delegation
    // handler is only called when $(event.target).is(delegate), in the scope of the jquery-object for event.target
    ; (function ($) {
        // only implement if not provided by jQuery core (since 1.4)
        // TODO verify if jQuery 1.4's implementation is compatible with older jQuery special-event APIs
        if (!jQuery.event.special.focusin && !jQuery.event.special.focusout && document.addEventListener) {
            $.each({
                focus: 'focusin',
                blur: 'focusout'
            }, function (original, fix) {
                $.event.special[fix] = {
                    setup: function () {
                        this.addEventListener(original, handler, true);
                    },
                    teardown: function () {
                        this.removeEventListener(original, handler, true);
                    },
                    handler: function (e) {
                        arguments[0] = $.event.fix(e);
                        arguments[0].type = fix;
                        return $.event.handle.apply(this, arguments);
                    }
                };
                function handler(e) {
                    e = $.event.fix(e);
                    e.type = fix;
                    return $.event.handle.call(this, e);
                }
            });
        };
        $.extend($.fn, {
            validateDelegate: function (delegate, type, handler) {
                return this.bind(type, function (event) {
                    var target = $(event.target);
                    if (target.is(delegate)) {
                        return handler.apply(target, arguments);
                    }
                });
            }
        });
    })(jQuery);

    /*!
** Unobtrusive validation support library for jQuery and jQuery Validate
** Copyright (C) Microsoft Corporation. All rights reserved.
*/

    /*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true, strict: false */
    /*global document: false, jQuery: false */

    (function ($) {
        var $jQval = $.validator,
            adapters,
            data_validation = "unobtrusiveValidation";

        function setValidationValues(options, ruleName, value) {
            options.rules[ruleName] = value;
            if (options.message) {
                options.messages[ruleName] = options.message;
            }
        }

        function splitAndTrim(value) {
            return value.replace(/^\s+|\s+$/g, "").split(/\s*,\s*/g);
        }

        function escapeAttributeValue(value) {
            // As mentioned on http://api.jquery.com/category/selectors/
            return value.replace(/([!"#$%&'()*+,./:;<=>?@\[\\\]^`{|}~])/g, "\\$1");
        }

        function getModelPrefix(fieldName) {
            return fieldName.substr(0, fieldName.lastIndexOf(".") + 1);
        }

        function appendModelPrefix(value, prefix) {
            if (value.indexOf("*.") === 0) {
                value = value.replace("*.", prefix);
            }
            return value;
        }

        function onError(error, inputElement) {  // 'this' is the form element
            var container = $(this).find("[data-valmsg-for='" + escapeAttributeValue(inputElement[0].name) + "']"),
                replace = $.parseJSON(container.attr("data-valmsg-replace")) !== false;

            container.removeClass("field-validation-valid").addClass("field-validation-error");
            error.data("unobtrusiveContainer", container);

            if (replace) {
                container.empty();
                error.removeClass("input-validation-error").appendTo(container);
            }
            else {
                error.hide();
            }
            $(window).resize();
        }

        function onErrors(event, validator) {  // 'this' is the form element
            var container = $(this).find("[data-valmsg-summary=true]"),
                list = container.find("ul");

            if (list && list.length && validator.errorList.length) {
                list.empty();
                container.addClass("validation-summary-errors").removeClass("validation-summary-valid");

                $.each(validator.errorList, function () {
                    $("<li />").html(this.message).appendTo(list);
                });
            }
            $(window).resize();
        }

        function onSuccess(error) {  // 'this' is the form element
            var container = error.data("unobtrusiveContainer"),
                replace = $.parseJSON(container.attr("data-valmsg-replace"));

            if (container) {
                container.addClass("field-validation-valid").removeClass("field-validation-error");
                error.removeData("unobtrusiveContainer");

                if (replace) {
                    container.empty();
                }
            }
            $(window).resize();
        }

        function onReset(event) {  // 'this' is the form element
            var $form = $(this);
            $form.data("validator").resetForm();
            $form.find(".validation-summary-errors")
                .addClass("validation-summary-valid")
                .removeClass("validation-summary-errors");
            $form.find(".field-validation-error")
                .addClass("field-validation-valid")
                .removeClass("field-validation-error")
                .removeData("unobtrusiveContainer")
                .find(">*")  // If we were using valmsg-replace, get the underlying error
                    .removeData("unobtrusiveContainer");
            $(window).resize();
        }

        function validationInfo(form) {
            var $form = $(form),
                result = $form.data(data_validation),
                onResetProxy = $.proxy(onReset, form);

            if (!result) {
                result = {
                    options: {  // options structure passed to jQuery Validate's validate() method
                        errorClass: "input-validation-error",
                        errorElement: "span",
                        errorPlacement: $.proxy(onError, form),
                        invalidHandler: $.proxy(onErrors, form),
                        messages: {},
                        rules: {},
                        success: $.proxy(onSuccess, form)
                    },
                    attachValidation: function () {
                        $form
                            .unbind("reset." + data_validation, onResetProxy)
                            .bind("reset." + data_validation, onResetProxy)
                            .validate(this.options);
                    },
                    validate: function () {  // a validation function that is called by unobtrusive Ajax
                        $form.validate();
                        return $form.valid();
                    }
                };
                $form.data(data_validation, result);
            }

            return result;
        }

        $jQval.unobtrusive = {
            adapters: [],

            parseElement: function (element, skipAttach) {
                /// <summary>
                /// Parses a single HTML element for unobtrusive validation attributes.
                /// </summary>
                /// <param name="element" domElement="true">The HTML element to be parsed.</param>
                /// <param name="skipAttach" type="Boolean">[Optional] true to skip attaching the
                /// validation to the form. If parsing just this single element, you should specify true.
                /// If parsing several elements, you should specify false, and manually attach the validation
                /// to the form when you are finished. The default is false.</param>
                var $element = $(element),
                    form = $element.parents("form")[0],
                    valInfo, rules, messages;

                if (!form) {  // Cannot do client-side validation without a form
                    return;
                }

                valInfo = validationInfo(form);
                valInfo.options.rules[element.name] = rules = {};
                valInfo.options.messages[element.name] = messages = {};

                $.each(this.adapters, function () {
                    var prefix = "data-val-" + this.name,
                        message = $element.attr(prefix),
                        paramValues = {};

                    if (message !== undefined) {  // Compare against undefined, because an empty message is legal (and falsy)
                        prefix += "-";

                        $.each(this.params, function () {
                            paramValues[this] = $element.attr(prefix + this);
                        });

                        this.adapt({
                            element: element,
                            form: form,
                            message: message,
                            params: paramValues,
                            rules: rules,
                            messages: messages
                        });
                    }
                });

                $.extend(rules, { "__dummy__": true });

                if (!skipAttach) {
                    valInfo.attachValidation();
                }
            },

            parse: function (selector) {
                /// <summary>
                /// Parses all the HTML elements in the specified selector. It looks for input elements decorated
                /// with the [data-val=true] attribute value and enables validation according to the data-val-*
                /// attribute values.
                /// </summary>
                /// <param name="selector" type="String">Any valid jQuery selector.</param>
                var $forms = $(selector)
                    .parents("form")
                    .andSelf()
                    .add($(selector).find("form"))
                    .filter("form");

                $(selector).find(":input[data-val=true]").each(function () {
                    $jQval.unobtrusive.parseElement(this, true);
                });

                $forms.each(function () {
                    var info = validationInfo(this);
                    if (info) {
                        info.attachValidation();
                    }
                });
            }
        };

        adapters = $jQval.unobtrusive.adapters;

        adapters.add = function (adapterName, params, fn) {
            /// <summary>Adds a new adapter to convert unobtrusive HTML into a jQuery Validate validation.</summary>
            /// <param name="adapterName" type="String">The name of the adapter to be added. This matches the name used
            /// in the data-val-nnnn HTML attribute (where nnnn is the adapter name).</param>
            /// <param name="params" type="Array" optional="true">[Optional] An array of parameter names (strings) that will
            /// be extracted from the data-val-nnnn-mmmm HTML attributes (where nnnn is the adapter name, and
            /// mmmm is the parameter name).</param>
            /// <param name="fn" type="Function">The function to call, which adapts the values from the HTML
            /// attributes into jQuery Validate rules and/or messages.</param>
            /// <returns type="jQuery.validator.unobtrusive.adapters" />
            if (!fn) {  // Called with no params, just a function
                fn = params;
                params = [];
            }
            this.push({ name: adapterName, params: params, adapt: fn });
            return this;
        };

        adapters.addBool = function (adapterName, ruleName) {
            /// <summary>Adds a new adapter to convert unobtrusive HTML into a jQuery Validate validation, where
            /// the jQuery Validate validation rule has no parameter values.</summary>
            /// <param name="adapterName" type="String">The name of the adapter to be added. This matches the name used
            /// in the data-val-nnnn HTML attribute (where nnnn is the adapter name).</param>
            /// <param name="ruleName" type="String" optional="true">[Optional] The name of the jQuery Validate rule. If not provided, the value
            /// of adapterName will be used instead.</param>
            /// <returns type="jQuery.validator.unobtrusive.adapters" />
            return this.add(adapterName, function (options) {
                setValidationValues(options, ruleName || adapterName, true);
            });
        };

        adapters.addMinMax = function (adapterName, minRuleName, maxRuleName, minMaxRuleName, minAttribute, maxAttribute) {
            /// <summary>Adds a new adapter to convert unobtrusive HTML into a jQuery Validate validation, where
            /// the jQuery Validate validation has three potential rules (one for min-only, one for max-only, and
            /// one for min-and-max). The HTML parameters are expected to be named -min and -max.</summary>
            /// <param name="adapterName" type="String">The name of the adapter to be added. This matches the name used
            /// in the data-val-nnnn HTML attribute (where nnnn is the adapter name).</param>
            /// <param name="minRuleName" type="String">The name of the jQuery Validate rule to be used when you only
            /// have a minimum value.</param>
            /// <param name="maxRuleName" type="String">The name of the jQuery Validate rule to be used when you only
            /// have a maximum value.</param>
            /// <param name="minMaxRuleName" type="String">The name of the jQuery Validate rule to be used when you
            /// have both a minimum and maximum value.</param>
            /// <param name="minAttribute" type="String" optional="true">[Optional] The name of the HTML attribute that
            /// contains the minimum value. The default is "min".</param>
            /// <param name="maxAttribute" type="String" optional="true">[Optional] The name of the HTML attribute that
            /// contains the maximum value. The default is "max".</param>
            /// <returns type="jQuery.validator.unobtrusive.adapters" />
            return this.add(adapterName, [minAttribute || "min", maxAttribute || "max"], function (options) {
                var min = options.params.min,
                    max = options.params.max;

                if (min && max) {
                    setValidationValues(options, minMaxRuleName, [min, max]);
                }
                else if (min) {
                    setValidationValues(options, minRuleName, min);
                }
                else if (max) {
                    setValidationValues(options, maxRuleName, max);
                }
            });
        };

        adapters.addSingleVal = function (adapterName, attribute, ruleName) {
            /// <summary>Adds a new adapter to convert unobtrusive HTML into a jQuery Validate validation, where
            /// the jQuery Validate validation rule has a single value.</summary>
            /// <param name="adapterName" type="String">The name of the adapter to be added. This matches the name used
            /// in the data-val-nnnn HTML attribute(where nnnn is the adapter name).</param>
            /// <param name="attribute" type="String">[Optional] The name of the HTML attribute that contains the value.
            /// The default is "val".</param>
            /// <param name="ruleName" type="String" optional="true">[Optional] The name of the jQuery Validate rule. If not provided, the value
            /// of adapterName will be used instead.</param>
            /// <returns type="jQuery.validator.unobtrusive.adapters" />
            return this.add(adapterName, [attribute || "val"], function (options) {
                setValidationValues(options, ruleName || adapterName, options.params[attribute]);
            });
        };

        $jQval.addMethod("__dummy__", function (value, element, params) {
            return true;
        });

        $jQval.addMethod("regex", function (value, element, params) {
            var match;
            if (this.optional(element)) {
                return true;
            }

            match = new RegExp(params).exec(value);
            return (match && (match.index === 0) && (match[0].length === value.length));
        });

        $jQval.addMethod("nonalphamin", function (value, element, nonalphamin) {
            var match;
            if (nonalphamin) {
                match = value.match(/\W/g);
                match = match && match.length >= nonalphamin;
            }
            return match;
        });

        adapters.addSingleVal("accept", "exts").addSingleVal("regex", "pattern");
        adapters.addBool("creditcard").addBool("date").addBool("digits").addBool("email").addBool("number").addBool("url");
        adapters.addMinMax("length", "minlength", "maxlength", "rangelength").addMinMax("range", "min", "max", "range");
        adapters.add("equalto", ["other"], function (options) {
            var prefix = getModelPrefix(options.element.name),
                other = options.params.other,
                fullOtherName = appendModelPrefix(other, prefix),
                element = $(options.form).find(":input[name='" + escapeAttributeValue(fullOtherName) + "']")[0];

            setValidationValues(options, "equalTo", element);
        });
        adapters.add("required", function (options) {
            // jQuery Validate equates "required" with "mandatory" for checkbox elements
            if (options.element.tagName.toUpperCase() !== "INPUT" || options.element.type.toUpperCase() !== "CHECKBOX") {
                setValidationValues(options, "required", true);
            }
        });
        adapters.add("remote", ["url", "type", "additionalfields"], function (options) {
            var value = {
                url: options.params.url,
                type: options.params.type || "GET",
                data: {}
            },
                prefix = getModelPrefix(options.element.name);

            $.each(splitAndTrim(options.params.additionalfields || options.element.name), function (i, fieldName) {
                var paramName = appendModelPrefix(fieldName, prefix);
                value.data[paramName] = function () {
                    return $(options.form).find(":input[name='" + escapeAttributeValue(paramName) + "']").val();
                };
            });

            setValidationValues(options, "remote", value);
        });
        adapters.add("password", ["min", "nonalphamin", "regex"], function (options) {
            if (options.params.min) {
                setValidationValues(options, "minlength", options.params.min);
            }
            if (options.params.nonalphamin) {
                setValidationValues(options, "nonalphamin", options.params.nonalphamin);
            }
            if (options.params.regex) {
                setValidationValues(options, "regex", options.params.regex);
            }
        });
        adapters.add("creditcardexpiredate", ["currentmonth", "currentyear"], function (options) {
            options.rules["creditcardexpiredate"] = {
                currentmonth: options.params.currentmonth,
                currentyear: options.params.currentyear
            };
            options.messages["creditcardexpiredate"] = options.message;
        });
        adapters.add("neweggcreditcard", [], function (options) {
            options.rules["neweggcreditcard"] = {
            };
            options.messages["neweggcreditcard"] = options.message;
        });

        $(function () {
            $jQval.unobtrusive.parse(document);
        });
    }(jQuery));

    /*! jQuery JSON plugin 2.4.0 | code.google.com/p/jquery-json */
    (function ($) {
        'use strict'; var escape = /["\\\x00-\x1f\x7f-\x9f]/g, meta = { '\b': '\\b', '\t': '\\t', '\n': '\\n', '\f': '\\f', '\r': '\\r', '"': '\\"', '\\': '\\\\' }, hasOwn = Object.prototype.hasOwnProperty; $.toJSON = typeof JSON === 'object' && JSON.stringify ? JSON.stringify : function (o) {
            if (o === null) { return 'null'; }
            var pairs, k, name, val, type = $.type(o); if (type === 'undefined') { return undefined; }
            if (type === 'number' || type === 'boolean') { return String(o); }
            if (type === 'string') { return $.quoteString(o); }
            if (typeof o.toJSON === 'function') { return $.toJSON(o.toJSON()); }
            if (type === 'date') {
                var month = o.getUTCMonth() + 1, day = o.getUTCDate(), year = o.getUTCFullYear(), hours = o.getUTCHours(), minutes = o.getUTCMinutes(), seconds = o.getUTCSeconds(), milli = o.getUTCMilliseconds(); if (month < 10) { month = '0' + month; }
                if (day < 10) { day = '0' + day; }
                if (hours < 10) { hours = '0' + hours; }
                if (minutes < 10) { minutes = '0' + minutes; }
                if (seconds < 10) { seconds = '0' + seconds; }
                if (milli < 100) { milli = '0' + milli; }
                if (milli < 10) { milli = '0' + milli; }
                return '"' + year + '-' + month + '-' + day + 'T' +
                hours + ':' + minutes + ':' + seconds + '.' + milli + 'Z"';
            }
            pairs = []; if ($.isArray(o)) {
                for (k = 0; k < o.length; k++) { pairs.push($.toJSON(o[k]) || 'null'); }
                return '[' + pairs.join(',') + ']';
            }
            if (typeof o === 'object') {
                for (k in o) {
                    if (hasOwn.call(o, k)) {
                        type = typeof k; if (type === 'number') { name = '"' + k + '"'; } else if (type === 'string') { name = $.quoteString(k); } else { continue; }
                        type = typeof o[k]; if (type !== 'function' && type !== 'undefined') { val = $.toJSON(o[k]); pairs.push(name + ':' + val); }
                    }
                }
                return '{' + pairs.join(',') + '}';
            }
        }; $.evalJSON = typeof JSON === 'object' && JSON.parse ? JSON.parse : function (str) { return eval('(' + str + ')'); }; $.secureEvalJSON = typeof JSON === 'object' && JSON.parse ? JSON.parse : function (str) {
            var filtered = str.replace(/\\["\\\/bfnrtu]/g, '@').replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(/(?:^|:|,)(?:\s*\[)+/g, ''); if (/^[\],:{}\s]*$/.test(filtered)) { return eval('(' + str + ')'); }
            throw new SyntaxError('Error parsing JSON, source is not valid.');
        }; $.quoteString = function (str) {
            if (str.match(escape)) {
                return '"' + str.replace(escape, function (a) {
                    var c = meta[a]; if (typeof c === 'string') { return c; }
                    c = a.charCodeAt(); return '\\u00' + Math.floor(c / 16).toString(16) + (c % 16).toString(16);
                }) + '"';
            }
            return '"' + str + '"';
        };
    }(jQuery));

    (function ($) {

    }(jQuery));

    // retina.js, a high-resolution image swapper (http://retinajs.com), v0.0.2
   /* (function () { function t(e) { this.path = e; var t = this.path.split("."), n = t.slice(0, t.length - 1).join("."), r = t[t.length - 1]; this.at_2x_path = n + "@2x." + r } function n(e) { this.el = e, src = this.el.getAttribute("src"); if (src != null) { this.path = new t(this.el.getAttribute("src")); var n = this; this.path.check_2x_variant(function (e) { e && n.swap() }); } } var e = typeof exports == "undefined" ? window : exports; e.RetinaImagePath = t, t.confirmed_paths = [], t.prototype.is_external = function () { return !!this.path.match(/^https?\:/i) && !this.path.match("//" + document.domain) }, t.prototype.check_2x_variant = function (e) { var n, r = this; if (this.is_external()) return e(!1); if (this.at_2x_path in t.confirmed_paths) return e(!0); n = new XMLHttpRequest, n.open("HEAD", this.at_2x_path), n.onreadystatechange = function () { return n.readyState != 4 ? e(!1) : n.status >= 200 && n.status <= 399 ? (t.confirmed_paths.push(r.at_2x_path), e(!0)) : e(!1) }, n.send() }, e.RetinaImage = n, n.prototype.swap = function (e) { function n() { t.el.complete ? (t.el.setAttribute("width", t.el.offsetWidth), t.el.setAttribute("height", t.el.offsetHeight), t.el.setAttribute("src", e)) : setTimeout(n, 5) } typeof e == "undefined" && (e = this.path.at_2x_path); var t = this; n() }, e.devicePixelRatio > 1 && (window.onload = function () { var e = document.getElementsByTagName("img"), t = [], r, i; for (r = 0; r < e.length; r++) i = e[r], t.push(new n(i)) }) })();
   */
    (function ($) {
        $.fn.itemBind = function (options) {
            var opts = $.extend($.fn.itemBind.defaults, options);
            return this.each(function () {
                $.fn.itemBind.init($(this), opts);
            });
        };

        $.fn.itemBind.init = function (obj, opts) {
            var _self = opts.container;
            $.ajax({
                url: opts.url,
                success: function (data, textStatys) {
                    var list = jQuery(data);
                    _self.context.paging.PageIndex = 1;
                    _self.context.paging.TotalCount = Number(jQuery(list[0]).attr("totalcount"));
                    _self.context.paging.TotalCount = isNaN(_self.context.paging.TotalCount) ? 0 : _self.context.paging.TotalCount;
                    _self.controls.itemList.html(list);
                    var itemPartial = new Views.Shared.ItemPartial(_self);
                    itemPartial.load(_self.controls.itemList);
                    _self.controls.total.text(_self.context.paging.TotalCount);
                    var old = _self.controls.total.parent();
                    if (_self.context.paging.TotalCount > 1) {
                        old.html('<strong id="lstTotalCount">' + _self.context.paging.TotalCount + '</strong>&nbsp;Items');
                    } else {
                        old.html('<strong id="lstTotalCount">' + _self.context.paging.TotalCount + '</strong>&nbsp;Item');
                    }
                    _self.controls.total = old.find('#lstTotalCount');
                    if (opts.complete != undefined && typeof opts.complete == 'function') {
                        opts.complete();
                    }
                }
            });
        };

        $.fn.itemBind.defaults = {
        };
    }(jQuery));

    (function ($) {
        $.fn.paging = function (options,withNoCount) {
            var opts = $.extend({}, options);
            return this.each&&this.each(function () {
                $.fn.paging.init($(this), opts, withNoCount);
            });
        };

        $.fn.paging.init = function (obj, opts, withNoCount) {
            var _self = opts.container;
            $(this).scrollPagination({
                scrollTarget: $(window),
                heightOffset: $("#Footer").height() + 50,

                load: function (sender, args) {
                    if (_self.context.paging.TotalCount > _self.context.paging.PageSize &&
                        _self.context.paging.TotalCount > _self.controls.itemList.find(".item").length &&
                        _self.controls.loading.is(":hidden")&&
                        _self.context.paging.TotalCount > (_self.context.paging.PageSize * _self.context.paging.PageIndex)) {
                        _self.controls.loading.show();

                        if (!_self.context.subCategoryID) {
                            _self.context.subCategoryID = 0;
                        }
                        jQuery.ajax({
                            url: opts.url(),
                            success: function (data, textStatus) {
                                var list = $(data);
                                ++_self.context.paging.PageIndex;
                                if (!withNoCount) {
                                    _self.context.paging.TotalCount = Number($(list[0]).attr("totalcount"));
                                    _self.context.paging.TotalCount = isNaN(_self.context.paging.TotalCount) ? 0 : _self.context.paging.TotalCount;
                                }
                                _self.controls.itemList.append(list);

                                var itemPartial = new Views.Shared.ItemPartial(_self);
                                itemPartial.load(_self.controls.itemList);
                                if (!withNoCount) {
                                    _self.controls.total.text(_self.context.paging.TotalCount);
                                }
                                if (opts.complete && (typeof opts.complete == "function")) {
                                    opts.complete();
                                }
                            },
                            complete: function (xmlHttpRequest, textStatus) {
                                args.completed();
                                _self.controls.loading.hide();
                                if (NEG.Layout.footerFix) {
                                    NEG.Layout.footerFix();
                                }
                            },
                            error: function (xmlHttpRequest, textStatus, errorThrown) {
                                if (window.console) {
                                    window.console.log(errorThrown);
                                }
                                _self.controls.loading.hide();
                            }
                        });
                    }
                }
            });
        };

    }(jQuery));

    (function ($) {
        $.fn.loadAdditionInfo = function (options) {
            var opts = $.extend({}, options);
            return this.each && this.each(function () {
                $.fn.loadAdditionInfo.init($(this), opts);
            });
        };
        $.fn.loadAdditionInfo.init = function (obj, opts) {
            var config = jQuery("#addConfig").attr("value").split(",");
            if (config.length == 5) {
                if (config[0] == "False" &&
                    config[1] == "False" &&
                    config[2] == "False" &&
                    config[3] == "False" &&
                    config[4] == "False") {
                    return;
                } 
            }
            var priceNoteALL = $(".item").find(".priceNoteWrap");
            var eggpointsALL = $(".item").find(".eggpointsWrap");
            var premierAll = $(".item").find(".premierWrap");
            var pagesize = 40;
            var total = priceNoteALL.length;
            var len = parseInt(Math.ceil(total / pagesize));
            for (var i = 0; i < len; i++) {
                var priceNote = [pagesize];
                var eggpoints = [pagesize];
                var premier = [pagesize];
                for (var index = 0; index < pagesize; index++) {
                    if (total < (i * pagesize + index))
                        break;
                    priceNote[index] = priceNoteALL[i * pagesize + index];
                    eggpoints[index] = eggpointsALL[i * pagesize + index];
                    premier[index] = premierAll[i * pagesize + index];
                }
                var itemnumber = "";
                if (priceNote && priceNote.length > 0) {
                    $.each(priceNote, function () {
                        if ($(this).removeClass("priceNoteWrap").attr("item")) {
                            itemnumber += $(this).removeClass("priceNoteWrap").attr("item") + ",";
                        }
                    });
                }
                if (itemnumber == "")
                    continue;

                var requestUrl = "/getadditional";
                if (StringResources.Config.ClientEvirment.GlobalPath && StringResources.Config.ClientEvirment.GlobalPath.length > 0)
                {
                    requestUrl = StringResources.Config.ClientEvirment.GlobalPath + "getadditional";
                }
                jQuery.ajax({
                    url: requestUrl,
                    type: "POST",
                    priceNote: priceNote,
                    eggpoints: eggpoints,
                    premier: premier,
                    data: { 'items': itemnumber, 'pageAliase': opts.page },
                    success: function (data, textStatus) {
                        if (data.length == 0) {
                            $.each(this.priceNote, function(idx, e) {
                                e.remove();
                            });
                            $.each(this.eggpoints, function (idx, e) {
                                e.remove();
                            });
                            $.each(this.premier, function (idx, e) {
                                e.remove();
                            });
                            //this.priceNote.remove();
                            //this.eggpoints.remove();
                            //this.premier.remove();
                            return;
                        }

                        $.each(this.premier, function (idex) {
                            $(this).removeClass("premierWrap");
                            if (idex < data.length) {
                                if (data[idex].Premier) {
                                    $(this).html(data[idex].Premier);
                                } else {
                                    $(this).remove();
                                }
                            }
                        });

                        $.each(this.priceNote, function (idex) {
                            if (idex < data.length) {
                                if (data[idex].Mir) {
                                    $(this).html(data[idex].Mir);
                                } else {
                                    $(this).remove();
                                }
                            }
                        });
                        $.each(this.eggpoints, function (idex) {
                            $(this).removeClass("eggpointsWrap");
                            if (idex < data.length) {
                                if (data[idex].EggPoint) {
                                    $(this).html(data[idex].EggPoint);
                                } else {
                                    $(this).remove();
                                }
                            }
                        });
                    },
                    complete: function (xmlHttpRequest, textStatus) {
                    },
                    error: function (xmlHttpRequest, textStatus, errorThrown) {
                        if (window.console) {
                            window.console.log(errorThrown);
                        }
                    }
                });
            }
        };
    }(jQuery));

    (function ($) {
        $.fn.placeholder = function () {
            var i = document.createElement('input'),
                placeholdersupport = 'placeholder' in i;
            if (!placeholdersupport) {
                var inputs = jQuery(this);
                inputs.each(function () {
                    var input = jQuery(this),
                        text = input.attr('placeholder'),
                        pdl = 0,
                        height = input.outerHeight(),
                        width = input.outerWidth(),
                        placeholder = jQuery('<span class="phTips">' + text + '</span>');
                    try {
                        pdl = input.css('padding-left').match(/\d*/i)[0] * 1;
                    } catch (e) {
                        pdl = 5;
                    }
                    placeholder.css({ 'margin-left': -(width - pdl), 'height': height, 'line-height': height + "px", 'position': 'absolute', 'color': "#757575" });
                    placeholder.click(function () {
                        input.focus();
                    });
                    if (input.val() != "") {
                        placeholder.css({ display: 'none' });
                    } else {
                        placeholder.css({ display: 'inline' });
                    }
                    placeholder.insertAfter(input);
                    input.keyup(function (e) {
                        if (jQuery(this).val() != "") {
                            placeholder.css({ display: 'none' });
                        } else {
                            placeholder.css({ display: 'inline' });
                        }
                    });
                });
            }
            return this;
        };
    })(jQuery);
    /*
 * Lazy Load - jQuery plugin for lazy loading images
 *
 * Copyright (c) 2007-2013 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *   http://www.appelsiini.net/projects/lazyload
 *
 * Version: 1.9.0
 *
 */
    !function (a, b, c, d) { var e = a(b); a.fn.lazyload = function (f) { function g() { var b = 0; i.each(function () { var c = a(this); if (!j.skip_invisible || c.is(":visible")) if (a.abovethetop(this, j) || a.leftofbegin(this, j)); else if (a.belowthefold(this, j) || a.rightoffold(this, j)) { if (++b > j.failure_limit) return !1 } else c.trigger("appear"), b = 0 }) } var h, i = this, j = { threshold: 0, failure_limit: 0, event: "scroll", effect: "show", container: b, data_attribute: "original", skip_invisible: !0, appear: null, load: null, placeholder: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC" }; return f && (d !== f.failurelimit && (f.failure_limit = f.failurelimit, delete f.failurelimit), d !== f.effectspeed && (f.effect_speed = f.effectspeed, delete f.effectspeed), a.extend(j, f)), h = j.container === d || j.container === b ? e : a(j.container), 0 === j.event.indexOf("scroll") && h.bind(j.event, function () { return g() }), this.each(function () { var b = this, c = a(b); b.loaded = !1, (c.attr("src") === d || c.attr("src") === !1) && c.attr("src", j.placeholder), c.one("appear", function () { if (!this.loaded) { if (j.appear) { var d = i.length; j.appear.call(b, d, j) } a("<img />").bind("load", function () { var d = c.data(j.data_attribute); c.hide(), c.is("img") ? c.attr("src", d) : c.css("background-image", "url('" + d + "')"), c[j.effect](j.effect_speed), b.loaded = !0; var e = a.grep(i, function (a) { return !a.loaded }); if (i = a(e), j.load) { var f = i.length; j.load.call(b, f, j) } }).attr("src", c.data(j.data_attribute)) } }), 0 !== j.event.indexOf("scroll") && c.bind(j.event, function () { b.loaded || c.trigger("appear") }) }), e.bind("resize", function () { g() }), /iphone|ipod|ipad.*os 5/gi.test(navigator.appVersion) && e.bind("pageshow", function (b) { b.originalEvent && b.originalEvent.persisted && i.each(function () { a(this).trigger("appear") }) }), a(c).ready(function () { g() }), this }, a.belowthefold = function (c, f) { var g; return g = f.container === d || f.container === b ? (b.innerHeight ? b.innerHeight : e.height()) + e.scrollTop() : a(f.container).offset().top + a(f.container).height(), g <= a(c).offset().top - f.threshold }, a.rightoffold = function (c, f) { var g; return g = f.container === d || f.container === b ? e.width() + e.scrollLeft() : a(f.container).offset().left + a(f.container).width(), g <= a(c).offset().left - f.threshold }, a.abovethetop = function (c, f) { var g; return g = f.container === d || f.container === b ? e.scrollTop() : a(f.container).offset().top, g >= a(c).offset().top + f.threshold + a(c).height() }, a.leftofbegin = function (c, f) { var g; return g = f.container === d || f.container === b ? e.scrollLeft() : a(f.container).offset().left, g >= a(c).offset().left + f.threshold + a(c).width() }, a.inviewport = function (b, c) { return !(a.rightoffold(b, c) || a.leftofbegin(b, c) || a.belowthefold(b, c) || a.abovethetop(b, c)) }, a.extend(a.expr[":"], { "below-the-fold": function (b) { return a.belowthefold(b, { threshold: 0 }) }, "above-the-top": function (b) { return !a.belowthefold(b, { threshold: 0 }) }, "right-of-screen": function (b) { return a.rightoffold(b, { threshold: 0 }) }, "left-of-screen": function (b) { return !a.rightoffold(b, { threshold: 0 }) }, "in-viewport": function (b) { return a.inviewport(b, { threshold: 0 }) }, "above-the-fold": function (b) { return !a.belowthefold(b, { threshold: 0 }) }, "right-of-fold": function (b) { return a.rightoffold(b, { threshold: 0 }) }, "left-of-fold": function (b) { return !a.rightoffold(b, { threshold: 0 }) } }) }(jQuery, window, document);

});
