﻿NEG.Module("Utility.CookieAdapter", function (require) {
    var cookie = require('Utility.Cookie');
    var bizCookie = {};
    var jQuery = require("Utility.JQuery");
    var context = {
        isNewHost: function () {
            var host = this.getHostName();
            var result = false;
            // _hosts is a global param loaded from free blocks
            _hosts = _hosts || [];
            for (var i = 0; i < _hosts.length; i++) {
                result |= host.indexOf(_hosts[i]) >= 0;
            }
            return result;
        },
        getHostName: function () {
            return window.location.hostname;
        },
        getTopLevelDomain: function () {
            var newHost = this.isNewHost();
            var result = this.getHostName().replace('flash', '');
            if (!newHost) {
                result = ".neweggflash.com";
            }
            return result;
        },
        getSecondLevelDomain: function () {
            var newHost = this.isNewHost();
            var result = this.getHostName();
            if (!newHost) {
                result = "neweggflash.com";
            }
            return result;
        }
    }

    if (context.isNewHost())
    { 
        bizCookie = require('Utility.NeweggCookie');
    }

    var cookieAdapter = { 
        setCookie: function (key, value, option,subKey) {
            if (!context.isNewHost()) {
                // set neweggflash cookie
                cookie.set(key, value, option);
            } else {
                // set newegg cookie
                // switch key
                if (key == 'NV_OTHERINFO') {
                    // searchHistory 
                    cookie.set('NF_COMINFO', value, option);
                } else if (key == 'NV_NEWEGGMINICOOKIE') {
                    cookie.set('NF_NEWEGGMINICOOKIE', value, option);
                } else if (key == 'NV_NEWEGGCOOKIE') {
                    var shopping = jQuery.parseJSON(value);
                     
                    // delete all neweggFlash items
                    var oldFlashItems = jQuery.parseJSON(this.getCookie('NV_NEWEGGCOOKIE'));
                    if (oldFlashItems != null && oldFlashItems.ItemInfos.length > 0) {
                        //find flash items and delete
                        jQuery.each(oldFlashItems.ItemInfos, function (index, item) {
                            if (item.isFls != null && item.isFls) {
                                bizCookie('NV_NEWEGGCOOKIE').clear(item.ItemNumber);
                            }
                        });
                    } 
                    jQuery.each(shopping.ItemInfos, function (index, item) {
                        if (item.isFls != null && item.isFls) { 
                                bizCookie('NV_NEWEGGCOOKIE').set(item.ItemNumber, String(item.Qty).replace('.FLS', '') + '.FLS'); 
                        } else {
                            if (item.isSub && item.SubInfo) {
                                bizCookie('NV_NEWEGGCOOKIE').set(item.ItemNumber, String(item.Qty) +  "%5F" + item.SubInfo);
                            } else {
                                bizCookie('NV_NEWEGGCOOKIE').set(item.ItemNumber, String(item.Qty));
                            }
                        }
                    });
                } else if ('NVTC' == key )
                    {
                    cookie.set(key, value, option);
                } else if ('NV_GL' == key) {
                    cookie.set('NF_GL', value, option);
                }
                else if ('NFSIC' == key) {
                    cookie.set('NFSIC', value, option);
                }
                else {
                    bizCookie(key).set(subKey, value, option);
                }
            }
        },
        getCookie: function (key, encode) {
            if (!context.isNewHost()) {
                if (key == "NV_OTHERINFO") {
                    return cookie.get(key);
                }
                else {
                    return cookie.get(key, encode);
                }
            } else {
                // switch key
                return this.getFormartedCookieString(key, encode);
            }
        },

        getFormartedCookieString: function (key, subkey) {
             
            if ('NV_NEWEGGCOOKIE' == key) {

                // already a object
                var cookieObj = bizCookie(key).get();
                 
                var shopping = {};
                shopping.ItemInfos = [];
                if (cookieObj == null || JSON.stringify(cookieObj) == "{}") {
                    return JSON.stringify(shopping);
                } else {
                    // formart to neweggflash cookie string in order to get the cookie transfer smoothly
                    //shopping.opt = bizCookie(key).getCookieOption(key);
                    jQuery.each(cookieObj, function (item, qty) {
                        qty = decodeURI(qty);
                        shopping.ItemInfos.push({
                            "ItemNumber": item,
                            "Qty": parseInt(qty.split("_")[0].toLowerCase().replace('.fls', '')),
                            "isSub": (qty.toLowerCase().indexOf('_') > 0),
                            "isFls": (qty.toLowerCase().indexOf('fls') > 0),
                            "SubInfo": qty.split("_").length > 1 ? qty.split("_")[1] : ""
                        });
                    });
                }
                return JSON.stringify(shopping);
            } else if ('NV_NEWEGGMINICOOKIE' == key) {
                // minicart cookie
                cookiestring = cookie.get('NF_NEWEGGMINICOOKIE');
                return cookiestring;
            } else if ('NV_OTHERINFO' == key) {
                if (subkey == "si") {
                    // loginid6 
                    cookiestring = bizCookie(key).get(subkey);
                    otherinfo = {};
                    otherinfo.si = bizCookie(key).get('sd');
                    otherinfo.name = bizCookie(key).get('si');
                    return JSON.stringify(otherinfo);

                }else  if (subkey == 'sc')
                {
                    key = "NV_DVINFO";
                    subkey = "s81";
                    cookiestring = bizCookie(key).get(subkey);
                    otherinfo = {};
                    otherinfo.sc = bizCookie(key).get(subkey);
                    return JSON.stringify(otherinfo);

                } else {
                    key = 'NF_COMINFO';
                    return cookie.get(key);
                }
            } else if ('NVTC' == key ) { 
                cookiestring = cookie.get(key);
                return cookiestring;
            } else if ('NV_GL' == key) {
                cookiestring = cookie.get('NF_GL');
                return cookiestring;
            } else if ('NFSIC' == key) {
                return cookie.get('NFSIC');
            }
            else {
                cookiestring = bizCookie(key).get();
                return JSON.stringify(cookiestring);
            }

        }

        //importCookie: function (data) {
        //    var oldCookie = data;
        //    var self = this;
        //    // shoping cart data import
        //    if (oldCookie != null && oldCookie.shopincart != null) {
        //        var itemInfos = oldCookie.shopincart.ItemInfos;
        //        var qtychangedItem = {};
        //        qtychangedItem.ItemInfos = [];
        //        if (itemInfos != null) {
        //            var neweggCookie = this.getCookie('NV_NEWEGGCOOKIE');
        //            var shopincart = jQuery.parseJSON(neweggCookie); 
        //            var newqty = 0;
        //            jQuery.each(itemInfos, function (index, item) {
        //                if (self.isInNeweggShoppingCart(shopincart.ItemInfos, item, false) > -1) {
        //                    neweggItem = shopincart.ItemInfos[index];
        //                    newqty = parseInt(String(neweggItem.Qty).replace('.FLS', '').replace('_sub', '')) + parseInt(item.Qty);
        //                    bizCookie('NV_NEWEGGCOOKIE').set(item.ItemNumber, newqty + '.FLS');
        //                    qtychangedItem.ItemInfos.push({
        //                        "no": item.ItemNumber,
        //                        "qty" : newqty
        //                    });
        //                } else {
        //                    bizCookie('NV_NEWEGGCOOKIE').set(item.ItemNumber, String(item.Qty).replace('.FLS', '') + '.FLS');
        //                }
        //            });
        //        } 
        //    }

        //    // minicart data import
        //    if (oldCookie != null && oldCookie.minicart != null)
        //    {
        //        var minicartItemList = oldCookie.minicart.ItemList;
        //        if (minicartItemList != null)
        //        {
        //            // update qty if needed
        //            jQuery.each(minicartItemList, function (index, item) {
        //                var position = self.isInNeweggShoppingCart(qtychangedItem.ItemInfos, item, true) ;
        //                if (position > -1) {
        //                    minicartItemList[index].qty = qtychangedItem.ItemInfos[position].qty;
        //                }
        //            });
        //            oldCookie.minicart.ItemList = minicartItemList; 
        //            cookie.set('NF_NEWEGGMINICOOKIE', JSON.stringify(oldCookie.minicart), oldCookie.minicart.opt);
        //        }
        //    }

        //    // other info import
        //    if (oldCookie != null && oldCookie.comminfo != null) {
        //        var cominfo = oldCookie.comminfo;
        //        if (cominfo != null) {
        //            cookie.set('NF_COMINFO', JSON.stringify(cominfo), cominfo.opt);
        //        }
        //    }

        //    // gatedLaunch
        //    if (oldCookie != null && oldCookie.gatedLaunch != null)
        //    {
        //        cookie.set('NF_GL', JSON.stringify(oldCookie.gatedLaunch), oldCookie.gatedLaunch.opt);
        //    }
        //},

        //isInNeweggShoppingCart: function (sourceCookie, item, minicartFlag) {
        //    var position = -1;

        //    if (sourceCookie == null || sourceCookie.length == 0) return position;
        //    if (minicartFlag) {
        //        jQuery.each(sourceCookie, function (index,iteminfo ) {
        //            if (item.no == iteminfo.no) {
        //                position = index;
        //                return position;
        //            }
        //        });
        //    } else {
        //        jQuery.each(sourceCookie, function (index,iteminfo ) {
        //            if (item.ItemNumber == iteminfo.ItemNumber) {
        //                position = index;
        //                return position;
        //            }
        //        });
        //    }
        //    return position;
        //}
    };
      
    cookieAdapter.context = context;
    return cookieAdapter;
});
