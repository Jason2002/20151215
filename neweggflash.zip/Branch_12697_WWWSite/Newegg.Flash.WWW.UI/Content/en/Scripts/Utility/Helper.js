﻿NEG.Module("Utility.Helper", function (require) {
    var cookie = require('Utility.Cookie');
    var cookieAdapter = require('Utility.CookieAdapter');
    var Helper = {
        weekDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        currencyFormat: function (value) {
            var param = Math.pow(10, 2);
            return (Math.round(value * param) / param).toFixed(2);
        },
        currencyFormat2: function (price, currency) {
            if (/[^0-9\.]/.test(price)) return "invalid value";
            price = price.replace(/^(\d*)$/, "$1.");
            price = (price + "00").replace(/(\d*\.\d\d)\d*/, "$1");
            price = price.replace(".", ",");
            var re = /(\d)(\d{3},)/;
            while (re.test(price))
                price = price.replace(re, "$1,$2");
            price = price.replace(/,(\d\d)$/, ".$1");
            return currency + price.replace(/^\./, "0.");
        },
        preparePopupMessage: function (obj, independence) {
            var pop = jQuery(obj);

            pop.each(function (index, element) {
                var container = jQuery(element);
                var popContext = {
                    container: container,
                    messageArea: container.find(".popContainer"),
                    maskBox: jQuery('<div class="mask"></div>'),
                    fixContainer: {
                        maskBox: jQuery('<div class="maskBox popupMaskBox"></div>'),
                        container: jQuery('<div class="popContainerFixed"></div>')
                    },
                    body: jQuery("body"),
                    allowClick: false,
                    Independence: independence
                }

                popContext.fixContainer.messageArea = popContext.container.find(".popContainer").clone();
                popContext.fixContainer.container.append(popContext.fixContainer.messageArea);
                popContext.fixContainer.container.css('z-index', 10001)
                popContext.fixContainer.messageArea.siblings().remove();
                popContext.fixContainer.messageArea.find(".arrow").remove();

                var popLogic = function (e) {
                    if (e.srcElement && e.srcElement.id && e.srcElement.id == "make-gift") {
                        return;
                    }

                    if (e.srcElement && e.srcElement.innerText && e.srcElement.innerText == "Make this item a gift") {
                        return;
                    }
                    if (popContext.allowClick) {

                        if (popContext.Independence && popContext.fixContainer.messageArea.length == 0) {
                            return;
                        }
                        popContext.body.addClass('bodyFix');

                        var container;
                        var messageArea;
                        var maskBox;

                        if (popContext.Independence) {
                            container = popContext.fixContainer.container;
                            messageArea = popContext.fixContainer.messageArea
                            maskBox = popContext.fixContainer.maskBox;

                            popContext.body.append(maskBox).append(container);
                            messageArea.show();

                            messageArea.css({ 'width': container.width() - 8, 'overflow-y': 'auto', 'position': 'fixed' })
                        }
                        else {
                            container = popContext.container;
                            messageArea = popContext.messageArea;
                            maskBox = popContext.maskBox;

                            messageArea.show().before(maskBox);
                        }

                        var _winHeight = jQuery(window).height();
                        var _thisPopConHeight = messageArea.outerHeight();

                        if (_thisPopConHeight <= _winHeight - 100) {
                            messageArea.css('top', (_winHeight - _thisPopConHeight) / 2);
                        } else {
                            messageArea.css({ 'top': 50, 'max-height': _winHeight - 110 });
                        }

                        var hidePop = function (event) {
                            event.stopPropagation();
                            maskBox.remove();
                            container.unbind("click").click(popLogic);
                            if (popContext.Independence) {
                                container.remove();
                            }

                            messageArea.removeAttr("style");
                            popContext.body.removeClass("bodyFix");
                        };
                        maskBox.unbind("click").click(hidePop);
                        container.unbind("click").click(hidePop);
                    } else if ((e.srcElement && e.srcElement.innerText == "Learn More")
                        || (e.target.innerHTML && e.target.innerHTML == "Learn More")) {
                        var _thisPopCon = jQuery(this).find('.popContainer');

                        if (popContext.messageArea.is(":hidden")) {
                            popContext.messageArea.css('z-index', 1010);
                            popContext.messageArea.show();
                        } else {
                            popContext.messageArea.css('z-index', "");
                            popContext.messageArea.hide();
                        }

                        _thisPopCon.hover(function () {
                            if (!popContext.allowClick) {
                                popContext.messageArea.css('z-index', 1010);
                                popContext.messageArea.show();
                            }
                        }, function () {
                            if (!popContext.allowClick) {
                                popContext.messageArea.css('z-index', "");
                                popContext.messageArea.hide();
                            }
                        });
                    }

                };
                if (element.id == "checklist") {
                    var _thisPopCon = jQuery(this).find('.popContainer'),
                        _linkTarget = jQuery(this).find(".popLinkTarget");

                    var currWinWidth = jQuery(window).width(),
                       isTouch = jQuery.IsTouchMedia(),
                       winWidth = {
                           _768: isTouch ? 768 : 751,
                           _1024: isTouch ? 1024 : 1007
                       };
                    if (currWinWidth > winWidth._768) {

                        popContext.allowClick = false;
                    } else {

                        popContext.allowClick = true;
                    }


                    _linkTarget.click(popLogic)
                    _thisPopCon.hover(function () {
                        if (!popContext.allowClick) {
                            popContext.messageArea.css('z-index', 1010);
                            popContext.messageArea.show();
                        }
                    }, function () {
                        if (!popContext.allowClick) {
                            popContext.messageArea.css('z-index', "");
                            popContext.messageArea.hide();
                        }
                    });
                } else {
                    popContext.container.click(popLogic)
                    .hover(function () {
                        if (!popContext.allowClick) {
                            popContext.messageArea.css('z-index', 1010);
                            popContext.messageArea.show();
                        }
                    }, function () {
                        if (!popContext.allowClick) {
                            popContext.messageArea.css('z-index', "");
                            popContext.messageArea.hide();
                        }
                    });
                }

                jQuery(window).bind("orientationchange", function () {
                    if (!popContext.fixContainer.messageArea.is(":hidden")) {
                        popContext.fixContainer.container.click();
                    }
                    if (!popContext.messageArea.is(":hidden")) {
                        popContext.container.click();
                    }
                });

                jQuery(window).resize(function () {

                    var currWinWidth = jQuery(window).width(),
                        isTouch = jQuery.IsTouchMedia(),
                        winWidth = {
                            _768: isTouch ? 768 : 751,
                            _1024: isTouch ? 1024 : 1007
                        };
                    if (currWinWidth > winWidth._768) {
                        jQuery("#productBullet").css({ "margin-top": "auto" });
                        //popContext.allowClick = false;
                    } else {
                        jQuery("#productBullet").css({ "margin-top": jQuery("#price").height() + "px" });
                        //popContext.allowClick = true;
                    }
                    //if (!popContext.fixContainer.messageArea.is(":hidden")) {
                    //    popContext.fixContainer.container.click();
                    //}
                    //if (!popContext.messageArea.is(":hidden")) {
                    //    popContext.container.click();
                    //}

                    //if (!popContext.fixContainer.messageArea.is(":hidden")) {
                    //    popContext.fixContainer.container.click();
                    //}
                    //if (!popContext.messageArea.is(":hidden")) {
                    //    popContext.container.click();
                    //}
                });

                //if (!popContext.fixContainer.messageArea.is(":hidden")) {
                //    popContext.fixContainer.container.click();
                //}
                //if (!popContext.messageArea.is(":hidden")) {
                //    popContext.container.click();
                //}
                //if ((jQuery(window).width() == 1025 || jQuery(window).width() == 960) && !jQuery.IsTouchMedia()) {
                //    popContext.allowClick = false;
                //} else if (jQuery(window).width() == 640 || jQuery.IsTouchMedia()) {
                //    popContext.allowClick = true;
                //}
                if (!popContext.fixContainer.messageArea.is(":hidden")) {
                    popContext.fixContainer.container.click();
                }
                if (!popContext.messageArea.is(":hidden")) {
                    popContext.container.click();
                }
                if ((jQuery(window).width() >= 1024 || jQuery(window).width() == 960) && !jQuery.IsTouchMedia()) {
                    popContext.allowClick = false;
                } else if (jQuery(window).width() <= 640 || jQuery.IsTouchMedia()) {
                    popContext.allowClick = true;
                }
                NEG.Layout.controls.deviceSizeChangeEvent.register(this, function (sender, args) {

                    //if ((args.newWidth >= 1024) && !jQuery.IsTouchMedia()) {
                    //    if (!_self.controls.message.container.is(":hidden") ||
                    //         jQuery("body").find(">div.popContainerFixed").length > 0) {
                    //        _self.controls.message.click();
                    //    }
                    //    _self.context.allowClick = false;
                    //} else if (args.newWidth == 640 || jQuery.IsTouchMedia()) {
                    //    _self.context.allowClick = true;
                    //}

                    if (!popContext.fixContainer.messageArea.is(":hidden")) {
                        popContext.fixContainer.container.click();
                    }
                    if (popContext.messageArea.length > 0 && !popContext.messageArea.is(":hidden")) {
                        popContext.container.click();
                    }
                    if ((args.newWidth == 1025 || args.newWidth == 960) && !jQuery.IsTouchMedia()) {
                        popContext.allowClick = false;
                    } else if (args.newWidth == 640 || jQuery.IsTouchMedia()) {
                        popContext.allowClick = true;
                    }
                });
            });
        },

        warrantyDaysFormat: function (days) {
            var result = "0 day";
            if (days > 999999) {
                result = "Lifetime";
            }
            else if (days > 0) {
                var param = Math.pow(10, 0);
                if (days % 365 >= 360 || days % 365 <= 5) {
                    var years = Math.round(days / 365);
                    years = Math.round(years * param) / param;
                    result = years + (years > 1 ? "years" : "year");
                } else {
                    result = days + " days";
                }
            }

            return result;
        },
        expiredTimeFormat: function (current, value) {
            value += 1 * 10000000;
            var result = value / (24 * 60 * 60 * 10000000);
            var content = null;
            if (result >= 1) {
                var date = new Date(current.getTime());
                date.setDate(date.getDate() + Math.ceil(result));
                content = Math.ceil(result) + " days (" + this.weekDays[date.getUTCDay()] + ")";
            }

            if (content == null && value > 0) {
                content = Math.ceil(value / (60 * 60 * 10000000)) + " hours";
                if (value / (60 * 60 * 10000000) < 1) {
                    content = "minutes!";
                }
            }

            return content;
        },
        checkEmail: function (email) {
            var reg = /^(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)$/;
            return reg.test(email);
        },
        expiredTimeFormat2: function (tickets, expired) {
            var result = tickets / (24 * 60 * 60 * 1000 * 10000);
            var content = null;
            if (result >= 1) {
                
                //days
                //计算规则=utcTime+currentOffset
                var localTime = new Date(expired.getTime()  + StringResources.Config.ClientEvirment.CurrentTimeZoneOffset);
                content = Math.ceil(result)  +" " + StringResources.Config.ClientResources.Days
                    + " (" + StringResources.Config.ClientResources.WeekDays[localTime.getUTCDay()] + ")";
            } else {
                // hours
                result = tickets / (60 * 60 * 1000 * 10000);
                if (result > 0) {
                    content = Math.ceil(result) + " " + StringResources.Config.ClientResources.Hours;
                } else {
                    //minutes
                    content = StringResources.Config.ClientResources.Minutes;
                }
            }
           

            return content;
        },
        NVTC: {
            utmaExpireTime: null,
            generateAndUpdate: function (siteID, utmaExpireTime) {
                this.utmaExpireTime = utmaExpireTime;
                //var utma = cookie.get('NVTC');
                var utma = cookieAdapter.getCookie('NVTC');
                var match = location.host.match(/\w+\.(\w+[\.\w+]+)/);
                var domain;
                if (match && match.length > 1) {
                    domain = match[1];
                }
                var expireDate = new Date();
                expireDate.setFullYear(expireDate.getFullYear() + 2);
                if (utma) {
                    utma = this.refresh(utma, domain, siteID);
                }
                else {
                    utma = this.generate(domain, siteID);
                }
                document.cookie = "NVTC=" + utma + "; domain=" + domain + "; expires=" + expireDate.toGMTString() + "; path=/";
            },
            generate: function (domain, siteID) {
                var domainHash = this.getDomainHash(domain);
                if (domainHash == 0) {
                    return "";
                }
                var id = this.random;
                var ct = this.totalSeconds;

                var utmaAry = new Array(7);
                utmaAry[0] = domainHash.toString();
                utmaAry[1] = siteID;
                utmaAry[2] = id.toString();
                utmaAry[3] = ct;
                utmaAry[4] = ct;
                utmaAry[5] = ct;
                utmaAry[6] = "1";

                return this.getUtma(utmaAry);
            },
            refresh: function (utma, domain, siteID) {
                var utmaAry = utma.split(".");
                if (utmaAry.length != 7) {
                    return utma;
                }

                var domainHash = this.getDomainHash(domain);
                if ((domainHash + "." + siteID) != (utmaAry[0] + "." + utmaAry[1])) {
                    return this.generate(domain, siteID);
                }

                var currentAccessTime = this.totalSeconds;
                var lastAccessTime = parseInt(utmaAry[5]);
                if ((lastAccessTime + this.getUTMAExpireTime() * 60 <= currentAccessTime)) {
                    utmaAry[4] = utmaAry[5];
                    utmaAry[5] = currentAccessTime.toString();
                    utmaAry[6] = parseInt(utmaAry[6]) + 1;
                    utma = this.getUtma(utmaAry);
                }

                return utma;
            },
            getUtma: function (utmaAry) {
                return utmaAry[0] + "." + utmaAry[1] + "." + utmaAry[2] + "." + utmaAry[3] + "." + utmaAry[4] + "." + utmaAry[5] + "." + utmaAry[6];
            },
            getDomainHash: function (a) {
                var b = 1, c = 0, d = 0, b = 0;
                if (a) {
                    for (d = a.length - 1; 0 <= d; d--) {
                        c = a.charAt(d).charCodeAt();
                        b = (b << 6 & 268435455) + c + (c << 14);
                        c = b & 266338304;
                        b = 0 != c ? b ^ c >> 21 : b;
                    }
                }
                return b;
            },
            totalSeconds: Date.parse(new Date()) / 1000,
            random: Math.floor(Math.random() * 1000000000),
            getUTMAExpireTime: function () {
                return this.utmaExpireTime;
            }
        },
        checkEmail: function (email) {
            var reg = /^(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)$/;
            return reg.test(email);
        },
        AdobeSiteCatalyst: {
            sendToAdobe: function (param) {
                if (param.orders) {
                    this.processPageOrder(param.orders);
                    return;
                }

                //scp.prop19 = cookie.get('NVTC');
                //scp.prop24 = cookie.get('__utma', true);
                scp.prop19 = cookieAdapter.getCookie('NVTC');
                scp.prop24 = cookieAdapter.getCookie('__utma', true);

                if (scp.eVar22 == null || scp.eVar22 == undefined) {
                    //var jsonStr = cookie.get('NV_OTHERINFO');
                    var jsonStr = cookieAdapter.getCookie('NV_OTHERINFO','sc');
                    if (jsonStr != "") {
                        var otherInfo = jQuery.parseJSON(jsonStr);
                        if (otherInfo.sc != undefined && otherInfo.sc != "") {
                            scp.eVar22 = otherInfo.sc;
                        }
                    }
                }

                var obj = undefined;
                if (typeof (ascp) != 'undefined') { obj = ascp; } else if (typeof (s) != 'undefined') { obj = s; }
                for (prop in scp) {
                    obj[prop] = scp[prop];
                }

                var s_code = obj.t();
                if (s_code) { document.write(s_code); }
            },
            processPageOrder: function (orders) {
                for (var i = 0; i < orders.length; i++) {
                    var od = orders[i];
                    if (!od) {
                        continue;
                    }
                    //od.prop19 = cookie.get('NVTC');
                    //od.prop24 = cookie.get('__utma', true);
                    od.prop19 = cookieAdapter.getCookie('NVTC');
                    od.prop24 = cookieAdapter.getCookie('__utma', true);

                    var obj = undefined;
                    if (typeof (ascp) != 'undefined') { obj = ascp; } else if (typeof (s) != 'undefined') { obj = s; }
                    for (prop in od) {
                        obj[prop] = od[prop];
                    }

                    if (i == 0) {
                        var s_code = obj.t();
                        if (s_code) {
                            document.write(s_code);
                        }
                        continue;
                    }
                    obj.linkTrackVars = 'events,products,purchaseID,eVar11,eVar12,eVar13,eVar23,';
                    if (od.eVar25) {
                        obj.linkTrackVars = obj.linkTrackVars + 'eVar25,';
                    }
                    if (od.eVar26) {
                        obj.linkTrackVars = obj.linkTrackVars + 'eVar26,';
                    }
                    if (od.eVar41) {
                        obj.linkTrackVars = obj.linkTrackVars + 'eVar41,';
                    }
                    obj.linkTrackVars = obj.linkTrackVars + 'zip,state';
                    obj.linkTrackEvents = 'purchase,event13,event14,event15,event33';
                    obj.tl(this, 'o', 'Subsequent Order');
                }
            }
        },
        getQueryStringByName: function (name) {
            name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
            return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        },
        LogShareInfo: function (data, action) {
            if (data == null || data == undefined)
                return;

            data.PageUrl = window.location.href;
            //data.NVTC = cookie.get("NVTC");
            data.NVTC = cookieAdapter.getCookie("NVTC");
            jQuery.FormPostAsync(data, action, true);
        }
    };

    return Helper;
});
