﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        if (Views.Shared.ItemPartial != undefined) {
            var control = jQuery(".itemList"), count;
            if (control.length > 0) {
                this.controls["deals"] = control;
                this.controls["deals"].controls = [];

                count = control.length;
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(jQuery(this.controls.deals[index]));
                    this.controls.deals.controls.push(child);
                }
            }
        }
        jQuery(window).loadAdditionInfo({ page: "EndingSoon" });
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.load();
});
