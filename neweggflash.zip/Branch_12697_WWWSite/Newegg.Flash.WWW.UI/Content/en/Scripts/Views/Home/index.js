﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        if (Views.Home != undefined && Views.Home.Banner != undefined) {
            this.controls["banner"] = new Views.Home.Banner(this);
            this.controls["banner"].load(jQuery("#sliderContainer"));
        }
        if (Views.Home != undefined && Views.Home.TopBanner != undefined) {
            this.controls["topbanner"] = new Views.Home.TopBanner(this);
            this.controls["topbanner"].load(jQuery("#Wrapper"));
        }
        
        if (Views.Shared.ItemPartial != undefined) {
            var control = jQuery(".itemList"), count;
            if (control.length > 0) {
                this.controls["deals"] = control;
                this.controls["deals"].controls = [];

                count = control.length;
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(jQuery(this.controls.deals[index]));
                    this.controls.deals.controls.push(child);
                }
            }

            control = jQuery("#upcomingContainer");

            if (control.length > 0) {
                this.controls["upcomings"] = control;
                this.controls["upcomings"].controls = [];

                count = Number(this.controls.upcomings.attr("count"));
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(this.controls.upcomings.find("#upcomingContainer" + index));
                    this.controls.upcomings.controls.push(child);
                }
            }
        }

        if (Views.Home != undefined && Views.Home.Invite != undefined) {
            this.controls["Invite"] = new Views.Home.Invite(this);
            this.controls["Invite"].load(jQuery("#inviteContainerBox"));
        }

        if (Views.Home != undefined && Views.Home.Subscribe != undefined) {
            this.controls["Subscribe"] = new Views.Home.Subscribe(this);
            this.controls["Subscribe"].load(jQuery("#subscribeContainer")); 
        }

        if (Views.Home != undefined && Views.Home.SweepstakesShare != undefined) {
            this.controls["SweepstatkesShare"] = new Views.Home.SweepstakesShare(this);
            this.controls["SweepstatkesShare"].load(jQuery("#PopSweepstakesShare"));
        }
        jQuery(window).loadAdditionInfo({ page: "Homepage" });
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.load();
});
