﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function() {
        var jQuery = this.context.jQuery;
        var container = jQuery("#Main");
        var _self = this;
        
        this.controls["container"] = container;
        this.controls["itemList"] = container.find("#itemListS");
        this.controls["loading"] = container.find("#loading");
        this.controls["total"] = container.find('#lstTotalCount');

        this.context.paging = eval("(" + this.controls["itemList"].attr("paging") + ")");
        this.controls.itemList.items = [];
        container.loadAdditionInfo({ page: "SpecialStore" });
        if (Views.Shared.ItemPartial != undefined) {
            var control = jQuery(".itemList"), count;
            if (control.length > 0) {
                this.controls["deals"] = control;
                this.controls["deals"].controls = [];
                count = control.length;
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(jQuery(this.controls.deals[index]));
                    this.controls.deals.controls.push(child);
                }
            } //if control.length
        } //if view.shared

        this.controls.itemList.paging({
            'container': _self,
            url: function() {
                return StringResources.Config.ClientEvirment.GlobalPath + "/SpecialStore/Paging/?pageIndex=" + (_self.context.paging.PageIndex + 1) + "&pageSize=" + _self.context.paging.PageSize + "&t=" + Math.random();
            },
            'complete': function () {
                _self.controls.itemList.loadAdditionInfo({ page: "SpecialStore" });
            }
        }, true);

    }//load
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
