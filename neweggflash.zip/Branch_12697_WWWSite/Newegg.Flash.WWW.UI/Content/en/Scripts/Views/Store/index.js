﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        var container = jQuery('#Main');
        var _self = this;
        this.controls["menu"] = container.find('.menuItem dt');
        this.controls["category"] = container.find('#selectCategory');
        this.controls["sortby"] = container.find('#selectSortBy');
        this.controls["menuitem"] = container.find('#subCategory dd a:not(".more")');
        this.controls["sortitem"] = container.find('#sortBy dd a');
        this.controls["more"] = container.find('.more');
        this.controls["total"] = container.find('#lstTotalCount');
        this.controls["loading"] = container.find('#loading');
        this.controls["itemList"] = container.find('#itemListS');
        this.context.paging = eval("(" + this.controls["itemList"].attr("paging") + ")");
        this.context.storeId = this.controls["itemList"].attr("storeId");
        this.context.subCategoryId = this.controls["itemList"].attr("subCategoryId");
        if (!this.context.subCategoryId) {
            this.context.subCategoryId = 0;
        }
        container.loadAdditionInfo({ page: "Store" });

        this.controls.menu.click(function () {
            var _menuItem = jQuery(this).parent();
            jQuery(this).find('.fold').toggleClass('close');
            _menuItem.find('dd').slideToggle(250);
            setTimeout(function () {
                NEG.Layout.footerFix();
            }, 300);
        });
        this.controls.category.change(function () {
            var _selectIndex = jQuery(this).index();
            var _index = jQuery(this).get(0).selectedIndex;
            var subcat = jQuery('#subCategory').eq(_selectIndex).find('dd a').eq(_index);
            subcat.addClass('current').siblings().removeClass('current');
            _self.context.subCategoryId = subcat.attr('subCategoryID');

            var loc = location.href.substring(0, location.href.lastIndexOf('/') + 1) + _self.context.subCategoryId + "?sortby=" + _self.context.paging.Sort;
            location.replace(loc);

            //_self.dataBind();
        });        this.controls.sortby.change(function () {
            var _selectIndex = jQuery(this).index();
            var _index = jQuery(this).get(0).selectedIndex;
            var subcat = jQuery('#sortBy').find('dd a').eq(_index);
            subcat.addClass('current').siblings().removeClass('current');
            _self.context.paging.Sort = subcat.attr('sort');

            var loc = location.href.substring(0, location.href.lastIndexOf('/') + 1) + _self.context.subCategoryId + "?sortby=" + _self.context.paging.Sort;
            location.replace(loc);
          
           // _self.dataBind();
        });        this.controls.menuitem.click(function () {
            jQuery(this).addClass('current').siblings().removeClass('current');

            var _selectIndex = jQuery(this).parents('.menuItem').index();
            var _text = jQuery(this).html();
            _self.controls.category.eq(_selectIndex).val(_text);

            _self.context.subCategoryId = jQuery(this).attr('subcategoryid');

            var loc = location.href.substring(0, location.href.lastIndexOf('/') + 1) + _self.context.subCategoryId + "?sortby=" + _self.context.paging.Sort;
            location.replace(loc);
        });        this.controls.sortitem.click(function () {
            jQuery(this).addClass('current').siblings().removeClass('current');

            var _selectIndex = jQuery(this).parents('.menuItem').index();
            var _text = jQuery(this).html();
            _self.controls.sortby.eq(_selectIndex).val(_text);

            _self.context.paging.Sort = jQuery(this).attr('sort');

            var loc = location.href.substring(0, location.href.lastIndexOf('/') + 1) + _self.context.subCategoryId + "?sortby=" + _self.context.paging.Sort;
            location.replace(loc);
        });        this.controls.more.click(function () {
            var _moreCon = jQuery(this).parent().find('.moreCategory');
            if (_moreCon.is(':hidden')) {
                jQuery(this).find('span').html('See Less');
                jQuery(this).find('b').addClass('iconArrowUp');
            } else {
                jQuery(this).find('span').html('See All');
                jQuery(this).find('b').removeClass('iconArrowUp');
            }
            _moreCon.slideToggle(200);
        })

        this.controls.itemList.paging({
            'container': _self,
            'url': function () {
                return StringResources.Config.ClientEvirment.GlobalPath + "/Store/Paging/" + _self.context.storeId + "?pageIndex=" + (_self.context.paging.PageIndex + 1) + "&pageSize=" + _self.context.paging.PageSize + "&sort=" + _self.context.paging.Sort + "&subCategoryID=" + _self.context.subCategoryId + "&t=" + Math.random();
            },
            'complete': function () {
                _self.controls.itemList.loadAdditionInfo({ page: "Store" });
            }
        },true);

        if (Views.Shared.ItemPartial != undefined) {
            var control = jQuery(".itemList"), count;
            if (control.length > 0) {
                this.controls["deals"] = control;
                this.controls["deals"].controls = [];

                count = control.length;
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(jQuery(this.controls.deals[index]));
                    this.controls.deals.controls.push(child);
                }
            }
        }
    },
    dataBind: function () {
        var _self = this;
        if (!_self.context.subCategoryId) {
            _self.context.subCategoryId = 0;
        }
        _self.controls.itemList.itemBind({
            'url': StringResources.Config.ClientEvirment.GlobalPath + "/Store/Paging/" + _self.context.storeId + "?pageIndex=1&pageSize=" + _self.context.paging.PageSize + "&sort=" + _self.context.paging.Sort + "&subCategoryID=" + _self.context.subCategoryId + "&t=" + Math.random(),
            'container': _self
        });
    },
    clear: function () {
        this.model = null;
        this.controls = null;
        this.context = null;
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
