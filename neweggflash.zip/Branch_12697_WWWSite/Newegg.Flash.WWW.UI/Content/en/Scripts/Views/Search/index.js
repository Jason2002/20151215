﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function() {
        var jQuery = this.context.jQuery;
        var _self = this;
        NEG.Layout.needLogin(false);
        if (jQuery("#searchListContainer").length != 0) {
            this.controls["list"] = new Views.Search.SearchDealsList(this);
            this.controls["list"].load(jQuery("#searchListContainer"));
        }

        if (Views.Shared.ItemPartial != undefined) {
            var control = jQuery(".itemList"), count;
            if (control.length > 0) {
                this.controls["deals"] = control;
                this.controls["deals"].controls = [];

                count = control.length;
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(jQuery(this.controls.deals[index]));
                    this.controls.deals.controls.push(child);
                }
            }
        }

    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
