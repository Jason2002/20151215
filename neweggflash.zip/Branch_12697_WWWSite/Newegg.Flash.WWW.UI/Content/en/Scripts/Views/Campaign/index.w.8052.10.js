﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        var _self = this;
        var needLoggin = jQuery("#descriptionContainer").attr("data-needLogin") == "True" ? true : false;
        NEG.Layout.needLogin(needLoggin);
        this.controls["description"] = new Views.Campaign.Description(this);
        this.controls["list"] = new Views.Campaign.CampaignList(this);
        this.controls["timespan"] = jQuery("#timespanContainer");
        this.controls["timespan"].value = this.controls["timespan"].find("#value");
        this.controls["expired"] = jQuery("#expiredContainer");
        this.controls["list"].load(jQuery("#campaignListContainer"));
        this.controls["description"].load(jQuery("#descriptionContainer"));
        NEG.Layout.controls.ItemMonitor.addItem("CampaignExpired",
                                       eval("(" + this.controls["timespan"].value.attr("data-value") + ")"),
                                       function (sender, args) {
                                           args.value.expired = args.value.expired - args.timespan * 10000;
                                           args.value.currentTime.setTime(args.value.currentTime.getTime() + args.timespan);
                                           if (args.value.expired <= 0) {
                                               sender.removeItem(args.key);
                                               NEG.Page.controls.timespan.hide();
                                               NEG.Page.controls.expired.show();
                                           } else {
                                               var content = NEG.Page.context["helper"].expiredTimeFormat2(args.value.currentTime, args.value.endTime);
                                               NEG.Page.controls.timespan.show();
                                               NEG.Page.controls.expired.hide();
                                               NEG.Page.controls.timespan.value.text(content);
                                           }
                                           return args.value;
                                       });
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
