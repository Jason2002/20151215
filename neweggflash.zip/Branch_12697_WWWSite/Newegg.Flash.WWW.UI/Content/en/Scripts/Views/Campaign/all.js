﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        var container = jQuery('#Main');
        var _self = this;
        this.controls["total"] = container.find('#lstTotalCount');
        this.controls["loading"] = container.find('#loading');
        //paging info
        this.controls["itemList"] = container.find('#itemListS');
        this.context.paging = eval("(" + this.controls["itemList"].attr("paging") + ")");
        this.context.storeId = this.controls["itemList"].attr("storeId");
        this.controls.itemList.paging({
            'container': _self,
            'url': function () {
                return StringResources.Config.ClientEvirment.GlobalPath + "/Campaign/AllPaging/" + _self.context.storeId + "?pageIndex=" + (_self.context.paging.PageIndex + 1) + "&pageSize=" + _self.context.paging.PageSize + "&t=" + Math.random();
            }
        },true);
        if (Views.Shared.ItemPartial != undefined) {
            var control = jQuery(".itemList"), count;
            if (control.length > 0) {
                this.controls["deals"] = control;
                this.controls["deals"].controls = [];

                count = control.length;
                for (var index = 0; index < count; index++) {
                    var child = new Views.Shared.ItemPartial(this);
                    child.load(jQuery(this.controls.deals[index]));
                    this.controls.deals.controls.push(child);
                }
            }
        }
    },
    clear: function () {
        this.model = null;
        this.controls = null;
        this.context = null;
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery"); //require("Utility.Plugins");
    NEG.Page.context["helper"] = require("Utility.Helper"); 
    NEG.Page.load();
});