﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var _self = this;
        var jQuery = this.context.jQuery;
        this.controls["viewer"] = jQuery("#ImageViewer");
        this.controls["list"] = this.controls.viewer.find("ul");
        //this.controls["open"] = jQuery("#btnOpen");
        //this.controls["index"] = jQuery("#lblIndex");
        this.context.source = eval("(" + this.controls.list.attr("data-value") + ")");
        this.controls.list.show();
        var width = this.controls.viewer.outerWidth();
        this.controls.list.find("li").width(width);

        if (this.controls.list.find("li").length > 1) {
            this.controls["slider"] = new Swiper("#ImageViewer", {
                pagination: '.thumbnail',
                paginationActiveClass: 'current',
                loop: true,
                grabCursor: false
            });
        }
        this.controls["list"].show();
        this.setBack();
        window.onorientationchange = function () {
            NEG.Page.setBack();
        };
    },
    setBack: function () {
        var list = this.controls.list,
            agent = navigator.userAgent,
            orient = window.orientation;
        if (orient == 0 || orient == 180) {
            if (agent.indexOf("Android") > 0) {
                list.find("li").css("background-size", "auto 100%");
            } else if (agent.indexOf('iPad') > 0 || agent.indexOf('iPhone') > 0) {
                ul.find('li').css('background-size', '100% auto');
            }
        } else if (orient == 90 || orient == -90) {
            if (agent.indexOf("Android") > 0) {
                list.find("li").css("background-size", "100% auto");
            } else if (agent.indexOf('iPad') > 0 || agent.indexOf('iPhone') > 0) {
                ul.find('li').css('background-size', 'auto 100%');
            }
        }
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    require("Utility.Plugins");
    NEG.Page.load();
});