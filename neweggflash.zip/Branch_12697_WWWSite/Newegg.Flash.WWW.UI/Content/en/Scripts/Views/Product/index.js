﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        jQuery(document).ready(function () {
            var dftHeight = jQuery(".right .wrap").height() + 180;
            jQuery(".section").css("min-height", dftHeight + "px");
        });

        if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
            jQuery("body").addClass("bodyIE");
        }

        if (jQuery(window).width() > 1024 || jQuery.IsIE(7) || jQuery.IsIE(8)) {
            jQuery('body').addClass('w1100');
        } else {
            jQuery('body').removeClass('w1100');
        }
        setTimeout(function () {
            if (jQuery.IsIE(7) || jQuery.IsIE(8)) { jQuery('body').removeClass('w1024'); }
        }, 300);

        jQuery(window).resize(function () {
            if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
                jQuery('body').removeClass('w1024');
                return;
            }
            if (jQuery(window).width() > 1024) {
                jQuery('body').addClass('w1100');
            } else {
                jQuery('body').removeClass('w1100');
            }
        });


        this.controls["content"] = jQuery("#txtDataSource");
        if (this.controls["content"].length == 0) {
            return;
        } else {
            this.model = jQuery.parseJSON(NEG.Layout.controls.base64.decode(this.controls.content.val()));
            for (var index = 0; index < this.model.Items.length; index++) {
                var data = this.model.Items[index];
                NEG.Layout.needLogin(data.IsNeedLogin);
                data.CurrentDateTime = eval("new " + data.CurrentDateTime.replace(/\//g, ""));
                data.ExpireTime = eval("new " + data.ExpireTime.replace(/\//g, ""));
                NEG.Page.setDealExpired(data);
            }
        }

        this.controls["timespan"] = {
            end: jQuery("#productTitleContainer").find("#timeSpanContainer"),
            expired: jQuery("#productTitleContainer").find("#expiredContainer")
        };
        this.controls["timespan"].end.value = this.controls["timespan"].end.find("#value");
        this.controls["viewer"] = new Views.Product.ImageViewer(this);
        this.controls["info"] = new Views.Product.ProductInfo(this);
        this.controls["specification"] = new Views.Product.Specification(this);
        this.controls["overview"] = new Views.Product.Overview(this);
        this.controls["return"] = new Views.Product.ReturnPolicies(this);
        this.controls["warranty"] = new Views.Product.WarrantyInfo(this);
        this.controls["manufacturer"] = new Views.Product.ManufacturerContactInfo(this);
        this.controls["navgationContainer"] = jQuery("#navgationContainer");
        this.controls.info.load(jQuery("#productInfoContainer"));
        this.controls.viewer.load(jQuery("#imgViewerContainer"));
        this.controls.specification.load(jQuery("#specificationContainer"));
        this.controls.overview.load(jQuery("#overviewContainer"));
        this.controls["return"].load(jQuery("#returnContainer"));
        this.controls.warranty.load(jQuery("#warrantyContainer"));
        this.controls.manufacturer.load(jQuery("#manufacturerContainer"));
        this.controls.info.model = this.model;

        jQuery(window).ready(function () {
            var currentItem = NEG.Page.model.Items[NEG.Page.model.CurrentItemIndex];
            jQuery("#ironEggContainer").hide();
            //mask close all;
            jQuery(".maskAll").on("click", function () {
                jQuery(".maskAll").removeClass("show");
                jQuery(".popContainer").hide();
                jQuery('body').removeClass('bodyFix');
            });
            var itemnumber = currentItem.ItemNumber;
            //if (jQuery.IsTouchMedia()) {
            //jQuery(window).resize(function () {
            //    jQuery(".maskAll").removeClass("show");
            //    jQuery(".popContainer").hide();
            //    jQuery('body').removeClass('bodyFix');
            //    NEG.Page.setCssWidth();
            //});
            //} 
            var config = jQuery("#addConfig").attr("value").split(",");
            if (config.length == 5) {
                if (config[1] == "True" || config[2] == "True" || config[3] == "True" || config[4] == "True") {
                    NEG.Page.getAdditionInfo(itemnumber);
                }
                if (config[0] == "True") {
                    NEG.Page.getEggPoints(itemnumber);
                }
            }
        });
    },
    setDealExpired: function (data) {
        if (data.AutoAddItemType == 2) return;
        NEG.Layout.controls.ItemMonitor.addItem("ProductDealExpired_" + data.NeweggItemNumber,
                                                   data,
                                                   function (sender, args) {
                                                       var value = args.value.ExpireTicks - args.timespan * 10000;
                                                       args.value.CurrentDateTime.setTime(args.value.CurrentDateTime.getTime() + args.timespan);
                                                       args.value.ExpireTicks = value;
                                                       if (value <= 0) {
                                                           sender.removeItem(args.key);
                                                       }
                                                       if (args.value.NeweggItemNumber == NEG.Page.model.Items[NEG.Page.model.CurrentItemIndex].NeweggItemNumber) {
                                                           NEG.Page.setTimeSpan(args.value);
                                                       }
                                                       return args.value;
                                                   });
    },
    setTimeSpan: function (item) {
        if (item.ExpireTicks <= 0) {
            NEG.Page.controls.timespan.end.hide();
            NEG.Page.controls.timespan.expired.show();
        } else {
            var content = NEG.Page.context["helper"].expiredTimeFormat2(item.ExpireTicks, item.ExpireTime);
            NEG.Page.controls.timespan.end.value.text(content);
            NEG.Page.controls.timespan.end.show();
            NEG.Page.controls.timespan.expired.hide();
        }
    },
    databind: function (model) {
        this.clear();
        this.model = model == undefined ? this.model : model;
        if (this.model != null) {
            var currentItem = this.model.Items[this.model.CurrentItemIndex];
            this.setDealExpired(currentItem);
            this.setTimeSpan(currentItem);
            this.controls.info.databind(this.model);
            this.controls.specification.databind(currentItem.Specification);
            this.controls.overview.databind(currentItem.OverView);
            this.controls["return"].databind(currentItem);
            this.controls.warranty.databind(currentItem);
            this.controls.manufacturer.databind(currentItem);
            var homeLink = this.controls.navgationContainer.find("a").first();
            var campaignLink = "";
            if (currentItem.CampaignName) {
                campaignLink = this.controls.navgationContainer.find("#breadcrumbCampaignLink").html();
                campaignLink = campaignLink.replace("/0", "/" + currentItem.CampaignId).replace("{name}", currentItem.CampaignName);
            }
            var itemSpan = this.controls.navgationContainer.find("#breadcrumbItem").html();
            itemSpan = itemSpan.replace("{itemnumber}", "Item#: " + currentItem.NeweggItemNumber);
            this.controls.navgationContainer.find(".thumbs").html(homeLink[0].outerHTML + " > " + campaignLink + itemSpan);
            this.controls.viewer.databind(currentItem);
        }
    },
    clear: function () {
        this.model = null;
        this.controls.viewer.clear();
        this.controls.info.clear();
        this.controls.specification.clear();
        this.controls.overview.clear();
        this.controls["return"].clear();
        this.controls.warranty.clear();
        this.controls.manufacturer.clear();
        this.controls.timespan.end.hide();
        this.controls.timespan.expired.hide();
        NEG.Layout.controls.ItemMonitor.removeItem("ProductDealExpired");
    },
    getAdditionInfo: function (itemNumber) {
        var helper = this.context.helper;
        var giftItem = jQuery("#btnGiftItem");
        var btnContainer = jQuery("#btnAddToCart");
        if (giftItem != null && !giftItem.is(":hidden")) {
            // gift item
            return;
        }
        var priceContainer = jQuery("#sellPrice");

        var requestUrl = StringResources.Config.ClientEvirment.GlobalPath + "/Product/AdditionalProductInfoHtml";
        /* For Newegg Central*/
        if (window.location.pathname.toLowerCase().indexOf('product.aspx') > 0) {
            requestUrl = window.location.pathname.toLowerCase().replace('product.aspx', 'Product/AdditionalProductInfoHtml');
        }

        if (priceContainer != null && !priceContainer.is(":hidden")) {
            jQuery.ajax({
                url: requestUrl,
                type: "POST",
                data: { itemNumber: itemNumber },
                success: function (infosting, textStatus) {
                    var makeGift = jQuery("#checklist");
                    var mirInfo = jQuery("#MIRInfoContainer");
                    var ironEggContainer = jQuery("#ironEggContainer");
                    var premierContainer = jQuery("#premierContainer");
                    var infos = infosting.split("||+||+||");
                    if (infos != null && infos.length == 4) {
                        if (infos[0].length == 0) {
                            mirInfo.hide();
                        } else {

                            mirInfo.html(infos[0]);
                            mirInfo.show();
                        }

                        if (infos[1].length == 0) {
                            ironEggContainer.hide();
                        } else {

                            ironEggContainer.html(infos[1]);
                            ironEggContainer.show();
                        }

                        if (infos[2].length == 0) {
                            makeGift.hide();
                        } else {
                            if (!jQuery("#btnAddToCart").is(":hidden")) {
                                makeGift.html(infos[2]);
                                makeGift.show();
                            } else {
                                makeGift.hide();
                            }
                        }
                         
                        if (infos[3].length == 0) {
                            premierContainer.hide();
                        } else { 
                                premierContainer.html(infos[3]);
                                premierContainer.show(); 
                        }
                        
                    }
                    var dftHeight = jQuery(".right .wrap").height() + 60;
                    jQuery(".section").css("min-height", dftHeight + "px");
                    helper.preparePopupMessage("#premierContainer", true);
                    helper.preparePopupMessage(".priceNote", true);
                    helper.preparePopupMessage("#checklist", true);
                    NEG.Page.setCssWidth();
                },
                complete: function (xmlHttpRequest, textStatus) {

                },
                error: function (xmlHttpRequest, textStatus, errorThrown) {
                    if (window.console) {
                        window.console.log(errorThrown);
                    }
                }
            });
        }
    },
    getEggPoints: function (itemNumber) {
        var helper = this.context.helper;
        var priceContainer = jQuery("#sellPrice");
        if (priceContainer != null && !priceContainer.is(":hidden")) {

            var giftItem = jQuery("#btnGiftItem");
            var btnContainer = jQuery("#btnAddToCart");
            if (giftItem != null && !giftItem.is(":hidden")) {
                // gift item
                return;
            }
            var requestUrl =  StringResources.Config.ClientEvirment.GlobalPath + "/Product/EggPointsInfoHtml";
            /* For Newegg Central*/
            if (window.location.pathname.toLowerCase().indexOf('product.aspx') > 0) {
                requestUrl = window.location.pathname.toLowerCase().replace('product.aspx', 'Product/EggPointsInfoHtml');
            }

            jQuery.ajax({
                url: requestUrl,
                type: "POST",
                data: { itemNumber: itemNumber, position: 'ProductDetail' },
                success: function (eggPointsHtml, textStatus) {
                    var eggPointsoContainer = jQuery("#eggPointsoContainer");
                    if (eggPointsHtml.length == "") {
                        eggPointsoContainer.hide();
                    } else {
                        eggPointsoContainer.html(eggPointsHtml);
                        eggPointsoContainer.show();
                        helper.preparePopupMessage("#eggPointsoContainer", true);
                    }
                    var dftHeight = jQuery(".right .wrap").height() + 60;
                    jQuery(".section").css("min-height", dftHeight + "px");
                    NEG.Page.setCssWidth();
                },
                complete: function (xmlHttpRequest, textStatus) {

                },
                error: function (xmlHttpRequest, textStatus, errorThrown) {
                    if (window.console) {
                        window.console.log(errorThrown);
                    }
                }
            });
        }
    },

    setCssWidth: function () {

        var g_url;
        var g_old_url = "old";
        var g_url960 = "";
        var g_url640 = "-mobile";
        var currWinWidth = jQuery(window).width(),
            isTouch = jQuery.IsTouchMedia(),
            winWidth = {
                _768: isTouch ? 768 : 751,
                _1024: isTouch ? 1024 : 1007
            };

        if (currWinWidth > winWidth._768 && currWinWidth <= winWidth._1024) {
            jQuery("body").addClass("w1024");
            if (jQuery.IsTouchMedia()) {
                jQuery('body').addClass('w1024Media');
            }
            g_url = g_url960;
        } else {
            jQuery("body").removeClass("w1024");
            if (jQuery.IsTouchMedia()) {
                jQuery('body').removeClass('w1024Media');
            }
            if (currWinWidth < winWidth._768) {
                g_url = g_url640;
            } else {
                g_url = g_url960;
            }
        }

        if (currWinWidth > winWidth._768) {
            jQuery("#productBullet").css({ "margin-top": "auto" });
        } else {
            jQuery("#productBullet").css({ "margin-top": jQuery("#price").height() + "px" });
        }

    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
