﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        jQuery(document).ready(function () {
            var dftHeight = jQuery(".right .wrap").height() + 100;
            jQuery(".section").css("min-height", dftHeight + "px");
        });
        this.controls["content"] = jQuery("#txtDataSource");
        if (this.controls["content"].length == 0) {
            return;
        } else {
            this.model = jQuery.parseJSON(NEG.Layout.controls.base64.decode(this.controls.content.val()));
            for (var index = 0; index < this.model.Items.length; index++) {
                var data = this.model.Items[index];
                NEG.Layout.needLogin(data.IsNeedLogin);
                data.CurrentDateTime = eval("new " + data.CurrentDateTime.replace(/\//g, ""));
                data.ExpireTime = eval("new " + data.ExpireTime.replace(/\//g, ""));
                NEG.Page.setDealExpired(data);
            }
        }

        this.controls["timespan"] = {
            end: jQuery("#productTitleContainer").find("#timeSpanContainer"),
            expired: jQuery("#productTitleContainer").find("#expiredContainer")
        };
        this.controls["timespan"].end.value = this.controls["timespan"].end.find("#value");
        this.controls["viewer"] = new Views.Product.ImageViewer(this);
        this.controls["info"] = new Views.Product.ProductInfo(this);
        this.controls["specification"] = new Views.Product.Specification(this);
        this.controls["overview"] = new Views.Product.Overview(this);
        this.controls["return"] = new Views.Product.ReturnPolicies(this);
        this.controls["warranty"] = new Views.Product.WarrantyInfo(this);
        this.controls["manufacturer"] = new Views.Product.ManufacturerContactInfo(this);
        this.controls["navgationContainer"] = jQuery("#navgationContainer");
        this.controls.info.load(jQuery("#productInfoContainer"));
        this.controls.viewer.load(jQuery("#imgViewerContainer"));
        this.controls.specification.load(jQuery("#specificationContainer"));
        this.controls.overview.load(jQuery("#overviewContainer"));
        this.controls["return"].load(jQuery("#returnContainer"));
        this.controls.warranty.load(jQuery("#warrantyContainer"));
        this.controls.manufacturer.load(jQuery("#manufacturerContainer"));
        this.controls.info.model = this.model;
    },
    setDealExpired: function (data) {
        NEG.Layout.controls.ItemMonitor.addItem("ProductDealExpired_" + data.NeweggItemNumber,
                                                   data,
                                                   function (sender, args) {
                                                       var value = args.value.ExpireTicks - args.timespan * 10000;
                                                       args.value.CurrentDateTime.setTime(args.value.CurrentDateTime.getTime() + args.timespan);
                                                       args.value.ExpireTicks = value;
                                                       if (value <= 0) {
                                                           sender.removeItem(args.key);
                                                       }
                                                       if (args.value.NeweggItemNumber == NEG.Page.model.Items[NEG.Page.model.CurrentItemIndex].NeweggItemNumber) {
                                                           NEG.Page.setTimeSpan(args.value);
                                                       }
                                                       return args.value;
                                                   });

    },
    setTimeSpan: function (item) {
        if (item.ExpireTicks <= 0) {
            NEG.Page.controls.timespan.end.hide();
            NEG.Page.controls.timespan.expired.show();
        } else {
            var content = NEG.Page.context["helper"].expiredTimeFormat2(item.CurrentDateTime, item.ExpireTime);
            NEG.Page.controls.timespan.end.value.text(content);
            NEG.Page.controls.timespan.end.show();
            NEG.Page.controls.timespan.expired.hide();
        }
    },
    databind: function (model) {
        this.clear();
        this.model = model == undefined ? this.model : model;
        if (this.model != null) {
            var currentItem = this.model.Items[this.model.CurrentItemIndex];
            this.setDealExpired(currentItem);
            this.setTimeSpan(currentItem);
            this.controls.info.databind(this.model);
            this.controls.specification.databind(currentItem.Specification);
            this.controls.overview.databind(currentItem.OverView);
            this.controls["return"].databind(currentItem);
            this.controls.warranty.databind(currentItem);
            this.controls.manufacturer.databind(currentItem);
            var homeLink = this.controls.navgationContainer.find("a").first();
            var campaignLink = "";
            if (currentItem.CampaignName) {
                campaignLink = this.controls.navgationContainer.find("#breadcrumbCampaignLink").html();
                campaignLink = campaignLink.replace("/0", "/" + currentItem.CampaignId).replace("{name}", currentItem.CampaignName);
            }
            var itemSpan = this.controls.navgationContainer.find("#breadcrumbItem").html();
            itemSpan = itemSpan.replace("{itemnumber}", "Item#: " + currentItem.NeweggItemNumber);
            this.controls.navgationContainer.find(".thumbs").html(homeLink[0].outerHTML + " > " + campaignLink + itemSpan);
            this.controls.viewer.databind(currentItem);
        }
    },
    clear: function () {
        this.model = null;
        this.controls.viewer.clear();
        this.controls.info.clear();
        this.controls.specification.clear();
        this.controls.overview.clear();
        this.controls["return"].clear();
        this.controls.warranty.clear();
        this.controls.manufacturer.clear();
        this.controls.timespan.end.hide();
        this.controls.timespan.expired.hide();
        NEG.Layout.controls.ItemMonitor.removeItem("ProductDealExpired");
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
