NEG.Layout = {
    controls: {},
    context: {
        ItemMonitor_TimeSpan: 45*1000    // set timespan for itemmonitor              
    },
    load: function () {
        var _self = this;
        var jQuery = this.context["jQuery"];
        //1 init control
        this.controls["header"] = jQuery("#Header");
        this.controls["section"] = jQuery(".section");
        this.controls["header"].logo = this.controls["header"].find("#LogoHeader");
        this.controls["footer"] = jQuery("#Footer");
        this.controls["footer"].logo = jQuery("#FooterLogo").find("#LogoFooter");
        this.controls["goTop"] = this.controls.footer.find(".goTopFix");
        this.controls["feedback"] = this.controls.footer.find(".feedback");
        //ItemMonitor
        function ItemMonitor(timespan) {
            var timerID = null;
            var items = {};
            var _self = this;
            this.addItem = function (key, value, callback) {
                items[key] = { value: value, callback: callback };
            };
            this.removeItem = function (key) {
                if (items.hasOwnProperty(key)) {
                    delete items[key];
                }
            };
            var onHandle = function () {
                for (var key in items) {
                    var item = items[key];
                    if (item.callback != null) {
                        item.value = item.callback(_self, { key: key, value: item.value, timespan: timespan });
                    }
                }
            };
            this.start = function () {
                if (timerID != null) {
                    this.stop();
                }
                var _self = this;
                timerID = setInterval(function () { onHandle(); }, timespan);
            };
            this.stop = function () {
                if (timerID != null) {
                    clearInterval(timerID);
                    timerID = null;
                }
            };
        }
        this.controls["ItemMonitor"] = new ItemMonitor(this.context.ItemMonitor_TimeSpan);
        this.controls["ItemMonitor"].start();
        //gzip
        this.controls["gzip"] = {
            encode: function (str) {
                var dict = {};
                var data = (str + "").split("");
                var out = [];
                var currChar;
                var phrase = data[0];
                var code = 256;
                for (var i = 1; i < data.length; i++) {
                    currChar = data[i];
                    if (dict[phrase + currChar] != null) {
                        phrase += currChar;
                    }
                    else {
                        out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
                        dict[phrase + currChar] = code;
                        code++;
                        phrase = currChar;
                    }
                }
                out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
                for (var i = 0; i < out.length; i++) {
                    out[i] = String.fromCharCode(out[i]);
                }
                return out.join("");
            },
            decode: function (str) {
                var dict = {};
                var data = (str + "").split("");
                var currChar = data[0];
                var oldPhrase = currChar;
                var out = [currChar];
                var code = 256;
                var phrase;
                for (var i = 1; i < data.length; i++) {
                    var currCode = data[i].charCodeAt(0);
                    if (currCode < 256) {
                        phrase = data[i];
                    }
                    else {
                        phrase = dict[currCode] ? dict[currCode] : (oldPhrase + currChar);
                    }
                    out.push(phrase);
                    currChar = phrase.charAt(0);
                    dict[code] = oldPhrase + currChar;
                    code++;
                    oldPhrase = phrase;
                }
                return out.join("");
            }
        };
        //base64
        this.controls["base64"] = {
            base64: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            encode: function (data) {
                var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
                  ac = 0,
                  enc = "",
                  tmp_arr = [];

                if (!data) {
                    return data;
                }

                do {
                    o1 = data.charCodeAt(i++);
                    o2 = data.charCodeAt(i++);
                    o3 = data.charCodeAt(i++);
                    bits = o1 << 16 | o2 << 8 | o3;
                    h1 = bits >> 18 & 0x3f;
                    h2 = bits >> 12 & 0x3f;
                    h3 = bits >> 6 & 0x3f;
                    h4 = bits & 0x3f;
                    tmp_arr[ac++] = this.base64.charAt(h1) + this.base64.charAt(h2) + this.base64.charAt(h3) + this.base64.charAt(h4);
                } while (i < data.length);
                enc = tmp_arr.join('');
                var r = data.length % 3;
                return (r ? enc.slice(0, r - 3) : enc) + '==='.slice(r || 3);
            },
            decode: function (data) {
                var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
                  ac = 0,
                  dec = "",
                  tmp_arr = [];

                if (!data) {
                    return data;
                }
                data += '';
                do {
                    h1 = this.base64.indexOf(data.charAt(i++));
                    h2 = this.base64.indexOf(data.charAt(i++));
                    h3 = this.base64.indexOf(data.charAt(i++));
                    h4 = this.base64.indexOf(data.charAt(i++));
                    bits = h1 << 18 | h2 << 12 | h3 << 6 | h4;
                    o1 = bits >> 16 & 0xff;
                    o2 = bits >> 8 & 0xff;
                    o3 = bits & 0xff;
                    if (h3 == 64) {
                        tmp_arr[ac++] = String.fromCharCode(o1);
                    } else if (h4 == 64) {
                        tmp_arr[ac++] = String.fromCharCode(o1, o2);
                    } else {
                        tmp_arr[ac++] = String.fromCharCode(o1, o2, o3);
                    }
                } while (i < data.length);
                dec = tmp_arr.join('');
                return dec;
            }
        };
        //deviceSizeChangeEvent
        this.controls["deviceSizeChangeEvent"] = {
            register: function (receiver, callback) {
                if (receiver && receiver != null) {
                    receiver.sizeChangeEventID = (Date.now || function () { return +new Date; })();
                    jQuery(window).bind("deviceSizeChange." + receiver.sizeChangeEventID, callback);
                }
            },
            unregister: function (receiver) {
                if (receiver && receiver != null && receiver.hasOwnProperty("sizeChangeEventID")) {
                    jQuery(window).unbind("deviceSizeChange." + receiver.sizeChangeEventID);
                    delete receiver.sizeChangeEventID;
                }
            },
            init: function () {
                //due screen size��>= 960,>=768,>=320
                var current = null;
                jQuery(window).bind("resize.deviceSizeChangeEvent", function () {
                    var value = (document.documentElement.clientWidth || document.body.clientWidth);
                    var width = 1080;
                    var isFullWebSite = (_self.context.cookie.get("FullWebSite") != "");

                    if (!isFullWebSite) {
                        if (value >= 960) {
                            width = 1080;
                        } else if (value >= 768) {
                            width = 960;
                        } else {
                            if (!(jQuery.IsIE(6) || jQuery.IsIE(7) || jQuery.IsIE(8))) {
                                if ((jQuery.IsIE(9) || jQuery.IsIE(10) || navigator.userAgent.indexOf('Firefox') >= 0) && value > 751) {
                                    width = 960;
                                } else if (document.width >= document.body.clientWidth || !document.width) {
                                    width = 640;
                                }
                            } else {
                                width = 960
                            }
                        }
                    } else {
                        width = 1080;
                    }

                    if (width != current) {
                        var setCurrent = function () {
                            jQuery(window).trigger("deviceSizeChange", [{ oldWidth: current, newWidth: width, width: value }]);
                            current = width;
                        };
                        if (current == null) {
                            setTimeout(function () {
                                setCurrent();
                            }, 0);
                        } else {
                            setCurrent();
                        }
                    }
                });
            }
        };
        this.controls["deviceSizeChangeEvent"].init();
        this.controls["deviceSizeChangeEvent"].register(this, function (sender, args) {
            var body = jQuery("body");
            if (args.newWidth == 1080 || args.newWidth == 640) {
                body.removeClass("w960");
                if (jQuery.IsTouchMedia()) {
                    body.removeClass('w960Media');
                }
            } else if (args.newWidth == 960) {
                body.addClass("w960");
                if (jQuery.IsTouchMedia()) {
                    body.addClass('w960Media');
                }
            }

            if (args.newWidth == 640) {
                _self.context["allowMenuFix"] = false;
            } else {
                _self.context["allowMenuFix"] = true;
            }
        });

        if (Views.Shared.HeaderMiniCartBar != undefined) {
            this.controls["cart"] = new Views.Shared.HeaderMiniCartBar(this);
            this.controls["cart"].load(jQuery("#HeaderMiniCartBarContainer"));
        }

        if (Views.Shared.HeaderUserInfoBar != undefined) {
            this.controls["account"] = new Views.Shared.HeaderUserInfoBar(this);
            this.controls["account"].load(jQuery("#HeaderUserInfoBarContainer"));
        }
        //2 bind event to control
        //jQuery.each([this.controls["header"].logo, this.controls["footer"].logo], function (index, item) {
        //    item.mouseover(function () {
        //        var userAgent = navigator.userAgent.toLowerCase();
        //        if (userAgent.indexOf('msie 7.0') > 0 ||
        //            userAgent.indexOf('msie 8.0') > 0 ||
        //            userAgent.indexOf('msie 6.0') > 0) return;
        //        if (item.find("div.logo_shadow_e").length == 0) {
        //            var shadow_e = jQuery('<div class="logo_shadow_e"></div>'),
        //            shadow_w = jQuery('<div class="logo_shadow_w"></div>');

        if (Views.Shared.HeaderMenuBar != undefined) {
            this.controls["menu"] = new Views.Shared.HeaderMenuBar(this);
            this.controls["menu"].load(jQuery("#HeaderMenuBarContainer"));
        }

        jQuery(window).bind("scroll.onScroll", NEG.Layout.onScroll)
         .bind("resize.footerFix", function () {
             _self.footerFix();
         })
        .trigger("scroll")
        .trigger("resize");
        
        jQuery(window).on("load", function () {
            jQuery(window).trigger("scroll").trigger("resize");
        });
        
        //ie placeholder
        if (jQuery.IsIE(6) || jQuery.IsIE(7) || jQuery.IsIE(8) || jQuery.IsIE(9)) {
            jQuery(".iePlaceholder .formText").each(function (index, element) {
                if (jQuery(this).val().length > 0) {
                    jQuery(this).siblings(".formTitle").hide();
                }
            }).keypress(function () {
                jQuery(this).siblings(".formTitle").hide();
            }).blur(function () {
                if (jQuery(this).val().length == 0) {
                    jQuery(this).siblings(".formTitle").show();
                }
            }).bind("paste",function () {
                jQuery(this).siblings(".formTitle").hide();
            });
        } else if (jQuery.IsIE(10)) {
            jQuery(".iePlaceholder .formTitle").hide();
        }
    },
    getPageScrollPostion: function () {
        var xScroll, yScroll;
        if (self.pageYOffset) {
            yScroll = self.pageYOffset;
            xScroll = self.pageXOffset;
        } else if (document.documentElement && document.documentElement.scrollTop) {	 // Explorer 6 Strict
            yScroll = document.documentElement.scrollTop;
            xScroll = document.documentElement.scrollLeft;
        } else if (document.body) {// all other Explorers
            yScroll = document.body.scrollTop;
            xScroll = document.body.scrollLeft;
        }
        return { x: xScroll, y: yScroll };
    },
    onScroll: function () {
        var jQuery = NEG.Layout.context.jQuery;
        var _self = NEG.Layout;
        var position = _self.getPageScrollPostion();
        var currentHeight = jQuery(document).height() - jQuery(window).height() - position.y;
        if (position.y > 0) {
            _self.controls.header.addClass("headerShaow");
        } else {
            _self.controls.header.removeClass("headerShadow");
        }
        _self.asideFun(_self);
        _self.menuFun(_self);

        if (position.y > 200) {
            _self.controls.goTop.show().css({ "display": "block" });
            _self.controls.goTop.addClass("fixed");
            if (currentHeight <= _self.controls.footer.height() + 30) {
                _self.controls.goTop.removeClass("fixed");
            }
        } else {
            _self.controls.goTop.show().css({ "display": "none" });
            _self.controls.goTop.removeClass("fixed");
        }
        _self.controls.feedback.css({"display": "block" });
        if (currentHeight <= _self.controls.footer.height() + 30) {
            _self.controls.feedback.css({ "position": "absolute", "top": "-146px"});
            if (jQuery.IsIE(7)) {
                _self.controls.feedback.css({
                    top: '-90px'
                })
            }
        } else {
            _self.controls.feedback.css({ "position": "", "top": "" });
        }
        _self.footerFix();
    },
    getDocumentHeight: function () {
        var doc = document;
        return Math.max(
                            doc.body.scrollHeight, doc.documentElement.scrollHeight,
                            doc.body.offsetHeight, doc.documentElement.offsetHeight,
                            doc.body.clientHeight, doc.documentElement.clientHeight
                        );
    },
    setFullWebSite: function () {
        NEG.Layout.context["cookie"].set("FullWebSite", "1");
        NEG.Layout.context["jQuery"](window).resize();
    },
    footerFix: function () {
        var jQuery = NEG.Layout.context.jQuery;
        if (!this.controls.footer.hasClass("hitTest")) {
            var isFooterFix;
            if ((isFooterFix = this.controls.footer.hasClass("footerFix"))) {
                this.controls.footer.addClass("hitTest");
                this.controls.footer.removeClass("footerFix");
            }

            var docHeight = NEG.Layout.getDocumentHeight();
            var viewPortHeight  = jQuery(window).height();  
            if (docHeight <= viewPortHeight ||
                jQuery("body").outerHeight() <= viewPortHeight) {
                this.controls.footer.addClass("footerFix");
            }
            this.controls.footer.removeClass("hitTest");
            if (isFooterFix != this.controls.footer.hasClass("footerFix")) {
                jQuery(window).trigger("resize");
            }
        }
    },
    asideFun: function asideFun(_self) {
        var o = this.context.jQuery("#ScrollFix");
        if (o[0]) {
            if (_self.getPageScrollPostion().y > 155) {
                o.removeAttr("style").addClass("fixed");
                if (_self.getPageScrollPostion().y - this.context.jQuery("#Header").height() >= this.context.jQuery(".section").height() - o.height()) {
                    var top = this.context.jQuery(".section").height() - o.height() - 70;
                    o.css({
                        "position": "absolute",
                        "top": top
                    });
                }
            } else {
                o.removeAttr("style").removeClass("fixed");
            }
        }
    },
    mask: function (obj, label) {
        var jQuery = this.context.jQuery;
        jQuery(obj).each(function () {
            var jObj = jQuery(this);
            if (jObj.hasClass("masked")) {
                NEG.Layout.unmask(jObj);
            }
            if (jObj.css("position") == "static") {
                jObj.addClass("masked-relative");
            }
            jObj.addClass("masked");

            var maskDiv = jQuery('<div class="loadmask"></div>');

            //auto height fix for IE
            if (navigator.userAgent.toLowerCase().indexOf("msie") > -1) {
                maskDiv.height(jObj.height() + parseInt(jObj.css("padding-top")) + parseInt(jObj.css("padding-bottom")));
                maskDiv.width(jObj.width() + parseInt(jObj.css("padding-left")) + parseInt(jObj.css("padding-right")));
            }

            //fix for z-index bug with selects in IE6
            if (navigator.userAgent.toLowerCase().indexOf("msie 6") > -1) {
                jObj.find("select").addClass("masked-hidden");
            }

            jObj.append(maskDiv);

            if (label !== undefined) {
                var maskMsgDiv = jQuery('<div class="loadmask-msg" style="display:none;"></div>');
                maskMsgDiv.append('<div>' + label + '</div>');
                jObj.append(maskMsgDiv);

                //calculate center position
                maskMsgDiv.css("top", Math.round(jObj.height() / 2 - (maskMsgDiv.height() - parseInt(maskMsgDiv.css("padding-top")) - parseInt(maskMsgDiv.css("padding-bottom"))) / 2) + "px");
                maskMsgDiv.css("left", Math.round(jObj.width() / 2 - (maskMsgDiv.width() - parseInt(maskMsgDiv.css("padding-left")) - parseInt(maskMsgDiv.css("padding-right"))) / 2) + "px");
                maskMsgDiv.show();
            }

        });
    },
    unmask: function (obj) {
        var jQuery = this.context.jQuery;
        jQuery(obj).each(function () {
            var jObj = jQuery(this);
            jObj.find(".loadmask-msg,.loadmask").remove();
            jObj.removeClass("masked");
            jObj.removeClass("masked-relative");
            jObj.find("select").removeClass("masked-hidden");
        });
    },
    menuFun: function (_self) {
        if (_self.context["allowMenuFix"]) {
            var o = this.context.jQuery("#Menu");
            if (o[0]) {
                if (_self.getPageScrollPostion().y > 75) {
                    o.removeAttr("style").addClass("fixed");
                    if (_self.getPageScrollPostion().y - this.context.jQuery("#Header").height() >= this.context.jQuery(".section").height() - o.height()) {
                        var top = this.context.jQuery(".section").height() - o.height() - 46;
                        o.css({
                            "position": "absolute",
                            "top": top
                        });
                    }
                } else {
                    o.removeAttr("style").removeClass("fixed");
                }
            }
        }
    },
    needLogin: function (needLogin) {
        if (needLogin) {
            var jQuery = this.context["jQuery"];
            var forceLogin = jQuery("body").attr("data-needLogin");
            if (forceLogin != "False") {
                var info = NEG.Layout.context["cookie"].get('NV_OTHERINFO');
                if (info == "" && needLogin) {
                    window.location.href = "http://" + window.location.host +
                                           "?url=" + encodeURI(window.location.href);
                }
            }
        }
    }
};
NEG.run(function (require) {
    NEG.Layout.context["jQuery"] = require("Utility.JQuery");
    NEG.Layout.context["cookie"] = require("Utility.Cookie");
    require("Utility.Plugins");
    NEG.Layout.load();
});
