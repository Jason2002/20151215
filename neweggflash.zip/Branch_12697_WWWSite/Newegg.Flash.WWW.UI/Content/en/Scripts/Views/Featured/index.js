﻿NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        var _self = this;
        NEG.Layout.needLogin(false);
        this.controls["list"] = new Views.Featured.FeaturedDealsList(this);
        this.controls["list"].load(jQuery("#featured"));
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
