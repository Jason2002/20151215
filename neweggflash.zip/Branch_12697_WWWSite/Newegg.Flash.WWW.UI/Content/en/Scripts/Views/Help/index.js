﻿NEG.Module('Views.Help._HelpMenu', function (require) {
    var jQuery = require("Utility.JQuery");

    NEG.NS("Views.Help")["HelpMenu"] = function (parent) {
        this.parent = parent;
        this.controls = {};
        this.context = { jQuery: jQuery };
        var _self = this;

        this.load = function (container) {
            this.controls["MenuTitle"] = container.find(".menu_title");
            this.controls["Menu"] = container.find(".menu_title").next(".menu");

            this.controls["MenuTitle"].click(function () {
                _self.controls["Menu"].slideToggle(200);
            });

            this.deviceSizeChange = function(sender, args){ 
                if (args.oldWidth == 640 && (args.newWidth >=1024)) {
                    NEG.Layout.menuFun(NEG.Layout);
                }else if(args.newWidth == 640){
                    _self.controls["Menu"].removeAttr("style").removeClass("fixed");
                }
            };

            NEG.Layout.controls.deviceSizeChangeEvent.register(this, this.deviceSizeChange);
        };
    };
});

NEG.Page = {
    controls: {},
    context: {},
    model: null,
    load: function () {
        var jQuery = this.context.jQuery;
        new Views.Help.HelpMenu(this).load(jQuery(".menu_wrap"));
    }
};

NEG.run(function (require) {
    NEG.Page.context["jQuery"] = require("Utility.JQuery");
    NEG.Page.context["helper"] = require("Utility.Helper");
    NEG.Page.load();
});
