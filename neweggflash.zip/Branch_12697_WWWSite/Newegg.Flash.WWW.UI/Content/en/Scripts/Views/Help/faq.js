﻿NEG.Module('Views.Help._FAQ', function (require) {
    var jQuery = require("Utility.JQuery");
    function ContactUs(parent) {
        var _self = this;
        this.parent = parent;
        this.controls = {};
        this.context = { jQuery: jQuery };

        this.load = function (container) {
            var _anchor = window.location.href.split('#')[1];
            var _padding = jQuery(window).width() > 768 ? 70 : 0;
            jQuery('html,body').animate({ scrollTop: jQuery('#faq_' + _anchor).offset().top - _padding }, 0);
            if (_padding != 0) {
                jQuery("#Menu").addClass("fixed");
            }
        }
    }
    NEG.NS("Views.Help")["FAQ"] = ContactUs;
});

NEG.run(function (require) {
    var jQuery = require("Utility.JQuery");
    new Views.Help.FAQ(this).load(jQuery("#container"));
});