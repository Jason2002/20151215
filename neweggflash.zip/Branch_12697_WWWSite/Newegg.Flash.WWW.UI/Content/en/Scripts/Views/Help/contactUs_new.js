﻿NEG.Module('Views.Help._ContactUs', function (require) {
    var jQuery = require("Utility.JQuery");
    function ContactUs(parent) {
        var _self = this;
        this.parent = parent;
        this.controls = {};
        this.context = { jQuery: jQuery };

        this.load = function (container) {
            this.controls["loading"] = container.find("#loading-mask");
            this.controls["IframeContactUs"] = container.find("#IframeContactUs");
            this.controls["contactUsSmall"] = container.find("#contactUsSmall");
            this.controls["iframeContactUs"] = container.find("#iframeContactUs"); 
            this.controls["loading"].show();
            jQuery(window).resize(function () {
                var width = _self.controls["IframeContactUs"].width() - 3;
                _self.controls["iframeContactUs"].width(width);
            });

            this.deviceSizeChange = function (sender, args) {
                var isTouch = jQuery.IsTouchMedia();
                if (isTouch) {
                    if (args.newWidth <= 1024)
                    {
                        _self.controls["IframeContactUs"].hide();
                        _self.controls["contactUsSmall"].show();
                        _self.controls["contactUsSmall"].addClass("contactUs_iefix");
                        _self.controls["loading"].hide();
                    } else
                    {
                        _self.controls["IframeContactUs"].show();
                        _self.controls["contactUsSmall"].hide();
                    }
                } else {
                    _self.controls["IframeContactUs"].show();
                    var width = _self.controls["IframeContactUs"].width() - 3;
                    _self.controls["iframeContactUs"].width(width);
                }
            }

            var oFrm = document.getElementById("iframeContactUs");
            oFrm.onload = function () { 
                _self.controls["loading"].hide();
            }

            NEG.Layout.controls.deviceSizeChangeEvent.register(this, this.deviceSizeChange);
        }
    }
    NEG.NS("Views.Help")["ContactUs"] = ContactUs;
});

NEG.run(function (require) {
    var jQuery = require("Utility.JQuery");
    new Views.Help.ContactUs(this).load(jQuery("#container"));
});
