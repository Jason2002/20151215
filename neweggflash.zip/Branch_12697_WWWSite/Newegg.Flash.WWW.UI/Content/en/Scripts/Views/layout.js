NEG.Layout = {
    controls: {},
    context: {
        ItemMonitor_TimeSpan: 45*1000    // set timespan for itemmonitor              
    },
    load: function () { 
        var _self = this;
        var jQuery = this.context["jQuery"];
        var cookieAdapter = this.context["cookieAdapter"]; 
        //var oldURl = cookieAdapter.context.getTopLevelDomain();

        //if (cookieAdapter.context.isNewHost()) {
            // cookie import ajax 
            //if (!this.isExistsInCookie('syn')
            //    || document.location.search.toLowerCase().indexOf('syn') > 0
            //    || document.referrer.toLowerCase().indexOf(oldURl) > 0) {
            //    var syncurl = cookieAdapter.context.getHostName() + '/CookieSync';

            //    jQuery.ajax({
            //        url: syncurl,
            //        dataType: "jsonp",
            //        success: function (data) {
            //            cookieAdapter.importCookie(data);
            //            _self.controls.cart.syncMiniCookie(_self.controls.cart.databind);
            //        }
            //    });
            //}
        //}  

        if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
            jQuery("body").addClass("bodyIE");
        }
        
        //set placeholder for IE browser, just normal size, without narrow size
        jQuery('#MiniSearch input[placeholder]').placeholder();

        //1 init control
        this.controls["header"] = jQuery("#Header");
        this.controls["section"] = jQuery(".section");
        this.controls["header"].logo = this.controls["header"].find("#LogoHeader");
        this.controls["main"] = jQuery("#Main");
        this.controls["main"].appTip = this.controls.main.find("#MobileGuide");
        this.controls["footer"] = jQuery("#Footer");
        this.controls["footer"].logo = jQuery("#FooterLogo").find("#LogoFooter");

        this.controls["goTop"] = jQuery("#GoTop");
        this.controls["feedback"] = jQuery("#FBK");
        //ItemMonitor
        function ItemMonitor(timespan) {
            var timerID = null;
            var items = {};
            var _self = this; 
            this.addItem = function (key, value, callback) {
                items[key] = { value: value, callback: callback };
            };
            this.removeItem = function (key) {
                if (items.hasOwnProperty(key)) {
                    delete items[key];
                }
            };
            var onHandle = function () {
                for (var key in items) {
                    var item = items[key];
                    if (item.callback != null) {
                        item.value = item.callback(_self, { key: key, value: item.value, timespan: timespan });
                    }
                }
            };
            this.start = function () {
                if (timerID != null) {
                    this.stop();
                }
                var _self = this;
                timerID = setInterval(function () { onHandle(); }, timespan);
            };
            this.stop = function () {
                if (timerID != null) {
                    clearInterval(timerID);
                    timerID = null;
                }
            };
        }
        this.controls["ItemMonitor"] = new ItemMonitor(this.context.ItemMonitor_TimeSpan);
        this.controls["ItemMonitor"].start();
        //gzip
        this.controls["gzip"] = {
            encode: function (str) {
                var dict = {};
                var data = (str + "").split("");
                var out = [];
                var currChar;
                var phrase = data[0];
                var code = 256;
                for (var i = 1; i < data.length; i++) {
                    currChar = data[i];
                    if (dict[phrase + currChar] != null) {
                        phrase += currChar;
                    }
                    else {
                        out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
                        dict[phrase + currChar] = code;
                        code++;
                        phrase = currChar;
                    }
                }
                out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
                for (var i = 0; i < out.length; i++) {
                    out[i] = String.fromCharCode(out[i]);
                }
                return out.join("");
            },
            decode: function (str) {
                var dict = {};
                var data = (str + "").split("");
                var currChar = data[0];
                var oldPhrase = currChar;
                var out = [currChar];
                var code = 256;
                var phrase;
                for (var i = 1; i < data.length; i++) {
                    var currCode = data[i].charCodeAt(0);
                    if (currCode < 256) {
                        phrase = data[i];
                    }
                    else {
                        phrase = dict[currCode] ? dict[currCode] : (oldPhrase + currChar);
                    }
                    out.push(phrase);
                    currChar = phrase.charAt(0);
                    dict[code] = oldPhrase + currChar;
                    code++;
                    oldPhrase = phrase;
                } 
                return out.join("");
            }
        };
        //base64
        this.controls["base64"] = {
            base64: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            encode: function (data) {
                var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
                  ac = 0,
                  enc = "",
                  tmp_arr = [];

                if (!data) {
                    return data;
                }

                do {
                    o1 = data.charCodeAt(i++);
                    o2 = data.charCodeAt(i++);
                    o3 = data.charCodeAt(i++);
                    bits = o1 << 16 | o2 << 8 | o3;
                    h1 = bits >> 18 & 0x3f;
                    h2 = bits >> 12 & 0x3f;
                    h3 = bits >> 6 & 0x3f;
                    h4 = bits & 0x3f;
                    tmp_arr[ac++] = this.base64.charAt(h1) + this.base64.charAt(h2) + this.base64.charAt(h3) + this.base64.charAt(h4);
                } while (i < data.length);
                enc = tmp_arr.join('');
                var r = data.length % 3;
                return (r ? enc.slice(0, r - 3) : enc) + '==='.slice(r || 3);
            },
            decode: function (data) {
                var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
                  ac = 0,
                  dec = "",
                  tmp_arr = [];

                if (!data) {
                    return data;
                }
                data += '';
                do {
                    h1 = this.base64.indexOf(data.charAt(i++));
                    h2 = this.base64.indexOf(data.charAt(i++));
                    h3 = this.base64.indexOf(data.charAt(i++));
                    h4 = this.base64.indexOf(data.charAt(i++));
                    bits = h1 << 18 | h2 << 12 | h3 << 6 | h4;
                    o1 = bits >> 16 & 0xff;
                    o2 = bits >> 8 & 0xff;
                    o3 = bits & 0xff;
                    if (h3 == 64) {
                        tmp_arr[ac++] = String.fromCharCode(o1);
                    } else if (h4 == 64) {
                        tmp_arr[ac++] = String.fromCharCode(o1, o2);
                    } else {
                        tmp_arr[ac++] = String.fromCharCode(o1, o2, o3);
                    }
                } while (i < data.length);
                dec = tmp_arr.join(''); 
                return unescape(dec);
            }
        };
        //fix ios orientation bug
        /*
        this.controls["orientationFixed"] = {
            current: null,
            args:null,
            init: function () {
                var agent = navigator.userAgent;
                var result = null;
                var _self = this;
                if ((agent.match(/iPhone/i) || agent.match(/iPad/i)) && agent.indexOf("OS 5_") > -1) {
                    var viewport = document.querySelector('meta[name="viewport"]');
                        body = document.body;
                    if (viewport) {
                        var params = viewport.content.match(/([^=,]+)=([^=,]+)/ig);
                        for (var index = 0; index < params.length; index++) {
                            var item = params[index].match(/([^=,]+)/ig);
                            if (this.args == null) {
                                this.args = {};
                            }
                            this.args[item[0]] = item[1];
                        }

                        if (this.args["minimum-scale"]) {
                            this.args["minimum-scale"] = Number(this.args["minimum-scale"]);
                        }

                        if (this.args["maximum-scale"]) {
                            this.args["maximum-scale"] = Number(this.args["maximum-scale"]);
                        }

                        if (this.args["initial-scale"]) {
                            this.args["initial-scale"] = Number(this.args["initial-scale"]);
                        }
                        viewport.content = "width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0";

                        body.addEventListener("orientationchange", function () {
                            body.style.webkitTransform = "scale(" + _self.args["initial-scale"] + ")";
                        }, false);
                        body.addEventListener("gesturechange", function (event) {
                            _self.current = event.scale;
                            if (_self.current > _self.args["maximum-scale"]) {
                                _self.current = _self.args["maximum-scale"];
                            } else if (_self.current < _self.args["minimum-scale"]) {
                                _self.current = _self.args["minimum-scale"];
                            }
                            body.style.webkitTransform = "scale(" + _self.current + ")";
                        },false);
                    }
                }
                return this;
            }
        }.init();
        */
        //mobileAppTip
        this.controls["mobileTip"] = {
            init: function () {
                var userAgentInfo = navigator.userAgent;
                if (userAgentInfo.indexOf('Android') > -1) {
                    _self.controls.main.appTip.show().find("#andriodApp").show();
                } else if (userAgentInfo.indexOf('iPhone') > -1 || userAgentInfo.indexOf('iPod') > -1) {
                    _self.controls.main.appTip.show().find("#appleApp").show();
                }
                return this;
            }
        }.init();
       
        //deviceSizeChangeEvent
        this.controls["deviceSizeChangeEvent"] = {
            register: function (receiver, callback) {
                if (receiver && receiver != null) {
                    receiver.sizeChangeEventID = (Date.now || function () { return +new Date; })();
                    jQuery(window).bind("deviceSizeChange." + receiver.sizeChangeEventID, callback);
                }
            },
            unregister: function (receiver) {
                if (receiver && receiver != null && receiver.hasOwnProperty("sizeChangeEventID")) {
                    jQuery(window).unbind("deviceSizeChange." + receiver.sizeChangeEventID);
                    delete receiver.sizeChangeEventID;
                }
            },
            init: function () {
                //due screen size��> 960,>768,>320
                var current = null;
                jQuery(window).bind("resize.deviceSizeChangeEvent", function () { 
                    var winWidth = (document.documentElement.clientWidth || document.body.clientWidth);
                    if (!jQuery.IsTouchMedia()) {
                        //+scroll width;
                        winWidth += 17;
                    }
                    var width = 1025;
                    var minWidth = jQuery.IsTouchMedia() ? 768 : 751;
                     
                    //var isFullWebSite = (_self.context.cookie.get("FullWebSite") != "");
                    var isFullWebSite = (_self.context.cookieAdapter.getCookie("FullWebSite") != "")
                                        && (_self.context.cookieAdapter.getCookie("FullWebSite") != "{}");

                    if (!isFullWebSite) {
                        if (winWidth <= minWidth) {
                            width = 640;
                        }else if (winWidth > minWidth && winWidth <= 1024) {
                            width = 1024;
                        } else {
                            width = 1025;
                        }
                    } else {
                        width = 1025;
                    }
                    if (width != current) {
                        var setCurrent = function () {
                            jQuery(window).trigger("deviceSizeChange", [{oldWidth: current, newWidth: width, width: winWidth}]);
                            current = width;
                        };
                        if (current == null) {
                            jQuery(function () {
                                setCurrent();
                            });
                        } else {
                            setCurrent();
                        }
                    }
                    setTimeout(function () {
                        jQuery(window).trigger("scroll");
                        setTimeout(function () {
                            jQuery(window).trigger("scroll");
                        }, 1000);
                    }, 1000);
                });
            }
        };
        this.controls["deviceSizeChangeEvent"].init();
        this.controls["deviceSizeChangeEvent"].register(this, function (sender, args) {
            var body = jQuery("body");
            if (args.newWidth == 1025 || args.newWidth == 640) {
                body.removeClass("w1024");
                if (jQuery.IsTouchMedia()) {
                    body.removeClass('w1024Media');
                }
            } else if (args.newWidth == 1024) {
                body.addClass("w1024");
                if (jQuery.IsTouchMedia()) {
                    body.addClass('w1024Media');
                }
            }

            if (args.newWidth == 640) {
                _self.context["allowMenuFix"] = false;
            } else {
                _self.context["allowMenuFix"] = true;
            }
        });

        if (Views.Shared.HeaderMiniCartBar != undefined && jQuery("#HeaderMiniCartBarContainer").length > 0) {
            this.controls["cart"] = new Views.Shared.HeaderMiniCartBar(this);
            this.controls["cart"].load(jQuery("#HeaderMiniCartBarContainer"));
        }

        if (Views.Shared.HeaderUserInfoBar != undefined && jQuery("#HeaderUserInfoBarContainer").length > 0) {
            this.controls["account"] = new Views.Shared.HeaderUserInfoBar(this);
            this.controls["account"].load(jQuery("#HeaderUserInfoBarContainer"));
        }

        if (Views.Shared.HeaderMenuBar != undefined && jQuery("#HeaderMenuBarContainer").length>0) {
            this.controls["menu"] = new Views.Shared.HeaderMenuBar(this);
            this.controls["menu"].load(jQuery("#HeaderMenuBarContainer"));
        }

        if (Views.Shared.HeaderSearchBar != undefined && jQuery("#HeaderSearchBarContainer").length > 0) {
            this.controls["search"] = new Views.Shared.HeaderSearchBar(this);
            this.controls["search"].load(jQuery("#HeaderSearchBarContainer"));
        }

        jQuery(window).bind("scroll.onScroll", NEG.Layout.onScroll)
         .bind("resize.footerFix", function () {
             _self.footerFix();
         });
          
        setTimeout(function () {
            jQuery(window).trigger("scroll").trigger("resize");
            setTimeout(function () {
                jQuery(window).trigger("scroll").trigger("resize");
                setTimeout(function () {
                    jQuery(window).trigger("scroll").trigger("resize");
                }, 1000);
            }, 1000);
        },0);
        if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
            setTimeout(function () {
                _self.footerFix();
            }, 2000);
        }
        
        //ie placeholder
        jQuery(function () {
            if (jQuery.IsIE(6) || jQuery.IsIE(7) || jQuery.IsIE(8) || jQuery.IsIE(9)) {
                var handle = function (sender, isKeypress) {
                    if (sender.val().length == 0 && !isKeypress) {
                        sender.siblings(".formTitle").show();
                    } else {
                        sender.siblings(".formTitle").hide();
                    }
                };
                jQuery(".iePlaceholder .formText").each(function (index, element) {
                    handle(jQuery(this));
                }).keypress(function () {
                    handle(jQuery(this),true);
                }).blur(function () {
                    handle(jQuery(this));
                }).bind("paste", function () {
                    handle(jQuery(this));
                });

                jQuery('.formTitle').click(function () {
                    jQuery('#' + jQuery(this).attr('for')).focus();
                });
            } else if (jQuery.IsIE(10)) {
                jQuery(".iePlaceholder .formTitle").hide();
            }
        });

        /* gotop & feedback */
        this.controls["feedback"].hover(function () {
            if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
                window.fbTimer = undefined;
            } else {
                jQuery(this).addClass('hover');
                var j = 0;
                window.fbTimer = setInterval(function () {
                    j++;
                    document.getElementById('FBK').style.backgroundPosition = -j * 60 + "px" + " 0px";

                    if (j == 22) {
                        clearTimeout(fbTimer);
                    }
                }, 24)
            }
        }, function () {
            clearTimeout(fbTimer);
            document.getElementById('FBK').style.backgroundPosition = "0px 0px";
            jQuery(this).removeClass('hover');
        });


        this.controls["goTop"].hover(function () {
            if (window.isEmit) {
                return;
            }

            if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
                window.goTopTimer = undefined;
            } else {
                jQuery(this).addClass('hover');
                var i = 0;
                window.goTopTimer = setInterval(function () {
                    i++;
                    document.getElementById('GoTop').style.backgroundPosition = -i * 72 + "px" + " 0px";

                    if (i == 24) {
                        clearTimeout(goTopTimer);
                    }
                }, 24)
            }
        }, function () {
            if (!window.isEmit && window.goTopTimer) {
                clearTimeout(goTopTimer);
                document.getElementById('GoTop').style.backgroundPosition = "0px 0px";
                _self.controls["goTop"].removeClass('hover');
            }
        });


        this.controls["goTop"].mousedown(function () {
            clearTimeout(goTopTimer);

            if (jQuery.IsIE(7) || jQuery.IsIE(8)) {
                return;
            }

            var i = 25;
            window.goTopTimer = setInterval(function () {
                i++;
                document.getElementById('GoTop').style.backgroundPosition = -i * 72 + "px" + " 0px";

                if (i == 43) {
                    i = 40;
                }
            }, 24);
        });

        this.controls["goTop"].click(function () {

            window.isEmit = true;

            clearTimeout(goTopTimer);

            if (!jQuery.IsIE(7) && !jQuery.IsIE(8)) {
                var i = 44;

                window.goTopTimer = setInterval(function () {
                    i++;
                    document.getElementById('GoTop').style.backgroundPosition = -i * 72 + "px" + " 0px";

                    if (i == 48) {
                        i = 44;
                    }
                }, 24);
            }

            var _time = parseFloat(_self.controls["goTop"].offset().top) - 800;
            _time = _time > 1200 ? 1200 : _time;
            _time = _time < 800 ? 800 : _time;

            if (!jQuery.IsIE(7) && !jQuery.IsIE(8)) {
                _self.controls["goTop"].addClass('emit').css({ 'bottom': 'auto', 'top': parseFloat(jQuery(window).height()) - parseFloat(_self.controls["goTop"].css('bottom')) - 52 })
                .animate({ 'top': 0 }, _time, 'easeIn', function () {
                    clearTimeout(goTopTimer);
                    _self.controls["goTop"].removeClass('dis hover emit');
                    window.isEmit = false;
                });
            } else {
                clearTimeout(goTopTimer);
                _self.controls["goTop"].removeClass('dis hover emit');
                window.isEmit = false;
            }

            jQuery("html, body").animate({ scrollTop: 0 }, _time, 'easeIn');
        });

        jQuery(window).bind("orientationchange", function () {
            setTimeout(function () {
                _self.controls.header.removeClass("headerShadow");
                jQuery('#Main').css('padding-top', 0);
            }, 100);
        });
    },
    //isExistsInCookie: function (key) {
    //    var ck = document.cookie;
    //    if (ck) {
    //        var i = ck.indexOf(key + '='); if (i > -1) {
    //            var j = ck.indexOf(';', i);
    //            return escape(ck.substring(i + n.length + 1, j < 0 ? ck.length : j))
    //        }
    //    }
    //},
    getPageScrollPostion: function () {
        var xScroll, yScroll;
        if (self.pageYOffset) {
            yScroll = self.pageYOffset;
            xScroll = self.pageXOffset;
        } else if (document.documentElement && document.documentElement.scrollTop) {	 // Explorer 6 Strict
            yScroll = document.documentElement.scrollTop;
            xScroll = document.documentElement.scrollLeft;
        } else if (document.body) {// all other Explorers
            yScroll = document.body.scrollTop;
            xScroll = document.body.scrollLeft;
        }
        return { x: xScroll, y: yScroll };
    },
    onScroll: function () {
        var jQuery = NEG.Layout.context.jQuery;
        var _self = NEG.Layout;
        var position = _self.getPageScrollPostion();
        var currentHeight = jQuery(document).height() - jQuery(window).height() - position.y;

        if (jQuery(window).width() > 1024 && position.y > 0) {
            _self.controls.header.addClass("headerShadow");
            jQuery('#Main').css('padding-top', 60);
        } else {
            _self.controls.header.removeClass("headerShadow");
            jQuery('#Main').css('padding-top', 0);
        }

        _self.asideFun(_self);
        _self.menuFun(_self);
        _self.footerFix();
    },
    getDocumentHeight: function () {
        var jQuery = NEG.Layout.context.jQuery;
        var doc = document;
        return jQuery.IsIE(7) ?
                Math.max(doc.body.scrollHeight, doc.body.offsetHeight, doc.body.clientHeight) :
                Math.max(
                            doc.body.scrollHeight, doc.documentElement.scrollHeight,
                            doc.body.offsetHeight, doc.documentElement.offsetHeight,
                            doc.body.clientHeight, doc.documentElement.clientHeight
                        );
    },
    setFullWebSite: function () {
        NEG.Layout.context["cookie"].set("FullWebSite", "1");
        NEG.Layout.context["jQuery"](window).resize();
    },
    footerFix: function () {
        var _self = NEG.Layout;
        var jQuery = NEG.Layout.context.jQuery;
        if (!jQuery.IsIE(7) && !jQuery.IsIE(8)) {
            if (jQuery(window).width() <= 768) {
                _self.controls.footer.height('auto');
            } else {
                var height = _self.controls.footer.attr("data-height");
                if (height) {
                    _self.controls.footer.height(Number(height));
                } else {
                    _self.controls.footer.height(250);
                }
            }
            _self.controls.main.css('padding-bottom', _self.controls.footer.outerHeight());
        }
        _self.controls.footer.css("visibility", "visible");

            jQuery.setGotopFeedback();
    },
    asideFun: function asideFun(_self) {
        var o = this.context.jQuery("#ScrollFix");
        if (o[0]) {
            if (_self.getPageScrollPostion().y > 155) {
                o.removeAttr("style").addClass("fixed");
                if (_self.getPageScrollPostion().y - this.context.jQuery("#Header").height() >= this.context.jQuery(".section").height() - o.height()) {
                    var top = this.context.jQuery(".section").height() - o.height() - 70;
                    o.css({
                        "position": "absolute",
                        "top": top
                    });
                }
            } else {
                o.removeAttr("style").removeClass("fixed");
            }
        }
    },
    mask: function (obj, label) {
        var jQuery = this.context.jQuery;
        jQuery(obj).each(function () {
            var jObj = jQuery(this);
            if (jObj.hasClass("masked")) {
                NEG.Layout.unmask(jObj);
            }
            if (jObj.css("position") == "static") {
                jObj.addClass("masked-relative");
            }
            jObj.addClass("masked");

            var maskDiv = jQuery('<div class="loadmask"></div>');

            //auto height fix for IE
            if (navigator.userAgent.toLowerCase().indexOf("msie") > -1) {
                maskDiv.height(jObj.height() + parseInt(jObj.css("padding-top")) + parseInt(jObj.css("padding-bottom")));
                maskDiv.width(jObj.width() + parseInt(jObj.css("padding-left")) + parseInt(jObj.css("padding-right")));
            }

            //fix for z-index bug with selects in IE6
            if (navigator.userAgent.toLowerCase().indexOf("msie 6") > -1) {
                jObj.find("select").addClass("masked-hidden");
            }

            jObj.append(maskDiv);

            if (label !== undefined) {
                var maskMsgDiv = jQuery('<div class="loadmask-msg" style="display:none;"></div>');
                maskMsgDiv.append('<div>' + label + '</div>');
                jObj.append(maskMsgDiv);

                //calculate center position
                maskMsgDiv.css("top", Math.round(jObj.height() / 2 - (maskMsgDiv.height() - parseInt(maskMsgDiv.css("padding-top")) - parseInt(maskMsgDiv.css("padding-bottom"))) / 2) + "px");
                maskMsgDiv.css("left", Math.round(jObj.width() / 2 - (maskMsgDiv.width() - parseInt(maskMsgDiv.css("padding-left")) - parseInt(maskMsgDiv.css("padding-right"))) / 2) + "px");
                maskMsgDiv.show();
            }

        });
    },
    unmask: function (obj) {
        var jQuery = this.context.jQuery;
        jQuery(obj).each(function () {
            var jObj = jQuery(this);
            jObj.find(".loadmask-msg,.loadmask").remove();
            jObj.removeClass("masked");
            jObj.removeClass("masked-relative");
            jObj.find("select").removeClass("masked-hidden");
        });
    },
    menuFun: function (_self) {
        if (_self.context["allowMenuFix"]) {
            var o = this.context.jQuery("#Menu");
            if (o[0]) {
                if (_self.getPageScrollPostion().y > 75) {
                    o.removeAttr("style").addClass("fixed");
                    if (_self.getPageScrollPostion().y - this.context.jQuery("#Header").height() >= this.context.jQuery(".section").height() - o.height()) {
                        var top = this.context.jQuery(".section").height() - o.height() - 46;
                        o.css({
                            "position": "absolute",
                            "top": top
                        });
                    }
                } else {
                    o.removeAttr("style").removeClass("fixed");
                }
            }
        }
    },
    needLogin: function (needLogin) {
        if (needLogin) {
            var jQuery = this.context["jQuery"];
            var forceLogin = jQuery("body").attr("data-needLogin");
            if (forceLogin != "False") { 
                var info = NEG.Layout.context["cookieAdapter"].getCookie('NV_OTHERINFO');
                    //NEG.Layout.context["cookie"].get('NV_OTHERINFO');
                if (info == "" && needLogin) {
                    window.location.href = "http://" + window.location.host +
                                           "?url=" + encodeURI(window.location.href);
                }
            }
        }
    }
};
NEG.run(function (require) {
    NEG.Layout.context["jQuery"] = require("Utility.JQuery");
    NEG.Layout.context["cookie"] = require("Utility.Cookie");
    NEG.Layout.context["cookieAdapter"] = require("Utility.CookieAdapter");
    require("Utility.Plugins");
    NEG.Layout.load();
});
