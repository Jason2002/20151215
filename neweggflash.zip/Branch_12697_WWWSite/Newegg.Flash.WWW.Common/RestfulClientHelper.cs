﻿using System.Web;
using Newegg.EC.Net.Http;
using Newegg.Framework.Threading;

namespace Newegg.Flash.WWW.Common
{
    /// <summary>
    /// RestfulRequestHelper info.
    /// </summary>
    public static class RestfulClientHelper
    {
        public static string RegionCode
        {
            get
            {
                var regionCode = LogicalThreadContext.GetData("ThreadStorage_Key_RegionCodeValue");
                if (null == regionCode)
                {
                    return "USA";
                }
                else
                {
                    return regionCode.ToString().Trim();
                }
            }
        }

        public static string CurrencyCode
        {
            get
            {
                var currencyCode = LogicalThreadContext.GetData("ThreadStorage_Key_CurrencyCodeValue");
                if (null == currencyCode)
                {
                    return "USD";
                }
                else
                {
                    return currencyCode.ToString().Trim();
                }
            }
        }

        /// <summary>
        /// Get Request From Configuration With RequestHeader.
        /// </summary>
        /// <param name="me">IRestfulClient param.</param>
        /// <param name="configName">ConfigName param.</param>
        /// <returns>RestfulRequest instance.</returns>
        public static IRestfulRequest GetRequestFromConfigurationWithRegion(this IRestfulClient me, string configName)
        {
            var request = me.GetRequestFromConfiguration(configName);

            request.SetUrlParameter("RegionCode", RegionCode);
            request.SetUrlParameter("CurrencyCode", CurrencyCode);
            request.IsAwaitContext = false;
            return request;
        }

        /// <summary>
        /// Get Request From Configuration With RequestHeader.
        /// </summary>
        /// <param name="me">IRestfulClient param.</param>
        /// <param name="configName">ConfigName param.</param>
        /// <returns>RestfulRequest instance.</returns>
        public static IRestfulRequest GetRequestFromConfigurationWithRequestHeaderForNeweggCentral(this IRestfulClient me, string configName)
        {
            var request = me.GetRequestFromConfigurationWithRegion(configName);
            request.SetUrlParameter("RegionCode", RegionCode);
            request.SetUrlParameter("CurrencyCode", CurrencyCode);
            request.SetHeader("X-NeweggCentral-Source", "Yes");
            request.IsAwaitContext = false;
            return request;
        }

        /// <summary>
        /// Get Request From Configuration With RequestHeader.
        /// </summary>
        /// <param name="me">IRestfulClient param.</param>
        /// <param name="configName">ConfigName param.</param>
        /// <returns>RestfulRequest instance.</returns>
        public static IRestfulRequest GetRequestFromConfigurationWithRequestHeader(this IRestfulClient me, string configName)
        {
            var request = me.GetRequestFromConfigurationWithRegion(configName);
            request.SetUrlParameter("RegionCode", RegionCode);
            request.SetUrlParameter("CurrencyCode", CurrencyCode);
            request.SetHeader("User-Agent", "NeweggFlashWebsite");
            request.SetHeader("X-Source-Ip", ReferenceIP());
            request.IsAwaitContext = false;
            return request;
        }

        /// <summary>
        /// Get Request From Configuration With RequestHeader.
        /// </summary>
        /// <typeparam name="TRequest">TRequest param.</typeparam>
        /// <param name="me">IRestfulClient param.</param>
        /// <param name="configName">ConfigName param.</param>
        /// <returns>RestfulRequest instance.</returns>
        public static IRestfulRequest<TRequest> GetRequestFromConfigurationWithRequestHeader<TRequest>(this IRestfulClient me, string configName)
        {
            var request = me.GetRequestFromConfiguration<TRequest>(configName);
            request.SetUrlParameter("RegionCode", RegionCode);
            request.SetUrlParameter("CurrencyCode", CurrencyCode);
            request.SetHeader("User-Agent", "NeweggFlashWebsite");
            request.SetHeader("X-Source-Ip", ReferenceIP());

            request.IsAwaitContext = false;
            return request;
        }

        /// <summary>
        /// Get client ip with ["X-Source-IP"] and ["REMOTE_ADDR"].
        /// </summary>
        /// <returns>Client ip.</returns>
        private static string ReferenceIP()
        {
            if (!string.IsNullOrEmpty(HttpContext.Current.Request.Headers["X-Source-IP"]))
            {
                return HttpContext.Current.Request.Headers["X-Source-IP"];
            }
            return HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}
