﻿
using System.Text;
using Newegg.Flash.WWW.Common.Configuration;
namespace Newegg.Flash.WWW.Common
{
    public class ProductImageBuilder
    {
        /// <summary>
        /// get image server path
        /// </summary>
        /// <param name="imageType">0: normal, 1: scene7, 2: specialScene7</param>
        /// <returns></returns>
        public static string GetProductImageServerPath(int imageType)
        {
            StringBuilder sb = new StringBuilder();

            switch (imageType)
            {
                case 1:
                case 2:
                    sb.Append(ConfigurationWWWManager<WebSite>.ItemCfg().ProductImageSiteConfig.ImageServerConfig.ServerList[ImageServerAlias.scene7].NormalImageSite.TrimEnd('/')).Append("/");
                    break;
                case 0:
                default:
                    sb.Append(ConfigurationWWWManager<WebSite>.ItemCfg().ProductImageSiteConfig.ImageServerConfig.ServerList[ImageServerAlias.akamai].NormalImageSite.TrimEnd('/')).Append("/");
                    break;
            }

            return sb.ToString();
        }

        /// <summary>
        /// get Scene7 Image size from config
        /// </summary>
        /// <param name="imageSize">ProductImageSize</param>
        /// <returns></returns>
        public static string GetScene7ImageSize(ImageSizeEnum imageSize, string hasWaterMark)
        {
            Scene7ImageSize s7Size = ConfigurationWWWManager<Scene7>.ItemCfg().ImageSize;
            string s7ConfigSize = string.Empty;
            switch (imageSize)
            {
                case ImageSizeEnum.FullSize:
                    s7ConfigSize = s7Size.FullSizeImageSite.Normal;
                    break;
                case ImageSizeEnum.Size640:
                    s7ConfigSize = s7Size.Size600.Normal;
                    break;
                case ImageSizeEnum.Size125:
                    s7ConfigSize = s7Size.Size125.Normal;
                    break;
                case ImageSizeEnum.Size300:
                default:
                    s7ConfigSize = s7Size.Size300.Normal;
                    break;
            }
            return s7ConfigSize;
        }

        /// <summary>
        /// get image site
        /// </summary>
        /// <param name="imageSize">imagesize. </param>
        /// <param name="hasWaterMark">watermark flag. 0: don't have, 1: has water mark. </param>
        /// <returns>folder path. End with '/', like 'productimage/'</returns>
        public static string GetImageSite(ImageSizeEnum imageSize, string hasWaterMark)
        {
            ProductImageSiteConfig config = ConfigurationWWWManager<WebSite>.ItemCfg().ProductImageSiteConfig;
            switch (imageSize)
            {
                case ImageSizeEnum.FullSize:
                    return config.FullSizeImageSite.Normal.TrimEnd('/') + "/";
                case ImageSizeEnum.Size640:
                    return config.Image600Site.Normal.TrimEnd('/') + "/";
                case ImageSizeEnum.Size125:
                    return config.Image125Site.Normal.TrimEnd('/') + "/";
                case ImageSizeEnum.Size300:
                default:
                    return config.Image300Site.Normal.TrimEnd('/') + "/";
            }
        }

        /// <summary>
        /// process the image site by watermrk flag
        /// return normalSite ,if waterMarkSite is empty 
        /// </summary>
        /// <param name="normalSite"></param>
        /// <param name="waterMarkSite"></param>
        /// <param name="hasWaterMark"></param>
        /// <returns></returns>
        private static string GetImageSiteBase(string normalSite, string waterMarkSite, string hasWaterMark)
        {
            if (!string.IsNullOrEmpty(waterMarkSite))
            {
                return hasWaterMark == "0" ? waterMarkSite : normalSite;
            }
            else
            {
                return normalSite;
            }
        }


        /// <summary>
        /// get scene7 default image
        /// </summary>
        /// <param name="imageName"></param>
        /// <returns></returns>
        public static string GetScene7DefaultImage()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(GetProductImageServerPath(1));
            sb.Append(ConfigurationWWWManager<Scene7>.ItemCfg().CommingSoonImage);
            return sb.ToString();
        }


        /// <summary>
        /// get default image
        /// </summary>
        /// <param name="imageSize">imagesize</param>
        /// <returns></returns>
        public static string GetDefaultImage(int imageSize)
        {
            switch (imageSize)
            {
                case 1:
                    return "ComingSoon640.JPG";
                case 0:
                default:
                    return "ComingSoon300.JPG";
            }
        }

    }
}
