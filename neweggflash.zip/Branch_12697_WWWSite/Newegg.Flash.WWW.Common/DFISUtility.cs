﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using System.Linq;
using System.Collections.Generic;
using Newegg.Flash.WWW.Common.Configuration;
using System;

namespace Newegg.Flash.WWW.Common
{
    public class DFISUtility
    {

        private static WebSite webSiteConfig = ConfigurationWWWManager<WebSite>.ItemCfg();

        private static bool DFISconfigEnable
        {
            get
            {
                return webSiteConfig != null && webSiteConfig.ProductImageSiteConfig != null &&
                       webSiteConfig.ProductImageSiteConfig.DFIS != null;
            }
        }

        /// <summary>
        /// Get DFIS image path
        /// </summary>
        /// <param name="imageSize">imageSize</param>
        /// <param name="itemType">ItemType, 0: Campaign, 1: Item. </param>
        /// <returns>return image path</returns>
        public static string GetItemImageUrl(ImageSizeEnum imageSize)
        {
            if (!DFISconfigEnable)
            {
                return string.Empty;
            }

            string DFISFileType = string.Empty;

            switch (imageSize)
            {
                case ImageSizeEnum.Size125:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image125Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size160:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image160Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size240:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image240Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size640:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image600Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size1280:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image1280Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size300:
                default:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image300Site.TrimEnd('/') + "/";
                    break;
            }

            if (string.IsNullOrWhiteSpace(DFISHost) || string.IsNullOrWhiteSpace(DFISFileGroup) ||
                string.IsNullOrWhiteSpace(DFISFileType))
            {
                return string.Empty;
            }
            return string.Format("{0}{1}{2}", DFISHost, DFISFileGroup, DFISFileType);
        }

        /// <summary>
        /// Get DFIS image path
        /// </summary>
        /// <param name="imageSize">imageSize</param>
        /// <param name="itemType">ItemType, 0: Campaign, 1: Item. </param>
        /// <returns>return image path</returns>
        public static string GetCampaignImageUrl(ImageSizeEnum imageSize)
        {
            if (!DFISconfigEnable)
            {
                return string.Empty;
            }
            string DFISFileType = string.Empty;
            switch (imageSize)
            {
                case ImageSizeEnum.Size240:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.CampaignImage.Image240Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size640:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.CampaignImage.Image600Site.TrimEnd('/') + "/";
                    break;
                case ImageSizeEnum.Size300:
                default:
                    DFISFileType = webSiteConfig.ProductImageSiteConfig.DFIS.CampaignImage.Image300Site.TrimEnd('/') + "/";
                    break;
            }
            if (string.IsNullOrWhiteSpace(DFISHost) || string.IsNullOrWhiteSpace(DFISFileGroup) ||
                string.IsNullOrWhiteSpace(DFISFileType))
            {
                return string.Empty;
            }
            return string.Format("{0}{1}{2}", DFISHost, DFISFileGroup, DFISFileType);
        }

        /// <summary>
        /// DFIS host address
        /// </summary>
        public static string DFISHost
        {
            get
            {
                if (DFISconfigEnable)
                {
                    return webSiteConfig.ProductImageSiteConfig.DFIS.DFISHost.TrimEnd('/') + "/";
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// file group of newegg flash image in the DIFS 
        /// </summary>
        public static string DFISFileGroup
        {
            get
            {
                if (DFISconfigEnable)
                {
                    return webSiteConfig.ProductImageSiteConfig.DFIS.DFISFileGroup.TrimEnd('/') + "/";
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Item full size image path in the config
        /// </summary>
        public static string FullSizeImagePath
        {
            get
            {
                if (DFISconfigEnable)
                {
                    return webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image1280Site.TrimEnd('/') + "/";
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Item 600 size image path in the config
        /// </summary>
        public static string BigSizeImagePath
        {
            get
            {
                if (DFISconfigEnable)
                {
                    return webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image600Site.TrimEnd('/') + "/";
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Item 125 size image path in the config
        /// </summary>
        public static string SmallSizeImagePath
        {
            get
            {
                if (DFISconfigEnable)
                {
                    return webSiteConfig.ProductImageSiteConfig.DFIS.ItemImage.Image125Site.TrimEnd('/') + "/";
                }
                return string.Empty;
            }
        }
    }
}
