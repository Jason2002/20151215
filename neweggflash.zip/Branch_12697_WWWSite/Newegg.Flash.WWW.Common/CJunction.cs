﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class CJunction
    {
        [XmlAttribute("enable")]
        public bool Enalbe
        {
            get;
            set;
        }

        [XmlElement("code")]
        public string Code
        {
            get;
            set;
        }

        [XmlElement("paramNames")]
        public ParamNames ParamNameConfig
        {
            get;
            set;
        }

    }

    public class ParamNames
    {
        [XmlElement("name")]
        public List<string> NameList
        {
            get;
            set;
        }
    }

    public class ParamValue
    {
        [XmlElement("value")]
        public List<string> ValueList
        {
            get;
            set;
        }
    }
}
