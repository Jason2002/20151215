﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Common
{
    /// <summary>
    /// Item Number convert
    /// </summary>
    public static class ItemNumberConvert
    {
        private const string NEWEGG_ITEM_NUMBER_COMDE = "N82E168";
        private const string SELLER_ITEM_NUMBER_COMDE = "9SI";
        private const string AUTOPARTS_ITEM_NUMBER = "9AT";

        private const string PARENT_ITEM_REGEX = "[0-8][0-9A-Z]{2}[-][0-9A-Z]{4}[-][0-9A-Z]{4}[0-9]";
        private const string BOOK_ITEM_NUMBER_REGEX = "978[0-9]{10}";

        public static string ItemNumber2NeweggItemNumber(string itemNumber)
        {
            if (string.IsNullOrEmpty(itemNumber))
            {
                return string.Empty;
            }
            #region seller item
            if (itemNumber.ToUpper().StartsWith(SELLER_ITEM_NUMBER_COMDE))
            {
                return itemNumber;
            }
            #endregion
            #region parent item
            if (Regex.IsMatch(itemNumber.ToUpper(), PARENT_ITEM_REGEX))
            {
                return itemNumber;
            }
            #endregion
            #region autoparts item

            if (itemNumber.ToUpper().StartsWith(AUTOPARTS_ITEM_NUMBER))
            {
                return itemNumber;
            }

            #endregion
            #region book item
            if (Regex.IsMatch(itemNumber, BOOK_ITEM_NUMBER_REGEX))
            {
                return itemNumber;
            }
            #endregion
            Int64 number;
            //build DVD item number:N82E168013132136592
            if (Int64.TryParse(itemNumber, out number))
            {
                return NEWEGG_ITEM_NUMBER_COMDE + itemNumber;
            }
            return NEWEGG_ITEM_NUMBER_COMDE + itemNumber.Replace("-", "");
        }

        public static string NeweggItemNumber2ItemNumber(string neweggItemNumber)
        {
            try
            {
                if (string.IsNullOrEmpty(neweggItemNumber) || neweggItemNumber.Length <= 7)
                {
                    return string.Empty;
                }
                neweggItemNumber = neweggItemNumber.ToUpper();
                #region seller item
                if (neweggItemNumber.StartsWith(SELLER_ITEM_NUMBER_COMDE))
                {
                    return neweggItemNumber;
                }
                #endregion
                #region parent item
                if (Regex.IsMatch(neweggItemNumber, PARENT_ITEM_REGEX))
                {
                    return neweggItemNumber;
                }
                #endregion
                #region autoparts itemnumber
                if (neweggItemNumber.ToUpper().StartsWith(AUTOPARTS_ITEM_NUMBER))
                {
                    return neweggItemNumber;
                }
                #endregion

                if (!neweggItemNumber.StartsWith(NEWEGG_ITEM_NUMBER_COMDE))
                {
                    return neweggItemNumber;
                }
                else if (Regex.IsMatch(neweggItemNumber, NEWEGG_ITEM_NUMBER_COMDE + BOOK_ITEM_NUMBER_REGEX))
                {
                    return neweggItemNumber.Substring(7);
                }

                #region DVD logic change: DVD item will be deal with as normal item
                if (neweggItemNumber.EndsWith("DV"))
                {
                    neweggItemNumber = neweggItemNumber.Substring(7);
                    return neweggItemNumber.Substring(0, neweggItemNumber.Length - 2);
                }
                //DVD item number:N82E168013132136592
                if (neweggItemNumber.Length == 19)
                {
                    string neweggDVDItemNumber = neweggItemNumber.Substring(7);
                    Int64 number;
                    if (Int64.TryParse(neweggDVDItemNumber, out number))
                    {
                        return neweggDVDItemNumber;
                    }
                }
                #endregion

                if (neweggItemNumber.EndsWith("R"))
                {
                    if (neweggItemNumber.Length == 16) //normal openbox item#:N82E16812345678R -> 12-345-678R
                    {
                        return neweggItemNumber.Substring(7).Insert(5, "-").Insert(2, "-");
                    }
                    else //new openbox item#: N82E168123456789123R -> 123456789123R
                    {
                        return neweggItemNumber.Substring(7);
                    }
                }
                if (neweggItemNumber.EndsWith("SF") || neweggItemNumber.EndsWith("TS"))
                {
                    return neweggItemNumber.Substring(7);
                }
                if (neweggItemNumber.EndsWith("IN"))
                {
                    return neweggItemNumber.Substring(7).Insert(6, "-").Insert(2, "-");
                }

                //check another normal item
                //like this:N82E16820-145-526
                if (neweggItemNumber.IndexOf("-") > 0 &&
                    neweggItemNumber.LastIndexOf("-") > 0 &&
                    neweggItemNumber.IndexOf("-") != neweggItemNumber.LastIndexOf("-"))
                {
                    return neweggItemNumber.Substring(7);
                }
                else
                {
                    return neweggItemNumber.Substring(7).Insert(5, "-").Insert(2, "-");
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        public static bool IsParentItem(string itemNumber)
        {
            return Regex.IsMatch(itemNumber.ToUpper(), PARENT_ITEM_REGEX);
        }
    }
}
