﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Common
{
    public static class CommonUtility
    {
        public static DateTime DateTimeNow
        {
            get
            {
                var timeZoneInfoPST = TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time");
                var result = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.Local, timeZoneInfoPST);
                return result;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceTime"></param>
        /// <param name="timeZoneID">destination timezoneID, if not a stadard tiem zone id ,use PST</param>
        /// <returns></returns>
        public static DateTime GetTimeByTimeZoneID(DateTime sourceTime, string fromTimeZoneID = "Pacific Standard Time", string toTimeZoneID = "Pacific Standard Time")
        {
            sourceTime = new DateTime(sourceTime.Year, sourceTime.Month, sourceTime.Day, sourceTime.Hour, sourceTime.Minute, sourceTime.Second, sourceTime.Millisecond, DateTimeKind.Unspecified);
            var systemTimeZone = TimeZoneInfo.GetSystemTimeZones().Select(x => x.Id);
            if (string.IsNullOrEmpty(fromTimeZoneID) || !systemTimeZone.Contains(fromTimeZoneID))
            {
                fromTimeZoneID = "Pacific Standard Time";
            }

            if (string.IsNullOrEmpty(toTimeZoneID) || !systemTimeZone.Contains(toTimeZoneID))
            {
                toTimeZoneID = "Pacific Standard Time";
            }
            TimeZoneInfo from = TimeZoneInfo.FindSystemTimeZoneById(fromTimeZoneID);
            TimeZoneInfo to = TimeZoneInfo.FindSystemTimeZoneById(toTimeZoneID);

            var result = TimeZoneInfo.ConvertTime(sourceTime, from, to);
            return result;
        }

    }
}
