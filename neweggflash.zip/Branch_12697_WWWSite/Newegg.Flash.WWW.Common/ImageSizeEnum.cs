﻿
namespace Newegg.Flash.WWW.Common
{
    /// <summary>
    /// Image size
    /// </summary>
    public enum ImageSizeEnum
    {
        Size125, 
        Size160, 
        Size240, 
        Size300,
        Size640,
        Size1280,
        FullSize,
    }
}
