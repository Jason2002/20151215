﻿using System;
using System.Collections.Generic;

namespace Newegg.Flash.WWW.Common
{
    public enum BrowserApplication
    {
        InternetExplorer,
        Firefox,
        Thunderbird,
        Mozilla,
        Opera,
        Netscape,
        Firebird,
        Safari,
        Lynx,
        Konqueror,
        OmniWeb,
        WebTV,
        iCab,
        Chrome,
        Unrecognized
    }

    public enum BrowserEngine
    {
        MSIE,
        Gecko,
        Opera,
        KHTML,
        Lynx,
        iCab,
        Unrecognized
    }

    public sealed class BrowserInfo
    {
        public BrowserInfo()
        {
            this.BrowserApplication = BrowserApplication.Unrecognized;
            this.BrowserEngine = BrowserEngine.Unrecognized;
        }

        public BrowserInfo(string identity, BrowserApplication app, BrowserEngine engin, string version)
        {
            this.rawIdentity = identity;
            this.BrowserApplication = app;
            this.BrowserEngine = engin;
            this.BrowserAppVersion = version;
        }

        #region <-Instance Fields->
        private string rawIdentity;
        #endregion

        #region <-Properties->
        public BrowserApplication BrowserApplication
        {
            get;
            private set;
        }

        public BrowserEngine BrowserEngine
        {
            get;
            private set;
        }

        public string BrowserAppVersion
        {
            get;
            private set;
        }

        public bool IsIpad
        {
            get
            {
                return (rawIdentity.IndexOf("iPad") != -1);
            }
        }

        public bool IsWindowsPhone7
        {
            get
            {
                return (rawIdentity.ToLower().IndexOf("windows phone") != -1);
            }
        }

        public bool IsItouchOrIPhone
        {
            get
            {
                if (rawIdentity.IndexOf("iPhone") == -1)
                {
                    return (rawIdentity.IndexOf("iPod") != -1);
                }
                return true;
            }
        }

        public bool IsAndroid
        {
            get
            {
                var identity = rawIdentity.ToLower();
                return ((identity.IndexOf("android") != -1) && (identity.IndexOf("mobile") != -1));
            }
        }

        public bool IsAndroidTablet
        {
            get
            {
                var identity = rawIdentity.ToLower();
                return ((identity.IndexOf("android") != -1) && (identity.IndexOf("mobile") == -1));
            }
        }

        public bool IsBlackBerry
        {
            get
            {
                return (rawIdentity.ToLower().IndexOf("blackberry") != -1);
            }
        }

        public bool IsGoogleCrawler
        {
            get
            {
                return (rawIdentity.ToLower().IndexOf("googlebot") >= 0);
            }
        }
        #endregion

        #region <-Methodes->
        public static BrowserInfo CreateUnrecognizedBrowserInfo()
        {
            return new BrowserInfo { BrowserApplication = BrowserApplication.Unrecognized, BrowserEngine = BrowserEngine.Unrecognized };
        }
        #endregion
    }

    public static class BrowserInfoParser
    {
        static BrowserInfoParser()
        {
            m_IdentifierList = new List<string>();
            m_ApplicationList = new List<BrowserApplication>();
            m_BrowserEngineList = new List<BrowserEngine>();
            m_IdentifierList.Add("Chrome");
            m_ApplicationList.Add(BrowserApplication.Chrome);
            m_BrowserEngineList.Add(BrowserEngine.KHTML);
            m_IdentifierList.Add("Firefox");
            m_ApplicationList.Add(BrowserApplication.Firefox);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
            m_IdentifierList.Add("Thunderbird");
            m_ApplicationList.Add(BrowserApplication.Thunderbird);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
            m_IdentifierList.Add("Minefield");
            m_ApplicationList.Add(BrowserApplication.Firefox);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
            m_IdentifierList.Add("Opera");
            m_ApplicationList.Add(BrowserApplication.Opera);
            m_BrowserEngineList.Add(BrowserEngine.Opera);
            m_IdentifierList.Add("Netscape");
            m_ApplicationList.Add(BrowserApplication.Netscape);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
            m_IdentifierList.Add("Firebird");
            m_ApplicationList.Add(BrowserApplication.Firebird);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
            m_IdentifierList.Add("iCab");
            m_ApplicationList.Add(BrowserApplication.iCab);
            m_BrowserEngineList.Add(BrowserEngine.iCab);
            m_IdentifierList.Add("Lynx");
            m_ApplicationList.Add(BrowserApplication.Lynx);
            m_BrowserEngineList.Add(BrowserEngine.Lynx);
            m_IdentifierList.Add("Konqueror");
            m_ApplicationList.Add(BrowserApplication.Konqueror);
            m_BrowserEngineList.Add(BrowserEngine.KHTML);
            m_IdentifierList.Add("OmniWeb");
            m_ApplicationList.Add(BrowserApplication.OmniWeb);
            m_BrowserEngineList.Add(BrowserEngine.KHTML);
            m_IdentifierList.Add("Safari");
            m_ApplicationList.Add(BrowserApplication.Safari);
            m_BrowserEngineList.Add(BrowserEngine.KHTML);
            m_IdentifierList.Add("SeaMonkey");
            m_ApplicationList.Add(BrowserApplication.Mozilla);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
            m_IdentifierList.Add("WebTV");
            m_ApplicationList.Add(BrowserApplication.WebTV);
            m_BrowserEngineList.Add(BrowserEngine.MSIE);
            m_IdentifierList.Add("MSIE");
            m_ApplicationList.Add(BrowserApplication.InternetExplorer);
            m_BrowserEngineList.Add(BrowserEngine.MSIE);
            m_IdentifierList.Add("Mozilla");
            m_ApplicationList.Add(BrowserApplication.Mozilla);
            m_BrowserEngineList.Add(BrowserEngine.Gecko);
        }

        #region <-Instance Fields->
        private static List<string> m_IdentifierList;
        private static List<BrowserEngine> m_BrowserEngineList;
        private static List<BrowserApplication> m_ApplicationList;
        #endregion

        #region <-Methodes->
        private static int DoParseBrowserApplication(string rawIdentity, string browserID)
        {
            return rawIdentity.IndexOf(browserID, StringComparison.InvariantCultureIgnoreCase);
        }

        private static string ParseAppVersion(string rawIdentity, int startPos)
        {
            while (startPos < rawIdentity.Length)
            {
                if ((rawIdentity[startPos] != ' ') && (rawIdentity[startPos] != '/'))
                {
                    break;
                }
                startPos++;
            }
            if (startPos == (rawIdentity.Length - 1))
            {
                return string.Empty;
            }
            int endPos = startPos;
            while (endPos < rawIdentity.Length)
            {
                if ((((rawIdentity[endPos] == ' ') || (rawIdentity[endPos] == ')')) || ((rawIdentity[endPos] == '(') || (rawIdentity[endPos] == ';'))) || (rawIdentity[endPos] == ','))
                {
                    break;
                }
                endPos++;
            }
            if (endPos == startPos)
            {
                return string.Empty;
            }
            return rawIdentity.Substring(startPos, endPos - startPos);
        }

        public static BrowserInfo Parse(string rawIdentity)
        {
            BrowserApplication browserApplication = BrowserApplication.Unrecognized;
            BrowserEngine browserEngine = BrowserEngine.Unrecognized;
            string appVersion = string.Empty;
            if (rawIdentity == null)
            {
                return BrowserInfo.CreateUnrecognizedBrowserInfo();
            }
            string key = "";
            int startPos = -1;
            for (int i = 0; i < m_IdentifierList.Count; i++)
            {
                key = m_IdentifierList[i];
                startPos = DoParseBrowserApplication(rawIdentity, key);
                if (startPos != -1)
                {
                    browserApplication = m_ApplicationList[i];
                    browserEngine = m_BrowserEngineList[i];
                    break;
                }
            }
            if (startPos != -1)
            {
                appVersion = ParseAppVersion(rawIdentity, (startPos + key.Length) + 1);
            }
            return new BrowserInfo(rawIdentity, browserApplication, browserEngine, appVersion);
        }
        #endregion
    }
}
