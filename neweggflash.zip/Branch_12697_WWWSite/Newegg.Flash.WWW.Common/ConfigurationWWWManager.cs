﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using Newegg.EC;
using Newegg.EC.Configuration;

namespace Newegg.Flash.WWW.Common
{
    /// <summary>
    /// Provides configuration info for WWW website
    /// </summary>
    /// <typeparam name="T">Configuration type</typeparam>
    public class ConfigurationWWWManager<T> where T :class
    {
        /// <summary>
        /// Gets configuration info
        /// </summary>
        /// <returns></returns>
        public static T ItemCfg()
        {
            //this key must be same with the key in "Configurations/ConfigPath.config" file
            string key = typeof (T).Name;
            return ECLibraryContainer.Current.GetInstance<IConfigurationManager>().GetConfigurationByKey<T>(key);
        }
    }
}
