﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Common
{
    /// <summary>
    /// The type that is crossing domain request.
    /// </summary>
    public enum CrossDomainActionEnum
    {
        ShareToFriend = 0,
        InviteToFriend = 1,
        ShareSweepstakes = 2,
        LogShare = 3,
        SubmitSweepstakes = 4,
        Logout = 5,
        EBlast = 6,
        ContactUs = 99,     //for kb.newwegg.com
    }
}
