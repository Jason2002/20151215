﻿namespace Newegg.Flash.WWW.Common
{
    /// <summary>
    /// Page Aliase.
    /// </summary>
    public static class PageAliase
    {
        public static bool SwitchToNeweggConfig
        {
            get
            {
                return ConfigurationWWWManager<Newegg.Flash.WWW.Common.Configuration.BizUI>.ItemCfg().SwithToNewegg;
            }
        }

        public static readonly string Electronics = "Electronics";
        public static readonly string ForHome = "ForHome";
        public static readonly string ForYou = "ForYou";
        public static readonly string AllStore = "AllStore";
        public static readonly string EndingSoon = "EndingSoon";
        public static readonly string Featured = "Featured";
        public static readonly string SpecialStore = "SpecialStore";
        /// <summary>
        /// Homepage
        /// </summary>
        public static readonly string Homepage = "Homepage";
        public static readonly string AllSales = "AllSales";
        /// <summary>
        /// Upcoming
        /// </summary>
        public static readonly string Upcoming = "Upcoming";

        /// <summary>
        /// TodayDeals
        /// </summary>
        public static readonly string TodayDeals = "TodayDeals";

        /// <summary>
        /// Campaign
        /// </summary>
        public static readonly string Campaign = "Campaign";

        /// <summary>
        /// Product
        /// </summary>
        public static readonly string Product = "Product";

        /// <summary>
        /// ReturnPolicy
        /// </summary>
        public static readonly string ReturnPolicy = "ReturnPolicy";

        /// <summary>
        /// ContactUs action.
        /// </summary>
        public static readonly string ContactUs = "ContactUs";

        /// <summary>
        /// About Us action.
        /// </summary>
        public static readonly string AboutUs = "AboutUs";

        /// <summary>
        /// FAQ action.
        /// </summary>
        public static readonly string FAQ = "FAQ";

        /// <summary>
        /// Policy Agreement.
        /// </summary>
        public static readonly string PolicyAgreement = "PolicyAgreement";

        /// <summary>
        /// Affiliates action.
        /// </summary>
        public static readonly string Affiliates = "Affiliates";

        /// <summary>
        /// Office hours and locations.
        /// </summary>
        public static readonly string OfficeHoursAndLocations = "OfficeHoursAndLocations";

        /// <summary>
        /// California transparency.
        /// </summary>
        public static readonly string CaliforniaTransparency = "CaliforniaTransparency";

        /// <summary>
        /// Privacy policy.
        /// </summary>
        public static readonly string PrivacyPolicy = "PrivacyPolicy";

        /// <summary>
        /// ReturnPolicy
        /// </summary>
        public static readonly string HelpReturnPolicy = "HelpReturnPolicy";

        /// <summary>
        /// Sell to us.
        /// </summary>
        public static readonly string SellToUs = "SellToUs";

        /// <summary>
        /// Mobile App
        /// </summary>
        public static readonly string MobileApp = "MobileApp";

        /// <summary>
        /// Message.
        /// </summary>
        public static readonly string ComingSoon = "ComingSoon";

        /// <summary>
        /// FeaturedStore.
        /// </summary>
        public static readonly string FeaturedStore = "FeaturedStore";

        public static readonly string AllCampaigns = "AllCampaigns";

        public static readonly string PolicyNPA = "PolicyNPA";

        public static readonly string PolicyBML = "PolicyBML";

        public static readonly string PolicyNSCC = "PolicyNSCC";

        /// <summary>
        /// Search.
        /// </summary>
        public static readonly string Search = "Search";

        /// <summary>
        /// Outsite class.
        /// </summary>
        public static class OutSite
        {
            /// <summary>
            /// Account Setting
            /// </summary>
            public static readonly string AccountSetting = "AccountSetting";

            /// <summary>
            /// Login Assistance
            /// </summary>
            public static readonly string LoginAssistance = "LoginAssistance";

            /// <summary>
            /// Your account.
            /// </summary>
            public static readonly string YourAccount = "YourAccount";

            /// <summary>
            /// Your payment.
            /// </summary>
            public static readonly string YourPayment = "YourPayment";

            /// <summary>
            /// Your address.
            /// </summary>
            public static readonly string YourAddress = "YourAddress";

            /// <summary>
            /// Shopping Cart.
            /// </summary>
            public static string ShoppingCart
            {
                get
                {
                    if (SwitchToNeweggConfig)
                    {
                        return "NeweggShoppingCart";
                    }
                    else
                    {
                        return "ShoppingCart";
                    }
                }
            }

            /// <summary>
            /// Add to NeweggFlash ShoppingCart (obsolete after project11377, 11337 still work).
            /// </summary>
            public static readonly string AddToShoppingCart = "AddToShoppingCart";

            /// <summary>
            /// Add to Newegg ShoppingCart.
            /// </summary>
            public static readonly string AddToNeweggShoppingCart = "AddToNeweggShoppingCart";

            /// <summary>
            /// Account subscriptions.
            /// </summary>
            public static readonly string AccountSubscriptions = "AccountSubscriptions";

            /// <summary>
            /// Login.
            /// </summary>
            public static readonly string Login = "Login";

            /// <summary>
            /// Newegg reseller certificate.
            /// </summary>
            public static readonly string NeweggResellerCertificate = "NeweggResellerCertificate";

            /// <summary>
            /// WWW newegg com.
            /// </summary>
            public static readonly string WWWNeweggCom = "WWWNeweggCom";

            /// <summary>
            /// WWW nutrend com.
            /// </summary>
            public static readonly string WWWNutrendCom = "WWWNutrendCom";

            /// <summary>
            /// SSL newegg com.
            /// </summary>
            public static readonly string SSLNeweggCom = "SSLNeweggCom";

            /// <summary>
            /// Newegg.com SSL Site login page.
            /// </summary>
            public static readonly string NeweggLogin = "NeweggLogin";

            /// <summary>
            /// Newegg.com SSL Site cross domain common request url.
            /// </summary>
            public static readonly string NeweggCommonShare = "NeweggCommonShare";

            /// <summary>
            /// NNewegg.com SSL Site YourAccount page.
            /// </summary>
            public static readonly string NeweggYourAccount = "NeweggYourAccount";

            /// <summary>
            /// Newegg rma.
            /// </summary>
            public static readonly string NeweggRMA = "NeweggRMA";
            public static readonly string CustomerRegister = "CustomerRegister";
            public static readonly string CustomerLogin = "CustomerLogin";
            public static readonly string Forgot = "Forgot";
            public static readonly string SaveSubscription = "SaveSubscription";
            public static readonly string ShareToFriend = "ShareToFriend";
            public static readonly string InviteFriend = "InviteFriend";
            public static readonly string ShareSweepstakes = "ShareSweepstakes";
            public static readonly string LogShareInfo = "LogShareInfo";

            /// <summary>
            /// iron egg icon link
            /// </summary>
            public static readonly string IronEggLink = "IronEggLink";
        }
    }
}
