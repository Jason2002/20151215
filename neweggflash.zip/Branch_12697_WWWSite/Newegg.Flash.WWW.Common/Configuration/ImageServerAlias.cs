﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

namespace Newegg.Flash.WWW.Common.Configuration
{
    public enum ImageServerAlias
    {
        akamai = 0,
        scene7 = 1,
    }
}
