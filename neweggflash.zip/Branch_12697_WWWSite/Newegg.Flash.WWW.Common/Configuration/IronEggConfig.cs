﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class IronEggConfig
    {
        [XmlAttribute("roles")]
        public String Roles { get; set; }

        [XmlAttribute("Enable")]
        public bool Enable { get; set; }

        [XmlElement("StartDateTime")]
        public string StartDateTime { get; set; }

        [XmlElement("EndDateTime")]
        public string EndDateTime { get; set; }

        [XmlElement("ProductPagePromotionLink")]
        public string ProductPagePromotionLink { get; set; }
    }
}
