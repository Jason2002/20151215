﻿using Newegg.Flash.WWW.Common.Configuration.SiteCatalyst;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// Third party config class
    /// </summary>
    [XmlRoot("thirdParty", Namespace = "http://www.newegg.com/Website")]
    public class ThirdParty
    {

        /// <summary>
        /// Gets or sets GoogleAnalyticsCode
        /// </summary>
        [XmlElement("GoogleAnalyticsCode")]
        public GoogleAnalyticsCode GoogleAnalyticsCode { get; set; }

        /// <summary>
        /// Gets a value indicating whether GoogleAnalyticsCode switch on or off.
        /// </summary>
        public bool GoogleAnalyticsCodeEnable
        {
            get { return this.GoogleAnalyticsCode != null && this.GoogleAnalyticsCode.Enable; }
        }

        /// <summary>
        /// Gets or sets Nassau value
        /// </summary>
        [XmlElement("Nassau")]
        public Nassau Nassau { get; set; }

        /// <summary>
        /// Gets a value indicating whether Nassau switch on or off.
        /// </summary>
        public bool NassauEnable
        {
            get { return this.Nassau != null && this.Nassau.Enable; }
        }

        /// <summary>
        /// Gets or sets NassauTracking value
        /// </summary>
        [XmlElement("NassauTracking")]
        public NassauTracking NassauTracking { get; set; }

        /// <summary>
        /// Gets a value indicating whether NassauTracking switch on or off.
        /// </summary>
        public bool NassauTrackingEnable
        {
            get { return this.NassauTracking != null && this.NassauTracking.Enable; }
        }

        /// <summary>
        /// Gets or sets the Tealium config value.
        /// </summary>
        [XmlElement("TealiumIQ")]
        public TealiumIQ TealiumIQ { get; set; }

        /// <summary>
        /// Gets a value indicating whether Tealium tracking swtiching on or off.
        /// </summary>
        public bool TealiumIQEnable
        {
            get { return this.TealiumIQ != null && this.TealiumIQ.Enable; }
        }

        [XmlElement("NVTC")]
        public NVTC NeweggVisitorTrackingCookie { get; set; }

        public bool NeweggVisitorTrackingCookieEnable
        {
            get { return this.NeweggVisitorTrackingCookie != null && this.NeweggVisitorTrackingCookie.Enable; }
        }

        /// <summary>
        /// Gets or sets the SiteCatalyst.
        /// </summary>
        [XmlElement("SiteCatalyst")]
        public SiteCatalystConfiguration SiteCatalyst { get; set; }


        [XmlElement("CJunction")]
        public CJunction CJunction { get; set; }
    }
}
