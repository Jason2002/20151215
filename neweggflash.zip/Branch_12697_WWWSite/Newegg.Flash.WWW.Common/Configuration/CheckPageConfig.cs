﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    [XmlRoot("CheckPage")]
    public class CheckPage
    {
        [XmlElement("ServerList")]
        public CheckPageServer ServerInfo { get; set; }

        [XmlElement("CommonPages")]
        public CommonPages PageInfo { get; set; }

        [XmlElement("IPList")]
        public IPList IPList { get; set; }
    }

    public class IPList
    {
        [XmlElement("E3IP")]
        public string E3IP { get; set; }

        [XmlElement("E4IP")]
        public string E4IP { get; set; }
    }

    public class IP
    {
        [XmlAttribute("name")]
        public string IPName { get; set; }

        [XmlText]
        public string IPAddress { get; set; }
    }

    public class CommonPages
    {
        [XmlElement("Page")]
        public List<PageInfo> PageInfos { get; set; }
    }

    public class CheckPageServer
    {
        [XmlElement("E3")]
        public E3 E3 { get; set; }

        [XmlElement("E4")]
        public E4 E4 { get; set; }
    }

    public class E3
    {
        [XmlElement("Server")]
        public List<ServerInfo> ServerInfos { get; set; }
    }

    public class E4
    {
        [XmlElement("Server")]
        public List<ServerInfo> ServerInfos { get; set; }
    }

    public class ServerInfo
    {
        [XmlAttribute("name")]
        public string ServerName { get; set; }

        [XmlAttribute("host")]
        public string ServerHost { get; set; }

        [XmlAttribute("isRelativeDomain")]
        public bool IsRelativeDomain { get; set; }
    }

    public class PageInfo
    {
        [XmlAttribute("name")]
        public string PageName { get; set; }

        [XmlAttribute("url")]
        public string PageUrl { get; set; }
    }
}
