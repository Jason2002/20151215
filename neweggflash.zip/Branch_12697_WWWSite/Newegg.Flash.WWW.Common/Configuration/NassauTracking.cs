﻿using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// NassauTracking config. Belong to Third party. 
    /// </summary>
    public class NassauTracking
    {
        /// <summary>
        /// Gets or sets a value indicating whether switch on or off.
        /// </summary>
        [XmlElement("enable")]
        public bool Enable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating NassauTracking content
        /// </summary>
        [XmlElement("trackingCode")]
        public string TrackingCode { get; set; }
    }
}
