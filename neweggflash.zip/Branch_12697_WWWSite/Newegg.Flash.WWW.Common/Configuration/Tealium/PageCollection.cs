﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Page config collection.
    /// </summary>
    public class PageCollection
    {
        /// <summary>
        /// Gets or sets page value.
        /// </summary>
        [XmlElement("page")]
        public List<Page> Pages { get; set; }
    }
}
