﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Page config section.
    /// </summary>
    public class Page
    {
        /// <summary>
        /// Indicating whether the page config is enabled.
        /// </summary>
        private bool enable = true;

        /// <summary>
        /// Gets or sets a value indicating whether the page config is enabled.
        /// </summary>
        [XmlAttribute("enable")]
        public bool Enable
        {
            get
            {
                return this.enable;
            }

            set
            {
                this.enable = value;
            }
        }

        /// <summary>
        /// Gets or sets action value.
        /// </summary>
        [XmlAttribute("action")]
        public string Action { get; set; }

        /// <summary>
        /// Gets or sets name value.
        /// </summary>
        [XmlAttribute("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets type value.
        /// </summary>
        [XmlAttribute("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets breadcrumb value.
        /// </summary>
        [XmlAttribute("breadcrumb")]
        public string Breadcrumb { get; set; }

        /// <summary>
        /// Gets or sets udoProperty value.
        /// </summary>
        [XmlElement("udoProperty")]
        public List<UdoProperty> PrivateUdoProperties { get; set; }
    }
}
