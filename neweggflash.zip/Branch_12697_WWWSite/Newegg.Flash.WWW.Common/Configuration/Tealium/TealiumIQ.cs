﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Tealium config.
    /// </summary>
    public partial class TealiumIQ
    {
        /// <summary>
        /// Indicate whether the tealium is enabled.
        /// </summary>
        private bool enable = true;

        /// <summary>
        /// Gets or sets a value indicating whether enable tealium.
        /// </summary>
        [XmlElement("enable")]
        public bool Enable
        {
            get
            {
                return this.enable;
            }

            set
            {
                this.enable = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether enable debug.
        /// </summary>
        [XmlElement("enableDebug")]
        public bool EnableDebug { get; set; }

        /// <summary>
        /// Gets or sets account value.
        /// </summary>
        [XmlElement("account")]
        public string Account { get; set; }

        /// <summary>
        /// Gets or sets profile value.
        /// </summary>
        [XmlElement("profile")]
        public string Profile { get; set; }

        /// <summary>
        /// Gets or sets code value.
        /// </summary>
        [XmlElement("code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets globalUdoProperty value.
        /// </summary>
        [XmlElement("globalUdoProperty")]
        public GlobalUdoPropertyCollection GlobalUdoPropertyCollection { get; set; }

        /// <summary>
        /// Gets or sets pageGroup value.
        /// </summary>
        [XmlElement("pageGroup")]
        public List<PageGroup> PageGroupCollection { get; set; }

        /// <summary>
        /// Gets or sets singlePage value.
        /// </summary>
        [XmlElement("singlePage")]
        public List<Page> SinglePageCollection { get; set; }
    }
}
