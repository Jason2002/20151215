﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Global udo property collection.
    /// </summary>
    public class GlobalUdoPropertyCollection
    {
        /// <summary>
        /// Gets or sets a value indicating whether enable all the items.
        /// </summary>
        [XmlAttribute("enableAll")]
        public bool EnableAll { get; set; }

        /// <summary>
        /// Gets or sets udoProperty value.
        /// </summary>
        [XmlElement("udoProperty")]
        public List<UdoProperty> GlobalUdoProperties { get; set; }
    }
}
