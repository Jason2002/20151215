﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Tealium config.
    /// </summary>
    public partial class TealiumIQ
    {
        /// <summary>
        /// Private udo property lists.
        /// </summary>
        private Dictionary<string, TealiumConfigItem> privateUdoProperties;

        /// <summary>
        /// Empty udo property lists.
        /// </summary>
        private List<UdoProperty> emptyPropertList = new List<UdoProperty>();

        /// <summary>
        /// The locker projects.
        /// </summary>
        private object locker = new object();

        /// <summary>
        /// Gets the global properties.
        /// </summary>
        public List<UdoProperty> GlobalUdoProperties
        {
            get
            {
                if (this.GlobalUdoPropertyCollection == null 
                    || this.GlobalUdoPropertyCollection.EnableAll == false
                    || this.GlobalUdoPropertyCollection.GlobalUdoProperties == null)
                {
                    return this.emptyPropertList;
                }

                return this.GlobalUdoPropertyCollection.GlobalUdoProperties;
            }
        }

        /// <summary>
        /// Gets the properties by page.
        /// </summary>
        /// <param name="key">Acion name.</param>
        /// <returns>Tealium config item for request page.</returns>
        public TealiumConfigItem this[string key]
        {
            get
            {
                this.SetPrivateUdoInit();

                TealiumConfigItem config;
                this.privateUdoProperties.TryGetValue(key.ToLower(), out config);

                return config;
            }
        }

        /// <summary>
        /// Check whether the request is configed to add tealium function.
        /// </summary>
        /// <param name="key">Action param.</param>
        /// <returns>If configed, return true, otherwise false.</returns>
        public bool IsConfigForAction(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                return false;
            }

            this.SetPrivateUdoInit();

            if (this.privateUdoProperties.ContainsKey(key.ToLower()))
            {
                var pageConfig = this.privateUdoProperties[key.ToLower()];
                ////<page>节点enable属性如果设置为false，则该页面配置将不会生效，默认不配置为true
                if (pageConfig.Page != null && pageConfig.Page.Enable == true)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Init properties for pages.
        /// </summary>
        private void SetPrivateUdoInit()
        {
            if (this.privateUdoProperties == null)
            {
                lock (this.locker)
                {
                    if (this.privateUdoProperties == null)
                    {
                        var tempUdoProperties = new Dictionary<string, TealiumConfigItem>();

                        this.InitSinglePageConfig(tempUdoProperties);
                        this.InitPageGroupConfig(tempUdoProperties);

                        this.privateUdoProperties = tempUdoProperties;
                    }
                }
            }
        }

        /// <summary>
        /// Init 'PageGroup' config. this function must been called after InitSinglePageConfig.
        /// If 'PageGroup' and 'SinglePage' has the same path, PageGroup config will not work. 
        /// </summary>
        /// <param name="properties">Single page inited list.</param>
        /// <returns>Full init list.</returns>
        private Dictionary<string, TealiumConfigItem> InitPageGroupConfig(Dictionary<string, TealiumConfigItem> properties)
        {
            if (properties == null)
            {
                properties = new Dictionary<string, TealiumConfigItem>();
            }

            foreach (var pageGroup in this.PageGroupCollection)
            {
                if (pageGroup == null || pageGroup.PageCollection == null
                    || pageGroup.PageCollection.Pages == null
                    || pageGroup.PageCollection.Pages.Count == 0)
                {
                    continue;
                }

                var privateList = this.emptyPropertList;
                if (pageGroup.PrivateUdoPropertyCollection != null
                    && pageGroup.PrivateUdoPropertyCollection.PrivateUdoProperties != null)
                {
                    privateList = pageGroup.PrivateUdoPropertyCollection.PrivateUdoProperties;
                }

                foreach (var page in pageGroup.PageCollection.Pages)
                {
                    if (string.IsNullOrWhiteSpace(page.Action))
                    {
                        continue;
                    }

                    string action = page.Action.ToLower();

                    if (properties.ContainsKey(action))
                    {
                        continue;
                    }

                    properties.Add(
                        action,
                        new TealiumConfigItem
                        {
                            Page = page,
                            PropertyList = privateList
                        });
                }
            }

            return properties;
        }

        /// <summary>
        /// Init the SinglePage config.
        /// </summary>
        /// <param name="properties">The config container.</param>
        /// <returns>Prepared config container.</returns>
        private Dictionary<string, TealiumConfigItem> InitSinglePageConfig(Dictionary<string, TealiumConfigItem> properties)
        {
            if (properties == null)
            {
                properties = new Dictionary<string, TealiumConfigItem>();
            }

            this.SinglePageCollection.ForEach(item =>
            {
                var privateList = item.PrivateUdoProperties ?? emptyPropertList;

                properties.Add(item.Action.ToLower(), new TealiumConfigItem { Page = item, PropertyList = privateList });
            });

            return properties;
        }

        /// <summary>
        /// Tealium config item.
        /// </summary>
        public class TealiumConfigItem
        {
            /// <summary>
            /// Gets or sets udo property list for special page.
            /// </summary>
            public List<UdoProperty> PropertyList { get; set; }

            /// <summary>
            /// Gets or sets the configured page info.
            /// </summary>
            public Page Page { get; set; }
        }
    }
}