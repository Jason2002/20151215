﻿using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Udo property.
    /// </summary>
    public class UdoProperty
    {
        /// <summary>
        /// Indicating whether the property is enabled.
        /// </summary>
        private bool enable = true;

        /// <summary>
        /// Indicating whether the property value can be overrided.
        /// </summary>
        private bool canOverride = true;

        /// <summary>
        /// Gets or sets a value indicating whether the property is enabled.
        /// </summary>
        [XmlAttribute("enable")]
        public bool Enable
        {
            get
            {
                return this.enable;
            }

            set
            {
                this.enable = value;
            }
        }

        /// <summary>
        /// Gets or sets name value.
        /// </summary>
        [XmlAttribute("name")]
        public TealiumPropertyName Name { get; set; }

        /// <summary>
        /// Gets or sets udo config value.
        /// </summary>
        [XmlAttribute("value")]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the value can be overrided.
        /// </summary>
        [XmlAttribute("override")]
        public bool Override
        {
            get
            {
                return this.canOverride;
            }

            set
            {
                this.canOverride = value;
            }
        }
    }
}
