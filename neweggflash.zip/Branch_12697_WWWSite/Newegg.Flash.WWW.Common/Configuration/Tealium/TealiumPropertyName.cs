﻿namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Tealium UDO propertiy names.
    /// </summary>
    public enum TealiumPropertyName
    {
        /// <summary>
        /// Site region.
        /// </summary>
        site_region,

        /// <summary>
        /// Site currency.
        /// </summary>
        site_currency,

        /// <summary>
        /// Page name.
        /// </summary>
        page_name,

        /// <summary>
        /// Page type.
        /// </summary>
        page_type,
        
        /// <summary>
        /// Page breadcrumb.
        /// </summary>
        page_breadcrumb,

        /// <summary>
        /// Search keyword.
        /// </summary>
        search_keyword,

        /// <summary>
        /// Search scope.
        /// </summary>
        search_scope,

        /// <summary>
        /// Search scope.
        /// </summary>
        search_results,

        /// <summary>
        /// Page campaign name.
        /// </summary>
        page_campaign_name,

        /// <summary>
        /// Page campaign id.
        /// </summary>
        page_campaign_id,

        /// <summary>
        /// Page number.
        /// </summary>
        page_number,

        /// <summary>
        /// Page sort.
        /// </summary>
        page_sort,

        /// <summary>
        /// Page size.
        /// </summary>
        page_size,

        /// <summary>
        /// Product id.
        /// </summary>
        product_id,

        /// <summary>
        /// Product title.
        /// </summary>
        product_title,

        /// <summary>
        /// Product manufacture.
        /// </summary>
        product_manufacture,

        /// <summary>
        /// Product unit price.
        /// </summary>
        product_unit_price,

        /// <summary>
        /// Product sale price.
        /// </summary>
        product_sale_price,

        /// <summary>
        /// Product promo text.
        /// </summary>
        product_promo_text,

        /// <summary>
        /// Product type.
        /// </summary>
        product_type,

        /// <summary>
        /// Product model.
        /// </summary>
        product_model,

        /// <summary>
        /// Product subcategory.
        /// </summary>
        product_subcategory,

        /// <summary>
        /// Product subcategory desc.
        /// </summary>
        product_subcategory_desc,

        /// <summary>
        /// Product extend price.
        /// </summary>
        product_extend_price,

        /// <summary>
        /// Product quantity.
        /// </summary>
        product_quantity,

        /// <summary>
        /// Product discount.
        /// </summary>
        product_discount,

        /// <summary>
        /// Order id.
        /// </summary>
        order_id,

        /// <summary>
        /// Order discount.
        /// </summary>
        order_discount,

        /// <summary>
        /// Order subtotal.
        /// </summary>
        order_subtotal,

        /// <summary>
        /// Order shipping.
        /// </summary>
        order_shipping,

        /// <summary>
        /// Order tax.
        /// </summary>
        order_tax,

        /// <summary>
        /// Order payment type.
        /// </summary>
        order_payment_type,

        /// <summary>
        /// Order total.
        /// </summary>
        order_total,

        /// <summary>
        /// Cart promo code.
        /// </summary>
        cart_promo_code,

        /// <summary>
        /// Cart grand total.
        /// </summary>
        cart_grand_total,

        /// <summary>
        /// Customer id.
        /// </summary>
        customer_id,

        /// <summary>
        /// Customer email.
        /// </summary>
        customer_email,

        /// <summary>
        /// Order option.
        /// </summary>
        order_option,

        /// <summary>
        /// Order keyword.
        /// </summary>
        order_keyword,
        
        /// <summary>
        /// Detail RMA status.
        /// </summary>
        detail_rma_status,
        
        /// <summary>
        /// Detail is tracking show.
        /// </summary>
        detail_is_tracking,
        
        /// <summary>
        /// Cancel reason.
        /// </summary>
        cancel_reason,
        
        /// <summary>
        /// Cancel code.
        /// </summary>
        cancel_code
    }
}