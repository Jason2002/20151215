﻿using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Page group config.
    /// </summary>
    public class PageGroup
    {
        /// <summary>
        /// Gets or sets pages value.
        /// </summary>
        [XmlElement("pages")]
        public PageCollection PageCollection { get; set; }

        /// <summary>
        /// Gets or sets privateUdoProperty value.
        /// </summary>
        [XmlElement("privateUdoProperty")]
        public PrivateUdoPropertyCollection PrivateUdoPropertyCollection { get; set; }
    }
}
