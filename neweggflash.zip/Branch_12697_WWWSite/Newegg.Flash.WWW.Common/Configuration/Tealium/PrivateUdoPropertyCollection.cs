﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.Tealium
{
    /// <summary>
    /// Private udo property collection.
    /// </summary>
    public class PrivateUdoPropertyCollection
    {
        /// <summary>
        /// Gets or sets udoProperty value.
        /// </summary>
        [XmlElement("udoProperty")]
        public List<UdoProperty> PrivateUdoProperties { get; set; }
    }
}
