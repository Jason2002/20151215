﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
     [XmlRoot("cookieList")]
    public class NeweggComCookies
    {
        private List<NeweggComCookie> neweggComCookieList;


        [XmlElement("cookie")]
        public List<NeweggComCookie> NeweggComCookieConfig
        {
            get { return neweggComCookieList; }
            set
            {
                neweggComCookieList = value;

                this.neweggComCookieList.Clear();
            }
        }

        [XmlElement("enableReformattedCookie")]
        public bool EnableReformattedCookie
        {
            get;
            set;
        }

        [XmlElement("writeReformattedCookie")]
        public bool WriteReformattedCookie
        {
            get;
            set;
        }

        [XmlElement("enableCookieNameMapping")]
        public bool EnableCookieNameMapping
        {
            get;
            set;
        }
    }
}
