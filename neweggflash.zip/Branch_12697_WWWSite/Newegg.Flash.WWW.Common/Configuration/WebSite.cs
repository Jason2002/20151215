﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using System.Xml.Serialization;
namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// Represents web site configuration. This class is for deserializtion's purpose only. Do not use directly.<br />
    /// Note: all the urls here do not contain a trailing '/' or '\'
    /// </summary>
    [XmlRoot("WebSite", Namespace = "http://www.newegg.com/Website")]
    public class WebSite
    {
        [XmlElement("productImageSiteConfig")]
        public ProductImageSiteConfig ProductImageSiteConfig { get; set; }
    }
}
