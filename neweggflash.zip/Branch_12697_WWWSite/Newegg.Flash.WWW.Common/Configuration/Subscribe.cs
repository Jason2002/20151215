﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class Subscribe
    {
        [XmlAttribute("enable")]
        public bool Enable { get; set; }

        [XmlAttribute("roles")]
        public string Roles { get; set; }

        [XmlElement("eBlastLink")]
        public string EBlastLink { get; set; }

        [XmlElement("displayLaw")]
        public bool DisplayLaw { get; set; }

    }
}
