﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class ProductImageType
    {
        #region fileds
        private string m_Normal;
        private string m_WaterMark;
        #endregion

        #region properties
        [XmlElement("normal")]
        public string Normal
        {
            get { return m_Normal; }
            set { m_Normal = value.Trim('\\', '/'); }
        }

        [XmlElement("waterMark")]
        public string WaterMark
        {
            get { return m_WaterMark; }
            set { m_WaterMark = value.Trim('\\', '/'); }
        }
        #endregion
    }
}
