﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Newegg.EC;

namespace Newegg.Flash.WWW.Common.Configuration
{
    [XmlRoot("BizUI", Namespace = "http://www.newegg.com/Website")]
    public class BizUI
    {
        protected Lazy<ICfgRoleFilter> cfgRooleFilter = new Lazy<ICfgRoleFilter>(() => ECLibraryContainer.Current.GetInstance<ICfgRoleFilter>());

        [XmlElement("almostGoneQty")]
        public int AlmostGoneQty { get; set; }

        [XmlElement("AFFILIATE")]
        public string AFFILIATE { get; set; }

        /// <summary>
        /// Gets or sets Upcoming Events configuration.
        /// </summary>
        [XmlElement]
        public UpcomingEvents UpcomingEvents { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether enable foece login Element.
		/// </summary>
		[XmlElement("enableForceLogin")]
		public bool EnableForceLogin { get; set; }

        /// <summary>
        /// Gets or sets Deals begin Clock.
        /// </summary>
        public int BeginClock { get; set; }

        /// <summary>
        /// Gets or sets ComingSoon config.
        /// </summary>
        public ComingSoon ComingSoon { get; set; }

        [XmlElement("maxSearchHistoryCount")]
        public int MaxSearchHistoryCount { get; set; }

        /// <summary>
        /// 请不要调用
        /// </summary>
        [XmlArray("sweepstakesConfig.regionRules"), XmlArrayItem("sweepstakesConfig")]
        public List<SweepstakesConfig> SweepstakesConfigs { get; set; }

        public SweepstakesConfig SweepstakesConfig {
            get { return cfgRooleFilter.Value.FilterSingle(SweepstakesConfigs, t => t.Roles, true); }
        }

        [XmlElement("socialShareConfig")]
        public SocialShareConfig SocialShareConfig { get; set; }

        [XmlArray("externalPageLinks.regionRules"), XmlArrayItem("externalPageLinks")]
        public List<ExternalPageLinksConfig> ExternalPageLinksConfigs { get; set; }

        public ExternalPageLinksConfig ExternalPageLinksConfig
        {
            get
            {
                return cfgRooleFilter.Value.FilterSingle(ExternalPageLinksConfigs, t => t.Roles, true);
            }
        }

        //[XmlElement("headlineConfig")]
        //public HeadlineConfig HeadlineConfig { get; set; }

        
        public IronEggConfig IronEggConfig {
            get
            {
                return cfgRooleFilter.Value.FilterSingle(InnerIronEggList, t => t.Roles, true);
            }
        }

        /// <summary>
        /// 请不要手工调用
        /// </summary>
        [XmlArray("IronEgg.regionRules"), XmlArrayItem("IronEgg")]
        public List<IronEggConfig> InnerIronEggList { get; set; }

        public MakeGiftConfig MakeGiftConfig {
            get
            {
               return cfgRooleFilter.Value.FilterSingle(InnerMakeGiftConfigs, t => t.Roles, true);

            }
        }

        /// <summary>
        /// 请不要手工调用
        /// </summary>
        [XmlArray("MakeGift.regionRules"), XmlArrayItem("MakeGift")]
        public List<MakeGiftConfig> InnerMakeGiftConfigs { get; set; }

        
        public EggPointConfig EggPointConfig {
            get
            {
                return cfgRooleFilter.Value.FilterSingle(InnerEggPointConfig, t => t.Roles, true); 
            }
        }

        /// <summary>
        /// 请不要手动调用
        /// </summary>
         [XmlArray("EggPoint.regionRules"), XmlArrayItem("EggPoints")]
        public List<EggPointConfig> InnerEggPointConfig { get; set; }
        
        public MIRConfig MIRConfig {
            get
            {
                return cfgRooleFilter.Value.FilterSingle(InnerMIRConfigs, t => t.Roles, true); 

            }
        }

        /// <summary>
        /// 请不要手动调用
        /// </summary>
         [XmlArray("MIR.regionRules"), XmlArrayItem("MIR")]
        public List<MIRConfig> InnerMIRConfigs { get; set; }

        public NeweggPremier NeweggPremier
        {
            get
            {
                return cfgRooleFilter.Value.FilterSingle(InnerNeweggPremiers, t => t.Roles, true);
            }
        }

        /// <summary>
        /// 请不要手动调用此方法
        /// </summary>
        [XmlArray("NeweggPremier.regionRules"), XmlArrayItem("NeweggPremier")]
        public List<NeweggPremier> InnerNeweggPremiers { get; set; }

        [XmlElement("SwithToNewegg")]
        public bool SwithToNewegg { get; set; }

        /// <summary>
        /// 用于内部读取配置，请不要调用此方法
        /// </summary>
        [XmlArray("blogroll.regionRules"), XmlArrayItem("blogroll")]
        public List<BlogrollConfigRoles> InnerBlogrolls { get; set; }

        public List<BlogrollConfig> Blogrolls {
            get
            {
                var wraps= cfgRooleFilter.Value.FilterSingle(InnerBlogrolls, t => t.Roles,true);
                if (wraps == null) return null;
                return wraps.BlogrollConfigs;
            }
        }
        
        public Subscribe Subscribe {
            get
            {
                return cfgRooleFilter.Value.FilterSingle(InnerSubscribes, t => t.Roles, true);
            }
        }

        /// <summary>
        /// 用于内部读取配置，请不要调用此方法
        /// </summary>
         [XmlArray("subscribe.regionRules"), XmlArrayItem("subscribe")]
        public List<Subscribe> InnerSubscribes { get; set; }

        /// <summary>
        /// 用于内部读取配置，请不要调用此方法
        /// </summary>
        [XmlArray("sharelink.regionRules"), XmlArrayItem("ShareLinks")]
         public List<ShareLinkRoles> InnerShareLinks { get; set; }

        public List<ShareLink> ShareLinks {
            get
            {
                var warp= cfgRooleFilter.Value.FilterSingle(InnerShareLinks, t => t.Roles,true);
                if (warp == null) return null;
                return warp.ShareLink;
            }
        }

        [XmlElement("IPData")]
        public IPData IPData { get; set; }

        /// <summary>
        /// Gets or sets translator configuration.
        /// </summary>
        [XmlElement("Translator")]
        public TranslatorSetting TranslatorSetting { get; set; }
    
    }
}
