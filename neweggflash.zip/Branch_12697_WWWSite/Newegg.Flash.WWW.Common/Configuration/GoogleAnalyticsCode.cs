﻿using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// GoogleAnalyticsCode config. Belong to third party
    /// </summary>
    public class GoogleAnalyticsCode
    {
        /// <summary>
        /// Gets or sets a value indicating whether switch on or off.
        /// </summary>
        [XmlElement("enable")]
        public bool Enable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether AccountID.
        /// </summary>
        [XmlElement("accountID")]
        public string AccountID { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether TrackDomain.
        /// </summary>
        [XmlElement("trackDomain")]
        public string TrackDomain { get; set; }

        /// <summary>
        /// Gets or sets a value indicating google tracking content.
        /// </summary>
        [XmlElement("content")]
        public string Content { get; set; }
    }
}
