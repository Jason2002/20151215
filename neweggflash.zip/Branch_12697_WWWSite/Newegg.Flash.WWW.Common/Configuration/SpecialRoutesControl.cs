﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    [XmlRoot("SpecialRoutesControl")]
    public class SpecialRoutesControl
    {
        [XmlArray("specialRoutes"), XmlArrayItem("route")]
        public List<Route> SpecialRoutes { get; set; }

        [XmlArray("allows"), XmlArrayItem("allow")]
        public List<Allow> Allows { get; set; }
    }


    public class Route
    {
        [XmlAttribute("path")]
        public string Path { get; set; }
    }

    public class Allow
    {
        [XmlAttribute("name")]
        public string Name { get; set; }
        [XmlAttribute("value")]
        public string Value { get; set; }
    }
}
