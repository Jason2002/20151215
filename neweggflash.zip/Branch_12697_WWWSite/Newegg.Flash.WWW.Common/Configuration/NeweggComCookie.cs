﻿using Newegg.EC;
using Newegg.EC.Configuration;
using Newegg.EC.Net.Implement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{ 
    public class NeweggComCookie
    {
        private TimeSpan m_ExpiresAfter;

        /// <summary>
        /// Gets or sets the cookie id.
        /// </summary>
        /// <value>The cookie id.</value>
        [XmlAttribute("cookieId")]
        public string CookieId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name of the cookie used in Http header.
        /// </summary>
        /// <value>The name of the cookie.</value>
        [XmlAttribute("cookieName")]
        public string CookieName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether [special domain].
        /// </summary>
        /// <value><c>true</c> if [special domain]; otherwise, <c>false</c>.</value>
        [XmlAttribute("specialDomain")]
        public bool SpecialDomain
        {
            get;
            set;
        }

        [XmlAttribute("domain")]
        public string Domain
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the name of the domain.
        /// Returns null if the cookie is not a domain cookie.
        /// </summary>
        /// <value>The name of the domain.</value>
        public string DomainName
        {
            get {
                if (!SpecialDomain
                    && !string.IsNullOrEmpty(this.Domain))
                {
                    return Domain;
                }

                var domainName = string.Empty;
                IConfigurationManager manager = ECLibraryContainer.Current.GetInstance<IConfigurationManager>();
                
                var hosts = manager.GetConfiguration<HostsConfig>(); 
                if (hosts != null
                    && hosts.Hosts != null
                    && hosts.Hosts.Collection != null
                    && hosts.Hosts.Collection.Count > 0)
                {
                    var host = hosts.Hosts.Collection.Where(x => "WWWNeweggCom".Equals(x.Name)).FirstOrDefault();
                    if (host != null)
                    {
                        if (host.Address.ToLower().Contains("localhost"))
                        {
                            // for dev test
                            domainName = "localhost";
                        }
                        else
                        {
                            domainName = host.Address.Replace("http://", "").Replace("https://", "").Replace("www", "");
                        }
                    }
                }
                return SpecialDomain ? domainName : Domain;
            }
        }

        [XmlAttribute("path")]
        public string Path
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the expiration.
        /// If the cookie never expires, the ExpiresAfter.Ticks = 0.
        /// </summary>
        /// <value>The expiration.</value>
        [XmlIgnore]
        public TimeSpan ExpiresAfter
        {
            get { return m_ExpiresAfter; }
        }

        /// <summary>
        /// This is used internallly. Do not use this property directly.
        /// </summary>
        /// <value>The internal value1.</value>
        [XmlAttribute("expiresAfter")]
        public string InternalValue1
        {
            get { return null; }
            set { m_ExpiresAfter = TimeSpan.Parse(value); }
        }

        /// <summary>
        /// Gets or sets the property indicating the cookie is available for https site only.
        /// </summary>
        /// <value>The secure only.</value>
        [XmlAttribute("secureOnly")]
        public bool SecureOnly
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this cookie info should be rendered to the client.
        /// </summary>
        /// <value><c>true</c> if the cookie info should be rendered to the client; otherwise, <c>false</c>.</value>
        [XmlAttribute("renderInClient")]
        public bool RenderInClient
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a value indicating whether expiration is enabled for the current cookie.
        /// </summary>
        /// <value><c>true</c> if expiration is enabled; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool EnableExpiration
        {
            get { return m_ExpiresAfter.Ticks != 0; }
        }

    }

}
