﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class DFIS
    {
        #region fileds
        private string m_DFISHost;
        private string m_DFISFileGroup;
        private string m_image160Site;
        private string m_image240Site;
        private string m_image300Site;
        private string m_image600Site;
        private string m_image1280Site;
        private string m_campaignImage240Site;
        private string m_campaignImage300Site;
        private string m_campaignImage600Site;
        #endregion

        [XmlElement("DFISHost")]
        public string DFISHost 
        {
            get { return m_DFISHost; }
            set { m_DFISHost = value; }
        }

        [XmlElement("DFISFileGroup")]
        public string DFISFileGroup 
        {
            get { return m_DFISFileGroup; }
            set { m_DFISFileGroup = value.Trim('\\', '/'); }
        }

        [XmlElement("Item")]
        public ImageSizeGroup ItemImage { get; set; }

        [XmlElement("Campaign")]
        public ImageSizeGroup CampaignImage { get; set; }
    }

    public class ImageSizeGroup
    {
        private string m_image125Site;
        private string m_image160Site;
        private string m_image240Site;
        private string m_image300Site;
        private string m_image600Site;
        private string m_image1280Site;

        [XmlElement("image125Site")]
        public string Image125Site
        {
            get { return m_image125Site; }
            set { m_image125Site = value.Trim('\\', '/'); }
        }

        [XmlElement("image160Site")]
        public string Image160Site
        {
            get { return m_image160Site; }
            set { m_image160Site = value.Trim('\\', '/'); }
        }

        [XmlElement("image240Site")]
        public string Image240Site
        {
            get { return m_image240Site; }
            set { m_image240Site = value.Trim('\\', '/'); }
        }

        [XmlElement("image300Site")]
        public string Image300Site
        {
            get { return m_image300Site; }
            set { m_image300Site = value.Trim('\\', '/'); }
        }

        [XmlElement("image600Site")]
        public string Image600Site
        {
            get { return m_image600Site; }
            set { m_image600Site = value.Trim('\\', '/'); }
        }

        [XmlElement("image1280Site")]
        public string Image1280Site
        {
            get { return m_image1280Site; }
            set { m_image1280Site = value.Trim('\\', '/'); }
        }
    }
}
