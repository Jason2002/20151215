﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// Newegg Visitor Tracking Cookie config info.
    /// </summary>
    public class NVTC
    {
        /// <summary>
        /// Gets or sets a value indicating whether is enable nvtc.
        /// </summary>
        [XmlElement("enable")]
        public bool Enable { get; set; }

        [XmlElement("code")]
        public string Code { get; set; }
    }
}
