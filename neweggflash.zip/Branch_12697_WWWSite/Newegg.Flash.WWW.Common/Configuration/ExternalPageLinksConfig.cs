﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class ExternalPageLinksConfig
    {
        [XmlAttribute("roles")]
        public String Roles { get; set; }

        [XmlElement("host")]
        public string Host { get; set; }

        [XmlElement("faq")]
        public string Faq { get; set; }
        
        [XmlElement("contactUs")]
        public string ContactUs { get; set; }

        [XmlElement("termsConditions")]
        public string TermsConditions { get; set; }

        [XmlElement("privacyPolicy")]
        public string PrivacyPolicy { get; set; }

        [XmlElement("returnPolicy")]
        public string ReturnPolicy { get; set; }

        [XmlElement("giftCardTermCondition")]
        public string GiftCardTermCondition { get; set; }
    }
}
