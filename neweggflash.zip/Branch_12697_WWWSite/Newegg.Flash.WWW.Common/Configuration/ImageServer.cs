﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class ImageServer
    {
        #region fields
        private ImageServerAlias m_ServerAlias;
        private string m_NormalImageSite;
        private string m_SecureImageSite;
        #endregion

        #region properties
        [XmlAttribute("serverAlias")]
        public ImageServerAlias ServerAlias
        {
            get { return m_ServerAlias; }
            set { m_ServerAlias = value; }
        }

        [XmlElement("normalImageSite")]
        public string NormalImageSite
        {
            get { return m_NormalImageSite; }
            set { m_NormalImageSite = value; }
        }

        [XmlElement("secureImageSite")]
        public string SecureImageSite
        {
            get { return m_SecureImageSite; }
            set { m_SecureImageSite = value; }
        }
        #endregion
    }

    public class ImageServerConfig
    {
        private List<ImageServer> m_ImageServers;

        public IDictionary<ImageServerAlias, ImageServer> ServerList
        {
            get
            {
                IDictionary<ImageServerAlias, ImageServer> dictionary = new Dictionary<ImageServerAlias, ImageServer>();

                if (m_ImageServers != null)
                {
                    foreach (ImageServer imageServer in m_ImageServers)
                    {
                        dictionary.Add(imageServer.ServerAlias, imageServer);
                    }
                }
                return dictionary;
            }
        }
        [XmlElement("server")]
        public List<ImageServer> ImageServers
        {
            get { return m_ImageServers; }
            set { m_ImageServers = value; }
        }
    }
}
