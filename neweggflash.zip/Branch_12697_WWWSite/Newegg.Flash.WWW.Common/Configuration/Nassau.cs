﻿using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// Nassau Config. Belong to third party
    /// </summary>
    public class Nassau
    {
        /// <summary>
        /// Gets or sets a value indicating whether switch on or off.
        /// </summary>
        [XmlElement("enable")]
        public bool Enable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating google tracking content.
        /// </summary>
        [XmlElement("content")]
        public string Content { get; set; }
    }
}
