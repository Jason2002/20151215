﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public interface ICfgRoleFilter
    {
        List<T> Filter<T>(IEnumerable<T> lst, Func<T, String> getRoles, bool nullIsAll) where T : class;

        T FilterSingle<T>(IEnumerable<T> lst, Func<T, String> getRoles, bool nullIsAll,bool nullIsDefault=true) where T : class;
    }

}
