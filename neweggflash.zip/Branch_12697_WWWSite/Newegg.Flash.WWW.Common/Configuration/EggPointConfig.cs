﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{ 
    public class EggPointConfig
    {
        [XmlAttribute("roles")]
        public String Roles { get; set; }

        private List<EggPointRule> ruleList;

        private Dictionary<string, EggPointRule> positionRule = new Dictionary<string, EggPointRule>();

        private static object syncObject = new object();

        [XmlAttribute("Enable")]
        public bool Enable { get; set; }

        [XmlElement("ProductPagePromotionLink")]
        public string ProductPagePromotionLink { get; set; }

        [XmlElement("DefaultRule")]
        public EggPointRule DefaultRule { get; set; }

        [XmlElement("Rule")]
        public List<EggPointRule> RuleList
        {
            get { return ruleList; }
            set
            {
                ruleList = value;

                this.positionRule.Clear();
            }
        }
         
        private void InitPosition()
        {
            if (this.ruleList == null)
            {
                return;
            }

            if (this.positionRule.Count > 0)
            {
                return;
            }

            lock (syncObject)
            {
                foreach (var n in this.ruleList)
                {
                    if (n.PositionList == null)
                    {
                        continue;
                    }

                    foreach (var p in n.PositionList)
                    {
                        if (!positionRule.ContainsKey(p))
                        {
                            positionRule.Add(p, n);
                        }
                    }
                }
            }
        }

        public EggPointRule GetRule(string position)
        {
            InitPosition();
            EggPointRule rule;
            this.positionRule.TryGetValue(position, out rule);
            return rule == null ? this.DefaultRule : rule;
        }
    }
}
     
 
