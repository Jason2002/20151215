﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class BlogrollConfig
    {

        [XmlAttribute("name")]
        public string Name { get; set; }
        

        [XmlElement("title")]
        public string Title { get; set; }

        [XmlElement("href")]
        public string Href { get; set; }

        [XmlElement("content")]
        public string Content { get; set; }


    }

    public class BlogrollConfigRoles
    {
        [XmlAttribute("roles")]
        public string Roles { get; set; }

        [XmlElement("link")]
        public List<BlogrollConfig> BlogrollConfigs { get; set; }
    }
}
