﻿
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class JsFilePath
    {
        [XmlElement("eluminate")]
        public string Eluminate { get; set; }

        [XmlElement("cmdatatagutils")]
        public string Cmdatatagutils { get; set; }
    }
}
