﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class ShareLink
    {
        [XmlAttribute("roles")]
        public string Roles { get; set; }

        [XmlElement("icon")]
        public string Icon { get; set; }

        [XmlElement("title")]
        public string Title { get; set; }

        [XmlElement("link")]
        public string Link { get; set; }

        [XmlElement("productLink")]
        public string ProductLink { get; set; }

        [XmlElement("shareType")]
        public string ShareType { get; set; }
    }

    public class ShareLinkRoles
    {
        [XmlAttribute("roles")]
        public string Roles { get; set; }

        [XmlElement("share")]
        public List<ShareLink> ShareLink { get; set; }
    }

}
