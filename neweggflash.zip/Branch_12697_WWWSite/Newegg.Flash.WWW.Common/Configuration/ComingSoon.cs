﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  6/21/2013 11:45:26 AM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class ComingSoon
    {
        /// <summary>
        /// Switch for ComingSoon.
        /// </summary>
        [XmlAttribute("enable")]
        public bool Enable { get; set; }

        /// <summary>
        /// NeweggFlash Launch Time.
        /// </summary>
        [XmlElement("LaunchTime")]
        public string InternalLaunchTime { get; set; }

        /// <summary>
        /// NeweggFlash Launch Time.
        /// </summary>
        [XmlIgnore]
        public DateTime LaunchTime {
            get
            {
                DateTime time;
                if (DateTime.TryParse(InternalLaunchTime, out time))
                {
                    return time;
                }
                else
                {
                    return new DateTime(1900, 1, 1);
                }
            }
        }

        /// <summary>
        /// Internal user's IP.
        /// </summary>
        public InternalIP InternalIP { get; set; }

        /// <summary>
        /// Redirect url.
        /// </summary>
        public string PageUrl { get; set; }
    }

    public class InternalIP
    {
        /// <summary>
        /// Internal user's IP.
        /// </summary>
        [XmlElement("IP")]
        public List<string> IP { get; set; } 
    }
}
