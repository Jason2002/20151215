﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class HeadlineConfig
    {
        [XmlElement("inTheSpotlight")]
        public string InTheSpotlight { get; set; }

        [XmlElement("featuredStore")]
        public string FeaturedStore { get; set; }

        [XmlElement("featuredDeals")]
        public string FeaturedDeals { get; set; }

        [XmlElement("specialStore")]
        public string SpecialStore { get; set; }

    }

    
}
