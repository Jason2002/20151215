﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    [XmlRoot("Varnish")]
    public class Varnish
    {
        [XmlElement("EnableVarnish")]
        public bool EnableVarnish { get; set; }

        [XmlElement("FromVarnishKey")]
        public string FromVarnishKey { get; set; }

        [XmlElement("FromVarnishValue")]
        public string FromVarnishValue { get; set; }

        [XmlElement("ToVarnishKey")]
        public string ToVarnishKey { get; set; }

        [XmlArray("Levelpages")]
        [XmlArrayItem("urlAlias")]
        public List<Levelpages> Levelpages { get; set; }

        [XmlElement("ByPass")]
        public ByPass ByPass { get; set; }
    }

    public class Levelpages
    {
        [XmlAttribute("value")]
        public string Value { get; set; }

        [XmlText]
        public string Url { get; set; }
    }

    public class ByPass
    {
        [XmlAttribute("value")]
        public string ByPassValue { get; set; }

        [XmlElement("devices")]
        public VarnishByPassDevices ByPassDevices { get; set; }

        [XmlElement("pages")]
        public VarnishByPassPages ByPassPages { get; set; }

        [XmlElement("checkAgents")]
        public VarnishCheckAgents CheckAgents { get; set; }
    }

    public class VarnishCheckAgents
    {
        [XmlElement("agent")]
        public List<string> Agents { get; set; }
    }

    public class VarnishByPassDevices
    {
        [XmlElement("device")]
        public List<string> Devices { get; set; }
    }

    public class VarnishByPassPages
    {
        [XmlElement("page")]
        public List<string> Pages { get; set; }
    }
}
