using System.Xml.Serialization;
using System.Linq;

namespace Newegg.Flash.WWW.Common.Configuration.SiteCatalyst
{
    /// <summary>
    /// The SiteCatalystConfiguration.
    /// </summary>
    public partial class SiteCatalystConfiguration
    {
        /// <summary>
        /// Gets the properties by page.
        /// </summary>
        /// <param name="key">Acion name.</param>
        /// <returns>Sitecatalyst Mapping config item for request page.</returns>
        public Mapping this[string key]
        {
            get
            {
                if (this.PageMapping != null && this.PageMapping.Mappings != null)
                {
                    return this.PageMapping.Mappings
                        .Where(c => c.Action.Equals(key, System.StringComparison.OrdinalIgnoreCase))
                        .FirstOrDefault();
                }

                return null;
            }
        }

        /// <summary>
        /// Check whether the request is configed to add sitecatalyst function.
        /// </summary>
        /// <param name="key">Action param.</param>
        /// <returns>If configed, return true, otherwise false.</returns>
        public bool IsConfigForAction(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                return false;
            }

            if (this.PageMapping != null && this.PageMapping.Mappings != null)
            {
                var configCount = this.PageMapping.Mappings
                            .Where(c => c.Action.Equals(key, System.StringComparison.OrdinalIgnoreCase))
                            .Count();
                return configCount > 0 ? true : false;
            }

            return false;
        }
    }
}