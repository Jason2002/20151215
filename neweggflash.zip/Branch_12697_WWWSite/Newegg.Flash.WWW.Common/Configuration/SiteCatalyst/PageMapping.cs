using System.Collections.Generic;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.SiteCatalyst
{
    /// <summary>
    /// The pagemapping.
    /// </summary>
    public class PageMapping
    {
        /// <summary>
        /// Gets or sets the mappings.
        /// </summary>
        [XmlElement("Mapping")]
        public List<Mapping> Mappings { get; set; }
    }
}