using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.SiteCatalyst
{
    /// <summary>
    /// The action mapping.
    /// </summary>
    public class Mapping
    {
        /// <summary>
        /// Gets or sets the Action Name.
        /// </summary>
        [XmlAttribute("action")]
        public string Action { get; set; }

        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        [XmlAttribute("category")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets the hierachy.
        /// </summary>
        [XmlAttribute("hierarchy")]
        public string Hierarchy { get; set; }

        /// <summary>
        /// Gets or sets the hierachy.
        /// </summary>
        [XmlAttribute("pageType")]
        public string PageType { get; set; }
    }
}