using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.SiteCatalyst
{
    /// <summary>
    /// The TagManagerConfiguration
    /// </summary>
    public class TagManagerConfiguration
    {
        /// <summary>
        /// Gets or sets the Enable.
        /// </summary>
        [XmlAttribute("Enable")]
        public bool Enable { get; set; }

        /// <summary>
        /// Gets or sets the TagLoaderCode.
        /// </summary>
        [XmlElement("TagDataCode")]
        public string TagDataCode { get; set; }
        
        /// <summary>
        /// Gets or sets the TagLoaderCode.
        /// </summary>
        [XmlElement("TagLoaderCode")]
        public string TagLoaderCode { get; set; }

        /// <summary>
        /// Gets or sets the OldTagLoaderCode.
        /// </summary>
        [XmlElement("OldTagLoaderCode")]
        public string OldTagLoaderCode { get; set; }

        /// <summary>
        /// Gets or sets the TagLoaderCode.
        /// </summary>
        [XmlElement("TagHeaderLink")]
        public string TagHeaderLink { get; set; } 
    }
}