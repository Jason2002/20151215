using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration.SiteCatalyst
{
    /// <summary>
    /// The SiteCatalystConfiguration.
    /// </summary>
    public partial class SiteCatalystConfiguration
    {
        private bool enable = true;

        /// <summary>
        /// Gets or sets the Enable.
        /// </summary>
        [XmlAttribute("Enable")]
        public bool Enable
        {
            get { return this.enable; }
            set { this.enable = value; }
        }

        /// <summary>
        /// Gets or sets the PageMapping.
        /// </summary>
        [XmlElement("PageMapping")]
        public PageMapping PageMapping { get; set; }

        /// <summary>
        /// Gets or sets the tag manager.
        /// </summary>
        [XmlElement("TagManager")]
        public TagManagerConfiguration TagManager { get; set; }

        /// <summary>
        /// Get or sets the Active 
        /// </summary>
        [XmlElement("Active")]
        public string Active { set; get; }

    }
}