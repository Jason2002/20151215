﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class IPData
    {
        [XmlElement("url")]
        public string URL { get; set; }

        [XmlAttribute("enable")]
        public bool Enable { get; set; }
    }
}
