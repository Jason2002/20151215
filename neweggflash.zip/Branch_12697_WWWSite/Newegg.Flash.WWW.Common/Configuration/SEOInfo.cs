﻿using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// SEO config
    /// </summary>
    [XmlRoot("SEOInfo", Namespace = "http://www.newegg.com/Website")]
    public class SEOInfo
    {
        [XmlElement("Home")]
        public SEOPageInfo Home { get; set; }

        [XmlElement("Today")]
        public SEOPageInfo Today { get; set; }

        [XmlElement("Upcoming")]
        public SEOPageInfo Upcoming { get; set; }

        [XmlElement("Campaign")]
        public SEOPageInfo Campaign { get; set; }

        [XmlElement("Product")]
        public SEOPageInfo Product { get; set; }

        [XmlElement("ProductReturnPolicy")]
        public SEOPageInfo ProductReturnPolicy { get; set; }

        [XmlElement("Help")]
        public SEOPageInfo Help { get; set; }
    }

    /// <summary>
    /// page info for seo
    /// </summary>
    public class SEOPageInfo
    {
        [XmlElement("pageDescription")]
        public string PageDescription { get; set; }

        [XmlElement("pageKeywords")]
        public string PageKeywords { get; set; }

        [XmlElement("pageTitle")]
        public string PageTitle { get; set; }
    }
}
