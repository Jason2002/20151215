﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    [XmlRoot("ABTestingConfig")]
    public class ABTesting
    {
        [XmlElement("enable")]
        public bool Enable { get; set; }

        [XmlArray("versions")]
        [XmlArrayItem("version")]
        public List<ABTestingVersion> Versions { get; set; }

        [XmlElement("whiteList")]
        public WhiteList WhiteList { get; set; }

    }

    public class ABTestingVersion
    {
        [XmlElement("number")]
        public int VersionNumber { get; set; }

        [XmlElement("rate")]
        public int Rate { get; set; }

        [XmlElement("expireTime")]
        public string ExpireTimeString { get; set; }

        [XmlElement("forcedRefresh")]
        public bool ForcedRefresh { get; set; }

        [XmlIgnore]
        public DateTime ExpireTime
        {
            get
            {
                var result = DateTime.MinValue;
                if (!string.IsNullOrEmpty(ExpireTimeString))
                {
                    DateTime.TryParse(ExpireTimeString, out result);
                }
                return result;
            }
        }
    }

    public class WhiteList
    {
        [XmlAttribute("version")]
        public int VersionNumber { get; set; }

        [XmlText]
        public string ContentCore { get; set; }

        [XmlIgnore]
        public List<string> Content
        {
            get
            {
                if (string.IsNullOrEmpty(ContentCore))
                {
                    return new List<string>();
                }
                return ContentCore.Replace("\r", string.Empty)
                                  .Replace("\n", string.Empty)
                                  .Replace("\t", string.Empty)
                                  .Replace(" ",string.Empty)
                                  .Split(',', ';').ToList();
            }
        }
    }
}
