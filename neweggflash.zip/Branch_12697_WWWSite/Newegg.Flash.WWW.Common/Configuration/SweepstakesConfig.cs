﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{    
    /// <summary>
    /// The Sweepstakes config.
    /// </summary>
    public class SweepstakesConfig
    {
        /// <summary>
        /// Config items.
        /// </summary>
        [XmlArray("items")]
        [XmlArrayItem("sweepstakes")]
        public List<SweepstakesConfigItem> Items { get; set; }

        [XmlAttribute("roles")]
        public string Roles { get; set; } 

        /// <summary>
        /// 
        /// </summary>
        public static SweepstakesConfigItem CurrentConfig
        {
            get
            {
                var config = ConfigurationWWWManager<BizUI>.ItemCfg().SweepstakesConfig;

                if (config == null || config.Items == null || config.Items.Count == 0)
                {
                    return null;
                }

                return config.Items.Where(p => p.Enabled == true
                                          && p.StartTime <= Common.CommonUtility.DateTimeNow
                                          && p.EndTime > Common.CommonUtility.DateTimeNow).FirstOrDefault();
            }
        }
    }
}
