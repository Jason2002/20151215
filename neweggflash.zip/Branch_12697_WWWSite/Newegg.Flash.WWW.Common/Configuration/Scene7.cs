﻿

using System.Xml.Serialization;
namespace Newegg.Flash.WWW.Common.Configuration
{
    [XmlRoot("scene7", Namespace = "http://www.newegg.com/Website")]
    public class Scene7
    {
        #region fields
  
        private bool m_EnableScene7;
        private bool m_EnableSpecialScene7;
        private bool m_EnableSSListForOldImageGallery;
        private bool m_EnableComboBundleScene7;
        private string m_commingSoonImage;
        private Scene7ImageSize m_Scene7ImageSize;
        #endregion

        #region property

        [XmlElement("enableScene7")]
        public bool EnableScene7
        {
            get { return m_EnableScene7; }
            set { m_EnableScene7 = value; }
        }

        [XmlElement("enableSpecialScene7")]
        public bool EnableSpecialScene7
        {
            get { return m_EnableSpecialScene7; }
            set { m_EnableSpecialScene7 = value; }
        }

        [XmlElement("enableSSListForOldImageGallery")]
        public bool EnableSSListForOldImageGallery
        {
            get { return m_EnableSSListForOldImageGallery; }
            set { m_EnableSSListForOldImageGallery = value; }
        }

        [XmlElement("enableComboBundleScene7")]
        public bool EnableComboBundleScene7
        {
            get { return m_EnableComboBundleScene7; }
            set { m_EnableComboBundleScene7 = value; }
        }

        [XmlElement("commingSoonImage")]
        public string CommingSoonImage
        {
            get { return m_commingSoonImage; }
            set { m_commingSoonImage = value; }
        }

        [XmlElement("imageSize")]
        public Scene7ImageSize ImageSize
        {
            get { return m_Scene7ImageSize; }
            set { m_Scene7ImageSize = value; }
        }

        #endregion
    }
    
    public class Scene7ImageSize
    {
        #region fields
        private ProductImageType m_Size125;
        private ProductImageType m_Size300;
        private ProductImageType m_Size600;
        private ProductImageType m_FullSizeImageSite;
        #endregion

        #region property
        [XmlElement("Size125")]
        public ProductImageType Size125
        {
            get { return m_Size125; }
            set { m_Size125 = value; }
        }

        [XmlElement("Size300")]
        public ProductImageType Size300
        {
            get { return m_Size300; }
            set { m_Size300 = value; }
        }

        [XmlElement("Size600")]
        public ProductImageType Size600
        {
            get { return m_Size600; }
            set { m_Size600 = value; }
        }

        [XmlElement("fullSizeImageSite")]
        public ProductImageType FullSizeImageSite
        {
            get { return m_FullSizeImageSite; }
            set { m_FullSizeImageSite = value; }
        }
        #endregion
    }
}
