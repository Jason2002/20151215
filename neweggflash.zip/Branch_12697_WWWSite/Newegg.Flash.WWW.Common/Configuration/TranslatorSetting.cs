﻿using Newegg.Flash.WWW.Common.Configuration.SiteCatalyst;
using Newegg.Flash.WWW.Common.Configuration.Tealium;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{

    public class TranslatorSetting
    {
        /// <summary>
        /// get or set translator URL
        /// </summary>
        [XmlElement("TranslatorAccessURI")]
        public string TranslatorAccessURI { get; set; }

        [XmlElement("TranslateURI")]
        public string TranslateURI { get; set; }

        /// <summary>
        /// get or set translator ClientID
        /// </summary>
        [XmlElement("ClientID")]
        public string ClientID { get; set; }

        /// <summary>
        /// get or set translator password
        /// </summary>
        [XmlElement("ACS")]
        public string Password { get; set; }

        /// <summary>
        /// get or set translator RequestDetails
        /// </summary>
        [XmlElement("RequestDetails")]
        public string RequestDetails { get; set; }
    }
}
