﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Royman Jing (royman.s.jing@newegg.com)
 * Create Date:  5/7/2013 10:47:46 AM
 * Usage:
 *
 * Revision History
 * Date         Author               Description
 * 
*****************************************************************/
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// Upcoming Events Configuration.
    /// </summary>
    public class UpcomingEvents
    {
        /// <summary>
        /// Gets or sets dayCount.
        /// </summary>
        [XmlAttribute]
        public int DayCount { get; set; }

        /// <summary>
        /// Gets or sets dealCount.
        /// </summary>
        [XmlAttribute]
        public int DealCount { get; set; }
    }
}
