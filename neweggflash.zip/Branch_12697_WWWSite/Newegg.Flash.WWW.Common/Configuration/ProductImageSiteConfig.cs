﻿/*****************************************************************
 * Copyright (C) Newegg Corporation. All rights reserved.
 * 
 * Author:   Melvin Ren (melvin.h.ren@newegg.com)
 * Create Date:  04/26/2013
 * Usage:
 *
 * RevisionHistory
 * Date         Author               PageDescription
 * 
*****************************************************************/

using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    public class ProductImageSiteConfig
    {
        #region fields
        private ImageServerConfig m_ImageServerConfig;
        private ProductImageType m_Image125Site;
        private ProductImageType m_Image300Site;
        private ProductImageType m_Image600Site;
        private ProductImageType m_FullSizeImageSite;
        private DFIS m_DFIS;
        #endregion

        #region properties
        
        [XmlElement("serverList")]
        public ImageServerConfig ImageServerConfig
        {
            get { return m_ImageServerConfig; }
            set { m_ImageServerConfig = value; }
        }

        /// <summary>
        /// Gets or sets the image300 site with no trailing '/' or '\'.
        /// </summary>
        /// <value>The image180 site.</value>
        [XmlElement("image125Site")]
        public ProductImageType Image125Site
        {
            get { return m_Image125Site; }
            set { m_Image125Site = value; }
        }

        /// <summary>
        /// Gets or sets the image300 site with no trailing '/' or '\'.
        /// </summary>
        /// <value>The image180 site.</value>
        [XmlElement("image300Site")]
        public ProductImageType Image300Site
        {
            get { return m_Image300Site; }
            set { m_Image300Site = value; }
        }

        /// <summary>
        /// Gets or sets the image300 site with no trailing '/' or '\'.
        /// </summary>
        /// <value>The image180 site.</value>
        [XmlElement("image600Site")]
        public ProductImageType Image600Site
        {
            get { return m_Image600Site; }
            set { m_Image600Site = value; }
        }

        /// <summary>
        /// Gets or sets the full size image site with no trailing '/' or '\'.
        /// </summary>
        /// <value>The full size image site.</value>
        [XmlElement("fullSizeImageSite")]
        public ProductImageType FullSizeImageSite
        {
            get { return m_FullSizeImageSite; }
            set { m_FullSizeImageSite = value; }
        }

        [XmlElement("DFIS")]
        public DFIS DFIS
        {
            get { return m_DFIS; }
            set { m_DFIS = value; }
        }
        #endregion
    }
}
