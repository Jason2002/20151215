﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Newegg.Flash.WWW.Common.Configuration
{
    /// <summary>
    /// The config item.
    /// </summary>
    public class SweepstakesConfigItem
    {
        /// <summary>
        ///  Gets or sets a value indicating whether the config item is enabled.
        /// </summary>
        [XmlAttribute("enabled")]
        public bool Enabled { get; set; }

        /// <summary>
        ///  Gets or sets start time.
        /// </summary>
        [XmlAttribute("startTime")]
        public DateTime StartTime { get; set; }

        /// <summary>
        ///  Gets or sets end time.
        /// </summary>
        [XmlAttribute("endTime")]
        public DateTime EndTime { get; set; }

        /// <summary>
        ///  Gets or sets the item description.
        /// </summary>
        [XmlAttribute("desc")]
        public string InnerDescription { get; set; }

        [XmlElement("promotionTitle")]
        public string Title { get; set; }

        [XmlElement("promotionImagePath")]
        public string ImagePath { get; set; }

        [XmlElement("promotionDecription")]
        public string Description { get; set; }

        [XmlElement("promotionUrl")]
        public string PromotionUrl { get; set; }
    }
}
