﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newegg.Flash.WWW.Model;
using System.Reflection;
using System.Collections.Generic;

namespace UnitTestProject1
{
    [TestClass]
    public class DbtransferTest
    {
        public string HomePage_Old = "http://localhost:12649/Api/";

        public string HomePage_New = "http://localhost:12649/Api/";

        public const string APPLE_DEVICE = "Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1C28 Safari/419.3";
        public const string ANDROID_DEVICE = "Mozilla/5.0 (Linux; U; Android 3.0.1; ja-jp; MZ604 Build/H.6.2-20) AppleWebKit/534.13 (KHTML, like Gecko) Version/4.0 Safari/534.13";
        public const string BLACK_BERRY_DEVICE = "BlackBerry9000/4.6.0.294 Profile/MIDP-2.0 Configuration/CLDC-1.1 VendorID/220";
        public const string WINDOWS_PHONE_DEVICE = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; KDDI-TS01; Windows Phone 6.5.3.5)";

        public const string OTHER_DEVICE_BROWSER = "Fiddler";

        public const string IE_BROWSER = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)";
        public const string FIREFOX_BROWSER = "Mozilla/5.0 (Windows NT 5.1; rv:5.0) Gecko/20100101 Firefox/5.0";
        public const string OPERA_BROWSER = "Opera/9.80 (Windows NT 5.1; U; zh-cn) Presto/2.9.168 Version/11.50";
        public const string SAFARI_BROWSER = "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1";
        public const string CHROME_BROWSER = "Mozilla/5.0 (Windows NT 5.2) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.122 Safari/534.30";
        private static int Fcount = 0;
         
        [TestMethod]
        public void TestMethod1()
        {
            if (!Directory.Exists("ResultJsons"))
            {
                Directory.CreateDirectory("ResultJsons");
            }
            else
            {
                var files = Directory.GetFiles("ResultJsons");
                foreach (string f in files)
                {
                    File.Delete(f);
                }
            }
            LoadUrlAndRunTest();
        }

        private string CreateTestUrl(string homePage, string urlTemplate, params object[] args)
        {
            return homePage + string.Format(urlTemplate, args);
        }

        /// <summary>
        /// 比较反序列化后实体的属性值是否完全相同
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url_old"></param>
        /// <param name="url_new"></param>
        /// <returns></returns>
        private bool CompareJsonEntity<T>(string url_old, string url_new)
        {
            var json_old = GetJsonString(url_old);
            var json_new = GetJsonString(url_new);

            if (!json_old.Equals(json_new))
            { 
                File.WriteAllLines(@"ResultJsons\ResultJson_" + Fcount + "_old.txt", new string[] {url_old,"\r\n", json_old });
                File.WriteAllLines(@"ResultJsons\ResultJson_" + Fcount + "_New.txt", new string[] { url_new, "\r\n", json_new });
                try
                {
                    var obj1 = JsonConvert.DeserializeObject(json_old, typeof(T));

                    var obj2 = JsonConvert.DeserializeObject(json_new, typeof(T));

                    return CompareEntity.IsEntiryEqual(obj1, obj2);
                }
                catch
                {
                    return false;
                }
            }
            else {
                return true;
            }
        }

        /// <summary>
        /// 获取RestService方法调用结果的json字符串
        /// </summary>
        /// <param name="sUrl"></param>
        /// <returns></returns>
        private string GetJsonString(string sUrl)
        {
            var url = sUrl;
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.UserAgent = IE_BROWSER;
            request.Headers.Add("X-From-Cache", "yes");
            var response = request.GetResponse();
            var respStream = response.GetResponseStream();
            string strBuff = "";
            char[] cbuffer = new char[256];
            int byteRead = 0;
            StreamReader respStreamReader = new StreamReader(respStream, Encoding.UTF8);

            byteRead = respStreamReader.Read(cbuffer, 0, 256);

            while (byteRead != 0)
            {
                string strResp = new string(cbuffer, 0, byteRead);
                strBuff = strBuff + strResp;
                byteRead = respStreamReader.Read(cbuffer, 0, 256);
            }

            respStream.Close();
            return strBuff;
        }


        private void LoadUrlAndRunTest()
        {
            var Lines = File.ReadAllLines("URL.txt");
            List<string> result = new List<string>();
            foreach (string line in Lines)
            {
                Fcount++; 
                if (!line.Trim().Equals(string.Empty))
                {
                    var url_old = line.Split(',')[0];
                    var url_new = line.Split(',')[1];
                    result.Add(url_new + "  ->  " + CompareJsonEntity<GeneralDeals>(url_old, url_new));
                }
                else
                {
                    break;
                }
            }
            File.WriteAllLines(@"ResultJsons\A_URLResults.txt", result); 
        }
    }
}
