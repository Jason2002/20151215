﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    public static class CompareEntity
    {
        public static bool IsEntiryEqual<T>(T t1, T t2)
        {
            if (t1 == null && t2 == null)
            {
                return true;
            }
            else if (t1 != null && t2 != null)
            {
                //string t1Ps = GetProperties(t1);
                //string t2Ps = GetProperties(t2);
                return (ObjectEquel(t1, t2));
            }
            else
            {
                return false;
            }

        }

        private static bool ObjectEquel<T>(T obj1, T obj2)
        {
            if (obj1 == null && obj2 == null)
            {
                return true;
            }
            else if (obj1 != null && obj2 != null)
            {
                Type type1 = obj1.GetType();
                Type type2 = obj2.GetType();

                System.Reflection.PropertyInfo[] properties1 = type1.GetProperties();
                System.Reflection.PropertyInfo[] properties2 = type2.GetProperties();

                bool IsMatch = true;
                for (int i = 0; i < properties1.Length; i++)
                {
                    string s = properties1[i].DeclaringType.Name;
                    var item = properties1[i];
                    if (item.PropertyType.IsValueType
                          || item.PropertyType.Name.StartsWith("String"))
                    {
                        if (properties1[i].GetValue(obj1, null) != null && properties2[i].GetValue(obj2, null) != null)
                        {
                            if (properties1[i].GetValue(obj1, null).ToString() != properties2[i].GetValue(obj2, null).ToString())
                            {
                                IsMatch = false;
                                break;
                            }
                        }
                    }
                    else if (typeof(ICollection).IsAssignableFrom(item.PropertyType))
                    {
                        var collection = item.GetValue(obj1);
                        var collection2 = item.GetValue(obj2);
                         
                        if (collection != null && collection2 != null)
                        {
                            var cnt1 = (int)collection.GetType().GetProperty("Count").GetValue(collection);
                            var cnt2 = (int)collection.GetType().GetProperty("Count").GetValue(collection2);
                            if (cnt1 != cnt2)
                            {
                                IsMatch = false;
                                break;
                            }
                            else
                            {
                                for (var index = 0; index < cnt1; index++)
                                {
                                    var method = collection.GetType().GetMethod("get_Item");
                                    var iv1 = method.Invoke(collection, new object[] { index });

                                    var method2 = collection.GetType().GetMethod("get_Item");
                                    var iv2 = method2.Invoke(collection, new object[] { index });
                                    IsMatch = IsMatch && ObjectEquel(iv1, iv2);
                                }
                            }
                        }
                    }
                    else if (Type.GetTypeCode(item.PropertyType) == TypeCode.Object)
                    {
                        IsMatch = IsMatch && ObjectEquel(item.GetValue(obj1), item.GetValue(obj2));
                    }
                    if (!IsMatch)
                    {
                        break;
                    }
                }
                return IsMatch;
            }
            else
            {
                return false;
            }
        }

        public static string GetProperties<T>(T t)
        {
            string tStr = string.Empty;
            if (t == null)
            {
                return tStr;
            }
            System.Reflection.PropertyInfo[] properties = t.GetType().GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);

            if (properties.Length <= 0)
            {
                return tStr;
            }
            foreach (System.Reflection.PropertyInfo item in properties)
            {
                string name = item.Name;

                object value = item.GetValue(t, null);

                if (item.PropertyType.IsValueType
                    || item.PropertyType.Name.StartsWith("String"))
                {
                    tStr += string.Format("{0}:{1},", name, value);
                }
                else
                {
                    if (typeof(ICollection).IsAssignableFrom(item.PropertyType))
                    {
                        var collection = item.GetValue(t);
                        if (collection != null)
                        {
                            var cnt = (int)collection.GetType().GetProperty("Count").GetValue(collection);
                            for (var index = 0; index < cnt; index++)
                            {
                                var method = collection.GetType().GetMethod("get_Item");
                                var iv = method.Invoke(collection, new object[] { index });

                                tStr += string.Format("{0}:{1},", index, GetProperties(iv));
                            }
                        }
                    }
                    else
                    {
                        tStr += GetProperties(value);
                    }
                }
            }
            return tStr;
        }
    }
}
