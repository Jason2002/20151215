﻿using System.Collections.Generic;
using Newegg.EC.Demo.Business.Interface;
using Newegg.EC.Web.Http;

namespace Newegg.EC.Demo.RestfulService.Controller
{
    /// <summary>
    /// Demo controller.
    /// </summary>
    public class DemosController : ServiceController
    {
        /// <summary>
        /// Get demos.
        /// </summary>
        /// <returns>Demo collection.</returns>
        public IEnumerable<DemoItem> GetDemos()
        {
            return ECLibraryContainer.Current.GetInstance<IDemo>().GetAllItems();
        }

        /// <summary>
        /// Get demos.
        /// </summary>
        /// <param name="id">Parameter of id.</param>
        /// <returns>Demo collection.</returns>
        public DemoItem GetDemos(int id)
        {
            return ECLibraryContainer.Current.GetInstance<IDemo>().GetItemByID(id);
        }

        /// <summary>
        /// Get demos.
        /// </summary>
        /// <param name="keywords">Parameter of keywords.</param>
        /// <param name="priority">Parameter of priority.</param>
        /// <returns>Demo collection.</returns>
        public IEnumerable<DemoItem> GetDemos(string keywords, int priority)
        {
            return ECLibraryContainer.Current.GetInstance<IDemo>().GetItems(keywords, priority);
        }
    }
}
