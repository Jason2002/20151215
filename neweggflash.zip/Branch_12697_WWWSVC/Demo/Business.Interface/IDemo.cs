﻿using System.Collections.Generic;

namespace Newegg.EC.Demo.Business.Interface
{
    /// <summary>
    /// Demo business inteface.
    /// </summary>
    public interface IDemo
    {
        /// <summary>
        /// Get all items.
        /// </summary>
        /// <returns>Demo item collection.</returns>
        IEnumerable<DemoItem> GetAllItems();

        /// <summary>
        /// Get item by id.
        /// </summary>
        /// <param name="id">Parameter of id.</param>
        /// <returns>Demo item.</returns>
        DemoItem GetItemByID(int id);

        /// <summary>
        /// Get item by keywords and priority.
        /// </summary>
        /// <param name="keywords">Parameter of keywords.</param>
        /// <param name="priority">Parameter of priority.</param>
        /// <returns>Queried items.</returns>
        IEnumerable<DemoItem> GetItems(string keywords, int priority);
    }
}
