﻿namespace Newegg.EC.Demo.Business.Interface
{
    /// <summary>
    /// Demo item.
    /// </summary>
    public class DemoItem
    {
        /// <summary>
        /// Gets or sets id.
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Gets or sets name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets priority.
        /// </summary>
        public int Priority { get; set; }
    }
}
