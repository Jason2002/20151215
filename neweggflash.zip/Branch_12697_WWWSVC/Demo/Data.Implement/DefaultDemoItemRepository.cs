﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newegg.EC.Demo.Data.Interface;
using Newegg.EC.IOC;

namespace Newegg.EC.Demo.Data.Implement
{
    /// <summary>
    /// Default demo item repository.
    /// </summary>
    [AutoSetupService(typeof(IDemoItemRepository))]
    public class DefaultDemoItemRepository : IDemoItemRepository
    {
        /// <summary>
        /// Field of items.
        /// </summary>
        private Lazy<List<DemoDataItem>> myData = new Lazy<List<DemoDataItem>>(CreateData);

        /// <summary>
        /// Get all items.
        /// </summary>
        /// <returns>Demo item collection.</returns>
        public IEnumerable<DemoDataItem> GetAllItems()
        {
            return this.myData.Value;
        }

        /// <summary>
        /// Get item by id.
        /// </summary>
        /// <param name="id">Parameter of id.</param>
        /// <returns>Demo item.</returns>
        public DemoDataItem GetItemByID(int id)
        {
            return this.myData.Value.FirstOrDefault(item => item.ID == id);
        }

        /// <summary>
        /// Create data.
        /// </summary>
        /// <returns>Demo data items.</returns>
        private static List<DemoDataItem> CreateData()
        {
            List<DemoDataItem> result = new List<DemoDataItem>();

            result.Add(new DemoDataItem() { ID = 1, Name = "Thales", Description = "Thales is sh ec architect.", Priority = 66 });
            result.Add(new DemoDataItem() { ID = 2, Name = "Royman", Description = "Royman is b2b pm.", Priority = 77 });
            result.Add(new DemoDataItem() { ID = 3, Name = "Jimmy", Description = "Jimmy is CD oversea architect.", Priority = 55 });
            result.Add(new DemoDataItem() { ID = 4, Name = "Johnny", Description = "Johnny from XA.", Priority = 30 });

            return result;
        }
    }
}
