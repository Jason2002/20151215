﻿using System.Collections.Generic;
using System.Linq;
using Newegg.EC.Demo.Business.Interface;
using Newegg.EC.Demo.Data.Interface;
using Newegg.EC.IOC;

namespace Newegg.EC.Demo.Business.Implement
{
    /// <summary>
    /// Default implement of demo interface.
    /// </summary>
    [AutoSetupService(typeof(IDemo))]
    public class DefaultDemo : IDemo
    {
        /// <summary>
        /// Get all items.
        /// </summary>
        /// <returns>Demo item collection.</returns>
        public IEnumerable<DemoItem> GetAllItems()
        {
            return ECLibraryContainer.Current.GetInstance<IDemoItemRepository>().GetAllItems().Select(item => item.ToDemoItem());
        }

        /// <summary>
        /// Get item by id.
        /// </summary>
        /// <param name="id">Parameter of id.</param>
        /// <returns>Demo item.</returns>
        public DemoItem GetItemByID(int id)
        {
            DemoItem result = null;

            DemoDataItem item = ECLibraryContainer.Current.GetInstance<IDemoItemRepository>().GetItemByID(id);

            if (item != null)
            {
                result = item.ToDemoItem();
            }

            return result;
        }

        /// <summary>
        /// Get item by keywords and priority.
        /// </summary>
        /// <param name="keywords">Parameter of keywords.</param>
        /// <param name="priority">Parameter of priority.</param>
        /// <returns>Queried items.</returns>
        public IEnumerable<DemoItem> GetItems(string keywords, int priority)
        {
            return ECLibraryContainer.Current.GetInstance<IDemoItemRepository>().GetAllItems().Where(item => this.Check(item, keywords, priority)).Select(item => item.ToDemoItem());
        }

        /// <summary>
        /// Check wheter item is valid.
        /// </summary>
        /// <param name="item">Parameter of item.</param>
        /// <param name="keywords">Parameter of keywords.</param>
        /// <param name="priority">Parameter of priority.</param>
        /// <returns>Check result.</returns>
        private bool Check(DemoDataItem item, string keywords, int priority)
        {
            if (item == null)
            {
                return false;
            }

            if (item.Priority < priority)
            {
                return false;
            }

            if (!string.IsNullOrWhiteSpace(keywords))
            {
                if (!string.IsNullOrWhiteSpace(item.Name) && item.Name.ToLower().Contains(keywords.ToLower()))
                {
                    return true;
                }

                if (!string.IsNullOrWhiteSpace(item.Description) && item.Description.ToLower().Contains(keywords.ToLower()))
                {
                    return true;
                }

                return false;
            }

            return true;
        }
    }
}
