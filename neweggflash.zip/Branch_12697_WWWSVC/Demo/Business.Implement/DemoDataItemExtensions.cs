﻿using Newegg.EC.Demo.Business.Interface;
using Newegg.EC.Demo.Data.Interface;

namespace Newegg.EC.Demo.Business.Implement
{
    /// <summary>
    /// Demo data item extension methods.
    /// </summary>
    public static class DemoDataItemExtensions
    {
        /// <summary>
        /// Convert demo data item to business demo item.
        /// </summary>
        /// <param name="me">Current demo data item.</param>
        /// <returns>Demo item.</returns>
        public static DemoItem ToDemoItem(this DemoDataItem me)
        {
            DemoItem result = null;

            if (me != null)
            {
                result = new DemoItem()
                {
                    ID = me.ID,
                    Name = me.Name,
                    Description = me.Description,
                    Priority = me.Priority
                };
            }

            return result;
        }
    }
}
