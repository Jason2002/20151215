﻿namespace Newegg.EC.Demo.Data.Interface
{
    /// <summary>
    /// Demo data item.
    /// </summary>
    public class DemoDataItem
    {
        /// <summary>
        /// Gets or sets id.
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Gets or sets name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets priority.
        /// </summary>
        public int Priority { get; set; }
    }
}
