﻿using System.Collections.Generic;

namespace Newegg.EC.Demo.Data.Interface
{
    /// <summary>
    /// Demo item repository interface.
    /// </summary>
    public interface IDemoItemRepository
    {
        /// <summary>
        /// Get all items.
        /// </summary>
        /// <returns>Demo item collection.</returns>
        IEnumerable<DemoDataItem> GetAllItems();

        /// <summary>
        /// Get item by id.
        /// </summary>
        /// <param name="id">Parameter of id.</param>
        /// <returns>Demo item.</returns>
        DemoDataItem GetItemByID(int id);
    }
}
