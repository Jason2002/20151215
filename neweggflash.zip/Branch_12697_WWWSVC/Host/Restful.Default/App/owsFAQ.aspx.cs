﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newegg.Flash.Business.Interface;

namespace Newegg.EC.Service.Host.Restful.Default
{
    /// <summary>
    /// The owsFAQ.
    /// </summary>
    public partial class owsFAQ : System.Web.UI.Page
    {
        #region <-Instance Fields->
        private const string SUCCESS_DESCRIPTION = "Server is ok!";
        private const string ERROR_DESCRIPTION = "Server doesn't work!";
        private const string SUCCESS_DESCRIPTION_DATABASE = "Database is ok!<br/>";
        private const string ERROR_DESCRIPTION_DATABASE = "Database is being maintained!<br/>";
        private const string SUCCESS_TAG = "<!--Newegg-->";
        private const string ERROR_TAG = "<!--##-->";
        #endregion

        #region <-Methodes->
        /// <summary>
        /// The OnPreRender.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreRender(EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            bool isDatabaseOk = false;
            try
            {
                isDatabaseOk = ECLibraryContainer.Current.GetInstance<IApplication>().DatabaseIsOk().DatabaseIsOk;
                if (isDatabaseOk)
                {
                    sb.AppendLine(SUCCESS_DESCRIPTION_DATABASE);
                }
                else
                {
                    sb.AppendLine(ERROR_DESCRIPTION_DATABASE);
                }
            }
            catch (Exception ex)
            {
                isDatabaseOk = false;
                sb.AppendLine("Exception:<br/>");
                sb.AppendLine(ex.Message);
                sb.AppendLine(ex.StackTrace);
            }
            if (isDatabaseOk)
            {
                Response.Write(SUCCESS_TAG + Environment.NewLine);
                Response.Write(SUCCESS_DESCRIPTION + Environment.NewLine + "<br/><br/>");
                Response.Write(sb.ToString());
            }
            else
            {
                SendFalureResponse();
                Response.Write(ERROR_DESCRIPTION + Environment.NewLine + "<br/><br/>");
                Response.Write(ERROR_TAG + Environment.NewLine);
                Response.Write(sb.ToString());
                Response.Write(ERROR_TAG);
            }
            base.OnPreRender(e);
        }

        /// <summary>
        /// If any error occurs and the server should be taken offline, return http response code 400. 
        /// </summary>
        private void SendFalureResponse()
        {
            string type = Request.QueryString["t"] ?? string.Empty;
            if (type != "1")
            {
                Response.StatusCode = 400;
            }
        }

        /// <summary>
        /// The Page_Load.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion
    }
}