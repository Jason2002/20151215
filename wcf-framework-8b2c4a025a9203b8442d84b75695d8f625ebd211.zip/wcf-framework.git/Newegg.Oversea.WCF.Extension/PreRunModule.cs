﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;

namespace Newegg.Oversea.WCF.Extension
{
    public class PreRunModule : IHttpModule
    {
        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            context.BeginRequest += (sender, args) =>
            {
                var headerNew = ((HttpApplication)sender).Context.Request.Headers;
                var accept = headerNew.AllKeys.FirstOrDefault(k => k.Equals("Accept", StringComparison.InvariantCultureIgnoreCase));
                if (accept != null)
                {
                    var rawAccept = headerNew[accept];
                    if (!string.IsNullOrEmpty(rawAccept) &&
                        (rawAccept.ToLower().IndexOf("application/json") > -1
                         || rawAccept.ToLower().IndexOf("text/json") > -1)
                        )
                    {
                        Type hdr = headerNew.GetType();
                        PropertyInfo ro = hdr.GetProperty("IsReadOnly",
                            BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.IgnoreCase | BindingFlags.FlattenHierarchy);
                        // Remove the ReadOnly property
                        ro.SetValue(headerNew, false, null);
                        // Invoke the protected InvalidateCachedArrays method 
                        hdr.InvokeMember("InvalidateCachedArrays",
                            BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Instance,
                            null, headerNew, null);
                        // Now invoke the protected "BaseAdd" method of the base class to add the
                        // headers you need. The header content needs to be an ArrayList or the
                        // the web application will choke on it.
                        hdr.InvokeMember("BaseSet",
                            BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Instance,
                            null, headerNew,
                            new object[] { accept, new ArrayList { "application/json" } });
                        // repeat BaseAdd invocation for any other headers to be added
                        // Then set the collection back to ReadOnly
                        ro.SetValue(headerNew, true, null);
                    }
                }
            };
        }
    }
}
