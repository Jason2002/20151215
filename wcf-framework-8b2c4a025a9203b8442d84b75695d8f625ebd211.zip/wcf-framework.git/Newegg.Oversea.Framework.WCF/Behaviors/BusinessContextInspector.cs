﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Dispatcher;
using System.ServiceModel;
using Newegg.Oversea.Framework.WCF.Contracts;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    public class BusinessContextInspector : IParameterInspector
    {
        public BusinessContextInspector()
        {
        }

        #region IParameterInspector Members

        public void AfterCall(string operationName, object[] outputs, object returnValue, object correlationState)
        {
            //
        }

        public object BeforeCall(string operationName, object[] inputs)
        {
            if (inputs != null)
            {
                for (int i = 0; i < inputs.Length; i++)
                {
                    DefaultDataContract dataContract = inputs[i] as DefaultDataContract;
                    MessageHeader msgHeader = null;
                    if (dataContract != null)
                    {
                        if (dataContract.Header != null)
                        {
                            msgHeader = dataContract.Header;
                        }
                    }
                    else
                    {
                        DefaultQueryContract queryContract = inputs[i] as DefaultQueryContract;
                        if (queryContract != null && queryContract.Header != null)
                        {
                           msgHeader = queryContract.Header;
                        }
                    }

                    if (msgHeader != null)
                    {
                        BusinessContextData contextData = new BusinessContextData();
                        contextData.CompanyCode = msgHeader.CompanyCode;
                        contextData.CountryCode = msgHeader.CountryCode;
                        contextData.Language = msgHeader.Language;
                        if (msgHeader.OperationUser != null)
                        {
                            contextData.OperationUserFullName =msgHeader.OperationUser.FullName;
                            contextData.OperationUserLoginName =msgHeader.OperationUser.SourceUserName;
                            contextData.OperationUserSourceDirectoryKey =msgHeader.OperationUser.SourceDirectoryKey;
                            contextData.OperationUserUniqueUserName =msgHeader.OperationUser.UniqueUserName;
                        }
                        contextData.StoreCompanyCode =msgHeader.StoreCompanyCode;
                        contextData.TimeZone =msgHeader.TimeZone;
                        contextData.From =msgHeader.From;
                        contextData.FromSystem =msgHeader.FromSystem;
                        contextData.To =msgHeader.To;
                        contextData.ToSystem =msgHeader.ToSystem;
                        contextData.TransactionCode =msgHeader.TransactionCode;
                        contextData.Tag =msgHeader.Tag;
                        contextData.Version = msgHeader.Version;

                        BusinessContext.Current = contextData;

                        break;
                    }
                }
            }
            
            return null;
        }


        #endregion
    } 
}
