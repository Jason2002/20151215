﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Diagnostics;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    public class ServiceAuthorizeAttribute : Attribute, IOperationBehavior
    {
        private string m_functionKey;
        private string m_functionPointKey;

        public ServiceAuthorizeAttribute(string functionKey) 
        {
            m_functionKey = functionKey;
        }

        public ServiceAuthorizeAttribute(string functionKey, string functionPointKey)
        {
            m_functionKey = functionKey;
            m_functionPointKey = functionPointKey;
        }

        public void AddBindingParameters(OperationDescription operationDescription, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation)
        {
        }

        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {
            IOperationInvoker originalInvoker = dispatchOperation.Invoker;
            dispatchOperation.Invoker = new ServiceAuthorizeInvoker(m_functionKey, m_functionPointKey, originalInvoker);
        }

        public void Validate(OperationDescription operationDescription)
        {
        }
    }

    internal class ServiceAuthorizeInvoker : IOperationInvoker
    {
        private string m_functionKey;
        private string m_functionPointKey;
        private IOperationInvoker m_originalInvoker;

        public ServiceAuthorizeInvoker(string functionKey, string functionPointKey, IOperationInvoker originalInvoker)
        {
            Debug.Assert(originalInvoker != null);
            m_functionKey = functionKey;
            m_functionPointKey = functionPointKey;
            m_originalInvoker = originalInvoker;
        }

        #region IOperationInvoker Members

        public object[] AllocateInputs()
        {
            return m_originalInvoker.AllocateInputs();
        }

        public object Invoke(object instance, object[] inputs, out object[] outputs)
        {
            // authorization here
            throw new NotImplementedException();
        }

        public IAsyncResult InvokeBegin(object instance, object[] inputs, AsyncCallback callback, object state)
        {
            // authorization here
            throw new NotImplementedException();
        }

        public object InvokeEnd(object instance, out object[] outputs, IAsyncResult result)
        {
            return m_originalInvoker.InvokeEnd(instance, out outputs, result);
        }

        public bool IsSynchronous
        {
            get 
            {
                return m_originalInvoker.IsSynchronous;
            }
        }

        #endregion
    }
}
