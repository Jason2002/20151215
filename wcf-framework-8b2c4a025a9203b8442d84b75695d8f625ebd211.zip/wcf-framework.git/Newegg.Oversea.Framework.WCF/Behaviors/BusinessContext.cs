﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    /// <summary>
    /// Provide context information for BizProcess layer.
    /// </summary>
    public class BusinessContext
    {
        [ThreadStatic]
        private static BusinessContextData m_current;

        public static BusinessContextData Current
        {
            get { return m_current; }
            set { m_current = value; }
        }
    }
}
