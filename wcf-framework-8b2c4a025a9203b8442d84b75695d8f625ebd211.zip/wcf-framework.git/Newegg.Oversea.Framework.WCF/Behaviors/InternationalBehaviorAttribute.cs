using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{

    /// <summary>
    /// This behavior used to hijack the incomming data contract, 
    /// and set the locale for current call thread.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class InternationalBehaviorAttribute: Attribute, IServiceBehavior
    {
        #region IServiceBehavior Members

        public void AddBindingParameters(ServiceDescription serviceDescription, System.ServiceModel.ServiceHostBase serviceHostBase, System.Collections.ObjectModel.Collection<ServiceEndpoint> endpoints, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, System.ServiceModel.ServiceHostBase serviceHostBase)
        {
            foreach (ChannelDispatcher channelDispatch in serviceHostBase.ChannelDispatchers)
            {
                foreach (EndpointDispatcher endpointDispatch in channelDispatch.Endpoints)
                {
                    foreach (DispatchOperation op in endpointDispatch.DispatchRuntime.Operations)
                    {
                        op.ParameterInspectors.Add(new InternationalInspector());
                    }
                }
            }
        }

        public void Validate(ServiceDescription serviceDescription, System.ServiceModel.ServiceHostBase serviceHostBase)
        {
        }

        #endregion
    }


}
