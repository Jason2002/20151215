﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    [Serializable]
    public class BusinessContextData
    {    
        public string From { get; set; }
        
        public string FromSystem { get; set; }

        public string To { get; set; }

        public string ToSystem { get; set; }

        public string TransactionCode { get; set; }

        public string CompanyCode { get; set; }
        
        public string CountryCode { get; set; }
        
        public string Language { get; set; }

        public string OperationUserFullName { get; set; }

        public string OperationUserLoginName { get; set; }

        public string OperationUserSourceDirectoryKey { get; set; }

        public string OperationUserUniqueUserName { get; set; }
       
        public string StoreCompanyCode { get; set; }

        public string TimeZone { get; set; }

        public string Tag { get; set; }

        public string Version { get; set; }
    }
}
