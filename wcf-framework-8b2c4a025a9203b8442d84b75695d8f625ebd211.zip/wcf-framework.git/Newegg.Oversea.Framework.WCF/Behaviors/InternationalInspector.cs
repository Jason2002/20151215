using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Dispatcher;
using Newegg.Oversea.Framework.WCF.Contracts;


namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    public class InternationalInspector : IParameterInspector
    {
        public InternationalInspector()
        {
        }

        #region IParameterInspector Members

        public void AfterCall(string operationName, object[] outputs, object returnValue, object correlationState)
        {
            //
        }

        public object BeforeCall(string operationName, object[] inputs)
        {
            if (inputs != null)
            {
                for (int i = 0; i < inputs.Length; i++)
                {
                    DefaultDataContract dataContract = inputs[i] as DefaultDataContract;
                    if (dataContract != null)
                    {
                        if (dataContract.Header != null)
                        {
                            this.GlobalizeCurrentThread(dataContract.Header.Language, dataContract.Header.TimeZone);
                        }
                    }
                    else
                    {
                        DefaultQueryContract queryContract = inputs[i] as DefaultQueryContract;
                        if (queryContract != null && queryContract.Header != null)
                        {
                            this.GlobalizeCurrentThread(queryContract.Header.Language, queryContract.Header.TimeZone);
                        }
                    }
                }
            }
            
            return null;
        }


        #endregion

        private void GlobalizeCurrentThread(string language, string timeZone)
        {
            try
            {
                System.Globalization.CultureInfo requestCulture
                    = new System.Globalization.CultureInfo(language);

                System.Threading.Thread.CurrentThread.CurrentCulture = requestCulture;
                System.Threading.Thread.CurrentThread.CurrentUICulture = requestCulture;
            }
            catch { /*When exception, do nothing means using default.*/ }
        }
    } 
}
