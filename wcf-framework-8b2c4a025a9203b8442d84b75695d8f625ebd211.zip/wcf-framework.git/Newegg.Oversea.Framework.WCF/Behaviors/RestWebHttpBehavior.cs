﻿using System;
using System.Text;
using System.Collections.Generic;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Configuration;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Text.RegularExpressions;
using Newegg.Oversea.Framework.WCF.HelpPage;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    public class RestWebHttpBehavior : IEndpointBehavior
    {
        #region IEndpointBehavior Members

        public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {

        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {

        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            endpointDispatcher.DispatchRuntime.OperationSelector = new RestOperationSelector(endpoint);
            endpointDispatcher.DispatchRuntime.MessageInspectors.Insert(0, new RestServiceMessageInspector());
            HelpPageService service = new HelpPageService(endpoint);
            DispatchOperation operationDispatcher = new DispatchOperation(endpointDispatcher.DispatchRuntime, "HelpPage", null, null);
            operationDispatcher.Formatter = new PassthroughMessageFormatter();
            operationDispatcher.Invoker = new HelpPageInvoker(service);
            operationDispatcher.SerializeReply = false;
            operationDispatcher.DeserializeRequest = false;
            endpointDispatcher.DispatchRuntime.Operations.Add(operationDispatcher);
        }

        public void Validate(ServiceEndpoint endpoint)
        {

        }

        #endregion
    }

    public class RestServiceMessageInspector : IDispatchMessageInspector
    {
        private const string ACCEPT_TYPE = "Portal_Accept";
        private const string LANGUAGE_CODE = "Portal_Language";
        private const string X_ACCEPT_LANGUAGE_OVERRIDE = "X-Accept-Language-Override";

        #region IDispatchMessageInspector Members

        public object AfterReceiveRequest(ref Message request, System.ServiceModel.IClientChannel channel, System.ServiceModel.InstanceContext instanceContext)
        {
            if (WebOperationContext.Current.IncomingRequest.Method.ToLower() == "get")
            {
                var type = GetQueryStringValue(WebOperationContext.Current.IncomingRequest, ACCEPT_TYPE);
                if (type != null && type.Length != 0)
                {
                    WebOperationContext.Current.IncomingRequest.Headers["Accept"] = type;
                }
                var languageCode = GetQueryStringValue(WebOperationContext.Current.IncomingRequest, LANGUAGE_CODE);
                if (languageCode != null && languageCode.Length != 0)
                {
                    WebOperationContext.Current.IncomingRequest.Headers[X_ACCEPT_LANGUAGE_OVERRIDE] = languageCode;
                }
            }
            return null;
        }

        private string GetQueryStringValue(IncomingWebRequestContext context,string key)
        {
            try
            {
                var queryStrings = context.UriTemplateMatch.QueryParameters;
                return queryStrings[key];
            }
            catch
            {
                return null;
            }
        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
            HttpResponseMessageProperty response = reply.Properties[HttpResponseMessageProperty.Name] as HttpResponseMessageProperty;
            response.Headers["Cache-Control"] = "No-Cache";
        }

        #endregion
    }

    public class RestWebHttpBehaviorExtensionElement : BehaviorExtensionElement
    {
        protected override object CreateBehavior()
        {
            return new RestWebHttpBehavior();
        }

        public override Type BehaviorType
        {
            get
            {
                return typeof(RestWebHttpBehavior);
            }
        }
    }

    public class RestOperationSelector : IDispatchOperationSelector
    {
        private const string COSNT_HEADER_METHOD = "X-HTTP-Method-Override";
        private const string COSNT_HELP_URL = "HelpPage";
        private ServiceEndpoint m_endpoint;

        public RestOperationSelector(ServiceEndpoint endpoint)
        {
            m_endpoint = endpoint;
        }
        #region IDispatchOperationSelector Members

        public string SelectOperation(ref System.ServiceModel.Channels.Message message)
        {
            HttpRequestMessageProperty httpRequest = message.Properties[HttpRequestMessageProperty.Name] as HttpRequestMessageProperty;

            if (httpRequest != null)
            {
                string methodName = httpRequest.Headers[COSNT_HEADER_METHOD];
                if (!string.IsNullOrEmpty(methodName) && httpRequest.Method.ToLower() != methodName.ToLower())
                {
                    httpRequest.Method = methodName;
                }
            }
            if (message.Headers.To != null && message.Headers.To.Segments != null)
            {
                if (message.Headers.To.Segments[message.Headers.To.Segments.Length - 1].Equals(COSNT_HELP_URL, StringComparison.InvariantCultureIgnoreCase))
                {
                    return COSNT_HELP_URL;
                }
            }
            string method = new WebHttpDispatchOperationSelector(m_endpoint).SelectOperation(ref message);
            if (!string.IsNullOrEmpty(method))
            {
                WebCacheAttribute webCache = null;
                foreach(OperationDescription item in m_endpoint.Contract.Operations)
                {
                    if (item.Name.Equals(method))
                    {
                        webCache = item.Behaviors.Find<WebCacheAttribute>();
                        break;
                    }
                }
            }
            else
            {
                return COSNT_HELP_URL;
            }
            return method;
        }

        #endregion
    }

    [AttributeUsage(AttributeTargets.Method)]
    public class WebCacheAttribute : Attribute, IOperationBehavior
    {

        #region IOperationBehavior Members

        public void AddBindingParameters(OperationDescription operationDescription, BindingParameterCollection bindingParameters)
        {

        }

        public void ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation)
        {
 
        }

        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {

        }

        public void Validate(OperationDescription operationDescription)
        {

        }

        #endregion
    }
}
