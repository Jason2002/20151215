﻿using System;
using System.Net;
using System.Xml;
using System.Threading;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Web;

using Newegg.Oversea.Framework.ExceptionHandler;
using Newegg.Oversea.Framework.WCF.Exceptions;

namespace Newegg.Oversea.Framework.WCF.Behaviors
{
    public class RestServiceAttribute : Attribute, IServiceBehavior
    {
        public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
        { }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            foreach (ChannelDispatcher channelDispatcher in serviceHostBase.ChannelDispatchers)
            {
                foreach (EndpointDispatcher endpointDispatcher in channelDispatcher.Endpoints)
                {
                    foreach (DispatchOperation dispatchOperation in endpointDispatcher.DispatchRuntime.Operations)
                    {
                        dispatchOperation.ParameterInspectors.Add(new RestServiceParameterInspector());
                    }
                }

                channelDispatcher.ErrorHandlers.Add(new RestServiceErrorHandler());
            }
        }

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        { }
    }

    public class RestServiceErrorHandler : IErrorHandler
    {
        public bool HandleError(Exception error)
        {
           // object[] requestParams = OperationContext.Current.RequestContext.RequestMessage.Properties["_RequestParams_"] as object[];
            
            object requestParams;

            OperationContext.Current.OutgoingMessageProperties.TryGetValue("_RequestParams_", out requestParams);

            ExceptionHelper.HandleException(error, requestParams as object[]);

            return true;
        }

        public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
        {
            HttpStatusCode statusCode;
            // Get Http Status Code
            if (error is SecurityAccessDeniedException)
            {
                statusCode = HttpStatusCode.Unauthorized;
            }
            else if (error is ServerTooBusyException)
            {
                statusCode = HttpStatusCode.ServiceUnavailable;
            }
            else if (error is BusinessException)
            {
                statusCode = HttpStatusCode.OK;
            }
            else
            {
                statusCode = HttpStatusCode.InternalServerError;
            }

            RestServiceError errorData = new RestServiceError()
            {
                StatusCode = (int)statusCode,
                StatusDescription = HttpWorkerRequest.GetStatusDescription((int)statusCode),
                Faults = new List<Error>()
            };

            bool includeExceptionDetail = false;
            OperationContext operationContext = OperationContext.Current;
            WebOperationContext webContext = WebOperationContext.Current;
            if (operationContext != null)
            {
                includeExceptionDetail = operationContext.EndpointDispatcher.ChannelDispatcher.IncludeExceptionDetailInFaults;
            }

            if (error is BatchBusinessException)
            {
                BatchBusinessException ex = error as BatchBusinessException;

                if (ex.Errors != null)
                {
                    foreach (BusinessError item in ex.Errors)
                    {
                        errorData.Faults.Add(new Error()
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorDescription = item.ErrorDescription
                        });
                    }
                }
            }
            else if (error is BusinessException)
            {
                BusinessException ex = error as BusinessException;

                errorData.Faults.Add(new Error()
                {
                    ErrorCode = ex.ErrorCode,
                    ErrorDescription = ex.ErrorDescription
                });
            }
            else
            {
                errorData.Faults.Add(new Error()
                {
                    ErrorCode = "00000",
                   // ErrorDescription = includeExceptionDetail ? error.ToString() : GetSystemExceptionMessage()
                    ErrorDescription =  error.ToString()
                });
            }

            if (version == MessageVersion.None)
            {
                WebMessageFormat messageFormat = WebOperationContext.Current.OutgoingResponse.Format ?? WebMessageFormat.Xml;
                WebContentFormat contentFormat = WebContentFormat.Xml;
                string contentType = "text/xml";

                if (messageFormat == WebMessageFormat.Json)
                {
                    contentFormat = WebContentFormat.Json;
                    contentType = "application/json";
                }

                WebBodyFormatMessageProperty bodyFormat = new WebBodyFormatMessageProperty(contentFormat);

                HttpResponseMessageProperty responseMessage = new HttpResponseMessageProperty();
                responseMessage.StatusCode = HttpStatusCode.OK;
                responseMessage.StatusDescription = HttpWorkerRequest.GetStatusDescription((int)responseMessage.StatusCode);
                responseMessage.Headers[HttpResponseHeader.ContentType] = contentType;
                responseMessage.Headers["X-HTTP-StatusCode-Override"] = "500";

                fault = Message.CreateMessage(MessageVersion.None, null, new RestServiceErrorWriter() { Error = errorData, Format = contentFormat });
                fault.Properties[WebBodyFormatMessageProperty.Name] = bodyFormat;
                fault.Properties[HttpResponseMessageProperty.Name] = responseMessage;
            }
        }

        private string GetSystemExceptionMessage()
        {
            switch (Thread.CurrentThread.CurrentCulture.Name)
            {
                case "zh-CN":
                    return "当前应用程序发生意外的错误, 已经将相关错误信息通知到系统管理员.";
                case "zh-TW":
                    return "當前應用程序發生意外的錯誤, 已經將相關錯誤信息通知到系統管理員.";
                default:
                    return "An unexpected error has occurred, and the system administrator has been notified.";
            }
        }

        class RestServiceErrorWriter : BodyWriter
        {
            public RestServiceErrorWriter()
                : base(true)
            { }

            public RestServiceError Error { get; set; }

            public WebContentFormat Format { get; set; }

            protected override BodyWriter OnCreateBufferedCopy(int maxBufferSize)
            {
                return base.OnCreateBufferedCopy(maxBufferSize);
            }

            protected override void OnWriteBodyContents(XmlDictionaryWriter writer)
            {
                if (Format == WebContentFormat.Json)
                {
                    new DataContractJsonSerializer(typeof(RestServiceError)).WriteObject(writer, Error);
                }
                else
                {
                    new DataContractSerializer(typeof(RestServiceError)).WriteObject(writer, Error);
                }
            }
        }
    }

    public class RestServiceParameterInspector : IParameterInspector
    {
        public object BeforeCall(string operationName, object[] inputs)
        {
            OperationContext operationContext = OperationContext.Current;
            if (operationContext != null)
            {
              // operationContext.RequestContext.RequestMessage.Properties["_RequestParams_"] = inputs;

                operationContext.OutgoingMessageProperties.Add("_RequestParams_", inputs);
            }

            WebOperationContext webOperationContext = WebOperationContext.Current;
            if (webOperationContext != null)
            {
                string language = GetAcceptLanguage(webOperationContext);

                System.Globalization.CultureInfo requestCulture = new System.Globalization.CultureInfo(language);

                System.Threading.Thread.CurrentThread.CurrentCulture = requestCulture;
                System.Threading.Thread.CurrentThread.CurrentUICulture = requestCulture;
            }

            return null;
        }

        public void AfterCall(string operationName, object[] outputs, object returnValue, object correlationState)
        {
            WebOperationContext context = WebOperationContext.Current;

            string cacheControl = context.IncomingRequest.Headers["Cache-Control"];
            if (cacheControl != null && cacheControl.ToLower() == "no-cache")
            {
                context.OutgoingResponse.Headers["Cache-Control"] = "No-Cache";
            }
        }

        private string GetAcceptLanguage(WebOperationContext webOperationContext)
        {
            string languageValue = webOperationContext.IncomingRequest.Headers["X-Accept-Language-Override"];
            if (languageValue == null || languageValue.Trim() == String.Empty)
            {
                languageValue = webOperationContext.IncomingRequest.Headers["Accept-Language"];
            }

            if (languageValue != null)
            {
                string[] array = languageValue.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = array.Length; i > 0; i--)
                {
                    string str = array[i - 1].ToLower();
                    switch (str)
                    {
                        case "en":
                        case "en-us":
                            return "en-US";
                        case "zh":
                        case "zh-chs":
                        case "zh-cn":
                            return "zh-CN";
                        case "zh-cht":
                        case "zh-tw":
                            return "zh-TW";
                    }
                }
            }

            return "en-US";
        }
    }


    [DataContract(Name = "ServiceError", Namespace = "")]
    public class RestServiceError
    {
        [DataMember]
        public int StatusCode { get; set; }

        [DataMember]
        public string StatusDescription { get; set; }

        [DataMember]
        public List<Error> Faults { get; set; }

        public RestServiceError()
        {
            Faults = new List<Error>();
        }
    }

    [DataContract(Name = "Error", Namespace = "")]
    public class Error
    {
        [DataMember]
        public string ErrorCode { get; set; }

        [DataMember]
        public string ErrorDescription { get; set; }
    }

}
