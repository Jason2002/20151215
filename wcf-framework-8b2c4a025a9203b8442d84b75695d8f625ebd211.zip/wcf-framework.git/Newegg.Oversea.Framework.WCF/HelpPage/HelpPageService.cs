﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;

namespace Newegg.Oversea.Framework.WCF.HelpPage
{
    internal class HelpPageService
    {
        ServiceEndpoint endpoint;
        public HelpPageService(ServiceEndpoint endpoint)
        {
            this.endpoint = endpoint;
        }
        public Message Process(Message input)
        {
            return new HelpPageMessage(this.endpoint);
        }
    }
}
