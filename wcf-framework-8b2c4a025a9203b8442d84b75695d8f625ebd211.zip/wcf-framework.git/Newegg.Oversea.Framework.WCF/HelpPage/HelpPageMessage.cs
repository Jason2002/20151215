﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Xml;
using System.ComponentModel;
using System.Reflection;
using System.Net;
using System.ServiceModel.Web;
using System.Globalization;

namespace Newegg.Oversea.Framework.WCF.HelpPage
{
    internal class HelpPageMessage : Message
    {
        MessageHeaders headers;
        MessageProperties properties;
        ServiceEndpoint endpoint;

        public HelpPageMessage(ServiceEndpoint endpoint)
        {
            this.headers = new MessageHeaders(MessageVersion.None);
            this.properties = InitializeMessageProperties();
            this.endpoint = endpoint;
        }

        public override MessageHeaders Headers
        {
            get { return this.headers; }
        }

        public override MessageProperties Properties
        {
            get { return this.properties; }
        }

        public override MessageVersion Version
        {
            get { return MessageVersion.None; }
        }

        protected override void OnWriteBodyContents(XmlDictionaryWriter writer)
        {
            writer.WriteStartElement("ServiceInfo");
            WriteEndpointDetails(writer);
            WriteContractOperations(writer);
            writer.WriteEndElement();//ServiceInfo
        }

        private void WriteEndpointDetails(XmlDictionaryWriter writer)
        {
            writer.WriteElementString("Address", this.endpoint.Address.ToString());
            writer.WriteElementString("Contract", this.endpoint.Contract.ContractType.FullName);
            writer.WriteElementString("Description", GetContractDescription(this.endpoint.Contract));
        }

        private string GetContractDescription(ContractDescription contact)
        {
            DescriptionAttribute[] description = (DescriptionAttribute[])contact.ContractType.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (description == null || description.Length == 0 || string.IsNullOrEmpty(description[0].Description))
            {
                return "Service " + contact.ContractType.Name;
            }
            else
            {
                return description[0].Description;
            }
        }

        private void WriteContractOperations(XmlDictionaryWriter writer)
        {
            writer.WriteStartElement("Operations");
            foreach (OperationDescription operation in this.endpoint.Contract.Operations)
            {
                writer.WriteStartElement("OperationInfo");
                writer.WriteElementString("Name", operation.Name);
                writer.WriteElementString("Signature", GetOperationSignature(operation));
                writer.WriteElementString("Description", GetOperationDescription(operation));
                writer.WriteElementString("Uri", GetWebUriTemplate(operation));
                writer.WriteElementString("Method", GetWebMethod(operation));
                writer.WriteElementString("CallSample", this.endpoint.Address + "/help/operations/" + operation.Name);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        private string GetWebMethod(OperationDescription od)
        {
            WebGetAttribute webGetAttribute = od.Behaviors.Find<WebGetAttribute>();
            WebInvokeAttribute webInvokeAttribute = od.Behaviors.Find<WebInvokeAttribute>();
            if (webGetAttribute != null)
            {
                return "GET";
            }
            if (webInvokeAttribute != null)
            {
                return webInvokeAttribute.Method ?? "POST";
            }
            return "POST";
        }

        private string GetWebUriTemplate(OperationDescription od)
        {
            WebGetAttribute webGetAttribute = od.Behaviors.Find<WebGetAttribute>();
            WebInvokeAttribute webInvokeAttribute = od.Behaviors.Find<WebInvokeAttribute>();
            if (webGetAttribute != null)
            {
                return webGetAttribute.UriTemplate;
            }
            if (webInvokeAttribute != null)
            {
                return webInvokeAttribute.UriTemplate;
            }
            return string.Empty;
        }

        private string GetOperationDescription(OperationDescription operation)
        {
            if (operation.SyncMethod != null)
            {
                DescriptionAttribute[] description = (DescriptionAttribute[])operation.SyncMethod.GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (description == null || description.Length == 0 || string.IsNullOrEmpty(description[0].Description))
                {
                    return "Operation " + operation.SyncMethod.Name;
                }
                else
                {
                    return description[0].Description;
                }
            }
            else
            {
                return string.Empty;
            }
        }

        private string GetOperationSignature(OperationDescription operation)
        {
            StringBuilder sb = new StringBuilder();
            if (operation.SyncMethod != null)
            {
                MethodInfo method = operation.SyncMethod;
                if (method.ReturnType == null || method.ReturnType == typeof(void))
                {
                    sb.Append("void");
                }
                else
                {
                    sb.Append(method.ReturnType.Name);
                }

                sb.Append(' ');
                sb.Append(method.Name);
                sb.Append('(');
                ParameterInfo[] parameters = method.GetParameters();
                for (int i = 0; i < parameters.Length; i++)
                {
                    if (i > 0)
                    {
                        sb.Append(", ");
                    }

                    sb.AppendFormat("{0} {1}", parameters[i].ParameterType.Name, parameters[i].Name);
                }

                sb.Append(')');
            }
            else
            {
                sb.Append("No Signature for this method");
            }

            return sb.ToString();
        }

        private MessageProperties InitializeMessageProperties()
        {
            MessageProperties result = new MessageProperties();
            HttpResponseMessageProperty httpResponse = new HttpResponseMessageProperty();
            httpResponse.StatusCode = HttpStatusCode.OK;
            httpResponse.Headers[HttpResponseHeader.ContentType] = "application/xml";
            result.Add(HttpResponseMessageProperty.Name, httpResponse);
            return result;
        }
    }
}
