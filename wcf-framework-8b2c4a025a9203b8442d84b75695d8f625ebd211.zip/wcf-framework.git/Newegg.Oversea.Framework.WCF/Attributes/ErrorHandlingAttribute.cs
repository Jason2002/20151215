using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

using PostSharp.Aspects;
using Newegg.Oversea.Framework.WCF.Contracts;
using Newegg.Oversea.Framework.WCF.Exceptions;

namespace Newegg.Oversea.Framework.ExceptionHandler
{
    [Serializable]
    [AttributeUsage(AttributeTargets.Method, AllowMultiple=false)]
    public class ErrorHandlingAttribute : OnMethodBoundaryAspect
    {
        private string m_Category;

        public ErrorHandlingAttribute()
        {
        }

        public ErrorHandlingAttribute(string category)
        {
            m_Category = category;
        }

        public override void OnException(MethodExecutionArgs eventArgs)
        {
            eventArgs.FlowBehavior = FlowBehavior.Return;

            string logID = ExceptionHelper.HandleException(eventArgs.Exception, m_Category, eventArgs.Arguments.ToArray());

            MessageFault fault = new MessageFault();
            fault.ErrorCode = logID;
            fault.ErrorDetail = eventArgs.Exception.ToString();
            fault.ErrorDescription = ExceptionHelper.GetErrorDescription(eventArgs.Exception);

            MethodInfo methodInfo = eventArgs.Method as MethodInfo;

            if (methodInfo.ReturnType.IsSubclassOf(typeof(DefaultDataContract))
              || methodInfo.ReturnType == typeof(DefaultDataContract)
              || methodInfo.ReturnType.Name == ("QueryResultContract`1"))
              {               
                MessageFaultCollection faults = new MessageFaultCollection();
                faults.Add(fault);

                object o = Activator.CreateInstance(methodInfo.ReturnType);
                if (o != null)
                {
                    o.GetType().GetProperty("Faults").SetValue(o, faults, null);
                }

                eventArgs.ReturnValue = o;
            }
        }



    }
}
