﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Newegg.Oversea.Framework.WCF.Exceptions
{
    [Serializable]
    public class BatchBusinessException : Exception
    {
        public IEnumerable<BusinessError> Errors { get; set; }

        public BatchBusinessException()
            : base()
        { }

        public BatchBusinessException(IEnumerable<BusinessError> errors)
            : base()
        {
            this.Errors = errors;
        }

        public BatchBusinessException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this.Errors = info.GetValue("m_errors", typeof(IEnumerable<BusinessError>)) as IEnumerable<BusinessError>;
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("m_errors", this.Errors);
        }
    }

    [Serializable]
    public class BusinessError
    {
        public string ErrorCode { get; set; }

        public string ErrorDescription { get; set; }
    }
}
