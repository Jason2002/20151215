﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.Framework.Tools.Serialization;

namespace Newegg.Oversea.Framework.WCF.Exceptions
{
    public class CommonUtility
    {
        public static string GetMethodArgumentValue(object[] arguments)
        {
            if (arguments == null || arguments.Length == 0)
            {
                return "N/A";
            }
            string result = string.Empty;
            for (int i = 0; i < arguments.Length; i++)
            {
                if (arguments[i] != null)
                {
                    if (arguments[i] is string)
                    {
                        result += Convert.ToString(arguments[i]);
                    }
                    else if (arguments[i].GetType().IsPrimitive)
                    {
                        result += arguments[i].ToString();
                    }
                    else
                    {
                        result += SerializeHelper.XmlSerializer(arguments[i]);
                    }
                    if (i != arguments.Length - 1)
                    {
                        result += ", ";
                    }
                }
            }
            return result;
        }


        public static string GetMethodArgumentType(object[] arguments)
        {
            if (arguments == null || arguments.Length == 0)
            {
                return "N/A";
            }
            string result = string.Empty;

            for (int i = 0; i < arguments.Length; i++)
            {
                if (arguments[i] == null)
                {
                    result += "NULL";
                }
                else
                {
                    result += arguments[i].GetType().ToString();
                }

                if (i != arguments.Length - 1)
                {
                    result += ", ";
                }
            }
            return result;
        }
    }
}
