using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Newegg.Oversea.Framework.WCF.Exceptions
{
    [Serializable]
    public class BusinessException : ApplicationException
    {
        private bool m_needLog = false;

        public bool NeedLog
        {
            get
            {
                return m_needLog;
            }
            set
            {
                m_needLog = value;   
            }
        }

        private string m_ErrorCode;

        public string ErrorCode
        {
            get { return m_ErrorCode; }
            set { m_ErrorCode = value; }
        }

        private string m_ErrorDescription;

        public string ErrorDescription
        {
            get { return m_ErrorDescription; }
            set { m_ErrorDescription = value; }
        }

        public BusinessException()
            : base()
        {
        }

        public BusinessException(string message)
            : this("0", message, false)
        {

        }

        public BusinessException(string errorCode, string message)
            : this(errorCode, message, false)
        {
        }

        public BusinessException(string errorCode, string message, bool needLog)
            : base(message)
        {
            m_ErrorCode = errorCode;            
            m_ErrorDescription = message;
            m_needLog = needLog;
        }

        public BusinessException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this.NeedLog = info.GetBoolean("NeedLog");
            this.ErrorCode = info.GetString("ErrorCode");
            this.ErrorDescription = info.GetString("ErrorDescription");

        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("NeedLog", NeedLog);
            info.AddValue("ErrorCode", ErrorCode);
            info.AddValue("ErrorDescription", ErrorDescription);
            base.GetObjectData(info, context);
        }

        public BusinessException(string message, Exception innerException)
            : this("0", message, innerException, false)
        {
        }

        public BusinessException(string errorCode, string message, Exception innerException)
            : this(errorCode, message, innerException, false)
        {
        }    
        
        public BusinessException(string message, Exception innerException, bool needLog)
            : this("0", message, innerException, needLog)
        {
        }

        public BusinessException(string errorCode, string message, Exception innerException, bool needLog)
            : base(message, innerException)
        {
            m_ErrorCode = message;
            m_ErrorDescription = message;
            m_needLog = needLog;
        }
    }
}
