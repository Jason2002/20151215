﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Exceptions
{
    [Serializable]
    public class ServiceException : ApplicationException
    {
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string ErrorDetail { get; set; }
        public bool IsBizException { get; set; }

        public ServiceException(string errorDescription, string errorDetail)
            : this("0", errorDescription, errorDetail, true)
        { }

        public ServiceException(string errorCode, string errorDescription, string errorDetail)
            : this(errorCode, errorDescription, errorDetail, false)
        { }

        public ServiceException(string errorCode, string errorDescription, string errorDetail, bool isBizException)
            : base(errorDescription)
        {
            this.ErrorCode = errorCode;
            this.ErrorDescription = errorDescription;
            this.ErrorDetail = errorDetail;
            this.IsBizException = isBizException;
        }

        public ServiceException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this.ErrorCode = info.GetString("m_errorCode");
            this.ErrorDescription = info.GetString("m_errorDescription");
            this.ErrorDetail = info.GetString("m_errorDetail");
            this.IsBizException = info.GetBoolean("m_isBizException");
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("m_errorCode", this.ErrorCode);
            info.AddValue("m_errorDescription", this.ErrorDescription);
            info.AddValue("m_errorDetail", this.ErrorDetail);
            info.AddValue("m_isBizException", this.IsBizException);
        }
    }

}
