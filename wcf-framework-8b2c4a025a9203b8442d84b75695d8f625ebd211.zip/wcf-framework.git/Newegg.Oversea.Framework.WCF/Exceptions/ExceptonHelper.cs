using System;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using Newegg.Framework.Tools.Log;


namespace Newegg.Oversea.Framework.WCF.Exceptions
{
    public static class ExceptionHelper
    {
        private const string c_DefultCategory = "ExceptionLog";

        public static string HandleException(Exception ex)
        {
            return HandleException(ex, null, c_DefultCategory, null);
        }

        public static string HandleException(Exception ex, object[] methodArguments)
        {
            return HandleException(ex, null, c_DefultCategory, methodArguments);
        }

        public static string HandleException(Exception ex, string message, object[] methodArguments)
        {
            return HandleException(ex, message, c_DefultCategory, methodArguments);
        }

        public static string HandleException(Exception ex, string message, string category, object[] methodArguments)
        {
            return HandleException(ex, message, category, methodArguments, null);
        }

        public static string HandleException(Exception ex, string message, string category, object[] methodArguments, string referenceKey)
        {
            List<ExtendProperty> list = new List<ExtendProperty>();
            if (message != null)
            {
                list.Add(new ExtendProperty { Key = "Error Message", Value = message });
            }
            list.Add(new ExtendProperty { Key = "Method Arguments Type", Value = CommonUtility.GetMethodArgumentType(methodArguments) });
            list.Add(new ExtendProperty { Key = "Method Arguments Value", Value = CommonUtility.GetMethodArgumentValue(methodArguments) });
            return HandleException(ex, category, list, referenceKey);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="extendedProperties"></param>
        /// <param name="category"></param>
        /// <returns>Error ID</returns>
        public static string HandleException(Exception ex, string category, List<ExtendProperty> extendedProperties)
        {
            return HandleException(ex, category, extendedProperties, null);
        }


        public static string HandleException(Exception ex, string category, List<ExtendProperty> extendedProperties, string referenceKey)
        {
            string errorID = null;
            BusinessException bizEx = ex as BusinessException;
            if (bizEx == null || bizEx.NeedLog)
            {
                if (string.IsNullOrEmpty(category))
                {
                    category = c_DefultCategory;
                }
                LogEntry log = new LogEntry();
                log.CategoryName = category;
                log.ExtendedProperties = extendedProperties;
                log.Content = GetExceptionDetail(ex);
                log.ReferenceKey = referenceKey;
                log.LogType = "E";
                errorID = Logger.WriteLog(log);
            }

            if (bizEx != null)
            {
                errorID = bizEx.ErrorCode;
            }

            return errorID;
        }


        private static string GetExceptionDetail(Exception ex)
        {
            if (ex == null) 
                return "";
            StringBuilder sb = new StringBuilder(1000);            
            if (ex.Message != null)
            {
                sb.AppendFormat("Message: {0}.\r\n", ex.Message);
            }
            sb.AppendFormat("Exception Type: {0}.\r\n", ex.GetType().FullName);
            if (ex.Source != null)
            {
                sb.AppendFormat("Source: {0}.\r\n", ex.Source);
            }
            if (ex.TargetSite != null)
            {
                sb.AppendFormat("Module Name: {0}.\r\n", ex.TargetSite.Module.FullyQualifiedName);
            }
            if (ex.StackTrace != null)
            {
                sb.AppendFormat("Stack Trace: {0}.\r\n", ex.StackTrace);
            }
            if (ex.InnerException != null)
            {
                AppendInnerException(ex.InnerException, sb);
            }

            return sb.ToString();
        }

        private static void AppendInnerException(Exception ex, StringBuilder sb)
        {
            sb.Append("\r\n");
            sb.AppendFormat("Inner Exception:\r\n");
            sb.AppendFormat("\tMessage: {0}. \r\n", ex.Message);
            sb.AppendFormat("\tException Type: {0}.\r\n", ex.GetType().FullName);
            if (ex.Source != null)
            {
                sb.AppendFormat("\tSource: {0}.\r\n", ex.Source);
            }
            if (ex.StackTrace != null)
            {
                sb.AppendFormat("\tStack Trace: {0}.\r\n", ex.StackTrace);
            }
            if (ex.InnerException != null)
            {
                AppendInnerException(ex.InnerException, sb);
            }
        }

        public static string GetErrorDescription(Exception ex)
        {
            BusinessException bizEx = ex as BusinessException;
            if (bizEx == null)
            {
                switch (Thread.CurrentThread.CurrentCulture.Name)
                {
                    case "zh-CN":
                        return "��ǰӦ�ó���������Ĵ���, �Ѿ�����ش�����Ϣ֪ͨ��ϵͳ����Ա.";
                    case "zh-TW":
                        return "��ǰ���ó���l��������e�`, �ѽ������P�e�`��Ϣ֪ͨ��ϵ�y����T.";
                    default:
                        return "An unexpected error has occurred, and the system administrator has been notified.";
                }
            }
            else
            {
                return bizEx.ErrorDescription;
            }
        }

    }
}
