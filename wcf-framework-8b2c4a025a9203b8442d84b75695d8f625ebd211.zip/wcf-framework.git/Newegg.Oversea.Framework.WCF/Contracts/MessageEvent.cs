﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    /// <summary>
    /// the definition of message event
    /// </summary>
    [Serializable]
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class MessageEvent
    {
        /// <summary>
        /// 事件ID
        /// </summary>
        [DataMember]
        public string EventID { get; set; }

        /// <summary>
        /// 动作
        /// </summary>
        [DataMember]
        public string Action { get; set; }

        /// <summary>
        /// 时间戳
        /// </summary>
        [DataMember]
        public DateTime TimeStamp { get; set; }

        /// <summary>
        /// 处理者
        /// </summary>
        [DataMember]
        public string Processor { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [DataMember]
        public string CompanyCode { get; set; }

        /// <summary>
        /// 描述
        /// </summary> 
        [DataMember]
        public string Description { get; set; }
    }
}
