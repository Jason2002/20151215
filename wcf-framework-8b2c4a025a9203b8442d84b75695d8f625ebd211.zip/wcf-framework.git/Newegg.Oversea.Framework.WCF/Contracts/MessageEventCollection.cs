﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [System.SerializableAttribute()]
    [CollectionDataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class MessageEventCollection : KeyedCollection<string, MessageEvent>
    {
        protected override string GetKeyForItem(MessageEvent item)
        {
            return item.EventID;
        }
    }
}
