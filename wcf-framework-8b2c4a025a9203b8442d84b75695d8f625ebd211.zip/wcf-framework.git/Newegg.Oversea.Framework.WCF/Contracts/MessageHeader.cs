﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    /// <summary>
    /// 消息头
    /// </summary>
    [System.SerializableAttribute()]
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class MessageHeader
    {
        /// <summary>
        /// 命名空间,命名策略见《WCF Policy，策略2.4》
        /// </summary>
        [DataMember]
        public string NameSpace { get; set; }

        /// <summary>
        /// 动作,例如：Void,Create,Hold,Update,Batch,UnHold,Dispatch,Verify,UnVerify
        /// </summary>
        [DataMember]
        public string Action { get; set; }

        /// <summary>
        /// 版本
        /// </summary>
        [DataMember]
        public string Version { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        [DataMember]
        public string Type { get; set; }

        /// <summary>
        /// 发起者
        /// </summary>
        [DataMember]
        public string Sender { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [DataMember]
        public string CompanyCode { get; set; }

        /// <summary>
        /// 关键字
        /// </summary>
        [DataMember]
        public string Tag { get; set; }

        /// <summary>
        /// 语言,如：ENU、CH
        /// </summary>
        [DataMember]
        public string Language { get; set; }

        /// <summary>
        /// 时区
        /// </summary>
        [DataMember]
        public string TimeZone { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        [DataMember]
        public string Description { get; set; }

        /// <summary>
        /// 原始发起者
        /// </summary>
        [DataMember]
        public string OriginalSender { get; set; }

        /// <summary>
        /// 原始消息号
        /// </summary>
        [DataMember]
        public string OriginalGUID { get; set; }

        /// <summary>
        /// 返回地址
        /// </summary>
        [DataMember]
        public string CallbackAddress { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string From { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string To { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string FromSystem { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ToSystem { get; set; }

        [DataMember]
        public string CountryCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        private GlobalBusinessType m_GlobalBusinessTypeValueField = GlobalBusinessType.Listing;
        [DataMember]
        public GlobalBusinessType GlobalBusinessType
        {
            get
            {
                return m_GlobalBusinessTypeValueField;
            }
            set
            {
                m_GlobalBusinessTypeValueField = value;
            }
        }

        /// <summary>
        /// Store Company Code
        /// </summary>
        [DataMember]
        public string StoreCompanyCode { get; set; }

        [DataMember]
        public string TransactionCode { get; set; }

        [DataMember]
        public OperationUser OperationUser { get; set; }

        [DataMember]
        public string AuthToken { get; set; }
    }
}
