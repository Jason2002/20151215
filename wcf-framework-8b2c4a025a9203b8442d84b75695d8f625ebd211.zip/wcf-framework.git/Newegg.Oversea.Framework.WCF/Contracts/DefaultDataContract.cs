﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [Serializable]
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class DefaultDataContract
    {
        [DataMember]
        public MessageHeader Header { get; set; }

        [DataMember]
        public MessageEventCollection Events { get; set; }

        [DataMember]
        public MessageFaultCollection Faults { get; set; }
    }
}
