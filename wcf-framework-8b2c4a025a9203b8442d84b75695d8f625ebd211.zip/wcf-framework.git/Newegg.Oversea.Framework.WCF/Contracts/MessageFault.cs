﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [Serializable]
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class MessageFault
    {
        [DataMember]
        public string ErrorCode { get; set; }

        [DataMember]
        public string ErrorDescription { get; set; }

        [DataMember]
        public string ErrorDetail { get; set; }
    }

    [System.SerializableAttribute()]
    [CollectionDataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class MessageFaultCollection : List<MessageFault>
    {
    }
}
