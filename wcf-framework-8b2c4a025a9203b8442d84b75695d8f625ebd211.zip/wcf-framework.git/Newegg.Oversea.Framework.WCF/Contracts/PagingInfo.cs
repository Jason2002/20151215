﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    [Serializable]
    public class PagingInfo
    {
        [DataMember]
        public int? StartRowIndex { get; set; }

        [DataMember]
        public int? PageSize { get; set; }

        private string m_SortField;
        [DataMember]
        public string SortField
        {
            get { return m_SortField == null ? null : m_SortField.Trim(); }
            set { m_SortField = value; }
        }

        [DataMember]
        public int TotalCount { get; set; }

        [DataMember]
        public SortType SortType { get; set; }
    }

    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public enum SortType
    {
        [EnumMember]
        DESC,
        [EnumMember]
        ASC
    }
}
