﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [Serializable]
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class DefaultQueryContract
    {
        public DefaultQueryContract() { }

        [DataMember]
        public MessageHeader Header { get; set; }

        [DataMember]
        public PagingInfo PagingInfo { get; set; }
    }
}
