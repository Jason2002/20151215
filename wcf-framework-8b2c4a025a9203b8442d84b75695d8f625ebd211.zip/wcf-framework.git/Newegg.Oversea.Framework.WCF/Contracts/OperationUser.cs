﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    [Serializable]
    public class OperationUser
    {
        public OperationUser() { }

        public OperationUser(string displayName, string loginName,
                             string sourceDirectoryKey, string companyCode)
        {
            this.FullName = displayName;
            this.SourceDirectoryKey = sourceDirectoryKey;
            this.SourceUserName = loginName;
            this.CompanyCode = companyCode;
            this.UniqueUserName = this.LogUserName = string.Format(@"{0}\{1}\{2}[{3}]",
                FullName, SourceDirectoryKey, SourceUserName, CompanyCode);
        }

        [DataMember]
        public string FullName { get; set; }

        [DataMember]
        public string SourceDirectoryKey { get; set; }

        [DataMember]
        public string SourceUserName { get; set; }

        [DataMember]
        public string CompanyCode { get; set; }

        /// <summary>
        /// For Downward Compatible only
        /// </summary>
        [DataMember]
        public string LogUserName { get; set; }

        [DataMember]
        public string UniqueUserName { get; set; }

        public static string ParseDisplayNameFromUniqueName(string uniqueName)
        {
            if (!string.IsNullOrEmpty(uniqueName) && uniqueName.IndexOf('\\') > -1)
            {
                return uniqueName.Split('\\')[0];
            }
            return uniqueName;
        }
    }
}
