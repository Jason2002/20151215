﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    [Serializable]
    [DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public class SimpleTypeDataContract<T> : DefaultDataContract
    {
        [DataMember]
        public T Value { get; set; }
    }
}
