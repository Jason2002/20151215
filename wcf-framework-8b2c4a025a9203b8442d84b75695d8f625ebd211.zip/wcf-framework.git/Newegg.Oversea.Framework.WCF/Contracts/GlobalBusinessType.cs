﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Newegg.Oversea.Framework.WCF.Contracts
{
    /// <summary>
    /// GlobalBusinessType of Enum type
    /// </summary>
    [System.SerializableAttribute()]
    [System.Runtime.Serialization.DataContract(Namespace = "http://oversea.newegg.com/Framework/Common/Contract")]
    public enum GlobalBusinessType
    {
        [EnumMember]
        VF,
        [EnumMember]
        Normal,
        [EnumMember]
        Listing
    }
}
