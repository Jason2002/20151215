﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Configuration;
using System.Text.RegularExpressions;
using System.IO;

namespace Newegg.Oversea.Framework.WCF
{
    public class RestServiceUrlRewriter:IHttpModule
    {
        private static RewriterSection s_configSection;
        private static readonly Dictionary<Rule,Regex> s_regexItems = new Dictionary<Rule,Regex>();
        private static string s_root;

        static RestServiceUrlRewriter()
        {
            s_configSection = ConfigurationManager.GetSection("oversea/restServiceRewriter") as RewriterSection;
        }

        #region IHttpModule Members

        public void Dispose()
        {
            
        }

        public void Init(HttpApplication context)
        {
            if (s_configSection.Rules.Count > 0 && s_regexItems.Count == 0)
            {
                Regex regex = new Regex(@"\{(?<name>\w+)\}", RegexOptions.IgnoreCase);
                s_root = context.Context.Request.Url.GetLeftPart(UriPartial.Authority) +
                        (context.Context.Request.ApplicationPath == "/" ? "" : context.Context.Request.ApplicationPath);
              
                foreach (Rule rule in s_configSection.Rules)
                {
                    if (rule.RuteFormat.StartsWith("~"))
                    {
                        rule.RuteFormat = rule.RuteFormat.Replace("~", s_root);
                    }
                    s_regexItems.Add(rule,new Regex(string.Format("{0}{1}", 
                            regex.Replace(rule.RuteFormat, @"(?<key${name}>\w+)"), @"(?<param>\w+)?"),
                            RegexOptions.IgnoreCase));  
                }
            }

            context.AuthorizeRequest += new EventHandler(context_AuthorizeRequest);
        }

        void context_AuthorizeRequest(object sender, EventArgs e)
        {
            UrlRewriter(sender as HttpApplication);
        }

        protected virtual void UrlRewriter(HttpApplication context)
        {
            Match match;
            string virtualPath, args;
            foreach (KeyValuePair<Rule, Regex> item in s_regexItems)
            {
                match = item.Value.Match(context.Request.Url.OriginalString);
                if (match.Success)
                {
                    virtualPath = item.Key.MappingPath;
                    if(match.Groups.Count > 0)
                    {
                        virtualPath = string.Format(item.Key.MappingPath, GetMachItems(match));
                    }
                    args = match.Groups["param"].Value;
                    if (File.Exists(context.Server.MapPath(virtualPath)))
                    {
                        virtualPath = virtualPath.TrimEnd(new char[] { '/' });
                        context.Context.RewritePath(virtualPath, "/" + args, 
                                        context.Request.QueryString.ToString(), true);
                        break;
                    }
                }
            }
        }

        private static string[] GetMachItems(Match match)
        {
            string[] list = new string[match.Groups.Count];
            for (int index = 0; index < match.Groups.Count; index++)
            {
                list[index] = match.Groups["key" + index.ToString()].Value;
            }
            return list;
        }

        #endregion
    }

    public class RewriterSection : ConfigurationSection
    {
        [ConfigurationProperty("rules", IsRequired = true)]
        public RuleCollection Rules
        {
            get
            {
                return this["rules"] as RuleCollection;
            }
        }
    }

    public class RuleCollection : ConfigurationElementCollection
    {
        public override bool IsReadOnly()
        {
            return false;
        }

        public Rule this[int index]
        {
            get
            {
                return base.BaseGet(index) as Rule;
            }
        }

        public new Rule this[string name]
        {
            get
            {
                return base.BaseGet(name) as Rule;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new Rule();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return (element as Rule).Key;
        }
    }

    public class Rule : ConfigurationElement
    {
        private string m_key;

        public Rule():base()
        {
            m_key = Guid.NewGuid().ToString("N");
        }

        public override bool IsReadOnly()
        {
            return false;
        }

        internal string Key
        {
            get
            {
                return m_key;
            }
        }
        
        [ConfigurationProperty("RuteFormat", IsRequired = true)]
        public string RuteFormat
        {
            get
            {
                return this["RuteFormat"] as string;
            }
            set
            {
                SetPropertyValue(this.Properties["RuteFormat"], value, true);
            }
        }

        [ConfigurationProperty("MappingPath", IsRequired = true)]
        public string MappingPath
        {
            get
            {
                return this["MappingPath"] as string;
            }
            set
            {
                SetPropertyValue(this.Properties["MappingPath"], value, true);
            }
        }
    }
}
