﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace Newegg.Oversea.Framework.WCF
{
    public class ClientServiceProxy<TChannel> : IDisposable where TChannel : class 
    {
        private ChannelFactory<TChannel> m_channelFactory = null;
        private TChannel m_channelInternal = null;

        public ClientServiceProxy()
        {
            m_channelFactory = new ChannelFactory<TChannel>();
            m_channelInternal = m_channelFactory.CreateChannel();
        }

        public ClientServiceProxy(string configPath)
        {
            m_channelFactory = new ClientChannelFactory<TChannel>(configPath);
            m_channelInternal = m_channelFactory.CreateChannel();
        }

        public TChannel Channel
        {
            get
            {
                return m_channelInternal;
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (m_channelFactory != null && 
                m_channelFactory.State == CommunicationState.Opened)
            {
                m_channelFactory.Close();
            }
        }

        #endregion
    }

}
