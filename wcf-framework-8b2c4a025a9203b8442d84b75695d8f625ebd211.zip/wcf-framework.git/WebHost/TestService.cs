﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Web;
using Newegg.Oversea.Framework.WCF.Behaviors;

namespace WebHost
{
    [ServiceContract]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall, AddressFilterMode = AddressFilterMode.Any)]
    [RestService]
    public class TestService
    {
        [WebInvoke(UriTemplate = "", Method = "POST")]
        public MenuItem Create(MenuItem item)
        {
            return item;
        }
    }

    public class MenuItem
    {
        public string MenuName { get; set; }
    }
}