Newegg Framework Tools
====
_Framework Tools_提供一系列工具函数库，比如压缩、加密解密、文件访问、网络调用、序列化等。

Target Framework Version
----
_Framework Tools_基于.NET Framework 4.0编译，可在.NET 4.0或更高版本的32位或64位环境中使用。

Getting Started
----
_Framework Tools_使用Nuget管理版本，可以从内部Nuget添加引用。

Dependency
----
_Framework Tools_作为底层类库，不依赖任何第三方类库。依赖于_Framework Tools_构建的项目包括Framework SDK, Rest API Client等。

License
----
Copyright (c) 2014 Newegg inc. All Rights Reserved.

About us
----
我们是BTS（Backend Tech Support） team。  
欢迎访问我们的[Blog](http://10.16.75.10:8002/)与我们进行交流。

![BTS](http://neg-app-img/MISInternal/DocumentTool/20140304042540930_easyicon_net_128.1394693687.ico)