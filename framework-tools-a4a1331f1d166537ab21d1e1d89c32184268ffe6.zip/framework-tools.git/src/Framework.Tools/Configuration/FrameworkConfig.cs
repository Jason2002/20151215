﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace Newegg.Framework.Tools.Configuration
{
    public class FrameworkConfiguration : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            FrameworkConfig config = GetDefaultConfig();

            if (section != null && section.HasChildNodes)
            {
                foreach (XmlNode node in section.ChildNodes)
                {
                    if (node.Name.Equals("logSetting", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (node.Attributes["logProvider"] != null && node.Attributes["logProvider"].Value != null)
                        {
                            config.LogSetting.LogType = node.Attributes["logProvider"].Value.Trim();
                        }
                        if (node.Attributes["logFolder"] != null && node.Attributes["logFolder"].Value != null)
                        {
                            string folder = node.Attributes["logFolder"].Value.Trim();
                            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folder);
                            config.LogSetting.LogFolder = path;
                        }
                        if (node.Attributes["emitter"] != null && node.Attributes["emitter"].Value != null)
                        {
                            config.LogSetting.EmitterType = node.Attributes["emitter"].Value.Trim();
                        }
                    }
                }
            }
            return config;
        }

        private FrameworkConfig GetDefaultConfig()
        {
            return new FrameworkConfig
            {
                LogSetting = new LogSetting
                {
                    LogType = "Text",
                    LogFolder = "Logs",
                    EmitterType = string.Empty,
                },
            };
        }
    }

    public class FrameworkConfig
    {

        public LogSetting LogSetting { get; set; }

        private static FrameworkConfig m_config = null;
        static object _lock = new object();

        public static FrameworkConfig Instance
        {
            get
            {
                if (m_config == null)
                {
                    lock (_lock)
                    {
                        m_config = ConfigurationManager.GetSection("frameworkTools") as FrameworkConfig;
                    }
                }
                return m_config;
            }
        }
    }

    public class LogSetting
    {
        public string LogType { get; set; }

        public string LogFolder { get; set; }

        public string EmitterType { get; set; }
    }
}
