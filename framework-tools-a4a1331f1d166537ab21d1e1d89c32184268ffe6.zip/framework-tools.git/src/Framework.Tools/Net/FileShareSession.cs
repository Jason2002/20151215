﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Newegg.Framework.Tools.Net
{
    /// <summary>
    /// Summary description for Connection.
    /// </summary>
    public class FileShareSession : IDisposable
    {

        public FileShareSession() { }

        public FileShareSession(FileShareConfig config)
        {
            this.Add(config);
        }

        public FileShareSession(List<FileShareConfig> configList)
        {
            if (configList != null)
            {
                configList.ForEach(
                    delegate(FileShareConfig config)
                    {
                        this.Add(config);
                    });
            }
        }

        private Hashtable m_configTable = new Hashtable();

        #region Public Method

        public void Add(FileShareConfig config)
        {
            if (config.Host == null ||
                config.Host.Trim().Length == 0)
            {
                throw new ArgumentNullException("config.Host");
            }

            if (m_configTable.Contains(config.Host) == false)
            {
                m_configTable.Add(config.Host, new RemoteFileShareConnection(config.Host, config, false));
                this.Connect();
            }
        }

        public void Connect()
        {
            IDictionaryEnumerator itor = m_configTable.GetEnumerator();
            while (itor.MoveNext())
            {
                RemoteFileShareConnection connection = itor.Value as RemoteFileShareConnection;

                if (connection != null && 
                    connection.Connected == false)
                {
                    bool connected = this.ExcuteNetCommand(connection.Config.Host,
                                                            connection.Config.UserName,
                                                            connection.Config.Password,
                                                            connection.Config.Persistent ? "connect_persistent" : "connect");
                    connection.Connected = connected;
                }
            }
        }

        public void DisConnect()
        {
            IDictionaryEnumerator itor = m_configTable.GetEnumerator();
            while (itor.MoveNext())
            {
                RemoteFileShareConnection connection = itor.Value as RemoteFileShareConnection;

                if (connection != null && 
                    connection.Connected == true)
                {
                    this.ExcuteNetCommand(connection.Config.Host,
                                        connection.Config.UserName,
                                        connection.Config.Password,
                                        "close");
                    connection.Connected = false;
                }
            }
        }

        #endregion

        #region Private Method
        /// <summary>
        /// Excute Net command for connecting remote Host and  some other actions
        /// </summary>
        /// <param name="remoteHost"> remote host name or IP Address</param>
        /// <param name="userName">user name for login</param>
        /// <param name="passWord">password for login</param>
        /// <param name="action">what you want to do</param>
        private bool ExcuteNetCommand(string remoteHost, string userName, string passWord, string action)
        {
            string cmd = string.Empty;

            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            try
            {
                proc.StartInfo.FileName = "cmd.exe";
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardInput = true;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.StartInfo.RedirectStandardError = true;
                proc.StartInfo.CreateNoWindow = true;
                proc.Start();

                switch (action)
                {
                    case "connect_persistent":
                        cmd = @"net use \\" + remoteHost + " " + passWord + " " + " /user:" + userName + " /persistent:yes";
                        break;
                    case "connect":
                        cmd = @"net use \\" + remoteHost + " " + passWord + " " + " /user:" + userName + " /persistent:no";
                        break;
                    case "ping":
                        cmd = @"ping -n 1 " + remoteHost;
                        break;
                    case "close":
                        cmd = @"net use  \\" + remoteHost + " " + passWord + " " + " /user:" + userName + " /del";
                        break;
                    case "share":
                        cmd = @"net share";
                        break;
                    default:
                        break;
                }

                proc.StandardInput.WriteLine(cmd);
                proc.StandardInput.WriteLine("exit");

                while (proc.HasExited == false)
                {
                    proc.WaitForExit(1000);
                }

                proc.StandardError.ReadToEnd();
                proc.StandardError.Close();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            finally
            {
                if (proc != null)
                {
                    proc.Close();
                    proc.Dispose();
                }
            }
            return true;
        }

        #endregion

        public void Dispose()
        {
            this.DisConnect();
        }

        class RemoteFileShareConnection
        {
            public RemoteFileShareConnection
                (string address, FileShareConfig config, bool connected)
            {
                m_address = address;
                m_config = config;
                m_connected = connected;
            }

            private string m_address;

            public string Address
            {
                get { return m_address; }
                set { m_address = value; }
            }

            private FileShareConfig m_config;

            public FileShareConfig Config
            {
                get { return m_config; }
                set { m_config = value; }
            }

            private bool m_connected;

            public bool Connected
            {
                get { return m_connected; }
                set { m_connected = value; }
            }

        }
    }

    /// <summary>
    /// 会话参数配置
    /// </summary>
    public class FileShareConfig
    {
        /// <summary>
        /// 
        /// </summary>
        public FileShareConfig()
        { }

        /// <param name="host">远程主机名或IP</param>
        /// <param name="username">登录名</param>
        /// <param name="password">口令</param>
        /// <param name="persistent">persistent:{yes | no}控制永久性网络连接的使用。默认值是最近一次所用的设置。无设备的连接不是永久性连接。Yes 将在连接完成后保存所有连接，并在下一次登录时恢复这些连接。No 不保存正在进行的连接或后续连接。现有的连接将在下次登录时恢复。</param>
        public FileShareConfig(string host, string username, string password, bool persistent)
        {
            Host = host;
            UserName = username;
            Password = password;
            Persistent = persistent;
        }

        /// <summary>
        /// 远程主机名或IP
        /// </summary>
        public string Host { get; set; }

        /// <summary>
        /// 登录名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 口令
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// persistent:{yes | no}控制永久性网络连接的使用。默认值是最近一次所用的设置。无设备的连接不是永久性连接。Yes 将在连接完成后保存所有连接，并在下一次登录时恢复这些连接。No 不保存正在进行的连接或后续连接。现有的连接将在下次登录时恢复。
        /// </summary>
        public bool Persistent { get; set; }
    }
}
