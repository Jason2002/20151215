﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Diagnostics;
using Newegg.Framework.Tools.Log.Emitter;
using Newegg.Framework.Tools.Serialization;

namespace Newegg.Framework.Tools.Log
{
    public class Logger
    {
        public static string WriteLog(LogEntry log, ILogEmitter logEmitter)
        {            
            try
            {
                logEmitter.EmitLog(log);
            }
            catch(Exception ex)
            {
                string message = string.Format("Write log failed.\r\n\r\n Error Info: {0}. \r\n\r\n Log Info: {1}",
                    ex.ToString(), SerializeHelper.XmlSerializer<LogEntry>(log));
                EventLogger.WriteEventLog("Oversea_LoggingComponent", message, EventLogEntryType.Error);
            }

            return log.ID;
        }

        public static string WriteLog(LogEntry log)
        {
            return WriteLog(log, EmitterFactory.Create());
        }

        public static string WriteLog(string content, string category)
        {
            return WriteLog(content, category, null, null);
        }

        public static string WriteLog(string content, string category, string referenceKey)
        {
            return WriteLog(content, category, referenceKey, null);
        }

        public static string WriteLog(string content, string category, string referenceKey, List<ExtendProperty> extendedProperties)
        {
            LogEntry log = new LogEntry();
            log.CategoryName = category;
            log.Content = content;
            log.ReferenceKey = referenceKey;
            log.ExtendedProperties = extendedProperties;
            return WriteLog(log);
        }
        
    }
}