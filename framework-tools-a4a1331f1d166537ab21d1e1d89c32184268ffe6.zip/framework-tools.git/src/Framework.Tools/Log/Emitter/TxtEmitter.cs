﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Configuration;
using Newegg.Framework.Tools.Configuration;
using Newegg.Framework.Tools.Serialization;

namespace Newegg.Framework.Tools.Log.Emitter
{
    internal class TxtEmitter : ILogEmitter
    {
        private static object m_syncObject = new object();

        public void EmitLog(LogEntry log)
        {
            if (!Directory.Exists(FrameworkConfig.Instance.LogSetting.LogFolder))
            {
                Directory.CreateDirectory(FrameworkConfig.Instance.LogSetting.LogFolder);
            }

            WriteToFile(SerializeHelper.XmlSerializer<LogEntry>(log), GetLogFileFullPath());
        }

        private string GetLogFileFullPath()
        {
            return Path.Combine(FrameworkConfig.Instance.LogSetting.LogFolder, DateTime.Now.ToString("yyyy-MM-dd") + ".txt");
        }

        private void WriteToFile(string log, string filePath)
        {
            lock (m_syncObject)
            {
                log += "\r\n**********************************************************************\r\n";
                byte[] textByte = System.Text.Encoding.UTF8.GetBytes(log);
                using (FileStream logStream = new FileStream(filePath, FileMode.Append, FileAccess.Write, FileShare.Write))
                {
                    logStream.Write(textByte, 0, textByte.Length);
                }
            }
        }
    }
}
