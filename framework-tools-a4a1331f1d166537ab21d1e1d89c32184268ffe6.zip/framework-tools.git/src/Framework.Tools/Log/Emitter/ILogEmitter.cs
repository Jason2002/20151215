﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Newegg.Framework.Tools.Configuration;


namespace Newegg.Framework.Tools.Log.Emitter
{
    public interface ILogEmitter
    {
        void EmitLog(LogEntry log);
    }
}
