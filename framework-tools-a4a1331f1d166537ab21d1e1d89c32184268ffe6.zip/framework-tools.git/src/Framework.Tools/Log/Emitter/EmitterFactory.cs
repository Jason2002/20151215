﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using Newegg.Framework.Tools.Configuration;


namespace Newegg.Framework.Tools.Log.Emitter
{
    public static class EmitterFactory
    {
        static object syncObj = new object();

        public static ILogEmitter Create()
        {
            var setting = FrameworkConfig.Instance.LogSetting;
            if (string.IsNullOrEmpty(setting.LogType))
            {
                throw new ArgumentException("Log type is null or empty string.");
            }

            ILogEmitter emitter = null;
            switch (setting.LogType.ToLower())
            {
                case "text":
                    emitter = new TxtEmitter();
                    break;
                case "other":
                    emitter = CreateLogEmitter(setting.EmitterType);
                    break;
                default:
                    emitter = new DebugEmitter();
                    break;
            }
            return emitter;
        }

        private static ILogEmitter CreateLogEmitter(string providerName)
        {
            if (string.IsNullOrEmpty(providerName))
            {
                throw new ArgumentException("Emitter is null or empty string.");
            }
            return (ILogEmitter)Activator.CreateInstance(Type.GetType(providerName));
        }
    }
}