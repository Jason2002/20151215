﻿using System;
using System.Collections.Generic;
using System.Text;
using Newegg.Framework.Tools.Serialization;


namespace Newegg.Framework.Tools.Log.Emitter
{
    internal class DebugEmitter : ILogEmitter
    {
        #region ILogEmitter Members

        public void EmitLog(LogEntry log)
        {
            System.Diagnostics.Debug.WriteLine(SerializeHelper.XmlSerializer<LogEntry>(log));
        }

        #endregion
    }

}
