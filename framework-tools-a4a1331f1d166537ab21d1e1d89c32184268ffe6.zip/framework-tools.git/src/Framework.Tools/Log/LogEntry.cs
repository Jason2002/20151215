﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Newegg.Framework.Tools.Log
{
    public class LogEntry
    {
        public LogEntry()
        {
            ID = Guid.NewGuid().ToString();
        }

        public string ID { get; set; }

        public string LocalName { get; set; }


        public string GlobalName { get; set; }


        public string Content { get; set; }


        public string LogUserName { get; set; }


        public string CategoryName { get; set; }

        private static string m_LogServerIP;
        public string LogServerIP
        {
            get
            {
                if (string.IsNullOrEmpty(m_LogServerIP))
                {
                    IPAddress[] address = Dns.GetHostEntry(LogServerName).AddressList;
                    if (address != null)
                    {
                        foreach (IPAddress addr in address)
                        {
                            //过滤IPv6的地址信息
                            if (addr.ToString().Length <= 16 && addr.ToString().Length > 5)
                            {
                                m_LogServerIP = addr.ToString();
                                break;
                            }
                        }
                    }
                }
                return m_LogServerIP;
            }

        }


        public string LogServerName
        {
            get
            {
                return Dns.GetHostName();
            }
        }


        public string LogType { get; set; }


        public List<ExtendProperty> ExtendedProperties { get; set; }


        public string ReferenceKey { get; set; }
    }

    public class ExtendProperty
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }

}