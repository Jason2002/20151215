﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Newegg.Framework.Tools.Log
{
    public class EventLogger
    {
        public static void WriteEventLog(string source, string content, EventLogEntryType type)
        {
            try
            {
                if (!EventLog.SourceExists(source))
                {
                    EventLog.CreateEventSource(source, "Newegg Framework");
                }
                using (EventLog errorLog = new EventLog())
                {
                    errorLog.Source = source;
                    errorLog.WriteEntry(content, type);
                }
            }
            catch (Exception ex)
            {
                try
                {
                    using (EventLog log = new EventLog("Application", ".", "Framework"))
                    {
                        log.WriteEntry(ex.ToString(), EventLogEntryType.Error);
                    }
                }
                catch
                {
                }
            }
        }
    }
}
