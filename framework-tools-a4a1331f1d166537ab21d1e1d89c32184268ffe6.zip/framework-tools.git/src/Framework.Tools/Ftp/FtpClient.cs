﻿using System;
using System.IO;
using System.Net;
using System.Text;

namespace Newegg.Framework.Tools.Ftp
{
    public class FtpClient : IFtp
    {
        string m_FtpServerIP;
        string m_FtpRemotePath;
        string m_FtpUserID;
        string m_FtpPassword;
        string m_FtpBaseURI;

        public FtpClient(string FtpServerIP, string FtpRemotePath, string FtpUserID, string FtpPassword)
        {
            m_FtpServerIP = FtpServerIP;

            m_FtpRemotePath = (FtpRemotePath.EndsWith("/")) ? FtpRemotePath : (FtpRemotePath + "/");
            m_FtpRemotePath = (m_FtpRemotePath.StartsWith("/")) ? m_FtpRemotePath : ("/" + m_FtpRemotePath);

            m_FtpBaseURI = string.Format("ftp://{0}{1}", m_FtpServerIP, m_FtpRemotePath);

            m_FtpUserID = string.IsNullOrEmpty(FtpUserID) ? "anonymous" : FtpUserID;
            m_FtpPassword = FtpPassword;
        }




        /// <summary>
        /// Upload File
        /// </summary>
        /// <param name="localFilePath">Local File full path.</param>
        public void Upload(string localFilePath)
        {
            FileInfo fileInf = new FileInfo(localFilePath);
            string uri = m_FtpBaseURI + fileInf.Name;
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(uri));
            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            reqFTP.KeepAlive = false;
            reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
            reqFTP.UseBinary = true;
            reqFTP.ContentLength = fileInf.Length;
            int buffLength = 4096;
            byte[] buff = new byte[buffLength];
            int contentLen;
            using (FileStream fs = fileInf.OpenRead())
            {
                if (!IsDirExist())
                {
                    MakeDir("");
                }
                using (Stream strm = reqFTP.GetRequestStream())
                {
                    contentLen = fs.Read(buff, 0, buffLength);
                    while (contentLen != 0)
                    {
                        strm.Write(buff, 0, contentLen);
                        contentLen = fs.Read(buff, 0, buffLength);
                    }
                    strm.Flush();
                }
            }
        }

        /// <summary>
        /// Upload File
        /// </summary>
        /// <param name="localFilePath">Local File full path.</param>
        public void Upload(string localFilePath, string remoteFileName)
        {
            FileInfo fileInf = new FileInfo(localFilePath);
            string uri = m_FtpBaseURI + remoteFileName;
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(uri));
            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            reqFTP.KeepAlive = false;
            reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
            reqFTP.UseBinary = true;
            reqFTP.ContentLength = fileInf.Length;
            int buffLength = 4096;
            byte[] buff = new byte[buffLength];
            int contentLen;
            using (FileStream fs = fileInf.OpenRead())
            {
                if (!IsDirExist())
                {
                    MakeDir("");
                }
                using (Stream strm = reqFTP.GetRequestStream())
                {
                    contentLen = fs.Read(buff, 0, buffLength);
                    while (contentLen != 0)
                    {
                        strm.Write(buff, 0, contentLen);
                        contentLen = fs.Read(buff, 0, buffLength);
                    }
                    strm.Flush();
                }
            }
        }


        /// <summary>
        /// Delete File
        /// </summary>
        /// <param name="fileName"></param>
        public void Delete(string remoteFileName)
        {

            string uri = string.Format("{0}{1}", m_FtpBaseURI, remoteFileName);


            FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(uri));

            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            reqFTP.KeepAlive = false;
            reqFTP.Method = WebRequestMethods.Ftp.DeleteFile;

            string result = string.Empty;
            using (FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse())
            {

                long size = response.ContentLength;
                using (Stream datastream = response.GetResponseStream())
                {
                    using (StreamReader sr = new StreamReader(datastream))
                    {
                        result = sr.ReadToEnd();
                    }
                }
            }

        }


        /// <summary>
        /// MakeDir
        /// </summary>
        /// <param name="dirName"></param>
        public void MakeDir(string dirName)
        {
            FtpWebRequest reqFTP;

            // dirName = name of the directory to create.
            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(m_FtpBaseURI + dirName));
            reqFTP.Method = WebRequestMethods.Ftp.MakeDirectory;
            reqFTP.UseBinary = true;
            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);

            using (FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse())
            {
                using (Stream ftpStream = response.GetResponseStream())
                {
                }
            }
        }

        public void GotoDirectory(string DirectoryName, bool IsRoot)
        {
            if (IsRoot)
            {
                m_FtpRemotePath = (DirectoryName.EndsWith("/")) ? DirectoryName : (DirectoryName + "/");
                m_FtpRemotePath = (m_FtpRemotePath.StartsWith("/")) ? m_FtpRemotePath : ("/" + m_FtpRemotePath);
            }
            else
            {
                m_FtpRemotePath += (DirectoryName.StartsWith("/")) ? DirectoryName.Remove(0, 1) : DirectoryName;
                m_FtpRemotePath = (m_FtpRemotePath.EndsWith("/")) ? m_FtpRemotePath : (m_FtpRemotePath + "/");
            }

            m_FtpBaseURI = string.Format("ftp://{0}{1}", m_FtpServerIP, m_FtpRemotePath);
        }

        /// <summary>
        /// GetFileList
        /// </summary>
        /// <returns>return current file & Directory list</returns>
        public string[] GetDirectyList()
        {

            StringBuilder result = new StringBuilder();
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(m_FtpBaseURI));
            reqFTP.UseBinary = true;
            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
            using (WebResponse response = reqFTP.GetResponse())
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        result.Append(line);
                        result.Append("\n");
                        line = reader.ReadLine();
                    }
                    // to remove the trailing '\n'      
                    result.Remove(result.ToString().LastIndexOf('\n'), 1);

                }
            }
            return result.ToString().Split('\n');

        }
        
        private bool IsDirExist()
        {
            var ftpWebRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri(m_FtpBaseURI));
            ftpWebRequest.UseBinary = true;
            ftpWebRequest.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            ftpWebRequest.Method = WebRequestMethods.Ftp.ListDirectory;

            try
            {
                ftpWebRequest.GetResponse();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        
        public bool IsExist(string fileName)
        {
            var sourceName = fileName.Trim();
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(m_FtpBaseURI));
            reqFTP.UseBinary = true;
            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
            using (WebResponse response = reqFTP.GetResponse())
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (string.Compare(sourceName, line.Trim(), true) == 0)
                        {
                            return true;
                        }
                    }

                }
            }

            return false;
        }

        public FtpDirectory GetDirectDetailList()
        {

            StringBuilder result = new StringBuilder();

            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(m_FtpBaseURI));
            reqFTP.UseBinary = true;
            reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
            reqFTP.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
            using (WebResponse response = reqFTP.GetResponse())
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        result.Append(line);
                        result.Append("\n");
                        line = reader.ReadLine();
                    }
                    if (result.Length < 2)
                    {
                        return new FtpDirectory();
                    }
                    // to remove the trailing '\n'      
                    result.Remove(result.ToString().LastIndexOf('\n'), 1);
                }

            }
            return new FtpDirectory(result.ToString(), m_FtpRemotePath);

        }


        /// <summary>
        /// Download File
        /// </summary>
        /// <param name="localFilePath">The full path where the file is to be created.</param>
        /// <param name="remotePathFileName">Name of the file to be createdNeed not name on FTP server.</param>
        public void Download(string localFilePath, string remoteFileName)
        {

            FtpWebRequest reqFTP;

            //filePath = <<>>, 
            //fileName = <<. name name()>>
            using (FileStream outputStream = new FileStream(localFilePath, FileMode.Create))
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(string.Format("{0}{1}", m_FtpBaseURI, remoteFileName)));
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
                using (FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse())
                {
                    using (Stream ftpStream = response.GetResponseStream())
                    {
                        long cl = response.ContentLength;
                        int bufferSize = 2048;
                        int readCount;
                        byte[] buffer = new byte[bufferSize];

                        readCount = ftpStream.Read(buffer, 0, bufferSize);
                        while (readCount > 0)
                        {
                            outputStream.Write(buffer, 0, readCount);
                            readCount = ftpStream.Read(buffer, 0, bufferSize);
                        }

                        outputStream.Flush();
                        //ftpStream.Close();
                        //outputStream.Close();
                        //response.Close();
                    }
                }
            }
        }


        /// <summary>
        /// Download File
        /// </summary>
        /// <param name="localFilePath">The full path where the file is to be created.</param>
        /// <param name="remotePathFileName">Name of the file to be createdNeed not name on FTP server.</param>
        public void Download(string localFilePath, string remoteFileName, long fileLength)
        {

            FtpWebRequest reqFTP;
            long lengthCount = 0;

            //filePath = <<>>, 
            //fileName = <<. name name()>>
            using (FileStream outputStream = new FileStream(localFilePath, FileMode.Create))
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(string.Format("{0}{1}", m_FtpBaseURI, remoteFileName)));
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(m_FtpUserID, m_FtpPassword);
                using (FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse())
                {
                    using (Stream ftpStream = response.GetResponseStream())
                    {
                        long cl = response.ContentLength;

                        //if (cl < fileLength)
                        //{
                        //    throw new Exception("Download file length occurrent error.");
                        //}

                        int bufferSize = 2048;
                        int readCount;
                        byte[] buffer = new byte[bufferSize];

                        readCount = ftpStream.Read(buffer, 0, bufferSize);
                        lengthCount += readCount;
                        while (readCount > 0)
                        {
                            outputStream.Write(buffer, 0, readCount);
                            readCount = ftpStream.Read(buffer, 0, bufferSize);
                            lengthCount += readCount;
                        }

                        outputStream.Flush();
                        //ftpStream.Close();
                        //outputStream.Close();
                        //response.Close();
                    }
                }
            }

            if (lengthCount != fileLength)
            {
                throw new Exception("Download file length occurrent error.");
            }
        }


        #region IDisposable Members

        public void Dispose()
        {

        }

        #endregion


        #region IFTP Members


        public string FTPPath
        {
            get { return m_FtpBaseURI.Substring(0, m_FtpBaseURI.Length - 1); }
        }

        #endregion
    }
}
