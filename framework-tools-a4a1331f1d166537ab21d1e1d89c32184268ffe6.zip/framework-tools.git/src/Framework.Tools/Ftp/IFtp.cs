﻿using System;

namespace Newegg.Framework.Tools.Ftp
{
    public interface IFtp : IDisposable
    {
        void MakeDir(string dirName);
        void Delete(string remoteFileName);
        void GotoDirectory(string DirectoryName, bool IsRoot);
        void Upload(string filename);
        void Upload(string localFilename, string remoteFileName);
        FtpDirectory GetDirectDetailList();
        void Download(string localFilePath, string remoteFileName);
        void Download(string localFilePath, string remoteFileName, long fileLength);
        string FTPPath { get; }
    }
}
