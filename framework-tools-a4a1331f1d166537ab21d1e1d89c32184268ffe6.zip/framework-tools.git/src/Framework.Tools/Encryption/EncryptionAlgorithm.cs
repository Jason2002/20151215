using System;
using System.Collections.Generic;
using System.Text;

namespace Newegg.Framework.Tools.Encryption
{
    [Serializable]
    public enum EncryptionAlgorithm
    {
        Des = 1,
        Rc2,
        Rijndael,
        TripleDes
    }
}
