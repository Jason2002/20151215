package com.newegg.willcall.activity.pos.order;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.entities.pos.order.CartInfo;
import com.newegg.willcall.utils.CurrencyUtils;

/**
 * Created by jaredluo on 12/20/14.
 */
public class POSDiscountActivity extends BaseActivity {

    public static final String PARAM_CART_INFO = "PARAM_CART_INFO";

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private DiscountAdapter mAdapter;
    private TextView mGrandTotal;

    private CartInfo mCartInfo;
    private TextView mTotalDiscount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posdiscount);

        findViews();
        setRecyclerView();

    }

    private void findViews() {
        mGrandTotal = (TextView)findViewById(R.id.posdiscount_grandtotal);
        mTotalDiscount = (TextView)findViewById(R.id.posdiscount_total_discount);
    }

    private void setRecyclerView() {
        if(getIntent() == null || getIntent().getSerializableExtra(PARAM_CART_INFO) == null){
            return;
        }

        mCartInfo =(CartInfo)getIntent().getSerializableExtra(PARAM_CART_INFO);

        mGrandTotal.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getGrandTotal()));
        mTotalDiscount.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getTotalDiscount()));

        mRecyclerView = (RecyclerView) findViewById(R.id.posdiscount_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new DiscountAdapter(mCartInfo);
        mAdapter.setOnDiscountChangedListener(new DiscountAdapter.OnDiscountChangedListener() {
            @Override
            public void onDiscountChanged() {
                mGrandTotal.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getGrandTotal()));
                mTotalDiscount.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getTotalDiscount()));
            }
        });
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            onBack();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        onBack();
        super.onBackPressed();
    }

    private void onBack(){
        Intent intent = new Intent();
        intent.putExtra(PARAM_CART_INFO, mCartInfo);
        setResult(RESULT_OK, intent);
        finish();
    }
}
