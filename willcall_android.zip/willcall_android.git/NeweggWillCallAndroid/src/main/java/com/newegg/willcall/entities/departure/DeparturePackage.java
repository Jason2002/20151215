package com.newegg.willcall.entities.departure;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-11.
 */
public class DeparturePackage {

    @JSONField(name = "Destination")
    private String mDestination;
    @JSONField(name = "TrackingNumber")
    private String mTrackingNumber;

    public String getDestination() {
        return mDestination;
    }

    public void setDestination(String destination) {
        mDestination = destination;
    }

    public String getTrackingNumber() {
        return mTrackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        mTrackingNumber = trackingNumber;
    }
}
