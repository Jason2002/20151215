package com.newegg.willcall;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.pos.order.POSCartActivity;
import com.newegg.willcall.activity.pos.orderReturn.InputOrderDialogFragment;
import com.newegg.willcall.activity.pos.salesSummary.SalesSummaryActivity;
import com.newegg.willcall.activity.pos.tools.POSTraceActivity;
import com.newegg.willcall.activity.willcall.checkout.CheckoutActivity;
import com.newegg.willcall.activity.willcall.checkout.PackagePickFragment;
import com.newegg.willcall.activity.willcall.departure.PackageDepartureActivity;
import com.newegg.willcall.activity.willcall.picking.ExpiredPackagePickingActivity;
import com.newegg.willcall.activity.willcall.picking.PackagePickingActivity;
import com.newegg.willcall.activity.willcall.picking.PackagePickingTaskActivity;
import com.newegg.willcall.activity.willcall.receiving.PackageMoveInActivity;
import com.newegg.willcall.activity.willcall.receiving.PackageReceivingActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.LogUserInfo;
import com.newegg.willcall.entities.Warehouse;
import com.newegg.willcall.entities.checkout.CheckOutItemInfo;
import com.newegg.willcall.entities.checkout.CheckOutPackageInfo;
import com.newegg.willcall.entities.checkout.CheckOutSoInfo;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.utils.QuickClickUtil;
import com.newegg.willcall.utils.ScreenUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.animation.ValueAnimator;
import com.nineoldandroids.view.ViewPropertyAnimator;

import java.io.Serializable;
import java.util.ArrayList;


public class MainActivity extends BaseActivity {

    public static final String PARAM_APP_TYPE = "PARAM_APP_TYPE";
    public static final String CACHE_APP_TYPE = "CACHE_APP_TYPE";


    public enum APP_TYPE{
        APP_TYPE_WILLCALL,
        APP_TYPE_POS
    }

    private APP_TYPE type;

    private static final int ANIMATION_DURATION = 500;

    private TextView mNameTextView;
    private TextView mWarehouseTextView;

    private TextView mReceivingTextView;
    private TextView mCheckoutTextView;
    private TextView mReturnTextView;

    private LinearLayout mReceivingContainer;
    private LinearLayout mCheckoutContainer;
    private LinearLayout mReturnContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setHomeButtonEnabled(false);

        setContentView(R.layout.activity_main);

        findView();

        buildUIByType();

        bindUI();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        if(type ==APP_TYPE.APP_TYPE_WILLCALL ){
            MenuItem menuItem = menu.findItem(R.id.action_view_log);
            if(menuItem != null) {
                menuItem.setVisible(false);
            }
        }
        return result;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_view_log){
            startActivity(new Intent(this, POSTraceActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void buildUIByType() {
        Intent intent = getIntent();
        Serializable object = intent.getSerializableExtra(PARAM_APP_TYPE);
        type = APP_TYPE.APP_TYPE_WILLCALL;
        if(object != null) {
            type = (APP_TYPE) object;
        }

        switch (type){
            case APP_TYPE_WILLCALL:
                mReceivingTextView.setText(R.string.receiving);
                mCheckoutTextView.setText(R.string.checkout);
                mReturnTextView.setText(R.string.rma);
                break;
            case APP_TYPE_POS:
                mReceivingTextView.setText(R.string.scan_and_order);
                mCheckoutTextView.setText(R.string.returns);
                mReturnTextView.setText(R.string.sales_summary);
                break;
        }

    }


    public void onReturnPickingClicked(View view) {
        if (QuickClickUtil.isFastClick())
            return;

        if (WillCallApp.getWarehouse().hasExpiredPrivilege()) {
            startActivity(new Intent(this, ExpiredPackagePickingActivity.class));
        } else {
            ToastUtil.show(this, getString(R.string.privilege_error));
        }
    }

    public void onReturnDepartureClicked(View view) {
        if (QuickClickUtil.isFastClick())
            return;
        if (WillCallApp.getWarehouse().hasDeparturePrivilege()) {
            startActivity(new Intent(this, PackageDepartureActivity.class));
        } else {
            ToastUtil.show(this, getString(R.string.privilege_error));
        }
    }

    private void setAnimation(final LinearLayout view,final TextView menuItemTextView
            ,final LinearLayout otherContainer1,final TextView otherMenuItemTextView1
            ,final LinearLayout otherContainer2,final TextView otherMenuItemTextView2 ) {
        final int normalHeight = view.getMeasuredHeight();
        final int receivingNormalLeft = mReceivingTextView.getLeft();
        final int checkoutNormalLeft = mCheckoutTextView.getLeft();
        final int returnNormalLeft = mReturnTextView.getLeft();

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int receivingDistance = receivingNormalLeft - ScreenUtil.getPxByDp(10);
                int checkoutDistance = checkoutNormalLeft - ScreenUtil.getPxByDp(10);
                int returnDistance = returnNormalLeft - ScreenUtil.getPxByDp(10);

                if (view.getMeasuredHeight() > normalHeight) {

                    animateHeight(view, view.getMeasuredHeight(), normalHeight);
                    animateHeight(menuItemTextView, menuItemTextView.getMeasuredHeight(), normalHeight);
                    animateHeight(otherContainer1, otherContainer1.getMeasuredHeight(), normalHeight);
                    animateHeight(otherContainer2, otherContainer2.getMeasuredHeight(), normalHeight);
                    animateHeight(otherMenuItemTextView2, otherMenuItemTextView2.getMeasuredHeight(), normalHeight);
                    animateHeight(otherMenuItemTextView1, otherMenuItemTextView2.getMeasuredHeight(), normalHeight);

                    animateX(mReceivingTextView, receivingDistance);
                    animateX(mCheckoutTextView, checkoutDistance);
                    animateX(mReturnTextView, returnDistance);

                    mReceivingTextView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_receiving_selector, 0, 0, 0);
                    mCheckoutTextView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_checkout_selector, 0, 0, 0);
                    mReturnTextView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_return_selector, 0, 0, 0);

                    int padding = ScreenUtil.getPxByDp(10);
                    mReceivingTextView.setCompoundDrawablePadding(padding);
                    mCheckoutTextView.setCompoundDrawablePadding(padding);
                    mReturnTextView.setCompoundDrawablePadding(padding);

                } else if (view.getMeasuredHeight()<normalHeight) {
                    animateHeight(view, view.getMeasuredHeight(), ScreenUtil.getPxByDp(240));
                    animateHeight(menuItemTextView, menuItemTextView.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherContainer1, otherContainer1.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherContainer2, otherContainer2.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherMenuItemTextView2, otherMenuItemTextView2.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherMenuItemTextView1, otherMenuItemTextView1.getMeasuredHeight(), normalHeight / 2);
                }
                else {
                    animateHeight(view, normalHeight, ScreenUtil.getPxByDp(240));
                    animateHeight(menuItemTextView, menuItemTextView.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherContainer1, otherContainer1.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherContainer2, otherContainer2.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherMenuItemTextView2, otherMenuItemTextView2.getMeasuredHeight(), normalHeight / 2);
                    animateHeight(otherMenuItemTextView1, otherMenuItemTextView1.getMeasuredHeight(), normalHeight / 2);

                    animateX(mReceivingTextView, -receivingDistance);
                    animateX(mCheckoutTextView, -checkoutDistance);
                    animateX(mReturnTextView, -returnDistance);

                    mReceivingTextView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_receiving_small_selector, 0, 0, 0);
                    mCheckoutTextView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_checkout_small_selector, 0, 0, 0);
                    mReturnTextView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_return_small_selector, 0, 0, 0);

                    int padding = ScreenUtil.getPxByDp(5);
                    mReceivingTextView.setCompoundDrawablePadding(padding);
                    mCheckoutTextView.setCompoundDrawablePadding(padding);
                    mReturnTextView.setCompoundDrawablePadding(padding);
                }
            }
        });
    }


    private void animateSize(TextView textView, float from, float to) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(textView, "TextSize", from, to);
        animator.setDuration(200).start();
    }


    private void animateHeight(final View view, int fromHeight, int toHeight) {
        ValueAnimator animator = ValueAnimator.ofInt(fromHeight, toHeight);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                ViewGroup.LayoutParams params = view.getLayoutParams();
                params.height = (Integer) animation.getAnimatedValue();
                view.setLayoutParams(params);
            }
        });
        animator.setDuration(ANIMATION_DURATION);
        animator.setInterpolator(new AccelerateInterpolator());
        animator.start();
    }

    private ViewPropertyAnimator animateX(final View view, final int distance) {
        ViewPropertyAnimator animator = ViewPropertyAnimator.animate(view);
        animator.translationXBy(distance).setDuration(200).start();
        return animator;
    }

    private void bindUI() {

        LogUserInfo userInfo = WillCallApp.getUser();
        Warehouse warehouse = WillCallApp.getWarehouse();
        if (userInfo != null) {
            mNameTextView.setText(userInfo.getName());
        }

        if (warehouse != null) {
            mWarehouseTextView.setText(warehouse.getWarehouseName());
        }

        if(type == APP_TYPE.APP_TYPE_WILLCALL){
            bindUIForWillCall();
        }else{
            bindUIForPos();
        }
    }





    private void bindUIForWillCall() {
        mReturnContainer.post(new Runnable() {
            @Override
            public void run() {
                setAnimation(mReturnContainer, mReturnTextView, mReceivingContainer, mReceivingTextView, mCheckoutContainer, mCheckoutTextView);
                setAnimation(mReceivingContainer, mReceivingTextView, mReturnContainer, mReturnTextView, mCheckoutContainer, mCheckoutTextView);
                setAnimation(mCheckoutContainer, mCheckoutTextView, mReturnContainer, mReturnTextView, mReceivingContainer, mReceivingTextView);
            }
        });
    }

    public void onPackageReceivingClicked(View view){
        if(WillCallApp.getWarehouse() == null){
            return;
        }
        if (WillCallApp.getWarehouse().hasReceivingPrivilege()) {
            startActivity(new Intent(this, PackageReceivingActivity.class));
        } else {
            ToastUtil.show(this, getString(R.string.privilege_error));
        }
    }

    public void onPackageMoveInClicked(View view){
        if(WillCallApp.getWarehouse() == null){
            return;
        }
        if (WillCallApp.getWarehouse().hasReceivingPrivilege()) {
            startActivity(new Intent(this, PackageMoveInActivity.class));
        } else {
            ToastUtil.show(this, getString(R.string.privilege_error));
        }
    }

    public void onCustomerCheckoutClicked(View view){
        if (WillCallApp.getWarehouse().hasCheckoutPrivilege()) {
            startActivity(new Intent(this, CheckoutActivity.class));
        } else {
            ToastUtil.show(this, getString(R.string.privilege_error));
        }
    }

    public void onPackagePickingClicked(View view){
        startActivity(new Intent(this, PackagePickingTaskActivity.class));
        overridePendingTransition(R.anim.anim_down_in,R.anim.anim_up_out);
    }

    private void findView() {
        mNameTextView = (TextView) findViewById(R.id.main_user_name);
        mWarehouseTextView = (TextView) findViewById(R.id.main_warehouse_name);

        mReceivingContainer = (LinearLayout) findViewById(R.id.main_receiving_container);
        mCheckoutContainer = (LinearLayout) findViewById(R.id.main_checkout_container);
        mReturnContainer = (LinearLayout) findViewById(R.id.main_return_container);

        mReceivingTextView = (TextView) findViewById(R.id.main_receiving);
        mCheckoutTextView = (TextView) findViewById(R.id.main_checkout);
        mReturnTextView = (TextView) findViewById(R.id.main_return);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.findItem(R.id.action_home);
        menuItem.setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    private void bindUIForPos() {
        mReturnContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SalesSummaryActivity.class));
            }
        });

        mReceivingContainer.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, POSCartActivity.class));
            }
        });

        mCheckoutContainer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                InputOrderDialogFragment fragment = new InputOrderDialogFragment();
                fragment.show(getFragmentManager(), "InputOrderDialogFragment");
            }
        });

    }


}
