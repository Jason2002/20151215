package com.newegg.willcall.activity.pos.orderReturn;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.orderReturn.POSReturnDTO;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;

public class InputOrderDialogFragment extends DialogFragment {
    private EditText mOrderNumberEditText;
    private TextView mErrorTextView;
    private Context mContext;
    private ProgressDialog mProgressDialog;
    private AlertDialog mDialog;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        mContext = getActivity();

        View layout = LayoutInflater.from(mContext).inflate(R.layout.pos_return_input_order_dialog, null);
        mOrderNumberEditText = (EditText)layout.findViewById(R.id.order_number_editText);
        mErrorTextView = (TextView)layout.findViewById(R.id.error_TextView);
        mDialog =  new AlertDialog.Builder(mContext)
                .setView(layout)
                .setPositiveButton(R.string.done, null)
                .setNegativeButton(R.string.cancel, null)
                .create();

        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button btn = mDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                btn.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        getOrderNumber();
                    }
                });
            }
        });

        mOrderNumberEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    mDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                }
            }
        });

        mOrderNumberEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    getOrderNumber();
                    return true;
                }
                return false;
            }
        });


        return mDialog;
    }

    private void getOrderNumber() {
        try {
            String strOrderNumber = mOrderNumberEditText.getText().toString();
            if (strOrderNumber.isEmpty()) {
                setErrorText(R.string.pos_return_error_empty_order_number);
                return;
            }
            int orderNumber = Integer.valueOf(strOrderNumber);

            getOrderInfo(orderNumber);
        } catch (Exception ex) {
            setErrorText(R.string.pos_return_error_invalid_order_number);
        }
    }

    private void getOrderInfo(int orderNumber){
        showProgressDialog();
        FastJsonObjectRequest<POSReturnDTO> request = new FastJsonObjectRequest<POSReturnDTO>(mContext, POSReturnDTO.class,
                HttpConfig.getFormatUrl(HttpConfig.POS_RETURN_AVAILABLE_RETURN, String.valueOf(orderNumber)), new Response.Listener<POSReturnDTO>() {
            @Override
            public void onResponse(POSReturnDTO result) {
                hideProgressDialog();

                if(result == null){
                    setErrorText(R.string.pos_return_error_invalid_order_number);
                }else if(result.getTransactionCollection() == null || result.getTransactionCollection().size() == 0){
                    setErrorText(R.string.pos_return_error_no_item_can_return);
                }else{
                    Intent intent = new Intent(mContext, POSReturnActivity.class);
                    intent.putExtra(POSReturnActivity.EXTRA_ORDER, result);
                    startActivity(intent);
                    mDialog.dismiss();
                }
            }
        }, new FastJsonObjectRequest.OnErrorListener() {

            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();

                if(info != null && info.getMessage() != null){
                    setErrorText(info.getMessage());
                }
            }
        });

        VolleyUtil.addToRequestQueue(mContext, request);
    }

    protected void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(mContext);
            mProgressDialog.setMessage("Loading");
            mProgressDialog.setCanceledOnTouchOutside(false);
        }
        mProgressDialog.show();
    }

    protected void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing())
            mProgressDialog.dismiss();
    }

    private void setErrorText(int resId){
        mErrorTextView.setVisibility(View.VISIBLE);
        mErrorTextView.setText(resId);
    }

    private void setErrorText(String errMsg){
        mErrorTextView.setVisibility(View.VISIBLE);
        mErrorTextView.setText(errMsg);
    }

}
