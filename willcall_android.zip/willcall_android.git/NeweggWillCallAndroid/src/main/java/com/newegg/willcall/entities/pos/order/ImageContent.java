package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class ImageContent implements Serializable{
    private static final long serialVersionUID = -5955890133285222444L;
    @JSONField(name = "SONumber")
    private int soNumber;
    @JSONField(name = "ImageID")
    private String imageID;
    @JSONField(name = "URL")
    private String url;
    @JSONField(name = "ImageType")
    private String imageType;
    @JSONField(name = "InUser")
    private String inUser;
    @JSONField(name = "ImageName")
    private String imageName;

    public int getSoNumber() {
        return soNumber;
    }

    public void setSoNumber(int soNumber) {
        this.soNumber = soNumber;
    }

    public String getImageID() {
        return imageID;
    }

    public void setImageID(String imageID) {
        this.imageID = imageID;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }

    public String getInUser() {
        return inUser;
    }

    public void setInUser(String inUser) {
        this.inUser = inUser;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }
}
