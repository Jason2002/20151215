package com.newegg.willcall.http;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.account.LoginActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.Warehouse;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by lenayan on 14-4-18.
 */
public abstract class BaseRequest<T> extends Request<T> {
    public static final int SOCKET_SHORT_TIMEOUT = 20*1000;
    public static final int SOCKET_LONG_TIMEOUT = 60*1000;

    protected static final String CHARSET = "utf-8";

    private static final String CONTENT_TYPE_JSON =
            String.format("application/json; charset=%s", CHARSET);

    private String contentType;

    private final Context context;
    private Object request;
    private HashMap<String,String> extraHeaders = new HashMap<String, String>(10);


    public void addHeader(String key,String value){
        if(!StringUtil.isEmpty(key)) {
            extraHeaders.put(key, value);
        }
    }

    protected OnErrorListener errorListener;

    protected BaseRequest(int method, String url, OnErrorListener listener, Context context) {
        this(method,url,listener,context,null);
    }

    protected BaseRequest(int method, String url, OnErrorListener listener, Context context, Object request) {
        super(method, url, null);
        this.errorListener = listener;
        this.context = context;
        this.request = request;
        contentType = CONTENT_TYPE_JSON;
        setRetry();
    }


    protected BaseRequest(int method, String url, Response.ErrorListener listener, Context context) {
        this(method,url,listener,context,null);
    }

    protected BaseRequest(int method, String url, Response.ErrorListener listener, Context context, Object request) {
        super(method, url, listener);
        this.context = context;
        this.request = request;
        contentType = CONTENT_TYPE_JSON;
        setRetry();

    }

    private void setRetry() {
        setRetryPolicy(new DefaultRetryPolicy(
                SOCKET_SHORT_TIMEOUT,
                5,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }


    @Override
    public byte[] getBody() throws AuthFailureError {
        if (request == null) {
            return null;
        }
        String jsonString = null;
        try {
            if(request instanceof String){
                jsonString = request.toString();
            }
            else {
                jsonString = JSON.toJSONString(request);
            }
            LogUtil.i("JsonString:" + jsonString);
            return jsonString == null ? null : jsonString.getBytes(CHARSET);
        } catch (UnsupportedEncodingException uee) {
            VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s",
                    jsonString, CHARSET);
            return null;
        }
    }

    @Override
    public String getBodyContentType() {
        return contentType;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> headers = new HashMap<String, String>();
        if (ConfigUtil.ServiceType != ConfigUtil.ServiceTypes.Local) {
            headers.put("Authorization", "7ec5f897aaa4937218a11b8b5b15934d&ec6a7f9c7a1ebf6c881d8e2c0c7eea68");
            //LogUtil.i("Authorization:" + WillCallApp.getAuthKey());
        }

        Warehouse warehouse = WillCallApp.getWarehouse();
        if (warehouse != null) {
            headers.put("X-WarehouseNumber", warehouse.getCode());
        }
        headers.put("Accept", "application/json");
        if(extraHeaders.size()>0){
            for(Map.Entry<String,String> item: extraHeaders.entrySet()){
                headers.put(item.getKey(),item.getValue());
            }
        }
        return headers;
    }

    @Override
    protected VolleyError parseNetworkError(VolleyError volleyError) {
        ErrorResponseInfo parsedErrorInfo = new ErrorResponseInfo();
        parsedErrorInfo.setStatusCode("-1");
        parsedErrorInfo.setMessage(context.getString(R.string.network_error));

        if (volleyError != null) {
            String toastString = null;
            if (volleyError.networkResponse != null) {
                String jsonString = "";
                try {
                    jsonString = new String(volleyError.networkResponse.data, CHARSET);
                    ErrorResponseInfo error = JSON.parseObject(jsonString, ErrorResponseInfo.class);

                    if (error != null) {
                        toastString = error.getStatusCode().equals("Unauthorized") ? context.getString(R.string.auth_error) : error.getMessage();
                        parsedErrorInfo = error;
                    }
                } catch (UnsupportedEncodingException e) {
                    LogUtil.e("Throwing " + UnsupportedEncodingException.class + " when parse " + jsonString);
                    toastString = context.getString(R.string.unsupport_encode_error);
                } catch (JSONException e) {
                    LogUtil.e("Throwing " + JSONException.class + " when parse " + jsonString);
                    toastString = context.getString(R.string.server_error);
                }
            } else if (volleyError instanceof AuthFailureError || (!StringUtil.isEmpty(volleyError.getMessage()) && volleyError.getMessage().toLowerCase().contains("no authentication challenges found"))) {
                LogUtil.i("volleyError instanceof AuthFailureError" + (volleyError instanceof AuthFailureError));
                redirectToLogin();
                toastString = context.getString(R.string.auth_error);
            } else if (volleyError instanceof NoConnectionError || volleyError instanceof NetworkError) {
                toastString = context.getString(R.string.network_error);
            } else if (volleyError instanceof ServerError) {
                toastString = context.getString(R.string.server_error);
            }
            if (!TextUtils.isEmpty(toastString)) {
                showToast(toastString);
            }
        }

        onError(parsedErrorInfo);

        return super.parseNetworkError(volleyError);
    }

    protected void onError(final ErrorResponseInfo error) {
        if (errorListener != null) {
            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    errorListener.onError(error);
                }
            });
        }

    }

    private void showToast(final String toast) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                ToastUtil.show(context, toast);
            }
        });
    }


    private void redirectToLogin() {
        VolleyUtil.cancelAllPandingRequest();
        Intent intent = new Intent(context, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }

    public interface OnErrorListener {
        void onError(ErrorResponseInfo info);
    }
}
