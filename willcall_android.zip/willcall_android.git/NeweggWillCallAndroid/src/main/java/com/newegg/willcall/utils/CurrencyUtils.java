package com.newegg.willcall.utils;

import org.apache.commons.math3.util.Decimal64;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * Created by jaredluo on 12/25/14.
 */
public class CurrencyUtils {
    public static String getFormatDecimal(Decimal64 input) {
        DecimalFormat form = new DecimalFormat("#0.00");
        return form.format(input.doubleValue());
    }

    public static Boolean isNumber(String numStr) {
        try {
            Double.parseDouble(numStr);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

    public static String getCurrencyFormat(Decimal64 input) {
        String resultStr = "$";
        if (input.doubleValue() < 0) {
            resultStr = "-$";
            input = input.abs();
        }

        input = getCellWith2Digit(input);

        DecimalFormat formatter = new DecimalFormat("#,###,##0.00");
        resultStr += formatter.format(input);
        return resultStr;
    }

    public static String getCurrencyFormat(BigDecimal decimal) {
        if (decimal == null) {
            return getCurrencyFormat(new Decimal64(0));
        }
        return getCurrencyFormat(new Decimal64(decimal.doubleValue()));
    }

    public static Decimal64 getCellWith2Digit(Decimal64 input) {
        BigDecimal result = new BigDecimal(input.toString());
        BigDecimal ceil = getCellWith2Digit(result);
        return new Decimal64(ceil.doubleValue());
    }

    public static BigDecimal getCellWith2Digit(BigDecimal decimal) {
        BigDecimal ceil = decimal.setScale(2, BigDecimal.ROUND_HALF_EVEN);
        return ceil;
    }

    public static String maskCrediCard(String cardNum) {
        if (StringUtil.isEmpty(cardNum) || cardNum.length() <= 4) {
            if (StringUtil.isEmpty(cardNum)) {
                return "";
            }
            return cardNum;
        }

        String lastPart = cardNum.substring(cardNum.length() - 4);

        String firstPart = cardNum.substring(0, cardNum.length() - 4);

        int count = firstPart.length() / 4;

        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < count; i++) {
            sb.append("****");
            sb.append(" ");
        }

        sb.append(firstPart.substring(count * 4, firstPart.length()));
        sb.append(lastPart);

        return sb.toString();
    }
}
