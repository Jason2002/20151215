package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class GiftCardInformation implements Serializable{
    private static final long serialVersionUID = 2046104019157770910L;
    @JSONField(name = "GCCode")
    private String gcCode;
    @JSONField(name = "SubCode")
    private int subCode;
    @JSONField(name = "RedeemAmount")
    private Double redeemAmount;

    public String getGcCode() {
        return gcCode;
    }

    public void setGcCode(String gcCode) {
        this.gcCode = gcCode;
    }

    public int getSubCode() {
        return subCode;
    }

    public void setSubCode(int subCode) {
        this.subCode = subCode;
    }

    public Double getRedeemAmount() {
        return redeemAmount;
    }

    public void setRedeemAmount(Double redeemAmount) {
        this.redeemAmount = redeemAmount;
    }
}
