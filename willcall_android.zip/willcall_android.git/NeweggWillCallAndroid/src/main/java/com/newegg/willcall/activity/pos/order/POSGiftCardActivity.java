package com.newegg.willcall.activity.pos.order;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.order.GiftCardRes;
import com.newegg.willcall.http.BaseRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import org.apache.commons.math3.util.Decimal64;

import java.util.ArrayList;

/**
 * Created by jaredluo on 12/20/14.
 */
public class POSGiftCardActivity extends BaseActivity {

    public static final String PARAM_GIFT_CARD_INFO = "PARAM_GIFT_CARD_INFO";
    public static final String PARAM_GRAND_TOTAL_WITHOUT_GC = "PARAM_GRAND_TOTAL_WITHOUT_GC";

    private RecyclerView mRecyclerView;
    private GiftCardAdapter mAdapter;
    private LinearLayoutManager mLayoutManager;
    private EditText mCardNumEditText;
    private EditText mSecureCodeEditText;
    private Button mApplyBtn;

    private double grandTotalWithoutGC;
    private ArrayList<GiftCardRes> mCards = new ArrayList<GiftCardRes>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posgiftcard);

        findViews();
        setRecyclerView();
    }

    private void findViews() {
        mCardNumEditText = (EditText) findViewById(R.id.posgc_card_number_et);
        mSecureCodeEditText = (EditText) findViewById(R.id.posgc_security_code_et);
        mApplyBtn = (Button) findViewById(R.id.posgc_apply_btn);

        mApplyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyGC(mCardNumEditText.getText(), mSecureCodeEditText.getText());
            }
        });
    }

    private void applyGC(Editable cardNumEditable, Editable secureCodeEditable) {

        hideKeyboard(mSecureCodeEditText);

        mCardNumEditText.setError(null);
        mSecureCodeEditText.setError(null);

        if (cardNumEditable == null || StringUtil.isEmpty(cardNumEditable.toString())) {
            mCardNumEditText.requestFocus();
            mCardNumEditText.requestFocusFromTouch();
            mCardNumEditText.setError(getString(R.string.empty_gc_card_num_hint));
            return;
        }

        if (secureCodeEditable == null || StringUtil.isEmpty(secureCodeEditable.toString())) {
            mSecureCodeEditText.requestFocus();
            mSecureCodeEditText.requestFocusFromTouch();
            mSecureCodeEditText.setError(getString(R.string.empty_gc_secure_code_hint));
            return;
        }

        String cardNum = cardNumEditable.toString().trim();
        String secureCode = secureCodeEditable.toString().trim();

        if (!StringUtil.isAlphaNumeric(cardNum)){
            mCardNumEditText.requestFocus();
            mCardNumEditText.requestFocusFromTouch();
            mCardNumEditText.setError(getString(R.string.invalid_gc_card_num_hint));
            return;
        }


        if (!StringUtil.isAlphaNumeric(secureCode)){
            mSecureCodeEditText.requestFocus();
            mSecureCodeEditText.requestFocusFromTouch();
            mSecureCodeEditText.setError(getString(R.string.invalid_gc_secure_code_hint));
            return;
        }

        for (GiftCardRes card : mCards) {
            if (cardNum.equals(card.getCardNum())) {
                mCardNumEditText.requestFocus();
                mCardNumEditText.requestFocusFromTouch();
                mCardNumEditText.setError(getString(R.string.gc_card_already_added));
                ToastUtil.show(this, getString(R.string.gc_card_already_added));
                return;
            }
        }

        double availableGrandTotal = availableGrandTotal();
        if (availableGrandTotal <= 0) {
            ToastUtil.show(this, getString(R.string.gc_card_enough));
            return;
        }


        requestData(availableGrandTotal, cardNum, secureCode);

    }

    private double availableGrandTotal() {
        Decimal64 totalGC = new Decimal64(0.0);
        for (GiftCardRes card : mCards) {
            totalGC = totalGC.add(new Decimal64(card.getRedeemAmount()));
        }
        return (new Decimal64(grandTotalWithoutGC).subtract(totalGC)).doubleValue();
    }

    private void requestData(final double availableGrandTotal, final String cardNum, String secureCode) {
        showProgressDialog();
        FastJsonObjectRequest<GiftCardRes> request = new FastJsonObjectRequest<GiftCardRes>(this, GiftCardRes.class, HttpConfig.getFormatUrl(HttpConfig.POS_CART_GET_GIFT_CARD, cardNum, secureCode), new Response.Listener<GiftCardRes>() {
            @Override
            public void onResponse(GiftCardRes giftCardRes) {
                hideProgressDialog();
                if (giftCardRes != null) {

                    if (giftCardRes.getBalance() <= 0.0) {
                        ToastUtil.show(POSGiftCardActivity.this, getString(R.string.gc_card_empty));
                        return;
                    }

                    double redeemAmount;
                    if (availableGrandTotal > giftCardRes.getBalance()) {
                        redeemAmount = giftCardRes.getBalance();
                    } else {
                        redeemAmount = availableGrandTotal;
                    }
                    giftCardRes.setCardNum(cardNum);
                    giftCardRes.setRedeemAmount(redeemAmount);

                    mCards.add(giftCardRes);
                    mAdapter.notifyDataSetChanged();
                    mRecyclerView.setVisibility(View.VISIBLE);
                    mRecyclerView.scrollToPosition(mCards.size() - 1);

                    mCardNumEditText.setText("");
                    mCardNumEditText.setError(null);
                    mSecureCodeEditText.setText("");
                    mSecureCodeEditText.setError(null);

                    ToastUtil.show(POSGiftCardActivity.this, getString(R.string.gc_card_added));

                }
            }
        }, new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();
                ToastUtil.show(POSGiftCardActivity.this, info.getMessage());
            }
        });

        VolleyUtil.addToRequestQueue(this, request);
    }

    private void setRecyclerView() {
        mRecyclerView = (RecyclerView) findViewById(R.id.posgc_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        if (getIntent() != null) {
            grandTotalWithoutGC = getIntent().getDoubleExtra(PARAM_GRAND_TOTAL_WITHOUT_GC, 0.0);
        }

        if (getIntent() != null && getIntent().getSerializableExtra(PARAM_GIFT_CARD_INFO) != null) {
            mCards = (ArrayList<GiftCardRes>) getIntent().getSerializableExtra(PARAM_GIFT_CARD_INFO);
            mRecyclerView.setVisibility(View.VISIBLE);
        }

        mAdapter = new GiftCardAdapter(mCards);
        mAdapter.setOnDeleteListener(new GiftCardAdapter.OnDeleteListener() {
            @Override
            public void onEmpty() {
                mRecyclerView.setVisibility(View.GONE);
            }
        });
        mRecyclerView.setAdapter(mAdapter);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBack();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        onBack();
        super.onBackPressed();
    }


    private void onBack() {
        Intent intent = new Intent();
        intent.putExtra(PARAM_GIFT_CARD_INFO, mCards);
        setResult(RESULT_OK, intent);
        finish();
    }
}
