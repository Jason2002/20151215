package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class POSSOReqDTO implements Serializable {
    @JSONField(name = "SOInfo")
    private SODTO soInfo;
    @JSONField(name = "PaymentInfo")
    private PaymentDTO paymentDTO;

    public SODTO getSoInfo() {
        return soInfo;
    }

    public void setSoInfo(SODTO soInfo) {
        this.soInfo = soInfo;
    }

    public PaymentDTO getPaymentDTO() {
        return paymentDTO;
    }

    public void setPaymentDTO(PaymentDTO paymentDTO) {
        this.paymentDTO = paymentDTO;
    }
}
