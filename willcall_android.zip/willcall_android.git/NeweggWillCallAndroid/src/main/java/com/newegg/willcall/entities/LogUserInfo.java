package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.utils.StringUtil;

import java.io.Serializable;
import java.util.List;

/**
 * Created by JaredLuo on 4/3/14.
 */
public class LogUserInfo implements Serializable {
    private static final long serialVersionUID = -9035043816494786105L;

    private static final String SPERATOR = "&";

    @JSONField(name = "UserID")
    private int userID;
    @JSONField(name = "Name")
    private String name;
    @JSONField(name = "LoginName")
    private String loginName;
    @JSONField(name = "PassWord")
    private String password;
    @JSONField(name = "Key")
    private String key;
    @JSONField(name = "Token")
    private String token;
    @JSONField(name = "AuthorizedWarehouseList")
    private List<Warehouse> authorizedWarehouseList;
    @JSONField(name = "POSAuthorizedWarehouseList")
    private List<Warehouse> posAuthorizedWarehouseList;

    public List<Warehouse> getPosAuthorizedWarehouseList() {
        return posAuthorizedWarehouseList;
    }

    public void setPosAuthorizedWarehouseList(List<Warehouse> posAuthorizedWarehouseList) {
        this.posAuthorizedWarehouseList = posAuthorizedWarehouseList;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        if (StringUtil.isEmpty(name)) {
            return loginName;
        }

        return name;
    }

    public String getTrimmedName() {
        String trimName = name;
        if (StringUtil.isEmpty(name)) {
            trimName = loginName;
        }

        if (trimName.length() > 10) {
            trimName = trimName.substring(0, 10);
        }

        return trimName;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public List<Warehouse> getAuthorizedWarehouseList() {
        return authorizedWarehouseList;
    }

    public void setAuthorizedWarehouseList(List<Warehouse> authorizedWarehouseList) {
        this.authorizedWarehouseList = authorizedWarehouseList;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAuthToken() {
        return getKey() + SPERATOR + getToken();
    }
}
