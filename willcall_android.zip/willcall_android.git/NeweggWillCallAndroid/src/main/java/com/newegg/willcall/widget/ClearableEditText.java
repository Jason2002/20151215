package com.newegg.willcall.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.EditText;

import com.newegg.willcall.R;

/**
 * Created by lenayan on 14-4-16.
 */
public class ClearableEditText extends EditText {


    private Bitmap mClearIconBitmap = null;

    private int mTextCount = 0;
    private int mClearIconGravity = Gravity.TOP;
    private int mClearIconTop = 0;
    private int mClearIconLeft = 0;
    private int mClearIconPadding = 0;
    private float mLastX = -1;
    private float mLastY = -1;

    private boolean mNeedInvalidate = true;
    private boolean mIsClearIconClipPadding = false;
    private boolean mIsClearIconDevision = true;
    private boolean mIsConfigChanged = false;


    public ClearableEditText(Context context) {
        this(context, null);
    }

    public ClearableEditText(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.editTextStyle);
    }

    public ClearableEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        Resources.Theme theme = context.getTheme();
        TypedArray typedArray = theme.obtainStyledAttributes(attrs, R.styleable.ClearableEditText, defStyle, 0);

        int count = typedArray.getIndexCount();
        for (int i = 0; i < count; i++) {
            int attr = typedArray.getIndex(i);
            switch (attr) {
                case R.styleable.ClearableEditText_clearIconPadding:
                    setClearIconPadding((int) typedArray.getDimension(attr, 0));
                    break;
                case R.styleable.ClearableEditText_clareIconDrawable:
                    Drawable drawable = typedArray.getDrawable(attr);
                    if (drawable != null)
                        mClearIconBitmap = ((BitmapDrawable) drawable).getBitmap();
                    break;
                case R.styleable.ClearableEditText_clearIconGravity:
                    setClearIconGravity(typedArray.getInt(attr, -1));
                    break;
                case R.styleable.ClearableEditText_clearIconClipParentPading:
                    mIsClearIconClipPadding = typedArray.getBoolean(attr, false);
                case R.styleable.ClearableEditText_clearIconDevision:
                    setClearIconDevision(typedArray.getBoolean(attr, true));
                    break;
                default:
                    break;
            }
        }
        typedArray.recycle();
    }

    @Override
    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mIsConfigChanged = true;
    }

    public void setClearIconDevision(boolean isClearIconDevision) {
        mIsClearIconDevision = isClearIconDevision;
    }

    public void setClearIconPadding(int clearIconPadding) {
        mClearIconPadding = clearIconPadding;
    }

    public void setClearIconClipPadding(boolean isClearIconClipPadding) {
        mIsClearIconClipPadding = isClearIconClipPadding;
    }

    public void setClearIconBitmap(Bitmap clearIconBitmap) {
        mClearIconBitmap = clearIconBitmap;
        invalidate();
    }

    public void setClearIconGravity(int clearIconGravity) {
        if (clearIconGravity == -1)
            return;
        if (clearIconGravity != mClearIconGravity) {
            mNeedInvalidate = true;
            mClearIconGravity = clearIconGravity;
            invalidate();
        }
    }

    public void setClearIconDrawableResoutce(int drawableID) {
        mClearIconBitmap = BitmapFactory.decodeResource(getResources(), drawableID);
        invalidate();
    }

    @Override
    public void setCompoundDrawables(Drawable left, Drawable top, Drawable right, Drawable bottom) {
        super.setCompoundDrawables(left, top, right, bottom);
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        final Bitmap bitmap = mClearIconBitmap;
        if (bitmap != null && mTextCount > 0) {
            if (mNeedInvalidate || mIsConfigChanged) {
                mNeedInvalidate = false;
                setupLeftTopOffset();
            }
            final int left = mClearIconLeft + getScrollX();
            final int top = mClearIconTop + getScrollY();
            final Paint paint = getPaint();
            canvas.drawBitmap(bitmap, left, top, paint);
        }
    }


    private void setupLeftTopOffset() {
        int verticalGravity = mClearIconGravity & Gravity.VERTICAL_GRAVITY_MASK;
        int topPadding = getPaddingTop();
        int bottomPadding = getPaddingBottom();
        int leftPadding = getPaddingLeft();
        int rightPadding = getPaddingRight();
        switch (verticalGravity) {
            case Gravity.TOP:
                topPadding += mClearIconPadding + mClearIconBitmap.getHeight() - 15;
                mClearIconTop = getTop() + (mIsClearIconClipPadding ? 0 : getPaddingTop()) + mClearIconPadding;
                break;
            case Gravity.BOTTOM:
                bottomPadding += mClearIconPadding + mClearIconBitmap.getHeight() - 15;
                mClearIconTop = getBottom() - mClearIconBitmap.getHeight() - (mIsClearIconClipPadding ? 0 : getPaddingBottom()) - mClearIconPadding;
                break;
            case Gravity.CENTER_VERTICAL:
                mClearIconTop = getTop() + (getBottom() - getTop() - mClearIconBitmap.getHeight()) / 2;
                break;
            default:
                mClearIconTop = getTop() + mClearIconPadding;
                break;
        }
        int horizonalGravity = mClearIconGravity & Gravity.HORIZONTAL_GRAVITY_MASK;
        switch (horizonalGravity) {
            case Gravity.LEFT:
                if (!mIsConfigChanged)
                    leftPadding += mClearIconPadding + mClearIconBitmap.getWidth() - 20;
                mClearIconLeft = getLeft() + (mIsClearIconClipPadding ? 0 : getPaddingLeft()) + mClearIconPadding;
                break;
            case Gravity.RIGHT:
                if (!mIsConfigChanged)
                    rightPadding += mClearIconPadding + mClearIconBitmap.getWidth() - 20;
                mClearIconLeft = getRight() - mClearIconBitmap.getWidth() - (mIsClearIconClipPadding ? 0 : getPaddingRight()) - mClearIconPadding;
                break;
            case Gravity.CENTER_HORIZONTAL:
                mClearIconLeft = getLeft() + (getRight() - getLeft() - mClearIconBitmap.getWidth()) / 2;
                break;
            default:
                mClearIconLeft = getLeft() + mClearIconPadding;
                break;
        }
        if (mIsClearIconDevision)
            setPadding(leftPadding, topPadding, rightPadding, bottomPadding);
        mIsConfigChanged = false;
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore,
                                 int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        mTextCount = text != null ? text.length() : 0;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        final float x = event.getX();
        final float y = event.getY();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                if (mTextCount > 0 && mClearIconBitmap != null && x > mClearIconLeft && x < mClearIconLeft + mClearIconBitmap.getWidth() && y < mClearIconTop + mClearIconBitmap.getHeight() && y > mClearIconTop) {
                    mLastX = event.getX();
                    mLastY = event.getY();
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                break;
            case MotionEvent.ACTION_UP:
                if (mLastX != -1 && mLastY != -1) {
                    if (x > mClearIconLeft && x < mClearIconLeft + mClearIconBitmap.getWidth() && y < mClearIconTop + mClearIconBitmap.getHeight() && y > mClearIconTop) {
                        setText("");
                    }
                    mLastX = -1;
                    mLastY = -1;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            default:
                break;
        }

        return super.onTouchEvent(event);
    }
}
