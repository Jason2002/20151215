package com.newegg.willcall.utils;

import android.util.Log;

import com.newegg.willcall.BuildConfig;

/**
 * Created by lenayan on 4/2/14.
 */
public class LogUtil {

    private final static String LOG_TAG = "NeweggWillCall";

    public static void i(String msg) {
        if (BuildConfig.DEBUG) {
            Log.i(LOG_TAG, msg);
        }
    }

    public static void e(String msg) {
        e(LOG_TAG, msg);
    }

    public static void e(String msg, Throwable throwable) {
        e(LOG_TAG, msg, throwable);
    }

    public static void i(String tag, String msg) {
        if (BuildConfig.DEBUG) {
            Log.i(tag, msg);
        }
    }

    public static void e(String tag, String msg) {
        if (BuildConfig.DEBUG) {
            Log.e(tag, msg);
        }
    }

    public static void e(String tag, String msg, Throwable throwable) {
        if (BuildConfig.DEBUG) {
            Log.e(tag, msg, throwable);
        }
    }

}
