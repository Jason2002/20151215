package com.newegg.willcall.entities.receiving;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-9.
 */
public class ReceivingPackageScanDTO extends ReceivingPackageReceiveDTO {

    @JSONField(name = "TrackingNumber")
    private String mTrackingNumber;

    public ReceivingPackageScanDTO(String trackingNumber, String userID, String wCCNumber) {
        super(userID, wCCNumber);
        this.mTrackingNumber = trackingNumber;
    }

    public String getTrackingNumber() {
        return mTrackingNumber;
    }

    public void setTrackingNumber(String mTrackingNumber) {
        this.mTrackingNumber = mTrackingNumber;
    }
}
