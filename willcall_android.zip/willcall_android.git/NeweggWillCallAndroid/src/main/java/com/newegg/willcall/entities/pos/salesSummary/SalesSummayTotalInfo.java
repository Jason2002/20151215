package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by flyerabc on 14/12/24.
 */
public class SalesSummayTotalInfo implements Serializable {
    @JSONField(name = "TotalOrderCount")
    private int totalOrderCount;

    @JSONField(name = "TotalSalesQty")
    private int totalSalesQty;

    @JSONField(name = "TotalSalesAmount")
    private BigDecimal totalSalesAmount;

    public int getTotalOrderCount() {
        return totalOrderCount;
    }

    public void setTotalOrderCount(int totalOrderCount) {
        this.totalOrderCount = totalOrderCount;
    }

    public int getTotalSalesQty() {
        return totalSalesQty;
    }

    public void setTotalSalesQty(int totalSalesQty) {
        this.totalSalesQty = totalSalesQty;
    }

    public BigDecimal getTotalSalesAmount() {
        return totalSalesAmount;
    }

    public void setTotalSalesAmount(BigDecimal totalSalesAmount) {
        this.totalSalesAmount = totalSalesAmount;
    }
}


