package com.newegg.willcall.activity.main;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.GridView;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.Response;
import com.newegg.willcall.MainActivity;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.adapter.WarehouseAdapter;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.cache.NeweggFileCache;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.LogInDTO;
import com.newegg.willcall.entities.LogUserInfo;
import com.newegg.willcall.entities.Warehouse;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.EncryptUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

public class WarehouseActivity extends BaseActivity {
    public static final String KEY_CACHE_KEY = "KEY";
    public static final String NAME_CACHE_KEY = "NAME";

    public static final String USER_WAREHOUSE_CACHE = "USER_WAREHOUSE_CACHE";
    public static final String USER_INFOR_CACHE = "USER_INFOR_CACHE";

    public static final String USER_WAREHOUSE_LIST_CACHE = "USER_WAREHOUSE_LIST_CACHE";

    public static final String PARAM_LOGIN_USER_ID = "PARAM_LOGIN_USER_ID";
    public static final String PARAM_LOGIN_PASSWORD = "PARAM_LOGIN_PASSWORD";
    public static final String PARAM_NEED_REMEMBER_PASSWORD = "PARAM_NEED_REMEMBER_PASSWORD";
    private ProgressBar progressBar;
    private GridView willcallGridView;
    private GridView posGridView;
    private View container;
    private WarehouseAdapter willCallAdapter;
    private WarehouseAdapter posAdapter;
    private View willcallContainer;
    private View posContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warehouse);

        if (getIntent() != null) {
            findView();

            String userId = getIntent().getStringExtra(PARAM_LOGIN_USER_ID);
            String password = getIntent().getStringExtra(PARAM_LOGIN_PASSWORD);
            boolean needRemember = getIntent().getBooleanExtra(PARAM_NEED_REMEMBER_PASSWORD, false);
            if (!StringUtil.isEmpty(userId) && !StringUtil.isEmpty(password)) {
                login(userId, password, needRemember);
            } else if (WillCallApp.getUser() != null) {
                bindUI(WillCallApp.getUser(), WillCallApp.getWarehouse());
            }
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void findView() {
        container = findViewById(R.id.container);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        willcallGridView = (GridView) findViewById(R.id.warehouse_gridview);
        posGridView = (GridView) findViewById(R.id.pos_location_gridview);
        willcallContainer = findViewById(R.id.warehouse_container);
        posContainer = findViewById(R.id.pos_location_container);
    }

    @Override
    public void onBackPressed() {
        back();
    }

    private void back() {
        finish();
        overridePendingTransition(R.anim.anim_down_in, R.anim.anim_down_out);
    }

    private void login(final String userId, final String password, final boolean needRemember) {
        LogInDTO logInDTO = new LogInDTO();
        logInDTO.setLoginName(userId);
        logInDTO.setPassword(password);

        FastJsonObjectRequest<LogUserInfo> request = new FastJsonObjectRequest<LogUserInfo>(this, LogUserInfo.class, Request.Method.POST, HttpConfig.LOGIN, logInDTO, new Response.Listener<LogUserInfo>() {
            @Override
            public void onResponse(LogUserInfo userInfo) {
                if (userInfo != null && (userInfo.getAuthorizedWarehouseList() != null && userInfo.getAuthorizedWarehouseList().size() > 0)
                        || (userInfo.getPosAuthorizedWarehouseList() != null && userInfo.getPosAuthorizedWarehouseList().size() > 0)) {
                    if (needRemember) {
                        try {
                            byte[] encrypted = EncryptUtil.encryptPwd(WarehouseActivity.this, password);
                            if (encrypted != null && encrypted.length >= 0) {
                                NeweggFileCache.getInstance().put(KEY_CACHE_KEY, encrypted);
                                NeweggFileCache.getInstance().put(NAME_CACHE_KEY, userId);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        NeweggFileCache.getInstance().remove(KEY_CACHE_KEY);
                        NeweggFileCache.getInstance().remove(NAME_CACHE_KEY);
                    }

                    NeweggFileCache.getInstance().put(USER_INFOR_CACHE, userInfo);
                    WillCallApp.setAuthKey(userInfo.getAuthToken());
                    WillCallApp.setUser(userInfo);

                    bindUI(userInfo, null);
                } else {
                    ToastUtil.show(WarehouseActivity.this, getString(R.string.login_no_warehouse));

                    back();
                }
            }
        }

                , new FastJsonObjectRequest.OnErrorListener()

        {
            @Override
            public void onError(ErrorResponseInfo info) {
                ToastUtil.show(WarehouseActivity.this, info.getMessage());
                back();
            }
        }
        );

        VolleyUtil.addToRequestQueue(this, request);
    }

    private void bindUI(LogUserInfo userInfo, Warehouse warehouse) {
//        if (userInfo.getAuthorizedWarehouseList().size() == 1) {
//            willcallGridView.setNumColumns(1);
//            posGridView.setNumColumns(1);
//        } else {
        willcallGridView.setNumColumns(2);
        posGridView.setNumColumns(2);
        //}
        container.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);

        if (userInfo.getAuthorizedWarehouseList() != null && userInfo.getAuthorizedWarehouseList().size() > 0) {
            willcallContainer.setVisibility(View.VISIBLE);
            willCallAdapter = new WarehouseAdapter(this, userInfo.getAuthorizedWarehouseList(), warehouse, MainActivity.APP_TYPE.APP_TYPE_WILLCALL);
            willcallGridView.setAdapter(willCallAdapter);
        } else {
            willcallContainer.setVisibility(View.GONE);
        }

        if (userInfo.getPosAuthorizedWarehouseList() != null && userInfo.getPosAuthorizedWarehouseList().size() > 0) {
            posContainer.setVisibility(View.VISIBLE);
            posAdapter = new WarehouseAdapter(this, userInfo.getPosAuthorizedWarehouseList(), warehouse, MainActivity.APP_TYPE.APP_TYPE_POS);
            posGridView.setAdapter(posAdapter);
        } else {
            posContainer.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }
}
