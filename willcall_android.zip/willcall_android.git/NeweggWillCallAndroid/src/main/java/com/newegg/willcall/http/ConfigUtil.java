package com.newegg.willcall.http;

import com.newegg.willcall.BuildConfig;

/**
 * Created by dy45 on 4/18/2015.
 */
public class ConfigUtil {

    public enum ServiceTypes {
        Local,Pre, Prd
    }

    public static ServiceTypes ServiceType;

    static {
        if(BuildConfig.BUILD_TYPE.equalsIgnoreCase("debug")){
            ServiceType = ServiceTypes.Local;
        }
        else if (BuildConfig.BUILD_TYPE.equalsIgnoreCase("pre")){
            ServiceType = ServiceTypes.Pre;
        }else{
            ServiceType = ServiceTypes.Prd;
        }
    }
}
