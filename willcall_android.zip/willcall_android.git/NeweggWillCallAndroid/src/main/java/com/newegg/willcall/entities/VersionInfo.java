package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by JaredLuo on 14-4-18.
 */
public class VersionInfo implements Serializable {
    @JSONField(name = "CurrentVersion")
    private String currentVersion;
    @JSONField(name = "IsForceUpgrade")
    private boolean isForceUpgrade;
    @JSONField(name = "UpgradeInformation")
    private String upgradeInformation;
    @JSONField(name = "UpgradeUrl")
    private String upgradeUrl;


    public String getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(String currentVersion) {
        this.currentVersion = currentVersion;
    }

    public boolean isForceUpgrade() {
        return isForceUpgrade;
    }

    public void setForceUpgrade(boolean isForceUpgrade) {
        this.isForceUpgrade = isForceUpgrade;
    }

    public String getUpgradeInformation() {
        return upgradeInformation;
    }

    public void setUpgradeInformation(String upgradeInformation) {
        this.upgradeInformation = upgradeInformation;
    }

    public String getUpgradeUrl() {
        return upgradeUrl;
    }

    public void setUpgradeUrl(String upgradeUrl) {
        this.upgradeUrl = upgradeUrl;
    }
}
