package com.newegg.willcall.entities.pos.order;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/31/14.
 */
public class CustomerEmailReq implements Serializable {
    private static final long serialVersionUID = 4023804483316020054L;
    public int soNumber;
    public String customerEmail;

    public int getSoNumber() {
        return soNumber;
    }

    public void setSoNumber(int soNumber) {
        this.soNumber = soNumber;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }
}
