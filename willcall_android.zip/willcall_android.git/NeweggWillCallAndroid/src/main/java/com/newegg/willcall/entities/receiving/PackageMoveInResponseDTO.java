package com.newegg.willcall.entities.receiving;

import com.alibaba.fastjson.annotation.JSONField;


/**
 * Created by cf86 on 4/16/2015.
 */
public class PackageMoveInResponseDTO  {

   // private static final long serialVersionUID = -7206334530108788476L;

    @JSONField(name = "IsSuccessful")
    private boolean successful;

    public boolean getIsSuccessful() {
        return successful;
    }

    public void setIsSuccessful(boolean isSuccessFull) {
        successful = isSuccessFull;
    }

    @JSONField(name = "ErrorMsg")
    private String m_errorMsg;

    public String getErrorMsg() {
        return m_errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        m_errorMsg = errorMsg;
    }
}
