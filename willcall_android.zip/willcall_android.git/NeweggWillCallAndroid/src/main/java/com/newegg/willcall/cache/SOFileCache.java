package com.newegg.willcall.cache;

import com.newegg.willcall.service.SOFileItem;
import com.newegg.willcall.utils.FileUtils;
import com.newegg.willcall.utils.ListUtil;
import com.newegg.willcall.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by dy45 on 5/29/2015.
 */
public class SOFileCache {
    private static String FilePath = "SOUploadList.txt";
    private static List<SOFileItem> mList;
    private static Object sync_lock = new Object();
    static{
        mList = readSOFile();
    }

    private static List<SOFileItem> readSOFile() {
        synchronized (sync_lock) {
            List<SOFileItem> list = FileUtils.readArray(FilePath,SOFileItem.class);
            if(list == null){
                list = new ArrayList<SOFileItem>(10);
            }
            return list;
        }
    }

    public static int getCount(){
        return mList.size();
    }


    public static void add(SOFileItem item){
        synchronized (sync_lock){
            mList.add(item);
            writeSOFile();
        }
    }

    public static SOFileItem pop(){
        synchronized (sync_lock){
            if (mList.size() > 0) {
                SOFileItem item = mList.remove(0);
                writeSOFile();
                return item;
            }
        }
        return null;
    }

    private static void writeSOFile(){
        FileUtils.writeObject(FilePath,mList);
    }
}
