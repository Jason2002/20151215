package com.newegg.willcall.http;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.newegg.willcall.R;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.utils.FileUtils;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jaredluo on 12/30/14.
 */
public class UploadFileRequest extends BaseRequest<String> {
    protected static final String CHARSET = "utf-8";

    private Response.Listener<String> listener;

    public File file;

    public UploadFileRequest(Context context,String url, File file
            , Response.Listener<String> listener
            ,BaseRequest.OnErrorListener errListener) {
        super(Method.POST, url,errListener,context);
        this.file = file;
        this.listener = listener;
        setRetryPolicy(new DefaultRetryPolicy(BaseRequest.SOCKET_LONG_TIMEOUT
                ,1
                ,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> headers = super.getHeaders();
        headers.put("Content-Length", String.valueOf(file.length()));
        headers.put("Content-Type", "application/x-www-form-urlencoded");

        return headers;
    }

    @Override
    protected Response<String> parseNetworkResponse(NetworkResponse networkResponse) {
        String result;
        try {
            result = new String(networkResponse.data, CHARSET);
            return Response.success(result, HttpHeaderParser.parseCacheHeaders(networkResponse));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return Response.error(new ParseError(e));
        }

    }

    @Override
    protected VolleyError parseNetworkError(VolleyError volleyError) {
        ErrorResponseInfo parsedErrorInfo = new ErrorResponseInfo();
        parsedErrorInfo.setStatusCode("-1");
        parsedErrorInfo.setMessage("Please check your network.");
        onError(parsedErrorInfo);
        return volleyError;
    }

    @Override
    protected void deliverResponse(String s) {
        listener.onResponse(s);
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        return FileUtils.fileToByteArray(file);
    }
}
