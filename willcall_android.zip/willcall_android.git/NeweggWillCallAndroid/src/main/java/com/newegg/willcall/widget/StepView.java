package com.newegg.willcall.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import com.newegg.willcall.R;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.ScreenUtil;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.ObjectAnimator;

/**
 * Created by JaredLuo on 14-4-8.
 */
public class StepView extends View {
    private int count = 4;
    private int currentStep;
    private Paint stepDesTextPaint;
    private Paint grayPaint;
    private Paint bluePaint;
    private Paint stepNumTextPaint;
    private RectF rect;

    private float lastStepPercent = 0f;

    public StepView(Context context) {
        super(context);
        init();
    }

    public StepView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public StepView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        stepDesTextPaint = new Paint();
        stepDesTextPaint.setAntiAlias(true);
        stepDesTextPaint.setStyle(Paint.Style.FILL);
        stepDesTextPaint.setTextSize(ScreenUtil.sp2px(9));
        stepDesTextPaint.setTextAlign(Paint.Align.LEFT);

        grayPaint = new Paint();
        grayPaint.setAntiAlias(true);
        grayPaint.setStyle(Paint.Style.FILL);
        grayPaint.setColor(getResources().getColor(R.color.gray));

        bluePaint = new Paint();
        bluePaint.setAntiAlias(true);
        bluePaint.setStyle(Paint.Style.FILL);
        bluePaint.setColor(getResources().getColor(R.color.blue));

        stepNumTextPaint = new Paint();
        stepNumTextPaint.setColor(Color.WHITE);
        stepNumTextPaint.setAntiAlias(true);
        stepNumTextPaint.setStyle(Paint.Style.FILL);
        stepNumTextPaint.setTextSize(ScreenUtil.getPxByDp(14));
        stepNumTextPaint.setTextAlign(Paint.Align.CENTER);

    }

    public void setStepCount(int stepCount) {
        this.count = stepCount;
    }

    public void setCurrentStep(int step) {
        LogUtil.i("test", step + "");
        if (step > count + 1) {
            throw new IllegalArgumentException("Current step can not exceeds max step.");
        }

        int oldStep = this.currentStep;
        this.currentStep = step;

        if (oldStep <= currentStep) {
            if (step != 1) {
                animateStep(false);
            } else {
                lastStepPercent = 1;
                invalidate();
            }
        } else {
            currentStep++;
            animateStep(true);
        }


    }

    public void nextStep() {
        if (currentStep > count + 1) {
            throw new IllegalArgumentException("Current step can not exceeds max step.");
        }
        this.currentStep++;
        invalidate();
    }

    public String[] getStepText() {
        return new String[]{"Customer Check", "Package Picking", "Item Confirmation", "Sign & Checkout"};
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float firstTextWidth = stepDesTextPaint.measureText(getStepText()[0]);
        float lastTextWidth = stepDesTextPaint.measureText(getStepText()[getStepText().length - 1]);

        int pointWidth = ScreenUtil.getPxByDp(18);

        int xOffset = (int) (firstTextWidth / 2) - pointWidth / 2;

        int width = (int) (getWidth() - xOffset - (lastTextWidth - pointWidth) / 2);

        int barTop = pointWidth / 2 - ScreenUtil.getPxByDp(3);
        int barBottom = pointWidth / 2 + ScreenUtil.getPxByDp(3);
        int barWidth = (width - pointWidth * count) / (count - 1);

        int magicOffset = ScreenUtil.getPxByDp(1);
        int selectOffset = ScreenUtil.getPxByDp(1.5f);

        for (int i = 0; i < count; i++) {

            canvas.drawCircle((pointWidth / 2) + i * (pointWidth + barWidth) + xOffset, pointWidth / 2, pointWidth / 2, grayPaint);


            if (i > 0) {
                if (rect == null) {
                    rect = new RectF();
                }
                rect.set(pointWidth - magicOffset + (i - 1) * (pointWidth + barWidth) + xOffset, barTop, i * (pointWidth + barWidth) + xOffset, barBottom);
                canvas.drawRect(rect, grayPaint);
                if (i < currentStep) {
                    if (i == currentStep - 1) {
                        rect.set(pointWidth + (i - 1) * (pointWidth + barWidth) + xOffset - selectOffset - magicOffset, barTop + selectOffset, (i - 1) * (pointWidth + barWidth) + pointWidth + barWidth * getLastStepPercent() + xOffset + selectOffset, barBottom - selectOffset);
                    } else {
                        rect.set(pointWidth + (i - 1) * (pointWidth + barWidth) + xOffset - selectOffset - magicOffset, barTop + selectOffset, i * (pointWidth + barWidth) + xOffset + selectOffset, barBottom - selectOffset);
                    }
                    canvas.drawRect(rect, bluePaint);


                }
            }

            if (i < currentStep) {
                if (i == currentStep - 1) {
                    if (getLastStepPercent() == 1)
                        canvas.drawCircle((pointWidth / 2) + i * (pointWidth + barWidth) + xOffset, pointWidth / 2, pointWidth / 2 - selectOffset, bluePaint);
                } else {
                    canvas.drawCircle((pointWidth / 2) + i * (pointWidth + barWidth) + xOffset, pointWidth / 2, pointWidth / 2 - selectOffset, bluePaint);
                }
            }


            canvas.drawText(String.valueOf(i + 1), (pointWidth / 2) + i * (pointWidth + barWidth) + xOffset, pointWidth * 3 / 4, stepNumTextPaint);

            if (i < currentStep) {
                stepDesTextPaint.setColor(getResources().getColor(R.color.timeline_complete_text_color));
            } else {
                stepDesTextPaint.setColor(getResources().getColor(R.color.timeline_text_color));
            }
            float textWidth = stepDesTextPaint.measureText(getStepText()[i]);
            canvas.drawText(getStepText()[i], xOffset + i * (pointWidth + barWidth) + pointWidth / 2 - textWidth / 2, ScreenUtil.getPxByDp(30), stepDesTextPaint);
        }
    }

    public void animateStep(final boolean inverse) {
        ObjectAnimator valueAnimator = ObjectAnimator.ofFloat(this, "lastStepPercent", inverse ? 1 : 0, inverse ? 0 : 1);
        valueAnimator.setDuration(500);
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.start();
        valueAnimator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (inverse) {
                    if (currentStep > 1) {
                        currentStep--;
                    }
                    setLastStepPercent(1);
                    invalidate();
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }

    public float getLastStepPercent() {
        return lastStepPercent;
    }

    public void setLastStepPercent(float lastStepPercent) {
        this.lastStepPercent = lastStepPercent;
        invalidate();
    }
}
