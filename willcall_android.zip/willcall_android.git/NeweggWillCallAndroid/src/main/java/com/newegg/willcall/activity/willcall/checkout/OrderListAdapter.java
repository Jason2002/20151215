package com.newegg.willcall.activity.willcall.checkout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.checkout.CheckOutItemInfo;
import com.newegg.willcall.entities.checkout.CheckOutPackageInfo;
import com.newegg.willcall.entities.checkout.CheckOutSoInfo;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.utils.ScreenUtil;
import com.newegg.willcall.utils.StringUtil;

import java.util.List;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class OrderListAdapter extends BaseAdapter {

    private final List<CheckOutSoInfo> mSos;
    private final Context mContext;
    private final String mName;
    private final boolean mIsShowPickLabel;

    public OrderListAdapter(Context context, ReferenceOrderPickingTask pickingTask, boolean isShowPickLabel) {
        this.mContext = context;
        this.mSos = pickingTask.getSoList();
        this.mName = pickingTask.getPickupPerson();
        this.mIsShowPickLabel = isShowPickLabel;
    }

    public List<CheckOutSoInfo> getSos() {
        return this.mSos;
    }

    @Override
    public int getCount() {
        return mSos.size();
    }

    @Override
    public CheckOutSoInfo getItem(int position) {
        return mSos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        ViewHolder holder;
        if (convertView == null || convertView.getTag() == null) {
            holder = new ViewHolder();

            convertView = inflater.inflate(R.layout.checkout_package_picking_cell, parent, false);
            holder.customerTextView = (TextView) convertView.findViewById(R.id.checkout_customer);
            holder.orderNumTextView = (TextView) convertView.findViewById(R.id.checkout_order_id);
            holder.packageContainer = (LinearLayout) convertView.findViewById(R.id.checkout_package_list_container);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        CheckOutSoInfo soInfo = getItem(position);

        holder.customerTextView.setText(mName);
        holder.orderNumTextView.setText(soInfo.getUniqueOrderNumber());

        List<CheckOutPackageInfo> packageInfos = soInfo.getPackageList();

        holder.packageContainer.removeAllViews();

        if (packageInfos != null) {
            for (int i = 0; i < packageInfos.size(); i++) {
                CheckOutPackageInfo packageInfo = packageInfos.get(i);

                FrameLayout packageCell = (FrameLayout) inflater.inflate(R.layout.checkout_package_picking_package_cell, holder.packageContainer, false);
                TextView packageNumTextView = (TextView) packageCell.findViewById(R.id.checkout_package_num);
                TextView packageLocationTextView = (TextView) packageCell.findViewById(R.id.checkout_package_location);
                TextView packageDescTextView = (TextView) packageCell.findViewById(R.id.checkout_package_desc);
                TextView packagePickedImageView = (TextView) packageCell.findViewById(R.id.checkout_has_picked_label);

                packageNumTextView.setText(i + 1 + ". " + packageInfo.getTrackingNumber());
                if (CheckOutPackageInfo.IS_SCANED_YES.equals(packageInfo.getIsScaned()) && mIsShowPickLabel) {
                    packageLocationTextView.setVisibility(View.GONE);
                } else if (!StringUtil.isEmpty(packageInfo.getLocation())) {
                    packageLocationTextView.setVisibility(View.VISIBLE);
                    packageLocationTextView.setText(mContext.getString(R.string.picking_location) + packageInfo.getLocation());
                } else {
                    packageLocationTextView.setVisibility(View.GONE);
                }
                packagePickedImageView.setVisibility((CheckOutPackageInfo.IS_SCANED_YES.equals(packageInfo.getIsScaned()) && mIsShowPickLabel) ? View.VISIBLE : View.GONE);

                StringBuilder descSB = new StringBuilder("");
                List<CheckOutItemInfo> itemInfos = packageInfo.getItemList();
                if (itemInfos != null) {
                    for (CheckOutItemInfo itemInfo : itemInfos) {
                        if (itemInfo != null) {
                            descSB.append(itemInfo.getQuantity());
                            descSB.append("×");
                            descSB.append(itemInfo.getItemNumber());
                            if (!StringUtil.isEmpty(itemInfo.getDescription())) {
                                descSB.append("(");
                                descSB.append(itemInfo.getDescription());
                                descSB.append(")");
                            }
                            packageDescTextView.setText(descSB.toString());
                        }
                    }

                    holder.packageContainer.addView(packageCell, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                    if (i < packageInfos.size() - 1) {
                        View dividerView = new View(mContext);
                        dividerView.setBackgroundResource(R.color.divider_color);
                        holder.packageContainer.addView(dividerView, LinearLayout.LayoutParams.MATCH_PARENT, ScreenUtil.getPxByDp(2));
                    }
                }
            }
        }

        return convertView;
    }


    public int getPositionByItemTrackingNumber(String trackingNumber) {
        int count = getCount();
        for (int i = 0; i < count; i++) {
            CheckOutSoInfo soInfo = getItem(i);
            for(CheckOutPackageInfo pkgInfo : soInfo.getPackageList()) {
                if (pkgInfo.getTrackingNumber().toLowerCase().equals(trackingNumber.toLowerCase())) {
                    return i;
                }
            }
        }
        return -1;
    }

    private static class ViewHolder {
        public TextView customerTextView;
        public TextView orderNumTextView;
        public LinearLayout packageContainer;

    }
}
