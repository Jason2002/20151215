package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.http.ConfigUtil;
import com.newegg.willcall.utils.StringUtil;

import java.io.Serializable;
import java.util.List;

/**
 * Created by JaredLuo on 4/3/14.
 */
public class Warehouse implements Serializable {
    private static final long serialVersionUID = 939472011888332862L;

    public static final String MENU_PACKAGE_PACKAGERECEIVING = "Menu_Package_PackageReceiving";
    public static final String MENU_ORDER_ORDERCHECKOUT = "Menu_Order_OrderCheckOut";
    public static final String MENU_PACKAGE_EXPIREDPACKAGEPICKING = "Menu_Package_ExpiredPackagePicking";
    public static final String MENU_PACKAGE_PACKAGEDEPARTURE = "Menu_Package_PackageDeparture";
    public static final String MENU_PACKAGE_PACKAGEMOVEIN="Menu_Package_PackageMoveIn";
    public static final String MENU_PACKAGE_PACKING_TASKLIST ="Menu_Order_CheckOut_PickingTaskList";

    @JSONField(name = "Code")
    private String code;
    @JSONField(name = "WareHouseName")
    private String warehouseName;
    @JSONField(name = "Description")
    private String description;
    @JSONField(name = "Address1")
    private String address1;
    @JSONField(name = "Address2")
    private String address2;
    @JSONField(name = "Country")
    private String country;
    @JSONField(name = "City")
    private String city;
    @JSONField(name = "State")
    private String state;
    @JSONField(name = "ZipCode")
    private String zipCode;
    @JSONField(name = "ContactWith")
    private String contactWith;
    @JSONField(name = "PhoneNumber")
    private String phoneNumber;
    @JSONField(name = "FaxNumber")
    private String faxNumber;
    @JSONField(name = "TaxRate")
    private double taxRate;
    @JSONField(name = "WCCUserFunctionList")
    private List<String> wccUserFunctionList;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getContactWith() {
        return contactWith;
    }

    public void setContactWith(String contactWith) {
        this.contactWith = contactWith;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getWarehouseName() {
        if (!StringUtil.isEmpty(warehouseName)) {
            return warehouseName.trim();
        }
        return "";
    }

    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName;
    }

    public List<String> getWccUserFunctionList() {
        return wccUserFunctionList;
    }

    public void setWccUserFunctionList(List<String> wccUserFunctionList) {
        this.wccUserFunctionList = wccUserFunctionList;
    }

    public boolean hasReceivingPrivilege() {
        return containPrivilege(MENU_PACKAGE_PACKAGERECEIVING);
    }

    public boolean hasMoveInPrivilege()
    {
        return  containPrivilege(MENU_PACKAGE_PACKAGEMOVEIN);
    }

    public boolean hasCheckoutPrivilege() {
        return containPrivilege(MENU_ORDER_ORDERCHECKOUT);
    }

    public boolean hasExpiredPrivilege() {
        return containPrivilege(MENU_PACKAGE_EXPIREDPACKAGEPICKING);
    }

    public boolean hasPackageTaskList(){
        return containPrivilege(MENU_PACKAGE_PACKING_TASKLIST);
    }


    public boolean hasDeparturePrivilege() {
        return containPrivilege(MENU_PACKAGE_PACKAGEDEPARTURE);
    }

    private boolean containPrivilege(String privilegeName) {
        if(ConfigUtil.ServiceType == ConfigUtil.ServiceTypes.Local){
            return true;
        }
        if (getWccUserFunctionList() != null && getWccUserFunctionList().size() > 0) {
            for (String havePrivilegeName : getWccUserFunctionList()) {
                if (privilegeName.equalsIgnoreCase(havePrivilegeName)) {
                    return true;
                }
            }
        }
        return false;
    }
}
