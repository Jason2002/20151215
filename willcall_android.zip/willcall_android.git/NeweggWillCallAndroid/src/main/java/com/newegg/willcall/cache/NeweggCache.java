package com.newegg.willcall.cache;

public interface NeweggCache {

    public abstract <T> T get(String key);

    public abstract <T> T get(String key, T defaultValue);

    public abstract <T> void put(String key, T value);

    public abstract int remove(String key);

    public abstract boolean exists(String key);
}