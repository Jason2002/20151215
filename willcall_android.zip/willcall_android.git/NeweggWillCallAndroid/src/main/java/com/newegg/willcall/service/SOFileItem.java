package com.newegg.willcall.service;

import java.io.Serializable;

/**
 * Created by dy45 on 5/29/2015.
 */
public class SOFileItem implements Serializable {
    private String orderNumber;
    private String orderType;
    private String filePath;

    public SOFileItem(String orderNumber, String orderType, String filePath) {
        this.orderNumber = orderNumber;
        this.orderType = orderType;
        this.filePath = filePath;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
