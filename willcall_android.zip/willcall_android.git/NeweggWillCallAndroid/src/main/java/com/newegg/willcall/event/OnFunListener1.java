package com.newegg.willcall.event;

/**
 * Created by dy45 on 4/14/2015.
 */
public interface OnFunListener1<T,R> {
    R fun(T t);
}
