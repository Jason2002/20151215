package com.newegg.willcall.activity.pos.salesSummary;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseFragment;
import com.newegg.willcall.adapter.HeaderViewRecyclerAdapter;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.salesSummary.POSOrderDetail;
import com.newegg.willcall.entities.pos.salesSummary.SalesOrderDetailInfo;
import com.newegg.willcall.entities.pos.salesSummary.SalesSummaryDTO;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.ToastUtil;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SalesFragment extends BaseFragment implements DatePickerFragment.OnDateSetListener, SalesSummaryActivity.OnSearchListener{
    private View mFromButton;
    private View mToButton;
    private TextView mFromValueTextView;
    private TextView mToValueTextView;
    private TextView mTotalRevenueTextView;
    private TextView mTotalSoldQtyTextView;
    private TextView mTotalOrdersTextView;
    private View mMainView;
    private View mHeaderView;
    private RecyclerView mRecyclerView;

    private HeaderViewRecyclerAdapter mAdapter;
    private List<SalesOrderDetailInfo> mList = new ArrayList<SalesOrderDetailInfo>();
    private Date mFromDate = new Date(new Date().getTime() - (1000 * 60 * 60 * 24 * 3));
    private Date mToDate = new Date();
    private Boolean mIsFromDate;
    private SimpleDateFormat mDateFormat = new SimpleDateFormat("yyyy/MM/dd");
    private Context mContext;

    public static SalesFragment newInstance() {
        SalesFragment fragment = new SalesFragment();
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = getActivity();
        mMainView = inflater.inflate(R.layout.pos_sales_summary_sales, container, false);
        mRecyclerView = (RecyclerView) mMainView.findViewById(R.id.recycler_view);

        mHeaderView  = inflater.inflate(R.layout.pos_sales_summary_sales_header, container, false);
        mFromButton = mHeaderView.findViewById(R.id.btn_From);
        mToButton = mHeaderView.findViewById(R.id.btn_To);
        mFromValueTextView = (TextView)mHeaderView.findViewById(R.id.from_date_TextView);
        mToValueTextView = (TextView)mHeaderView.findViewById(R.id.to_date_TextView);
        mTotalRevenueTextView = (TextView)mHeaderView.findViewById(R.id.total_revenue_textView);
        mTotalSoldQtyTextView = (TextView)mHeaderView.findViewById(R.id.total_sold_qty_textView);
        mTotalOrdersTextView = (TextView)mHeaderView.findViewById(R.id.total_orders_textView);

        mFromButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mIsFromDate = true;
                DatePickerFragment fragment = DatePickerFragment.newInstance(mFromDate, getString(R.string.salesSummary_From));
                fragment.setTargetFragment(SalesFragment.this, 0);
                fragment.show(getActivity().getSupportFragmentManager(), "FromTimePickerFragment");
            }
        });

        mToButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mIsFromDate = false;
                DatePickerFragment fragment = DatePickerFragment.newInstance(mToDate, getString(R.string.salesSummary_To));
                fragment.setTargetFragment(SalesFragment.this, 0);
                fragment.show(getActivity().getSupportFragmentManager(), "ToTimePickerFragment");
            }
        });

        setDateText(mFromValueTextView, mFromDate);
        setDateText(mToValueTextView, mToDate);

        mAdapter = new HeaderViewRecyclerAdapter(new SalesRecyclerAdapter(mList));
        mAdapter.addHeaderView(mHeaderView);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mAdapter);

        callService();

        return mMainView;
    }

    @Override
    public void onDateSet(Date date) {
        if(mIsFromDate){
            mFromDate = date;
            setDateText(mFromValueTextView, mFromDate);
            callService();
        }else{
            mToDate = date;
            setDateText(mToValueTextView, mToDate);
            callService();
        }
    }

    private void setDateText(TextView view, Date date){
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        view.setText(format.format(date));
    }

    private void callService(){
        showProgressDialog();
        String url = HttpConfig.getFormatUrl(HttpConfig.POS_SUMMARY_SALES, WillCallApp.getWarehouse().getCode(), mDateFormat.format(mFromDate), mDateFormat.format(mToDate));
        FastJsonObjectRequest<SalesSummaryDTO> request = new FastJsonObjectRequest<SalesSummaryDTO>(mContext, SalesSummaryDTO.class,
                url, new Response.Listener<SalesSummaryDTO>() {
            @Override
            public void onResponse(SalesSummaryDTO result) {
                hideProgressDialog();
                BindData(result);
            }
        }, new FastJsonObjectRequest.OnErrorListener() {

            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();
                if(info != null && info.getMessage() != null){
                    ToastUtil.show(mContext, info.getMessage());
                }
            }
        });

        VolleyUtil.addToRequestQueue(mContext, request);
    }

    private void BindData(SalesSummaryDTO info){
        mList.clear();
        if(info == null || info.getSummary() == null){
            mTotalRevenueTextView.setText(CurrencyUtils.getCurrencyFormat(new BigDecimal("0")));
            mTotalSoldQtyTextView.setText("0");
            mTotalOrdersTextView.setText("0");
        }else {
            mTotalRevenueTextView.setText(CurrencyUtils.getCurrencyFormat(info.getSummary().getTotalSalesAmount()));
            mTotalSoldQtyTextView.setText("" + info.getSummary().getTotalSalesQty());
            mTotalOrdersTextView.setText("" + info.getSummary().getTotalOrderCount());
            mList.addAll(info.getSOList());
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void doSearch(final String input) {
        int orderNumber;
        try {
            orderNumber = Integer.valueOf(input);
        } catch (Exception ex) {
            ToastUtil.show(mContext, getString(R.string.pos_return_error_invalid_order_number));
            return;
        }

        showProgressDialog(mContext);
        String url = HttpConfig.getFormatUrl(HttpConfig.POS_SUMMARY_ORDER_DETAIL, String.valueOf(orderNumber));
        FastJsonObjectRequest<POSOrderDetail> request = new FastJsonObjectRequest<POSOrderDetail>(mContext, POSOrderDetail.class,
                url, new Response.Listener<POSOrderDetail>() {
            @Override
            public void onResponse(POSOrderDetail result) {
                hideProgressDialog();
                if(result != null){
                    Intent intent = new Intent(mContext, POSOrderDetailActivity.class);
                    intent.putExtra(POSOrderDetailActivity.EXTRA_ORDER_INFO, result);
                    mContext.startActivity(intent);
                }
            }
        }, new FastJsonObjectRequest.OnErrorListener() {

            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();
                if(info != null && info.getMessage() != null){
                    ToastUtil.show(mContext, info.getMessage());
                }
            }
        });

        VolleyUtil.addToRequestQueue(mContext, request);
    }
}
