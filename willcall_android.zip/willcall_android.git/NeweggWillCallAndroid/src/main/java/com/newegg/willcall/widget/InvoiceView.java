package com.newegg.willcall.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.newegg.willcall.R;

/**
 * Created by JaredLuo on 14-12-23.
 */
public class InvoiceView extends LinearLayout {

    public InvoiceView(Context context) {
        super(context);
    }

    public InvoiceView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public InvoiceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }




    public Bitmap getBitmap() {
        measure(MeasureSpec.makeMeasureSpec(595, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        Bitmap b = Bitmap.createBitmap(595, getMeasuredHeight(), Bitmap.Config.ARGB_4444);

        Canvas c = new Canvas(b);
        //Drawable oldBackground = getBackground();

        layout(0, 0, 595, getMeasuredHeight());

        //setBackgroundColor(getResources().getColor(R.color.white));
        draw(c);
        //setBackgroundDrawable(oldBackground);
        return b;
    }
}