package com.newegg.willcall.activity.pos.order;

import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.pos.order.CartInfo;
import com.newegg.willcall.entities.pos.order.ItemBase;
import com.newegg.willcall.entities.pos.order.ItemInfo;
import com.newegg.willcall.entities.pos.order.ItemInfoResDTO;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.ToastUtil;

import java.util.List;

/**
 * Created by jaredluo on 12/19/14.
 */

public class CartAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static int ITEM_TYPE_NORMAL = 0;
    private static int ITEM_TYPE_FOOTER = 1;

    private CartInfo info;
    private List<ItemInfo> items;

    private OnEditSubTotal listener;

    public void setOnEditSubTotal(OnEditSubTotal listener) {
        this.listener = listener;
    }

    public CartAdapter(CartInfo info) {
        this.info = info;
        this.items = info.getItems();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());


        if (viewType == ITEM_TYPE_NORMAL) {
            View cellView = inflater.inflate(R.layout.poscart_cell, parent, false);
            ViewHolder holder = new ViewHolder(cellView);
            holder.titleTv = (TextView) cellView.findViewById(R.id.cart_cell_title);
            holder.snTv = (TextView) cellView.findViewById(R.id.cart_cell_sn);
            holder.priceTv = (TextView) cellView.findViewById(R.id.cart_cell_price);
            holder.qtyTv = (TextView) cellView.findViewById(R.id.cart_cell_qty);
            holder.divider = cellView.findViewById(R.id.cart_cell_divider);
            holder.rmBtn = (ImageButton) cellView.findViewById(R.id.cart_remove_btn);
            return holder;
        } else {
            View footerView = inflater.inflate(R.layout.poscart_footer, parent, false);
            ViewFooterHolder holder = new ViewFooterHolder(footerView);
            holder.ewraContainer = footerView.findViewById(R.id.cart_footer_ewra_container);
            holder.subtotalTv = (TextView) footerView.findViewById(R.id.cart_footer_subtotal);
            holder.ewraTv = (TextView) footerView.findViewById(R.id.cart_footer_ewra);
            holder.taxTv = (TextView) footerView.findViewById(R.id.cart_footer_tax);
            holder.discountTv = (TextView) footerView.findViewById(R.id.cart_footer_discount);
            holder.giftCardTv = (TextView) footerView.findViewById(R.id.cart_footer_gift_card);
            holder.grandTotalTv = (TextView) footerView.findViewById(R.id.cart_footer_grand_total);
            holder.taxCheckbox = (CheckBox) footerView.findViewById(R.id.cart_footer_tax_checkbox);
            holder.editDiscountBtn = (ImageButton) footerView.findViewById(R.id.edit_discount_btn);
            holder.editGiftcardBtn = (ImageButton) footerView.findViewById(R.id.edit_giftcard_btn);
            return holder;
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof ViewHolder) {

            ViewHolder viewHolder = (ViewHolder) holder;
            ItemInfo item = items.get(position);
            if (item == null) {
                return;
            }

//            if(position == 2){
//                setAnimation(viewHolder.itemView, position);
//                return;
//            }

            viewHolder.titleTv.setText(item.getLongDescription());
            StringBuilder sb = new StringBuilder("");
            for (String value : item.getBarcodeValues()) {
                sb.append("Serial Number: " + value + "\r\n");
            }
            viewHolder.snTv.setText(sb.toString());
            viewHolder.qtyTv.setText("" + item.getQty());
            SpannableStringBuilder ssb = new SpannableStringBuilder(CurrencyUtils.getCurrencyFormat(item.getUnitPrice().multiply(item.getQty())) + "");
            ssb.setSpan(new RelativeSizeSpan(0.5f), ssb.length() - 3, ssb.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            viewHolder.priceTv.setText(ssb);

            if (position == getItemCount() - 2) {
                viewHolder.divider.setVisibility(View.INVISIBLE);
            } else {
                viewHolder.divider.setVisibility(View.VISIBLE);
            }

            //TODO:for test
            viewHolder.rmBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //TODO:

                }
            });

        } else {
            ViewFooterHolder viewHolder = (ViewFooterHolder) holder;
            viewHolder.subtotalTv.setText(CurrencyUtils.getCurrencyFormat(info.getSubtotal()));
            if (info.getTotalEwra().doubleValue() > 0) {
                viewHolder.ewraContainer.setVisibility(View.VISIBLE);
                viewHolder.ewraTv.setText(CurrencyUtils.getCurrencyFormat(info.getTotalEwra()));
            } else {
                viewHolder.ewraContainer.setVisibility(View.GONE);
            }

            if (!viewHolder.taxCheckbox.isChecked()) {
                viewHolder.taxTv.setText(viewHolder.taxTv.getContext().getString(R.string.pos_checkout_tax_waived));
            } else {
                viewHolder.taxTv.setText(CurrencyUtils.getCurrencyFormat(info.getTotalTax()));
            }
            viewHolder.discountTv.setText("-" + CurrencyUtils.getCurrencyFormat(info.getTotalDiscount()));
            viewHolder.giftCardTv.setText("-" + CurrencyUtils.getCurrencyFormat(info.getTotalGC()));

            viewHolder.grandTotalTv.setText(CurrencyUtils.getCurrencyFormat(info.getGrandTotal()));
            viewHolder.taxCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        info.setTaxRate(WillCallApp.getWarehouse().getTaxRate());
                        notifyDataSetChanged();
                    } else {
                        info.setTaxRate(0.0);
                        info.needReduceGiftCard();
                        notifyDataSetChanged();
                    }
                }
            });

            viewHolder.editDiscountBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onEditDiscount();
                    }
                }
            });
            viewHolder.editGiftcardBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onEditGiftCard();
                    }
                }
            });
        }
    }

    private void setAnimation(View itemView, int position) {
        Animation animation = AnimationUtils.loadAnimation(itemView.getContext(), android.R.anim.slide_out_right);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        itemView.startAnimation(animation);
    }

    @Override
    public int getItemCount() {
        if (items != null && items.size() > 0) {
            return items.size() + 1;
        }
        return 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView titleTv;
        public TextView snTv;
        public TextView priceTv;
        public TextView qtyTv;
        public View divider;
        public ImageButton rmBtn;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public static class ViewFooterHolder extends RecyclerView.ViewHolder {
        public View ewraContainer;
        public TextView subtotalTv;
        public TextView ewraTv;
        public TextView taxTv;
        public TextView discountTv;
        public TextView giftCardTv;
        public TextView grandTotalTv;
        public CheckBox taxCheckbox;
        public ImageButton editGiftcardBtn;
        public ImageButton editDiscountBtn;

        public ViewFooterHolder(View itemView) {
            super(itemView);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (position == getItemCount() - 1) {
            return ITEM_TYPE_FOOTER;
        }
        return ITEM_TYPE_NORMAL;
    }

    public interface OnEditSubTotal {
        void onEditDiscount();

        void onEditGiftCard();
    }
}
