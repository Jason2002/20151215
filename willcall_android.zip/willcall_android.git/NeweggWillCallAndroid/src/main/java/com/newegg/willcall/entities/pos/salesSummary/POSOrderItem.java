package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSOrderItem implements Serializable {
    private static final long serialVersionUID = -4465555679237483940L;
    @JSONField(name = "Description")
    private String description;
    @JSONField(name = "ItemNumber")
    private String itemNumber;
    @JSONField(name = "Quantity")
    private int quantity;
    @JSONField(name = "UnitPrice")
    private BigDecimal unitPrice;
    @JSONField(name = "ExtendPrice")
    private BigDecimal extendPrice;

    @JSONField(name = "ItemSNList")
    private List<POSOrderSNItem> itemSNList;

    public BigDecimal getExtendPrice() {
        return extendPrice;
    }

    public void setExtendPrice(BigDecimal extendPrice) {
        this.extendPrice = extendPrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public List<POSOrderSNItem> getItemSNList() {
        return itemSNList;
    }

    public void setItemSNList(List<POSOrderSNItem> itemSNList) {
        this.itemSNList = itemSNList;
    }
}
