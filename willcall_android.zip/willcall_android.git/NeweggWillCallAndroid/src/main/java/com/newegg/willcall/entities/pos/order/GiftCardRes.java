package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.utils.CurrencyUtils;

import org.apache.commons.math3.util.Decimal64;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/26/14.
 */
public class GiftCardRes extends ErrorResponseInfo implements Serializable {
    private static final long serialVersionUID = -4518526127121453897L;
    @JSONField(name = "Amount")
    private double amount;
    @JSONField(name = "Balance")
    private double balance;

    private String cardNum;
    private double redeemAmount;

    public double getRedeemAmount() {
        return redeemAmount;
    }

    public Decimal64 getFormatRedeemAmount(){
        return CurrencyUtils.getCellWith2Digit(new Decimal64(redeemAmount));
    }

    public void setRedeemAmount(double redeemAmount) {
        this.redeemAmount = redeemAmount;
    }

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
