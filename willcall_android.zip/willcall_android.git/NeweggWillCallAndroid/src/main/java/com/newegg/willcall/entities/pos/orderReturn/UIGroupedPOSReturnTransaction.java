package com.newegg.willcall.entities.pos.orderReturn;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class UIGroupedPOSReturnTransaction implements Serializable {
    private String itemNumber;

    private List<String> serialNumberList;

    private String itemDescption;

    private BigDecimal unitPrice;

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public List<String> getSerialNumberList() {
        return serialNumberList;
    }

    public void setSerialNumberList(List<String> serialNumberList) {
        this.serialNumberList = serialNumberList;
    }

    public String getItemDescption() {
        return itemDescption;
    }

    public void setItemDescption(String itemDescption) {
        this.itemDescption = itemDescption;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }



}