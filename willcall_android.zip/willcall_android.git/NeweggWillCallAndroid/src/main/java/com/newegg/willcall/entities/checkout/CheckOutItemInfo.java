package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class CheckOutItemInfo implements Serializable {
    private static final long serialVersionUID = -5846256271440758134L;
    @JSONField(name = "TrackingNumber")
    private String trackingNumber;
    @JSONField(name = "Quantity")
    private int quantity;
    @JSONField(name = "ItemNumber")
    private String itemNumber;
    @JSONField(name = "Description")
    private String description;

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
