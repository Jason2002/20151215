package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by flyerabc on 14/12/24.
 */
public class SalesOrderDetailInfo implements Serializable {
    @JSONField(name = "SONumber")
    private int SONumber;

    @JSONField(name = "Revenue")
    private BigDecimal revenue;

    @JSONField(name = "SoldQty")
    private int soldQty;

    public int getSONumber() {
        return SONumber;
    }

    public void setSONumber(int SONumber) {
        this.SONumber = SONumber;
    }

    public BigDecimal getRevenue() {
        return revenue;
    }

    public void setRevenue(BigDecimal revenue) {
        this.revenue = revenue;
    }

    public int getSoldQty() {
        return soldQty;
    }

    public void setSoldQty(int soldQty) {
        this.soldQty = soldQty;
    }
}


