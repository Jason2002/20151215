package com.newegg.willcall.activity.account;

import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;

/**
 * Created by lenayan on 14-4-17.
 */
public class AboutUsActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        TextView titleTextView = (TextView) findViewById(R.id.logo_title);
//        titleTextView.setText("Test");
        titleTextView.setText(getFormatTitle("Newegg " + getString(R.string.app_name), "\nfor Android " + getString(R.string.app_version_name), getResources().getColor(R.color.main_text_color), getResources().getColor(R.color.secondary_text_color), (int) titleTextView.getTextSize()));
    }

    private Spannable getFormatTitle(String preFixString, String sufixString, int prefixColor, int sufixColor, int textSize) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        spannableStringBuilder.append(preFixString);
        spannableStringBuilder.setSpan(new ForegroundColorSpan(prefixColor), 0, preFixString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.setSpan(new AbsoluteSizeSpan(textSize), 0, preFixString.length() - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.append(sufixString);
        spannableStringBuilder.setSpan(new ForegroundColorSpan(sufixColor), preFixString.length(), spannableStringBuilder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.setSpan(new AbsoluteSizeSpan(textSize - 10), preFixString.length(), spannableStringBuilder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableStringBuilder;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.findItem(R.id.action_about_us);
        menuItem.setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }
}
