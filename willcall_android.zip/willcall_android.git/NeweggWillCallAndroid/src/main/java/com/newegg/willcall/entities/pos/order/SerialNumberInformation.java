package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class SerialNumberInformation implements Serializable{
    private static final long serialVersionUID = 157461679749907701L;
    @JSONField(name = "ItemNumber")
    private String itemNumber;
    @JSONField(name = "SerialNumber")
    private String serialNumber;

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
