package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class PickingTaskDTO implements Serializable {
    private static final long serialVersionUID = 6727729596763002682L;
    @JSONField(name = "UniqueOrderNumbers")
    private String uniqueOrderNumbers;
    @JSONField(name = "UserID")
    private String userID;
    @JSONField(name = "WCCNumber")
    private String wccNumber;


    public String getUniqueOrderNumbers() {
        return uniqueOrderNumbers;
    }

    public void setUniqueOrderNumbers(String uniqueOrderNumbers) {
        this.uniqueOrderNumbers = uniqueOrderNumbers;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getWccNumber() {
        return wccNumber;
    }

    public void setWccNumber(String wccNumber) {
        this.wccNumber = wccNumber;
    }
}
