package com.newegg.willcall.activity.willcall.picking;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.adapter.PackageListPickingAdapter;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.BooleanResponse;
import com.newegg.willcall.entities.picking.ExpiredTrackingInfo;
import com.newegg.willcall.entities.picking.ScanExpiredTrackingDTO;
import com.newegg.willcall.http.FastJsonArrayRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.listener.OnDataSetChangedListener;
import com.newegg.willcall.scan.CaptureActivity;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.util.List;

/**
 * Created by lenayan on 14-4-10.
 */
public class ExpiredPackagePickingActivity extends BaseActivity {

    private static final int REQUEST_CODE = 0x13;

    private View mContentView = null;
    private View mLoadingView = null;
    private View mErrorView = null;
    private View mEmptyView = null;

    private ListView mPackageListView = null;
    private EditText mInputEditText = null;
    private TextView mScandedCountTextView = null;
    private TextView mPackageListTotalCountTextView = null;
    private Button mPickingingBtn = null;

    private PackageListPickingAdapter mPickingAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picking_expire_package);

        if (!WillCallApp.getWarehouse().hasExpiredPrivilege()) {
            ToastUtil.show(this, getString(R.string.privilege_error));
            finish();
            return;
        }

        initView();
        getExpiredPackages();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null && !TextUtils.isEmpty(data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY))) {
            String trackingNumnber = data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY);
            mInputEditText.setText("");
            mInputEditText.append(trackingNumnber);
            pickingScan(trackingNumnber);
        }
    }

    private void initView() {
        mContentView = findViewById(R.id.picking_content);
        mLoadingView = findViewById(R.id.loading_layout);
        mErrorView = findViewById(R.id.error_layout);
        mEmptyView = findViewById(R.id.empty_layout);

        TextView emptyTitle = (TextView) mEmptyView.findViewById(R.id.empty_title);
        emptyTitle.setText(getString(R.string.picking_empty));

        mPackageListView = (ListView) findViewById(R.id.package_list);
        mInputEditText = (EditText) findViewById(R.id.package_list_input_edit_text);
        mScandedCountTextView = (TextView) findViewById(R.id.package_list_count);
        mPickingingBtn = (Button) findViewById(R.id.picking_btn);

        mInputEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN && !TextUtils.isEmpty(mInputEditText.getText())) {
                    pickingScan(formatInputTrackingNumber(mInputEditText.getText().toString()));
                    return true;
                }
                return false;
            }
        });
        View headerView = LayoutInflater.from(this).inflate(R.layout.package_list_header_layout, mPackageListView, false);
        TextView headerTitleTextView = (TextView) headerView.findViewById(R.id.title);
        mPackageListTotalCountTextView = (TextView) headerView.findViewById(R.id.total_count);
        headerTitleTextView.setText(getString(R.string.picking_package_list_header));
        mPackageListTotalCountTextView.setVisibility(View.VISIBLE);
        mPackageListView.addHeaderView(headerView);
    }

    private String formatInputTrackingNumber(String inputValue) {
        String prefix = getString(R.string.tracking_number_prefix);
        String lowerCasePreFix = prefix.toLowerCase();
        if (inputValue.startsWith(prefix))
            return inputValue;
        if (inputValue.startsWith(lowerCasePreFix))
            return inputValue.replace(lowerCasePreFix, prefix);
        if (inputValue.toLowerCase().contains(lowerCasePreFix))
            return inputValue.toLowerCase().replace(lowerCasePreFix, prefix);
        if (StringUtil.isNumeric(inputValue))
            return prefix + inputValue;
        return inputValue;
    }

    private void controlCountViewStatus() {
        boolean hasScanedPackages = mPickingAdapter.getScanedPackagesCount() > 0;
        mScandedCountTextView.setVisibility(hasScanedPackages ? View.VISIBLE : View.GONE);
        mScandedCountTextView.setText(String.valueOf(mPickingAdapter.getScanedPackagesCount()));
        mPackageListTotalCountTextView.setText(getResources().getQuantityString(R.plurals.picking_packages_plirals, mPickingAdapter.getCount(), mPickingAdapter.getCount()));
        mPickingingBtn.setEnabled(hasScanedPackages);
    }

    public void onScanButtonClicked(View view) {
        Intent intent = new Intent(this, CaptureActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    public void onPickingButtonClicked(View view) {
        int count = mPickingAdapter.getScanedPackagesCount();
        ToastUtil.show(this, getResources().getQuantityString(R.plurals.picking_result_toast, count, count));
        finish();
    }

    public void onRetryClick(View view) {
        mErrorView.setVisibility(View.GONE);
        getExpiredPackages();
    }

    private void getExpiredPackages() {
        mLoadingView.setVisibility(View.VISIBLE);
        FastJsonArrayRequest<List<ExpiredTrackingInfo>, ExpiredTrackingInfo> request = new FastJsonArrayRequest<List<ExpiredTrackingInfo>, ExpiredTrackingInfo>(this, ExpiredTrackingInfo.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_PICKING_GET_EXPIRED, WillCallApp.getWarehouse().getCode()), new Response.Listener<List<ExpiredTrackingInfo>>() {
            @Override
            public void onResponse(List<ExpiredTrackingInfo> result) {
                if (result != null && result.size() > 0) {
                    mPickingAdapter = new PackageListPickingAdapter(ExpiredPackagePickingActivity.this, result, new OnDataSetChangedListener() {
                        @Override
                        public void onDataSetChanged() {
                            controlCountViewStatus();
                        }
                    });
                    mPackageListView.setAdapter(mPickingAdapter);
                    controlCountViewStatus();
                    mContentView.setVisibility(View.VISIBLE);
                    mLoadingView.setVisibility(View.GONE);
                } else {
                    mLoadingView.setVisibility(View.GONE);
                    mEmptyView.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                mLoadingView.setVisibility(View.GONE);
                mErrorView.setVisibility(View.VISIBLE);
            }
        });
        VolleyUtil.addToRequestQueue(this, request);
    }

    private void pickingScan(final String trackingNumber) {
        final String finalTrackingNumber = trackingNumber == null ? null : trackingNumber.trim();
        if (finalTrackingNumber != null && !TextUtils.isEmpty(finalTrackingNumber) &&
                mPickingAdapter.getPositionByItemTrackingNumber(finalTrackingNumber) != -1) {
            showProgressDialog();
            ScanExpiredTrackingDTO trackingDTO = new ScanExpiredTrackingDTO(finalTrackingNumber, String.valueOf(WillCallApp.getUser().getUserID()));
            FastJsonObjectRequest<BooleanResponse> trackingRequest = new FastJsonObjectRequest<BooleanResponse>(this, BooleanResponse.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_PICKING_SCAN_PACKAGE, finalTrackingNumber), trackingDTO, new Response.Listener<BooleanResponse>() {
                @Override
                public void onResponse(BooleanResponse result) {
                    hideProgressDialog();
                    if (result.isSuccessful()) {
                        if (mPickingAdapter.isScaned(trackingNumber)) {
                            ToastUtil.show(ExpiredPackagePickingActivity.this, getString(R.string.picking_package_picked));
                        } else {
                            ToastUtil.show(ExpiredPackagePickingActivity.this, getString(R.string.picking_package_one_package_picked));
                            mPickingAdapter.changePackageItemState(finalTrackingNumber);
                        }
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    hideProgressDialog();
                }
            });
            VolleyUtil.addToRequestQueue(this, trackingRequest);
        } else {
            ToastUtil.show(this, String.format(getString(R.string.trackingnumber_input_error), finalTrackingNumber), ToastUtil.TOAST_DURATION_LONG);
        }
    }

    @Override
    public void onBarcodeScanned(final String barcode) {
        super.onBarcodeScanned(barcode);

        if (StringUtil.isEmpty(barcode)) {
            return;
        }

        if (mInputEditText == null) {
            return;
        }

        if (mInputEditText.getHandler() == null) {
            mInputEditText.setText("");
            mInputEditText.append(barcode);
            pickingScan(barcode);
        } else {
            mInputEditText.post(new Runnable() {
                public void run() {
                    mInputEditText.setText("");
                    mInputEditText.append(barcode);
                    pickingScan(barcode);
                }
            });
        }
    }
}
