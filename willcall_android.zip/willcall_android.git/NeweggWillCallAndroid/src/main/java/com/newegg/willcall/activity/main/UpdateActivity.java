package com.newegg.willcall.activity.main;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.VersionInfo;
import com.newegg.willcall.utils.VersionUtils;

import java.io.File;

/**
 * Created by JaredLuo on 14-4-19.
 */
public class  UpdateActivity extends Activity {

    public static final String PARAMS_VERSION_INFO = "PARAMS_VERSION_INFO";

    private AlertDialog dialog;
    private ProgressDialog mDownLoadDialog;

    private VersionInfo versionInfo;

    @Override
    protected void onResume() {
        super.onResume();

        if (getIntent() != null && (dialog == null || !dialog.isShowing())) {
            versionInfo = (VersionInfo) getIntent().getSerializableExtra(PARAMS_VERSION_INFO);
            if (versionInfo.isForceUpgrade()) {
                dialog = new AlertDialog.Builder(this).setTitle(R.string.new_version).setCancelable(false).
                        setMessage(versionInfo.getUpgradeInformation()).setIcon(R.drawable.logo).
                        setPositiveButton(R.string.new_version_update_now, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                download();
                            }
                        }).create();
                dialog.show();
            } else {
                dialog = new AlertDialog.Builder(this).setTitle(R.string.new_version).setCancelable(true).
                        setMessage(versionInfo.getUpgradeInformation()).setIcon(R.drawable.logo).
                        setPositiveButton(R.string.new_version_update_now, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                download();
                            }
                        }).
                        setNegativeButton(R.string.new_version_update_later, null).setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        finish();
                    }
                }).create();
                dialog.show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private void download() {
        VersionUtils.startDownloadThread(this, versionInfo.getUpgradeUrl(), "neweggwillcall" + versionInfo.getCurrentVersion(),
                new VersionUtils.DownloadListener() {
                    @Override
                    public void OnDownloading(final long totalSize, final long downloadedSize, final File file) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (mDownLoadDialog == null) {
                                    mDownLoadDialog = buildProgressDialog();
                                    mDownLoadDialog.setMax((int) totalSize / 1000);
                                    mDownLoadDialog.show();
                                    return;
                                }

                                mDownLoadDialog.setProgress((int) downloadedSize / 1000);

                                if (totalSize / 1000 == downloadedSize / 1000) {
                                    VersionUtils.install(UpdateActivity.this, file);
                                }
                            }
                        });

                    }
                }
        );
    }

    private ProgressDialog buildProgressDialog() {
        ProgressDialog downLoadDialog = new ProgressDialog(UpdateActivity.this);
        downLoadDialog.setMessage(getString(R.string.new_version_downloading));
        downLoadDialog.setCancelable(false);
        downLoadDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {

            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_BACK) {
                    VersionUtils.stopDownload();
                }
                return false;
            }
        });
        downLoadDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        return downLoadDialog;
    }

    @Override
    public void onBackPressed() {
        System.exit(0);
    }
}
