package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.utils.CurrencyUtils;

import org.apache.commons.math3.util.Decimal64;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/25/14.
 */
public class ItemInfoResDTO extends ItemBase implements Serializable {
    private static final long serialVersionUID = -3696608373702017349L;

    public static final String BARCODE_TYPE_SN = "S/N";
    public static final String BARCODE_TYPE_UPC = "UPC";

    @JSONField(name = "BarcodeValue")
    private String barcodeValue;
    @JSONField(name = "BarcodeType")
    private String barcodeType;


    public ItemInfoResDTO() {
        super();
    }

    public ItemInfoResDTO(ItemBase base) {
        super(base);
    }

    public String getBarcodeValue() {
        return barcodeValue;
    }


    public void setBarcodeValue(String barcodeValue) {
        this.barcodeValue = barcodeValue;
    }


    public String getBarcodeType() {
        return barcodeType;
    }


    public void setBarcodeType(String barcodeType) {
        this.barcodeType = barcodeType;
    }

}
