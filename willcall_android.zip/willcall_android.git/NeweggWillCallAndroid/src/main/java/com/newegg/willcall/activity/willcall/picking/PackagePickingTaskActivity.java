package com.newegg.willcall.activity.willcall.picking;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.willcall.checkout.PackagePickFragment;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.event.OnActionListener1;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;


public class PackagePickingTaskActivity extends BaseActivity  {


    private ListView mlistview;
    private PackagePickingTaskAdapter mAdapter;
    private View mListViewContainer ;

    private View mEmptyContainer;
    private TextView emptyTitleTextView;

    private View mErrorContainer = null;
    private TextView mTaskCountTextView = null;
    private boolean isRefreshing = false;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setIsLandscape(false);
        super.onCreate(savedInstanceState);

        if(!WillCallApp.getWarehouse().hasPackageTaskList())
        {
            ToastUtil.show(this, getString(R.string.privilege_error));
            finish();
            return;
        }
        setContentView(R.layout.activity_package_picking_task);
        FindView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.searchTask();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    private void FindView() {
        mListViewContainer = findViewById(R.id.picking_task_list_view_container);
        mlistview = (ListView)findViewById(R.id.willcall_package_picking_task_listview);
        mAdapter=new PackagePickingTaskAdapter(this);
        mlistview.setAdapter(mAdapter);
        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Activity context = PackagePickingTaskActivity.this;
                ReferenceOrderPickingTask task = mAdapter.getItem(position);
                Intent intent = new Intent(PackagePickingTaskActivity.this,PackagePickingActivity.class);
                intent.putExtra(PackagePickFragment.ARGUMENT_ORDER_PICKING_TASK,task);
                context.startActivity(intent);
                context.overridePendingTransition(R.anim.anim_up_in,R.anim.anim_up_out);
            }
        });

        mEmptyContainer = findViewById(R.id.empty_layout);
        emptyTitleTextView = (TextView) findViewById(R.id.empty_title);
        emptyTitleTextView.setText(R.string.not_find_picktasklist);

        mErrorContainer = findViewById(R.id.picking_task_network_error_container);
        mTaskCountTextView = (TextView) findViewById(R.id.picking_task_list_count);
    }

    public void onRefreshClicked(View view){
        searchTask();
    }


    private void showProcessBar(){
        isRefreshing = true;
        showProgressDialog();
        mEmptyContainer.setVisibility(View.GONE);

        mErrorContainer.setVisibility(View.GONE);
        mListViewContainer.setVisibility(View.GONE);
        mTaskCountTextView.setVisibility(View.GONE);
    }

    private void hideProcessBar(){
        isRefreshing = false;
        hideProgressDialog();
    }

    private void searchTask(){
        if(!isRefreshing) {
            showProcessBar();
            mAdapter.searchTask(PackagePickingTaskActivity.this, new OnActionListener1<String>() {
                @Override
                public void action(String errorMsg) {
                    hideProcessBar();
                    int count = mAdapter.getCount();
                    mTaskCountTextView.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
                    mTaskCountTextView.setText(Integer.toString(count));

                    if (!StringUtil.isEmpty(errorMsg)) {
//                    ToastUtil.show(PackagePickingTaskActivity.this, errorMsg);
                        mErrorContainer.setVisibility(View.VISIBLE);
                    } else if (count == 0) {
                        mEmptyContainer.setVisibility(View.VISIBLE);
                    } else if (count > 0) {
                        mListViewContainer.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
    }
}
