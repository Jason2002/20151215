package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by JaredLuo on 4/2/14.
 */
public class LogInDTO implements Serializable {
    private static final long serialVersionUID = 464771145036960507L;
    @JSONField(name = "LoginName")
    private String loginName;
    @JSONField(name = "PassWord")
    private String password;


    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
