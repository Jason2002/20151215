package com.newegg.willcall.http;

import com.newegg.willcall.entities.ErrorResponseInfo;

/**
 * Created by dy45 on 5/28/2015.
 */
public class RestResult<T> {
    private T result;
    private ErrorResponseInfo error;

    public ErrorResponseInfo getError() {
        return error;
    }

    public T getResult() {
        return result;
    }

    public RestResult(ErrorResponseInfo error) {
        this.error = error;
    }

    public RestResult(T result) {
        this.result = result;
    }

    public boolean hasError(){
        return error !=null;
    }

    public String getErrorMsg(){
        if(hasError()){
            String msg=error.getMessage();
            if(msg == null){
                msg = error.toString();
            }
            return msg;
        }
        return "";
    }
}
