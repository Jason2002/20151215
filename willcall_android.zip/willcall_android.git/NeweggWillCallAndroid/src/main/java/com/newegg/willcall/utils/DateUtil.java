package com.newegg.willcall.utils;

import android.provider.ContactsContract;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by dy45 on 4/24/2015.
 */
public class DateUtil {

    public final static Date MinDate= parseDate(1970,1,1);
    public final static Date StartDate = parseDate(2000,1,1);

    public static String toString(Date date, String format){
        SimpleDateFormat simpleDateFormat =  new SimpleDateFormat(format);
        return simpleDateFormat.format(date);
    }

    public static String toString(String format){
        return toString(new Date(), format);
    }

    public static String toDayString(Date date){
        return toString(date,"yyyy-MM-dd");
    }

    public static Date parseDate(String date,String format){
        return parseDate(date,format,MinDate);
    }

    public static Date parseDayDate(String date){
        return parseDate(date,"yyyy-MM-dd");
    }

    public static Date parseDate(int year,int month,int day){
        Calendar calendar = Calendar.getInstance();
        calendar.set(year,month,day,0,0,0);
        return calendar.getTime();
    }

    public static Date addDay(Date date, int day){
        return add(Calendar.DATE, date, day);
    }

    private static Date add(int field,Date date,int value){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(field,value);
        return calendar.getTime();
    }

    public static Date addHour(Date date, int hour){
        return add(Calendar.HOUR, date, hour);
    }

    public static Date parseDate(String date,String format,Date defaultValue){
        SimpleDateFormat simpleDateFormat =  new SimpleDateFormat(format);
        try {
            return simpleDateFormat.parse(date);
        }
        catch (Exception ex){
            return defaultValue;
        }
    }

    public static boolean isDate(Date date){
        if(date == null){
            return false;
        }
        return date.compareTo(StartDate)>0;
    }

    public static boolean isSameDay(Date date1,Date date2){
        if(date1==date2){
            return true;
        }
        if(date1==null
                || date2==null){
            return false;
        }
        return toString(date1,"yyyy-MM-dd").compareTo(toString(date2,"yyyy-MM-dd"))==0;
    }

}
