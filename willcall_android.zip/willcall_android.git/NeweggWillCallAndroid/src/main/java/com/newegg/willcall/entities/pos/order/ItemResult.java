package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by jaredluo on 1/3/15.
 */
public class ItemResult implements Serializable {
    private static final long serialVersionUID = 5158919264100917234L;
    @JSONField(name = "ItemList")
    private List<ItemInfoResDTO> itemList;

    public List<ItemInfoResDTO> getItemList() {
        return itemList;
    }

    public void setItemList(List<ItemInfoResDTO> itemList) {
        this.itemList = itemList;
    }
}
