package com.newegg.willcall.entities.pos.orderReturn;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSReturnMasterDTO implements Serializable {
    @JSONField(name = "SONumber")
    private int soNumber;

    @JSONField(name = "WarehouseNumber")
    private String warehouseNumber;

    @JSONField(name = "CreditCardReturnAmount")
    private BigDecimal creditCardReturnAmount;

    @JSONField(name = "RestockingFee")
    private BigDecimal restockingFee;

    @JSONField(name = "InUserID")
    private String inUserID;

    @JSONField(name = "InUserName")
    private String inUserName;

    public BigDecimal getCreditCardReturnAmount() {
        return creditCardReturnAmount;
    }

    public void setCreditCardReturnAmount(BigDecimal creditCardReturnAmount) {
        this.creditCardReturnAmount = creditCardReturnAmount;
    }

    public BigDecimal getRestockingFee() {
        return restockingFee;
    }

    public void setRestockingFee(BigDecimal restockingFee) {
        this.restockingFee = restockingFee;
    }

    public String getInUserID() {
        return inUserID;
    }

    public void setInUserID(String inUserID) {
        this.inUserID = inUserID;
    }

    public String getInUserName() {
        return inUserName;
    }

    public void setInUserName(String inUserName) {
        this.inUserName = inUserName;
    }

    public int getSoNumber() {
        return soNumber;
    }

    public void setSoNumber(int soNumber) {
        this.soNumber = soNumber;
    }

    public String getWarehouseNumber() {
        return warehouseNumber;
    }

    public void setWarehouseNumber(String warehouseNumber) {
        this.warehouseNumber = warehouseNumber;
    }
}
