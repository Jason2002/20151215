package com.newegg.willcall.service;

import android.app.AlertDialog;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.pos.tools.TimeTrace;
import com.newegg.willcall.activity.pos.tools.UploadFileActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.cache.SOFileCache;
import com.newegg.willcall.entities.pos.order.ImageContent;
import com.newegg.willcall.entities.pos.order.POSSOResDTO;
import com.newegg.willcall.event.OnActionListener;
import com.newegg.willcall.event.OnActionListener1;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.RequestWrapper;
import com.newegg.willcall.http.RestResult;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.io.File;

public class UploadFileService extends IntentService {

    public static final String FilePathParam = "FILEPATHPARAM";
    public static final String OrderNumberParam = "OrderNumberParam";
    public static final String OrderTypePARAM = "OrderTypePARAM";
    public static final int NotificationID = 127260350;
    private static final int MAXLOOP = 10;

    NotificationManager mNotifyManager;

    Notification notification;

    public static void startUploadFile(Context context
            , String filePath
            ,String orderNumber
            ,String orderType) {

        LogUtil.i("test", "startService in UploadFileService");
        Intent intent = buildIntent(context, filePath, orderNumber, orderType);
        context.startService(intent);
    }

    private static Intent buildIntent(Context context, String filePath, String orderNumber, String orderType) {
        Intent intent = new Intent(context, UploadFileService.class);
        intent.putExtra(FilePathParam, filePath);
        intent.putExtra(OrderNumberParam,orderNumber);
        intent.putExtra(OrderTypePARAM,orderType);
        return intent;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        Intent intent = new Intent(this, UploadFileActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent,0);
        NotificationCompat.Builder  mBuilder;
        mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setContentTitle("Upload invoice file failed")
                .setContentText("Click to retry again.")
                .setSmallIcon(R.drawable.uploading)
                .setContentIntent(pendingIntent);
        notification = mBuilder.build();
    }

    public UploadFileService() {
        super("UploadFileService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            String filePath = intent.getStringExtra(FilePathParam);
            String orderNumber = intent.getStringExtra(OrderNumberParam);
            String orderType = intent.getStringExtra(OrderTypePARAM);
            uploadFile(new File(filePath), orderNumber, orderType, 0);
        }
    }

    private void uploadFile(final File pdfFile
            , final String orderNumber
            ,final String orderType
            , final int loop) {
        if(SOFileCache.getCount() == 0){
            mNotifyManager.cancelAll();
        }
        RequestWrapper getImgWrapper = new RequestWrapper(UploadFileService.this);
        getImgWrapper.getObject(ImageContent.class
                ,HttpConfig.getFormatUrl(HttpConfig.POS_UPLOAD_IMAGE_ID,orderNumber, pdfFile.getName())
                ,new OnActionListener1<RestResult<ImageContent>>() {
                    @Override
                    public void action(RestResult<ImageContent> imgRest) {
                        if(imgRest.hasError()
                                || imgRest.getResult() == null
                                || StringUtil.isEmpty(imgRest.getResult().getImageID())){
                            if(loop>MAXLOOP) {
                                ToastUtil.show(UploadFileService.this,"Upload invoice file failed."
                                        ,ToastUtil.TOAST_DURATION_LONG);
                                notifyUser(pdfFile.getAbsolutePath(), orderNumber, orderType);
                                return;
                            }
                            if(imgRest.hasError()){
                                uploadFile(pdfFile,orderNumber,orderType,loop+1);
                                return;
                            }
                            else {
                                final RequestWrapper wrapper = buildUploadFileRequest(pdfFile, orderNumber, orderType);
                                final TimeTrace timeTrace = new TimeTrace("upload invoice file");
                                timeTrace.start("so#:" + orderNumber);
                                wrapper.uploadFile(HttpConfig.POS_UPLOAD_PDF,pdfFile,new OnActionListener1<RestResult<String>>() {
                                    @Override
                                    public void action(RestResult<String> uploadRest) {
                                        if(uploadRest.hasError()){
                                            timeTrace.end("so#:" + orderNumber+" failed."+uploadRest.getErrorMsg());
                                            uploadFile(pdfFile,orderNumber,orderType,loop+1);
                                        }
                                        else{
                                            timeTrace.end("so#: " + orderNumber+" successfully.");
                                        }
                                    }
                                });
                            }
                        }
                    }
                }
        );
    }




    private RequestWrapper buildUploadFileRequest(File pdfFile, String orderNumber, String orderType) {
        final RequestWrapper wrapper = new RequestWrapper(UploadFileService.this);
        wrapper.addHeader("FileGroup","POS");
        wrapper.addHeader("FileType","Invoice");
        wrapper.addHeader("UploadType","UPDATE");
        wrapper.addHeader("FileName",pdfFile.getName());
        wrapper.addHeader("UserName","ovs");
        wrapper.addHeader("OrderNumber",orderNumber);
        wrapper.addHeader("UploadUrl", HttpConfig.HOST_DFIS_UPLOAD);
        wrapper.addHeader("UniqueOrderNumber",orderNumber);
        wrapper.addHeader("OrderType",orderType);
        wrapper.addHeader("FullUrl",HttpConfig.getFormatUrl(HttpConfig.POS_GET_PDF, pdfFile.getName()));
        wrapper.addHeader("InUser", WillCallApp.getUser().getTrimmedName());
        return wrapper;
    }

//    uploadFile(pdfFile,orderNumber,orderType,loop+1);


    private void notifyUser(String pdfFile,String orderNumber,String orderType){
        SOFileCache.add(new SOFileItem(orderNumber,orderType,pdfFile));
        mNotifyManager.notify("POS",NotificationID,notification);
    }
}
