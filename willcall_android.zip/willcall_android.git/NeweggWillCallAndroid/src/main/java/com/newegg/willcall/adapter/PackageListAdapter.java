package com.newegg.willcall.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.newegg.willcall.listener.OnDataSetChangedListener;

import java.util.List;

/**
 * Created by lenayan on 14-4-10.
 */
public abstract class PackageListAdapter<T> extends BaseAdapter {

    protected List<T> mItemsList = null;
    protected LayoutInflater mLayoutInflater = null;
    protected Context mContext = null;
    private OnDataSetChangedListener mDataSetChangedListener = null;

    public PackageListAdapter(Context context, List<T> packageList, OnDataSetChangedListener listener) {
        this(context, packageList);
        mDataSetChangedListener = listener;
    }

    public PackageListAdapter(Context context, List<T> packageList) {
        mContext = context;
        mItemsList = packageList;
        mLayoutInflater = LayoutInflater.from(context);
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        if (mDataSetChangedListener != null)
            mDataSetChangedListener.onDataSetChanged();
    }

    @Override
    public int getCount() {
        return mItemsList == null ? 0 : mItemsList.size();
    }

    @Override
    public T getItem(int position) {
        return mItemsList == null ? null : mItemsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mItemsList == null ? 0 : mItemsList.size();
    }

    @Override
    public abstract View getView(int position, View convertView, ViewGroup parent);

}

