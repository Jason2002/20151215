package com.newegg.willcall.activity.pos.order;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

import com.newegg.willcall.BuildConfig;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.entities.pos.order.CartInfo;
import com.newegg.willcall.entities.pos.order.CreditCardDTO;
import com.newegg.willcall.utils.CreditCardUtils;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.EncryptUtil;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

public class POSCheckoutActivity extends BaseActivity {

    public static final String PARAM_CART_INFO_INFO = "PARAM_CART_INFO_INFO";
    public static final String PARAM_CREDIT_CARD_INFO = "PARAM_CREDIT_CARD_INFO";
    public static final String PARAM_PAYTERM_CODE = "PARAM_PAYTERM_CODE";
    public static final String PARAM_CARD_NUM = "PARAM_CARD_NUM";

    private View mContainer;
    private View mEmpty;
    private TextView mSubTotalTv;
    private TextView mCardNumTv;
    private TextView mCardOwner;
    private TextView mCardExpDate;

    private CartInfo mCartInfo;
    private String mPaytermsCode;
    private CreditCardDTO mCreditCardDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poscheckout);

        if (getIntent() != null && getIntent().getSerializableExtra(PARAM_CART_INFO_INFO) != null) {
            mCartInfo = (CartInfo) getIntent().getSerializableExtra(PARAM_CART_INFO_INFO);
        }

        findViews();

        //TODO: for test
        if (BuildConfig.DEBUG) {
            mEmpty.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onCreditCardScanned("343434343434343", "Test", "09/19", "%B343434343434343^YOU/YONG^1236563659875421000000?", ";343434343434343=1236563659875421?");
                }
            });
        }
    }

    private void findViews() {
        mContainer = findViewById(R.id.pos_checkout_container);
        mEmpty = findViewById(R.id.pos_checkout_empty);
        mSubTotalTv = (TextView) findViewById(R.id.pos_checkout_subtotal);
        mCardNumTv = (TextView) findViewById(R.id.pos_checkout_credit_card_num);
        mCardOwner = (TextView) findViewById(R.id.pos_checkout_credit_card_owner);
        mCardExpDate = (TextView) findViewById(R.id.pos_checkout_credit_card_exp_date);
    }

    public void onConfirmButtonClicked(View view) {
        if (StringUtil.isEmpty(mPaytermsCode)) {
            ToastUtil.show(POSCheckoutActivity.this, getString(R.string.pos_checkout_credit_card_num_invaild));
            return;
        }
        Intent intent = new Intent(this, POSSignActivity.class);
        intent.putExtra(PARAM_CART_INFO_INFO, mCartInfo);
        intent.putExtra(PARAM_CREDIT_CARD_INFO, mCreditCardDTO);
        intent.putExtra(PARAM_PAYTERM_CODE, mPaytermsCode);
        intent.putExtra(PARAM_CARD_NUM, mCardNumTv.getText());

        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public void onCreditCardScanned(String number, String owner, String exp, String track1, String track2) {
        super.onCreditCardScanned(number, owner, exp, track1, track2);

        mEmpty.setVisibility(View.GONE);
        mContainer.setVisibility(View.VISIBLE);

        mSubTotalTv.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getGrandTotal()));
        mCardNumTv.setText(number);
        mCardOwner.setText(owner);
        mCardExpDate.setText(exp);

        mPaytermsCode = CreditCardUtils.getPaytermsCode(number);
        if (StringUtil.isEmpty(mPaytermsCode)) {
            ToastUtil.show(POSCheckoutActivity.this, getString(R.string.pos_checkout_credit_card_num_invaild));
            return;
        }

        Log.i("test", "Payterms Code: " + mPaytermsCode);


        mCreditCardDTO = new CreditCardDTO();
        mCreditCardDTO.setExpDate(EncryptUtil.rsaEncrypt(exp));
        //TODO:
        mCreditCardDTO.setMagneticTrack1(EncryptUtil.rsaEncrypt(track1));
        mCreditCardDTO.setMagneticTrack2(EncryptUtil.rsaEncrypt(track2));
        mCreditCardDTO.setPaymentAmount(mCartInfo.getGrandTotal().doubleValue());
        mCreditCardDTO.setCardNumber(EncryptUtil.rsaEncrypt(number));
        mCreditCardDTO.setHashCardNumber(EncryptUtil.sha256(number));

//        Log.i("test:", "track1: " + mCreditCardDTO.getMagneticTrack1());
//        Log.i("test:", "track2: " + mCreditCardDTO.getMagneticTrack2());
//        Log.i("test:", "card num: " + mCreditCardDTO.getCardNumber());
//        Log.i("test:", "exp date: " + mCreditCardDTO.getExpDate());

    }
}
