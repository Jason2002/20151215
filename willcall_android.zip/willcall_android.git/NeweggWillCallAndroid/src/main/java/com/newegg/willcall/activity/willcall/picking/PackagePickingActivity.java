package com.newegg.willcall.activity.willcall.picking;

import android.content.Intent;
import android.os.Bundle;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.willcall.checkout.PackagePickFragment;

import java.io.Serializable;

public class PackagePickingActivity extends BaseActivity {


    private PackagePickFragment packagePickFragment ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_picking);
        if(savedInstanceState == null) {
            Serializable task = null;
            Intent intent = getIntent();
            if(intent!=null) {
                task = intent.getSerializableExtra(PackagePickFragment.ARGUMENT_ORDER_PICKING_TASK);
            }
            packagePickFragment = PackagePickFragment.createPackagePickFragment(task);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.package_picking_container, packagePickFragment)
                    .commit();
        }
    }

    public void onBarcodeScanned(String barcode) {
        packagePickFragment.onBarcodeScanned(barcode);
    }

}
