package com.newegg.willcall.entities;

import java.io.Serializable;

/**
 * Created by JaredLuo on 14-4-22.
 */
public class WarehouseCache implements Serializable {
    private static final long serialVersionUID = -17685236096126011L;
    private int userID;
    private Warehouse warehouse;


    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }
}
