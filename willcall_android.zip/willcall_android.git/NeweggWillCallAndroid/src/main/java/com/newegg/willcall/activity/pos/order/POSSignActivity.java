package com.newegg.willcall.activity.pos.order;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.view.ActionMode;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.itextpdf.text.DocumentException;
import com.newegg.willcall.BuildConfig;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.pos.tools.TimeTrace;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.cache.POSTraceCache;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.order.CartInfo;
import com.newegg.willcall.entities.pos.order.CreditCardDTO;
import com.newegg.willcall.entities.pos.order.DFISDTO;
import com.newegg.willcall.entities.pos.order.ImageContent;
import com.newegg.willcall.entities.pos.order.ItemInfo;
import com.newegg.willcall.entities.pos.order.POSSOReqDTO;
import com.newegg.willcall.entities.pos.order.POSSOResDTO;
import com.newegg.willcall.event.OnActionListener1;
import com.newegg.willcall.http.BaseRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.RequestWrapper;
import com.newegg.willcall.http.RestResult;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.service.UploadFileService;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.FileUtils;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.PDFUtils;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.newegg.willcall.widget.InvoiceView;
import com.newegg.willcall.widget.SignView;

import java.io.File;
import java.io.IOException;
import java.sql.Wrapper;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.UUID;

/**
 * Created by JaredLuo on 14-4-11.
 */
public class POSSignActivity extends BaseActivity {
    public static final String PARAMS_CHECKOUT_PAGE_ORIENTATION = "PARAMS_CHECKOUT_PAGE_ORIENTATION";
    public static final String REQUEST_TAG_UPLOAD_PDF = "REQUEST_TAG_UPLOAD_PDF";
    public static final String REQUEST_TAG_UPDATE_ID = "REQUEST_TAG_UPDATE_ID";

    private static int MENU_ITEM_CLEAR_ID = 0x10;

    private boolean mIsVisible;

    private SignView mSignView;
    private ActionMode.Callback mActionCallBack;
    private int mOrientation;
    private AlertDialog confirmDialog;

    private CartInfo mCartInfo;
    private CreditCardDTO mCreditCardInfo;
    private String paytermsCode;
    private String mCardNum;

    private String mTransactionId;
    private Boolean isPlacingOrder = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setIsLandscape(true);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_possign);

        mSignView = (SignView) findViewById(R.id.sign_view);

        mTransactionId = UUID.randomUUID().toString();

        if (getIntent() != null) {
            if (getIntent().getSerializableExtra(POSCheckoutActivity.PARAM_CART_INFO_INFO) != null) {
                mCartInfo = (CartInfo) getIntent().getSerializableExtra(POSCheckoutActivity.PARAM_CART_INFO_INFO);
            }

            if (getIntent().getSerializableExtra(POSCheckoutActivity.PARAM_CREDIT_CARD_INFO) != null) {
                mCreditCardInfo = (CreditCardDTO) getIntent().getSerializableExtra(POSCheckoutActivity.PARAM_CREDIT_CARD_INFO);
            }

            if (getIntent().getStringExtra(POSCheckoutActivity.PARAM_PAYTERM_CODE) != null) {
                paytermsCode = getIntent().getStringExtra(POSCheckoutActivity.PARAM_PAYTERM_CODE);
            }

            if (getIntent().getStringExtra(POSCheckoutActivity.PARAM_CARD_NUM) != null) {
                mCardNum = getIntent().getStringExtra(POSCheckoutActivity.PARAM_CARD_NUM);
            }

            mOrientation = getIntent().getIntExtra(PARAMS_CHECKOUT_PAGE_ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        mActionCallBack = createActionMode();
        startSupportActionMode(mActionCallBack);
    }

    private ActionMode.Callback createActionMode() {
        return new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                View customTitle = LayoutInflater.from(POSSignActivity.this).inflate(R.layout.checkout_sign_pickup_by, null);
                TextView customer = (TextView) customTitle.findViewById(R.id.checkout_sign_customer);
                SpannableStringBuilder ssb = new SpannableStringBuilder();

                String total = CurrencyUtils.getCurrencyFormat(mCartInfo.getGrandTotal());

                int firstLength = getString(R.string.pos_checkout_total_colon).length();
                int secondLength = total.length();

                ssb.append(getString(R.string.pos_checkout_total_colon));
                ssb.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.secondary_text_color)), 0, firstLength, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
                ssb.append(total);
                ssb.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), firstLength, firstLength + secondLength, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
                customer.setText(ssb);
                mode.setCustomView(customTitle);

                menu.add(0, MENU_ITEM_CLEAR_ID, 1, "clear");

                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                if (item.getItemId() == MENU_ITEM_CLEAR_ID) {
                    mSignView.clear();
                }
                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                if (mIsVisible) {
                    if (!mSignView.isEmpty()) {
                        final Bitmap bitmap = mSignView.getBitmap();

                        View view = getLayoutInflater().inflate(R.layout.signature_confirm_dialog, null);
                        ImageView signatureImageView = (ImageView) view.findViewById(R.id.signature_dialog_image_view);

                        signatureImageView.setImageBitmap(bitmap);

                        confirmDialog = new AlertDialog.Builder(POSSignActivity.this).setTitle(R.string.checkout_signature_confirm_title).
                                setPositiveButton(R.string.checkout_signature_confirm_pos_btn, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        confirmOrder(bitmap);
                                    }
                                }).setNegativeButton(R.string.checkout_signature_confirm_neg_btn, null).setInverseBackgroundForced(true).
                                setView(view).create();


                        confirmDialog.show();

                        ViewGroup parent = (ViewGroup) view.getParent();
                        parent.setPadding(0, 0, 0, 0);

                    } else {
                        showMsg(getString(R.string.checkout_empty_sign));
                    }
                }

                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        startSupportActionMode(mActionCallBack);
                    }
                });
            }
        };
    }

    private void confirmOrder(final Bitmap bitmap) {
        if (isPlacingOrder) {
            return;
        }
        isPlacingOrder = true;

        showProgressDialog(false);

        final POSSOReqDTO soRequest = mCartInfo.buildSOReq();

        soRequest.getPaymentDTO().setCreditCardInfo(mCreditCardInfo);
        soRequest.getSoInfo().setPaytermsCode(paytermsCode);

        soRequest.getSoInfo().setTransactionID(mTransactionId);

        final TimeTrace timeTrace = new TimeTrace("submit SO ");
        timeTrace.start("id:"+mTransactionId);

        String url = HttpConfig.getFormatUrl(HttpConfig.POS_CART_CREATE_SO, mTransactionId);
        FastJsonObjectRequest<POSSOResDTO> request = new FastJsonObjectRequest<POSSOResDTO>(this, POSSOResDTO.class, Request.Method.PUT, url, soRequest, new Response.Listener<POSSOResDTO>() {
            @Override
            public void onResponse(POSSOResDTO soResDTO) {
                isPlacingOrder = false;
                if (soResDTO != null) {
                    LogUtil.i("test", "order num: " + soResDTO.getSoNumber());
                    //TODO: for test
                    if (BuildConfig.DEBUG) {
                        ToastUtil.show(POSSignActivity.this, "order num: " + soResDTO.getSoNumber(), 10000);
                    }
                    timeTrace.end("so#:"+soResDTO.getSoNumber());
                    placeInvoice(bitmap, soResDTO);
                }

                hideProgressDialog();
            }
        }, new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                timeTrace.end("failed.");
                isPlacingOrder = false;
                hideProgressDialog();
                showMsg(info.getMessage());
            }
        });

        VolleyUtil.addToRequestQueue(this, request).setRetryPolicy(new DefaultRetryPolicy(60000*3, 0, 1.0f));
        LogUtil.i("test", "start place order: " + mTransactionId);

    }

    private void placeInvoice(Bitmap bitmap, final POSSOResDTO soResDTO) {

        final InvoiceView invoiceView = getInvoiceView(bitmap, soResDTO);
        final TimeTrace timeTrace = new TimeTrace("generate invoice");
        timeTrace.start("so#:"+soResDTO.getSoNumber());
        AsyncTask<Void, Void, File> task = new AsyncTask<Void, Void, File>() {
            @Override
            protected File doInBackground(Void... params) {
                try {
                    return PDFUtils.bitmap2Pdf(invoiceView.getBitmap(), soResDTO.getSoNumber() + ".pdf");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (DocumentException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(File file) {
                super.onPostExecute(file);
                hideProgressDialog();
                timeTrace.end("so#:" + soResDTO.getSoNumber());
                if (file == null) {
                    showMsg("Generate invoice failed");
                    return;
                }
                UploadFileService.startUploadFile(POSSignActivity.this
                        ,file.getAbsolutePath()
                        ,String.valueOf(soResDTO.getSoNumber())
                        ,"101");
                toPrint(file, soResDTO.getSoNumber());
            }
        };
        task.execute();
        showProgressDialog();
    }

    private void toPrint(File file, int soNumber) {
        Intent intent = new Intent(this, POSPrintActivity.class);
        intent.putExtra(POSPrintActivity.PARAM_PDF_FILE_NAME, file.getAbsolutePath());
        intent.putExtra(POSPrintActivity.PARAM_SO_NUMBER, soNumber);
        startActivity(intent);
    }

    private InvoiceView getInvoiceView(Bitmap signImageBitmap, POSSOResDTO soRep) {
        LayoutInflater inflater = LayoutInflater.from(this);
        final InvoiceView invoiceView = (InvoiceView) inflater.inflate(R.layout.pos_invoice, null);

        TextView orderNumTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_order_num);
        TextView submittedTimeTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_submitted_time);
        TextView eventLocationTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_event_location);
        TextView creditCardTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_credit_card_num);
        ImageView signImageView = (ImageView) invoiceView.findViewById(R.id.pos_invoice_sign_image);
        LinearLayout itemContainer = (LinearLayout) invoiceView.findViewById(R.id.pos_invoice_order_item_container);

        TextView subtotalTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_subtotal);
        TextView ewraTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_ewra);
        TextView taxTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_tax);
        TextView discountTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_discount);
        TextView gcTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_gift_card);
        TextView orderTotalTv = (TextView) invoiceView.findViewById(R.id.pos_invoice_order_total);

        orderNumTv.setText(soRep.getSoNumber() + "");

        Calendar c = new GregorianCalendar();
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
        String date = df.format(c.getTime());
        submittedTimeTv.setText(date);

        StringBuilder addressBuilder = new StringBuilder("");

        if (!StringUtil.isEmpty(WillCallApp.getWarehouse().getAddress1())) {
            addressBuilder.append(WillCallApp.getWarehouse().getAddress1());
        }
        if (!StringUtil.isEmpty(WillCallApp.getWarehouse().getAddress2())) {
            addressBuilder.append("\n");
            addressBuilder.append(WillCallApp.getWarehouse().getAddress2());
        }

        eventLocationTv.setText(addressBuilder.toString());

        creditCardTv.setText(CurrencyUtils.maskCrediCard(mCardNum));

        signImageView.setImageBitmap(signImageBitmap);

        List<ItemInfo> itemInfos = mCartInfo.getItems();

        for (int i = 0; i < itemInfos.size(); i++) {
            View cell = LayoutInflater.from(this).inflate(R.layout.pos_invoice_cell, invoiceView, false);
            TextView qtyTv = (TextView) cell.findViewById(R.id.pos_invoice_cell_qty);
            TextView descTv = (TextView) cell.findViewById(R.id.pos_invoice_cell_desc);
            TextView priceTv = (TextView) cell.findViewById(R.id.pos_invoice_cell_price);

            qtyTv.setText(itemInfos.get(i).getQty() + "");
            descTv.setText(itemInfos.get(i).getLongDescription());
            priceTv.setText(CurrencyUtils.getCurrencyFormat(itemInfos.get(i).getUnitPrice()));

            itemContainer.addView(cell, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }


        subtotalTv.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getSubtotal()));
        ewraTv.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getTotalEwra()));
        if (mCartInfo.getTotalTax().doubleValue() == 0.0) {
            taxTv.setText(getString(R.string.pos_checkout_tax_waived));
        } else {
            taxTv.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getTotalTax()));
        }

        discountTv.setText("-" + CurrencyUtils.getCurrencyFormat(mCartInfo.getTotalDiscount()));
        gcTv.setText("-" + CurrencyUtils.getCurrencyFormat(mCartInfo.getTotalGC()));
        orderTotalTv.setText(CurrencyUtils.getCurrencyFormat(mCartInfo.getGrandTotal()));

        return invoiceView;
    }


    @Override
    protected void onResume() {
        mIsVisible = true;
        super.onResume();
    }

    @Override
    protected void onPause() {
        mIsVisible = false;
        super.onPause();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            done(RESULT_CANCELED);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void done(final int resultCode) {

        AlertDialog dialog = new AlertDialog.Builder(this).setMessage(R.string.pos_checkout_not_finish_hint)
                .setCancelable(true).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent();
                        intent.putExtra(PARAMS_CHECKOUT_PAGE_ORIENTATION, mOrientation);
                        setResult(resultCode, intent);
                        finish();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();

        if (mIsVisible) {
            dialog.show();
        }

    }

    private ProgressDialog getLoadingDialog() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(R.style.ProgressBarWillCallIndeterminate_White);
        progressDialog.setMessage("Loading");
        return progressDialog;
    }

    private void showMsg(String msg) {
        ToastUtil.show(this, msg, ToastUtil.TOAST_DURATION_LONG);
    }

    @Override
    protected void onDestroy() {
        Log.i("test", "Sign Activity On Destory");
        super.onDestroy();
    }
}
