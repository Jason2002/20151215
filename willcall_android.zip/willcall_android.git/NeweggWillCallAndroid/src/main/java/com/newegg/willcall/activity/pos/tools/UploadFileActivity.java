package com.newegg.willcall.activity.pos.tools;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.newegg.willcall.R;
import com.newegg.willcall.cache.SOFileCache;
import com.newegg.willcall.service.SOFileItem;
import com.newegg.willcall.service.UploadFileService;

public class UploadFileActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SOFileItem item = SOFileCache.pop();
        while (item != null){
            String filePath = item.getFilePath();
            String orderNumber = item.getOrderNumber();
            String orderType = item.getOrderType();
            UploadFileService.startUploadFile(this,filePath,orderNumber,orderType);
            item =  SOFileCache.pop();
        }

        this.finish();
    }
}
