package com.newegg.willcall.activity.willcall.picking;

import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.willcall.checkout.PackagePickFragment;
import com.newegg.willcall.adapter.PackageListAdapter;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.event.OnActionListener1;
import com.newegg.willcall.http.BaseRequest;
import com.newegg.willcall.http.FastJsonArrayRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.listener.OnDataSetChangedListener;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;

/**
 * Created by dy45 on 4/14/2015.
 */
public class PackagePickingTaskAdapter extends PackageListAdapter<ReferenceOrderPickingTask> {



    public PackagePickingTaskAdapter(Context context) {
        super(context, new ArrayList<ReferenceOrderPickingTask>(10));
    }


    public void searchTask(final Context context, final OnActionListener1<String> onFinish){
//
//        ReferenceOrderPickingTask task = new ReferenceOrderPickingTask();
//        task.setTaskId(mItemsList.size()+1);
//        task.setBillingContactWith("Denny"+mItemsList.size());
//        mItemsList.add(task);
//
//        android.os.Handler handler =  new  android.os.Handler(Looper.getMainLooper());
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                PackagePickingTaskAdapter.this.notifyDataSetChanged();
//                onFinish.action(null);
//            }
//        },1000);


        mItemsList.clear();
        BaseRequest<List<ReferenceOrderPickingTask>> request =
                new FastJsonArrayRequest<List<ReferenceOrderPickingTask>,ReferenceOrderPickingTask>(context
                        ,ReferenceOrderPickingTask.class
                        , HttpConfig.PACKAGE_PICKAGE_TASK_LIST
                        ,new Response.Listener<List<ReferenceOrderPickingTask>>() {
                            @Override
                            public void onResponse(List<ReferenceOrderPickingTask> list) {
                                if(list!=null){
                                    mItemsList.addAll(list);
                                }
                                PackagePickingTaskAdapter.this.notifyDataSetChanged();
                                if(onFinish!=null){
                                    onFinish.action(null);
                                }
                            }
                        },new BaseRequest.OnErrorListener() {
                            @Override
                            public void onError(ErrorResponseInfo info) {
                                PackagePickingTaskAdapter.this.notifyDataSetChanged();
                                if(onFinish!=null){
                                    onFinish.action(info.getMessage());
                                }
                            }
                        }
                );
        VolleyUtil.addToRequestQueue(context, request);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if(convertView==null
                || convertView.getTag()==null){
            convertView = mLayoutInflater.inflate(R.layout.package_picking_task_item, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }

        ReferenceOrderPickingTask task = getItem(position);
        holder.taskTextView.setText(Integer.toString(task.getTaskId()));
        holder.customerTextView.setText(task.getPickupPerson());
        return convertView;
    }


    public static class ViewHolder {
        public TextView taskTextView;
        public TextView customerTextView;
//        public View taskButton;
//        public ReferenceOrderPickingTask task;

        public ViewHolder(View itemView) {
            taskTextView = (TextView) itemView.findViewById(R.id.pickage_picking_task_item_taskid);
            customerTextView = (TextView) itemView.findViewById(R.id.pickage_picking_task_item_customername);
//            taskButton = itemView.findViewById(R.id.package_picking_task_item_container);
//            taskButton.setOnClickListener(this);
        }
    }
}
