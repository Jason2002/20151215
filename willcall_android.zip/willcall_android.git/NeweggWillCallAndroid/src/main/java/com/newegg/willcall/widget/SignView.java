package com.newegg.willcall.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.newegg.willcall.R;

/**
 * Created by JaredLuo on 14-4-11.
 */
public class SignView extends View {

    private Paint paint;
    private Path path;
    private boolean isDrawing;

    public SignView(Context context) {
        super(context);
        init();
    }

    public SignView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SignView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.DKGRAY);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(8);
        paint.setAntiAlias(true);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        if (path != null) {
            canvas.drawPath(path, paint);
        }
    }

    public boolean isEmpty() {
        boolean isEmpty = (path == null || path.isEmpty());

        if (!isEmpty) {
            PathMeasure pm = new PathMeasure(path, false);
            Float pathLength = 0.0f;
            do{
                pathLength+=pm.getLength();
            }while(pm.nextContour());

            if (pathLength <= 20.0f) {
                return true;
            }
            return false;
        } else {
            return true;
        }

    }

    public void clear() {
        path = null;
        invalidate();
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (path == null) {
            path = new Path();
        }
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(event.getX(), event.getY());
                path.lineTo(event.getX(), event.getY());
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(event.getX(), event.getY());
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                path.lineTo(event.getX(), event.getY());
                invalidate();
                break;
            default:
                break;
        }
        return true;
    }

    public Bitmap getBitmap() {
        Bitmap b = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Drawable oldBackground = getBackground();
        layout(getLeft(), getTop(), getRight(), getBottom());
        setBackgroundColor(getResources().getColor(R.color.white));
        draw(c);
        setBackgroundDrawable(oldBackground);
        return b;
    }
}