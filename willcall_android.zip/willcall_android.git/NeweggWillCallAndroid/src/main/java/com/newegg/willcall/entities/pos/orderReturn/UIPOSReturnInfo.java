package com.newegg.willcall.entities.pos.orderReturn;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class UIPOSReturnInfo implements Serializable {
    public enum RestockingFeeType{
        Percent, FixedPrice
    }

    private BigDecimal restockingFeeRate = new BigDecimal("0");

    private RestockingFeeType restockingFeeType = RestockingFeeType.FixedPrice;

    private List<POSReturnTransactionDTO> transactionCollection = new ArrayList<POSReturnTransactionDTO>();

    private List<GiftCardReturnTransactionDTO> giftCardCollection = new ArrayList<GiftCardReturnTransactionDTO>();

    private List<GiftCardReturnTransactionDTO> originalGiftCardCollection = new ArrayList<GiftCardReturnTransactionDTO>();

    public void setOriginalGiftCardCollection(List<GiftCardReturnTransactionDTO> originalGiftCardCollection) {
        sortGiftCard(originalGiftCardCollection);
        this.originalGiftCardCollection = originalGiftCardCollection;
    }

    public List<POSReturnTransactionDTO> getTransactionCollection() {
        return transactionCollection;
    }

    public List<GiftCardReturnTransactionDTO> getGiftCardCollection() {
        return giftCardCollection;
    }

    public RestockingFeeType getRestockingFeeType() {
        return restockingFeeType;
    }


    public void setRestockingFeeType(RestockingFeeType restockingFeeType) {
        this.restockingFeeType = restockingFeeType;
    }

    public BigDecimal getRestockingFeeRate() {
        return restockingFeeRate;
    }

    public void setRestockingFeeRate(BigDecimal restockingFeeRate) {
        this.restockingFeeRate = restockingFeeRate;
    }

    public BigDecimal getTotalDiscountAmount() {
        BigDecimal totalDiscountAmount = new BigDecimal("0");
        for(POSReturnTransactionDTO item : transactionCollection){
            if(item.getDiscountAmount() != null){
                totalDiscountAmount = totalDiscountAmount.add(item.getDiscountAmount());
            }
        }
        return totalDiscountAmount;
    }


    public BigDecimal getTotalUnitPrice() {
        BigDecimal totalUnitPrice = new BigDecimal("0");
        for(POSReturnTransactionDTO item : transactionCollection){
            if(item.getUnitPrice() != null){
                totalUnitPrice = totalUnitPrice.add(item.getUnitPrice());
            }
        }
        return totalUnitPrice;
    }

    public BigDecimal getTotalTaxAmount() {
        BigDecimal totalTaxAmount = new BigDecimal("0");
        for(POSReturnTransactionDTO item : transactionCollection){
            if(item.getTaxAmount() != null){
                totalTaxAmount = totalTaxAmount.add(item.getTaxAmount());
            }
        }
        return totalTaxAmount;
    }

    public BigDecimal getTotalEWRA() {
        BigDecimal totalEWRA = new BigDecimal("0");
        for(POSReturnTransactionDTO item : transactionCollection){
            if(item.getEwra() != null){
                totalEWRA = totalEWRA.add(item.getEwra());
            }
        }
        return totalEWRA;
    }

    public BigDecimal getTotalAmount() {
        return getTotalUnitPrice()
                .add(getTotalTaxAmount())
                .add(getTotalEWRA())
                .add(getTotalDiscountAmount())
                .subtract(getRestockingFee());
    }

    public BigDecimal getRestockingFee() {
        if(restockingFeeType == RestockingFeeType.FixedPrice){
            return getRestockingFeeRate();
        }else {
            BigDecimal totalAmount = getTotalUnitPrice()
                .add(getTotalTaxAmount())
                .add(getTotalEWRA())
                .add(getTotalDiscountAmount());
            return totalAmount.multiply(getRestockingFeeRate());
        }
    }


    public void reassignGiftCard(){
        if(this.originalGiftCardCollection == null || this.originalGiftCardCollection.size() == 0){
            return;
        }

        BigDecimal totalAmount = getTotalAmount();
        this.giftCardCollection.clear();

        for(GiftCardReturnTransactionDTO gift : this.originalGiftCardCollection) {
            BigDecimal totalGiftCardAmount = getTotalGiftCardAmount();
            if(totalAmount.compareTo(totalGiftCardAmount) == 0){
                break;
            }

            //这张gift的剩余退款金额
            BigDecimal giftBalance = getGiftCardBalance(gift);
            //这张gift已经退完
            if(giftBalance.signum() == 0){
                continue;
            }

            BigDecimal giftReturnAmount;
            if(totalGiftCardAmount.add(giftBalance).compareTo(totalAmount) > 0){
                giftReturnAmount = totalAmount.subtract(totalGiftCardAmount);
            }else{
                giftReturnAmount = giftBalance;
            }

            GiftCardReturnTransactionDTO usedGift = this.findGiftCard(gift.getGiftCardCode());
            if(usedGift == null){
                usedGift = new GiftCardReturnTransactionDTO();
                usedGift.setGiftCardCode(gift.getGiftCardCode());
                usedGift.setIsExpired(gift.getIsExpired());
                usedGift.setPriorityOrder(gift.getPriorityOrder());

                usedGift.setReturnAmount(giftReturnAmount);
                this.giftCardCollection.add(usedGift);
            }else{
                usedGift.setReturnAmount(usedGift.getReturnAmount().add(giftReturnAmount));
            }
        }
    }

    public BigDecimal getTotalGiftCardAmount() {
        BigDecimal totalGiftCard = new BigDecimal("0");
        if(giftCardCollection != null && giftCardCollection.size() > 0){
            for(GiftCardReturnTransactionDTO item : giftCardCollection){
                if(item.getReturnAmount() != null){
                    totalGiftCard = totalGiftCard.add(item.getReturnAmount());
                }
            }
        }
        return totalGiftCard;
    }


    public BigDecimal getCreditCardAmount() {
        return getTotalAmount().subtract(getTotalGiftCardAmount());
    }

    private BigDecimal getGiftCardBalance(GiftCardReturnTransactionDTO gift){
        GiftCardReturnTransactionDTO usedGift = this.findGiftCard(gift.getGiftCardCode());
        if(usedGift != null){
            return gift.getReturnAmount().subtract(usedGift.getReturnAmount());
        }else{
            return gift.getReturnAmount();
        }
    }

    private GiftCardReturnTransactionDTO findGiftCard(String giftCardCode){
        for(GiftCardReturnTransactionDTO item : this.giftCardCollection) {
            if(item.getGiftCardCode().trim().equalsIgnoreCase(giftCardCode.trim())){
                return item;
            }
        }
        return null;
    }


    private void sortGiftCard(List<GiftCardReturnTransactionDTO> giftCardList) {
        if(giftCardList ==  null){
            return;
        }

        Collections.sort(giftCardList, new Comparator<GiftCardReturnTransactionDTO>(){

            @Override
            public int compare(GiftCardReturnTransactionDTO left, GiftCardReturnTransactionDTO right) {
                return right.getPriorityOrder() - left.getPriorityOrder();
            }
        });
    }


}
