package com.newegg.willcall.listener;

/**
 * Created by lenayan on 14-4-10.
 */
public interface OnDataSetChangedListener {
    public void onDataSetChanged();
}
