package com.newegg.willcall.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintJob;
import android.print.PrintManager;
import android.widget.Toast;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import com.newegg.willcall.activity.pos.tools.TimeTrace;
import com.newegg.willcall.cache.NeweggFileCache;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by jaredluo on 12/23/14.
 */
public class PDFUtils {

    public static File bitmap2Pdf(Bitmap bitmap, String fileName) throws IOException, DocumentException {
        String cacheRoot = NeweggFileCache.getInstance().getCacheRoot();
        Document document = new Document(PageSize.A4);

        File file = new File(cacheRoot, fileName);
        PdfWriter docWriter = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] bytes = baos.toByteArray();

        Image image = Image.getInstance(bytes);

        float width = image.getScaledWidth();
        float height = image.getScaledHeight();

        PdfContentByte canvas = docWriter.getDirectContentUnder();

        int pages = (int) (height / PageSize.A4.getHeight()) + 1;
        float mod = height % PageSize.A4.getHeight();
        for (int i = pages - 1; i >= 0; i--) {

            canvas.addImage(image, width, 0, 0, height, 0, -(mod + PageSize.A4.getHeight() * (i - 1)));
            if (mod != 0 || i != pages - 1) {
                document.newPage();
            }
        }

        document.close();
        docWriter.close();
        return file;
    }

    public static void printPDF(Context context, final File file) {

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            final TimeTrace timeTrace=new TimeTrace("print invoice");
            timeTrace.start("");
            PrintDocumentAdapter pda = new PrintDocumentAdapter() {
                @Override
                public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback) {
                    InputStream input = null;
                    OutputStream output = null;

                    try {

                        input = new FileInputStream(file);
                        output = new FileOutputStream(destination.getFileDescriptor());

                        byte[] buf = new byte[1024];
                        int bytesRead;

                        while ((bytesRead = input.read(buf)) > 0) {
                            output.write(buf, 0, bytesRead);
                        }
                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                        }


                    } catch (FileNotFoundException e) {
                        //Catch exception
                        e.printStackTrace();
                    } catch (Exception e) {
                        //Catch exception
                        e.printStackTrace();
                    } finally {
                        timeTrace.end("");
                        try {
                            input.close();
                            output.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes, CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle extras) {
                    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        if (cancellationSignal.isCanceled()) {
                            callback.onLayoutCancelled();
                            return;
                        }


                        PrintDocumentInfo pdi = new PrintDocumentInfo.Builder(file.getName()).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build();

                        callback.onLayoutFinished(pdi, true);
                    }
                }
            };

            PrintManager printManager = (PrintManager) context.getSystemService(Context.PRINT_SERVICE);
            String jobName = "Invoice";

            PrintJob job = printManager.print(jobName, pda, null);
            if (job != null) {
                //TODO:
            } else {
                //TODO:
            }
        } else {
            ToastUtil.show(context, "Sorry, printing is only supported on Android 4.4 KitKat or higher", Toast.LENGTH_LONG);
        }


    }
}
