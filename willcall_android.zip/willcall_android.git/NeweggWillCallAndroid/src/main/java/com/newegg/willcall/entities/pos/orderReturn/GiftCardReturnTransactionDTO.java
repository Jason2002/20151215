package com.newegg.willcall.entities.pos.orderReturn;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by jaredluo on 12/25/14.
 */
public class GiftCardReturnTransactionDTO implements Serializable {
    @JSONField(name = "GiftCardCode")
    private String giftCardCode;

    @JSONField(name = "ReturnAmount")
    private BigDecimal returnAmount;

    @JSONField(name = "PriorityOrder")
    private int priorityOrder;

    @JSONField(name = "IsExpired")
    private String isExpired;

    public String getGiftCardCode() {
        return giftCardCode;
    }

    public void setGiftCardCode(String giftCardCode) {
        this.giftCardCode = giftCardCode;
    }

    public BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }

    public int getPriorityOrder() {
        return priorityOrder;
    }

    public void setPriorityOrder(int priorityOrder) {
        this.priorityOrder = priorityOrder;
    }

    public String getIsExpired() {
        return isExpired;
    }

    public void setIsExpired(String isExpired) {
        this.isExpired = isExpired;
    }

}
