package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class CreditCardResInfo implements Serializable{
    private static final long serialVersionUID = -3748187801901890510L;
    @JSONField(name = "CurrencyCode")
    private String currencyCode;
    @JSONField(name = "Amount")
    private String amount;
    @JSONField(name = "CurrentBalance")
    private String currentBalance;
    @JSONField(name = "RedemptionAmount")
    private String redemptionAmount;
    @JSONField(name = "AuthCode")
    private String authCode;
    @JSONField(name = "AVSCode")
    private String avsCode;
    @JSONField(name = "CVV2Code")
    private String cvv2Code;
    @JSONField(name = "CAVVCode")
    private String cavvCode;
    @JSONField(name = "ReconciliationID")
    private String reconciliationID;
    @JSONField(name = "MaskCardNumber")
    private String maskCardNumber;
    @JSONField(name = "IssuerCountry")
    private String issuerCountry;
    @JSONField(name = "Commercial")
    private String commercial;
    @JSONField(name = "BankName")
    private String bankName;
    @JSONField(name = "BankPhone1")
    private String bankPhone1;
    @JSONField(name = "BankPhone2")
    private String bankPhone2;
    @JSONField(name = "ProcessorReasonCode")
    private String processorReasonCode;

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(String currentBalance) {
        this.currentBalance = currentBalance;
    }

    public String getRedemptionAmount() {
        return redemptionAmount;
    }

    public void setRedemptionAmount(String redemptionAmount) {
        this.redemptionAmount = redemptionAmount;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getAvsCode() {
        return avsCode;
    }

    public void setAvsCode(String avsCode) {
        this.avsCode = avsCode;
    }

    public String getCvv2Code() {
        return cvv2Code;
    }

    public void setCvv2Code(String cvv2Code) {
        this.cvv2Code = cvv2Code;
    }

    public String getCavvCode() {
        return cavvCode;
    }

    public void setCavvCode(String cavvCode) {
        this.cavvCode = cavvCode;
    }

    public String getReconciliationID() {
        return reconciliationID;
    }

    public void setReconciliationID(String reconciliationID) {
        this.reconciliationID = reconciliationID;
    }

    public String getMaskCardNumber() {
        return maskCardNumber;
    }

    public void setMaskCardNumber(String maskCardNumber) {
        this.maskCardNumber = maskCardNumber;
    }

    public String getIssuerCountry() {
        return issuerCountry;
    }

    public void setIssuerCountry(String issuerCountry) {
        this.issuerCountry = issuerCountry;
    }

    public String getCommercial() {
        return commercial;
    }

    public void setCommercial(String commercial) {
        this.commercial = commercial;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankPhone1() {
        return bankPhone1;
    }

    public void setBankPhone1(String bankPhone1) {
        this.bankPhone1 = bankPhone1;
    }

    public String getBankPhone2() {
        return bankPhone2;
    }

    public void setBankPhone2(String bankPhone2) {
        this.bankPhone2 = bankPhone2;
    }

    public String getProcessorReasonCode() {
        return processorReasonCode;
    }

    public void setProcessorReasonCode(String processorReasonCode) {
        this.processorReasonCode = processorReasonCode;
    }
}
