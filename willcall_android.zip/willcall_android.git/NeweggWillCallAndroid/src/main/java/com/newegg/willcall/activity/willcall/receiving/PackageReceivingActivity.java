package com.newegg.willcall.activity.willcall.receiving;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.adapter.PackageListReceivingAdapter;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.BooleanResponse;
import com.newegg.willcall.entities.receiving.ReceivingPackageReceiveDTO;
import com.newegg.willcall.entities.receiving.ReceivingPackageScanDTO;
import com.newegg.willcall.http.FastJsonArrayRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.listener.OnDataSetChangedListener;
import com.newegg.willcall.scan.CaptureActivity;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.util.ArrayList;
import java.util.List;

public class PackageReceivingActivity extends BaseActivity {

    private static final int REQUEST_CODE = 0x12;

    private View mContentView = null;
    private View mLoadingView = null;
    private View mErrorView = null;

    private ListView mPackageListView = null;
    private EditText mInputEditText = null;
    private TextView mPackageListCount = null;
    private Button mReceivingBtn = null;

    private PackageListReceivingAdapter mPackageListReceivingAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_receiving);

        if (!WillCallApp.getWarehouse().hasReceivingPrivilege()) {
            ToastUtil.show(this, getString(R.string.privilege_error));
            finish();
            return;
        }

        initView();
        getScanedPackage();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null && !TextUtils.isEmpty(data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY))) {
            String trackingNumnber = data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY);
            mInputEditText.setText("");
            mInputEditText.append(trackingNumnber);
            trackingScan(trackingNumnber);
        }
    }

    public void onScanButtonClicked(View view) {
        Intent intent = new Intent(this, CaptureActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    public void onReveivingButtonClicked(View view) {
        if (mPackageListReceivingAdapter.getCount() == 0)
            return;
        receivingTrackingList();
    }

    public void onRetryClick(View view) {
        mErrorView.setVisibility(View.GONE);
        getScanedPackage();
    }

    private void getScanedPackage() {
        mLoadingView.setVisibility(View.VISIBLE);
        FastJsonArrayRequest<List<String>, String> request = new FastJsonArrayRequest<List<String>, String>(this, String.class, String.format(HttpConfig.PACKAGE_RECEIVING_GET_SCANED, String.valueOf(WillCallApp.getUser().getUserID()), WillCallApp.getWarehouse().getCode()), new Response.Listener<List<String>>() {
            @Override
            public void onResponse(List<String> stringList) {
                if (stringList != null && stringList.size() > 0) {
                    List<String> tmpStrings = new ArrayList<String>();
                    int count = stringList.size();
                    for (int i = count - 1; i >= 0; i--) {
                        tmpStrings.add(stringList.get(i));
                    }
                    stringList = tmpStrings;
                }
                mPackageListReceivingAdapter = new PackageListReceivingAdapter(PackageReceivingActivity.this, stringList, new OnDataSetChangedListener() {
                    @Override
                    public void onDataSetChanged() {
                        controlCountViewStatus();
                    }
                });
                mPackageListView.setAdapter(mPackageListReceivingAdapter);
                mPackageListView.setVisibility(mPackageListReceivingAdapter.getCount() > 0 ? View.VISIBLE : View.GONE);
                controlCountViewStatus();
                mContentView.setVisibility(View.VISIBLE);
                mLoadingView.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                mLoadingView.setVisibility(View.GONE);
                mErrorView.setVisibility(View.VISIBLE);
            }
        });
        VolleyUtil.addToRequestQueue(this, request);
    }

    private void trackingScan(String trackingNumber) {
        final String finalTrackingNumber = trackingNumber == null ? null : trackingNumber.trim();
        if (StringUtil.isTrackingNUmber(finalTrackingNumber)) {
            showProgressDialog();
            ReceivingPackageScanDTO receivingPackageScanDTO = new ReceivingPackageScanDTO(finalTrackingNumber, String.valueOf(WillCallApp.getUser().getUserID()), WillCallApp.getWarehouse().getCode());
            FastJsonObjectRequest<BooleanResponse> trackingRequest = new FastJsonObjectRequest<BooleanResponse>(this, BooleanResponse.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_RECEIVING_SCAN_TRACKING, finalTrackingNumber), receivingPackageScanDTO, new Response.Listener<BooleanResponse>() {
                @Override
                public void onResponse(BooleanResponse result) {
                    hideProgressDialog();
                    if (result.isSuccessful())
                        mPackageListReceivingAdapter.addUPCCode(finalTrackingNumber);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    hideProgressDialog();
                }
            });
            VolleyUtil.addToRequestQueue(this, trackingRequest);
        } else {
            ToastUtil.show(this, String.format(getString(R.string.trackingnumber_input_error), finalTrackingNumber), ToastUtil.TOAST_DURATION_LONG);
        }
    }

    private void receivingTrackingList() {
        showProgressDialog();
        ReceivingPackageReceiveDTO packageReceiveDTO = new ReceivingPackageReceiveDTO(String.valueOf(WillCallApp.getUser().getUserID()), WillCallApp.getWarehouse().getCode());
        FastJsonObjectRequest<Void> receivingRequest = new FastJsonObjectRequest<Void>(this, Void.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_RECEIVING_TRACKING_RECEIVING, String.valueOf(packageReceiveDTO.getUserID())), packageReceiveDTO, new Response.Listener<Void>() {
            @Override
            public void onResponse(Void result) {
                hideProgressDialog();
                int count = mPackageListReceivingAdapter.getCount();
                ToastUtil.show(PackageReceivingActivity.this, getResources().getQuantityString(R.plurals.receiving_result_toast, count, count));
                mPackageListReceivingAdapter.removeAllTrackingNumbers();
                mInputEditText.setText("");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                hideProgressDialog();
            }
        });
        VolleyUtil.addToRequestQueue(this, receivingRequest);
    }

    private void initView() {
        mContentView = findViewById(R.id.receiving_content);
        mLoadingView = findViewById(R.id.loading_layout);
        mErrorView = findViewById(R.id.error_layout);

        mPackageListView = (ListView) findViewById(R.id.package_list);
        mInputEditText = (EditText) findViewById(R.id.package_list_input_edit_text);
        mPackageListCount = (TextView) findViewById(R.id.package_list_count);
        mReceivingBtn = (Button) findViewById(R.id.receiving_btn);

        mInputEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN && !TextUtils.isEmpty(mInputEditText.getText())) {
                    trackingScan(StringUtil.formatInputTrackingNumber(mInputEditText.getText().toString()));
                    return true;
                }
                return false;
            }
        });
        View headerView = LayoutInflater.from(this).inflate(R.layout.package_list_header_layout, mPackageListView, false);
        TextView headerTitleTextView = (TextView) headerView.findViewById(R.id.title);
        headerTitleTextView.setText(getString(R.string.receiving_package_list));
        mPackageListView.addHeaderView(headerView);
    }

//    private String formatInputTrackingNumber(String inputValue) {
//        String prefix = getString(R.string.tracking_number_prefix);
//        String lowerCasePreFix = prefix.toLowerCase();
//        if (inputValue.startsWith(prefix))
//            return inputValue;
//        if (inputValue.startsWith(lowerCasePreFix))
//            return inputValue.replace(lowerCasePreFix, prefix);
//        if (inputValue.toLowerCase().contains(lowerCasePreFix))
//            return inputValue.toLowerCase().replace(lowerCasePreFix, prefix);
//        if (StringUtil.isNumeric(inputValue))
//            return prefix + inputValue;
//        return inputValue;
//    }

    private void controlCountViewStatus() {
        boolean hasPackages = mPackageListReceivingAdapter.getCount() > 0;
        mPackageListCount.setVisibility(hasPackages ? View.VISIBLE : View.GONE);
        mPackageListCount.setText(String.valueOf(mPackageListReceivingAdapter.getCount()));
        mReceivingBtn.setEnabled(hasPackages);
        mPackageListView.setVisibility(hasPackages ? View.VISIBLE : View.GONE);
        mPackageListView.post(new Runnable() {
            @Override
            public void run() {
                mPackageListView.smoothScrollToPosition(mPackageListReceivingAdapter.getCount() - 1 + mPackageListView.getHeaderViewsCount());
            }
        });
    }

    @Override
    public void onBarcodeScanned(final String barcode) {
        super.onBarcodeScanned(barcode);

        if (StringUtil.isEmpty(barcode)){
            return;
        }

        if (mInputEditText == null) {
            return;
        }

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setBarcode(barcode);
            }
        });

    }

    private void setBarcode(String barcode){
        mInputEditText.setText("");
        mInputEditText.append(barcode);
        trackingScan(barcode);
    }
}
