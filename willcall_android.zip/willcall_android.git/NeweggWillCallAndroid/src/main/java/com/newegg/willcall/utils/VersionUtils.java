package com.newegg.willcall.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;

import com.newegg.willcall.activity.main.UpdateActivity;
import com.newegg.willcall.entities.VersionInfo;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by JaredLuo on 14-4-18.
 */
public class VersionUtils {
    private static boolean mIsDownload;

    public static void checkUpdate(Context context, VersionInfo versionInfo) {
        if (versionInfo != null
                && !StringUtil.isEmpty(versionInfo.getCurrentVersion())
                && !StringUtil.isEmpty(versionInfo.getUpgradeInformation())
                && !StringUtil.isEmpty(versionInfo.getUpgradeUrl())) {

            try {
                PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                String version = pInfo.versionName;
                int[] remoteVersion = parseVersion(versionInfo.getCurrentVersion());
                int[] localVersion = parseVersion(version);

                if (remoteVersion == null || localVersion == null) {
                    return;
                }

                boolean needUpdate = compareVersions(localVersion, remoteVersion);
                if (needUpdate) {
                    Intent intent = new Intent(context, UpdateActivity.class);
                    intent.putExtra(UpdateActivity.PARAMS_VERSION_INFO, versionInfo);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }

            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

        }

    }

    public static void stopDownload() {
        mIsDownload = true;
    }

    private static boolean compareVersions(int[] localVersion, int[] remoteVersion) {
        boolean needUpgrade = false;
        for (int i = 0; i < remoteVersion.length; i++) {
            for (int j = 0; j < localVersion.length; j++) {
                if (remoteVersion[i] > localVersion[j]) {
                    needUpgrade = true;
                    return needUpgrade;
                } else if (remoteVersion[i] < localVersion[j]) {
                    needUpgrade = false;
                    return needUpgrade;
                }
            }
        }

        return needUpgrade;

    }

    private static int[] parseVersion(String verStr) {
        String[] verStrs = verStr.split("\\.");
        int[] versions = new int[3];
        if (verStrs != null && verStrs.length == 3) {
            for (int i = 0; i < verStrs.length; i++) {
                String str = verStrs[i];
                try {
                    int ver = Integer.parseInt(str);
                    versions[i] = ver;
                } catch (NumberFormatException e) {
                    return null;
                }
            }

            return versions;
        }
        return null;
    }

    public static void startDownloadThread(final Context context, final String url, final String apkFileName, final DownloadListener listener) {
        new Thread() {
            public void run() {
                String sdpath = Environment.getExternalStorageDirectory() + "/";
                String path = sdpath + "download";
                File file = new File(path);
                if (!file.exists()) {
                    file.mkdir();
                }
                final File apkFile = new File(path, apkFileName);
                if (apkFile.exists()) {
                    apkFile.delete();
                }
                HttpClient client = new DefaultHttpClient();
                HttpGet get = new HttpGet(url);
                HttpResponse response;

                InputStream is = null;
                FileOutputStream fileOutputStream = null;

                try {
                    response = client.execute(get);
                    HttpEntity entity = response.getEntity();
                    long length = entity.getContentLength();

                    is = entity.getContent();

                    if (is != null) {
                        // 获得存储卡的路径
                        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                            fileOutputStream = new FileOutputStream(apkFile);
                        } else {
                            fileOutputStream = context.openFileOutput(apkFile.getName(),
                                    Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE);
                        }
                        byte[] buf = new byte[1024];
                        int ch;
                        int count = 0;
                        mIsDownload = true;
                        while ((ch = is.read(buf)) != -1) {
                            if (mIsDownload) {
                                fileOutputStream.write(buf, 0, ch);
                                count += ch;
                                if (listener != null) {
                                    listener.OnDownloading(length, count, apkFile);
                                }
                            } else {
                                return;
                            }
                        }
                    }
                    fileOutputStream.flush();
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }

                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (is != null) {
                        try {
                            is.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }.start();
    }

    public interface DownloadListener {
        void OnDownloading(long totalSize, long downloadedSize, File apkFile);
    }

    public static void install(Context context, File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        if (!file.exists()) {
            return;
        }
        intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
        context.startActivity(intent);
    }

}
