package com.newegg.willcall.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.picking.ExpiredTrackingInfo;
import com.newegg.willcall.listener.OnDataSetChangedListener;
import com.newegg.willcall.utils.PackageListComparetor;
import com.newegg.willcall.utils.StringUtil;

import java.util.Collections;
import java.util.List;

/**
 * Created by lenayan on 14-4-10.
 */
public class PackageListPickingAdapter extends PackageListAdapter<ExpiredTrackingInfo> {

    private int mScanedPackagesCount = 0;

    public int getScanedPackagesCount() {
        return mScanedPackagesCount;
    }

    public PackageListPickingAdapter(Context context, List<ExpiredTrackingInfo> packageList, OnDataSetChangedListener listener) {
        super(context, packageList, listener);
        if (mItemsList != null && mItemsList.size() > 0) {
            int count = mItemsList.size();
            for (int i = 0; i < count; i++) {
                ExpiredTrackingInfo expiredTrackingInfo = mItemsList.get(i);
                if (expiredTrackingInfo.getScaned().equals(ExpiredTrackingInfo.SCANED_YES))
                    mScanedPackagesCount++;
            }
        }
        Collections.sort(mItemsList, new PackageListComparetor());
    }

    public void changePackageItemState(String trackingNumber) {
        int position = getPositionByItemTrackingNumber(trackingNumber);
        if (position >= 0) {
            ExpiredTrackingInfo expiredTrackingInfo = getItem(position);
            if (expiredTrackingInfo != null && !expiredTrackingInfo.hasScaned()) {
                expiredTrackingInfo.setScaned(ExpiredTrackingInfo.SCANED_YES);
                mScanedPackagesCount++;
                Collections.sort(mItemsList, new PackageListComparetor());
                notifyDataSetChanged();
            }
        }
    }

    public boolean isScaned(String trackingNumber) {
        ExpiredTrackingInfo expiredTrackingInfo = getItemByTrackingNumber(trackingNumber);
        if (expiredTrackingInfo != null && expiredTrackingInfo.hasScaned()) {
            return true;
        }
        return false;
    }

    private ExpiredTrackingInfo getItemByTrackingNumber(String trackingNumber) {
        int count = getCount();
        for (int i = 0; i < count; i++) {
            ExpiredTrackingInfo expiredTrackingInfo = getItem(i);
            if (expiredTrackingInfo.getTrackingNumber().toLowerCase().equals(trackingNumber.toLowerCase())) {
                return expiredTrackingInfo;
            }
        }
        return null;
    }

    public int getPositionByItemTrackingNumber(String trackingNumber) {
        int count = getCount();
        for (int i = 0; i < count; i++) {
            ExpiredTrackingInfo expiredTrackingInfo = getItem(i);
            if (expiredTrackingInfo.getTrackingNumber().toLowerCase().equals(trackingNumber.toLowerCase())) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PackageListViewHolder viewHolder;
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new PackageListViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.package_list_cell_with_tag, parent, false);
            viewHolder.packageTitle = (TextView) convertView.findViewById(R.id.tracking_number);
            viewHolder.packageTag = (TextView) convertView.findViewById(R.id.picking_tag);
            viewHolder.packageLocation = (TextView) convertView.findViewById(R.id.package_location);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (PackageListViewHolder) convertView.getTag();
        }
        ExpiredTrackingInfo expiredTrackingInfo = getItem(position);
        viewHolder.packageTitle.setText((position + 1) + ". " + expiredTrackingInfo.getTrackingNumber());
        viewHolder.packageTag.setVisibility(expiredTrackingInfo.getScaned().equals(ExpiredTrackingInfo.SCANED_YES) ? View.VISIBLE :
                View.GONE);
        if (expiredTrackingInfo.getScaned().equals(ExpiredTrackingInfo.SCANED_YES)) {
            viewHolder.packageLocation.setVisibility(View.GONE);
        } else if (!StringUtil.isEmpty(expiredTrackingInfo.getLocation())) {
            viewHolder.packageLocation.setVisibility(View.VISIBLE);
            viewHolder.packageLocation.setText(mContext.getString(R.string.picking_location) + expiredTrackingInfo.getLocation());
        } else {
            viewHolder.packageLocation.setVisibility(View.GONE);
        }
        return convertView;
    }

    private static class PackageListViewHolder {
        TextView packageTitle;
        TextView packageTag;
        TextView packageLocation;
    }

}

