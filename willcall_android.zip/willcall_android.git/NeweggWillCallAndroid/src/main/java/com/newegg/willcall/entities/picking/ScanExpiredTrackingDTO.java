package com.newegg.willcall.entities.picking;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-10.
 */
public class ScanExpiredTrackingDTO {

    @JSONField(name = "TrackingNumber")
    private String mTrackingNumber;
    @JSONField(name = "UserID")
    private String mUserID;

    public ScanExpiredTrackingDTO(String trackingNumber, String userID) {
        mTrackingNumber = trackingNumber;
        mUserID = userID;
    }

    public String getTrackingNumber() {
        return mTrackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        mTrackingNumber = trackingNumber;
    }

    public String getUserID() {
        return mUserID;
    }

    public void setUserID(String userID) {
        mUserID = userID;
    }
}
