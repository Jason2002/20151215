package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class ItemInformation implements Serializable {
    private static final long serialVersionUID = 4844865188000514645L;
    @JSONField(name = "ItemNumber")
    private String itemNumber;
    @JSONField(name = "Description")
    private String description;
    @JSONField(name = "Quantity")
    private int quantity;
    @JSONField(name = "UnitPrice")
    private double unitPrice;
    @JSONField(name = "UnitTax")
    private double unitTax;
    @JSONField(name = "UnitDiscount")
    private double unitDiscount;
    @JSONField(name = "UnitEWRA")
    private double unitEWRA;
    @JSONField(name = "IsEWRAItem")
    private Boolean ewraItem;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getUnitTax() {
        return unitTax;
    }

    public void setUnitTax(double unitTax) {
        this.unitTax = unitTax;
    }

    public double getUnitDiscount() {
        return unitDiscount;
    }

    public void setUnitDiscount(double unitDiscount) {
        this.unitDiscount = unitDiscount;
    }

    public double getUnitEWRA() {
        return unitEWRA;
    }

    public void setUnitEWRA(double unitEWRA) {
        this.unitEWRA = unitEWRA;
    }

    public Boolean isEwraItem() {
        return ewraItem;
    }

    public void setEwraItem(Boolean ewraItem) {
        this.ewraItem = ewraItem;
    }
}
