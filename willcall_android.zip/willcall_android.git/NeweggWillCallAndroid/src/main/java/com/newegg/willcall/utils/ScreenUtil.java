/****************************************************************** 
 * Copyright (C) Newegg Corporation. All rights reserved.
 *
 * Author: Shark Lin(Shark.M.Lin@newegg.com) 
 * Create Date: 09/15/2011
 * Description:
 *
 * Revision History:
 *      Date         Author               Description
 *
 *****************************************************************/

package com.newegg.willcall.utils;

import android.content.Context;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Window;
import android.view.WindowManager;

public class ScreenUtil {

    private static Context sContext;
    private static WindowManager sWindowManger;

    public static void setContext(Context ctx) {
        sContext = ctx;
        sWindowManger = (WindowManager) sContext.getSystemService(
                Context.WINDOW_SERVICE);
    }

    public static int getPxByDp(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, sContext.getResources()
                .getDisplayMetrics());
    }

    public static int getPxByDp(float dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, sContext.getResources()
                .getDisplayMetrics());
    }

    public static int getDpByPx(int px) {

        final float scale = sContext.getResources().getDisplayMetrics().density;
        return (int) (px / scale + 0.5f);
    }


    public static int sp2px(float spValue) {
        final float fontScale = sContext.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }

    public static int px2sp(float pxValue) {
        final float fontScale = sContext.getResources().getDisplayMetrics().scaledDensity;
        return (int) (pxValue / fontScale + 0.5f);
    }

    public static float pxToSp(Float px) {
        float scaledDensity = sContext.getResources().getDisplayMetrics().scaledDensity;
        return px / scaledDensity;
    }

    public static int getScreenWidth() {
        DisplayMetrics metrics = new DisplayMetrics();
        sWindowManger.getDefaultDisplay().getMetrics(metrics);
        return metrics.widthPixels;
    }

    public static int getScreenHeight() {
        DisplayMetrics metrics = new DisplayMetrics();
        sWindowManger.getDefaultDisplay().getMetrics(metrics);
        return metrics.heightPixels;
    }

    public static float getScreenDensity() {
        DisplayMetrics metrics = new DisplayMetrics();
        sWindowManger.getDefaultDisplay().getMetrics(metrics);
        return metrics.density;
    }

    public static float getScreenPPI() {
        DisplayMetrics metrics = new DisplayMetrics();
        sWindowManger.getDefaultDisplay().getMetrics(metrics);
        return metrics.densityDpi;
    }

    public static float getScreenInch() {
        return (float) Math.sqrt((Math.pow(getScreenHeight(), 2) + Math.pow(getScreenWidth(), 2))) / getScreenPPI();

    }

    public static float getStatusBarHight(Window window) {
        Rect rectgle = new Rect();
        window.getDecorView().getWindowVisibleDisplayFrame(rectgle);
        int statusBarHeight = rectgle.top;
        return statusBarHeight;
    }
}
