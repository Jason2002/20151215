package com.newegg.willcall.http;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.event.OnActionListener1;
import com.newegg.willcall.utils.StringUtil;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dy45 on 5/28/2015.
 */
public class RequestWrapper{

    private Context context;

    public RequestWrapper(Context context){
        this.context = context;
    }

    private HashMap<String,String> extraHeaders = new HashMap<String, String>(10);
    public void addHeader(String key,String value){
        if(!StringUtil.isEmpty(key)) {
            extraHeaders.put(key, value);
        }
    }

    private <T> void sendRequest(Class<T> clazz,String url,int method,Object reqDTO,final OnActionListener1<RestResult<T>> listener1){
        FastJsonObjectRequest<T> req = new FastJsonObjectRequest<T>(context,clazz,url,method,reqDTO,new Response.Listener<T>() {
            @Override
            public void onResponse(T t) {
                listener1.action(new RestResult<T>(t));
            }
        },new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                listener1.action(new RestResult<T>(info));
            }
        });
        setHeader(req);
        VolleyUtil.addToRequestQueue(context,req);
    }

    private <T> void sendArrayRequest(Class<T> clazz,String url,int method,Object reqDTO,final OnActionListener1<RestResult<List<T>>> listener1){
        FastJsonArrayRequest<List<T>,T> req=new FastJsonArrayRequest<List<T>, T>(context,clazz,url,method,reqDTO,new Response.Listener<List<T>>() {
            @Override
            public void onResponse(List<T> list) {
                listener1.action(new RestResult<List<T>>(list));
            }
        },new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                listener1.action(new RestResult<List<T>>(info));
            }
        });
        setHeader(req);
        VolleyUtil.addToRequestQueue(context,req);
    }

    public <T> void getObject(Class<T> clazz,String url,final OnActionListener1<RestResult<T>> listener1){
        sendRequest(clazz,url, Request.Method.GET,null,listener1);
    }

    public <T> void putObject(Class<T> clazz,String url,Object reqDTO,final OnActionListener1<RestResult<T>> listener1){
        sendRequest(clazz,url, Request.Method.PUT,reqDTO,listener1);
    }

    public <T> void postObject(Class<T> clazz,String url,Object reqDTO,final OnActionListener1<RestResult<T>> listener1){
        sendRequest(clazz,url, Request.Method.POST,reqDTO,listener1);
    }

    public <T> void getArray(Class<T> clazz,String url, final OnActionListener1<RestResult<List<T>>> listener1){
        sendArrayRequest(clazz,url, Request.Method.GET,null,listener1);
    }
    public <T> void putArray(Class<T> clazz,String url,Object reqDTO, final OnActionListener1<RestResult<List<T>>> listener1){
        sendArrayRequest(clazz,url, Request.Method.PUT,reqDTO,listener1);
    }
    public <T> void postArray(Class<T> clazz,String url,Object reqDTO, final OnActionListener1<RestResult<List<T>>> listener1){
        sendArrayRequest(clazz,url, Request.Method.POST,reqDTO,listener1);
    }

    public <T> void uploadFile(String url,File file,final OnActionListener1<RestResult<String>> listener1){
        UploadFileRequest req = new UploadFileRequest(context,url,file,new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                listener1.action(new RestResult<String>(s));
            }
        }, new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                listener1.action(new RestResult<String>(info));
            }
        });
        setHeader(req);
        VolleyUtil.addToRequestQueue(context,req);
    }

    private void setHeader(BaseRequest<?> request){
        for(Map.Entry<String,String> item:extraHeaders.entrySet()){
            request.addHeader(item.getKey(),item.getValue());
        }
    }

}
