package com.newegg.willcall.activity.base;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextSwitcher;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.grabba.Grabba;
import com.grabba.GrabbaBarcode;
import com.grabba.GrabbaBarcodeListener;
import com.grabba.GrabbaButtonListener;
import com.grabba.GrabbaConnectionListener;
import com.grabba.GrabbaDriverNotInstalledException;
import com.grabba.GrabbaException;
import com.grabba.GrabbaMagstripe;
import com.grabba.GrabbaMagstripeListener;
import com.newegg.willcall.MainActivity;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.account.AboutUsActivity;
import com.newegg.willcall.activity.account.LoginActivity;
import com.newegg.willcall.activity.main.WarehouseActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.cache.NeweggFileCache;
import com.newegg.willcall.entities.BooleanResponse;
import com.newegg.willcall.entities.LogOutDTO;
import com.newegg.willcall.entities.WarehouseCache;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.umeng.analytics.MobclickAgent;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by JaredLuo on 4/2/14.
 */
public class BaseActivity extends ActionBarActivity {

    boolean isPaused = false;
    boolean isInstalled = false;
    boolean isLandscape = false;

    private ProgressDialog mProgressDialog = null;
    private Handler mHandler = null;

    public void setIsLandscape(boolean isLandscape) {
        this.isLandscape = isLandscape;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isLandscape) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (WillCallApp.getUser() == null || TextUtils.isEmpty(WillCallApp.getAuthKey()) || WillCallApp.getWarehouse() == null) {
            redirectToLogin();
        }
    }

    private void redirectToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        MobclickAgent.onResume(this);

        ToastUtil.getScreenWidth(this);

        regGrabba();

        isPaused = false;
    }

    @Override
    protected void onPause() {
        super.onPause();

        MobclickAgent.onPause(this);

        unRegGrabba();

        isPaused = true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            case R.id.action_home:
                backToHome();
                break;
            case R.id.action_change_will_call_center:
                startActivity(new Intent(this, WarehouseActivity.class));
                break;
            case R.id.action_about_us:
                startActivity(new Intent(this, AboutUsActivity.class));
                break;
            case R.id.log_out:
                logOut();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        VolleyUtil.cancelPendingRequests(this);
    }

    protected void backToHome() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(MainActivity.PARAM_APP_TYPE, WillCallApp.getAppType());
        startActivity(intent);
    }

    private void logOut() {
        if (mHandler == null)
            mHandler = new Handler();
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                showProgressDialog();
                FastJsonObjectRequest<BooleanResponse> request = new FastJsonObjectRequest<BooleanResponse>(BaseActivity.this, BooleanResponse.class, HttpConfig.LOGOUT, new LogOutDTO(String.valueOf(WillCallApp.getUser().getUserID())), new Response.Listener<BooleanResponse>() {
                    @Override
                    public void onResponse(BooleanResponse result) {
                        hideProgressDialog();
                        if (result != null && result.isSuccessful()) {

                            NeweggFileCache.getInstance().remove(WarehouseActivity.KEY_CACHE_KEY);
                            NeweggFileCache.getInstance().remove(WarehouseActivity.NAME_CACHE_KEY);
                            PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).edit().remove(WarehouseActivity.PARAM_NEED_REMEMBER_PASSWORD).commit();
                            List<WarehouseCache> caches = NeweggFileCache.getInstance().get(WarehouseActivity.USER_WAREHOUSE_LIST_CACHE);
                            WarehouseCache removeCache = null;
                            if (caches != null && caches.size() > 0) {
                                for (WarehouseCache cache : caches) {
                                    if (WillCallApp.getUser().getUserID() == cache.getUserID()) {
                                        removeCache = cache;
                                        break;
                                    }
                                }
                            }
                            if (removeCache != null) {
                                caches.remove(removeCache);
                                NeweggFileCache.getInstance().put(WarehouseActivity.USER_WAREHOUSE_LIST_CACHE, caches);
                            }

                            WillCallApp.setAuthKey(null);
                            WillCallApp.setUser(null);
                            WillCallApp.setWarehouse(null);
                            Intent intent = new Intent(BaseActivity.this, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        hideProgressDialog();
                    }
                });
                VolleyUtil.addToRequestQueue(BaseActivity.this, request);
            }
        });
    }


    protected void showProgressDialog() {
        showProgressDialog(true);
    }

    protected void showProgressDialog(boolean cancelable) {

        if (isPaused) {
            return;
        }

        if (mProgressDialog == null) mProgressDialog = new ProgressDialog(this);
        mProgressDialog.show();
        mProgressDialog.setCancelable(cancelable);
        mProgressDialog.setContentView(com.newegg.willcall.R.layout.progress_dialog_layout);
    }

    protected void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing())
            mProgressDialog.dismiss();
    }

    private void regGrabba() {

        try {
            Grabba.open(this, "NeweggWillCall");
            isInstalled = true;
        } catch (GrabbaDriverNotInstalledException e) {
            isInstalled = false;
            //toast("GrabbaDriverNotInstalledException:"+e.toString());
        }

        if (!isInstalled) {
            return;
        }

        // Register listeners to receive events
        Grabba.getInstance().addConnectionListener(grabbaConnectionListener);
        GrabbaMagstripe.getInstance().addEventListener(grabbaMagstripeListener);
        Grabba.getInstance().addButtonListener(grabbaButtonListener);

        GrabbaBarcode.getInstance().addEventListener(grabbaBarcodeListener);

        Grabba.getInstance().acquireGrabba();
    }

    private void unRegGrabba() {
        if (!isInstalled) {
            return;
        }

        // Unregister listeners to prevent unintentional event triggers
        Grabba.getInstance().removeConnectionListener(grabbaConnectionListener);
        GrabbaMagstripe.getInstance().removeEventListener(
                grabbaMagstripeListener);
        Grabba.getInstance().removeButtonListener(grabbaButtonListener);

        GrabbaBarcode.getInstance().removeEventListener(grabbaBarcodeListener);

        Grabba.getInstance().releaseGrabba();
    }

    private final GrabbaButtonListener grabbaButtonListener = new GrabbaButtonListener() {

        @Override
        public void grabbaRightButtonEvent(boolean arg0) {

            startScan();
        }

        @Override
        public void grabbaLeftButtonEvent(boolean arg0) {

            startScan();
        }
    };

    private void startScan() {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    // Start barcode scanning
                    GrabbaBarcode.getInstance().trigger(true);
                } catch (GrabbaException e) {
                    // Print the exception on the screen
                    toast("Grabba Exception:" + e.toString());
                }
                return null;
            }
        }.execute();
    }

    private final GrabbaBarcodeListener grabbaBarcodeListener = new GrabbaBarcodeListener() {

        @Override
        public void barcodeTriggeredEvent() {
            // TODO Auto-generated method stub
        }

        @Override
        public void barcodeTimeoutEvent() {
            // TODO Auto-generated method stub
        }

        @Override
        public void barcodeScanningStopped() {
            // TODO Auto-generated method stub
        }

        @Override
        public void barcodeScannedEvent(String barcode, int symbologyType) {
            // TODO Auto-generated method stub
            LogUtil.i("test", "scanned:" + symbologyType);
            onBarcodeScanned(barcode);
        }
    };

    private final GrabbaConnectionListener grabbaConnectionListener = new GrabbaConnectionListener() {

        @Override
        public void grabbaDisconnectedEvent() {
            toast("Grabba Disconnected");
        }

        @Override
        public void grabbaConnectedEvent() {

        }
    };


    private void setText(final int id, final String text) {
        final View v = findViewById(id);
        if (v == null) {
            return;
        }
        // Check if v is attached to a window. If not, we can set the text
        // directly.
        // Note: This is done so that no text is lost if the view is not
        // attached.
        if (v.getHandler() == null) {
            ((TextView) v).setText(text);
        } else {
            v.post(new Runnable() {
                public void run() {
                    if (v instanceof TextView) {
                        ((TextView) v).setText(text);
                    } else if (v instanceof TextSwitcher) {
                        ((TextSwitcher) v).setText(text);
                    }
                }
            });
        }
    }

    private void toast(final String msg) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ToastUtil.show(BaseActivity.this, msg);
            }
        });
    }

    public void onBarcodeScanned(String barcode) {

    }

    public void onCreditCardScanned(String number, String owner, String exp, String track1, String track2) {

    }

    private final GrabbaMagstripeListener grabbaMagstripeListener = new GrabbaMagstripeListener() {

        @Override
        public void magstripeReadEvent(byte[] track1, byte[] track2,
                                       byte[] track3) {

            String track1Str = getDataForTrack(track1);
            String track2Str = getDataForTrack(track2);

            LogUtil.i("test", track1Str);

            // Track1 looks like the %B[numberofcreditcard]^Name^ExperiationDate
            Pattern p = Pattern.compile("%B([0-9]+)\\^([^\\^]+)\\^([0-9]+)\\?*");
            Matcher m = p.matcher(track1Str);
            if (m.find()) {
                String number = m.group(1);
                String owner = m.group(2).replace("/", " ").trim();
                String exp = m.group(3);
                if (exp.length() >= 4) {
                    exp = exp.substring(2, 4) + "/" + exp.substring(0, 2);
                }
                bindToUI(number, owner, exp, track1Str, track2Str);
            } else {
                BaseActivity.this.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        toast("Credit card is invalid");
                    }
                });
            }
//
//            try {
//                String number = m.group(1);
//                String owner = m.group(2);
//                String exp = m.group(3);
//                if (exp.length() >= 4) {
//                    exp = exp.substring(2, 4) + "/" + exp.substring(0, 2);
//                }
//                bindToUI(number, owner, exp, track1Str, track2Str);
//            } catch (IllegalStateException e) {
//                BaseActivity.this.runOnUiThread(new Runnable() {
//
//                    @Override
//                    public void run() {
//                        toast("Credit card is invalid");
//                    }
//                });
//            }

        }

        private void bindToUI(final String number, final String owner,
                              final String exp, final String track1, final String track2) {
            BaseActivity.this.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    onCreditCardScanned(number, owner, exp, track1, track2);
                }
            });

        }

        private String getDataForTrack(byte[] tracks) {
            if (tracks == null) {
                return "";
            }
            if (tracks.length == 0) {
                return "";
            }


            return new String(tracks);

        }

        @Override
        public void magstripeRawReadEvent(byte[] track1raw, byte[] track2raw,
                                          byte[] track3raw) {
        }
    };

    public void openKeyboard(final EditText et) {
        et.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager keyboard = (InputMethodManager) BaseActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                keyboard.showSoftInput(et, 0);
            }
        }, 200);
    }

    public void hideKeyboard(EditText et) {
        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
    }
}
