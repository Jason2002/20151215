package com.newegg.willcall.activity.pos.order;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.pos.tools.TimeTrace;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.order.CustomerEmailReq;
import com.newegg.willcall.http.BaseRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

public class POSPrintActivity extends BaseActivity {

    public static final String PARAM_SO_NUMBER = "PARAM_SO_NUMBER";
    public static final String PARAM_PDF_FILE_NAME = "PDF_FILE_NAME";
    public static final String REQUEST_ADD_EMAIL = "REQUEST_ADD_EMAIL";
    private int mSONumber;

    private CheckBox mEmailCheckbox;
    private String mFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posprint);

        mEmailCheckbox = (CheckBox) findViewById(R.id.email_checkbox);

        if (getIntent() != null) {
            mSONumber = getIntent().getIntExtra(PARAM_SO_NUMBER, 0);
            mFilePath = getIntent().getStringExtra(PARAM_PDF_FILE_NAME);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    public void onPrintButtonClicked(View view) {

        if (mEmailCheckbox.isChecked()) {

            View layout = getLayoutInflater().inflate(R.layout.pos_print_mail_dialog, null);
            final EditText emailEt = (EditText) layout.findViewById(R.id.email_address_editText);
            final AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("")
                    .setView(layout)
                    .setPositiveButton("Done", null)
                    .setNegativeButton("Cancel", null)
                    .create();
            dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface d) {
                    Button button = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (emailEt.getText() == null || StringUtil.isEmpty(emailEt.getText().toString()) || !StringUtil.isEmail(emailEt.getText().toString())) {
                                emailEt.setError(getString(R.string.pos_checkout_email_address_empty));
                                ToastUtil.show(POSPrintActivity.this, getString(R.string.pos_checkout_email_address_empty));
                            } else if (mSONumber != 0) {
                                emailEt.setError(null);
                                requestAddEmail(emailEt.getText().toString());
                                dialog.dismiss();
                            }
                        }
                    });
                }
            });
            dialog.show();
        } else {
            goToThankyou();
        }
    }

    private void requestAddEmail(String email) {
        CustomerEmailReq emailReq = new CustomerEmailReq();
        emailReq.setSoNumber(mSONumber);
        emailReq.setCustomerEmail(email);
        final TimeTrace timeTrace = new TimeTrace("upload email");
        timeTrace.start("SO#:"+mSONumber);

        FastJsonObjectRequest<String> request = new FastJsonObjectRequest<String>(this, String.class, Request.Method.PUT, HttpConfig.getFormatUrl(HttpConfig.POS_ADD_CUSTOM_EMAIL, mSONumber + ""), emailReq, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                timeTrace.end("SO#:"+mSONumber+" successfully");
                hideProgressDialog();
                goToThankyou();
            }
        }, new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();
                timeTrace.end("SO#:"+mSONumber+" failed");
                if(info != null && info.getMessage() != null){
                    ToastUtil.show(POSPrintActivity.this, info.getMessage(), Toast.LENGTH_LONG);
                }
            }
        });

        VolleyUtil.addToRequestQueue(this, request, REQUEST_ADD_EMAIL);
    }

    private void goToThankyou(){
        Intent intent = new Intent(this, POSOrderThankyouActivity.class);
        intent.putExtra(POSOrderThankyouActivity.PARAM_PDF_FILE_NAME, mFilePath);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {

    }
}
