package com.newegg.willcall.activity.pos.salesSummary;


import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.DatePicker;

import java.util.Calendar;
import java.util.Date;

public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener  {
    private static final String KEY_DATE = "Date";
    private static final String KEY_TITLE = "Title";

    private OnDateSetListener mCallback;

    public interface OnDateSetListener {
        public void onDateSet(Date date);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            mCallback = (OnDateSetListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement OnDateSetListener interface");
        }
    }

    public static DatePickerFragment newInstance(Date date, String title) {
        DatePickerFragment fragment = new DatePickerFragment();
        Bundle args = new Bundle();
        args.putLong(KEY_DATE, date.getTime());
        args.putString(KEY_TITLE, title);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final Calendar c = Calendar.getInstance();
        c.setTimeInMillis(getArguments().getLong(KEY_DATE));

        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, year, month, day);
        datePickerDialog.setTitle(getArguments().getString(KEY_TITLE));
        return datePickerDialog;
    }

    @Override
    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        if(mCallback != null){
            final Calendar c = Calendar.getInstance();
            c.set(year, monthOfYear, dayOfMonth);
            mCallback.onDateSet(c.getTime());
        }
    }
}
