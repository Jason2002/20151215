package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSOrderSNItem implements Serializable {
    private static final long serialVersionUID = -4465555679237483640L;
    @JSONField(name = "SerialNumber")
    private String serialNumber;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
