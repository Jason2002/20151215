package com.newegg.willcall.activity.willcall.checkout;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.FrameLayout;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.base.BaseFragment;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.newegg.willcall.widget.StepView;

/**
 * Created by JaredLuo on 14-4-8.
 */
public class CheckoutActivity extends BaseActivity {
    public static final int REQUEST_CODE_START_CAPTURE = 0x15;
    public static final String INTENT_ORDER_PICKING_TASK="INTENT_ORDER_PICKING_TASK";

    private Fragment mCurrentFragment;
    private FrameLayout mContainer;
    private StepView mStepView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        getSupportActionBar().setTitle(R.string.checkout_activity_title);

        if (!WillCallApp.getWarehouse().hasCheckoutPrivilege()) {
            ToastUtil.show(this, getString(R.string.privilege_error));
            finish();
            return;
        }

        findView();
        BaseFragment fragment = null;

        FragmentManager fragmentManager = getSupportFragmentManager();
        ReferenceOrderPickingTask task = null;
        if(getIntent()!=null){
            task =(ReferenceOrderPickingTask) getIntent().getSerializableExtra(INTENT_ORDER_PICKING_TASK);
        }
        if(task!=null){
            if(task.isAllScaned()){
                fragment = ItemConfirmationFragment.createItemConfirmationFragment(task);
            }
            else{
                fragment = PackagePickFragment.createPackagePickFragment(task);
            }
        }
        else if (fragmentManager.getBackStackEntryCount() == 0) {
            fragment = new CustomerCheckoutFragment();
        }
        if(fragment != null){
            switchContent(fragment, false);
        }
    }

    private void findView() {

        mContainer = (FrameLayout) findViewById(R.id.checkout_container);
        mStepView = (StepView) findViewById(R.id.checkout_stepview);
    }

    public void setStep(int step) {
        mStepView.setCurrentStep(step);
    }

    public void switchContent(Fragment fragment, boolean isAddedBackStack) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if (isAddedBackStack) {
            fragmentTransaction.setCustomAnimations(R.anim.anim_frag_enter, R.anim.anim_frag_exit, R.anim.anim_frag_pop_enter, R.anim.anim_frag_pop_exit);
        }else{
            fragmentTransaction.setCustomAnimations(0, 0, R.anim.anim_frag_pop_enter, R.anim.anim_frag_pop_exit);
        }
        fragmentTransaction.replace(R.id.checkout_container, fragment);
        if (isAddedBackStack) {
            fragmentTransaction.addToBackStack(null);
        }
        fragmentTransaction.commit();
        mCurrentFragment = fragment;
    }

    @Override
    public void onBarcodeScanned(String barcode) {
        super.onBarcodeScanned(barcode);

        if (StringUtil.isEmpty(barcode)){
            return;
        }

        if (mCurrentFragment != null && mCurrentFragment.isAdded()){
            if (mCurrentFragment instanceof CustomerCheckoutFragment) {
                CustomerCheckoutFragment checkoutFragment = (CustomerCheckoutFragment) mCurrentFragment;
                checkoutFragment.onBarcodeScanned(barcode);
            }else if(mCurrentFragment instanceof PackagePickFragment){
                PackagePickFragment pickFragment = (PackagePickFragment) mCurrentFragment;
                pickFragment.onBarcodeScanned(barcode);
            }
        }
    }
}
