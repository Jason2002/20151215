package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by lenayan on 14-4-9.
 */
public class BooleanResponse implements Serializable {

    private static final long serialVersionUID = -7206334530108788477L;

    @JSONField(name = "IsSuccessful")
    private boolean successful;

    public boolean isSuccessful() {
        return successful;
    }

    public void setSuccessful(boolean isSuccessFull) {
        successful = isSuccessFull;
    }
}
