package com.newegg.willcall.entities.pos.orderReturn;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSReturnDTO implements Serializable {

    @JSONField(name = "POSReturnMaster")
    private POSReturnMasterDTO posReturnMasterDTO;

    @JSONField(name = "TransactionCollection")
    private List<POSReturnTransactionDTO> transactionCollection;

    @JSONField(name = "GiftCardCollection")
    private List<GiftCardReturnTransactionDTO> giftCardCollection;

    public POSReturnMasterDTO getPosReturnMaster() {
        return posReturnMasterDTO;
    }

    public void setPosReturnMaster(POSReturnMasterDTO posReturnMasterDTO) {
        this.posReturnMasterDTO = posReturnMasterDTO;
    }

    public List<POSReturnTransactionDTO> getTransactionCollection() {
        return transactionCollection;
    }

    public void setTransactionCollection(List<POSReturnTransactionDTO> transactionCollection) {
        this.transactionCollection = transactionCollection;
    }

    public List<GiftCardReturnTransactionDTO> getGiftCardCollection() {
        return giftCardCollection;
    }

    public void setGiftCardCollection(List<GiftCardReturnTransactionDTO> giftCardCollection) {
        this.giftCardCollection = giftCardCollection;
    }
}
