package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 1/15/15.
 */
public class DFISDTO implements Serializable {
    private static final long serialVersionUID = 3392503467150184032L;
    @JSONField(name = "FileGroup")
    public String fileGroup;
    @JSONField(name = "FileType")
    public String fileType;
    @JSONField(name = "FileName")
    public String fileName;
    @JSONField(name = "Data")
    public byte[] data;
    @JSONField(name = "Url")
    public String url;
    @JSONField(name = "UserName")
    public String userName;
    @JSONField(name = "UploadType")
    public String uploadType;

    public String getFileGroup() {
        return fileGroup;
    }

    public void setFileGroup(String fileGroup) {
        this.fileGroup = fileGroup;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUploadType() {
        return uploadType;
    }

    public void setUploadType(String uploadType) {
        this.uploadType = uploadType;
    }
}
