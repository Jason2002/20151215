package com.newegg.willcall.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by jaredluo on 12/27/14.
 */
public class CreditCardUtils {

    public static final String AMEX_PAYTERM_CODE = "004";
    public static final String VISA_PAYTERM_CODE = "001";
    public static final String MASTERCARD_PAYTERM_CODE = "002";
    public static final String DISCOVER_PAYTERM_CODE = "003";

    public static final String AMEX_CARD_PATTERN = "^3[47]\\d{13}$";
    public static final String VISA_CARD_PATTERN = "^4\\d{15}$";
    public static final String MASTERCARD_CARD_PATTERN = "^5[1-5]\\d{14}$";
    public static final String DISCOVER_CARD_PATTERN = "^(6011\\d{12}|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])\\d{10}|65\\d{14})$";

    public static String getPaytermsCode(String cardNum) {
        Pattern amexPattern = Pattern.compile(AMEX_CARD_PATTERN);
        Pattern visaPattern = Pattern.compile(VISA_CARD_PATTERN);
        Pattern mastercardPattern = Pattern.compile(MASTERCARD_CARD_PATTERN);
        Pattern discoverPattern = Pattern.compile(DISCOVER_CARD_PATTERN);

        Matcher amexMatcher = amexPattern.matcher(cardNum);
        if (amexMatcher.matches()) {
            return AMEX_PAYTERM_CODE;
        }

        Matcher visaMatcher = visaPattern.matcher(cardNum);
        if (visaMatcher.matches()) {
            return VISA_PAYTERM_CODE;
        }

        Matcher mastercardMatcher = mastercardPattern.matcher(cardNum);
        if (mastercardMatcher.matches()) {
            return MASTERCARD_PAYTERM_CODE;
        }

        Matcher discoverMatcher = discoverPattern.matcher(cardNum);
        if (discoverMatcher.matches()) {
            return DISCOVER_PAYTERM_CODE;
        }

        return null;
    }
}
