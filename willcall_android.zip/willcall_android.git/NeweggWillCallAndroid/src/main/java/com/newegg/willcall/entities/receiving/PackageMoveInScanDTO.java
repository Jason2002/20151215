package com.newegg.willcall.entities.receiving;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by cf86 on 4/16/2015.
 */
public class PackageMoveInScanDTO {

    @JSONField(name = "UserID")
    private String mUserID;
    @JSONField(name = "Location")
    private String mLocation;
    @JSONField(name = "TrackingNumber")
    private String mTrackingNumber;
    @JSONField(name = "IsForcedMoveIn")
    private  Boolean mIsForcedMoveIn;


    public PackageMoveInScanDTO(String userID, String location,String trackingNumber,Boolean isForcedMoveIn) {
        this.mUserID = userID;
        this.mLocation=location;
        this.mTrackingNumber=trackingNumber;
        this.mIsForcedMoveIn=isForcedMoveIn;
    }

    public String getUserID() {
        return mUserID;
    }

    public void setUserID(String mUserID) {
        this.mUserID = mUserID;
    }

    public String getLocation() {
        return mLocation;
    }

    public void setLocation(String location) {
        this.mLocation = location;
    }

    public String getTrackingNumber() {
        return mTrackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.mTrackingNumber = trackingNumber;
    }

    public Boolean getIsForcedMoveIn() {
        return mIsForcedMoveIn;
    }

    public void setIsForcedMoveIn(Boolean isForcedMoveIn) {
        this.mIsForcedMoveIn = isForcedMoveIn;
    }
}
