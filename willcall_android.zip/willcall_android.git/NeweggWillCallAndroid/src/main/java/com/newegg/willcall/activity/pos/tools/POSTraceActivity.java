package com.newegg.willcall.activity.pos.tools;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.cache.POSTraceCache;
import com.newegg.willcall.utils.DateUtil;
import com.newegg.willcall.utils.StringUtil;

import java.util.Calendar;
import java.util.Date;

public class POSTraceActivity extends BaseActivity {

    private View btnDateContainer;
    private TextView dateView;
    private TextView memoView;
    private Button btnClear;
    private Date date;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        MenuItem menuItem = menu.findItem(R.id.action_view_log);
        if(menuItem != null) {
            menuItem.setVisible(false);
        }
        return result;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postrace);

        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setHomeButtonEnabled(false);

        btnDateContainer = findViewById(R.id.pos_trace_btn_date);
        dateView = (TextView) findViewById(R.id.pos_trace_date_view);
        memoView = (TextView) findViewById(R.id.pos_trace_txb_memo);
        btnClear = (Button) findViewById(R.id.pos_trace_btn_clear);

        btnDateContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date);
                int year = calendar.get(Calendar.YEAR);
                int month =calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(POSTraceActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        Date selectDate = DateUtil.parseDate(year,monthOfYear,dayOfMonth);
                        POSTraceActivity.this.setDate(selectDate);
                    }
                }, year, month, day);
                datePickerDialog.setTitle("Select one day to view log");
                datePickerDialog.show();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(DateUtil.isDate(date)
                   && !StringUtil.isEmpty(memoView.getText().toString())) {
                    AlertDialog dialog = new  AlertDialog.Builder(POSTraceActivity.this)
                            .setTitle(R.string.clear_log_confirm_title)
                            .setMessage(R.string.clear_log_confirm_content)
                            .setPositiveButton(R.string.Yes, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    POSTraceCache.clear(date);
                                    memoView.setText("");
                                }
                            })
                            .setNegativeButton(R.string.cancel,new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            })
                            .create();
                    dialog.show();
                }
            }
        });

        setDate(new Date());
    }

    private void setDate(Date date){
        if(!DateUtil.isDate(this.date)
            || !DateUtil.isSameDay(date,this.date)){
            this.date = date;
            if(DateUtil.isDate(date)) {
                dateView.setText(DateUtil.toDayString(date));
                memoView.setText(POSTraceCache.read(this.date));
            }
        }
    }
}
