package com.newegg.willcall.utils;

/**
 * Created by lenayan on 14-5-2.
 */
public class QuickClickUtil {
    private static final int DEFAULT_DURATION = 1000;
    private static long sLastClickTime;

    public static boolean isFastClick() {
        return isFastClick(DEFAULT_DURATION);
    }

    public static boolean isFastClick(long spaceTime) {
        long currentTime = System.currentTimeMillis();
        long tmpTime = currentTime - sLastClickTime;
        if (tmpTime > 0 && tmpTime < spaceTime) {
            return true;
        }
        sLastClickTime = currentTime;
        return false;
    }
}
