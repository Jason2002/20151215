package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class CreditCardDTO implements Serializable {
    private static final long serialVersionUID = -7060447871716949218L;
    @JSONField(name = "CardNumber")
    private String cardNumber;
    @JSONField(name = "ExpDate")
    private String expDate;
    @JSONField(name = "CVV2")
    private String cvv2;
    @JSONField(name = "MagneticTrack1")
    private String magneticTrack1;
    @JSONField(name = "MagneticTrack2")
    private String magneticTrack2;
    @JSONField(name = "PaymentAmount")
    private double paymentAmount;
    @JSONField(name = "HashCardNumber")
    private String hashCardNumber;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getCvv2() {
        return cvv2;
    }

    public void setCvv2(String cvv2) {
        this.cvv2 = cvv2;
    }

    public String getMagneticTrack1() {
        return magneticTrack1;
    }

    public void setMagneticTrack1(String magneticTrack1) {
        this.magneticTrack1 = magneticTrack1;
    }

    public String getMagneticTrack2() {
        return magneticTrack2;
    }

    public void setMagneticTrack2(String magneticTrack2) {
        this.magneticTrack2 = magneticTrack2;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(Double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getHashCardNumber() {
        return hashCardNumber;
    }

    public void setHashCardNumber(String hashCardNumber) {
        this.hashCardNumber = hashCardNumber;
    }
}
