package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class CheckOutSoInfo implements Serializable {
    private static final long serialVersionUID = -3497113150043968781L;
    @JSONField(name = "UniqueOrderNumber")
    private String uniqueOrderNumber;
    @JSONField(name = "PackageList")
    private List<CheckOutPackageInfo> packageList;

    public String getUniqueOrderNumber() {
        return uniqueOrderNumber;
    }

    public void setUniqueOrderNumber(String uniqueOrderNumber) {
        this.uniqueOrderNumber = uniqueOrderNumber;
    }

    public List<CheckOutPackageInfo> getPackageList() {
        return packageList;
    }

    public void setPackageList(List<CheckOutPackageInfo> packageList) {
        this.packageList = packageList;
    }
}
