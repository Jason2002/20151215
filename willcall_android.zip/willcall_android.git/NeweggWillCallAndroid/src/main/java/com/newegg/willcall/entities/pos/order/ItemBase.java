package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.utils.CurrencyUtils;

import org.apache.commons.math3.util.Decimal64;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/25/14.
 */
public class ItemBase implements Serializable {
    private static final long serialVersionUID = -8864585910053190824L;

    public ItemBase() {

    }

    public ItemBase(ItemBase base) {
        setItemNumber(base.getItemNumber());
        setShortDescription(base.getShortDescription());
        setLongDescription(base.getLongDescription());
        setModelNumber(base.getModelNumber());
        setManufacturerPartsNumber(base.getManufacturerPartsNumber());
        setUnitPrice(base.getUnitPrice().doubleValue());
        setEwra(base.getEwra().doubleValue());
        setCurrencyCode(base.getCurrencyCode());
        setEwraItemNumber(base.getEwraItemNumber());
        setUnitDiscount(base.getUnitDiscount());
    }


    @JSONField(name = "ItemNumber")
    private String itemNumber;
    @JSONField(name = "ShortDescription")
    private String shortDescription;
    @JSONField(name = "LongDescription")
    private String longDescription;
    @JSONField(name = "ModelNumber")
    private String modelNumber;
    @JSONField(name = "ManufacturerPartsNumber")
    private String manufacturerPartsNumber;
    @JSONField(name = "UnitPrice")
    private double unitPrice;
    @JSONField(name = "EWRA")
    private double ewra;
    @JSONField(name = "CurrencyCode")
    private String currencyCode;
    @JSONField(name = "EWRAItemNumber")
    public String ewraItemNumber;

    private double unitDiscount;

    public String getEwraItemNumber() {
        return ewraItemNumber;
    }

    public void setEwraItemNumber(String ewraItemNumber) {
        this.ewraItemNumber = ewraItemNumber;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getModelNumber() {
        return modelNumber;
    }

    public void setModelNumber(String modelNumber) {
        this.modelNumber = modelNumber;
    }

    public String getManufacturerPartsNumber() {
        return manufacturerPartsNumber;
    }

    public void setManufacturerPartsNumber(String manufacturerPartsNumber) {
        this.manufacturerPartsNumber = manufacturerPartsNumber;
    }

    public Decimal64 getUnitPrice() {
        return CurrencyUtils.getCellWith2Digit(new Decimal64(unitPrice));
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Decimal64 getEwra() {
        return CurrencyUtils.getCellWith2Digit(new Decimal64(ewra));
    }

    public void setEwra(double ewra) {
        this.ewra = ewra;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public double getUnitDiscount() {
        return unitDiscount;
    }

    public void setUnitDiscount(double unitDiscount) {
        this.unitDiscount = unitDiscount;
    }

    public Decimal64 getFormatUnitDiscount() {
        return CurrencyUtils.getCellWith2Digit(new Decimal64(getUnitDiscount()));
    }

    public Decimal64 getUnitTax(Decimal64 taxRate) {
        return CurrencyUtils.getCellWith2Digit((getUnitPrice().subtract(getUnitDiscount())).multiply(taxRate));
    }


}
