package com.newegg.willcall.entities.picking;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-10.
 */
public class ExpiredTrackingInfo {

    public static final String SCANED_YES = "Y";
    public static final String SCANED_NO = "N";

    @JSONField(name = "TrackingNumber")
    public String mTrackingNumber;
    @JSONField(name = "IsScaned")
    public String mScaned;
    @JSONField(name = "Location")
    public String mLocation;

    public String getTrackingNumber() {
        return mTrackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        mTrackingNumber = trackingNumber;
    }

    public String getScaned() {
        return mScaned;
    }

    public void setScaned(String scaned) {
        mScaned = scaned;
    }

    public boolean hasScaned() {
        return mScaned.equals(SCANED_YES);
    }

    public String getLocation() {
        return mLocation;
    }

    public void setLocation(String mLocation) {
        this.mLocation = mLocation;
    }
}
