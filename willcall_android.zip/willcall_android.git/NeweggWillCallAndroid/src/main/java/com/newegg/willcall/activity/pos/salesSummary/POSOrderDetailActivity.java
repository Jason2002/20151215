package com.newegg.willcall.activity.pos.salesSummary;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.salesSummary.POSOrderDetail;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.ToastUtil;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSOrderDetailActivity extends BaseActivity {
    public final static String EXTRA_ORDER_NUMBER = "EXTRA_ORDER_NUMBER";
    public final static String EXTRA_ORDER_INFO = "EXTRA_ORDER_INFO";


    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private OrderDetailAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pos_order_detail);
        setRecyclerView();

        if(getIntent() != null){
            POSOrderDetail orderInfo = (POSOrderDetail)getIntent().getSerializableExtra(EXTRA_ORDER_INFO);
            if(orderInfo != null){
                setTitle(getString(R.string.pos_return_title) + orderInfo.getOrderNumber());
                bindData(orderInfo);
            }else{
                int orderNumber = getIntent().getIntExtra(EXTRA_ORDER_NUMBER, 0);
                setTitle(getString(R.string.pos_return_title) + orderNumber);
                callService(orderNumber);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    private void callService(int orderNumber){
        showProgressDialog();
        String url = HttpConfig.getFormatUrl(HttpConfig.POS_SUMMARY_ORDER_DETAIL, String.valueOf(orderNumber));
        FastJsonObjectRequest<POSOrderDetail> request = new FastJsonObjectRequest<POSOrderDetail>(POSOrderDetailActivity.this, POSOrderDetail.class,
                url, new Response.Listener<POSOrderDetail>() {
            @Override
            public void onResponse(POSOrderDetail result) {
                hideProgressDialog();
                bindData(result);
            }
        }, new FastJsonObjectRequest.OnErrorListener() {

            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();
                if(info != null && info.getMessage() != null){
                    ToastUtil.show(POSOrderDetailActivity.this, info.getMessage());
                }
            }
        });

        VolleyUtil.addToRequestQueue(POSOrderDetailActivity.this, request);
    }

    private void setRecyclerView() {
        mRecyclerView = (RecyclerView)findViewById(R.id.pos_order_detail_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager =  new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
    }

    private void bindData(POSOrderDetail detail){
        mAdapter = new OrderDetailAdapter(detail);
        mRecyclerView.setAdapter(mAdapter);
    }

}
