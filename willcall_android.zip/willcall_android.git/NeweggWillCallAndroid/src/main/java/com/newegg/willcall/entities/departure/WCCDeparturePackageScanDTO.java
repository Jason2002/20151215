package com.newegg.willcall.entities.departure;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-11.
 */
public class WCCDeparturePackageScanDTO {

    @JSONField(name = "TrackingNumber")
    private String mTrackingNumber;
    @JSONField(name = "WCCNumber")
    private String mWCCNumber;
    @JSONField(name = "UserID")
    private String mUserID;

    public WCCDeparturePackageScanDTO(String trackingNumber, String WCCNumber, String userID) {
        mTrackingNumber = trackingNumber;
        mWCCNumber = WCCNumber;
        mUserID = userID;
    }

    public String getTrackingNumber() {
        return mTrackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        mTrackingNumber = trackingNumber;
    }

    public String getWCCNumber() {
        return mWCCNumber;
    }

    public void setWCCNumber(String WCCNumber) {
        mWCCNumber = WCCNumber;
    }

    public String getUserID() {
        return mUserID;
    }

    public void setUserID(String userID) {
        mUserID = userID;
    }
}
