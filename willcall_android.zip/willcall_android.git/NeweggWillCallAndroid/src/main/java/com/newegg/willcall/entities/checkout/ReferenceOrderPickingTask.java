package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.utils.ListUtil;

import java.io.Serializable;
import java.util.List;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class ReferenceOrderPickingTask implements Serializable {
    private static final long serialVersionUID = -3752085052863599823L;
    @JSONField(name = "TaskId")
    private int taskId;
    @JSONField(name = "PickupPerson")
    private String pickupPerson;
    @JSONField(name = "CreditCard")
    private String creditCard;
    @JSONField(name = "BillingContactWith")
    private String billingContactWith;
    @JSONField(name = "PayTerms")
    private String payTerms;
    @JSONField(name = "PickupType")
    private String pickupType;
    @JSONField(name = "ErrorMessage")
    private String errorMessage;
    @JSONField(name = "SOList")
    private List<CheckOutSoInfo> soList;

    private String lastRequestCode;

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getPickupPerson() {
        return pickupPerson;
    }

    public void setPickupPerson(String pickupPerson) {
        this.pickupPerson = pickupPerson;
    }

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }

    public String getBillingContactWith() {
        return billingContactWith;
    }

    public void setBillingContactWith(String billingContactWith) {
        this.billingContactWith = billingContactWith;
    }

    public String getPayTerms() {
        return payTerms;
    }

    public void setPayTerms(String payTerms) {
        this.payTerms = payTerms;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public List<CheckOutSoInfo> getSoList() {
        return soList;
    }

    public void setSoList(List<CheckOutSoInfo> soList) {
        this.soList = soList;
    }

    public String getPickupType() {
        return pickupType;
    }

    public void setPickupType(String pickupType) {
        this.pickupType = pickupType;
    }

    public String getLastRequestCode() {
        return lastRequestCode;
    }

    public void setLastRequestCode(String lastRequestCode) {
        this.lastRequestCode = lastRequestCode;
    }

    public boolean isAllScaned(){
        if(ListUtil.isNullOrEmpty(soList))
        {
            return false;
        }
        for(CheckOutSoInfo soInfo : soList){
            if(soInfo.getPackageList().size()>0){
                for (CheckOutPackageInfo packageInfo : soInfo.getPackageList()){
                    if(!packageInfo.getIsScaned().equals(CheckOutPackageInfo.IS_SCANED_YES)){
                        return false;
                    }
                }
            }
        }
        return true;
    }

}
