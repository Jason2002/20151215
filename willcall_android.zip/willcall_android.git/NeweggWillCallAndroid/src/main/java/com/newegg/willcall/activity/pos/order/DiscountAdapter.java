package com.newegg.willcall.activity.pos.order;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.pos.order.CartInfo;
import com.newegg.willcall.entities.pos.order.ItemInfo;
import com.newegg.willcall.entities.pos.order.ItemInfoResDTO;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import org.apache.commons.math3.util.Decimal64;
import org.w3c.dom.Text;

/**
 * Created by jaredluo on 12/23/14.
 */
public class DiscountAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private CartInfo info;
    private OnDiscountChangedListener listener;

    public DiscountAdapter(CartInfo info) {
        this.info = info;
    }

    public void setOnDiscountChangedListener(OnDiscountChangedListener listener) {
        this.listener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.pos_discount_cell, parent, false);
        ViewHolder holder = new ViewHolder(view);
        holder.titleTv = (TextView) view.findViewById(R.id.posdiscount_cell_item_title);
        holder.qtyTv = (TextView) view.findViewById(R.id.posdiscount_cell_qty);
        holder.discountAmountEt = (EditText) view.findViewById(R.id.posdiscount_amount);
        holder.applyBtn = (Button) view.findViewById(R.id.posdicount_apply_btn);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ViewHolder viewHolder = (ViewHolder) holder;
        final ItemInfo item = info.getItems().get(position);
        viewHolder.titleTv.setText(item.getLongDescription());
        viewHolder.qtyTv.setText(viewHolder.qtyTv.getContext().getString(R.string.qty_colon) + item.getQty());
        if (item.getUnitDiscount() > 0) {
            viewHolder.discountAmountEt.setText(CurrencyUtils.getFormatDecimal(CurrencyUtils.getCellWith2Digit(new Decimal64(item.getUnitDiscount()))));
        } else {
            viewHolder.discountAmountEt.setText(null);
        }

        viewHolder.discountAmountEt.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_ENTER) {
                    viewHolder.applyBtn.performClick();
                }
                return false;
            }
        });
        viewHolder.applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) viewHolder.applyBtn.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(viewHolder.discountAmountEt.getWindowToken(), 0);
                Editable discountEditable = viewHolder.discountAmountEt.getText();
                String discountStr = "";

                if (discountEditable == null || StringUtil.isEmpty(discountEditable.toString())) {
                    viewHolder.discountAmountEt.setText("0.00");
                    discountStr = "0.00";
                } else {
                    discountStr = discountEditable.toString();
                }

                if (CurrencyUtils.isNumber(discountStr)) {
                    Double discount = Double.parseDouble(discountStr);

                    if (discount >= 0) {

                        ItemInfo _item = info.getItems().get(position);

                        if (_item.getUnitPrice().doubleValue() >= discount) {
                            viewHolder.discountAmountEt.setError(null);

                            info.setDiscountToRaws(discount, _item.getItemNumber());

                            if (listener != null) {
                                listener.onDiscountChanged();
                            }

                            ToastUtil.show(viewHolder.applyBtn.getContext(), viewHolder.applyBtn.getContext().getString(R.string.valid_discount_hint));

                        } else {
                            viewHolder.discountAmountEt.setError(viewHolder.discountAmountEt.getContext().getString(R.string.discount_max));
                            ToastUtil.show(viewHolder.applyBtn.getContext(), viewHolder.applyBtn.getContext().getString(R.string.discount_max));
                        }

                        return;
                    }
                }

                viewHolder.discountAmountEt.setError(viewHolder.discountAmountEt.getContext().getString(R.string.invalid_discount_hint));
                ToastUtil.show(viewHolder.applyBtn.getContext(), viewHolder.applyBtn.getContext().getString(R.string.invalid_discount_hint));

            }
        });

    }

    @Override
    public int getItemCount() {
        if (info != null && info.getItems() != null && info.getItems().size() > 0) {
            return info.getItems().size();
        }
        return 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView titleTv;
        public TextView qtyTv;
        public EditText discountAmountEt;
        public Button applyBtn;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public interface OnDiscountChangedListener {
        void onDiscountChanged();
    }
}
