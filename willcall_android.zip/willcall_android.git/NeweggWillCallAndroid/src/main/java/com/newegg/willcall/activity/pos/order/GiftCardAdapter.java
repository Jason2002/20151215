package com.newegg.willcall.activity.pos.order;

import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.pos.order.GiftCardRes;
import com.newegg.willcall.utils.CurrencyUtils;

import org.apache.commons.math3.util.Decimal64;

import java.util.List;

/**
 * Created by jaredluo on 12/19/14.
 */

public class GiftCardAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private OnDeleteListener listener;

    private List<GiftCardRes> cards;

    public GiftCardAdapter(List<GiftCardRes> cards){
        this.cards = cards;
    }

    public void setOnDeleteListener(OnDeleteListener listener){
        this.listener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());


        View cellView = inflater.inflate(R.layout.pos_giftcard_cell, parent, false);
        ViewHolder holder = new ViewHolder(cellView);
        holder.cardNumTv = (TextView) cellView.findViewById(R.id.giftcard_num);
        holder.amountTv = (TextView) cellView.findViewById(R.id.giftcard_amount);
        holder.removeBtn = (ImageButton) cellView.findViewById(R.id.giftcard_remove_btn);

        return holder;

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.cardNumTv.setText(cards.get(position).getCardNum());
        viewHolder.amountTv.setText("-"+CurrencyUtils.getCurrencyFormat(new Decimal64(cards.get(position).getRedeemAmount())));
        viewHolder.removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cards.remove(position);
                notifyDataSetChanged();
                if (cards.size() == 0 && listener != null){
                    listener.onEmpty();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (cards != null && cards.size() > 0){
            return cards.size();
        }
        return 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView cardNumTv;
        public TextView amountTv;
        public ImageButton removeBtn;


        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public interface OnDeleteListener{
        void onEmpty();
    }


}
