package com.newegg.willcall.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;

import com.newegg.willcall.MainActivity;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.main.WarehouseActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.cache.NeweggFileCache;
import com.newegg.willcall.entities.Warehouse;
import com.newegg.willcall.entities.WarehouseCache;
import com.newegg.willcall.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by JaredLuo on 14-4-4.
 */
public class WarehouseAdapter extends BaseAdapter {

    private final List<Warehouse> warehouses;
    private final Warehouse selectedWarehouse;
    private final Context context;
    private final MainActivity.APP_TYPE type;

    public WarehouseAdapter(Context context, List<Warehouse> warehouses, Warehouse selectedWarehouse, MainActivity.APP_TYPE type) {
        this.context = context;
        this.warehouses = warehouses;
        this.selectedWarehouse = selectedWarehouse;
        this.type = type;
    }

    @Override
    public int getCount() {
        return warehouses.size();
    }

    @Override
    public Warehouse getItem(int position) {
        return warehouses.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null || convertView.getTag() == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.warehourse_cell, parent, false);

            holder = new ViewHolder();
            holder.btn = (Button) convertView.findViewById(R.id.warehouse_btn);
            holder.selectedTag = convertView.findViewById(R.id.warehouse_selected_tag);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final Warehouse warehouse = getItem(position);
        if (warehouse != null && !StringUtil.isEmpty(warehouse.getWarehouseName())) {
            if (selectedWarehouse != null && !StringUtil.isEmpty(warehouse.getCode()) && warehouse.getCode().equals(selectedWarehouse.getCode())) {
                holder.selectedTag.setVisibility(View.VISIBLE);
            } else {
                holder.selectedTag.setVisibility(View.GONE);
            }
            holder.btn.setText(warehouse.getWarehouseName());
            holder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    WillCallApp.setWarehouse(warehouse);
                    WillCallApp.setAppType(type);

                    WarehouseCache cache = new WarehouseCache();
                    cache.setUserID(WillCallApp.getUser().getUserID());
                    cache.setWarehouse(warehouse);

                    List<WarehouseCache> caches = NeweggFileCache.getInstance().get(WarehouseActivity.USER_WAREHOUSE_LIST_CACHE);
                    if (caches == null) {
                        caches = new ArrayList<WarehouseCache>();
                    } else {
                        for (int i = 0; i < caches.size(); i++) {
                            WarehouseCache oldCache = caches.get(i);
                            if (oldCache != null && oldCache.getUserID() == cache.getUserID()) {
                                caches.remove(i);
                                i--;
                            }
                        }
                    }


                    caches.add(cache);
                    NeweggFileCache.getInstance().put(WarehouseActivity.USER_WAREHOUSE_LIST_CACHE, caches);

                    Intent intent = new Intent(context, MainActivity.class);
                    intent.putExtra(MainActivity.PARAM_APP_TYPE, WillCallApp.getAppType());
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(intent);

                }
            });
        }
        return convertView;
    }

    private static class ViewHolder {
        public Button btn;
        public View selectedTag;
    }
}
