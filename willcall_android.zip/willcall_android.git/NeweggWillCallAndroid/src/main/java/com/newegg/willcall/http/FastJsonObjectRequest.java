package com.newegg.willcall.http;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.utils.LogUtil;

import java.io.UnsupportedEncodingException;

/**
 * Created by JaredLuo on 4/2/14.
 */
public class FastJsonObjectRequest<T> extends BaseRequest<T> {

    private Response.Listener<T> listener;
    private Class<T> clazz;

    /**
     * Method general
     *
     * @param method
     * @param url
     * @param request
     * @param responseListener
     * @param errlistener
     */

    public FastJsonObjectRequest(Context context, Class<T> clazz, int method, String url, Object request, Response.Listener<T> responseListener, Response.ErrorListener errlistener) {
        super(method, url, errlistener, context, request);
        LogUtil.i("PostUrl:" + url);
        this.listener = responseListener;
        this.clazz = clazz;
    }

    public FastJsonObjectRequest(Context context, Class<T> clazz, int method, String url, Object request, Response.Listener<T> responseListener, OnErrorListener errlistener) {
        super(method, url, errlistener, context, request);
        LogUtil.i("PostUrl:" + url);
        this.listener = responseListener;
        this.clazz = clazz;
    }

    /**
     * Method Get
     *
     * @param url
     * @param responseListener
     * @param errlistener
     */

    public FastJsonObjectRequest(Context context, Class<T> clazz, String url, Response.Listener<T> responseListener, Response.ErrorListener errlistener) {
        super(Method.GET, url, errlistener, context);
        LogUtil.i("GetUrl:" + url);
        this.listener = responseListener;
        this.clazz = clazz;
    }

    public FastJsonObjectRequest(Context context, Class<T> clazz, String url, Response.Listener<T> responseListener, OnErrorListener errlistener) {
        super(Method.GET, url, errlistener, context);
        LogUtil.i("GetUrl:" + url);
        this.listener = responseListener;
        this.clazz = clazz;
    }

    /**
     * Method Post
     *
     * @param url
     * @param request
     * @param responseListener
     * @param errlistener
     */

    public FastJsonObjectRequest(Context context, Class<T> clazz, String url, Object request, Response.Listener<T> responseListener, Response.ErrorListener errlistener) {
        super(Method.POST, url, errlistener, context, request);
        LogUtil.i("PostUrl:" + url);
        this.listener = responseListener;
        this.clazz = clazz;
    }

    public FastJsonObjectRequest(Context context
            , Class<T> clazz
            , String url
            , Object request
            , Response.Listener<T> responseListener, OnErrorListener errlistener) {
        this(context,clazz,Method.POST,url,request,responseListener,errlistener);
    }

    public FastJsonObjectRequest(Context context
            , Class<T> clazz
            , String url
            , int method
            , Object request
            , Response.Listener<T> responseListener
            , OnErrorListener errlistener) {
        super(method, url, errlistener, context, request);
        LogUtil.i("PostUrl:" + url);
        this.listener = responseListener;
        this.clazz = clazz;
    }

    @Override
    protected Response<T> parseNetworkResponse(NetworkResponse networkResponse) {
        try {
            String jsonString = new String(networkResponse.data, CHARSET);

            T parsed = null;
            if (!jsonString.equals("")) {
                parsed = JSON.parseObject(jsonString, clazz);
                LogUtil.i("parsed:" +jsonString);
            }
            return Response.success(parsed,
                    HttpHeaderParser.parseCacheHeaders(networkResponse));

        } catch (UnsupportedEncodingException e) {
            LogUtil.i("UnsupportedEncodingException" + e.getMessage());
            e.printStackTrace();
            ErrorResponseInfo err = new ErrorResponseInfo();
            err.setStatusCode("-1");
            err.setMessage(e.getMessage());
            onError(err);
            return Response.error(new ParseError(e));
        } catch (Exception ex) {
            LogUtil.i("Exception" + ex.getMessage());
            ex.printStackTrace();
            ErrorResponseInfo err = new ErrorResponseInfo();
            err.setStatusCode("-1");
            err.setMessage(ex.getMessage());
            onError(err);
            return Response.error(new ParseError(ex));
        }
    }

    @Override
    protected void deliverResponse(T response) {
        listener.onResponse(response);
    }
}
