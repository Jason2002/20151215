package com.newegg.willcall.activity.willcall.departure;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LayoutAnimationController;
import android.view.animation.TranslateAnimation;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.departure.DepartureDestination;
import com.newegg.willcall.entities.departure.DeparturePackage;
import com.newegg.willcall.entities.departure.SetPackageAsExpiredDTO;
import com.newegg.willcall.entities.departure.WCCDeparturePackageScanDTO;
import com.newegg.willcall.http.FastJsonArrayRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.scan.CaptureActivity;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.AnimatorListenerAdapter;
import com.nineoldandroids.animation.ObjectAnimator;

import java.util.List;

/**
 * Created by lenayan on 14-4-11.
 */
public class PackageDepartureActivity extends BaseActivity {

    public static final int REQUEST_CODE = 0x14;

    private View mContentView = null;
    private View mLoadingView = null;
    private View mErrorView = null;

    private ExpandableListView mWareHouseListView = null;
    private View mLastHistoryView = null;
    private TextView mLastTrackingNumberTextView = null;
    private TextView mLastWareHouseTextView = null;
    private EditText mInputEditText = null;
    private TextView mPackageListCount = null;
    private Button mDepartBtn = null;

    private Runnable mShowHistoryRunnable = null;

    private DeparturePackageListAdapter mListAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_departure);

        if (!WillCallApp.getWarehouse().hasDeparturePrivilege()) {
            ToastUtil.show(this, getString(R.string.privilege_error));
            finish();
            return;
        }

        initView();
        getDeparturePackageList();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null && !TextUtils.isEmpty(data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY))) {
            String trackingNumnber = data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY);
            mInputEditText.setText("");
            mInputEditText.append(trackingNumnber);
            scanDeparturePackage(trackingNumnber);
        }
    }

    private void initView() {
        mContentView = findViewById(R.id.departure_content);
        mLoadingView = findViewById(R.id.loading_layout);
        mErrorView = findViewById(R.id.error_layout);
        mWareHouseListView = (ExpandableListView) findViewById(R.id.package_list);
        mLastHistoryView = findViewById(R.id.last_history_layout);
        mLastTrackingNumberTextView = (TextView) findViewById(R.id.last_scaded);
        mLastWareHouseTextView = (TextView) findViewById(R.id.history_destination);
        mInputEditText = (EditText) findViewById(R.id.package_list_input_edit_text);
        mPackageListCount = (TextView) findViewById(R.id.package_list_count);
        mDepartBtn = (Button) findViewById(R.id.departure_btn);
        mInputEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN && !TextUtils.isEmpty(mInputEditText.getText())) {
                    scanDeparturePackage(formatInputTrackingNumber(mInputEditText.getText().toString()));
                    return true;
                }
                return false;
            }
        });

        AnimationSet set = new AnimationSet(true);

        Animation animation = new AlphaAnimation(0.0f, 1.0f);
        animation.setDuration(50);
        set.addAnimation(animation);

        animation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, -1.0f, Animation.RELATIVE_TO_SELF, 0.0f
        );
        animation.setDuration(100);
        set.addAnimation(animation);

        LayoutAnimationController controller = new LayoutAnimationController(set, 0.5f);
        mWareHouseListView.setLayoutAnimation(controller);
    }

    private void showHistoryView(String trackNumber, List<DepartureDestination> departureDestinations) {
        int count = departureDestinations.size();
        String destination = "";
        destinationForeach:
        for (int i = 0; i < count; i++) {
            DepartureDestination departureDestination = departureDestinations.get(i);
            int trackingNumberount = departureDestination.getTrackingNumberList().size();
            for (int j = 0; j < trackingNumberount; j++) {
                String trackingNumber = departureDestination.getTrackingNumberList().get(j);
                if (TextUtils.isEmpty(trackingNumber))
                    continue;
                if (departureDestination.getTrackingNumberList().get(j).toLowerCase().equals(trackingNumber.toLowerCase())) {
                    destination = departureDestination.getDestination();
                    break destinationForeach;
                }
            }
        }
        mLastHistoryView.setVisibility(View.VISIBLE);
        mLastTrackingNumberTextView.setText(trackNumber);
        mLastWareHouseTextView.setText(destination);
        if (mShowHistoryRunnable != null)
            mLastHistoryView.removeCallbacks(mShowHistoryRunnable);
        mShowHistoryRunnable = new Runnable() {
            @Override
            public void run() {
                mLastHistoryView.setVisibility(View.GONE);
            }
        };
        mLastHistoryView.postDelayed(mShowHistoryRunnable, 10000);
    }

    public void onScanButtonClicked(View view) {
        Intent intent = new Intent(this, CaptureActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    public void onDepartureButtonClicked(View view) {
        packagesDeparture();
    }

    public void onRetryClick(View view) {
        mErrorView.setVisibility(View.GONE);
        getDeparturePackageList();
    }


    private void getDeparturePackageList() {
        mLoadingView.setVisibility(View.VISIBLE);
        FastJsonArrayRequest<List<DepartureDestination>, DepartureDestination> request = new FastJsonArrayRequest<List<DepartureDestination>, DepartureDestination>(this, DepartureDestination.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_DEPARTURE_GET_LIST, WillCallApp.getWarehouse().getCode(), String.valueOf(WillCallApp.getUser().getUserID())),
                new Response.Listener<List<DepartureDestination>>() {
                    @Override
                    public void onResponse(List<DepartureDestination> result) {
                        mLoadingView.setVisibility(View.GONE);
                        mContentView.setVisibility(View.VISIBLE);
                        if (result != null && result.size() > 0) {
                            mListAdapter = new DeparturePackageListAdapter(PackageDepartureActivity.this, result);
                            mWareHouseListView.setAdapter(mListAdapter);
                            controlCountViewStatus();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                mLoadingView.setVisibility(View.GONE);
                mErrorView.setVisibility(View.VISIBLE);
            }
        }
        );
        VolleyUtil.addToRequestQueue(this, request);
    }

    private void scanDeparturePackage(final String trackingNumber) {
        final String finalTrackingNumber = trackingNumber == null ? null : trackingNumber.trim();
        if (StringUtil.isTrackingNUmber(finalTrackingNumber)) {
            showProgressDialog();
            WCCDeparturePackageScanDTO requestInfo = new WCCDeparturePackageScanDTO(finalTrackingNumber, WillCallApp.getWarehouse().getCode(), String.valueOf(WillCallApp.getUser().getUserID()));
            FastJsonArrayRequest<List<DepartureDestination>, DepartureDestination> request = new FastJsonArrayRequest<List<DepartureDestination>, DepartureDestination>(this, DepartureDestination.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_DEPARTURE_SCAN_TRACKING, finalTrackingNumber), requestInfo, new Response.Listener<List<DepartureDestination>>() {
                @Override
                public void onResponse(List<DepartureDestination> result) {
                    hideProgressDialog();
                    if (result != null && result.size() > 0) {
                        mContentView.setVisibility(View.VISIBLE);
                        showHistoryView(finalTrackingNumber, result);
                        if (mListAdapter != null) {
                            mListAdapter.setDepartureDestinations(result);
                        } else {
                            mListAdapter = new DeparturePackageListAdapter(PackageDepartureActivity.this, result);
                            mWareHouseListView.setAdapter(mListAdapter);
                            controlCountViewStatus();
                        }
                    } else {
                        mContentView.setVisibility(View.GONE);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    hideProgressDialog();
                }
            }
            );
            VolleyUtil.addToRequestQueue(this, request);
        } else {
            ToastUtil.show(this, String.format(getString(R.string.trackingnumber_input_error), finalTrackingNumber), ToastUtil.TOAST_DURATION_LONG);
        }
    }

    private void packagesDeparture() {
        showProgressDialog();
        SetPackageAsExpiredDTO requestInfo = new SetPackageAsExpiredDTO(WillCallApp.getWarehouse().getCode(), String.valueOf(WillCallApp.getUser().getUserID()));

        FastJsonObjectRequest<Void> request = new FastJsonObjectRequest<Void>(this, Void.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_DEPARTURE_PACKAGE_DEPARTURE, requestInfo.getUserID()), requestInfo, new Response.Listener<Void>() {
            @Override
            public void onResponse(Void result) {
                hideProgressDialog();
                int count = mListAdapter.getTotalChildCount();
                ToastUtil.show(PackageDepartureActivity.this, getResources().getQuantityString(R.plurals.departure_result_toast, count, count));
                mListAdapter.removeAllDestinations();
                mInputEditText.setText("");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                hideProgressDialog();
            }
        });
        VolleyUtil.addToRequestQueue(this, request);
    }

    private void deleteUnDeparturedPackage() {
        showProgressDialog();
        FastJsonObjectRequest<Void> request = new FastJsonObjectRequest<Void>(this, Void.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_DEPARTURE_DELETE_UNDEPARTURE_PACKAGES, String.valueOf(WillCallApp.getUser().getUserID())), new Response.Listener<Void>() {
            @Override
            public void onResponse(Void result) {
                hideProgressDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                hideProgressDialog();
            }
        });
        VolleyUtil.addToRequestQueue(this, request);
    }

    private String formatInputTrackingNumber(String inputValue) {
        String prefix = getString(R.string.tracking_number_prefix);
        String lowerCasePreFix = prefix.toLowerCase();
        if (inputValue.startsWith(prefix))
            return inputValue;
        if (inputValue.startsWith(lowerCasePreFix))
            return inputValue.replace(lowerCasePreFix, prefix);
        if (inputValue.toLowerCase().contains(lowerCasePreFix))
            return inputValue.toLowerCase().replace(lowerCasePreFix, prefix);
        if (StringUtil.isNumeric(inputValue))
            return prefix + inputValue;
        return inputValue;
    }

    private void controlCountViewStatus() {
        boolean hasPackages = mListAdapter.getTotalChildCount() > 0;
        mPackageListCount.setVisibility(hasPackages ? View.VISIBLE : View.GONE);
        mPackageListCount.setText(String.valueOf(mListAdapter.getTotalChildCount()));
        mWareHouseListView.setVisibility(hasPackages ? View.VISIBLE : View.GONE);
        mDepartBtn.setEnabled(hasPackages);
    }

    private class DeparturePackageListAdapter extends BaseExpandableListAdapter {

        private List<DepartureDestination> mDepartureDestinations = null;
        private LayoutInflater mLayoutInflater = null;
        private int mLastExpandGroupPosition = -1;

        private DeparturePackageListAdapter(Context context, List<DepartureDestination> setPackageAsExpiredDTOs) {
            mLayoutInflater = LayoutInflater.from(context);
            mDepartureDestinations = setPackageAsExpiredDTOs;
        }

        public void setDepartureDestinations(List<DepartureDestination> departureDestinations) {
            mDepartureDestinations = departureDestinations;
            notifyDataSetChanged();
        }

        public void removeAllDestinations() {
            mDepartureDestinations.clear();
            notifyDataSetChanged();
        }

        private void addTrackingNumber(DeparturePackage departurePackage) {
            int count = getGroupCount();
            for (int i = 0; i < count; i++) {
                if (getGroup(i).getDestination().equals(departurePackage.getDestination())) {
                    getGroup(i).getTrackingNumberList().add(departurePackage.getTrackingNumber());
                    notifyDataSetChanged();
                    return;
                }
            }
            DepartureDestination departureDestination = new DepartureDestination();
            departureDestination.setDestination(departurePackage.getDestination());
            departureDestination.getTrackingNumberList().add(departurePackage.getTrackingNumber());
            mDepartureDestinations.add(departureDestination);
            notifyDataSetChanged();
        }

        @Override
        public void notifyDataSetChanged() {
            super.notifyDataSetChanged();
            controlCountViewStatus();
        }

        @Override

        public void registerDataSetObserver(DataSetObserver observer) {
            super.registerDataSetObserver(observer);
        }

        @Override
        public void unregisterDataSetObserver(DataSetObserver observer) {
            super.unregisterDataSetObserver(observer);
        }

        @Override
        public int getGroupCount() {
            return mDepartureDestinations.size();
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return mDepartureDestinations.get(groupPosition).getTrackingNumberList().size();
        }

        public int getTotalChildCount() {
            int childCount = 0;
            for (int i = 0; i < getGroupCount(); i++) {
                childCount += getChildrenCount(i);
            }
            return childCount;
        }

        @Override
        public DepartureDestination getGroup(int groupPosition) {
            return mDepartureDestinations.get(groupPosition);
        }

        @Override
        public String getChild(int groupPosition, int childPosition) {
            return mDepartureDestinations.get(groupPosition).getTrackingNumberList().get(childPosition);
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }

        @Override
        public View getGroupView(final int groupPosition, final boolean isExpanded, View convertView, ViewGroup parent) {
            GroupViewHolder viewHolder;
            if (convertView == null || convertView.getTag() == null) {
                viewHolder = new GroupViewHolder();
                convertView = mLayoutInflater.inflate(R.layout.departure_package_list_group_view, parent, false);
                viewHolder.wareHouseTextView = (TextView) convertView.findViewById(R.id.warehouse);
                viewHolder.qtyTextView = (TextView) convertView.findViewById(R.id.quantity);
                viewHolder.packageListView = (TextView) convertView.findViewById(R.id.package_list);
                viewHolder.topDividerView = convertView.findViewById(R.id.top_divider);
                viewHolder.bottomDividerView = convertView.findViewById(R.id.bottom_divider);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (GroupViewHolder) convertView.getTag();
            }
            DepartureDestination departureDestination = getGroup(groupPosition);
            viewHolder.wareHouseTextView.setText(departureDestination.getDestination());
            viewHolder.qtyTextView.setText(String.valueOf(departureDestination.getQuantity()));
            viewHolder.packageListView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean expanded = isExpanded ? mWareHouseListView.collapseGroup(groupPosition) : mWareHouseListView.expandGroup(groupPosition);
                }
            });
            viewHolder.packageListView.setCompoundDrawablesWithIntrinsicBounds(0, 0, isExpanded ? R.drawable.arrow_up : R.drawable.arrow_down, 0);
            viewHolder.topDividerView.setVisibility(groupPosition == 0 ? View.GONE : View.VISIBLE);
            viewHolder.bottomDividerView.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
            return convertView;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
            ChildViewHolder childViewHolder;
            if (convertView == null || convertView.getTag() == null) {
                childViewHolder = new ChildViewHolder();
                convertView = mLayoutInflater.inflate(R.layout.package_list_cell, parent, false);
                childViewHolder.trackingNumberTextView = (TextView) convertView;
                convertView.setTag(childViewHolder);
            } else {
                childViewHolder = (ChildViewHolder) convertView.getTag();
            }
            childViewHolder.trackingNumberTextView.setText((childPosition + 1) + ". " + getChild(groupPosition, childPosition));
            int padding = (int) mContentView.getResources().getDimension(R.dimen.padding_l);
            childViewHolder.trackingNumberTextView.setPadding(padding, 0, padding, 0);
            convertView.setBackgroundColor(getResources().getColor(R.color.white));
//            convertView.setVisibility(View.GONE);
//            childShowingAnimation(convertView);
            return convertView;
        }

        private void childShowingAnimation(final View childView) {
            childView.post(new Runnable() {
                @Override
                public void run() {
                    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(childView, "translationY", 500, 0).setDuration(500);
                    objectAnimator.setStartDelay(100);
                    objectAnimator.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationStart(Animator animation) {
                            super.onAnimationStart(animation);
                            childView.setVisibility(View.VISIBLE);
                        }
                    });
                    objectAnimator.start();
                }
            });
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return false;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public void onGroupExpanded(int groupPosition) {
            if (mLastExpandGroupPosition != -1) {
                mWareHouseListView.collapseGroup(mLastExpandGroupPosition);
            }
            mWareHouseListView.setSelectedChild(groupPosition, 0, false);
            mLastExpandGroupPosition = groupPosition;
        }

        @Override
        public void onGroupCollapsed(final int groupPosition) {
            if (groupPosition == mLastExpandGroupPosition) {
                mLastExpandGroupPosition = -1;
            }
        }

        @Override
        public long getCombinedChildId(long groupId, long childId) {
            return 0;
        }

        @Override
        public long getCombinedGroupId(long groupId) {
            return 0;
        }
    }

    private static class GroupViewHolder {
        TextView wareHouseTextView;
        TextView qtyTextView;
        TextView packageListView;
        View topDividerView;
        View bottomDividerView;
    }

    private static class ChildViewHolder {
        TextView trackingNumberTextView;
    }

    @Override
    public void onBarcodeScanned(final String barcode) {
        super.onBarcodeScanned(barcode);

        if (StringUtil.isEmpty(barcode)) {
            return;
        }

        if (mInputEditText == null) {
            return;
        }

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mInputEditText.setText("");
                mInputEditText.append(barcode);
                scanDeparturePackage(barcode);
            }
        });

    }
}
