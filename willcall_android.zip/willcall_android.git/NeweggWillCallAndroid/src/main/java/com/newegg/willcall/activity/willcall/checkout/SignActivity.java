package com.newegg.willcall.activity.willcall.checkout;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.view.ActionMode;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.checkout.ConfirmCheckoutDTO;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.newegg.willcall.widget.SignView;

import java.io.ByteArrayOutputStream;

/**
 * Created by JaredLuo on 14-4-11.
 */
public class SignActivity extends BaseActivity {
    public static final String PARAMS_CHECKOUT_TASK_INFO = "PARAMS_CHECKOUT_TASK_INFO";
    public static final String PARAMS_CHECKOUT_PAGE_ORIENTATION = "PARAMS_CHECKOUT_PAGE_ORIENTATION";

    private static int MENU_ITEM_CLEAR_ID = 0x10;

    private boolean mIsVisible;

    private ReferenceOrderPickingTask mTaskInfo;
    private SignView mSignView;
    private ActionMode.Callback mActionCallBack;
    private int mOrientation;
    private AlertDialog confirmDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setIsLandscape(true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        mSignView = (SignView) findViewById(R.id.sign_view);

        if (getIntent() != null) {
            mTaskInfo = (ReferenceOrderPickingTask) getIntent().getSerializableExtra(PARAMS_CHECKOUT_TASK_INFO);
            mOrientation = getIntent().getIntExtra(PARAMS_CHECKOUT_PAGE_ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        mActionCallBack = createActionMode();
        startSupportActionMode(mActionCallBack);
    }

    private ActionMode.Callback createActionMode() {
        return new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                View customTitle = LayoutInflater.from(SignActivity.this).inflate(R.layout.checkout_sign_pickup_by, null);
                TextView customer = (TextView) customTitle.findViewById(R.id.checkout_sign_customer);
                SpannableStringBuilder ssb = new SpannableStringBuilder();

                int firstLength = getString(R.string.checkout_customer_colon).length();
                int secondLength = mTaskInfo.getPickupPerson().length();

                ssb.append(getString(R.string.checkout_customer_colon));
                ssb.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.secondary_text_color)), 0, firstLength, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
                ssb.append(mTaskInfo.getPickupPerson());
                ssb.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), firstLength, firstLength + secondLength, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
                customer.setText(ssb);
                mode.setCustomView(customTitle);

                menu.add(0, MENU_ITEM_CLEAR_ID, 1, "clear");

                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                if (item.getItemId() == MENU_ITEM_CLEAR_ID) {
                    mSignView.clear();
                }
                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                if (mIsVisible) {
                    if (!mSignView.isEmpty()) {
                        final Bitmap bitmap = mSignView.getBitmap();

                        View view = getLayoutInflater().inflate(R.layout.signature_confirm_dialog, null);
                        ImageView signatureImageView = (ImageView) view.findViewById(R.id.signature_dialog_image_view);
                        signatureImageView.setImageBitmap(bitmap);

                        confirmDialog = new AlertDialog.Builder(SignActivity.this).setTitle(R.string.checkout_signature_confirm_title).
                                setPositiveButton(R.string.checkout_signature_confirm_pos_btn, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        confirmOrder(mTaskInfo, bitmap);
                                    }
                                }).setNegativeButton(R.string.checkout_signature_confirm_neg_btn, null).setInverseBackgroundForced(true).
                                setView(view).create();


                        confirmDialog.show();

                        ViewGroup parent = (ViewGroup) view.getParent();
                        parent.setPadding(0, 0, 0, 0);

                    } else {
                        showMsg(getString(R.string.checkout_empty_sign));
                    }
                }

                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        startSupportActionMode(mActionCallBack);
                    }
                });
            }
        };
    }

    private void confirmOrder(ReferenceOrderPickingTask taskInfo, Bitmap bitmap) {

        final ProgressDialog progressDialog = getLoadingDialog();
        progressDialog.show();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] bytes = baos.toByteArray();
        String base64 = Base64.encodeToString(bytes, Base64.DEFAULT);

        ConfirmCheckoutDTO checkoutRequest = new ConfirmCheckoutDTO();
        checkoutRequest.setUserID(WillCallApp.getUser().getUserID() + "");
        checkoutRequest.setTaskID(taskInfo.getTaskId());
        checkoutRequest.setWccNumber(WillCallApp.getWarehouse().getCode());
        checkoutRequest.setUploadFileBase64String(base64);

        FastJsonObjectRequest<Object> request = new FastJsonObjectRequest<Object>(this, Object.class, HttpConfig.getFormatUrl(HttpConfig.CHECKOUT_CONFIRM_CHECKOUT, String.valueOf(taskInfo.getTaskId())), checkoutRequest, new Response.Listener<Object>() {
            @Override
            public void onResponse(Object result) {
                if (!mIsVisible) {
                    return;
                }
                if (confirmDialog != null) {
                    confirmDialog.dismiss();
                }
                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
                showMsg(getString(R.string.checkout_successfully));
                done(RESULT_OK);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (!mIsVisible) {
                    return;
                }
                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
//                showMsg(volleyError.getMessage());
            }
        });

        VolleyUtil.addToRequestQueue(this, request);
    }

    @Override
    protected void onResume() {
        mIsVisible = true;
        super.onResume();
    }

    @Override
    protected void onPause() {
        mIsVisible = false;
        super.onPause();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            done(RESULT_CANCELED);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void done(int resultCode) {
        Intent intent = new Intent();
        intent.putExtra(PARAMS_CHECKOUT_PAGE_ORIENTATION, mOrientation);
        setResult(resultCode, intent);
        finish();
    }

    private ProgressDialog getLoadingDialog() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(R.style.ProgressBarWillCallIndeterminate_White);
        progressDialog.setMessage("Loading");
        return progressDialog;
    }

    private void showMsg(String msg) {
        ToastUtil.show(this, msg, ToastUtil.TOAST_DURATION_LONG);
    }

}
