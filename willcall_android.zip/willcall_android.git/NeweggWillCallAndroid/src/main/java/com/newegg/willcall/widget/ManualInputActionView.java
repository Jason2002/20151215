package com.newegg.willcall.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.CollapsibleActionView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newegg.willcall.R;

/**
 * Created by flyerabc on 15/1/7.
 */
public class ManualInputActionView extends LinearLayout implements CollapsibleActionView {

    private EditText mInputEditText;
    private Button mApplyButton;
    private Context mContext;
    private OnManualInputListener mListener;

    public interface OnManualInputListener {
        void onApply(String input);
    }

    public void setOnManualInputListener(OnManualInputListener listener) {
        mListener = listener;
    }

    public ManualInputActionView(Context context) {
        this(context, null);
    }

    public ManualInputActionView(Context context, AttributeSet attrs) {
        super(context, attrs);

        mContext = context;

        this.setLayoutParams(new ViewGroup.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.pos_manual_input, this, true);

        mInputEditText = (EditText) findViewById(R.id.manual_input_text);
        mApplyButton = (Button) findViewById(R.id.manual_apply_button);
        mInputEditText.setHint(R.string.pos_return_serial_number_hint);
        mApplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = mInputEditText.getText().toString().trim();
                if (mListener != null) {
                    mListener.onApply(input);
                }
            }
        });

        mInputEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_DONE
                        || keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER && keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                    String input = mInputEditText.getText().toString().trim();
                    if (mListener != null) {
                        mListener.onApply(input);
                    }

                    return true;
                }

                return false;
            }
        });
    }

    public void setHint(String hint) {
        mInputEditText.setHint(hint);
    }

    public void setInputType(int type) {
        mInputEditText.setInputType(type);
    }

    @Override
    public void onActionViewExpanded() {
        this.requestFocus();
        mInputEditText.setText("");
        mInputEditText.postDelayed(new Runnable() {
            @Override
            public void run() {
                mInputEditText.requestFocus();
                InputMethodManager keyboard = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                keyboard.showSoftInput(mInputEditText, 0);
            }
        }, 200);
    }

    @Override
    public void onActionViewCollapsed() {
        this.clearFocus();
        InputMethodManager keyboard = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        keyboard.hideSoftInputFromWindow(mInputEditText.getWindowToken(), 0);
    }
}
