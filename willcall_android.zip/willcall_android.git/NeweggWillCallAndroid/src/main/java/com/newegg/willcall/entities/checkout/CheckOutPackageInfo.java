package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class CheckOutPackageInfo implements Serializable {
    private static final long serialVersionUID = -935214274350051622L;

    public static final String IS_SCANED_YES = "Y";
    public static final String IS_SCANED_NO = "N";

    @JSONField(name = "UniqueOrderNumber")
    private String uniqueOrderNumber;
    @JSONField(name = "TrackingNumber")
    private String trackingNumber;
    @JSONField(name = "IsScaned")
    private String isScaned;
    @JSONField(name = "ItemList")
    private List<CheckOutItemInfo> itemList;
    @JSONField(name = "Location")
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getUniqueOrderNumber() {
        return uniqueOrderNumber;
    }

    public void setUniqueOrderNumber(String uniqueOrderNumber) {
        this.uniqueOrderNumber = uniqueOrderNumber;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public String getIsScaned() {
        return isScaned;
    }

    public void setIsScaned(String isScaned) {
        this.isScaned = isScaned;
    }

    public List<CheckOutItemInfo> getItemList() {
        return itemList;
    }

    public void setItemList(List<CheckOutItemInfo> itemList) {
        this.itemList = itemList;
    }

}
