package com.newegg.willcall.entities.pos.orderReturn;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSReturnTransactionDTO implements Serializable {
    @JSONField(name = "ItemNumber")
    private String itemNumber;

    @JSONField(name = "SerialNumber")
    private String serialNumber;

    @JSONField(name = "DiscountAmount")
    private BigDecimal discountAmount;

    @JSONField(name = "UnitPrice")
    private BigDecimal unitPrice;

    @JSONField(name = "TaxAmount")
    private BigDecimal taxAmount;

    @JSONField(name = "EWRA")
    private BigDecimal ewra;


    @JSONField(name = "ItemDescription")
    private String itemDescption;

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public BigDecimal getDiscountAmount() {
        return this.discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }

    public BigDecimal getEwra() {
        return ewra;
    }

    public void setEwra(BigDecimal ewra) {
        this.ewra = ewra;
    }

    public String getItemDescption() {
        return itemDescption;
    }

    public void setItemDescption(String itemDescption) {
        this.itemDescption = itemDescption;
    }
}
