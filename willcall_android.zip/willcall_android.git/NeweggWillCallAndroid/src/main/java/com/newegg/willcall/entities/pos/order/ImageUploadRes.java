package com.newegg.willcall.entities.pos.order;

import com.newegg.willcall.entities.ErrorResponseInfo;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class ImageUploadRes extends ErrorResponseInfo implements Serializable {
    private static final long serialVersionUID = -3396321889288358627L;
}
