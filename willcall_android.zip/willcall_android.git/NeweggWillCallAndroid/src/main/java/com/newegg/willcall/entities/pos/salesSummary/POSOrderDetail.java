package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.entities.ErrorResponseInfo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * Created by jaredluo on 12/25/14.
 */
public class POSOrderDetail extends ErrorResponseInfo implements Serializable {
    private static final long serialVersionUID = -6498834438827858359L;
    @JSONField(name = "ItemList")
    private List<POSOrderItem> itemList;
    @JSONField(name = "OrderNumber")
    private String orderNumber;
    @JSONField(name = "SubtotalAmount")
    private BigDecimal subtotalAmount;
    @JSONField(name = "TaxAmount")
    private BigDecimal taxAmount;
    @JSONField(name = "DiscountAmount")
    private BigDecimal discountAmount;
    @JSONField(name = "GiftCardAmount")
    private BigDecimal giftCardAmount;
    @JSONField(name = "SOAmount")
    private BigDecimal soAmount;

    @JSONField(name = "EWRAAmount")
    private BigDecimal ewraAmount;

    public List<POSOrderItem> getItemList() {
        return itemList;
    }

    public void setItemList(List<POSOrderItem> itemList) {
        this.itemList = itemList;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public BigDecimal getSubtotalAmount() {
        return subtotalAmount;
    }

    public void setSubtotalAmount(BigDecimal subtotalAmount) {
        this.subtotalAmount = subtotalAmount;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public BigDecimal getGiftCardAmount() {
        return giftCardAmount;
    }

    public void setGiftCardAmount(BigDecimal giftCardAmount) {
        this.giftCardAmount = giftCardAmount;
    }

    public BigDecimal getSoAmount() {
        return soAmount;
    }

    public void setSoAmount(BigDecimal soAmount) {
        this.soAmount = soAmount;
    }

    public BigDecimal getEwraAmount() {
        return ewraAmount;
    }

    public void setEwraAmount(BigDecimal ewraAmount) {
        this.ewraAmount = ewraAmount;
    }
}
