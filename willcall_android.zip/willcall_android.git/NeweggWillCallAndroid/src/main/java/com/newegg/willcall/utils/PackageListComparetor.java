package com.newegg.willcall.utils;

import com.newegg.willcall.entities.picking.ExpiredTrackingInfo;

import java.util.Comparator;

/**
 * Created by lenayan on 14-4-10.
 */
public class PackageListComparetor implements Comparator<ExpiredTrackingInfo> {
    @Override
    public int compare(ExpiredTrackingInfo lhs, ExpiredTrackingInfo rhs) {
        return lhs.getScaned().compareTo(rhs.getScaned());
    }
}
