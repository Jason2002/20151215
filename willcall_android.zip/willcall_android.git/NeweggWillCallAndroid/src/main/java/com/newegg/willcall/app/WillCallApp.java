package com.newegg.willcall.app;

import android.app.Application;
import android.text.TextUtils;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.MainActivity;
import com.newegg.willcall.activity.main.WarehouseActivity;
import com.newegg.willcall.cache.NeweggFileCache;
import com.newegg.willcall.entities.LogUserInfo;
import com.newegg.willcall.entities.VersionInfo;
import com.newegg.willcall.entities.Warehouse;
import com.newegg.willcall.entities.WarehouseCache;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.ScreenUtil;
import com.newegg.willcall.utils.VersionUtils;

/**
 * Created by JaredLuo on 4/2/14.
 */
public class WillCallApp extends Application {

    private static String authKey;

    private static LogUserInfo user;

    private static Warehouse warehouse;

    private static MainActivity.APP_TYPE appType;


    public static String getAuthKey() {
        if (TextUtils.isEmpty(authKey))
            authKey = getUser() != null ? getUser().getAuthToken() : null;
        return authKey;
    }

    public static void setAuthKey(String authKey) {
        WillCallApp.authKey = authKey;
    }

    public static LogUserInfo getUser() {
        if (user == null)
            user = NeweggFileCache.getInstance().get(WarehouseActivity.USER_INFOR_CACHE);
        return user;
    }

    public static void setUser(LogUserInfo user) {
        WillCallApp.user = user;
    }

    public static Warehouse getWarehouse() {
        if (warehouse == null) {
            WarehouseCache cachedWareHouseInfo = NeweggFileCache.getInstance().get(WarehouseActivity.USER_WAREHOUSE_CACHE);
            if (cachedWareHouseInfo != null && getUser().getUserID() == cachedWareHouseInfo.getUserID()) {
                warehouse = cachedWareHouseInfo.getWarehouse();
            }
        }
        return warehouse;
    }

    public static void setWarehouse(Warehouse warehouse) {

        WillCallApp.warehouse = warehouse;
        WarehouseCache cachedWareHouseInfo = new WarehouseCache();
        cachedWareHouseInfo.setUserID(getUser().getUserID());
        cachedWareHouseInfo.setWarehouse(warehouse);
        NeweggFileCache.getInstance().put(WarehouseActivity.USER_WAREHOUSE_CACHE, cachedWareHouseInfo);

    }

    public static MainActivity.APP_TYPE getAppType() {
        if (WillCallApp.appType == null) {
            MainActivity.APP_TYPE type = NeweggFileCache.getInstance().get(MainActivity.CACHE_APP_TYPE);
            if (type == null) {
                WillCallApp.appType = MainActivity.APP_TYPE.APP_TYPE_WILLCALL;
            } else {
                WillCallApp.appType = type;
            }
        }

        return WillCallApp.appType;
    }

    public static void setAppType(MainActivity.APP_TYPE type) {
        NeweggFileCache.getInstance().put(MainActivity.CACHE_APP_TYPE, type);
        WillCallApp.appType = type;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        LogUtil.i("ApplicationCreate");
        ScreenUtil.setContext(this);
        NeweggFileCache.install(this);
        NeweggFileCache.getInstance().clearExpiredData();
        getVersionInfo();
    }

    private void getVersionInfo() {
        FastJsonObjectRequest<VersionInfo> request = new FastJsonObjectRequest<VersionInfo>(getApplicationContext(), VersionInfo.class, HttpConfig.VERSION_INFO, new Response.Listener<VersionInfo>() {
            @Override
            public void onResponse(VersionInfo versionInfo) {
                if (versionInfo != null) {
                    VersionUtils.checkUpdate(getApplicationContext(), versionInfo);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        });

        VolleyUtil.addToRequestQueue(getApplicationContext(), request);
    }

}
