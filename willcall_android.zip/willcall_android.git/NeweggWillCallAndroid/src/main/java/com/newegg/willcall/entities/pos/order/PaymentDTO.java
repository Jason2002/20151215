package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class PaymentDTO implements Serializable{

    private static final long serialVersionUID = 1614837860298254231L;
    @JSONField(name = "CreditCardInfo")
    private CreditCardDTO creditCardInfo;

    public CreditCardDTO getCreditCardInfo() {
        return creditCardInfo;
    }

    public void setCreditCardInfo(CreditCardDTO creditCardInfo) {
        this.creditCardInfo = creditCardInfo;
    }
}
