package com.newegg.willcall.activity.willcall.receiving;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.adapter.PackageMoveInAdapter;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.receiving.PackageMoveInResponseDTO;
import com.newegg.willcall.entities.receiving.PackageMoveInScanDTO;
import com.newegg.willcall.entities.receiving.PackageMoveInTrackingResponseDTO;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.listener.OnDataSetChangedListener;
import com.newegg.willcall.scan.CaptureActivity;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.util.ArrayList;

public class PackageMoveInActivity extends BaseActivity  {

    private static final int REQUEST_CODE = 0x12;
    private EditText txtInput;
    private ListView lvTracking;
    private TextView txtHeader;
    private String m_location;
    private PackageMoveInAdapter m_packageMoveInAdapter;
    private TextView txtLocation;
    private AlertDialog confirmDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_movein);

        if (!WillCallApp.getWarehouse().hasMoveInPrivilege()) {
            ToastUtil.show(this, getString(R.string.privilege_error));
            finish();
            return;
        }

        lvTracking=(ListView)findViewById(R.id.package_movein_listview);
        txtHeader=(TextView)findViewById(R.id.package_movein_header_textview);

        txtInput=(EditText)findViewById(R.id.package_movein_input_edittext);
        txtInput.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN && !TextUtils.isEmpty(txtInput.getText())) {
                    if(StringUtil.isEmpty(m_location)) {
                        scanLocationAndTracking(txtInput.getText().toString());
                    }
                    else
                    {
                        scanLocationAndTracking(StringUtil.formatInputTrackingNumber(txtInput.getText().toString()));
                    }
                    return true;
                } else {
                    return false;
                }
            }});

        View headerView = LayoutInflater.from(this).inflate(R.layout.package_list_header_layout, lvTracking, false);
        TextView headerTitleTextView = (TextView) headerView.findViewById(R.id.title);
        txtLocation = (TextView) headerView.findViewById(R.id.total_count);
        headerTitleTextView.setText(getString(R.string.package_movein_packagelist));
        txtLocation.setText(getString(R.string.package_movein_location));
        txtLocation.setVisibility(View.VISIBLE);
        lvTracking.addHeaderView(headerView);
        lvTracking.setVisibility(View.VISIBLE);

        TextView txtNew=(TextView)findViewById(R.id.package_movein_txt_clear);
        txtNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                m_packageMoveInAdapter.removeAllTrackingNumbers();
                m_location="";
                txtInput.setText("");
                txtLocation.setText(getString(R.string.package_movein_location));
                txtHeader.setText(R.string.package_movein_scan_location);
                txtInput.requestFocus();
            }
        });

        m_packageMoveInAdapter = new PackageMoveInAdapter(PackageMoveInActivity.this, new ArrayList<String>(), new OnDataSetChangedListener() {
            @Override
            public void onDataSetChanged() {
                lvTracking.post(new Runnable() {
                    @Override
                    public void run() {
                        lvTracking.smoothScrollToPosition(m_packageMoveInAdapter.getCount() );
                    }
                });
            }
        });

        lvTracking.setAdapter(m_packageMoveInAdapter);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null && !TextUtils.isEmpty(data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY))) {
            String location = data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY);
            txtInput.setText("");
            txtInput.append(location);
            scanLocationAndTracking(location);
        }
    }

    private void scanLocationAndTracking(String barcode)
    {
        if(StringUtil.isEmpty(barcode))
        {
            return;
        }
        barcode=barcode.trim();

        if(StringUtil.isEmpty(this.m_location)) {
            scanLocation(barcode);
        }
        else{
            scanTrackingNumber(barcode,false);
        }
    }

    private  void scanTrackingNumber(String barcode,Boolean isForcedMoveIn)
    {
        if (!StringUtil.isTrackingNUmber(barcode)) {
            ToastUtil.show(this, String.format(getString(R.string.trackingnumber_input_error), barcode), ToastUtil.TOAST_DURATION_LONG);
            return;
        }

        final String  finalTracking=barcode.trim();
        showProgressDialog();
        PackageMoveInScanDTO packageMoveInScanDTO = new PackageMoveInScanDTO(String.valueOf(WillCallApp.getUser().getUserID()), m_location,finalTracking,isForcedMoveIn);
        FastJsonObjectRequest<PackageMoveInTrackingResponseDTO> receivingRequest = new FastJsonObjectRequest<PackageMoveInTrackingResponseDTO>(this, PackageMoveInTrackingResponseDTO.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_MOVEIN_SCAN_TRACKING, packageMoveInScanDTO.getTrackingNumber()), packageMoveInScanDTO, new Response.Listener<PackageMoveInTrackingResponseDTO>() {
            @Override
            public void onResponse(PackageMoveInTrackingResponseDTO result) {
                hideProgressDialog();

                if(result.getStatus().equals(PackageMoveInTrackingResponseDTO.Success))
                {
                    txtInput.setText("");
                     m_packageMoveInAdapter.addUPCCode(finalTracking);
                }
                else if(result.getStatus().equals(PackageMoveInTrackingResponseDTO.Failed))
                {
                    ToastUtil.show(PackageMoveInActivity.this,result.getErrorMsg(), ToastUtil.TOAST_DURATION_LONG);
                }
                else if(result.getStatus().equals(PackageMoveInTrackingResponseDTO.Confirm))
                {
                    View view = getLayoutInflater().inflate(R.layout.movein_confirm_dialog, null);
                    TextView txt = (TextView) view.findViewById(R.id.movein_dialog_textview);
                    txt.setText(result.getErrorMsg());
                    confirmDialog = new AlertDialog.Builder(PackageMoveInActivity.this).setTitle(R.string.package_movein_confirm).
                            setPositiveButton(R.string.checkout_signature_confirm_pos_btn, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    scanTrackingNumber(finalTracking,true);
                                }
                            }).setNegativeButton(R.string.checkout_signature_confirm_neg_btn, null)
                            .setInverseBackgroundForced(true)
                            .setView(view).create();

                    confirmDialog.show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                hideProgressDialog();
            }
        });
        VolleyUtil.addToRequestQueue(this, receivingRequest);
    }

    private void scanLocation(String barcode)
    {
        final String finalLocation = barcode.trim();
        this.showProgressDialog();
        FastJsonObjectRequest<PackageMoveInResponseDTO> request = new FastJsonObjectRequest<PackageMoveInResponseDTO>(this, PackageMoveInResponseDTO.class, HttpConfig.getFormatUrl(HttpConfig.PACKAGE_MOVEIN_GET_LOCATION, finalLocation), new Response.Listener<PackageMoveInResponseDTO>() {
            @Override
            public void onResponse(PackageMoveInResponseDTO result) {
                hideProgressDialog();
               if (result.getIsSuccessful()) {
                    txtInput.setText("");
                    m_location=finalLocation;
                    txtHeader.setText(R.string.package_movein_scan_tracking);
                    txtLocation.setText(getString(R.string.package_movein_location)+finalLocation);
                    txtInput.requestFocus();
                } else {
                   ToastUtil.show(PackageMoveInActivity.this, result.getErrorMsg(), ToastUtil.TOAST_DURATION_LONG);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                hideProgressDialog();
            }
        });
        VolleyUtil.addToRequestQueue(this, request);
    }

    public void onScanButtonClicked(View view) {
        Intent intent = new Intent(this, CaptureActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    public void onBarcodeScanned(final String barcode) {
        super.onBarcodeScanned(barcode);

        if (StringUtil.isEmpty(barcode)){
            return;
        }

        if (this.txtInput == null) {
            return;
        }

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setBarcode(barcode);
            }
        });
    }

    private void setBarcode(String barcode){
        txtInput.setText("");
        txtInput.append(barcode);
        scanLocationAndTracking(barcode);
    }
}

