package com.newegg.willcall.activity.pos.orderReturn;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.pos.order.POSOrderThankyouActivity;
import com.newegg.willcall.adapter.HeaderViewRecyclerAdapter;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.orderReturn.POSReturnDTO;
import com.newegg.willcall.entities.pos.orderReturn.POSReturnMasterDTO;
import com.newegg.willcall.entities.pos.orderReturn.POSReturnTransactionDTO;
import com.newegg.willcall.entities.pos.orderReturn.UIPOSReturnInfo;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.newegg.willcall.widget.ManualInputActionView;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public class POSReturnActivity extends BaseActivity implements  View.OnClickListener{
    public static final String EXTRA_ORDER = "EXTRA_ORDER";
    public static final int REQUEST_CODE_RESTOCKING_FEE = 1;

    private View mEmptyView;
    private View mMainView;
    private View mFooterView;
    private View mEWRAView;
    private View mGiftCardView;
    private View mDiscountView;
    private RecyclerView mRecyclerView;
    private Button mCancelButton;
    private Button mReturnButton;
    private TextView mSubtotalTextView;
    private TextView mEWRATextView;
    private TextView mTaxTextView;
    private TextView mRestockingFeeTextView;
    private TextView mDiscountTextView;
    private TextView mGiftCardTextView;
    private TextView mGrandTotalTextView;
    private ImageButton mRestockingFeeButton;

    private HeaderViewRecyclerAdapter mAdapter;
    private POSReturnRecyclerAdapter mReturnAdapter;

    private POSReturnDTO mOriginalOrder;
    private UIPOSReturnInfo mReturnOrder;
    private String mGuid = UUID.randomUUID().toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posreturn);

        if(getIntent() != null){
            mOriginalOrder = (POSReturnDTO)getIntent().getSerializableExtra(EXTRA_ORDER);
            mReturnOrder = new UIPOSReturnInfo();
            mReturnOrder.setOriginalGiftCardCollection(mOriginalOrder.getGiftCardCollection());

            setTitle(getString(R.string.pos_return_title) + mOriginalOrder.getPosReturnMaster().getSoNumber());
        }

        mMainView = findViewById(R.id.pos_return_container);
        mEmptyView = findViewById(R.id.pos_return_empty_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        mCancelButton = (Button)findViewById(R.id.pos_return_cancelButton);
        mReturnButton = (Button)findViewById(R.id.pos_return_returnButton);
        mCancelButton.setOnClickListener(this);
        mReturnButton.setOnClickListener(this);

        mFooterView = getLayoutInflater().inflate(R.layout.pos_return_detail_footer, null, false);
        mSubtotalTextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_subtotal);
        mEWRATextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_ewra);
        mTaxTextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_tax);
        mRestockingFeeTextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_restocking_fee);
        mDiscountTextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_discount);
        mGiftCardTextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_gift_card);
        mGrandTotalTextView = (TextView)mFooterView.findViewById(R.id.order_detail_footer_grand_total);
        mEWRAView = mFooterView.findViewById(R.id.order_detail_footer_ewra_layout);
        mGiftCardView = mFooterView.findViewById(R.id.order_detail_footer_gift_card_layout);
        mDiscountView = mFooterView.findViewById(R.id.order_detail_footer_discount_layout);
        mRestockingFeeButton = (ImageButton)mFooterView.findViewById(R.id.edit_restocking_fee_btn);
        mRestockingFeeButton.setOnClickListener(this);

        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mReturnAdapter = new POSReturnRecyclerAdapter();
        mAdapter = new HeaderViewRecyclerAdapter(mReturnAdapter);
        mAdapter.addFooterView(mFooterView);
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_posreturn, menu);

        final MenuItem item = menu.findItem(R.id.manual_input);
        ManualInputActionView inputAction =  (ManualInputActionView)item.getActionView();
        inputAction.setOnManualInputListener(new ManualInputActionView.OnManualInputListener() {
            @Override
            public void onApply(String input) {
                addItem(input);
                item.collapseActionView();
            }
        });
        return true;
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.edit_restocking_fee_btn:
                intent = new Intent(this, POSReturnRestockingFeeActivity.class);
                intent.putExtra(POSReturnRestockingFeeActivity.EXTRA_RETURN_ORDER, mReturnOrder);
                startActivityForResult(intent, REQUEST_CODE_RESTOCKING_FEE);
                break;
            case R.id.pos_return_cancelButton:
                finish();
                break;
            case R.id.pos_return_returnButton:
                createReturnOrder();
                break;

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_RESTOCKING_FEE && resultCode == RESULT_OK){
            BigDecimal rate = (BigDecimal)data.getSerializableExtra(POSReturnRestockingFeeActivity.EXTRA_RESULT_RATE);
            UIPOSReturnInfo.RestockingFeeType type = (UIPOSReturnInfo.RestockingFeeType)data.getSerializableExtra(POSReturnRestockingFeeActivity.EXTRA_RESULT_TYPE);

            mReturnOrder.setRestockingFeeRate(rate);
            mReturnOrder.setRestockingFeeType(type);

            mReturnOrder.reassignGiftCard();
            updateFooterData();
        }
    }

    @Override
    public void onBarcodeScanned(final String barcode) {
        super.onBarcodeScanned(barcode);

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                addItem(barcode);
            }
        });
    }

    private void addItem(String snNumber){
        if(StringUtil.isEmpty(snNumber)){
            return;
        }

        if(getSNCount(snNumber, mOriginalOrder.getTransactionCollection()) == 0){
            ToastUtil.show(this, getString(R.string.pos_return_error_invalid_serial_number));
            return;
        }

        if(getSNCount(snNumber, mReturnOrder.getTransactionCollection()) >= getSNCount(snNumber, mOriginalOrder.getTransactionCollection())){
            ToastUtil.show(this, getString(R.string.pos_return_error_limit_qty_serial_number));
            return;
        }

        Boolean found = false;
        for(POSReturnTransactionDTO item : mOriginalOrder.getTransactionCollection()){
            if(item.getSerialNumber().trim().equalsIgnoreCase(snNumber.trim())){
                POSReturnTransactionDTO copyItem = StringUtil.deepClone(item, POSReturnTransactionDTO.class);

                mReturnOrder.getTransactionCollection().add(copyItem);
                mReturnOrder.reassignGiftCard();

                mReturnAdapter.addItem(copyItem);
                mAdapter.notifyDataSetChanged();

                updateFooterData();

                mEmptyView.setVisibility(View.GONE);
                mMainView.setVisibility(View.VISIBLE);

                found = true;
                break;
            }
        }

        if(!found){
            ToastUtil.show(this, getString(R.string.pos_return_error_invalid_serial_number));
        }
    }

    private int getSNCount(String snNumber, List<POSReturnTransactionDTO> list){
        int count = 0 ;
        for(POSReturnTransactionDTO item : list) {
            if(item.getSerialNumber().trim().equalsIgnoreCase(snNumber.trim())){
                count++;
            }
        }
        return count;
    }

    private void updateFooterData(){
        if (mReturnOrder.getTotalEWRA().signum() != 0) {
            mEWRATextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getTotalEWRA()));
            mEWRAView.setVisibility(View.VISIBLE);
        } else {
            mEWRAView.setVisibility(View.GONE);
        }

        if (mReturnOrder.getTotalGiftCardAmount().signum() != 0) {
            mGiftCardTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getTotalGiftCardAmount().negate()));
            mGiftCardView.setVisibility(View.VISIBLE);
        } else {
            mGiftCardView.setVisibility(View.GONE);
        }

        if (mReturnOrder.getTotalDiscountAmount().signum() != 0) {
            mDiscountTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getTotalDiscountAmount()));
            mDiscountView.setVisibility(View.VISIBLE);
        } else {
            mDiscountView.setVisibility(View.GONE);
        }

        mSubtotalTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getTotalUnitPrice()));
        mTaxTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getTotalTaxAmount()));
        mRestockingFeeTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getRestockingFee().negate()));
        mGrandTotalTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getCreditCardAmount()));
    }


    private void createReturnOrder(){
        POSReturnMasterDTO master = new POSReturnMasterDTO();
        master.setSoNumber(mOriginalOrder.getPosReturnMaster().getSoNumber());
        master.setWarehouseNumber(WillCallApp.getWarehouse().getCode());
        master.setCreditCardReturnAmount(mReturnOrder.getCreditCardAmount());
        master.setRestockingFee(mReturnOrder.getRestockingFee());
        master.setInUserID("" + WillCallApp.getUser().getUserID());
        master.setInUserName(WillCallApp.getUser().getTrimmedName());

        POSReturnDTO postData = new POSReturnDTO();
        postData.setPosReturnMaster(master);
        postData.setGiftCardCollection(mReturnOrder.getGiftCardCollection());
        postData.setTransactionCollection(mReturnOrder.getTransactionCollection());

        showProgressDialog();
        String url = HttpConfig.getFormatUrl(HttpConfig.POS_RETURN_CREATE, mGuid);
        FastJsonObjectRequest<POSReturnDTO> request = new FastJsonObjectRequest<POSReturnDTO>(this, POSReturnDTO.class, Request.Method.PUT,
                url, postData, new Response.Listener<POSReturnDTO>() {
            @Override
            public void onResponse(POSReturnDTO result) {
                hideProgressDialog();

                Intent intent = new Intent(POSReturnActivity.this, POSOrderThankyouActivity.class);
                intent.putExtra(POSOrderThankyouActivity.PARAM_TIP, getString(R.string.pos_thankyou_refund_tip));
                startActivity(intent);
                finish();
            }
        }, new FastJsonObjectRequest.OnErrorListener() {

            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();

                if(info != null && info.getMessage() != null){
                    ToastUtil.show(POSReturnActivity.this, info.getMessage(), Toast.LENGTH_LONG);
                }
            }
        });

        VolleyUtil.addToRequestQueue(POSReturnActivity.this, request);
    }
}
