package com.newegg.willcall.activity.pos.orderReturn;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.entities.pos.orderReturn.UIPOSReturnInfo;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class POSReturnRestockingFeeActivity extends BaseActivity {
    public static final String EXTRA_RETURN_ORDER = "EXTRA_ORDER";
    public static final String EXTRA_RESULT_TYPE = "EXTRA_RESULT_TYPE";
    public static final String EXTRA_RESULT_RATE = "EXTRA_RESULT_RATE";

    private Button mApplyButton;
    private EditText mFixedPriceEditText;
    private EditText mPercentEditText;
    private TextView mSubTotalTextView;

    private UIPOSReturnInfo mReturnOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posreturn_restocking_fee);

        mReturnOrder = (UIPOSReturnInfo)getIntent().getSerializableExtra(EXTRA_RETURN_ORDER);

        mApplyButton = (Button)findViewById(R.id.pos_return_apply_button);
        mFixedPriceEditText = (EditText)findViewById(R.id.pos_return_fixedPrice_editText);
        mPercentEditText = (EditText)findViewById(R.id.pos_return_percent_editText);
        mSubTotalTextView = (TextView)findViewById(R.id.pos_return_subTotal_value_textView);

        mSubTotalTextView.setText(CurrencyUtils.getCurrencyFormat(mReturnOrder.getTotalUnitPrice()));
        if(mReturnOrder.getRestockingFeeType() == UIPOSReturnInfo.RestockingFeeType.FixedPrice){
            mFixedPriceEditText.setText(mReturnOrder.getRestockingFeeRate().toString());
            mFixedPriceEditText.selectAll();
            mFixedPriceEditText.requestFocus();
            openKeyboard(mFixedPriceEditText);
        }else{
            mPercentEditText.setText(mReturnOrder.getRestockingFeeRate().multiply(new BigDecimal("100")).setScale(2, RoundingMode.HALF_EVEN).toString());
            mPercentEditText.selectAll();
            mPercentEditText.requestFocus();
            openKeyboard(mPercentEditText);
        }

        mPercentEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                mFixedPriceEditText.setText("");
            }
        });

        mFixedPriceEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                mPercentEditText.setText("");
            }
        });

        mApplyButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                UIPOSReturnInfo.RestockingFeeType type;
                BigDecimal rate;

                if(StringUtil.isEmpty(mPercentEditText.getText().toString())
                  && StringUtil.isEmpty(mFixedPriceEditText.getText().toString())){
                    ToastUtil.show(POSReturnRestockingFeeActivity.this, getString(R.string.pos_return_restocking_fee_empty_message));
                    return;
                }

                if(StringUtil.isEmpty(mPercentEditText.getText().toString())){
                    type = UIPOSReturnInfo.RestockingFeeType.FixedPrice;
                    rate = new BigDecimal(mFixedPriceEditText.getText().toString()).setScale(2, RoundingMode.HALF_EVEN);
                }else{
                    type = UIPOSReturnInfo.RestockingFeeType.Percent;
                    rate = new BigDecimal(mPercentEditText.getText().toString()).divide(new BigDecimal("100")).setScale(4, RoundingMode.HALF_EVEN);
                }

                mReturnOrder.setRestockingFeeRate(rate);
                mReturnOrder.setRestockingFeeType(type);
                mReturnOrder.reassignGiftCard();

                BigDecimal total = mReturnOrder.getTotalAmount().add(mReturnOrder.getRestockingFee());
                if(mReturnOrder.getRestockingFee().compareTo(total) > 0){
                    ToastUtil.show(POSReturnRestockingFeeActivity.this, getString(R.string.pos_return_restocking_fee_invalid));
                    return;
                }

                Intent intent = new Intent();
                intent.putExtra(EXTRA_RESULT_TYPE, type);
                intent.putExtra(EXTRA_RESULT_RATE, rate);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }
}
