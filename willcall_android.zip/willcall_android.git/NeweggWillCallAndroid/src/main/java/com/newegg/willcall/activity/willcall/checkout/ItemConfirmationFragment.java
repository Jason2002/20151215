package com.newegg.willcall.activity.willcall.checkout;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseFragment;
import com.newegg.willcall.entities.checkout.CheckOutPackageInfo;
import com.newegg.willcall.entities.checkout.CheckOutSoInfo;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;

import java.util.List;

/**
 * Created by JaredLuo on 14-4-11.
 */
public class ItemConfirmationFragment extends BaseFragment {
    public static final String ARGUMENT_CONFIRMATION_PICKING_TASK = "ARGUMENT_CONFIRMATION_PICKING_TASK";
    public static final int REQUEST_CODE_FOR_SIGN = 0x20;

    private CheckoutActivity mActivity;
    private ListView mListView;
    private Button mSignBtn;
    private OrderListAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checkout_frag_item_confirmation, container, false);

        mActivity = (CheckoutActivity) getActivity();
        if (isAdded()) {
            mActivity.setStep(3);
        }

        findView(view);
        if (getArguments() != null) {
            ReferenceOrderPickingTask pickingTask = (ReferenceOrderPickingTask) getArguments().getSerializable(ARGUMENT_CONFIRMATION_PICKING_TASK);
            bindUI(pickingTask);
        }

        return view;
    }

    public static ItemConfirmationFragment createItemConfirmationFragment(ReferenceOrderPickingTask pickingTask){
        ItemConfirmationFragment fragment = new ItemConfirmationFragment();
        if(pickingTask!=null) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(ItemConfirmationFragment.ARGUMENT_CONFIRMATION_PICKING_TASK, pickingTask);
            fragment.setArguments(bundle);
        }
        return fragment;
    }


    private void bindUI(final ReferenceOrderPickingTask pickingTask) {

        List<CheckOutSoInfo> sos = pickingTask.getSoList();
        int count = getPackageCount(sos);
        if (sos != null) {
            mListView.setFooterDividersEnabled(true);
            mListView.addFooterView(getFooterView(pickingTask, count));
            mAdapter = new OrderListAdapter(mActivity, pickingTask, false);
            mListView.setAdapter(mAdapter);
            mSignBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //TODO SIGN
                    Intent intent = new Intent(mActivity, SignActivity.class);
                    intent.putExtra(SignActivity.PARAMS_CHECKOUT_TASK_INFO, pickingTask);
                    intent.putExtra(SignActivity.PARAMS_CHECKOUT_PAGE_ORIENTATION, mActivity.getRequestedOrientation());
                    startActivityForResult(intent, REQUEST_CODE_FOR_SIGN);
                }
            });
        }
    }


    private void findView(View view) {
        mListView = (ListView) view.findViewById(R.id.checkout_confirm_package_list);
        mSignBtn = (Button) view.findViewById(R.id.checkout_sign_btn);
    }


    private int getPackageCount(List<CheckOutSoInfo> sos) {
        int count = 0;
        if (sos != null) {
            for (CheckOutSoInfo so : sos) {
                if (so != null && so.getPackageList() != null) {
                    List<CheckOutPackageInfo> packages = so.getPackageList();
                    if (packages != null) {
                        count += packages.size();
                    }
                }
            }
        }

        return count;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_FOR_SIGN) {
            if (data != null) {
                int orientation = data.getIntExtra(SignActivity.PARAMS_CHECKOUT_PAGE_ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                mActivity.setRequestedOrientation(orientation);
                if (resultCode == Activity.RESULT_OK) {
                    mActivity.finish();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private View getFooterView(ReferenceOrderPickingTask pickingTask, int totalPackageCount) {
        View footerView = LayoutInflater.from(mActivity).inflate(R.layout.checkout_package_footer, null);
        TextView totalCountTextView = (TextView) footerView.findViewById(R.id.checkout_footer_total_count);
        totalCountTextView.setText(totalPackageCount + " " + getString(R.string.checkout_packages));
        return footerView;
    }
}