package com.newegg.willcall.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.listener.OnDataSetChangedListener;
import com.newegg.willcall.utils.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cf86 on 4/15/2015.
 */
public class PackageMoveInAdapter extends PackageListAdapter<String> {

    public PackageMoveInAdapter(Context context, List<String> packageList, OnDataSetChangedListener listener) {
        super(context, packageList, listener);
    }

    public void setStringList(List<String> stringList) {
        mItemsList = stringList;
        notifyDataSetChanged();
    }

    public void removeAllTrackingNumbers() {
        mItemsList.clear();
        notifyDataSetChanged();
    }

    public void addUPCCode(String packageScan) {
        if (TextUtils.isEmpty(packageScan))
            throw new IllegalArgumentException("Package barcode is empty");
        if (mItemsList == null) {
            mItemsList = new ArrayList<String>();
            mItemsList.add(packageScan);
        } else {
            if (mItemsList.contains(packageScan)) {
                ToastUtil.show(mContext, mContext.getString(R.string.reveiving_package_exist), ToastUtil.TOAST_DURATION_LONG);
            } else {
                mItemsList.add(packageScan);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PackageListViewHolder viewHolder;
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new PackageListViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.package_list_cell, parent, false);
            viewHolder.packageTitle = (TextView) convertView;
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (PackageListViewHolder) convertView.getTag();
        }
        viewHolder.packageTitle.setText((position + 1) + ". " + getItem(position));
        return convertView;
    }



    private static class PackageListViewHolder {
        TextView packageTitle;
    }
}
