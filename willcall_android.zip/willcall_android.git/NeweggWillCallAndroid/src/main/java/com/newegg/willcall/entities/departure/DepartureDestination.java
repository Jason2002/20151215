package com.newegg.willcall.entities.departure;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lenayan on 14-4-11.
 */
public class DepartureDestination {

    @JSONField(name = "Destination")
    private String mDestination;
    @JSONField(name = "Quantity")
    private int mQuantity;
    @JSONField(name = "TrackingNumberList")
    private List<String> mTrackingNumberList;


    public String getDestination() {
        return mDestination;
    }

    public void setDestination(String destination) {
        mDestination = destination;
    }

    public int getQuantity() {
        return getTrackingNumberList().size();
    }

    public List<String> getTrackingNumberList() {
        if (mTrackingNumberList == null)
            mTrackingNumberList = new ArrayList<String>();
        return mTrackingNumberList;
    }

    public void setTrackingNumberList(List<String> trackingNumberList) {
        mTrackingNumberList = trackingNumberList;
    }
}
