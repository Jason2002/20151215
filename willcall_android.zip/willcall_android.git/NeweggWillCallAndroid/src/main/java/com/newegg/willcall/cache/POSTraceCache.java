package com.newegg.willcall.cache;

import android.text.format.DateUtils;

import com.newegg.willcall.utils.DateUtil;
import com.newegg.willcall.utils.FileUtils;

import java.io.File;
import java.util.Date;

/**
 * Created by dy45 on 5/29/2015.
 */
public class POSTraceCache {
    private static String FileDir = "POSTrace"+ File.separator;
    private static Object sync_lock = new Object();

    private static String getFilePath(){
        return getFilePath(new Date());
    }

    private static String getFilePath(Date date){
        if(!DateUtil.isDate(date)){
            date = new Date();
        }
        return FileDir+ DateUtil.toDayString(date);
    }

    public static String read(Date date){
        return FileUtils.read(getFilePath(date));
    }

    public static void add(String msg){
        msg ="\n"+ DateUtil.toString("HH:mm:ss")+"  "+msg;
        synchronized (sync_lock){
            FileUtils.write(getFilePath(),msg,true);
        }
    }
    
    public static void clear(Date date){
        FileUtils.write(getFilePath(date),"",false);
    }
}
