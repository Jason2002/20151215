package com.newegg.willcall.utils;

import java.util.List;

/**
 * Created by dy45 on 4/18/2015.
 */
public class ListUtil {
    public static boolean isNullOrEmpty(List list){
        return list == null || list.size()==0;
    }
}
