package com.newegg.willcall.entities.receiving;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by cf86 on 4/17/2015.
 */
public class PackageMoveInTrackingResponseDTO {

    public  static final   String Success="Success";
    public  static final   String Failed="Failed";
    public  static final   String Confirm="Confirm";

    @JSONField(name = "Status")
    private String mStatus;

    public String getStatus() {
        return mStatus;
    }

    public void setStatus(String status) {
        mStatus = status;
    }

    @JSONField(name = "ErrorMsg")
    private String m_errorMsg;

    public String getErrorMsg() {
        return m_errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        m_errorMsg = errorMsg;
    }
}
