package com.newegg.willcall.entities.pos.order;

import com.newegg.willcall.utils.CurrencyUtils;

import org.apache.commons.math3.util.Decimal64;

import java.io.Serializable;
import java.util.List;

/**
 * Created by jaredluo on 12/25/14.
 */
public class ItemInfo extends ItemBase implements Serializable {
    private static final long serialVersionUID = -5460596864433074372L;
    private List<String> barcodeValues;
    private int qty = 1;


    public ItemInfo() {

    }

    public ItemInfo(ItemBase base) {
        super(base);
    }

    public List<String> getBarcodeValues() {
        return barcodeValues;
    }

    public void setBarcodeValues(List<String> barcodeValues) {
        this.barcodeValues = barcodeValues;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }


}
