package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-16.
 */
public class LogOutDTO {

    @JSONField(name = "UserID")
    private String mUserID;

    public LogOutDTO(String userID) {
        mUserID = userID;
    }

    public String getUserID() {
        return mUserID;
    }

    public void setUserID(String userID) {
        mUserID = userID;
    }
}
