package com.newegg.willcall.event;

/**
 * Created by dy45 on 4/14/2015.
 */
public interface OnActionListener2<T1,T2> {
    void action(T1 t1,T2 t2);
}
