package com.newegg.willcall.activity.account;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.method.PasswordTransformationMethod;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newegg.willcall.BuildConfig;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.main.WarehouseActivity;
import com.newegg.willcall.cache.NeweggFileCache;
import com.newegg.willcall.utils.EncryptUtil;
import com.newegg.willcall.utils.ScreenUtil;
import com.newegg.willcall.utils.StringUtil;
import com.nineoldandroids.animation.ValueAnimator;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by JaredLuo on 4/3/14.
 */
public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private LinearLayout mLoginContainer;
    private EditText mUserIdEditText;
    private EditText mPasswordEditText;
    private Button mLoginBtn;
    private CheckBox mRememberPassword;
    private TextView mtxbVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        MobclickAgent.updateOnlineConfig(this);

        findView();

        mLoginBtn.setOnClickListener(this);

        mLoginContainer.postDelayed(new Runnable() {
            @Override
            public void run() {
                animate();
            }
        }, 2000);

        mtxbVersion.setText("V"+BuildConfig.VERSION_NAME);

    }

    private void getCacheKey() {
        byte[] encrypted = NeweggFileCache.getInstance().get(WarehouseActivity.KEY_CACHE_KEY);
        String userId = NeweggFileCache.getInstance().get(WarehouseActivity.NAME_CACHE_KEY);
        if (encrypted != null && encrypted.length > 0) {
            String pwd = "";
            try {
                pwd = EncryptUtil.decryptPwd(this, encrypted);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!StringUtil.isEmpty(pwd) && !StringUtil.isEmpty(userId)) {
                mUserIdEditText.setText(userId);
                mPasswordEditText.setText(pwd);
            }
        }
    }

    private void findView() {
        mLoginContainer = (LinearLayout) findViewById(R.id.login_container);

        mUserIdEditText = (EditText) findViewById(R.id.login_user_id);

        mPasswordEditText = (EditText) findViewById(R.id.login_password);
        mPasswordEditText.setTransformationMethod(new PasswordTransformationMethod());

        mPasswordEditText.setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    login();
                }
                return false;
            }
        });

        mLoginBtn = (Button) findViewById(R.id.login_btn);
        mRememberPassword = (CheckBox) findViewById(R.id.remember_password_checkbox);
        mtxbVersion = (TextView) findViewById(R.id.login_version);

        final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isNeedRemember = sharedPreferences.getBoolean(WarehouseActivity.PARAM_NEED_REMEMBER_PASSWORD, false);
        if (isNeedRemember) getCacheKey();
        mRememberPassword.setChecked(isNeedRemember);
        mRememberPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                sharedPreferences.edit().putBoolean(WarehouseActivity.PARAM_NEED_REMEMBER_PASSWORD, isChecked).commit();
            }
        });
    }

    @Override
    public void onClick(View v) {
        login();
    }

    private void login() {

        CharSequence inputId = mUserIdEditText.getText();
        CharSequence inputPwd = mPasswordEditText.getText();

        if (inputId == null || StringUtil.isEmpty(inputId.toString())) {
            mUserIdEditText.setError(getString(R.string.login_user_id_empty));
            mUserIdEditText.requestFocus();
            return;
        }

        if (inputPwd == null || StringUtil.isEmpty(inputPwd.toString())) {
            mPasswordEditText.setError(getString(R.string.login_password_empty));
            mPasswordEditText.requestFocus();
            return;
        }

        Intent intent = new Intent(this, WarehouseActivity.class);
        intent.putExtra(WarehouseActivity.PARAM_LOGIN_USER_ID, inputId.toString().trim());
        intent.putExtra(WarehouseActivity.PARAM_LOGIN_PASSWORD, inputPwd.toString().trim());
        intent.putExtra(WarehouseActivity.PARAM_NEED_REMEMBER_PASSWORD, mRememberPassword.isChecked());
        startActivity(intent);
        overridePendingTransition(R.anim.anim_up_in, R.anim.anim_up_out);
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    private void animate() {
        int fromHeight = mLoginContainer.getMeasuredHeight();
        int toHeight = ScreenUtil.getPxByDp(200);

        mLoginContainer.setVisibility(View.VISIBLE);

        ValueAnimator animator = ValueAnimator.ofInt(fromHeight, toHeight);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                ViewGroup.LayoutParams params = mLoginContainer.getLayoutParams();
                params.height = (Integer) animation.getAnimatedValue();
                mLoginContainer.setLayoutParams(params);
            }
        });

        animator.setDuration(200);
        animator.setInterpolator(new AccelerateInterpolator());
        animator.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }
}
