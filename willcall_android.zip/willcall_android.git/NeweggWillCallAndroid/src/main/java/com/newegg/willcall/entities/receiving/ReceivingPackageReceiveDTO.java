package com.newegg.willcall.entities.receiving;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-9.
 */
public class ReceivingPackageReceiveDTO {
    @JSONField(name = "UserID")
    private String mUserID;
    @JSONField(name = "WCCNumber")
    private String mWCCNumber;

    public ReceivingPackageReceiveDTO(String userID, String wCCNumber) {
        this.mUserID = userID;
        this.mWCCNumber = wCCNumber;
    }

    public String getUserID() {
        return mUserID;
    }

    public void setUserID(String mUserID) {
        this.mUserID = mUserID;
    }

    public String getWCCNumber() {
        return mWCCNumber;
    }

    public void setWCCNumber(String mWCCNumber) {
        this.mWCCNumber = mWCCNumber;
    }
}
