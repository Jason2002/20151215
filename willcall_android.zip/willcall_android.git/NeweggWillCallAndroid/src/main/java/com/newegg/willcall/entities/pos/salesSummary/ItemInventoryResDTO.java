package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by flyerabc on 14/12/24.
 */
public class ItemInventoryResDTO implements Serializable {
    @JSONField(name = "SKU")
    private int sku;

    @JSONField(name = "SoldQty")
    private int soldQty;

    @JSONField(name = "Inventory")
    private int inventory;

    @JSONField(name = "ItemDescription")
    private String itemDescription;

    @JSONField(name = "ItemNumber")
    private String itemNumber;

    public int getSku() {
        return sku;
    }

    public void setSku(int sku) {
        this.sku = sku;
    }

    public int getSoldQty() {
        return soldQty;
    }

    public void setSoldQty(int soldQty) {
        this.soldQty = soldQty;
    }

    public int getInventory() {
        return inventory;
    }

    public void setInventory(int inventory) {
        this.inventory = inventory;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }
}


