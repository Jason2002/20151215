package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by jaredluo on 12/24/14.
 */
public class SODTO implements Serializable{
    private static final long serialVersionUID = -7291661911750773953L;

    public static final int VISA = 1;
    public static final int MASTER_CARD = 2;
    public static final int DISCOVER = 3;
    public static final int AMERICAN_EXPRESS = 4;

    @JSONField(name = "TransactionID")
    private String transactionID;
    @JSONField(name = "SalesPerson")
    private String salesPerson;
    @JSONField(name = "SOAmount")
    private double soAmount;
    @JSONField(name = "TaxRate")
    private double taxRate;
    @JSONField(name = "TaxAmount")
    private double taxAmount;
    @JSONField(name = "PaytermsCode")
    private String paytermsCode;
    @JSONField(name = "OrderItemInfos")
    private List<ItemInformation> orderItemInfos;
    @JSONField(name = "GCInfos")
    private List<GiftCardInformation> gcInfos;
    @JSONField(name = "SerialNumberInfos")
    private List<SerialNumberInformation> serialNumberInfos;
    @JSONField(name = "WarehouseNumber")
    private String warehouseNumber;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getSalesPerson() {
        return salesPerson;
    }

    public void setSalesPerson(String salesPerson) {
        this.salesPerson = salesPerson;
    }

    public double getSoAmount() {
        return soAmount;
    }

    public void setSoAmount(double soAmount) {
        this.soAmount = soAmount;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getPaytermsCode() {
        return paytermsCode;
    }

    public void setPaytermsCode(String paytermsCode) {
        this.paytermsCode = paytermsCode;
    }

    public List<ItemInformation> getOrderItemInfos() {
        return orderItemInfos;
    }

    public void setOrderItemInfos(List<ItemInformation> orderItemInfos) {
        this.orderItemInfos = orderItemInfos;
    }

    public List<GiftCardInformation> getGcInfos() {
        return gcInfos;
    }

    public void setGcInfos(List<GiftCardInformation> gcInfos) {
        this.gcInfos = gcInfos;
    }

    public List<SerialNumberInformation> getSerialNumberInfos() {
        return serialNumberInfos;
    }

    public void setSerialNumberInfos(List<SerialNumberInformation> serialNumberInfos) {
        this.serialNumberInfos = serialNumberInfos;
    }

    public String getWarehouseNumber() {
        return warehouseNumber;
    }

    public void setWarehouseNumber(String warehouseNumber) {
        this.warehouseNumber = warehouseNumber;
    }
}
