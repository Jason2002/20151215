package com.newegg.willcall.entities.pos.order;

import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.utils.CurrencyUtils;
import com.newegg.willcall.utils.StringUtil;

import org.apache.commons.math3.util.Decimal64;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Created by jaredluo on 12/25/14.
 */
public class CartInfo implements Serializable {
    private static final long serialVersionUID = 1337451931345882427L;
    private List<ItemInfo> items;
    private List<ItemInfoResDTO> rawItems;
    private ArrayList<GiftCardRes> giftCards;
    private double subtotal;
    private double totalEwra;
    private double totalTax;
    private double totalDiscount;
    private double totalGC;
    private double grandTotal;
    private double taxRate;

    public ArrayList<GiftCardRes> getGiftCards() {
        if (giftCards == null) {
            giftCards = new ArrayList<GiftCardRes>();
        }
        return giftCards;
    }

    public void setGiftCards(ArrayList<GiftCardRes> giftCards) {
        this.giftCards = giftCards;
    }

    public Decimal64 getTaxRate() {
        return new Decimal64(taxRate);
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = (new Decimal64(taxRate).divide(new Decimal64(100.0d))).doubleValue();
    }

    public List<ItemInfoResDTO> getRawItems() {
        if (rawItems == null) {
            rawItems = new ArrayList<ItemInfoResDTO>();
        }
        return rawItems;
    }

    public void setRawItems(List<ItemInfoResDTO> rawItems) {
        this.rawItems = rawItems;
    }

    public void addRawItems(ItemInfoResDTO rawItem) {
        List<ItemInfoResDTO> rawItems = getRawItems();
        Boolean hasSameGroup = false;
        int insertPosition = 0;

        if (rawItems == null) {
            rawItems = new ArrayList<ItemInfoResDTO>();
        }

        for (ItemInfoResDTO raw : rawItems) {

            if (raw.getItemNumber().equalsIgnoreCase(rawItem.getItemNumber())) {
                hasSameGroup = true;
                rawItem.setUnitDiscount(raw.getUnitDiscount());
            } else if (hasSameGroup) {
                break;
            }

            insertPosition++;
        }
        rawItems.add(insertPosition, rawItem);
        updateItems();
    }

    public void removeRawItems(ItemInfoResDTO rawItem) {
        getRawItems().remove(rawItem);
        updateItems();
    }

    public List<ItemInfo> getItems() {

        updateItems();
        return items;
    }

    public void updateItems() {

        if (items == null) {
            items = new ArrayList<ItemInfo>();
        } else {
            items.clear();
        }

        if (rawItems != null && rawItems.size() > 0) {
            flag:
            for (ItemInfoResDTO rawItem : rawItems) {
                for (ItemInfo item : items) {
                    if (item.getItemNumber() != null && item.getItemNumber().equalsIgnoreCase(rawItem.getItemNumber())) {
                        item.getBarcodeValues().add(rawItem.getBarcodeValue());
                        item.setQty(item.getQty() + 1);
                        continue flag;
                    }
                }

                List<String> barcodeValues = new ArrayList<String>();
                barcodeValues.add(rawItem.getBarcodeValue());

                ItemBase itemBase = rawItem;
                ItemInfo item = new ItemInfo(itemBase);

                item.setBarcodeValues(barcodeValues);
                items.add(item);
            }

        }

    }

    public void setItems(List<ItemInfo> items) {
        this.items = items;
    }

    public Decimal64 getSubtotal() {
        Decimal64 subtotalDecimal = new Decimal64(0.00);
        List<ItemInfoResDTO> _rawItems = getRawItems();
        if (_rawItems != null && _rawItems.size() > 0) {
            for (ItemInfoResDTO item : _rawItems) {
                subtotalDecimal = subtotalDecimal.add(item.getUnitPrice());
            }
        }
        return CurrencyUtils.getCellWith2Digit(subtotalDecimal);
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public Decimal64 getTotalEwra() {
        Decimal64 totalEwraDecimal = new Decimal64(0.00);
        List<ItemInfoResDTO> _rawItems = getRawItems();
        if (_rawItems != null && _rawItems.size() > 0) {
            for (ItemInfoResDTO item : _rawItems) {
                totalEwraDecimal = totalEwraDecimal.add(item.getEwra());
            }
        }

        return CurrencyUtils.getCellWith2Digit(totalEwraDecimal);
    }

    public void setTotalEwra(double totalEwra) {
        this.totalEwra = totalEwra;
    }

    public Decimal64 getTotalTax() {
        Decimal64 taxRateDecimal = getTaxRate();
        Decimal64 totalTaxDecimal = new Decimal64(0.00);
        List<ItemInfoResDTO> _rawItems = getRawItems();
        if (_rawItems != null && _rawItems.size() > 0) {
            for (ItemInfoResDTO item : _rawItems) {
                totalTaxDecimal = totalTaxDecimal.add((item.getUnitPrice().subtract(item.getUnitDiscount())).multiply(taxRateDecimal));
            }
        }
        return CurrencyUtils.getCellWith2Digit(totalTaxDecimal);
    }

    public void setTotalTax(double totalTax) {
        this.totalTax = totalTax;
    }

    public Decimal64 getTotalDiscount() {
        Decimal64 totalDiscountDecimal = new Decimal64(0.00);
        List<ItemInfoResDTO> _rawItems = getRawItems();
        if (_rawItems != null && _rawItems.size() > 0) {
            for (ItemInfoResDTO item : _rawItems) {
                totalDiscountDecimal = totalDiscountDecimal.add(item.getFormatUnitDiscount());
            }
        }
        return CurrencyUtils.getCellWith2Digit(totalDiscountDecimal);
    }

    public void setTotalDiscount(double totalDiscount) {
        this.totalDiscount = totalDiscount;
    }

    public Decimal64 getTotalGC() {
        Decimal64 totalGC = new Decimal64(0.0);

        if (giftCards == null || giftCards.size() == 0) {
            return totalGC;
        }

        for (GiftCardRes gc : giftCards) {
            totalGC = totalGC.add(gc.getFormatRedeemAmount());
        }
        return totalGC;
    }

    public void setTotalGC(double totalGC) {
        this.totalGC = totalGC;
    }

    public Decimal64 getGrandTotal() {
        Decimal64 grandTotalWithoutGCDecimal = getGrandTotalWithoutGC();

        return CurrencyUtils.getCellWith2Digit(grandTotalWithoutGCDecimal.subtract(getTotalGC()));
    }

    public Decimal64 getGrandTotalWithoutGC() {
        Decimal64 taxRateDecimal = getTaxRate();
        List<ItemInfoResDTO> _rawItems = getRawItems();
        Decimal64 grandTotalDecimal = new Decimal64(0.00);
        if (_rawItems != null && _rawItems.size() > 0) {
            for (ItemInfoResDTO item : _rawItems) {
                grandTotalDecimal = grandTotalDecimal.add(item.getUnitPrice()).add(item.getEwra()).subtract(item.getFormatUnitDiscount());
            }
        }
        grandTotalDecimal = grandTotalDecimal.add(getTotalTax());
        return CurrencyUtils.getCellWith2Digit(grandTotalDecimal);
    }

    public void setGrandTotal(double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public POSSOReqDTO buildSOReq() {

        List<ItemInfo> items = getItems();
        List<ItemInformation> itemReqInfos = new ArrayList<ItemInformation>();

        for (ItemInfo item : items) {
            ItemInformation orderItemInfo = new ItemInformation();
            orderItemInfo.setItemNumber(item.getItemNumber());
            orderItemInfo.setEwraItem(false);
            orderItemInfo.setQuantity(item.getQty());
            orderItemInfo.setUnitDiscount(-item.getFormatUnitDiscount().doubleValue());
            orderItemInfo.setUnitEWRA(item.getEwra().doubleValue());
            orderItemInfo.setUnitPrice(item.getUnitPrice().doubleValue());
            orderItemInfo.setUnitTax(item.getUnitTax(getTaxRate()).doubleValue());
            orderItemInfo.setDescription(item.getLongDescription() == null ? "" : item.getLongDescription());
            itemReqInfos.add(orderItemInfo);

            if (!StringUtil.isEmpty(item.getEwraItemNumber())) {
                ItemInformation ewraItem = new ItemInformation();
                ewraItem.setEwraItem(true);
                ewraItem.setUnitPrice(item.getEwra().doubleValue());
                ewraItem.setQuantity(item.getQty());
                ewraItem.setItemNumber(item.getEwraItemNumber());
                ewraItem.setDescription(item.getLongDescription());
                itemReqInfos.add(ewraItem);
            }
        }

        ArrayList<GiftCardRes> giftCards = getGiftCards();
        List<GiftCardInformation> giftCardReqInfos = new ArrayList<GiftCardInformation>();
        int priority = 1;
        for (GiftCardRes card : giftCards) {
            GiftCardInformation giftCardInfo = new GiftCardInformation();
            giftCardInfo.setGcCode(card.getCardNum());
            giftCardInfo.setSubCode(priority);
            giftCardInfo.setRedeemAmount(-card.getFormatRedeemAmount().doubleValue());

            giftCardReqInfos.add(giftCardInfo);

            priority++;
        }

        List<ItemInfoResDTO> rawItems = getRawItems();
        List<SerialNumberInformation> snReqInfos = new ArrayList<SerialNumberInformation>();

        for (ItemInfoResDTO item : rawItems) {
            SerialNumberInformation snInfo = new SerialNumberInformation();
            snInfo.setItemNumber(item.getItemNumber());
            snInfo.setSerialNumber(item.getBarcodeValue());

            snReqInfos.add(snInfo);
        }

        SODTO soInfo = new SODTO();

        soInfo.setGcInfos(giftCardReqInfos);
        soInfo.setOrderItemInfos(itemReqInfos);
        soInfo.setSalesPerson(WillCallApp.getUser().getTrimmedName());
        soInfo.setSerialNumberInfos(snReqInfos);
        soInfo.setSoAmount(getGrandTotalWithoutGC().doubleValue());
        soInfo.setTaxAmount(getTotalTax().doubleValue());
        soInfo.setTaxRate(getTaxRate().multiply(new Decimal64(100)).intValue());
        soInfo.setTransactionID(UUID.randomUUID().toString());
        soInfo.setWarehouseNumber(WillCallApp.getWarehouse().getCode());

        CreditCardDTO creditCardDTO = new CreditCardDTO();
        creditCardDTO.setPaymentAmount(getGrandTotal().doubleValue());

        PaymentDTO paymentDTO = new PaymentDTO();
        paymentDTO.setCreditCardInfo(creditCardDTO);

        POSSOReqDTO soReq = new POSSOReqDTO();
        soReq.setSoInfo(soInfo);
        soReq.setPaymentDTO(paymentDTO);

        return soReq;
    }

    public void setDiscountToRaws(double discount, String itemNumber) {

        for (ItemInfoResDTO rawItem : getRawItems()) {
            if (rawItem.getItemNumber().equalsIgnoreCase(itemNumber)) {
                rawItem.setUnitDiscount(discount);
            }
        }

        updateItems();

        needReduceGiftCard();
    }

    public void needReduceGiftCard() {
        if (getGiftCards().size() > 0) {
            List<GiftCardRes> cards = getGiftCards();
            Iterator<GiftCardRes> iterator = cards.iterator();
            while (iterator.hasNext() && getGrandTotal().doubleValue() < 0) {
                GiftCardRes card = iterator.next();
                if (card.getRedeemAmount() > Math.abs(getGrandTotal().doubleValue())) {
                    Decimal64 redeemAmountDecimal = new Decimal64(card.getRedeemAmount());
                    card.setRedeemAmount(redeemAmountDecimal.add(getGrandTotal()).doubleValue());
                } else {
                    iterator.remove();
                }
            }

        }
    }

//    public void needImproveGiftCard() {
//        if (getGiftCards().size() > 0) {
//            List<GiftCardRes> cards = getGiftCards();
//            Iterator<GiftCardRes> iterator = cards.iterator();
//            while (iterator.hasNext() && getGrandTotal().doubleValue() > 0) {
//                GiftCardRes card = iterator.next();
//                Decimal64 balanceDecimal = new Decimal64(card.getBalance());
//                Decimal64 redeemDecimal = new Decimal64(card.getRedeemAmount());
//                Decimal64 leftDecimal = balanceDecimal.subtract(redeemDecimal);
//                if (leftDecimal.doubleValue() > 0) {
//                    Decimal64 redeemAmountDecimal = new Decimal64(card.getRedeemAmount());
//                    if (leftDecimal.doubleValue() > getGrandTotal().doubleValue()) {
//                        card.setRedeemAmount(redeemAmountDecimal.add(getGrandTotal()).doubleValue());
//                    } else {
//                        card.setRedeemAmount(redeemAmountDecimal.add(leftDecimal).doubleValue());
//                    }
//                }
//            }
//
//        }
//    }

}
