package com.newegg.willcall.activity.pos.order;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.utils.PDFUtils;
import com.newegg.willcall.utils.StringUtil;

import java.io.File;

public class POSOrderThankyouActivity extends BaseActivity {
    public static final String PARAM_TIP = "PARAM_TIP";
    public static final String PARAM_PDF_FILE_NAME = "PDF_FILE_NAME";

    private TextView tipTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posorder_thankyou);

        tipTextView = (TextView) findViewById(R.id.thankyou_tip_TextView);

        if (getIntent() != null) {
            String tip = getIntent().getStringExtra(PARAM_TIP);
            if (!StringUtil.isEmpty(tip)) {
                tipTextView.setText(tip);
                tipTextView.setVisibility(View.VISIBLE);
            } else {
                tipTextView.setVisibility(View.GONE);
            }

            String printFile = getIntent().getStringExtra(PARAM_PDF_FILE_NAME);
            if (!StringUtil.isEmpty(printFile)) {
                PDFUtils.printPDF(this, new File(printFile));
            }
        }
    }

    public void onBackButtonClicked(View view) {
        this.backToHome();
    }

    @Override
    public void onBackPressed() {

    }
}
