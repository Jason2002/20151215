package com.newegg.willcall.activity.pos.salesSummary;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.pos.salesSummary.SalesOrderDetailInfo;
import com.newegg.willcall.utils.CurrencyUtils;

import java.util.List;

public class SalesRecyclerAdapter extends RecyclerView.Adapter<SalesRecyclerAdapter.ViewHolder>{
    private List<SalesOrderDetailInfo> mList;

    public SalesRecyclerAdapter(List<SalesOrderDetailInfo> list){
        mList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pos_sales_summary_sales_cell, parent, false);
        return new ViewHolder(v, parent.getContext());
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        SalesOrderDetailInfo item = mList.get(position);
        holder.orderNumberTextView.setText(String.valueOf(item.getSONumber()));
        holder.revenueTextView.setText(CurrencyUtils.getCurrencyFormat(item.getRevenue()));
        holder.soldQtyTextView.setText(String.valueOf(item.getSoldQty()));
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView orderNumberTextView;
        public TextView revenueTextView;
        public TextView soldQtyTextView;
        public View layoutView;
        private Context context;

        public ViewHolder(View itemView, Context ctx) {
            super(itemView);

            context = ctx;
            orderNumberTextView = (TextView) itemView.findViewById(R.id.order_number_textView);
            revenueTextView = (TextView) itemView.findViewById(R.id.revenue_textView);
            soldQtyTextView = (TextView) itemView.findViewById(R.id.sold_qty_textView);
            layoutView = itemView.findViewById(R.id.layout);
            layoutView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int orderNumber = Integer.parseInt(orderNumberTextView.getText().toString());
            Intent intent = new Intent(context, POSOrderDetailActivity.class);
            intent.putExtra(POSOrderDetailActivity.EXTRA_ORDER_NUMBER, orderNumber);
            context.startActivity(intent);
        }
    }
}
