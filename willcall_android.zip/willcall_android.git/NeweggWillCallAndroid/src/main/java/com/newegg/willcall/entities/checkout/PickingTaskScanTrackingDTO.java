package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by JaredLuo on 14-4-11.
 */
public class PickingTaskScanTrackingDTO implements Serializable {
    private static final long serialVersionUID = 2115038945387421648L;
    @JSONField(name = "TrackingNumber")
    private String trackingNumber;
    @JSONField(name = "UserID")
    private String userID;

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
