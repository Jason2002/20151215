package com.newegg.willcall.activity.willcall.checkout;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseFragment;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.checkout.CheckOutSoInfo;
import com.newegg.willcall.entities.checkout.PickingTaskDTO;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.scan.CaptureActivity;
import com.newegg.willcall.utils.ScreenUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by JaredLuo on 14-4-9.
 */
public class CustomerCheckoutFragment extends BaseFragment {
    private CheckoutActivity mActivity;

    private EditText mCodeEditText;
    private ScrollView mOrderContainer;
    private TextView mPickupByTextView;
    private TextView mCreditCardNameTextView;
    private TextView mCreditCardNumTextView;
    private LinearLayout mOrderNumContainer;
    private TextView mTypeTextView;
    private TextView mClearTextView;
    private Button mNextBtn;

    private List<CheckOutSoInfo> mScanedSOs = new ArrayList<CheckOutSoInfo>();

    private ReferenceOrderPickingTask mTask;
    private ImageButton mScanBtn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checkout_frag_customer_checkout, container, false);

        mActivity = (CheckoutActivity) getActivity();
        if (isAdded()) {
            mActivity.setStep(1);
        }

        findView(view);

        setEditText();

        if (mTask != null) {
            mScanedSOs.clear();
            dealResult(mTask);
        }

        return view;
    }

    private void setEditText() {
        mCodeEditText.setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(mCodeEditText.getWindowToken(), 0);
                    if (mCodeEditText.getText() != null && !StringUtil.isEmpty(mCodeEditText.getText().toString())) {
                        orderPickTask(mCodeEditText.getText().toString());
                    }
                }
                return false;
            }
        });

        mScanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, CaptureActivity.class);
                startActivityForResult(intent, CheckoutActivity.REQUEST_CODE_START_CAPTURE);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == CheckoutActivity.RESULT_OK && requestCode == CheckoutActivity.REQUEST_CODE_START_CAPTURE) {
            if (data != null) {
                String code = data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY);
                if (!StringUtil.isEmpty(code)) {
                    mCodeEditText.setText(code);
                    orderPickTask(mCodeEditText.getText().toString());
                }
            }
        }
    }

    private void orderPickTask(String orderNum) {
        if (!StringUtil.isEmpty(orderNum)) {
            orderNum = orderNum.trim();
        }

        final ProgressDialog progressDialog = getLoadingDialog();
        progressDialog.show();

        StringBuilder combinedOrderNumsSB = getCombinOrderNums(mScanedSOs);

        String combinedOrderNums;
        if (combinedOrderNumsSB.length() > 0) {
            combinedOrderNums = combinedOrderNumsSB.toString() + ";" + orderNum;
        } else {
            combinedOrderNums = orderNum;
        }

        final PickingTaskDTO requestBody = new PickingTaskDTO();
        requestBody.setUniqueOrderNumbers(combinedOrderNums);
        requestBody.setWccNumber(WillCallApp.getWarehouse().getCode());

        final FastJsonObjectRequest<ReferenceOrderPickingTask> request = new FastJsonObjectRequest<ReferenceOrderPickingTask>(mActivity, ReferenceOrderPickingTask.class, HttpConfig.CHECKOUT_ORDER_PICKING_TASK, requestBody, new Response.Listener<ReferenceOrderPickingTask>() {
            @Override
            public void onResponse(ReferenceOrderPickingTask orderPickingTask) {
                if (mActivity == null) {
                    return;
                }

                progressDialog.dismiss();

                if (orderPickingTask != null) {

                    orderPickingTask.setLastRequestCode(requestBody.getUniqueOrderNumbers());
                    dealResult(orderPickingTask);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                progressDialog.dismiss();
            }
        });

        VolleyUtil.addToRequestQueue(mActivity, request);
    }

    private void dealResult(final ReferenceOrderPickingTask task) {
        if (!StringUtil.isEmpty(task.getErrorMessage())) {
            showErr(task.getErrorMessage());
            mCodeEditText.requestFocus();
            mCodeEditText.requestFocusFromTouch();
            mCodeEditText.selectAll();
            return;
        }

        if (task.getTaskId() > 0) {
            if (mScanedSOs.size() == 0) {
                mCodeEditText.setFocusable(false);
                mCodeEditText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog dialog = new AlertDialog.Builder(mActivity).setTitle(R.string.checkout_task_exist_title).
                                setMessage(R.string.checkout_task_exist_note_1).setCancelable(true).setPositiveButton(R.string.button_ok, null).create();
                        dialog.show();
                    }
                });
                bindUI(task);
            } else {
                AlertDialog dialog = new AlertDialog.Builder(mActivity).setTitle(R.string.checkout_task_exist_title).
                        setMessage(getString(R.string.checkout_task_exist_note_2, task.getLastRequestCode())).setCancelable(true).setPositiveButton(R.string.button_ok, null).create();
                dialog.show();
            }

        } else {
            bindUI(task);
        }


    }

    private StringBuilder getCombinOrderNums(List<CheckOutSoInfo> scanedSOs) {
        StringBuilder sb = new StringBuilder("");
        if (scanedSOs == null || scanedSOs.size() == 0) {
            return sb;
        }
        for (CheckOutSoInfo soInfo : scanedSOs) {
            sb.append(";");
            sb.append(soInfo.getUniqueOrderNumber());
        }

        if (sb.length() > 0) {
            sb.deleteCharAt(0);
        }

        return sb;
    }

    private ProgressDialog getLoadingDialog() {
        ProgressDialog progressDialog = new ProgressDialog(mActivity);
        progressDialog.setProgressStyle(R.style.ProgressBarWillCallIndeterminate_White);
        progressDialog.setMessage("Loading");
        return progressDialog;
    }

    private void showErr(String err) {
        ToastUtil.show(mActivity, err, ToastUtil.TOAST_DURATION_LONG);
    }

    private void bindUI(ReferenceOrderPickingTask orderPickingTask) {

        mTask = orderPickingTask;

        mScanedSOs.clear();
        mScanedSOs.addAll(orderPickingTask.getSoList());

        mPickupByTextView.setText(orderPickingTask.getPickupPerson());
        if (orderPickingTask.getCreditCard() != null && !"".equals(orderPickingTask.getCreditCard().trim())) {
            mCreditCardNumTextView.setText(orderPickingTask.getCreditCard().trim());
        } else {
            mCreditCardNumTextView.setText(orderPickingTask.getPayTerms().trim());
        }
        mCreditCardNameTextView.setText(orderPickingTask.getBillingContactWith());
        mTypeTextView.setText(orderPickingTask.getPickupType());

        setCreditCardImg(orderPickingTask.getPayTerms());

        List<CheckOutSoInfo> soList = orderPickingTask.getSoList();
        mOrderNumContainer.removeAllViews();
        if (soList != null) {
            for (CheckOutSoInfo soInfo : soList) {
                TextView soNumTextView = (TextView) LayoutInflater.from(mActivity).inflate(R.layout.checkout_so_num, mOrderNumContainer, false);
                soNumTextView.setText(soInfo.getUniqueOrderNumber());
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mOrderNumContainer.addView(soNumTextView, params);
            }
        }

        mNextBtn.setEnabled(true);
        mClearTextView.setEnabled(true);

        mNextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createPickingTask();
            }
        });

        mClearTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScanedSOs.clear();
                mCodeEditText.setText("");
                mCodeEditText.setOnClickListener(null);
                mCodeEditText.setFocusableInTouchMode(true);
                mCodeEditText.setFocusable(true);
                mCodeEditText.requestFocus();
                mCodeEditText.requestFocusFromTouch();
                mOrderContainer.setVisibility(View.GONE);
                mNextBtn.setEnabled(false);
                mClearTextView.setEnabled(false);
            }
        });
        mOrderContainer.setVisibility(View.VISIBLE);
    }

    private void createPickingTask() {
        //TODO

        final ProgressDialog progressDialog = getLoadingDialog();
        progressDialog.show();

        StringBuilder combinedOrderNumsSB = getCombinOrderNums(mScanedSOs);

        if (combinedOrderNumsSB.length() == 0) {
            return;
        }

        PickingTaskDTO requestBody = new PickingTaskDTO();
        requestBody.setUniqueOrderNumbers(combinedOrderNumsSB.toString());
        requestBody.setUserID(WillCallApp.getUser().getUserID() + "");
        requestBody.setWccNumber(WillCallApp.getWarehouse().getCode());

        FastJsonObjectRequest<ReferenceOrderPickingTask> request = new FastJsonObjectRequest<ReferenceOrderPickingTask>(mActivity, ReferenceOrderPickingTask.class, Request.Method.PUT, HttpConfig.CHECKOUT_ORDER_PICKING_TASK, requestBody, new Response.Listener<ReferenceOrderPickingTask>() {
            @Override
            public void onResponse(ReferenceOrderPickingTask orderPickingTask) {
                if (mActivity == null) {
                    return;
                }

                progressDialog.dismiss();

                if (orderPickingTask != null) {
                    if (!StringUtil.isEmpty(orderPickingTask.getErrorMessage())) {
                        showErr(orderPickingTask.getErrorMessage());
                        return;
                    }
                    if(orderPickingTask.isAllScaned()){
                        BaseFragment fragment = ItemConfirmationFragment.createItemConfirmationFragment(orderPickingTask);
                        mActivity.switchContent(fragment, true);
                    }else{
                        PackagePickFragment pickFragment = PackagePickFragment.createPackagePickFragment(orderPickingTask);
                        mActivity.switchContent(pickFragment, true);
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                progressDialog.dismiss();
            }
        });

        VolleyUtil.addToRequestQueue(mActivity, request);
    }

    private void setCreditCardImg(String payTerms) {
        payTerms = payTerms.trim();
        int resId = 0;
        if ("VISA".equalsIgnoreCase(payTerms)) {
            resId = R.drawable.credit_card_visa;
        } else if ("Mastercard".equalsIgnoreCase(payTerms)) {
            resId = R.drawable.credit_card_master;
        } else if ("Discover".equalsIgnoreCase(payTerms)) {
            resId = R.drawable.credit_card_discover;
        } else if ("American Express".equals(payTerms)) {
            resId = R.drawable.credit_card_amex;
        }

        mCreditCardNumTextView.setCompoundDrawablesWithIntrinsicBounds(resId, 0, 0, 0);
        mCreditCardNumTextView.setCompoundDrawablePadding(ScreenUtil.getPxByDp(10));
    }

    private void findView(View view) {
        mCodeEditText = (EditText) view.findViewById(R.id.checkout_code_edittext);
        mScanBtn = (ImageButton) view.findViewById(R.id.btn_scan);
        mOrderContainer = (ScrollView) view.findViewById(R.id.order_info_container);
        mPickupByTextView = (TextView) view.findViewById(R.id.checkout_pickup_by);
        mCreditCardNameTextView = (TextView) view.findViewById(R.id.checkout_credit_card_name);
        mCreditCardNumTextView = (TextView) view.findViewById(R.id.checkout_credit_card_num);
        mOrderNumContainer = (LinearLayout) view.findViewById(R.id.checkout_order_id_container);
        mTypeTextView = (TextView) view.findViewById(R.id.checkout_type);
        mClearTextView = (TextView) view.findViewById(R.id.checkout_clear);
        mNextBtn = (Button) view.findViewById(R.id.checkout_next);
    }

    public void onBarcodeScanned(final String barcode) {
        if (StringUtil.isEmpty(barcode)) {
            return;
        }

        if (mCodeEditText == null) {
            return;
        }

        if (mCodeEditText.getHandler() == null) {
            mCodeEditText.setText(barcode);
            orderPickTask(mCodeEditText.getText().toString());
        } else {
            mCodeEditText.post(new Runnable() {
                public void run() {
                    mCodeEditText.setText(barcode);
                    orderPickTask(mCodeEditText.getText().toString());
                }
            });
        }


    }
}
