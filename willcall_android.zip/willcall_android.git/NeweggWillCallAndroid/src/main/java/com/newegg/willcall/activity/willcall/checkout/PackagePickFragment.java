package com.newegg.willcall.activity.willcall.checkout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.activity.base.BaseFragment;
import com.newegg.willcall.activity.willcall.picking.PackagePickingActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.BooleanResponse;
import com.newegg.willcall.entities.checkout.CheckOutPackageInfo;
import com.newegg.willcall.entities.checkout.CheckOutSoInfo;
import com.newegg.willcall.entities.checkout.PickingTaskScanTrackingDTO;
import com.newegg.willcall.entities.checkout.ReferenceOrderPickingTask;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.scan.CaptureActivity;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.newegg.willcall.widget.StepButton;

import java.io.Serializable;
import java.util.List;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class PackagePickFragment extends BaseFragment {
    public static final String ARGUMENT_ORDER_PICKING_TASK = "ARGUMENT_ORDER_PICKING_TASK";

    private BaseActivity mActivity;

    private ListView mOrderListView;
    private ImageButton mScanBtn;
    private EditText mTrackingEditText;

    private OrderListAdapter mAdapter;
    private StepButton mStepBtn;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checkout_frag_package_picking, container, false);

        mActivity = (BaseActivity) getActivity();
        if (isAdded()) {
            if(mActivity instanceof CheckoutActivity) {
                ((CheckoutActivity)mActivity).setStep(2);
            }
        }

        findView(view);

        setScanBtn();
        setInput();
        if (getArguments() != null) {
            ReferenceOrderPickingTask pickingTask = (ReferenceOrderPickingTask) getArguments().getSerializable(ARGUMENT_ORDER_PICKING_TASK);
            bindUI(pickingTask);
        }
        return view;
    }

    private void setScanBtn() {
        mScanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, CaptureActivity.class);
                startActivityForResult(intent, CheckoutActivity.REQUEST_CODE_START_CAPTURE);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == CheckoutActivity.RESULT_OK && requestCode == CheckoutActivity.REQUEST_CODE_START_CAPTURE) {
            if (data != null) {
                String code = data.getStringExtra(CaptureActivity.UPC_CODE_PARA_KEY);
                if (!StringUtil.isEmpty(code)) {
                    mTrackingEditText.setText(code);
                    scanTracking(mTrackingEditText.getText().toString());
                }
            }
        }
    }

    private void setInput() {
        mTrackingEditText.setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(mTrackingEditText.getWindowToken(), 0);
                    if (mTrackingEditText.getText() != null && !StringUtil.isEmpty(mTrackingEditText.getText().toString())) {
                        scanTracking(mTrackingEditText.getText().toString());
                    }
                }
                return false;
            }
        });
    }

    private void scanTracking(String trackingNum) {
        if (!StringUtil.isEmpty(trackingNum)) {
            trackingNum = trackingNum.trim();
        }

        if (StringUtil.isTrackingNUmber(trackingNum)) {
            StringBuilder formatBuilder = new StringBuilder();
            if (trackingNum.toLowerCase().contains("willcall")) {
                formatBuilder.append("WILLCALL");
                formatBuilder.append(trackingNum.toLowerCase().replaceAll("willcall", ""));
            } else {
                formatBuilder.append("WILLCALL");
                formatBuilder.append(trackingNum);
            }

            final String formatTrackingNum = formatBuilder.toString();

            if(mAdapter != null && mAdapter.getPositionByItemTrackingNumber(formatTrackingNum) == -1){
                ToastUtil.show(getActivity(), String.format(getString(R.string.trackingnumber_input_no_this_order), trackingNum), ToastUtil.TOAST_DURATION_LONG);
                return;
            }

            final ProgressDialog progressDialog = getLoadingDialog();
            progressDialog.show();

            PickingTaskScanTrackingDTO scanRequest = new PickingTaskScanTrackingDTO();
            scanRequest.setUserID(WillCallApp.getUser().getUserID() + "");
            scanRequest.setTrackingNumber(formatTrackingNum);

            FastJsonObjectRequest<BooleanResponse> request = new FastJsonObjectRequest<BooleanResponse>(mActivity, BooleanResponse.class, HttpConfig.getFormatUrl(HttpConfig.CHECKOUT_SCAN_TRACKING, formatTrackingNum), scanRequest, new Response.Listener<BooleanResponse>() {
                @Override
                public void onResponse(BooleanResponse result) {
                    if (mActivity == null && !result.isSuccessful()) {
                        return;
                    }
                    progressDialog.dismiss();

                    boolean isSuccess = updateStatus(formatTrackingNum);
                    if (isSuccess) {
                        ToastUtil.show(mActivity, getString(R.string.checkout_scan_package_successfully, formatTrackingNum));
                    } else {
                        ToastUtil.show(mActivity, getString(R.string.checkout_scan_package_not_found));
                        mTrackingEditText.requestFocusFromTouch();
                        mTrackingEditText.selectAll();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    progressDialog.dismiss();
                }
            });

            VolleyUtil.addToRequestQueue(mActivity, request);
        } else {
            if (getActivity() != null)
                ToastUtil.show(getActivity(), String.format(getString(R.string.trackingnumber_input_error), trackingNum), ToastUtil.TOAST_DURATION_LONG);
        }
    }

    private boolean updateStatus(String trackingNum) {
        List<CheckOutSoInfo> sos = mAdapter.getSos();
        if (sos != null) {
            for (CheckOutSoInfo so : sos) {
                if (so != null && so.getPackageList() != null) {
                    List<CheckOutPackageInfo> packages = so.getPackageList();
                    if (packages != null) {
                        for (CheckOutPackageInfo packageInfo : packages) {
                            if (trackingNum.equalsIgnoreCase(packageInfo.getTrackingNumber())) {
                                packageInfo.setIsScaned(CheckOutPackageInfo.IS_SCANED_YES);
                                mAdapter.notifyDataSetChanged();
                                updateStepBtn(getPackageTotalAndScannedCount(sos)[0], getPackageTotalAndScannedCount(sos)[1]);
                                return true;
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    private void showErr(String err) {
//        ToastUtil.show(mActivity, err, ToastUtil.TOAST_DURATION_LONG);
    }

    private void bindUI(final ReferenceOrderPickingTask pickingTask) {
        List<CheckOutSoInfo> sos = pickingTask.getSoList();
        if (sos != null) {
            mOrderListView.setFooterDividersEnabled(true);
            int[] totalAndScannedCount = getPackageTotalAndScannedCount(pickingTask.getSoList());
            mOrderListView.addFooterView(getFooterView(pickingTask, totalAndScannedCount[0]));
            mAdapter = new OrderListAdapter(mActivity, pickingTask, true);
            mOrderListView.setAdapter(mAdapter);
            updateStepBtn(totalAndScannedCount[0], totalAndScannedCount[1]);
            mStepBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    StepButton stepBtn = (StepButton) v;
                    if (stepBtn.getCurrentSteps() == stepBtn.getTotalSteps()) {
                        goConfirmPage(pickingTask);
                    }
                }
            });
        }
    }

    private void goConfirmPage(ReferenceOrderPickingTask pickingTask) {

        if(mActivity instanceof CheckoutActivity) {
            ItemConfirmationFragment fragment = ItemConfirmationFragment.createItemConfirmationFragment(pickingTask);
            ((CheckoutActivity)(mActivity)).switchContent(fragment, true);
        }
        else {
            Intent intent = new Intent(mActivity,CheckoutActivity.class);
            intent.putExtra(CheckoutActivity.INTENT_ORDER_PICKING_TASK,pickingTask);
            mActivity.startActivity(intent);
            mActivity.overridePendingTransition(R.anim.anim_up_in,R.anim.anim_up_out);
            mActivity.finish();
        }
    }


    private void updateStepBtn(int totalSteps, int scannedSteps) {
        mStepBtn.setTotalSteps(totalSteps);
        mStepBtn.setCurrentStep(scannedSteps);
        mStepBtn.invalidate();
    }

    private View getFooterView(ReferenceOrderPickingTask pickingTask, int totalPackageCount) {
        View footerView = LayoutInflater.from(mActivity).inflate(R.layout.checkout_package_footer, null);
        TextView totalCountTextView = (TextView) footerView.findViewById(R.id.checkout_footer_total_count);
        totalCountTextView.setText(totalPackageCount + " " + getString(R.string.checkout_packages));
        return footerView;
    }

    private int[] getPackageTotalAndScannedCount(List<CheckOutSoInfo> sos) {
        int count = 0;
        int scannedCount = 0;
        if (sos != null) {
            for (CheckOutSoInfo so : sos) {
                if (so != null && so.getPackageList() != null) {
                    List<CheckOutPackageInfo> packages = so.getPackageList();
                    if (packages != null) {
                        count += packages.size();
                        for (CheckOutPackageInfo packageInfo : packages) {
                            if (CheckOutPackageInfo.IS_SCANED_YES.equals(packageInfo.getIsScaned())) {
                                scannedCount++;
                            }
                        }
                    }
                }
            }
        }

        return new int[]{count, scannedCount};
    }

    private void findView(View view) {
        mTrackingEditText = (EditText) view.findViewById(R.id.checkout_tracking_edittext);
        mScanBtn = (ImageButton) view.findViewById(R.id.btn_scan);
        mOrderListView = (ListView) view.findViewById(R.id.checkout_package_list);
        mStepBtn = (StepButton) view.findViewById(R.id.checkout_picking_btn);
    }

    private ProgressDialog getLoadingDialog() {
        ProgressDialog progressDialog = new ProgressDialog(mActivity);
        progressDialog.setProgressStyle(R.style.ProgressBarWillCallIndeterminate_White);
        progressDialog.setMessage("Loading");
        return progressDialog;
    }

    public static PackagePickFragment createPackagePickFragment(Serializable task){
        PackagePickFragment pickFragment = new PackagePickFragment();
        if(task!=null) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(PackagePickFragment.ARGUMENT_ORDER_PICKING_TASK, task);
            pickFragment.setArguments(bundle);
        }
        return pickFragment;
    }


    public void onBarcodeScanned(final String barcode){

        if (StringUtil.isEmpty(barcode)) {
            return;
        }

        if (mTrackingEditText == null) {
            return;
        }

        if (mTrackingEditText.getHandler() == null) {
            mTrackingEditText.setText(barcode);
            scanTracking(mTrackingEditText.getText().toString());
        } else {
            mTrackingEditText.post(new Runnable() {
                public void run() {
                    mTrackingEditText.setText(barcode);
                    scanTracking(mTrackingEditText.getText().toString());
                }
            });
        }
    }
}
