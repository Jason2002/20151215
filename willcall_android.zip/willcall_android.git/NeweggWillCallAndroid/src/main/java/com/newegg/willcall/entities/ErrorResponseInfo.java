package com.newegg.willcall.entities;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-9.
 */
public class ErrorResponseInfo {

    @JSONField(name = "ResponseCode")
    private String mResponseCode;
    @JSONField(name = "Message")
    private String mMessage;
    @JSONField(name = "StatusCode")
    private String mStatusCode;
    @JSONField(name = "StackTrace")
    private String mStackTrace;

    public String getResponseCode() {
        return mResponseCode;
    }

    public void setResponseCode(String responseCode) {
        mResponseCode = responseCode;
    }

    public String getMessage() {
        return mMessage;
    }

    public void setMessage(String message) {
        mMessage = message;
    }

    public String getStatusCode() {
        return mStatusCode;
    }

    public void setStatusCode(String statusCode) {
        mStatusCode = statusCode;
    }

    public String getStackTrace() {
        return mStackTrace;
    }

    public void setStackTrace(String mStackTrace) {
        this.mStackTrace = mStackTrace;
    }
}
