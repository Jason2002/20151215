package com.newegg.willcall.event;

/**
 * Created by dy45 on 4/14/2015.
 */
public interface OnFunListener3<T1,T2,T3,R> {
    R fun(T1 t1,T2 t2,T3 t3);
}
