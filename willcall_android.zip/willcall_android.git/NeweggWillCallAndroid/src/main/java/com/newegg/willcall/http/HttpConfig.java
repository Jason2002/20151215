package com.newegg.willcall.http;

import com.newegg.willcall.BuildConfig;

import java.net.URLEncoder;

/**
 * Created by JaredLuo on 4/2/14.
 */
public class HttpConfig {



    public static String HOST = "";
    public static String HOST_RMA = "";
    public static String HOST_IR = "";
    public static String HOST_DFIS_UPLOAD = "";
    public static String HOST_DFIS_DOWNLOAD = "";

    static {
        switch (ConfigUtil.ServiceType) {
            case Local:
                HOST = "http://10.1.24.145:8083/WCC/";
                HOST_IR = "http://10.1.24.145:8084/";
                HOST_DFIS_UPLOAD = "http://10.1.24.160:8021";
                HOST_DFIS_DOWNLOAD = "http://10.1.24.160:8001/";
                HOST_RMA = "http://10.1.24.130:3000/ozzo/central/v1/";
                break;
            case Pre:
                HOST = "https://apis.newegg.com/AndroidWCC/V1/";
                HOST_IR = "http://apitest.newegg.org/WMS/V2/";
                HOST_DFIS_UPLOAD = "http://neg-app-dfis:8200";
                HOST_DFIS_DOWNLOAD = "http://neg-app-img/";
                HOST_RMA = "http://apitest.newegg.org/ozzo/central/v1/";
                break;
            case Prd:
                HOST = "https://apis.newegg.com/AndroidWCC/V1/";
                HOST_IR = "https://apis.newegg.com/WMS/V2/";
                HOST_DFIS_UPLOAD = "http://neg-app-dfis:8200";
                HOST_DFIS_DOWNLOAD = "http://images10.newegg.com/";
                HOST_RMA = "https://apis.newegg.com/ozzo/central/v1/";
                break;
        }

    }

    //WillCall's URLs
    public static final String VERSION_INFO = HOST + "VersionInfo";
    public static final String LOGIN = HOST + "Login";
    public static final String LOGOUT = HOST + "LogOut";

    public static final String PACKAGE_MOVEIN_GET_LOCATION=HOST+"Locations/Verification"+"?Location=%1$s";
    public static final String PACKAGE_MOVEIN_SCAN_TRACKING=HOST+"Packages"+"/%1$s/MoveIn";
    public static final String PACKAGE_RECEIVING_GET_SCANED = HOST + "UnReceivedPackages" + "?userID=%1$s&WCCNumber=%2$s";
    public static final String PACKAGE_RECEIVING_SCAN_TRACKING = HOST + "UnReceivedPackage" + "/%1$s/ScanTrackingNumber";
    public static final String PACKAGE_RECEIVING_TRACKING_RECEIVING = HOST + "UnReceivedPackages" + "/%1$s/Receive";
    public static final String PACKAGE_PICKING_GET_EXPIRED = HOST + "ExpiredTrackings" + "?WCCNumber=%1$s";
    public static final String PACKAGE_PICKING_SCAN_PACKAGE = HOST + "ExpiredTracking" + "/%1$s/ScanTrackingNumber";
    public static final String PACKAGE_DEPARTURE_GET_LIST = HOST + "DepartureTrackings" + "?WCCNumber=%1$s&userID=%2$s";
    public static final String PACKAGE_DEPARTURE_SCAN_TRACKING = HOST + "DepartureTracking/%1$s/ScanTrackingNumber";
    public static final String PACKAGE_DEPARTURE_PACKAGE_DEPARTURE = HOST + "DepartureTrackings/%1$s/DeparturePackages";
    public static final String PACKAGE_DEPARTURE_DELETE_UNDEPARTURE_PACKAGES = HOST + "DepartureTrackings/%1$s/DeletePackages";
    public static final String CHECKOUT_ORDER_PICKING_TASK = HOST + "OrderPickingTask";
    public static final String CHECKOUT_SCAN_TRACKING = HOST + "OrderPickingTask/%1$s/ScanTrackingNumber";
    public static final String CHECKOUT_CONFIRM_CHECKOUT = HOST + "OrderPickingTask/%1$s/ConfirmCheckOut";
    public static final String PACKAGE_PICKAGE_TASK_LIST=HOST+"Packages/PickingTasks";

    //TODO:POS's URLs
    public static final String POS_CART_GET_ITEM_INFO = HOST_IR + "POS/ItemInfoList?barcode=%1$s";
    public static final String POS_CART_GET_GIFT_CARD = HOST_RMA + "pos/giftcard/%1$s?secureCode=%2$s";
    public static final String POS_CART_CREATE_SO = HOST_RMA + "pos/sales/%1$s";
    public static final String POS_UPLOAD_IMAGE_ID = HOST_RMA + "pos/sales/%1$s/Image/%2$s";
         //"http://127.0.0.1:11109/pos/sales/%1$s/Image/%2$s";
    public static final String POS_ADD_CUSTOM_EMAIL = HOST_RMA + "pos/sales/%1$s/CustomerEmail";
    public static final String POS_UPLOAD_PDF = HOST_RMA + "POS/File";
    public static final String POS_GET_PDF = HOST_DFIS_DOWNLOAD + "POS/Invoice/%1$s";

    public static final String POS_RETURN_CREATE = HOST_RMA + "pos/return/%1$s";
    public static final String POS_RETURN_AVAILABLE_RETURN = HOST_RMA + "pos/sales/%1$s/availableReturn";

    public static final String POS_SUMMARY_SALES = HOST_RMA + "pos/sales/summary?warehouseNumber=%1$s&fromDate=%2$s&toDate=%3$s";
    public static final String POS_SUMMARY_INVENTORY = HOST_IR + "pos/inventoryList";
    public static final String POS_SUMMARY_ORDER_DETAIL = HOST_RMA + "pos/sales/%1$s/detail";


    public static String getFormatUrl(String format, String... strings) {
        int count = strings == null ? 0 : strings.length;
        Object[] params = new Object[count];
        for (int i = 0; i < count; i++) {
            params[i] = URLEncoder.encode(strings[i]);
        }

        return String.format(format, params);
    }

}
