package com.newegg.willcall.utils;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import static javax.crypto.Cipher.getInstance;

/**
 * Created by JaredLuo on 14-4-16.
 */
public class EncryptUtil {

    public static String RSA_PUBLIC_KEY_MODULUS = "p281cUoX+9mZfp0dMtHauykJPZrIBtnNOGSN0J7O6d4o01uvRC1xVqoTA9S5RP/aodbtzJep1vypYjEFpyjy5+Ic+F2r9dP1fJeIlxbp+oS9kHWMEECqYbZBxBkXX1VwC6STH18iIt3euJR2hxOQnruxPWFUbth6TsbvJUecCis=";

    public static String RSA_PUBLIC_KEY_EXPONENT = "AQAB";

    private static final int MAX_ENCRYPT_BLOCK = 117;

    private static byte[] getKey(Context context) throws UnsupportedEncodingException {
        StringBuilder keySb = new StringBuilder("NWC");
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceId = tm.getDeviceId();
        if (!StringUtil.isEmpty(deviceId)) {
            keySb.append(deviceId);
        }

        byte[] bytes = keySb.toString().getBytes("UTF-8");
        byte[] byte32 = new byte[32];
        for (int i = 0; i < byte32.length; i++) {
            if (i < bytes.length) {
                byte32[i] = bytes[i];
            } else {
                byte32[i] = 0;
            }
        }
        return byte32;
    }

    public static byte[] encryptPwd(Context context, String pwd) throws Exception {
        if (StringUtil.isEmpty(pwd)) {
            return null;
        }

        byte[] key = getKey(context);
        byte[] encrypted = encrypt(key, pwd.getBytes("UTF-8"));

        return encrypted;

    }

    public static String decryptPwd(Context context, byte[] encrypted) throws Exception {
        if (encrypted == null || encrypted.length == 0) {
            return null;
        }

        byte[] key = getKey(context);
        byte[] decrypted = decrypt(key, encrypted);

        return new String(decrypted, "UTF-8");
    }

    private static byte[] encrypt(byte[] raw, byte[] clear) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(clear);
        return encrypted;
    }

    private static byte[] decrypt(byte[] raw, byte[] encrypted) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] decrypted = cipher.doFinal(encrypted);
        return decrypted;
    }

    public static String rsaEncrypt(final String plain) {

        try {

            byte[] modulusBytes = Base64.decode(RSA_PUBLIC_KEY_MODULUS, Base64.DEFAULT);
            byte[] exponentBytes = Base64.decode(RSA_PUBLIC_KEY_EXPONENT, Base64.DEFAULT);

            BigInteger modulus = new BigInteger(1, modulusBytes);
            BigInteger exponent = new BigInteger(1, exponentBytes);

            RSAPublicKeySpec publicKeySpec = new RSAPublicKeySpec(modulus, exponent);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            RSAPublicKey publicKey = (RSAPublicKey) keyFactory.generatePublic(publicKeySpec);

            Cipher cipher = getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);

            byte[] data = plain.getBytes("UTF-16LE");

            int inputLen = data.length;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int offSet = 0;
            byte[] cache;
            int i = 0;
            // 对数据分段加密
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                    cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
                } else {
                    cache = cipher.doFinal(data, offSet, inputLen - offSet);
                }
                out.write(cache, 0, cache.length);
                i++;
                offSet = i * MAX_ENCRYPT_BLOCK;
            }
            byte[] encryptedData = out.toByteArray();
            out.close();

            String result = Base64.encodeToString(encryptedData, 0, encryptedData.length, Base64.NO_WRAP);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String sha256(String text) {

        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
            md.update(text.getBytes("UTF-16LE"));
            byte[] digest = md.digest();

            return Base64.encodeToString(digest, Base64.DEFAULT);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return "";
        }
    }
}
