package com.newegg.willcall.entities.departure;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created by lenayan on 14-4-11.
 */
public class SetPackageAsExpiredDTO {

    @JSONField(name = "WCCNumber")
    private String mWCCNumber;
    @JSONField(name = "UserID")
    private String mUserID;

    public SetPackageAsExpiredDTO(String WCCNumber, String userID) {
        mWCCNumber = WCCNumber;
        mUserID = userID;
    }

    public String getWCCNumber() {
        return mWCCNumber;
    }

    public void setWCCNumber(String WCCNumber) {
        mWCCNumber = WCCNumber;
    }

    public String getUserID() {
        return mUserID;
    }

    public void setUserID(String userID) {
        mUserID = userID;
    }
}
