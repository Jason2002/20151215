package com.newegg.willcall.http;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.widget.ImageView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;
import com.newegg.willcall.utils.StringUtil;

/**
 * Created by JaredLuo on 4/2/14.
 */
public class VolleyUtil {

    private static RequestQueue mRequestQueue;
    private static ImageLoader mImageLoader;

    public static RequestQueue getRequestQueue(Context context) {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(context);
        }

        return mRequestQueue;
    }

    public static ImageLoader getImageLoader(Context context) {

        mImageLoader = new ImageLoader(getRequestQueue(context), new ImageLoader.ImageCache() {
            private final LruCache<String, Bitmap> mCache = new LruCache<String, Bitmap>(10);

            public void putBitmap(String url, Bitmap bitmap) {
                mCache.put(url, bitmap);
            }

            public Bitmap getBitmap(String url) {
                return mCache.get(url);
            }
        });

        return mImageLoader;
    }

    public static void loadImage(Context context, String url, ImageView imageView) {
        mImageLoader = getImageLoader(context);
        mImageLoader.get(url, ImageLoader.getImageListener(imageView, 0, 0));
    }

    public static <T> Request addToRequestQueue(Context context, Request<T> req, String tag) {
        // set the default tag if tag is empty
        req.setTag(StringUtil.isEmpty(tag) ? context.getClass().getName() : tag);

        VolleyLog.d("Adding request to queue: %s", req.getUrl());

        return getRequestQueue(context).add(req);
    }


    public static <T> Request addToRequestQueue(Context context, Request<T> req) {
        req.setTag(context.getClass().getName());
        return getRequestQueue(context).add(req);
    }


    public static void cancelPendingRequests(Context context) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(context.getClass().getName());
            mRequestQueue.cancelAll(new RequestQueue.RequestFilter() {
                @Override
                public boolean apply(Request<?> request) {
                    return false;
                }
            });
        }
    }

    public static void cancelAllPandingRequest() {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(new RequestQueue.RequestFilter() {
                @Override
                public boolean apply(Request<?> request) {
                    return true;
                }
            });
        }
    }

    public static void cancelPendingRequest(String tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }
}
