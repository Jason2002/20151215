package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by flyerabc on 14/12/24.
 */
public class SalesSummaryDTO implements Serializable {
    @JSONField(name = "Summary")
    private SalesSummayTotalInfo summary;

    @JSONField(name = "SOList")
    private List<SalesOrderDetailInfo> soList;

    public SalesSummayTotalInfo getSummary() {
        return summary;
    }

    public void setSummary(SalesSummayTotalInfo summary) {
        this.summary = summary;
    }

    public List<SalesOrderDetailInfo> getSOList() {
        return soList;
    }

    public void setSOList(List<SalesOrderDetailInfo> soList) {
        this.soList = soList;
    }
}


