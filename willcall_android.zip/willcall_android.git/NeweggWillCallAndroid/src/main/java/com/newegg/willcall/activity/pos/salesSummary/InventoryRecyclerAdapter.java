package com.newegg.willcall.activity.pos.salesSummary;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.pos.salesSummary.ItemInventoryResDTO;

import java.util.List;

public class InventoryRecyclerAdapter extends RecyclerView.Adapter<InventoryRecyclerAdapter.ViewHolder>{
    private List<ItemInventoryResDTO> mList;

    public InventoryRecyclerAdapter(List<ItemInventoryResDTO> list){
        mList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pos_sales_summary_inventory_cell, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemInventoryResDTO item = mList.get(position);
        holder.itemDescTextView.setText(String.valueOf(item.getItemDescription()));
        holder.skuTextView.setText(String.valueOf(item.getSku()));
        holder.soldQtyTextView.setText(String.valueOf(item.getSoldQty()));
        holder.inventoryTextView.setText(String.valueOf(item.getInventory()));
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemDescTextView;
        public TextView skuTextView;
        public TextView soldQtyTextView;
        public TextView inventoryTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            itemDescTextView = (TextView) itemView.findViewById(R.id.item_desc_textView);
            skuTextView = (TextView) itemView.findViewById(R.id.sku_textView);
            soldQtyTextView = (TextView) itemView.findViewById(R.id.sold_qty_textView);
            inventoryTextView = (TextView) itemView.findViewById(R.id.inventory_textView);
        }
    }
}
