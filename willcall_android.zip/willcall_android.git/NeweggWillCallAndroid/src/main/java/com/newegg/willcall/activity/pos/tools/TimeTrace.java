package com.newegg.willcall.activity.pos.tools;

import android.text.format.DateUtils;

import com.newegg.willcall.cache.POSTraceCache;

import java.util.Date;

/**
 * Created by dy45 on 5/29/2015.
 */
public class TimeTrace {
    private String tag;
    private long startDate;

    public TimeTrace(String tag){
        this.tag = tag;
    }

    public void start(String msg){
        POSTraceCache.add("start "+tag+" " + msg);
        startDate =  System.currentTimeMillis();
    }

    public void end(String msg){
        long endDate =  System.currentTimeMillis();
        POSTraceCache.add("end "+tag+" Time:"+String.valueOf(endDate-startDate)+"ms"+"  "+ msg);
    }

}
