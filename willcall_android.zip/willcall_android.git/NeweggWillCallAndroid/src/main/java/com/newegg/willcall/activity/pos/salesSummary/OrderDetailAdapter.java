package com.newegg.willcall.activity.pos.salesSummary;

import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.pos.salesSummary.POSOrderDetail;
import com.newegg.willcall.entities.pos.salesSummary.POSOrderItem;
import com.newegg.willcall.utils.CurrencyUtils;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by jaredluo on 12/19/14.
 */

public class OrderDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static int ITEM_TYPE_NORMAL = 0;
    private static int ITEM_TYPE_FOOTER = 1;

    private POSOrderDetail mOrderDetail;

    public OrderDetailAdapter(POSOrderDetail orderDetail) {
        this.mOrderDetail = orderDetail;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());


        if (viewType == ITEM_TYPE_NORMAL) {
            View cellView = inflater.inflate(R.layout.pos_order_detail_cell, parent, false);
            ViewHolder holder = new ViewHolder(cellView);
            holder.titleTv = (TextView) cellView.findViewById(R.id.order_detail_cell_title);
            holder.snTv = (TextView) cellView.findViewById(R.id.order_detail_cell_sn);
            holder.priceTv = (TextView) cellView.findViewById(R.id.order_detail_cell_price);
            holder.qtyTv = (TextView) cellView.findViewById(R.id.order_detail_cell_qty);
            holder.divider = cellView.findViewById(R.id.order_detail_cell_divider);
            return holder;
        } else {
            View footerView = inflater.inflate(R.layout.pos_order_detail_footer, parent, false);
            ViewFooterHolder holder = new ViewFooterHolder(footerView);
            holder.subtotalTv = (TextView) footerView.findViewById(R.id.order_detail_footer_subtotal);
            holder.ewraTv = (TextView) footerView.findViewById(R.id.order_detail_footer_ewra);
            holder.taxTv = (TextView) footerView.findViewById(R.id.order_detail_footer_tax);
            holder.discountTv = (TextView) footerView.findViewById(R.id.order_detail_footer_discount);
            holder.giftCardTv = (TextView) footerView.findViewById(R.id.order_detail_footer_gift_card);
            holder.grandTotalTv = (TextView) footerView.findViewById(R.id.order_detail_footer_grand_total);

            holder.ewraLayout =  footerView.findViewById(R.id.order_detail_footer_ewra_layout);
            holder.dicountLayout =  footerView.findViewById(R.id.order_detail_footer_discount_layout);
            holder.giftCardLayout =  footerView.findViewById(R.id.order_detail_footer_gift_card_layout);

            return holder;
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {

            List<POSOrderItem> items = mOrderDetail.getItemList();
            POSOrderItem item = items.get(position);

            ViewHolder viewHolder = (ViewHolder) holder;
            viewHolder.titleTv.setText(item.getDescription());

            String snText = "";
            for(int i=0;i<item.getItemSNList().size();i++){
                snText += "Serial Number: " + item.getItemSNList().get(i).getSerialNumber();
                if(i != item.getItemSNList().size()-1){
                    snText += "\r\n";
                }
            }
            viewHolder.snTv.setText(snText);

            viewHolder.qtyTv.setText(item.getQuantity() + "");
            SpannableStringBuilder ssb = new SpannableStringBuilder(CurrencyUtils.getCurrencyFormat(item.getUnitPrice().multiply(new BigDecimal("" + item.getQuantity()))));
            ssb.setSpan(new RelativeSizeSpan(0.5f), ssb.length() - 3, ssb.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            viewHolder.priceTv.setText(ssb);

            if (position == getItemCount() - 2) {
                viewHolder.divider.setVisibility(View.INVISIBLE);
            } else {
                viewHolder.divider.setVisibility(View.VISIBLE);
            }

        } else {
            ViewFooterHolder viewHolder = (ViewFooterHolder) holder;
            viewHolder.subtotalTv.setText(CurrencyUtils.getCurrencyFormat(mOrderDetail.getSubtotalAmount()));
            viewHolder.ewraTv.setText(CurrencyUtils.getCurrencyFormat(mOrderDetail.getEwraAmount()));
            viewHolder.taxTv.setText(CurrencyUtils.getCurrencyFormat(mOrderDetail.getTaxAmount()));
            viewHolder.discountTv.setText(CurrencyUtils.getCurrencyFormat(mOrderDetail.getDiscountAmount()));
            viewHolder.giftCardTv.setText(CurrencyUtils.getCurrencyFormat(mOrderDetail.getGiftCardAmount().negate()));
            viewHolder.grandTotalTv.setText(CurrencyUtils.getCurrencyFormat(mOrderDetail.getSoAmount()));

            if(mOrderDetail.getEwraAmount().signum() == 0){
                viewHolder.ewraLayout.setVisibility(View.GONE);
            }else{
                viewHolder.ewraLayout.setVisibility(View.VISIBLE);
            }

            if(mOrderDetail.getDiscountAmount().signum() == 0){
                viewHolder.dicountLayout.setVisibility(View.GONE);
            }else{
                viewHolder.dicountLayout.setVisibility(View.VISIBLE);
            }

            if(mOrderDetail.getGiftCardAmount().signum() == 0){
                viewHolder.giftCardLayout.setVisibility(View.GONE);
            }else{
                viewHolder.giftCardLayout.setVisibility(View.VISIBLE);
            }

        }
    }

    @Override
    public int getItemCount() {
        return mOrderDetail.getItemList().size() + 1;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView titleTv;
        public TextView snTv;
        public TextView priceTv;
        public TextView qtyTv;
        public View divider;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public static class ViewFooterHolder extends RecyclerView.ViewHolder {
        public TextView subtotalTv;
        public TextView ewraTv;
        public TextView taxTv;
        public TextView discountTv;
        public TextView giftCardTv;
        public TextView grandTotalTv;
        public View ewraLayout;
        public View dicountLayout;
        public View giftCardLayout;

        public ViewFooterHolder(View itemView) {
            super(itemView);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (position == getItemCount() - 1) {
            return ITEM_TYPE_FOOTER;
        }
        return ITEM_TYPE_NORMAL;
    }
}
