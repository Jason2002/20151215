package com.newegg.willcall.activity.pos.order;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.view.ActionMode;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.app.WillCallApp;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.order.CartInfo;
import com.newegg.willcall.entities.pos.order.GiftCardRes;
import com.newegg.willcall.entities.pos.order.ItemInfoResDTO;
import com.newegg.willcall.entities.pos.order.ItemResult;
import com.newegg.willcall.http.BaseRequest;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.LogUtil;
import com.newegg.willcall.utils.StringUtil;
import com.newegg.willcall.utils.ToastUtil;
import com.newegg.willcall.widget.ManualInputActionView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by jaredluo on 12/19/14.
 */
public class POSCartActivity extends BaseActivity implements CartAdapter.OnEditSubTotal {

    public static final int REQUEST_CODE_FOR_DISCOUNT = 0x01;
    public static final int REQUEST_CODE_FOR_GIFT_CARD = 0x02;

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private CartAdapter mAdapter;

    private ActionMode.Callback mActionCallBack;

    private LinearLayout mContainer;

    private Button mClearAllBtn;
    private Button mCheckoutBtn;
    private TextView mEmpty;

    private Boolean isDeleteMode = false;

    private CartInfo mCartInfo;
    private ActionMode mActionMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poscart);

        setRecyclerView();
        findViews();
    }

    private void findViews() {
        mClearAllBtn = (Button) findViewById(R.id.poscart_clear_all);
        mCheckoutBtn = (Button) findViewById(R.id.poscart_checkout);

        mContainer = (LinearLayout) findViewById(R.id.poscart_container);
        mEmpty = (TextView) findViewById(R.id.poscart_empty);

        mCheckoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkout(mCartInfo);
            }
        });

        mClearAllBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearAll();
            }
        });
    }

    private void clearAll() {
        mContainer.setVisibility(View.GONE);
        mEmpty.setVisibility(View.VISIBLE);

        mCartInfo.getItems().clear();
        mCartInfo.getRawItems().clear();
        mCartInfo.getGiftCards().clear();

        mAdapter.notifyDataSetChanged();
    }

    private void checkout(CartInfo cartInfo) {
        Intent intent;
        if (cartInfo.getGrandTotal().doubleValue() <= 0) {
            intent = new Intent(POSCartActivity.this, POSSignActivity.class);
            intent.putExtra(POSCheckoutActivity.PARAM_CART_INFO_INFO, cartInfo);
        } else {
            intent = new Intent(POSCartActivity.this, POSCheckoutActivity.class);
            intent.putExtra(POSCheckoutActivity.PARAM_CART_INFO_INFO, cartInfo);
        }

        startActivity(intent);
    }

    private void setRecyclerView() {
        mRecyclerView = (RecyclerView) findViewById(R.id.poscart_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);


        mCartInfo = new CartInfo();
        mCartInfo.setTaxRate(WillCallApp.getWarehouse().getTaxRate());
        mAdapter = new CartAdapter(mCartInfo);
        mAdapter.setOnEditSubTotal(this);
        mRecyclerView.setAdapter(mAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_poscart, menu);

        final MenuItem itemInput = menu.findItem(R.id.manual_input);
        final MenuItem itemDelete = menu.findItem(R.id.scan_to_delete);

        ManualInputActionView inputAction = (ManualInputActionView) itemInput.getActionView();
        inputAction.setOnManualInputListener(new ManualInputActionView.OnManualInputListener() {
            @Override
            public void onApply(String input) {
                itemInput.collapseActionView();
                if (!StringUtil.isEmpty(input)) {
                    scanToAdd(input);
                } else {
                    ToastUtil.show(POSCartActivity.this, getString(R.string.invalid_barcode));
                }
            }
        });

        itemInput.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                itemDelete.setVisible(false);
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                itemDelete.setVisible(true);
                return true;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.scan_to_delete) {

            mActionCallBack = createActionMode();
            mActionMode = startSupportActionMode(mActionCallBack);

            isDeleteMode = true;
        }
        return super.onOptionsItemSelected(item);
    }

    private ActionMode.Callback createActionMode() {
        return new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                mode.setTitle(getString(R.string.scan_to_delete_note));
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {

                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                isDeleteMode = false;
            }
        };
    }

    @Override
    public void onEditDiscount() {
        Intent intent = new Intent(this, POSDiscountActivity.class);
        intent.putExtra(POSDiscountActivity.PARAM_CART_INFO, mCartInfo);
        startActivityForResult(intent, REQUEST_CODE_FOR_DISCOUNT);
    }

    @Override
    public void onEditGiftCard() {
        Intent intent = new Intent(this, POSGiftCardActivity.class);
        ArrayList<GiftCardRes> cards = mCartInfo.getGiftCards();
        if (cards != null && cards.size() > 0) {
            intent.putExtra(POSGiftCardActivity.PARAM_GIFT_CARD_INFO, cards);
        }
        intent.putExtra(POSGiftCardActivity.PARAM_GRAND_TOTAL_WITHOUT_GC, mCartInfo.getGrandTotalWithoutGC().doubleValue());
        startActivityForResult(intent, REQUEST_CODE_FOR_GIFT_CARD);
    }


    @Override
    public void onBarcodeScanned(final String barcode) {
        super.onBarcodeScanned(barcode);

        if (StringUtil.isEmpty(barcode)) {
            return;
        }

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isDeleteMode) {
                    scanToDelete(barcode);
                } else {
                    scanToAdd(barcode);
                }
            }
        });
    }

    private void scanToDelete(String barcode) {
        if (!StringUtil.isEmpty(barcode)) {
            Iterator<ItemInfoResDTO> iterator = mCartInfo.getRawItems().iterator();
            while (iterator.hasNext()) {
                ItemInfoResDTO rawItem = iterator.next();
                if (rawItem != null && barcode.equalsIgnoreCase(rawItem.getBarcodeValue())) {
                    mCartInfo.removeRawItems(rawItem);
                    mCartInfo.needReduceGiftCard();
                    if (mCartInfo.getRawItems().size() == 0) {
                        clearAll();
                        if (mActionMode != null) {
                            mActionMode.finish();
                        }
                    } else {
                        mAdapter.notifyDataSetChanged();
                    }
                    ToastUtil.show(this, getString(R.string.delete_item_successfully));
                    return;
                }
            }

            ToastUtil.show(this, getString(R.string.scan_error_hint));
        } else {
            ToastUtil.show(this, getString(R.string.invalid_barcode));
        }

    }

    private void scanToAdd(String barcode) {
        if (!StringUtil.isEmpty(barcode)) {
            requestItem(barcode);
        } else {
            ToastUtil.show(this, getString(R.string.invalid_barcode));
        }
    }

    private void requestItem(String barcode) {
        showProgressDialog();
        FastJsonObjectRequest<ItemResult> request = new FastJsonObjectRequest<ItemResult>(this, ItemResult.class, HttpConfig.getFormatUrl(HttpConfig.POS_CART_GET_ITEM_INFO, barcode), new Response.Listener<ItemResult>() {
            @Override
            public void onResponse(ItemResult itemResult) {
                hideProgressDialog();
                if (itemResult == null || itemResult.getItemList() == null || itemResult.getItemList().size() == 0) {
                    ToastUtil.show(POSCartActivity.this, getString(R.string.invalid_barcode));
                    return;
                }

                ItemInfoResDTO item = itemResult.getItemList().get(0);

                List<ItemInfoResDTO> rawItems = mCartInfo.getRawItems();
                if (ItemInfoResDTO.BARCODE_TYPE_SN.equalsIgnoreCase(item.getBarcodeType())) {
                    for (ItemInfoResDTO rawItem : rawItems) {
                        if (rawItem.getBarcodeValue().equalsIgnoreCase(item.getBarcodeValue())) {
                            ToastUtil.show(POSCartActivity.this, getString(R.string.exist_sn));
                            return;
                        }
                    }
                }
                mCartInfo.addRawItems(item);
                if (mCartInfo.getRawItems().size() == 1) {
                    mEmpty.setVisibility(View.GONE);
                    mContainer.setVisibility(View.VISIBLE);
                }


                mAdapter.notifyDataSetChanged();

            }
        }, new BaseRequest.OnErrorListener() {
            @Override
            public void onError(ErrorResponseInfo info) {
                ToastUtil.show(POSCartActivity.this, info.getMessage());
                hideProgressDialog();
            }
        });

        VolleyUtil.addToRequestQueue(this, request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }
        if (requestCode == REQUEST_CODE_FOR_DISCOUNT) {
            if (data != null && data.getSerializableExtra(POSDiscountActivity.PARAM_CART_INFO) != null) {
                CartInfo info = (CartInfo) data.getSerializableExtra(POSDiscountActivity.PARAM_CART_INFO);
                mCartInfo.setRawItems(info.getRawItems());
                mCartInfo.setGiftCards(info.getGiftCards());
                mAdapter.notifyDataSetChanged();
            }
        } else if (requestCode == REQUEST_CODE_FOR_GIFT_CARD) {
            if (data != null && data.getSerializableExtra(POSGiftCardActivity.PARAM_GIFT_CARD_INFO) != null) {
                ArrayList<GiftCardRes> cards = (ArrayList<GiftCardRes>) data.getSerializableExtra(POSGiftCardActivity.PARAM_GIFT_CARD_INFO);
                mCartInfo.setGiftCards(cards);
                mAdapter.notifyDataSetChanged();
            }

        }
    }
}
