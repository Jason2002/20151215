package com.newegg.willcall.activity.pos.salesSummary;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseActivity;
import com.newegg.willcall.widget.ManualInputActionView;
import com.viewpagerindicator.TabPageIndicator;


public class SalesSummaryActivity extends BaseActivity {

    private SalesSummaryFragmentPagerAdapter mPagerAdapter;
    private ViewPager mViewPager;
    private TabPageIndicator mPageIndicator;
    private ManualInputActionView mInputAction;

    public interface OnSearchListener {
        public void doSearch(String input);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_summary);

        mPagerAdapter = new SalesSummaryFragmentPagerAdapter(getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.viewPager);
        mViewPager.setAdapter(mPagerAdapter);

        mPageIndicator = (TabPageIndicator)findViewById(R.id.titles);
        mPageIndicator.setViewPager(mViewPager);
        mPageIndicator.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener(){

            @Override
            public void onPageSelected(int position) {
                setHint(mInputAction, position);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_sales_summary, menu);

        final MenuItem item = menu.findItem(R.id.action_search);
        mInputAction = (ManualInputActionView)item.getActionView();
        mInputAction.setOnManualInputListener(new ManualInputActionView.OnManualInputListener() {
            @Override
            public void onApply(String input) {
                item.collapseActionView();

                if (!input.equalsIgnoreCase("")) {
                    android.support.v4.app.Fragment currentFrag = mPagerAdapter.getItem(mViewPager.getCurrentItem());
                    ((OnSearchListener) currentFrag).doSearch(input);
                }
            }
        });
        setHint(mInputAction, mViewPager.getCurrentItem());
        return true;
    }

    private void setHint(ManualInputActionView inputAction, int position) {
        if(inputAction == null)
            return;

        if(position == 0){
            inputAction.setHint(getString(R.string.salesSummary_order_number_hit));
            inputAction.setInputType(InputType.TYPE_CLASS_NUMBER);
        }else{
            inputAction.setHint(getString(R.string.salesSummary_item_number_hint));
            inputAction.setInputType(InputType.TYPE_CLASS_TEXT);
        }
    }

    class SalesSummaryFragmentPagerAdapter extends FragmentPagerAdapter {

        private android.support.v4.app.Fragment frag1 = SalesFragment.newInstance();

        private android.support.v4.app.Fragment frag2= InventoryFragment.newInstance();

        public SalesSummaryFragmentPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public android.support.v4.app.Fragment getItem(int position) {
            if(position == 0){
                return frag1;
            }else{
                return frag2;
            }
        }

        @Override
        public CharSequence getPageTitle (int position) {
            if(position == 0){
                return "Sales";
            }else{
                return "Inventory";
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    }
}
