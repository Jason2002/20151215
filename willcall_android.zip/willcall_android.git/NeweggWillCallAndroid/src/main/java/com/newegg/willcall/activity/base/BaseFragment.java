package com.newegg.willcall.activity.base;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.v4.app.Fragment;

/**
 * Created by JaredLuo on 14-4-9.
 */
public class BaseFragment extends Fragment {
    private ProgressDialog mProgressDialog;

    protected void showProgressDialog() {
        showProgressDialog(getActivity());
    }

    protected void showProgressDialog(Context context) {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(context);
        }
        mProgressDialog.show();
        mProgressDialog.setContentView(com.newegg.willcall.R.layout.progress_dialog_layout);
    }

    protected void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()){
            mProgressDialog.dismiss();
        }

    }
}
