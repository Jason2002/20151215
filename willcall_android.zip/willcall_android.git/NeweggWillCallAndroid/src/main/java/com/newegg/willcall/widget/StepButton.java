package com.newegg.willcall.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

import com.newegg.willcall.R;
import com.newegg.willcall.utils.ScreenUtil;
import com.newegg.willcall.utils.StringUtil;

/**
 * Created by JaredLuo on 14-4-10.
 */
public class StepButton extends View {

    private int currentStep = 0;
    private int totalSteps = 1;
    private Paint textPaint;


    public StepButton(Context context) {
        super(context);
        init();
    }

    public StepButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public StepButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        if(!isInEditMode()) {
            init();
        }
    }

    private void init() {
        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setAntiAlias(true);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextSize(ScreenUtil.sp2px(16));
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setTotalSteps(int steps) {
        this.totalSteps = steps;
    }

    public void setCurrentStep(int step) {
        this.currentStep = step;
    }

    public int getTotalSteps() {
        return this.totalSteps;
    }

    public int getCurrentSteps() {
        return this.currentStep;
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();

        int stepWidth = width / totalSteps;

        Drawable drawable = getResources().getDrawable(R.drawable.btn_focus);
        drawable.setBounds(0, 0, stepWidth * currentStep, height);
        drawable.draw(canvas);
        String text = "Checkout(" + currentStep + "/" + totalSteps + ")";
        canvas.drawText(text, getWidth() / 2, getHeight() / 2 + 10, textPaint);
    }
}
