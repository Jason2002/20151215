package com.newegg.willcall.entities.pos.salesSummary;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.List;

/**
 * Created by flyerabc on 14/12/24.
 */
public class InventoryListResDTO implements Serializable {
    @JSONField(name = "TotalSKU")
    private int totalSKU;

    @JSONField(name = "TotalSoldQty")
    private int totalSoldQty;

    @JSONField(name = "TotalInventory")
    private int totalInventory;

    @JSONField(name = "ItemInventories")
    private List<ItemInventoryResDTO> itemInventories;

    public int getTotalSKU() {
        return totalSKU;
    }

    public void setTotalSKU(int totalSKU) {
        this.totalSKU = totalSKU;
    }

    public int getTotalSoldQty() {
        return totalSoldQty;
    }

    public void setTotalSoldQty(int totalSoldQty) {
        this.totalSoldQty = totalSoldQty;
    }

    public int getTotalInventory() {
        return totalInventory;
    }

    public void setTotalInventory(int totalInventory) {
        this.totalInventory = totalInventory;
    }

    public List<ItemInventoryResDTO> getItemInventories() {
        return itemInventories;
    }

    public void setItemInventories(List<ItemInventoryResDTO> itemInventories) {
        this.itemInventories = itemInventories;
    }
}


