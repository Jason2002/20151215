
package com.newegg.willcall.utils;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.newegg.willcall.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class StringUtil {

    public static boolean isEmpty(String value) {
        return value == null || value.trim().equals("") || value.length() == 0;
    }

    public static boolean isEmail(String str) {

        Pattern pattern = Pattern
                .compile("^((([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+(\\.([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22))@((([a-zA-Z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-zA-Z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-zA-Z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-zA-Z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.)+(([a-zA-Z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-zA-Z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-zA-Z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-zA-Z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.?$");
        Matcher isEMail = pattern.matcher(str);
        if (!isEMail.matches()) {
            return false;
        }
        return true;
    }

    public static boolean isUrl(String str) {
        Pattern pattern = Pattern
                .compile("^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]");
        Matcher isEMail = pattern.matcher(str);
        if (!isEMail.matches()) {
            return false;
        }
        return true;
    }

    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }

    public static boolean isTrackingNUmber(String trackingNumber) {
        if (TextUtils.isEmpty(trackingNumber))
            return false;
        Pattern p = Pattern.compile("^[A-Za-z0-9]+$");
        return p.matcher(trackingNumber.trim()).matches();
    }

    public static String formatInputTrackingNumber(String inputValue) {
        String prefix = "WILLCALL";
        String lowerCasePreFix = prefix.toLowerCase();
        if (inputValue.startsWith(prefix))
            return inputValue;
        if (inputValue.startsWith(lowerCasePreFix))
            return inputValue.replace(lowerCasePreFix, prefix);
        if (inputValue.toLowerCase().contains(lowerCasePreFix))
            return inputValue.toLowerCase().replace(lowerCasePreFix, prefix);
        if (StringUtil.isNumeric(inputValue))
            return prefix + inputValue;
        return inputValue;
    }

    public static <T> T deepClone(T obj, Class<T> c){
        return JSON.parseObject(JSON.toJSONString(obj), c);
    }

    public static boolean isAlphaNumeric(String s){
        String pattern= "^[a-zA-Z0-9]*$";
        if(s.matches(pattern)){
            return true;
        }
        return false;
    }
}
