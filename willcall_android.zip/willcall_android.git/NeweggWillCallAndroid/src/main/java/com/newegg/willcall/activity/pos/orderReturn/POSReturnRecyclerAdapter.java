package com.newegg.willcall.activity.pos.orderReturn;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.newegg.willcall.R;
import com.newegg.willcall.entities.pos.orderReturn.POSReturnTransactionDTO;
import com.newegg.willcall.entities.pos.orderReturn.UIGroupedPOSReturnTransaction;
import com.newegg.willcall.utils.CurrencyUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class POSReturnRecyclerAdapter extends RecyclerView.Adapter<POSReturnRecyclerAdapter.ViewHolder>{
    private List<UIGroupedPOSReturnTransaction> mGroupedList = new ArrayList<UIGroupedPOSReturnTransaction>();
    private Context mContext;

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pos_return_detail_cell, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        UIGroupedPOSReturnTransaction item = mGroupedList.get(position);
        holder.itemDescTextView.setText(String.valueOf(item.getItemDescption()));
        holder.qtyTextView.setText(String.valueOf(item.getSerialNumberList().size()));

        BigDecimal extendPrice = item.getUnitPrice().multiply(new BigDecimal(""+item.getSerialNumberList().size()));
        holder.priceTextView.setText(CurrencyUtils.getCurrencyFormat(extendPrice));

        String snText = "";
        for(int i=0;i<item.getSerialNumberList().size();i++){
            snText += mContext.getText(R.string.pos_return_serial_number) + " " + item.getSerialNumberList().get(i);
            if(i != item.getSerialNumberList().size()-1){
                snText += "\r\n";
            }
        }
        holder.snTextView.setText(snText);

        if(getItemCount()-1 == position){
            holder.dividerView.setVisibility(View.INVISIBLE);
        }else{
            holder.dividerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return mGroupedList.size();
    }


    public void addItem(POSReturnTransactionDTO item){
        UIGroupedPOSReturnTransaction found = findByItemNumber(item.getItemNumber());
        if(found == null) {
            found = new UIGroupedPOSReturnTransaction();
            found.setItemDescption(item.getItemDescption());
            found.setItemNumber(item.getItemNumber());
            found.setUnitPrice(item.getUnitPrice());
            found.setSerialNumberList(new ArrayList<String>());
            found.getSerialNumberList().add(item.getSerialNumber());
            mGroupedList.add(found);
        }else{
            found.getSerialNumberList().add(item.getSerialNumber());
        }
    }

    private UIGroupedPOSReturnTransaction findByItemNumber(String itemNumber){
        for(UIGroupedPOSReturnTransaction item : mGroupedList) {
            if(item.getItemNumber().equalsIgnoreCase(itemNumber.trim())){
                return item;
            }
        }
        return null;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemDescTextView;
        public TextView qtyTextView;
        public TextView snTextView;
        public TextView priceTextView;
        public View dividerView;

        public ViewHolder(View itemView) {
            super(itemView);
            itemDescTextView = (TextView) itemView.findViewById(R.id.order_detail_cell_title);
            qtyTextView = (TextView) itemView.findViewById(R.id.order_detail_cell_qty);
            snTextView = (TextView) itemView.findViewById(R.id.order_detail_cell_sn);
            priceTextView = (TextView) itemView.findViewById(R.id.order_detail_cell_price);
            dividerView =  itemView.findViewById(R.id.order_detail_cell_divider);
        }
    }

}
