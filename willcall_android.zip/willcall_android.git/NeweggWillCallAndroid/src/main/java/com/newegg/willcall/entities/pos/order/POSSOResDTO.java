package com.newegg.willcall.entities.pos.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.newegg.willcall.entities.ErrorResponseInfo;

import java.io.Serializable;

/**
 * Created by jaredluo on 12/24/14.
 */
public class POSSOResDTO extends ErrorResponseInfo implements Serializable{
    public final String OrderType = "101";

    private static final long serialVersionUID = -1608333034531185519L;
    @JSONField(name = "SONumber")
    private int soNumber;
    @JSONField(name = "CreditCardResInfo")
    private CreditCardDTO creditCardResInfo;

    public int getSoNumber() {
        return soNumber;
    }

    public void setSoNumber(int soNumber) {
        this.soNumber = soNumber;
    }

    public CreditCardDTO getCreditCardResInfo() {
        return creditCardResInfo;
    }

    public void setCreditCardResInfo(CreditCardDTO creditCardResInfo) {
        this.creditCardResInfo = creditCardResInfo;
    }
}
