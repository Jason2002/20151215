package com.newegg.willcall.activity.pos.salesSummary;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Response;
import com.newegg.willcall.R;
import com.newegg.willcall.activity.base.BaseFragment;
import com.newegg.willcall.adapter.HeaderViewRecyclerAdapter;
import com.newegg.willcall.entities.ErrorResponseInfo;
import com.newegg.willcall.entities.pos.salesSummary.InventoryListResDTO;
import com.newegg.willcall.entities.pos.salesSummary.ItemInventoryResDTO;
import com.newegg.willcall.http.FastJsonObjectRequest;
import com.newegg.willcall.http.HttpConfig;
import com.newegg.willcall.http.VolleyUtil;
import com.newegg.willcall.utils.ToastUtil;

import java.util.ArrayList;
import java.util.List;


public class InventoryFragment extends BaseFragment implements SalesSummaryActivity.OnSearchListener{

    private View mMainView;
    private View mHeaderView;
    private RecyclerView mRecyclerView;
    private TextView mTotalSKUTextView;
    private TextView mTotalSoldQtyTextView;
    private TextView mTotalInventoryTextView;

    private HeaderViewRecyclerAdapter mAdapter;
    private Context mContext;
    private List<ItemInventoryResDTO> mList = new ArrayList<ItemInventoryResDTO>();

    public static InventoryFragment newInstance() {
        InventoryFragment fragment = new InventoryFragment();
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = getActivity();
        mMainView = inflater.inflate(R.layout.pos_sales_summary_inventory, container, false);
        mHeaderView = inflater.inflate(R.layout.pos_sales_summary_inventory_header, container, false);
        mRecyclerView = (RecyclerView) mMainView.findViewById(R.id.recycler_view);

        mTotalSoldQtyTextView = (TextView)mHeaderView.findViewById(R.id.total_sold_qty_textView);
        mTotalSKUTextView = (TextView)mHeaderView.findViewById(R.id.total_sku_textView);
        mTotalInventoryTextView = (TextView)mHeaderView.findViewById(R.id.total_inventory_textView);

        mAdapter = new HeaderViewRecyclerAdapter(new InventoryRecyclerAdapter(mList));
        mAdapter.addHeaderView(mHeaderView);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mAdapter);

        callService();

        return mMainView;
    }

    private void callService(){
        showProgressDialog();
        String url = HttpConfig.getFormatUrl(HttpConfig.POS_SUMMARY_INVENTORY);
        FastJsonObjectRequest<InventoryListResDTO> request = new FastJsonObjectRequest<InventoryListResDTO>(mContext, InventoryListResDTO.class,
                url, new Response.Listener<InventoryListResDTO>() {
            @Override
            public void onResponse(InventoryListResDTO result) {
                hideProgressDialog();
                BindData(result);
            }
        }, new FastJsonObjectRequest.OnErrorListener() {

            @Override
            public void onError(ErrorResponseInfo info) {
                hideProgressDialog();
                if(info != null && info.getMessage() != null){
                    ToastUtil.show(mContext, info.getMessage());
                }
            }
        });

        VolleyUtil.addToRequestQueue(mContext, request);
    }

    private void BindData(InventoryListResDTO info){
        mList.clear();
        if(info == null){
            mTotalSKUTextView.setText("0");
            mTotalSoldQtyTextView.setText("0");
            mTotalInventoryTextView.setText("0");
        }else {
            mTotalSKUTextView.setText("" + info.getTotalSKU());
            mTotalSoldQtyTextView.setText("" + info.getTotalSoldQty());
            mTotalInventoryTextView.setText("" + info.getTotalInventory());
            if(info.getItemInventories() != null){
                mList.addAll(info.getItemInventories());
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void doSearch(final String input) {
        boolean found = false;
        for(ItemInventoryResDTO item : mList){
            if(item.getItemNumber().equalsIgnoreCase(input.trim())){
                List<ItemInventoryResDTO> list = new ArrayList<ItemInventoryResDTO>();
                list.add(item);
                mRecyclerView.setAdapter(new InventoryRecyclerAdapter(list));
                found = true;
                break;
            }
        }

        if(!found){
            ToastUtil.show(mContext, "Can not found Item "+input);
        }
    }
}
