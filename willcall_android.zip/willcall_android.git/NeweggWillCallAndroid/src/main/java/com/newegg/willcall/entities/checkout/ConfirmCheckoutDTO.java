package com.newegg.willcall.entities.checkout;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * Created by JaredLuo on 14-4-12.
 */
public class ConfirmCheckoutDTO implements Serializable {
    private static final long serialVersionUID = -2873698017235180848L;
    @JSONField(name = "TaskID")
    private int taskID;
    @JSONField(name = "UploadFileBase64String")
    private String uploadFileBase64String;
    @JSONField(name = "UserID")
    private String userID;
    @JSONField(name = "WCCNumber")
    private String wccNumber;


    public int getTaskID() {
        return taskID;
    }

    public void setTaskID(int taskID) {
        this.taskID = taskID;
    }

    public String getUploadFileBase64String() {
        return uploadFileBase64String;
    }

    public void setUploadFileBase64String(String uploadFileBase64String) {
        this.uploadFileBase64String = uploadFileBase64String;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getWccNumber() {
        return wccNumber;
    }

    public void setWccNumber(String wccNumber) {
        this.wccNumber = wccNumber;
    }
}
